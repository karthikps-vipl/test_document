--
-- FULL POSTGRESQL SQL DUMP
-- Project: Centralized User Management + Macro Node Synchronization
--
-- CENTRAL DATABASE:
--   user_management_db
--   Authoritative user records, application access, audit and sync outbox.
--
-- NODE DATABASE:
--   Run the separate NODE DATABASE SECTION at the end on EACH receiving
--   Macro Node database. It creates local user/profile replicas and a
--   batch receipt log. Password hashes are not replicated because the
--   central service validates credentials.
--
-- Create database separately:
--   CREATE DATABASE user_management_db;
-- Connect:
--   \c user_management_db
-- Execute central section:
--   psql -U <db_user> -d user_management_db -f user_management_full_dump.sql
--
-- IMPORTANT:
--   * Replace example node IP addresses, ports and application URLs.
--   * Replace application client-secret placeholders with real hashes.
--   * Never store plaintext passwords or raw application secrets.
--   * users.photo stores a file/object-storage path or key, not image bytes.
--   * Individual applications continue to manage their own JWTs and roles.
--

-- =====================================================================
-- CENTRAL DATABASE SECTION
-- =====================================================================

BEGIN;

-- 1. Common updated_at trigger function
CREATE OR REPLACE FUNCTION update_modified_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Master tables
CREATE TABLE rank_master (
    rank_id BIGSERIAL PRIMARY KEY,
    rank_code VARCHAR(30) UNIQUE,
    rank_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE macro_node_master (
    macro_node_id BIGSERIAL PRIMARY KEY,
    macro_node_code VARCHAR(50) NOT NULL UNIQUE,
    macro_node_name VARCHAR(150) NOT NULL UNIQUE,
    ip_address INET NOT NULL,
    port_number INTEGER NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    CONSTRAINT chk_macro_node_port
        CHECK (port_number BETWEEN 1 AND 65535)
);

CREATE TABLE group_level_master (
    group_level_id BIGSERIAL PRIMARY KEY,
    group_level_code VARCHAR(50) UNIQUE,
    group_level_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE group_node_master (
    group_node_id BIGSERIAL PRIMARY KEY,
    macro_node_id BIGINT NOT NULL,
    group_node_code VARCHAR(50),
    group_node_name VARCHAR(150) NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    CONSTRAINT fk_group_node_macro
        FOREIGN KEY (macro_node_id)
        REFERENCES macro_node_master(macro_node_id),
    CONSTRAINT uq_group_node_code
        UNIQUE (macro_node_id, group_node_code),
    CONSTRAINT uq_group_node_id_macro
        UNIQUE (group_node_id, macro_node_id)
);

CREATE TABLE user_type_master (
    user_type_id BIGSERIAL PRIMARY KEY,
    user_type_code VARCHAR(50) UNIQUE,
    user_type_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

-- Central MDM portal roles only. Application-specific roles remain
-- in each individual application.
CREATE TABLE mdm_role (
    id BIGSERIAL PRIMARY KEY,
    role_name VARCHAR(100) NOT NULL UNIQUE,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

-- 3. Registered applications
-- client_secret_hash stores a secure hash. The raw secret is generated
-- by the backend and shown only once.
CREATE TABLE application_master (
    application_id BIGSERIAL PRIMARY KEY,
    application_code VARCHAR(50) NOT NULL UNIQUE,
    application_name VARCHAR(150) NOT NULL,
    application_url VARCHAR(255),
    client_id VARCHAR(100) NOT NULL UNIQUE,
    client_secret_hash VARCHAR(255) NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

-- 4. Central users
-- password_hash contains a BCrypt/Argon2 hash.
-- photo contains a storage path/key, not the image binary.
-- Composite FK ensures group_node belongs to selected macro_node.
CREATE TABLE users (
    user_id BIGSERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    mdm_role_id BIGINT,
    rank_id BIGINT,
    email_address VARCHAR(150),
    macro_node_id BIGINT,
    phone_number VARCHAR(20),
    group_level_id BIGINT,
    group_node_id BIGINT,
    user_type_id BIGINT,
    photo VARCHAR(500),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    failed_login_attempts INTEGER NOT NULL DEFAULT 0,
    account_locked_until TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,

    CONSTRAINT fk_users_mdm_role
        FOREIGN KEY (mdm_role_id) REFERENCES mdm_role(id),
    CONSTRAINT fk_user_rank
        FOREIGN KEY (rank_id) REFERENCES rank_master(rank_id),
    CONSTRAINT fk_user_macro_node
        FOREIGN KEY (macro_node_id)
        REFERENCES macro_node_master(macro_node_id),
    CONSTRAINT fk_user_group_level
        FOREIGN KEY (group_level_id)
        REFERENCES group_level_master(group_level_id),
    CONSTRAINT fk_user_group_node
        FOREIGN KEY (group_node_id, macro_node_id)
        REFERENCES group_node_master(group_node_id, macro_node_id),
    CONSTRAINT fk_user_type
        FOREIGN KEY (user_type_id) REFERENCES user_type_master(user_type_id),
    CONSTRAINT chk_failed_login_attempts
        CHECK (failed_login_attempts >= 0)
);

CREATE UNIQUE INDEX uq_users_username_lower ON users (LOWER(username));
CREATE INDEX idx_users_macro_node ON users (macro_node_id);
CREATE INDEX idx_users_group_level ON users (group_level_id);
CREATE INDEX idx_users_group_node ON users (group_node_id);
CREATE INDEX idx_users_mdm_role ON users (mdm_role_id);
CREATE INDEX idx_users_email ON users (LOWER(email_address));

-- 5. User-to-application access mapping.
-- This controls application access only, not application-specific roles.
CREATE TABLE user_application_mapping (
    mapping_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    assigned_by BIGINT,
    CONSTRAINT fk_mapping_user
        FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT fk_mapping_application
        FOREIGN KEY (application_id)
        REFERENCES application_master(application_id),
    CONSTRAINT fk_mapping_assigned_by
        FOREIGN KEY (assigned_by) REFERENCES users(user_id),
    CONSTRAINT uq_user_application
        UNIQUE (user_id, application_id)
);

CREATE INDEX idx_user_application_user
    ON user_application_mapping(user_id);
CREATE INDEX idx_user_application_app
    ON user_application_mapping(application_id);

-- 6. Login audit
CREATE TABLE login_audit (
    audit_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT,
    application_id BIGINT,
    username VARCHAR(100) NOT NULL,
    login_status VARCHAR(20) NOT NULL,
    failure_reason VARCHAR(255),
    ip_address INET,
    user_agent TEXT,
    login_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT fk_audit_application
        FOREIGN KEY (application_id)
        REFERENCES application_master(application_id) ON DELETE SET NULL,
    CONSTRAINT chk_login_status
        CHECK (login_status IN ('SUCCESS', 'FAILED', 'BLOCKED'))
);

CREATE INDEX idx_login_audit_user ON login_audit(user_id);
CREATE INDEX idx_login_audit_time ON login_audit(login_time);
CREATE INDEX idx_login_audit_username ON login_audit(username);
CREATE INDEX idx_login_audit_application ON login_audit(application_id);

-- 7. Password reset token support (for forgot/reset-password APIs).
-- Store only a hash of the reset token.
CREATE TABLE password_reset_token (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    token_hash VARCHAR(255) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    used_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_password_reset_user
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_password_reset_user ON password_reset_token(user_id);
CREATE INDEX idx_password_reset_expiry ON password_reset_token(expires_at);

-- 8. Synchronization batch: one batch for one user or a bulk set.
CREATE TABLE user_sync_batch (
    batch_id BIGSERIAL PRIMARY KEY,
    batch_reference UUID NOT NULL UNIQUE,
    operation_type VARCHAR(30) NOT NULL,
    total_records INTEGER NOT NULL DEFAULT 0,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    CONSTRAINT chk_batch_operation
        CHECK (operation_type IN (
            'USER_CREATE', 'USER_UPDATE', 'USER_DELETE',
            'APPLICATION_UPDATE'
        )),
    CONSTRAINT chk_batch_status
        CHECK (sync_status IN (
            'PENDING', 'PROCESSING', 'COMPLETED',
            'PARTIAL_FAILED', 'FAILED'
        )),
    CONSTRAINT chk_batch_total_records CHECK (total_records >= 0)
);

CREATE INDEX idx_user_sync_batch_status ON user_sync_batch(sync_status);
CREATE INDEX idx_user_sync_batch_created ON user_sync_batch(created_at);

-- 9. Per-node delivery status, one row per batch and target Macro Node.
CREATE TABLE user_sync_node_status (
    id BIGSERIAL PRIMARY KEY,
    batch_id BIGINT NOT NULL,
    macro_node_id BIGINT NOT NULL,
    total_records INTEGER NOT NULL DEFAULT 0,
    success_records INTEGER NOT NULL DEFAULT 0,
    failed_records INTEGER NOT NULL DEFAULT 0,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    retry_count INTEGER NOT NULL DEFAULT 0,
    last_attempt_at TIMESTAMP,
    next_retry_at TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    CONSTRAINT fk_sync_node_batch
        FOREIGN KEY (batch_id) REFERENCES user_sync_batch(batch_id),
    CONSTRAINT fk_sync_node_macro
        FOREIGN KEY (macro_node_id)
        REFERENCES macro_node_master(macro_node_id),
    CONSTRAINT uq_batch_macro_node UNIQUE (batch_id, macro_node_id),
    CONSTRAINT chk_node_sync_status
        CHECK (sync_status IN (
            'PENDING', 'PROCESSING', 'COMPLETED', 'FAILED'
        )),
    CONSTRAINT chk_node_sync_counts
        CHECK (
            total_records >= 0 AND success_records >= 0
            AND failed_records >= 0
            AND success_records + failed_records <= total_records
        ),
    CONSTRAINT chk_node_retry_count CHECK (retry_count >= 0)
);

CREATE INDEX idx_user_sync_node_status
    ON user_sync_node_status(sync_status);
CREATE INDEX idx_user_sync_node_retry
    ON user_sync_node_status(next_retry_at);
CREATE INDEX idx_user_sync_node_macro
    ON user_sync_node_status(macro_node_id);

-- 10. Transactional outbox.
-- Insert user change + outbox event in the SAME DB transaction.
-- Do not put plaintext passwords or raw application secrets in payload.
CREATE TABLE user_sync_outbox (
    id BIGSERIAL PRIMARY KEY,
    batch_id BIGINT NOT NULL,
    user_id BIGINT,
    operation_type VARCHAR(30) NOT NULL,
    payload JSONB NOT NULL,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    CONSTRAINT fk_outbox_batch
        FOREIGN KEY (batch_id) REFERENCES user_sync_batch(batch_id),
    CONSTRAINT fk_outbox_user
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT chk_outbox_operation
        CHECK (operation_type IN (
            'USER_CREATE', 'USER_UPDATE', 'USER_DELETE',
            'APPLICATION_UPDATE'
        )),
    CONSTRAINT chk_outbox_status
        CHECK (sync_status IN (
            'PENDING', 'PROCESSING', 'PROCESSED', 'FAILED'
        ))
);

CREATE INDEX idx_user_sync_outbox_status
    ON user_sync_outbox(sync_status);
CREATE INDEX idx_user_sync_outbox_batch
    ON user_sync_outbox(batch_id);
CREATE INDEX idx_user_sync_outbox_user
    ON user_sync_outbox(user_id);
CREATE INDEX idx_user_sync_outbox_created
    ON user_sync_outbox(created_at);

-- 11. updated_at triggers
CREATE TRIGGER trg_rank_master_updated
BEFORE UPDATE ON rank_master
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_macro_node_master_updated
BEFORE UPDATE ON macro_node_master
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_group_level_master_updated
BEFORE UPDATE ON group_level_master
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_group_node_master_updated
BEFORE UPDATE ON group_node_master
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_user_type_master_updated
BEFORE UPDATE ON user_type_master
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_mdm_role_updated
BEFORE UPDATE ON mdm_role
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_application_master_updated
BEFORE UPDATE ON application_master
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_users_updated
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

CREATE TRIGGER trg_user_sync_node_status_updated
BEFORE UPDATE ON user_sync_node_status
FOR EACH ROW EXECUTE FUNCTION update_modified_timestamp();

COMMIT;

-- =====================================================================
-- OPTIONAL SAMPLE MASTER DATA
-- Review/replace these examples with actual organizational data.
-- =====================================================================

INSERT INTO rank_master (rank_code, rank_name, description) VALUES
    ('R001', 'Manager', 'Manager rank'),
    ('R002', 'Senior Manager', 'Senior manager rank'),
    ('R003', 'Engineer', 'Engineer rank'),
    ('R004', 'Administrator', 'Administrator rank');

INSERT INTO macro_node_master
    (macro_node_code, macro_node_name, ip_address, port_number, description)
VALUES
    ('MN001', 'Bangalore', '192.168.1.101', 8080, 'Bangalore Macro Node'),
    ('MN002', 'Mumbai', '192.168.1.102', 8080, 'Mumbai Macro Node'),
    ('MN003', 'Hyderabad', '192.168.1.103', 8080, 'Hyderabad Macro Node');

INSERT INTO group_level_master (group_level_code, group_level_name) VALUES
    ('GL001', 'Level 1'),
    ('GL002', 'Level 2'),
    ('GL003', 'Level 3');

INSERT INTO group_node_master
    (macro_node_id, group_node_code, group_node_name)
VALUES
    (1, 'GN001', 'Bangalore North'),
    (1, 'GN002', 'Bangalore South'),
    (2, 'GN003', 'Mumbai Central'),
    (2, 'GN004', 'Mumbai East');

INSERT INTO user_type_master (user_type_code, user_type_name) VALUES
    ('UT001', 'Internal'),
    ('UT002', 'External'),
    ('UT003', 'Guest');

INSERT INTO mdm_role (role_name, sort_order) VALUES
    ('Super Admin', 1),
    ('Admin', 2),
    ('User', 3);

-- Replace placeholder hashes and example URLs before using these records.
-- In production, generate client IDs and secrets securely in the backend.
INSERT INTO application_master
    (application_code, application_name, application_url,
     client_id, client_secret_hash, description)
VALUES
    ('NMS', 'Network Management System',
     'https://nms.company.com', 'nms-client',
     '<REPLACE_WITH_REAL_CLIENT_SECRET_HASH>',
     'Network Management System'),
    ('CNMS', 'Core Network Management System',
     'https://cnms.company.com', 'cnms-client',
     '<REPLACE_WITH_REAL_CLIENT_SECRET_HASH>',
     'Core Network Management System'),
    ('RNMS', 'Radio Network Management System',
     'https://rnms.company.com', 'rnms-client',
     '<REPLACE_WITH_REAL_CLIENT_SECRET_HASH>',
     'Radio Network Management System');

-- =====================================================================
-- NODE DATABASE SECTION
-- =====================================================================
-- Run this section separately on EACH receiving Macro Node database.
-- Do NOT run this section in the central database.
--
-- Node replica users do not store password_hash. The central service
-- validates credentials. The central user_id is preserved as the local ID.
-- Add any application-specific local columns/roles in the application DB
-- as required by that application.

BEGIN;

CREATE TABLE IF NOT EXISTS users (
    user_id BIGINT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    mdm_role_id BIGINT,
    rank_id BIGINT,
    email_address VARCHAR(150),
    macro_node_id BIGINT,
    phone_number VARCHAR(20),
    group_level_id BIGINT,
    group_node_id BIGINT,
    user_type_id BIGINT,
    photo VARCHAR(500),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    central_created_at TIMESTAMP,
    central_updated_at TIMESTAMP,
    last_synced_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_node_users_username_lower
    ON users (LOWER(username));

CREATE TABLE IF NOT EXISTS user_application_mapping (
    mapping_id BIGINT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    assigned_at TIMESTAMP,
    last_synced_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_node_user_application UNIQUE (user_id, application_id)
);

CREATE INDEX IF NOT EXISTS idx_node_user_application_user
    ON user_application_mapping(user_id);

CREATE TABLE IF NOT EXISTS sync_batch_log (
    id BIGSERIAL PRIMARY KEY,
    batch_reference UUID NOT NULL UNIQUE,
    source_node VARCHAR(100) NOT NULL,
    operation_type VARCHAR(30) NOT NULL,
    total_records INTEGER NOT NULL DEFAULT 0,
    success_records INTEGER NOT NULL DEFAULT 0,
    failed_records INTEGER NOT NULL DEFAULT 0,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'PROCESSING',
    received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    CONSTRAINT chk_node_batch_status
        CHECK (sync_status IN ('PROCESSING', 'COMPLETED', 'FAILED')),
    CONSTRAINT chk_node_batch_counts
        CHECK (
            total_records >= 0 AND success_records >= 0
            AND failed_records >= 0
        )
);

CREATE INDEX IF NOT EXISTS idx_node_sync_batch_received
    ON sync_batch_log(received_at);
CREATE INDEX IF NOT EXISTS idx_node_sync_batch_status
    ON sync_batch_log(sync_status);

COMMIT;

-- =====================================================================
-- END OF DUMP
-- =====================================================================
