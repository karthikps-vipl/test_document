package org.bel.location.controller;

import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.sql.DataSource;
import java.sql.Connection;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/internal/health")
@RequiredArgsConstructor
public class LocalSyncHealthController {
    private final DataSource dataSource;

    @GetMapping("/sync")
    public ResponseEntity<Map<String, Object>> health() {
        boolean dbUp = false;
        try (Connection connection = dataSource.getConnection()) {
            dbUp = connection.isValid(2);
        } catch (Exception ignored) { }
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("service", "node-sync");
        body.put("application", "UP");
        body.put("database", dbUp ? "UP" : "DOWN");
        body.put("status", dbUp ? "UP" : "DOWN");
        body.put("checkedAt", OffsetDateTime.now());
        return ResponseEntity.status(dbUp ? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE).body(body);
    }
}
