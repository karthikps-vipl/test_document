package org.bel.location.service;

import lombok.RequiredArgsConstructor;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.stereotype.Service;
import java.net.InetAddress;

@Service
@RequiredArgsConstructor
public class CurrentNodeResolver {
	private final NodeRegistryRepository repo;

	public NodeRegistry getCurrentNode() {
		String ip = getLocalIpAddress();
		return repo.findByIpAddress(ip).orElseThrow(
				() -> new IllegalStateException("Current server IP " + ip + " is not registered in node_registry"));
	}

	public String getCurrentNodeId() {
		return getCurrentNode().getNodeId();
	}

	private String getLocalIpAddress() {
		try {
			return InetAddress.getLocalHost().getHostAddress();
		} catch (Exception e) {
			throw new IllegalStateException("Unable to determine local server IP", e);
		}
	}
}
