package org.bel.location.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeHealthMonitor {
    private final RestClient restClient;
    private final NodeRegistryService nodeRegistryService;
    private final SyncOutboxDeliveryRepository deliveryRepository;
    private final Map<String, HealthState> states = new ConcurrentHashMap<>();

    @Value("${sync.health.endpoint:/internal/health/sync}")
    private String healthEndpoint;

    @Scheduled(fixedDelayString = "${sync.health.check-interval-ms:15000}", initialDelayString = "${sync.health.initial-delay-ms:3000}")
    public void refreshHealth() {
        List<NodeRegistry> peers = nodeRegistryService.getOtherRegisteredNodes();
        List<String> healthyNodeIds = new ArrayList<>();

        for (NodeRegistry node : peers) {
            if (!"ACTIVE".equalsIgnoreCase(node.getStatus())) {
                states.put(node.getNodeId(), new HealthState(false, "INACTIVE_IN_REGISTRY", LocalDateTime.now()));
                continue;
            }
            try {
                String url = "http://" + node.getIpAddress() + ":" + node.getPort() + healthEndpoint;
                restClient.get().uri(url).retrieve().toBodilessEntity();
                states.put(node.getNodeId(), new HealthState(true, "UP", LocalDateTime.now()));
                healthyNodeIds.add(node.getNodeId());
            } catch (Exception ex) {
                states.put(node.getNodeId(), new HealthState(false, "DOWN", LocalDateTime.now()));
                log.debug("Node {} health check failed: {}", node.getNodeId(), ex.getMessage());
            }
        }

        // Reconcile every healthy peer each health cycle, not just on a cached transition.
        // This recovers deliveries even if a DOWN->UP transition was missed or this process restarted.
        if (!healthyNodeIds.isEmpty()) {
            try {
                int requeued = deliveryRepository.requeueWaitingDeliveriesForHealthyNodes(healthyNodeIds);
                if (requeued > 0) {
                    log.info("Requeued {} waiting sync deliveries for healthy peers", requeued);
                }
            } catch (Exception ex) {
                log.error("Healthy peers were detected, but waiting deliveries could not be reconciled", ex);
            }
        }
    }

    /** Immediately marks a peer down after a sync connection failure. */
    public void markUnhealthy(String nodeId, String reason) {
        states.put(nodeId, new HealthState(false, "DOWN", LocalDateTime.now()));
        log.debug("Marked node {} unhealthy after sync failure: {}", nodeId, reason);
    }

    public boolean isHealthy(String nodeId) {
        HealthState state = states.get(nodeId);
        return state != null && state.healthy();
    }

    public HealthState getState(String nodeId) {
        return states.getOrDefault(nodeId, new HealthState(false, "UNKNOWN", null));
    }

    public record HealthState(boolean healthy, String state, LocalDateTime checkedAt) {}
}
