package org.bel.location.service;

import lombok.RequiredArgsConstructor;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NodeRegistryService {
	private final NodeRegistryRepository repo;
	private final CurrentNodeResolver resolver;

	public NodeRegistry getCurrentNode() {
		return resolver.getCurrentNode();
	}

	public String getCurrentNodeId() {
		return resolver.getCurrentNodeId();
	}

	public List<NodeRegistry> getOtherActiveNodes() {
		System.out.println("currrent Node id:" + resolver.getCurrentNode());
		return repo.findByStatusAndNodeIdNot("ACTIVE", resolver.getCurrentNodeId());
	}
    public List<NodeRegistry> getOtherRegisteredNodes() {
        return repo.findByNodeIdNot(resolver.getCurrentNodeId());
    }
}
