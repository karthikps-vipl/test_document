package org.bel.location.dto;

import java.time.LocalDateTime;

public record LocationResponse(Integer userId, String nodeId, Double latitude, Double longitude,
		 LocalDateTime timestamp, Long version) {
}
