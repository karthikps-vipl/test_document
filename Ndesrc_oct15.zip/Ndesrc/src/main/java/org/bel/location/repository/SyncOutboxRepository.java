package org.bel.location.repository;

import java.util.Optional;
import java.util.UUID;

import org.bel.location.entity.SyncOutbox;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SyncOutboxRepository extends JpaRepository<SyncOutbox, Long> {

    Optional<SyncOutbox> findByEventId(UUID eventId);

    /**
     * Rotating pages of pending events allow the worker to reconcile old
     * pending rows without permanently starving later rows.
     */
    Page<SyncOutbox> findByStatusOrderByCreatedAtAsc(String status, Pageable pageable);

    long countByStatus(String status);
}
