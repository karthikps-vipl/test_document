package org.bel.location.repository;

import java.util.List;

import org.bel.location.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmUserRepository extends JpaRepository<MdmUser, Integer>{
//		@Query("SELECT u FROM MdmUser u " +
//		           "JOIN FETCH u.mdmNode n " +
//		           "JOIN u.mdmRole mr " +
//		           "WHERE mr.sortOrder > :sortOrder " +
//		           "AND u.userStats = :uStatus " +
//		           "AND u.id != :userId " +
//		           "AND NOT EXISTS (" +
//		           "   SELECT 1 FROM LaaGroupTrackingDtl d " +
//		           "   JOIN d.laaGroupTracking gt " +
//		           "   WHERE d.mdmUser.id = u.id " +
//		           "   AND gt.groupStats = :groupStats " +
//		           "   AND gt.id != :editGrpId" +
//		           ") " +
//		           "ORDER BY u.serviceId")
//		    List<MdmUser> findUsersNotInActiveGroup(
//		            @Param("sortOrder") Integer sortOrder,
//		            @Param("uStatus") Integer uStatus,
//		            @Param("userId") Integer userId,
//		            @Param("groupStats") Integer groupStats,
//		            @Param("editGrpId") Integer editGrpId);
}
