package org.bel.location.entity;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "user_location_history", schema = "tcs_laa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLocationHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user__id")
	private MdmUser mdmUser; //userId;
	
	@Column(name = "node_id", nullable = false)
	private String nodeId;
	
	@Column(nullable = false)
	@Min(-90)
	@Max(90)
	private Double latitude;
	
	@Column(nullable = false)
	@Min(-180)
	@Max(180)
	private Double longitude;
//	private BigDecimal accuracy;
	
	@Column(name = "location_timestamp", nullable = false)
	private OffsetDateTime locationTimestamp;
	
	@Column(name = "location_version", nullable = false)
	private Long locationVersion;
	
	@Column(name = "recorded_at", nullable = false)
	private OffsetDateTime recordedAt;
}
