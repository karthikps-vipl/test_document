package org.bel.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Entity
@Table(name = "user_location_sync_state", schema = "tcs_laa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLocationSyncState {
	@Id
	@Column(name = "user_id")
	private Integer userId;
	@Column(name = "last_synced_latitude")
	private Double lastSyncedLatitude;
	@Column(name = "last_synced_longitude")
	private Double lastSyncedLongitude;
	@Column(name = "last_synced_version")
	private Long lastSyncedVersion;
	@Column(name = "last_synced_at")
	private LocalDateTime lastSyncedAt;
	@Column(name = "last_local_update_at")
	private LocalDateTime lastLocalUpdateAt;
	@Column(name = "updated_at")
	private LocalDateTime updatedAt;
}
