package org.bel.location.repository;

import org.bel.location.entity.MdmNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmNodeRepository extends JpaRepository<MdmNode, Integer>{

}
