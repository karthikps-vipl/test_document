package org.bel.location.service;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

import org.bel.location.dto.LocationSyncEvent;
import org.bel.location.dto.SyncAckResponse;
import org.bel.location.entity.ProcessedSyncEvent;
import org.bel.location.entity.UserLocationLatest;
import org.bel.location.repository.ProcessedSyncEventRepository;
import org.bel.location.repository.UserLocationLatestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class LocationSyncService {
	private final UserLocationLatestRepository latestRepo;
	private final ProcessedSyncEventRepository processedRepo;
	private final NodeRegistryService nodeRegistryService;

	@Transactional
	public SyncAckResponse process(LocationSyncEvent event) {
		log.info("entered Process");
		String current = nodeRegistryService.getCurrentNodeId();
		if (processedRepo.existsById(event.eventId()))
			return new SyncAckResponse(event.eventId(), "ACKNOWLEDGED", current);
		UserLocationLatest old = latestRepo.findById(event.userId()).orElse(null);
		if (old != null && event.version() <= old.getLocationVersion()) {
			saveProcessed(event);
			return new SyncAckResponse(event.eventId(), "STALE_IGNORED", current);
		}
		latestRepo.save(UserLocationLatest.builder().userId(event.userId()).nodeId(event.sourceNodeId())
				.latitude(event.latitude()).longitude(event.longitude())
				.locationTimestamp(event.timestamp()).locationVersion(event.version()).updatedAt(LocalDateTime.now())
				.build());
		saveProcessed(event);
		return new SyncAckResponse(event.eventId(), "ACKNOWLEDGED", current);
	}

	private void saveProcessed(LocationSyncEvent e) {
		processedRepo.save(ProcessedSyncEvent.builder().eventId(e.eventId()).eventType(e.eventType())
				.sourceNodeId(e.sourceNodeId()).processedAt(OffsetDateTime.now()).build());
	}
}
