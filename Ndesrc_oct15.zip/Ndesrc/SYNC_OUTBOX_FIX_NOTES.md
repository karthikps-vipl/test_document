# Sync outbox fixes

## Behavior
- `sync_outbox` parent status is reconciled for existing PENDING events, including events that already have some or all delivery rows.
- Reconciliation rotates through pages of pending events so the first batch cannot permanently starve later events.
- Every currently registered peer receives a durable `sync_outbox_delivery` row for a pending event, even when that peer is inactive or its health is down. This is a record of required delivery, not a network request.
- A network synchronization request is dispatched only when the peer registry status is `ACTIVE` and the local health monitor reports sync service status `UP`.
- A delivery is acknowledged only after a valid acknowledgement response is received and saved.
- Parent status becomes `ACKNOWLEDGED` only when every currently registered peer has an `ACKNOWLEDGED` delivery row.
- Parent status refresh reloads the parent event by event ID after delivery persistence, avoiding stale detached entity state.
- Delivery claiming remains an atomic conditional database update to reduce duplicate concurrent dispatch.

## Important interpretation
`syncServiceStatus` is not a mapped column in `NodeRegistry` in this source. It is computed by `NodeHealthMonitor` from the remote health endpoint and exposed by the cluster health API. The eligibility rule is therefore `node_registry.status = ACTIVE` AND health-monitor state `UP`.

## Database
No new tables or columns are introduced. The existing database must allow the statuses used by the application (`PENDING`, `SENDING`, `FAILED`, `ACKNOWLEDGED`, `WAITING_FOR_NODE`).

## Verification
Build and test with the project's Java/Maven environment before deployment. This environment did not have Maven available, so no Maven compile/test result is claimed.



Ndesrc/src/main/java/org/bel/location/service/SyncOutboxWorker.java

Ndesrc/src/main/java/org/bel/location/repository/SyncOutboxRepository.java

Ndesrc/src/main/java/org/bel/location/service/NodeSyncService.java
