-- Run on EVERY node service database before deploying the code.
-- Dedicated tables: existing sync_outbox and sync_outbox_delivery are untouched.
CREATE TABLE IF NOT EXISTS tcs_laa.node_registry_outbox (
    event_id UUID PRIMARY KEY,
    source_node_id VARCHAR(100) NOT NULL,
    payload TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_error TEXT
);
CREATE INDEX IF NOT EXISTS idx_node_registry_outbox_status_created
    ON tcs_laa.node_registry_outbox(status, created_at);

CREATE TABLE IF NOT EXISTS tcs_laa.node_registry_outbox_delivery (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL REFERENCES tcs_laa.node_registry_outbox(event_id) ON DELETE CASCADE,
    target_node_id VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_error TEXT,
    CONSTRAINT uq_node_registry_delivery_event_target UNIQUE(event_id, target_node_id)
);
CREATE INDEX IF NOT EXISTS idx_node_registry_delivery_dispatch
    ON tcs_laa.node_registry_outbox_delivery(status, next_retry_at, created_at);
