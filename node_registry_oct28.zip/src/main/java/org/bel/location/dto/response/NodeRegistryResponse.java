package org.bel.location.dto.response;

import lombok.Data;
@Data
public class NodeRegistryResponse {
	private String nodeId;
	private String nodeName;
	private String ipAddress;
	private Integer port;
	private String status;
}
