package org.bel.location.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class NodeRegistryRequest {
	
	@NotBlank(message = "Node Id is required")
	private String nodeId;
	
	@NotBlank(message = "Ip address is required")
	@Pattern(
			regexp = "^((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$", 
    		message = "Invalid IPv4 format"
    		)
	private String ipAddress;
}
