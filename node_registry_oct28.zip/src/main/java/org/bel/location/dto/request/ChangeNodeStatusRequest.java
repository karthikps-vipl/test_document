package org.bel.location.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class ChangeNodeStatusRequest {
	@NotBlank(message = "Node Id is required")
	private String nodeId;
	
	@NotBlank(message = "Status is required")
    @Pattern(
    		 regexp = "^(?i)(ACTIVE|DEACTIVE)$", 
             message = "Status must be either 'ACTIVE' or 'DEACTIVE'"
             )
	private String status;
}
