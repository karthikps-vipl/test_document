package org.bel.location.dto.request;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddLocationRequest {

	@NotNull(message = "Latitude value is required")
	@Digits(integer = 2, fraction = 10, message = "Latitude must have up to 2 integer digits and 10 decimal places")
	private Double latitude;

	@NotNull(message = "Longitude value is required")
	@Digits(integer = 3, fraction = 10, message = "Latitude must have up to 3 integer digits and 10 decimal places")
	private Double longitude;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime createdTime;

}
