package org.bel.location.dto.request;

import java.time.LocalDateTime;
import java.util.UUID;

public record LocationSyncEvent(UUID eventId, String eventType, String entityType, Integer userId, String sourceNodeId,
		String targetNodeId, Long version, Double latitude, Double longitude,
		LocalDateTime timestamp) {
}
