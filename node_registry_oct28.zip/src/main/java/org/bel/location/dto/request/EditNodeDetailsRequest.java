package org.bel.location.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class EditNodeDetailsRequest {
	
	@NotBlank(message = "Node Id is required")
	private String nodeId;
	
    @Size(min = 1, max = 100, message = "Node Name must be between 1 and 100 characters")
    private String nodeName;

    @Pattern(regexp = "^((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$", 
             message = "Invalid IPv4 format")
    private String ipAddress;

    @Min(value = 1, message = "Port must be greater than 0")
    @Max(value = 65535, message = "Port must be less than 65536")
    private Integer port;
}
