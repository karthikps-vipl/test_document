package org.bel.location.dto.response;

import lombok.Data;

@Data
public class EditNodeResponse {
	private String nodeId;
	private String ipAddress;
	private String nodeName;
	private Integer port;
	private String status;
}
