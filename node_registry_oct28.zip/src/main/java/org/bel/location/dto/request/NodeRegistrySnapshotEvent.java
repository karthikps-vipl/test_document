package org.bel.location.dto.request;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public record NodeRegistrySnapshotEvent(UUID eventId, String sourceNodeId, List<NodeRecord> nodes) {
    public record NodeRecord(String nodeId, String nodeName, String ipAddress, Integer port,
                             String status, OffsetDateTime createdAt, OffsetDateTime updatedAt) {}
}
