package org.bel.location.dto.request;

import jakarta.validation.constraints.*;
import java.time.OffsetDateTime;

public record LocationUpdateRequest(@NotNull @DecimalMin("-90.0") @DecimalMax("90.0") Double latitude,
		@NotNull @DecimalMin("-180.0") @DecimalMax("180.0") Double longitude, Double accuracy,
		@NotNull OffsetDateTime timestamp) {
}
