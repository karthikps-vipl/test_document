package org.bel.location.dto.request;

import java.util.UUID;

public record UserSyncAck(UUID eventId, String status, String receivingNodeId, String message) {}
