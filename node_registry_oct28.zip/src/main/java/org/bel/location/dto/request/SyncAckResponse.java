package org.bel.location.dto.request;

import java.util.UUID;

public record SyncAckResponse(UUID eventId, String status, String nodeId) {
}
