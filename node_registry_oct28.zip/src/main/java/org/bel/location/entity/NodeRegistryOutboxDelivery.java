package org.bel.location.entity;

import java.time.LocalDateTime;
import java.util.UUID;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "node_registry_outbox_delivery", schema = "tcs_laa",
       uniqueConstraints = @UniqueConstraint(name = "uq_node_registry_delivery_event_target", columnNames = {"event_id", "target_node_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class NodeRegistryOutboxDelivery {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "event_id", nullable = false) private UUID eventId;
    @Column(name = "target_node_id", nullable = false) private String targetNodeId;
    @Column(name = "status", nullable = false) private String status;
    @Column(name = "retry_count", nullable = false) private Integer retryCount;
    @Column(name = "next_retry_at") private LocalDateTime nextRetryAt;
    @Column(name = "created_at", nullable = false) private LocalDateTime createdAt;
    @Column(name = "updated_at", nullable = false) private LocalDateTime updatedAt;
    @Column(name = "last_error", columnDefinition = "text") private String lastError;
}
