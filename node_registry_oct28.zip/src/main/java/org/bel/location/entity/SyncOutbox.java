package org.bel.location.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "sync_outbox", schema = "tcs_laa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncOutbox {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "event_id", nullable = false, unique = true)
	private UUID eventId;
	@Column(name = "event_type", nullable = false)
	private String eventType;
	@Column(name = "entity_type", nullable = false)
	private String entityType;
	@Column(name = "user_id", nullable = false)
	private Integer userId;
	@Column(name = "source_node_id", nullable = false)
	private String sourceNodeId;
	@Column(name = "event_version", nullable = false)
	private Long eventVersion;
	@Column(nullable = false, columnDefinition = "jsonb")
	@JdbcTypeCode(SqlTypes.JSON)
	private String payload;
	@Column(nullable = false)
	private String status;
	@Column(name = "retry_count", nullable = false)
	private Integer retryCount;
	@Column(name = "next_retry_at")
	private LocalDateTime nextRetryAt;
	@Column(name = "created_at", nullable = false)
	private LocalDateTime createdAt;
	@Column(name = "sent_at")
	private LocalDateTime sentAt;
	@Column(name = "last_error")
	private String lastError;
}
