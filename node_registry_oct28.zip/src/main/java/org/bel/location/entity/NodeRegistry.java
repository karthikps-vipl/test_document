package org.bel.location.entity;

import java.time.OffsetDateTime;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "node_registry", schema = "tcs_laa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NodeRegistry {
	@Id
	@Column(name = "node_id")
	private String nodeId;
	@Column(name = "node_name", nullable = false)
	private String nodeName;
	@Column(name = "ip_address", columnDefinition = "inet")
	@JdbcTypeCode(SqlTypes.INET)
	private String ipAddress;
	@Column(name = "port", nullable = false)
	private Integer port;
	@Column(name = "status", nullable = false)
	private String status;
	@Column(name = "created_at", nullable = false)
	private OffsetDateTime createdAt;
	@Column(name = "updated_at", nullable = false)
	private OffsetDateTime updatedAt;
}
