package org.bel.location.entity;

import java.time.LocalDateTime;
import java.util.UUID;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "node_registry_outbox", schema = "tcs_laa")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class NodeRegistryOutbox {
    @Id @Column(name = "event_id", nullable = false) private UUID eventId;
    @Column(name = "source_node_id", nullable = false) private String sourceNodeId;
    @Column(name = "payload", nullable = false, columnDefinition = "text") private String payload;
    @Column(name = "status", nullable = false) private String status;
    @Column(name = "created_at", nullable = false) private LocalDateTime createdAt;
    @Column(name = "updated_at", nullable = false) private LocalDateTime updatedAt;
    @Column(name = "last_error", columnDefinition = "text") private String lastError;
}
