package org.bel.location.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.locationtech.jts.geom.Point;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "laa_ue_location_hist", schema = "tcs_laa")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LaaUeLocationHist {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user__id")
	private MdmUser mdmUser;

	// Relationship: Many Location Histories per UE
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_ue__id")
	private MdmUe mdmUe;

	// Relationship: Many Histories per Map Entry
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mdm_user_ue_map__id")
	private MdmUserUeMapping mdmUserUeMapping;

	// Relationship: Many Histories per Node
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "node_id")
	private NodeRegistry node;

	@Column(name = "latitude")
	@Min(-90)
	@Max(90)
	private Double latitude;

	@Column(name = "longitude")
	@Min(-180)
	@Max(180)
	private Double longitude;

	@Column(name = "battery_avail")
	private Double batteryAvail;

	@CreationTimestamp
	@Column(name = "created_at")
	private LocalDateTime createdAt;

	@Column(name = "created_time")
	private LocalDateTime createdTime;
	
	@Column(name = "geom", columnDefinition = "geography(Point, 4326)")
    private Point geom;

}
