package org.bel.location.exception;

public class UnauthorisedException extends RuntimeException {

	public UnauthorisedException(String message) {
		super(message);
	}
}
