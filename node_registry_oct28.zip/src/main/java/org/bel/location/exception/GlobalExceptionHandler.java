package org.bel.location.exception;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;

import org.bel.location.dto.response.Response;
import org.bel.location.dto.response.SingleResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<ErrorResponse> handleAccessDenied(AccessDeniedException ex) {
		log.warn("Access Denied: {}", ex.getMessage());
		ErrorResponse err = new ErrorResponse(HttpStatus.FORBIDDEN.value(),
				"Access Denied: You do not have permission to access this resource");
		return new ResponseEntity<>(err, HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(NoResourceFoundException.class)
	public ResponseEntity<ErrorResponse> handleNoResourceFound(NoResourceFoundException ex) {
		log.warn("Endpoint not found: {}", ex.getResourcePath());
		ErrorResponse err = new ErrorResponse(HttpStatus.NOT_FOUND.value(),
				"The requested endpoint '/" + ex.getResourcePath() + "' does not exist");
		return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(BadRequestException.class)
	public ResponseEntity<ErrorResponse> handleBadRequest(BadRequestException ex) {

//        log.error("Bad Request exception", ex);
		log.error("Bad Request exception: {}", ex.getMessage());
		ErrorResponse err = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UnauthorisedException.class)
	public ResponseEntity<ErrorResponse> handleUnauthorisation(UnauthorisedException ex) {
//        log.error("Unauthorised exception", ex);
		log.error("Unauthorised exception: {}", ex.getMessage());
		ErrorResponse err = new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), ex.getMessage());
		return new ResponseEntity<>(err, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(ForbiddenException.class)
	public ResponseEntity<ErrorResponse> handleForbidden(ForbiddenException ex) {
//        log.error("forbidden exception", ex);
		log.error("forbidden exception: {}", ex.getMessage());
		ErrorResponse err = new ErrorResponse(HttpStatus.FORBIDDEN.value(), ex.getMessage());
		return new ResponseEntity<>(err, HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<ErrorResponse> handleNotFound(NotFoundException ex) {
//        log.error("Not found exception", ex);
		log.error("Not found exception: {}", ex.getMessage());
		ErrorResponse err = new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
		return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {
		List<String> errors = new ArrayList<>();

		// Collect all field errors into a readable format
		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			errors.add(error.getField() + ": " + error.getDefaultMessage());
		}

		// Join the errors into a single string
		String combinedErrorMessage = "Validation failed - " + String.join(", ", errors);

		log.warn("Validation exception: {}", combinedErrorMessage);

		// Use the standard ErrorResponse matching your other handlers
		ErrorResponse err = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), combinedErrorMessage);

		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ErrorResponse> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {
		log.warn("Malformed JSON or invalid data type: {}", ex.getMessage());

		ErrorResponse err = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage() // "Malformed JSON request
																								// or invalid data
																								// format provided.
																								// Please check your
																								// input types."
		);

		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MicroserviceException.class)
	public ResponseEntity<SingleResponse<?>> handleMicroserviceIntegrationException(MicroserviceException ex) {
		// Return the exact status code that the authService originally threw
		return ResponseEntity.status(ex.getStatusCode())
				.body(new SingleResponse<>(null, new Response(ex.getStatusCode(), ex.getMessage()) // Assuming you have
																									// a Response object
																									// for errors
				));
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleException(Exception ex) {

//        log.error("Unexpected application error", ex);
		log.error("Unexpected application error: {}", ex.getMessage());
		ErrorResponse err = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Internal Server Error");

		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<SingleResponse<String>> handleCustomException(CustomException ex) {

		// 1. Build your standard SingleResponse using the data from the exception
		SingleResponse<String> response = new SingleResponse<>(ex.getMessage(), // Pulls "User already has an active
																				// group"
				ex.getCustomStatus()// Pulls CustomStatus.USER_ALREADY_IN_GROUP
		);

		// 2. Return it with the exact HTTP status code you passed (400)
		return ResponseEntity.status(ex.getStatus()).body(response);
	}

}
