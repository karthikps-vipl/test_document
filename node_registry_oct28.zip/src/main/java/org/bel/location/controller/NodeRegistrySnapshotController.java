package org.bel.location.controller;

import org.bel.location.dto.request.NodeRegistrySnapshotEvent;
import org.bel.location.dto.request.SyncAckResponse;
import org.bel.location.service.NodeRegistrySnapshotReceiver;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;

@RestController @RequiredArgsConstructor
@RequestMapping("/internal/sync/node-registry")
public class NodeRegistrySnapshotController {
    private final NodeRegistrySnapshotReceiver receiver;

    @PostMapping
    public ResponseEntity<?> receive(@RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
                                     @RequestBody NodeRegistrySnapshotEvent event) {
        if (!receiver.validToken(token)) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing or invalid internal sync token");
        return ResponseEntity.ok(receiver.receive(event));
    }
}
