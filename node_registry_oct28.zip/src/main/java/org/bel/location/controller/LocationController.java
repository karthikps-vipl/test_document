package org.bel.location.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.bel.location.dto.request.*;
import org.bel.location.dto.response.SingleResponse;
import org.bel.location.service.LocationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/location")
@RequiredArgsConstructor
public class LocationController {
	private final LocationService service;

	@PostMapping("/users")
	public ResponseEntity<SingleResponse<LocationResponse>> update(@RequestHeader("X-User-Id")Integer userId, @Valid @RequestBody AddLocationRequest request) {
		return ResponseEntity.ok(service.updateLocation(userId,request));
	}
}
