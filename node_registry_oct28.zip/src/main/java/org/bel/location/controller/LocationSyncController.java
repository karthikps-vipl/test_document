package org.bel.location.controller;

import lombok.RequiredArgsConstructor;

import org.bel.location.dto.request.*;
import org.bel.location.service.LocationSyncService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/internal/sync")
@RequiredArgsConstructor
public class LocationSyncController {
	private final LocationSyncService service;

	@PostMapping("/location")
	public ResponseEntity<SyncAckResponse> receive(@RequestBody LocationSyncEvent event) {
		return ResponseEntity.ok(service.process(event));
	}
}
