package org.bel.location.controller;

import java.sql.Connection;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.bel.location.constants.AppConstants;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.service.NodeHealthMonitor;
import org.bel.location.service.NodeRegistryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/nodes")
@RequiredArgsConstructor
public class ClusterSyncHealthController {
    private final NodeRegistryService nodeRegistryService;
    private final NodeHealthMonitor healthMonitor;
    private final DataSource dataSource;
    
    @GetMapping("/sync-health")
    public Map<String, Object> getClusterSyncHealth() {
        List<Map<String, Object>> nodes = new ArrayList<>();
        int active = 0, healthy = 0, unhealthy = 0, inactive = 0;
        // Include this node in the cluster result as well as its peers.
        NodeRegistry localNode = nodeRegistryService.getCurrentNode();
        boolean localDbUp = false;
        try (Connection connection = dataSource.getConnection()) { localDbUp = connection.isValid(2); }
        catch (Exception ignored) { }
        Map<String, Object> local = new LinkedHashMap<>();
        local.put("nodeId", localNode.getNodeId());
        local.put("registryStatus", localNode.getStatus());
        local.put("syncServiceStatus", localDbUp ? AppConstants.UP : AppConstants.DOWN);
        local.put("healthy", localDbUp && AppConstants.ACTIVE.equalsIgnoreCase(localNode.getStatus()));
        local.put("lastCheckedAt", OffsetDateTime.now());
        nodes.add(local);
        if (AppConstants.ACTIVE.equalsIgnoreCase(localNode.getStatus())) active++; else inactive++;
        if (localDbUp && AppConstants.ACTIVE.equalsIgnoreCase(localNode.getStatus())) healthy++;
        else if (AppConstants.ACTIVE.equalsIgnoreCase(localNode.getStatus())) unhealthy++;
        for (NodeRegistry node : nodeRegistryService.getOtherRegisteredNodes()) {
            boolean registryActive = AppConstants.ACTIVE.equalsIgnoreCase(node.getStatus());
            NodeHealthMonitor.HealthState state = healthMonitor.getState(node.getNodeId());
            if (registryActive) active++; else inactive++;
            if (registryActive && state.healthy()) healthy++;
            else if (registryActive) unhealthy++;
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("nodeId", node.getNodeId());
            item.put("registryStatus", node.getStatus());
            item.put("syncServiceStatus", registryActive ? state.state() : AppConstants.INACTIVE_IN_REGISTRY);
            item.put("healthy", registryActive && state.healthy());
            item.put("lastCheckedAt", state.checkedAt());
            nodes.add(item);
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("checkedAt", OffsetDateTime.now());
        result.put("overallStatus", unhealthy == 0 && inactive == 0 ? AppConstants.UP : AppConstants.DEGRADED);
        result.put("registeredPeerCount", nodes.size());
        result.put("activeNodeCount", active);
        result.put("healthyNodeCount", healthy);
        result.put("unhealthyNodeCount", unhealthy);
        result.put("inactiveNodeCount", inactive);
        result.put("nodes", nodes);
        return result;
    }
}
