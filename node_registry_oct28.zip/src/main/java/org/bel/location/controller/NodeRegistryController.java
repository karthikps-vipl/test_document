package org.bel.location.controller;

import java.util.List;

import org.bel.location.dto.request.ChangeNodeStatusRequest;
import org.bel.location.dto.request.NodeRegistryRequest;
import org.bel.location.dto.response.NodeRegistryResponse;
import org.bel.location.dto.response.SingleResponse;
import org.bel.location.service.NodeRegistryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/node")
@RequiredArgsConstructor
public class NodeRegistryController {
	
	private final NodeRegistryService nodeService;
	
	@GetMapping("/list")
	public ResponseEntity<SingleResponse<List<NodeRegistryResponse>>> getAllNodesList(@RequestHeader("X-User-Role") String roleId){
		return ResponseEntity.ok(nodeService.getAllNodesList(roleId));
	}
	
	@PostMapping("/add")
	public ResponseEntity<SingleResponse<String>> createNode(@RequestHeader("X-User-Role") String roleId,
													 	@Valid @RequestBody NodeRegistryRequest request){
		return ResponseEntity.ok(nodeService.createNode(roleId, request));
	}
	
	@PatchMapping("/change/status")
	public ResponseEntity<SingleResponse<String>> changeNodeStatus(@RequestHeader("X-User-Role") String roleId,
														  	  @Valid @RequestBody ChangeNodeStatusRequest request){
		return ResponseEntity.ok(nodeService.changeNodeStatus(roleId, request));
	}
}
