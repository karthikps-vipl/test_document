package org.bel.location.service;

import java.time.LocalDateTime;

import org.bel.location.constants.AppConstants;
import org.bel.location.dto.request.LocationSyncEvent;
import org.bel.location.dto.request.SyncAckResponse;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.entity.SyncOutbox;
import org.bel.location.entity.SyncOutboxDelivery;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeSyncService {
    private final RestClient restClient;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final ObjectMapper mapper;
    private final ObjectProvider<SyncOutboxWorker> outboxWorker;
    private final NodeHealthMonitor nodeHealthMonitor;

    @Async("syncExecutor")
    public void send(SyncOutbox outbox, SyncOutboxDelivery delivery, NodeRegistry target) {
        try {
            // Recheck eligibility immediately before network I/O. The worker also checks
            // these conditions before claiming the row; this second check narrows races.
            if (!AppConstants.ACTIVE.equalsIgnoreCase(target.getStatus())
                    || !AppConstants.UP.equalsIgnoreCase(nodeHealthMonitor.getState(target.getNodeId()).state())) {
                delivery.setStatus(AppConstants.WAITING_FOR_NODE);
                delivery.setNextRetryAt(null);
                delivery.setLastError("Target node must be ACTIVE and syncServiceStatus UP");
                deliveryRepo.save(delivery);
                return;
            }

            LocationSyncEvent e = mapper.readValue(outbox.getPayload(), LocationSyncEvent.class);
            LocationSyncEvent targetEvent = new LocationSyncEvent(e.eventId(), e.eventType(), e.entityType(),
                    e.userId(), e.sourceNodeId(), target.getNodeId(), e.version(), e.latitude(), e.longitude(), e.timestamp());
            String url = "http://" + target.getIpAddress() + ":" + target.getPort() + "/internal/sync/location";
            ResponseEntity<SyncAckResponse> response = restClient.post().uri(url).body(targetEvent)
                    .retrieve().toEntity(SyncAckResponse.class);
            SyncAckResponse ack = response.getBody();
            if (response.getStatusCode().is2xxSuccessful() && ack != null
                    && outbox.getEventId().equals(ack.eventId())
                    && (AppConstants.ACKNOWLEDGED.equals(ack.status()) || AppConstants.STALE_IGNORED.equals(ack.status()))) {
                LocalDateTime now = LocalDateTime.now();
                delivery.setStatus(AppConstants.ACKNOWLEDGED);
                delivery.setSentAt(now);
                delivery.setAcknowledgedAt(now);
                delivery.setNextRetryAt(null);
                delivery.setLastError(null);
                deliveryRepo.save(delivery);
            } else {
                fail(delivery, new IllegalStateException("Invalid or mismatched sync acknowledgement"));
            }
        } catch (ResourceAccessException ex) {
            nodeHealthMonitor.markUnhealthy(delivery.getTargetNodeId(), ex.getMessage());
            delivery.setStatus(AppConstants.WAITING_FOR_NODE);
            delivery.setNextRetryAt(null);
            delivery.setLastError(shortError(ex));
            deliveryRepo.save(delivery);
        } catch (Exception ex) {
            fail(delivery, ex);
        } finally {
            // Refresh by ID so the worker reloads current persisted delivery state.
            outboxWorker.getObject().refreshOutboxStatus(outbox.getEventId());
        }
    }

    private void fail(SyncOutboxDelivery d, Exception ex) {
        int retry = (d.getRetryCount() == null ? 0 : d.getRetryCount()) + 1;
        d.setRetryCount(retry);
        d.setStatus(AppConstants.FAILED);
        d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300, 10L * retry)));
        d.setLastError(shortError(ex));
        deliveryRepo.save(d);
    }

    private String shortError(Exception ex) {
        String msg = ex.getMessage();
        return msg != null && msg.length() > 2000 ? msg.substring(0, 2000) : msg;
    }
}
