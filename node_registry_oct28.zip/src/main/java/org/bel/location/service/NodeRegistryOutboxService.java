package org.bel.location.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.bel.location.dto.request.NodeRegistrySnapshotEvent;
import org.bel.location.dto.request.NodeRegistrySnapshotEvent.NodeRecord;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.entity.NodeRegistryOutbox;
import org.bel.location.repository.NodeRegistryRepository;
import org.bel.location.repository.NodeRegistryOutboxRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service @RequiredArgsConstructor @Slf4j
public class NodeRegistryOutboxService {
    private final NodeRegistryOutboxRepository outboxRepository;
    private final NodeRegistryRepository nodeRegistryRepository;
    private final CurrentNodeResolver currentNodeResolver;
    private final ObjectMapper objectMapper;

    /** Must run in the same transaction as the registry change, so no change is lost. */
    @Transactional
    public void enqueueFullSnapshot() {
        String sourceNodeId = currentNodeResolver.getCurrentNodeId();
        List<NodeRecord> records = nodeRegistryRepository.findAllOrderByNodeIdAsc().stream()
            .map(n -> new NodeRecord(n.getNodeId(), n.getNodeName(), n.getIpAddress(), n.getPort(), n.getStatus(), n.getCreatedAt(), n.getUpdatedAt()))
            .toList();
        NodeRegistrySnapshotEvent event = new NodeRegistrySnapshotEvent(UUID.randomUUID(), sourceNodeId, records);
        try {
            LocalDateTime now = LocalDateTime.now();
            outboxRepository.save(NodeRegistryOutbox.builder().eventId(event.eventId()).sourceNodeId(sourceNodeId)
                .payload(objectMapper.writeValueAsString(event)).status("PENDING").createdAt(now).updatedAt(now).build());
            log.info("Queued node registry snapshot event {} containing {} nodes", event.eventId(), records.size());
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Could not serialize node registry snapshot", e);
        }
    }
}
