package org.bel.location.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.bel.location.constants.AppConstants;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.event.NodeRegistryCacheRefreshEvent;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeHealthMonitor {
    private final RestClient restClient;
    private final NodeRegistryService nodeRegistryService;
    private final SyncOutboxDeliveryRepository deliveryRepository;
    private final Map<String, HealthState> states = new ConcurrentHashMap<>();

    @Value("${sync.health.endpoint:/internal/health/sync}")
    private String healthEndpoint;

    @Scheduled(fixedDelayString = "${sync.health.check-interval-ms:15000}", initialDelayString = "${sync.health.initial-delay-ms:3000}")
    public void refreshHealth() {
        List<NodeRegistry> peers = nodeRegistryService.getOtherRegisteredNodes();
        List<String> healthyNodeIds = new ArrayList<>();

        for (NodeRegistry node : peers) {
            if (!AppConstants.ACTIVE.equalsIgnoreCase(node.getStatus())) {
                states.put(node.getNodeId(), new HealthState(false, AppConstants.INACTIVE_IN_REGISTRY, LocalDateTime.now()));
                continue;
            }
            try {
                String url = "http://" + node.getIpAddress() + ":" + node.getPort() + healthEndpoint;
                restClient.get().uri(url).retrieve().toBodilessEntity();
                states.put(node.getNodeId(), new HealthState(true, AppConstants.UP, LocalDateTime.now()));
                healthyNodeIds.add(node.getNodeId());
            } catch (Exception ex) {
                states.put(node.getNodeId(), new HealthState(false, AppConstants.DOWN, LocalDateTime.now()));
                log.debug("Node {} health check failed: {}", node.getNodeId(), ex.getMessage());
            }
        }

        // Reconcile every healthy peer each health cycle, not just on a cached transition.
        // This recovers deliveries even if a DOWN->UP transition was missed or this process restarted.
        if (!healthyNodeIds.isEmpty()) {
            try {
                int requeued = deliveryRepository.requeueWaitingDeliveriesForHealthyNodes(healthyNodeIds);
                if (requeued > 0) {
                    log.info("Requeued {} waiting sync deliveries for healthy peers", requeued);
                }
            } catch (Exception ex) {
                log.error("Healthy peers were detected, but waiting deliveries could not be reconciled", ex);
            }
        }
    }

    /**
     * Refreshes cached states as soon as a received registry snapshot has committed.
     * ACTIVE nodes become UNKNOWN until the next real health probe; inactive nodes are
     * immediately marked INACTIVE_IN_REGISTRY. This does not claim a node is reachable.
     */
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onRegistrySnapshotApplied(NodeRegistryCacheRefreshEvent event) {
        String localNodeId = null;
        try {
            localNodeId = nodeRegistryService.getCurrentNodeId();
        } catch (RuntimeException ex) {
            log.debug("Could not resolve local node while refreshing health cache: {}", ex.getMessage());
        }

        for (NodeRegistry node : event.nodes()) {
            if (node.getNodeId() == null || node.getNodeId().equals(localNodeId)) {
                continue;
            }
            if (AppConstants.ACTIVE.equalsIgnoreCase(node.getStatus())) {
                states.put(node.getNodeId(), new HealthState(false, AppConstants.UNKNOWN, null));
            } else {
                states.put(node.getNodeId(), new HealthState(false, AppConstants.INACTIVE_IN_REGISTRY, LocalDateTime.now()));
            }
        }
        log.debug("Refreshed node health cache after registry snapshot; registry entries={}", event.nodes().size());
    }

    /** Immediately marks a peer down after a sync connection failure. */
    public void markUnhealthy(String nodeId, String reason) {
        states.put(nodeId, new HealthState(false, AppConstants.DOWN, LocalDateTime.now()));
        log.debug("Marked node {} unhealthy after sync failure: {}", nodeId, reason);
    }

    public boolean isHealthy(String nodeId) {
        HealthState state = states.get(nodeId);
        return state != null && state.healthy();
    }

    public HealthState getState(String nodeId) {
        return states.getOrDefault(nodeId, new HealthState(false, AppConstants.UNKNOWN, null));
    }

    public record HealthState(boolean healthy, String state, LocalDateTime checkedAt) {}
}
