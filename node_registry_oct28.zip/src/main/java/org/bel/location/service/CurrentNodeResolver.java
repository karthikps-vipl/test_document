package org.bel.location.service;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CurrentNodeResolver {
	private final NodeRegistryRepository repo;

	public NodeRegistry getCurrentNode() {
		String ip = getLocalIpAddress();
		return repo.findByIpAddress(ip).orElseThrow(
				() -> new IllegalStateException("Current server IP " + ip + " is not registered in node_registry"));
	}

	public String getCurrentNodeId() {
		return getCurrentNode().getNodeId();
	}

	private String getLocalIpAddress() {
		try {
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();

			while (interfaces.hasMoreElements()) {
				NetworkInterface networkInterface = interfaces.nextElement();

				if (!networkInterface.isUp() || networkInterface.isLoopback() || networkInterface.isVirtual()) {
					continue;
				}

				Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();

				while (addresses.hasMoreElements()) {
					InetAddress address = addresses.nextElement();

					if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
						return address.getHostAddress();
					}
				}
			}

			throw new IllegalStateException("No active non-loopback IPv4 address found");

		} catch (SocketException e) {
			throw new IllegalStateException("Unable to determine local server IP", e);
		}
	}

}
