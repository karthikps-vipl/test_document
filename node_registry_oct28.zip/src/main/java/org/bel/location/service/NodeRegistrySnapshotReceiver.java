package org.bel.location.service;

import java.security.MessageDigest;
import java.util.List;
import org.bel.location.dto.request.NodeRegistrySnapshotEvent;
import org.bel.location.dto.request.NodeRegistrySnapshotEvent.NodeRecord;
import org.bel.location.dto.request.SyncAckResponse;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.event.NodeRegistryCacheRefreshEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;

@Service @RequiredArgsConstructor
public class NodeRegistrySnapshotReceiver {
    private final NodeRegistryRepository repository;
    private final CurrentNodeResolver currentNodeResolver;
    private final ApplicationEventPublisher eventPublisher;
    @Value("${sync.internal-token:}") private String internalToken;

    public boolean validToken(String supplied) {
        if (internalToken == null || internalToken.isBlank() || supplied == null) return false;
        return MessageDigest.isEqual(internalToken.getBytes(java.nio.charset.StandardCharsets.UTF_8), supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    @Transactional
    public SyncAckResponse receive(NodeRegistrySnapshotEvent event) {
        if (event == null || event.eventId() == null || event.nodes() == null || event.nodes().isEmpty())
            throw new IllegalArgumentException("Node registry snapshot is empty or invalid");
        String resolvedLocalNodeId;
        try { resolvedLocalNodeId = currentNodeResolver.getCurrentNodeId(); } catch (RuntimeException ignored) { resolvedLocalNodeId = null; /* new node bootstrap */ }
        final String localNodeId = resolvedLocalNodeId;
        List<NodeRegistry> toSave = event.nodes().stream().map(this::toEntity)
            .filter(n -> localNodeId == null || !localNodeId.equals(n.getNodeId()))
            .toList();
        for (NodeRegistry incoming : toSave) {
            NodeRegistry existing = repository.findById(incoming.getNodeId()).orElse(null);
            if (existing != null && existing.getUpdatedAt() != null && incoming.getUpdatedAt() != null
                    && existing.getUpdatedAt().isAfter(incoming.getUpdatedAt())) continue;
            repository.save(incoming);
        }

        // Publish the registry state that is actually in the local database. The listener
        // refreshes the in-memory health cache only after this transaction commits.
        eventPublisher.publishEvent(new NodeRegistryCacheRefreshEvent(repository.findAllOrderByNodeIdAsc()));
        return new SyncAckResponse(event.eventId(), "ACKNOWLEDGED", localNodeId == null ? "BOOTSTRAP" : localNodeId);
    }

    private NodeRegistry toEntity(NodeRecord r) {
        if (r.nodeId() == null || r.nodeName() == null || r.ipAddress() == null || r.port() == null || r.status() == null || r.createdAt() == null || r.updatedAt() == null)
            throw new IllegalArgumentException("Snapshot contains an incomplete node record");
        return NodeRegistry.builder().nodeId(r.nodeId()).nodeName(r.nodeName()).ipAddress(r.ipAddress()).port(r.port())
            .status(r.status()).createdAt(r.createdAt()).updatedAt(r.updatedAt()).build();
    }
}
