package org.bel.location.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import org.bel.location.constants.AppConstants;
import org.bel.location.dto.request.AddLocationRequest;
import org.bel.location.dto.request.LocationResponse;
import org.bel.location.dto.request.LocationSyncEvent;
import org.bel.location.dto.response.SingleResponse;
import org.bel.location.entity.LaaUeLocationHist;
import org.bel.location.entity.MdmUser;
import org.bel.location.entity.MdmUserUeMapping;
import org.bel.location.entity.SyncOutbox;
import org.bel.location.entity.UserLocationLatest;
import org.bel.location.entity.UserLocationSyncState;
import org.bel.location.enums.CustomStatus;
import org.bel.location.exception.CustomException;
import org.bel.location.repository.LaaUeLocationHistRepostiory;
import org.bel.location.repository.MdmUeRepository;
import org.bel.location.repository.MdmUserRepository;
import org.bel.location.repository.MdmUserUeMappingRepository;
import org.bel.location.repository.SyncOutboxRepository;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.bel.location.repository.UserLocationLatestRepository;
import org.bel.location.repository.UserLocationSyncStateRepository;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.PrecisionModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class LocationService {
	private final UserLocationLatestRepository latestRepo;
	private final UserLocationSyncStateRepository stateRepo;
	private final SyncOutboxRepository outboxRepo;
	private final SyncOutboxDeliveryRepository deliveryRepo;
	private final NodeRegistryService nodeRegistryService;
	private final MdmUserRepository mdmUserRepository;
	private final MdmUeRepository ueRepository;
	private final ObjectMapper mapper;
	private final LaaUeLocationHistRepostiory locationHistRepostiory;
	private final MdmUserUeMappingRepository mappingRepository;
	
	@Value("${location.sync.interval-seconds:60}")
	private long intervalSeconds;
	@Value("${location.sync.distance-threshold-meters:30}")
	private double distanceThreshold;

	@Transactional
	public SingleResponse<LocationResponse> updateLocation(Integer userId, AddLocationRequest request) {
		String node = nodeRegistryService.getCurrentNodeId();
		LocalDateTime now = LocalDateTime.now();
		UserLocationLatest old = latestRepo.findById(userId).orElse(null);
		
		MdmUser user = mdmUserRepository.findById(userId)
				.orElseThrow(() ->new CustomException(CustomStatus.USER_NOT_FOUND, 404));
		
		Optional<MdmUserUeMapping> mappedDevice = mappingRepository.findByMdmUser(user);
		
		Integer mdmUeId = mappedDevice.get().getMdmUe().getId();
		log.info("Latitude value received is : {}", request.getLatitude());

		log.info("Longitude value received is : {}", request.getLongitude());
		
		long version = old == null ? 1L : old.getLocationVersion() + 1;
		latestRepo.save(UserLocationLatest.builder().userId(userId).nodeId(node).latitude(request.getLatitude())
				.longitude(request.getLongitude()).locationTimestamp(now)
				.locationVersion(version).updatedAt(now).build());
		
		LaaUeLocationHist history = new LaaUeLocationHist();

		// 1. Map Relationships (Fetch the actual entities from DB)
		history.setMdmUser(mdmUserRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found")));

		history.setMdmUe(
				ueRepository.findById(mdmUeId).orElseThrow(() -> new RuntimeException("UE not found")));

		log.info("DEBUG: Current node is :{}",nodeRegistryService.getCurrentNode());
		log.info("DEBUG: Current node Id is :{}",nodeRegistryService.getCurrentNode().getNodeId());
		history.setNode(nodeRegistryService.getCurrentNode());
		
		// 2. Set Coordinates
		history.setLatitude(request.getLatitude());
		history.setLongitude(request.getLongitude());
		history.setCreatedTime(request.getCreatedTime());
		history.setCreatedAt(now);
		log.info("DEBUG: Create AT time is :{}", now);
		history.setBatteryAvail(5.0);

		// 3. Handle Spatial Data (The "geom" field)
		GeometryFactory geometryFactory = new GeometryFactory(new PrecisionModel(), 4326);
		Point point = geometryFactory.createPoint(new Coordinate(request.getLongitude(), request.getLatitude()));
		history.setGeom(point);

		// 4. Save using Repository
		locationHistRepostiory.save(history);
		
		
		UserLocationSyncState state = stateRepo.findById(userId)
				.orElseGet(() -> UserLocationSyncState.builder().userId(userId).build());
		boolean sync = shouldSynchronize(state, request.getLatitude(), request.getLongitude(), now);
		state.setLastLocalUpdateAt(now);
		state.setUpdatedAt(now);
		if (sync) {
			UUID id = UUID.randomUUID();
			LocationSyncEvent event = new LocationSyncEvent(id, AppConstants.LOCATION_UPDATED, AppConstants.USER_LOCATION, userId, node, null,
					version, request.getLatitude(), request.getLongitude(),  request.getCreatedTime());
			
			log.info("DEBUG: Requested created Time is {}", request.getCreatedTime());
			try {
				// Location synchronization is latest-state replication, not event history.
				// Drop older pending location events for this user so an offline peer
				// receives the newest state instead of replaying obsolete GPS points.
				coalescePendingLocationEvents(userId);
				outboxRepo.save(SyncOutbox.builder()
						.eventId(id)
						.eventType(event.eventType())
						.entityType(event.entityType())
						.userId(event.userId())
						.sourceNodeId(node)
						.eventVersion(version)
						.payload(mapper.writeValueAsString(event))
						.status(AppConstants.PENDING)
						.retryCount(0)
						.createdAt(now)
						.build());
			} catch (Exception e) {
				throw new IllegalStateException("Unable to create sync outbox event", e);
			}
			state.setLastSyncedLatitude(request.getLatitude());
			state.setLastSyncedLongitude(request.getLongitude());
			state.setLastSyncedVersion(version);
			state.setLastSyncedAt(now);
		}
		stateRepo.save(state);
		
		LocationResponse response = new LocationResponse(userId, node, request.getLatitude(), request.getLongitude(), request.getCreatedTime(),
				version);
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	/**
	 * Keeps pending location events bounded during a peer outage. Any event with a
	 * SENDING delivery is retained because a network request may already be in flight.
	 * A later update can remove it once that attempt has completed.
	 */
	private void coalescePendingLocationEvents(Integer userId) {
		var pending = outboxRepo.findByUserIdAndStatusAndEventTypeOrderByCreatedAtAscIdAsc(
				userId, AppConstants.PENDING, AppConstants.LOCATION_UPDATED);
		for (SyncOutbox oldEvent : pending) {
			if (deliveryRepo.existsByEventIdAndStatus(oldEvent.getEventId(), AppConstants.SENDING)) {
				continue;
			}
			// Delete child deliveries first in case the database has a foreign key.
			deliveryRepo.deleteByEventId(oldEvent.getEventId());
			outboxRepo.delete(oldEvent);
		}
	}

	private boolean shouldSynchronize(UserLocationSyncState s, Double lat, Double lon, LocalDateTime now) {
		if (s.getLastSyncedAt() == null)
			return true;
		if (Duration.between(s.getLastSyncedAt(), now).getSeconds() >= intervalSeconds)
			return true;
		if (s.getLastSyncedLatitude() == null || s.getLastSyncedLongitude() == null)
			return true;
		Double Distancecal= distance(s.getLastSyncedLatitude().doubleValue(), s.getLastSyncedLongitude().doubleValue(),
				lat.doubleValue(), lon.doubleValue());
		log.info("Distancecal:{}",Distancecal);
		return  Distancecal>= distanceThreshold;
	}

	private double distance(double a, double b, double c, double d) {
		double R = 6371000.0, x = Math.toRadians(c - a), y = Math.toRadians(d - b);
		double h = Math.sin(x / 2) * Math.sin(x / 2)
				+ Math.cos(Math.toRadians(a)) * Math.cos(Math.toRadians(c)) * Math.sin(y / 2) * Math.sin(y / 2);
		return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
	}
}
