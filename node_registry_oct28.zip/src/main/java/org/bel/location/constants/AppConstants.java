package org.bel.location.constants;

import org.springframework.stereotype.Component;

@Component
public class AppConstants {
	public static final String PENDING = "PENDING";
	public static final String LOCATION_UPDATED = "LOCATION_UPDATED";
	public static final String SENDING = "SENDING";
	public static final String USER_LOCATION = "USER_LOCATION";
	public static final String ACTIVE_STATUS = "ACTIVE";
	public static final String DEACTIVE_STATUS = "DEACTIVE";
	public static final String ACKNOWLEDGED = "ACKNOWLEDGED";
    public static final String ACTIVE = "ACTIVE";
    public static final String UP = "UP";
    public static final String DOWN = "DOWN";
    public static final String WAITING_FOR_NODE = "WAITING_FOR_NODE";
    public static final String STALE_IGNORED = "STALE_IGNORED";
    public static final String INACTIVE_IN_REGISTRY = "INACTIVE_IN_REGISTRY";
    public static final String UNKNOWN = "UNKNOWN";
    public static final String FAILED = "FAILED";
    public static final String DEGRADED = "DEGRADED";
	public static final String NODE_CONSTANT = "NODE-";
}
