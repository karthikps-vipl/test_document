package org.bel.location.event;

import java.util.List;

import org.bel.location.entity.NodeRegistry;

/** Published after a node registry snapshot has been applied to the local database. */
public record NodeRegistryCacheRefreshEvent(List<NodeRegistry> nodes) {
    public NodeRegistryCacheRefreshEvent {
        nodes = nodes == null ? List.of() : List.copyOf(nodes);
    }
}
