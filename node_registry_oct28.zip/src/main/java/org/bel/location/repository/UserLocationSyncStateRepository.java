package org.bel.location.repository;

import org.bel.location.entity.UserLocationSyncState;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLocationSyncStateRepository extends JpaRepository<UserLocationSyncState, Integer> {
}
