package org.bel.location.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bel.location.entity.NodeRegistryOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NodeRegistryOutboxDeliveryRepository extends JpaRepository<NodeRegistryOutboxDelivery, Long> {
    Optional<NodeRegistryOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);
    List<NodeRegistryOutboxDelivery> findByEventId(UUID eventId);
    List<NodeRegistryOutboxDelivery> findTop200ByStatusInAndNextRetryAtLessThanEqualOrderByCreatedAtAsc(List<String> statuses, LocalDateTime now);
    List<NodeRegistryOutboxDelivery> findTop200ByStatusInAndNextRetryAtIsNullOrderByCreatedAtAsc(List<String> statuses);
}
