package org.bel.location.repository;

import java.util.Optional;

import org.bel.location.entity.MdmUser;
import org.bel.location.entity.MdmUserUeMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmUserUeMappingRepository extends JpaRepository<MdmUserUeMapping, Integer>{
	Optional<MdmUserUeMapping> findByMdmUser(MdmUser user);
}
