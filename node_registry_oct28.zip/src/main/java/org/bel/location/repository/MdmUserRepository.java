package org.bel.location.repository;


import org.bel.location.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmUserRepository extends JpaRepository<MdmUser, Integer>{
}
