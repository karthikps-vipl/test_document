package org.bel.location.repository;


import org.bel.location.entity.LaaUeLocationHist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaUeLocationHistRepostiory extends JpaRepository<LaaUeLocationHist, Integer> {
}
