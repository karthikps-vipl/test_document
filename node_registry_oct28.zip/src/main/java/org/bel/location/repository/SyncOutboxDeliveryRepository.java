package org.bel.location.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.bel.location.entity.SyncOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SyncOutboxDeliveryRepository extends JpaRepository<SyncOutboxDelivery, Long> {
    Optional<SyncOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);
    List<SyncOutboxDelivery> findByEventId(UUID eventId);

    boolean existsByEventIdAndStatus(UUID eventId, String status);

    /** Delete delivery rows before deleting/superseding their parent outbox event. */
    long deleteByEventId(UUID eventId);

    /** Only rows eligible to be sent are polled; WAITING_FOR_NODE is deliberately excluded. */
    @Query("SELECT d FROM SyncOutboxDelivery d WHERE d.status = 'PENDING' " +
           "OR (d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now)) " +
           "ORDER BY d.createdAt")
    List<SyncOutboxDelivery> findDispatchable(@Param("now") LocalDateTime now);

    /** Atomic claim: only one worker/process can move an eligible row to SENDING. */
    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'SENDING', d.sentAt = :now, d.nextRetryAt = NULL " +
           "WHERE d.id = :id AND (d.status = 'PENDING' OR " +
           "(d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now)))")
    int claimDispatchable(@Param("id") Long id, @Param("now") LocalDateTime now);

    /** Do not overwrite a row another worker has already claimed. */
    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'WAITING_FOR_NODE', d.nextRetryAt = NULL, " +
           "d.lastError = :reason WHERE d.id = :id AND (d.status = 'PENDING' OR " +
           "(d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now)))")
    int markWaitingIfDispatchable(@Param("id") Long id, @Param("now") LocalDateTime now,
                                  @Param("reason") String reason);

    /** Batch reconciliation also covers missed DOWN->UP transitions and monitor restarts. */
    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL, d.lastError = NULL " +
           "WHERE d.targetNodeId IN (:nodeIds) AND d.status = 'WAITING_FOR_NODE'")
    int requeueWaitingDeliveriesForHealthyNodes(@Param("nodeIds") List<String> nodeIds);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL " +
           "WHERE d.status = 'SENDING' AND d.sentAt IS NOT NULL AND d.sentAt < :cutoff")
    int resetStaleSendingRows(@Param("cutoff") LocalDateTime cutoff);
}
