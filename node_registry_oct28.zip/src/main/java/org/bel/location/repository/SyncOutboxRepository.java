package org.bel.location.repository;

import java.util.Optional;
import java.util.UUID;

import org.bel.location.entity.SyncOutbox;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SyncOutboxRepository extends JpaRepository<SyncOutbox, Long> {

    Optional<SyncOutbox> findByEventId(UUID eventId);

    /** Pending location events for one user, oldest first, for latest-state coalescing. */
    java.util.List<SyncOutbox> findByUserIdAndStatusAndEventTypeOrderByCreatedAtAscIdAsc(
            Integer userId, String status, String eventType);

    /**
     * Rotating pages of pending events allow the worker to reconcile old
     * pending rows without permanently starving later rows.
     */
    Page<SyncOutbox> findByStatusOrderByCreatedAtAsc(String status, Pageable pageable);

    long countByStatus(String status);

    @Query("SELECT DISTINCT o.userId FROM SyncOutbox o WHERE o.status = :status AND o.eventType = :eventType")
    java.util.List<Integer> findDistinctUserIdsByStatusAndEventType(
            @Param("status") String status, @Param("eventType") String eventType);
}
