package org.bel.location.repository;

import java.util.List;
import java.util.UUID;
import org.bel.location.entity.NodeRegistryOutbox;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NodeRegistryOutboxRepository extends JpaRepository<NodeRegistryOutbox, UUID> {
    List<NodeRegistryOutbox> findTop100ByStatusInOrderByCreatedAtAsc(List<String> statuses);
}
