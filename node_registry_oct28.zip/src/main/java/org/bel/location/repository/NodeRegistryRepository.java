package org.bel.location.repository;

import org.bel.location.entity.NodeRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface NodeRegistryRepository extends JpaRepository<NodeRegistry, String> {
	// We use a native query to force the cast to 'inet'
    @Query(value = "SELECT * FROM tcs_laa.node_registry WHERE ip_address = CAST(?1 AS inet)", nativeQuery = true)
    Optional<NodeRegistry> findByIpAddress(String ipAddress);

    List<NodeRegistry> findByStatusAndNodeIdNot(String status, String nodeId);

    List<NodeRegistry> findByNodeIdNot(String nodeId);
    
    Optional<NodeRegistry> findByNodeId(String nodeId);
    
    @Query("SELECT n FROM NodeRegistry n ORDER BY n.nodeId ASC")
    List<NodeRegistry> findAllOrderByNodeIdAsc();

	boolean existsByIpAddress(String ipAddress);
	
	boolean existsByIpAddressAndStatus(String ipAddress, String status);

	boolean existsByIpAddressAndStatusAndNodeIdNot(String ipAddress, String string, String nodeId);
}
