package org.bel.location.repository;

import org.bel.location.entity.UserLocationLatest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLocationLatestRepository extends JpaRepository<UserLocationLatest, Integer> {
}
