package org.bel.location.repository;

import org.bel.location.entity.UserLocationHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLocationHistoryRepository extends JpaRepository<UserLocationHistory, Long> {
}
