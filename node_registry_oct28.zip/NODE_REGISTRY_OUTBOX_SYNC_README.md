# Node registry snapshot synchronization (separate from location synchronization)

This change adds a separate durable registry outbox and delivery queue. It does not modify the existing `sync_outbox`, `sync_outbox_delivery`, `NodeSyncService`, or location endpoint.

## Flow
1. Creating a node or changing a node status saves `node_registry` and inserts a full snapshot event into `tcs_laa.node_registry_outbox` in the same transaction.
2. `NodeRegistryOutboxWorker` creates per-destination rows in `tcs_laa.node_registry_outbox_delivery` for every node in the snapshot except the source node.
3. The worker posts the complete snapshot to each destination at `POST /internal/sync/node-registry`.
4. The destination validates `X-Node-Sync-Token`, upserts registry rows, preserves its own local row when it can identify it, and returns an acknowledgement.
5. Failed deliveries are retried with increasing delays; delivery state is tracked independently per destination.

When Node D is added at Node A, the snapshot includes A, B, C and D. A is excluded as the sender, so B, C and D each receive the full snapshot. Node D does not need a special payload.

## Deploy
1. Run `NODE_REGISTRY_OUTBOX_MIGRATION.sql` on every Node Service database.
2. Set the same strong `SYNC_INTERNAL_TOKEN` secret on all nodes. Do not use the development fallback in production.
3. Build and test with `mvn clean package` before deployment.

The worker retries offline peers independently. Registry sync uses dedicated tables and does not change the location synchronization pipeline.

## Health-cache refresh after receiving a snapshot
After the receiver applies the snapshot, it publishes `NodeRegistryCacheRefreshEvent`.
`NodeHealthMonitor` handles the event after the database transaction commits. Active peer
entries are immediately set to `UNKNOWN` until the next actual health probe; inactive entries
are set to `INACTIVE_IN_REGISTRY`. The local node is excluded when it can be resolved. This
updates only the in-memory health cache and does not alter location synchronization.

The same cache-refresh event is also published after a local node registration or status change.
Because the listener runs after transaction commit, both the source node and receiving nodes refresh
health-cache entries immediately; active peers remain `UNKNOWN` until probed, and inactive peers
are marked `INACTIVE_IN_REGISTRY`.


| No. | File | Purpose |
|---|---|---|
| 1 | `src/main/java/org/bel/location/controller/NodeRegistrySnapshotController.java` | Receives registry snapshots through an internal REST API. |
| 2 | `src/main/java/org/bel/location/dto/request/NodeRegistrySnapshotEvent.java` | Defines the registry snapshot event and its node records. |
| 3 | `src/main/java/org/bel/location/entity/NodeRegistryOutbox.java` | Represents pending registry synchronization events. |
| 4 | `src/main/java/org/bel/location/entity/NodeRegistryOutboxDelivery.java` | Tracks delivery status separately for each destination. |
| 5 | `src/main/java/org/bel/location/event/NodeRegistryCacheRefreshEvent.java` | Publishes registry changes for immediate health-cache refresh. |
| 6 | `src/main/java/org/bel/location/repository/NodeRegistryOutboxRepository.java` | Database operations for registry outbox events. |
| 7 | `src/main/java/org/bel/location/repository/NodeRegistryOutboxDeliveryRepository.java` | Database operations for registry delivery records. |
| 8 | `src/main/java/org/bel/location/service/NodeRegistryOutboxService.java` | Creates full registry snapshots and queues them for delivery. |
| 9 | `src/main/java/org/bel/location/service/NodeRegistryOutboxWorker.java` | Processes queued events, sends snapshots, and handles delivery retries. |
| 10 | `src/main/java/org/bel/location/service/NodeRegistrySnapshotReceiver.java` | Applies incoming registry snapshots to the local database and publishes the cache-refresh event. |
| 11 | `NODE_REGISTRY_OUTBOX_MIGRATION.sql` | Creates the dedicated registry outbox and delivery tables. |
| 12 | `NODE_REGISTRY_OUTBOX_SYNC_README.md` | Documents the registry synchronization design and deployment instructions. |


| No. | File path | Why it was updated |
|---|---|---|
| 1 | `src/main/java/org/bel/location/service/NodeRegistryService.java` | Queues a full registry snapshot when a node is registered or its status changes. Also publishes a cache-refresh event for local registry changes. |
| 2 | `src/main/java/org/bel/location/service/NodeHealthMonitor.java` | Handles registry cache-refresh events so newly discovered nodes can be reflected in the in-memory health cache. |
