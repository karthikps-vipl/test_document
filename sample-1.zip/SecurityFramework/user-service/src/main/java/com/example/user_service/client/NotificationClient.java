package com.example.user_service.client;

import com.example.user_service.dto.NotificationMessage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="sf-notificationservice")
public interface NotificationClient {
    @PostMapping("/notifications/send")
    String send(@RequestBody NotificationMessage notificationMessage);

    @PostMapping("/api/notifications/internal/send")
    String sendPrivateNotification(@RequestBody NotificationMessage notificationMessage);

    @PostMapping("/api/notifications/internal/broadcast")
    String sendBroadcast(@RequestBody NotificationMessage notificationMessage);
}
