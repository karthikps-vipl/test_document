package com.example.audit_service.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.support.converter.JacksonJsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    public static final String EXCHANGE="audit.exchange";
    public static final String QUEUE="audit.queue";
    public static final String ROUTING_KEY="audit.login";
    @Bean
    public Queue auditQueue(){
        return new Queue(QUEUE,true);
    }

    @Bean
    public DirectExchange auditExchange(){
        return new DirectExchange(EXCHANGE,true,false);
    }

    @Bean
    public Binding auditBinding(Queue auditQueue, DirectExchange auditExchange){
        return BindingBuilder.bind(auditQueue).to(auditExchange).with(ROUTING_KEY);
    }

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new JacksonJsonMessageConverter();
    }
}
