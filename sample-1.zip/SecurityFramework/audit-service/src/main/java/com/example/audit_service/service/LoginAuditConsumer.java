package com.example.audit_service.service;

import com.example.audit_service.config.RabbitMQConfig;
import com.example.audit_service.dto.AuditRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class LoginAuditConsumer {
    private final AuditService auditService;
    @RabbitListener(queues = RabbitMQConfig.QUEUE)
    public void receiveLoginAudit(AuditRequest message){
        System.out.println("Received audit message");
        log.info("Received login audit message for user: {}",message.getUsername());
        auditService.save(message.getUsername(),message.getAction(),message.getDescription());
        System.out.println("Audit log saved successfully");
    }
}
