package com.example.notification_service.registry;

import org.springframework.stereotype.Component;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class NotificationSessionRegistry {
    private final ConcurrentHashMap<Long,String> userToSessionId=new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String,Long> sessionIdToUser=new ConcurrentHashMap<>();
    public void register(Long userId,String sessionId){
        userToSessionId.put(userId,sessionId);
        sessionIdToUser.put(sessionId,userId);
        System.out.println("Registered user: "+userId);
        System.out.println("Current map: "+userToSessionId);
    }

    public void unregisterBySessionId(String sessionId){
        Long userId=sessionIdToUser.remove(sessionId);
        if(userId!=null){
            userToSessionId.remove(userId);
        }
    }

    public boolean isOnline(Long userId){
        System.out.println("Checking user: "+userId);
        System.out.println("Current map: "+userToSessionId);
        return userToSessionId.containsKey(userId);
    }

    public String getSessionId(Long userId){
        return userToSessionId.get(userId);
    }
}
