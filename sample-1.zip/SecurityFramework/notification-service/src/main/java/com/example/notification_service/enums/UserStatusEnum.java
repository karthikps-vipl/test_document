package com.example.notification_service.enums;

public enum UserStatusEnum {
    ACTIVE,
    BLOCKED
}
