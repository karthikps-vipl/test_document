package com.example.notification_service.controller;

import com.example.notification_service.dto.NotificationMessage;
import com.example.notification_service.service.NotificationService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/notifications")
@AllArgsConstructor
public class NotificationController {
    private final NotificationService notificationService;
    @PostMapping("/send")
    public String send(@RequestBody NotificationMessage notificationMessage){
        return notificationService.sendBroadcast(notificationMessage);
    }
}
