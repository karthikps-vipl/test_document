package com.example.notification_service.config;

import com.example.notification_service.filter.JWTFilter;
import lombok.AllArgsConstructor;
import org.apache.catalina.filters.RateLimitFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@AllArgsConstructor
public class SecurityConfig {
    private final JWTFilter jwtFilter;
//    @Bean
//    public RateLimitFilter rateLimitFilter(){
//        return new RateLimitFilter();
//    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception{
        httpSecurity
                .cors(cors->{})
                .csrf(csrf->csrf.disable())
                .sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(notification->notification
                        .requestMatchers("/notification.html","/ws","/ws/**")
                        .permitAll()
                        .requestMatchers(HttpMethod.POST,"/notifications/send").permitAll()
                        .requestMatchers(HttpMethod.POST,"/api/notifications/internal/send").authenticated()
                        .requestMatchers(HttpMethod.POST,"/api/notifications/internal/broadcast").authenticated()
                        .anyRequest().authenticated())
//                .addFilterBefore(rateLimitFilter, UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return httpSecurity.build();
    }
}
