package com.example.auth_service.service;

import com.example.auth_service.config.RabbitMQConfig;
import com.example.auth_service.dto.AuditRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginAuditProducer {
    private final RabbitTemplate rabbitTemplate;

    public void sendLoginAudit(AuditRequest message){
        try {
            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE,RabbitMQConfig.ROUTING_KEY,message);
            System.out.println("Rabbit mq message sent successfully");
        } catch(Exception e) {
            System.out.println("Rabbit mq message sending failed");
            e.printStackTrace();
            throw e;
        }
    }
}

