package com.example.auth_service.dto;

public class LoginResponse {
    private String accessToken;
    private String refreshToken;

    public String getRefreshToken() {
        return refreshToken;
    }
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getAccessToken() {
        return accessToken;
    }
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public LoginResponse(String accessToken,String refreshToken) {
        this.accessToken=accessToken;
        this.refreshToken=refreshToken;
    }
}
