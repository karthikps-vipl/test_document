package com.example.rabbitmq_poc.controller;

import com.example.rabbitmq_poc.service.MessageProducer;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/message")
public class MessageController {
    private final MessageProducer producer;

    public MessageController(MessageProducer producer) {
        this.producer = producer;
    }
    @PostMapping
    public String sendMessage(@RequestBody String message){
        producer.sendMessage(message);
        return "Message sent successfully";
    }
}
