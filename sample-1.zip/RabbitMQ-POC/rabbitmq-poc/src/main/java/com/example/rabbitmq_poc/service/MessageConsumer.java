package com.example.rabbitmq_poc.service;

import com.example.rabbitmq_poc.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class MessageConsumer {
    @RabbitListener(queues = RabbitMQConfig.QUEUE)
    public void receiveMessage(String message){
        System.out.println("Received message: "+message);
    }
}
