package com.example.rabbitmq_poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitmqPocApplication.class, args);
	}

}
