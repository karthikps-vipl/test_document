package com.example.rabbitmq_poc.config;

import com.rabbitmq.client.AMQP;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.amqp.core.Queue;

@Configuration
public class RabbitMQConfig {
    public static final String EXCHANGE="employee.exchange";
    public static final String QUEUE="employee.queue";
    public static final String ROUTING_KEY="employee.created";
    @Bean
    public Queue employeeQueue(){
        return new Queue(QUEUE);
    }

    @Bean
    public DirectExchange employeeExchange(){
        return new DirectExchange(EXCHANGE);
    }

    @Bean
    public Binding employeeBinding(Queue employeeQueue,DirectExchange employeeExchange){
        return BindingBuilder.bind(employeeQueue).to(employeeExchange).with(ROUTING_KEY);
    }
}
