import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const rootDir = path.dirname(fileURLToPath(import.meta.url));
const saveTopologyDir = path.join(rootDir, "src", "saveTopology");

const readRequestBody = (request) =>
  new Promise((resolve, reject) => {
    let body = "";

    request.on("data", (chunk) => {
      body += chunk;
    });
    request.on("end", () => resolve(body));
    request.on("error", reject);
  });

const safeFileName = (value) =>
  `${value || `fabric-topology-${Date.now()}`}`
    .replace(/[^a-z0-9._-]/gi, "-")
    .replace(/-+/g, "-")
    .slice(0, 120);

const saveTopologyMiddleware = () => ({
  name: "save-topology-middleware",
  configureServer(server) {
    server.middlewares.use("/api/save-topology", async (request, response) => {
      if (request.method !== "POST") {
        response.statusCode = 405;
        response.end("Method not allowed");
        return;
      }

      try {
        const body = await readRequestBody(request);
        const payload = JSON.parse(body || "{}");
        const fileName = `${safeFileName(payload.fileName)}.json`;
        const filePath = path.join(saveTopologyDir, fileName);

        await fs.mkdir(saveTopologyDir, { recursive: true });
        await fs.writeFile(filePath, JSON.stringify(payload.topology ?? payload, null, 2));

        response.setHeader("Content-Type", "application/json");
        response.end(
          JSON.stringify({
            ok: true,
            fileName,
            relativePath: `src/saveTopology/${fileName}`,
          }),
        );
      } catch (error) {
        response.statusCode = 500;
        response.setHeader("Content-Type", "application/json");
        response.end(
          JSON.stringify({
            ok: false,
            message: error instanceof Error ? error.message : "Unable to save topology",
          }),
        );
      }
    });
  },
});

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), saveTopologyMiddleware()],
});
