import "@xyflow/react/dist/style.css";
import "./App.css";
import TopologyWrapper from "./Component/Topology/TopologyWrapper";

function App() {
  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <div className="app-kicker">NMS Topology</div>
          <h1>Fabric Architecture Workspace</h1>
        </div>
        <div className="app-status">React Flow + Fabric</div>
      </header>

      <main className="app-main">
        <TopologyWrapper />
      </main>
    </div>
  );
}

export default App;
