import { memo, useCallback } from "react";
import {
  addEdge,
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  useEdgesState,
  useNodesState,
} from "@xyflow/react";
import TopologyEditActions from "./TopologyEditActions";

const initialNodes = [
  {
    id: "terminal-1",
    type: "input",
    position: { x: 80, y: 120 },
    data: { label: "Terminal" },
  },
  {
    id: "switch-1",
    position: { x: 330, y: 80 },
    data: { label: "Core Switch" },
  },
  {
    id: "server-1",
    type: "output",
    position: { x: 580, y: 150 },
    data: { label: "NMS Server" },
  },
];

const initialEdges = [
  { id: "e-terminal-switch", source: "terminal-1", target: "switch-1" },
  { id: "e-switch-server", source: "switch-1", target: "server-1" },
];

const downloadJson = (payload) => {
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = `reactflow-topology-${Date.now()}.json`;
  link.click();
  URL.revokeObjectURL(url);
};

const CanvasTopology = ({ topologyRenderMode, setTopologyRenderMode }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (connection) => setEdges((current) => addEdge(connection, current)),
    [setEdges],
  );

  const handleSave = useCallback(() => {
    downloadJson({
      module: "topology",
      renderer: "reactflow",
      version: 1,
      savedAt: new Date().toISOString(),
      nodes,
      edges,
    });
  }, [edges, nodes]);

  return (
    <section className="topology-surface">
      <div className="topology-toolbar">
        <TopologyEditActions
          currentViewTopology
          topologyRenderMode={topologyRenderMode}
          setTopologyRenderMode={setTopologyRenderMode}
          canUndo={false}
          canRedo={false}
          canUndoRack={false}
          canRedoRack={false}
          onCanvasSave={handleSave}
        />
      </div>

      <div className="topology-canvas">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          fitView
          proOptions={{ hideAttribution: true }}
        >
          <MiniMap pannable zoomable />
          <Controls showInteractive={false} position="bottom-right" />
          <Background gap={22} size={1} color="#d7dde5" />
        </ReactFlow>
      </div>
    </section>
  );
};

export default memo(CanvasTopology);
