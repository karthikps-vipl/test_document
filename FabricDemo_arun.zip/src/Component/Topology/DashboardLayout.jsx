import TopologyWrapper from "./TopologyWrapper";

const DashboardLayout = () => {
  const { leftSidebarVisible } = useSelector((state) => state.leftSidebarSlice);

  const [bottomOpen, setBottomOpen] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);
  const [activeTabKey, setActiveTabKey] = useState("topology");
  const [activeView, setActiveViewKey] = useState("topology");

  const { fetchData } = UseDataFetchingComponent();

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div
      className="flex flex-col h-full w-full bg-slate-50 overflow-hidden"
      style={{}}
    >
      <div className="h-11 bg-[#3F3F3F] flex items-center px-1 shrink-0 w-full z-40">
        <SecondHeader />
      </div>

      {/* BODY WRAPPER */}
      <div className="flex flex-1 overflow-hidden relative">
        <aside
          className={`transition-all duration-300 flex flex-col z-30 shrink-0 ${
            leftSidebarVisible ? "w-0 overflow-hidden" : "w-64"
          }`}
        >
          <SidebarTree />
        </aside>

        <div className="flex-1 flex flex-col relative overflow-hidden">
          <DashboardTabs
            activeTabKey={activeView}
            setActiveTabKey={setActiveViewKey}
          />

          {/* 5. MAIN CONTENT (Lime Green) */}
          <main className="flex-1 min-h-0 relative overflow-hidden border-t-2 border-gray-200">
            {/* outlet context={{ setSelectedNode }} */}

            {activeView === "topology" && (
              <TopologyWrapper setSelectedNode={setSelectedNode} />
            )}

            {activeView === "faults" && <Fault />}

            {activeView === "performance" && <></>}
          </main>

          {/* 6. ALARMS (Orange Bottom) */}
          <div className="shrink-0 z-40">
            <AlarmDrawer
              activeTabKey={activeTabKey}
              isOpen={bottomOpen}
              onToggle={() => setBottomOpen(!bottomOpen)}
            />
          </div>
        </div>

        {/* 7. TOOL BAR (Purple Right) */}
        <div
          id="right-rail-container"
          className="relative h-full shrink-0 z-30"
        >
          <RightUtilityDrawer selectedNode={selectedNode} />
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;
