import {
  Box,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Switch,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  ArrowLeftRight,
  ArrowRight,
  Minus,
  RotateCcw,
  RotateCw,
  Save,
  Trash2,
  Upload,
} from "lucide-react";

const iconButtonSx = {
  width: 34,
  height: 34,
  border: "1px solid #d6dde6",
  borderRadius: "8px",
  color: "#1f2937",
  backgroundColor: "#ffffff",
  "&:hover": {
    backgroundColor: "#eef6f6",
    borderColor: "#0f766e",
  },
  "&.Mui-disabled": {
    opacity: 0.45,
  },
};

const fieldSx = {
  minWidth: 132,
  "& .MuiInputBase-root": {
    height: 34,
    backgroundColor: "#ffffff",
  },
};

const TopologyEditActions = ({
  topologyRenderMode = "canvas",
  setTopologyRenderMode,
  canUndo,
  canRedo,
  onCanvasUndo,
  onCanvasRedo,
  onCanvasSave,
  fabricTerminals = [],
  fabricDevices = [],
  fabricForm,
  fabricSelectedObject,
  onFabricUpload,
  onFabricAddLine,
  onFabricDeleteSelected,
  onFabricSave,
  onFabricFieldChange,
}) => {
  const isSvgMode = topologyRenderMode === "svg";

  const handleRenderModeChange = (event) => {
    setTopologyRenderMode?.(event.target.checked ? "svg" : "canvas");
  };

  const handleTerminalChange = (event) => {
    onFabricFieldChange?.("terminalId", event.target.value);
  };

  const handleDeviceChange = (event) => {
    onFabricFieldChange?.("deviceId", event.target.value);
  };

  const handleSegmentChange = (event) => {
    onFabricFieldChange?.("segment", event.target.value);
  };

  const handleRadioWidthChange = (event) => {
    onFabricFieldChange?.("radioWidth", event.target.value);
  };

  return (
    <Box sx={{ display: "flex", width: "100%", alignItems: "center", gap: 1 }}>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.25, minWidth: 210 }}>
        <Typography sx={{ fontSize: 13, fontWeight: 700, color: "#334155" }}>
          {isSvgMode ? "Fabric Topology" : "React Flow Topology"}
        </Typography>
      </Box>

      <Box
        sx={{
          display: "flex",
          flex: 1,
          flexWrap: "wrap",
          justifyContent: "flex-end",
          alignItems: "center",
          gap: 0.75,
        }}
      >
        {!isSvgMode && (
          <>
            <Tooltip title="Undo">
              <span>
                <IconButton
                  sx={iconButtonSx}
                  onClick={onCanvasUndo}
                  disabled={!canUndo}
                  aria-label="Undo canvas change"
                >
                  <RotateCcw size={17} />
                </IconButton>
              </span>
            </Tooltip>

            <Tooltip title="Redo">
              <span>
                <IconButton
                  sx={iconButtonSx}
                  onClick={onCanvasRedo}
                  disabled={!canRedo}
                  aria-label="Redo canvas change"
                >
                  <RotateCw size={17} />
                </IconButton>
              </span>
            </Tooltip>
          </>
        )}

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 0.75,
            px: 1,
            color: "#475569",
            fontSize: 13,
            fontWeight: 700,
          }}
        >
          Canvas
          <Switch
            checked={isSvgMode}
            color="success"
            size="small"
            onChange={handleRenderModeChange}
            inputProps={{ "aria-label": "Switch topology renderer" }}
          />
          Svg
        </Box>

        {isSvgMode && (
          <>
            <Tooltip title="Upload JPG topology">
              <IconButton
                component="label"
                sx={iconButtonSx}
                aria-label="Upload JPG topology"
              >
                <Upload size={17} />
                <input
                  hidden
                  type="file"
                  accept=".jpg,.jpeg,image/jpeg"
                  onChange={onFabricUpload}
                />
              </IconButton>
            </Tooltip>

            <Tooltip title="Add line">
              <IconButton
                sx={iconButtonSx}
                onClick={() => onFabricAddLine?.("line")}
                aria-label="Add single line"
              >
                <Minus size={19} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Add one-way arrow">
              <IconButton
                sx={iconButtonSx}
                onClick={() => onFabricAddLine?.("arrow")}
                aria-label="Add one-way arrow line"
              >
                <ArrowRight size={18} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Add two-way arrow">
              <IconButton
                sx={iconButtonSx}
                onClick={() => onFabricAddLine?.("doubleArrow")}
                aria-label="Add two-way arrow line"
              >
                <ArrowLeftRight size={18} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Delete selected object">
              <span>
                <IconButton
                  sx={iconButtonSx}
                  onClick={onFabricDeleteSelected}
                  disabled={!fabricSelectedObject}
                  aria-label="Delete selected fabric object"
                >
                  <Trash2 size={17} />
                </IconButton>
              </span>
            </Tooltip>

            <FormControl size="small" sx={fieldSx}>
              <InputLabel>Terminal</InputLabel>
              <Select
                label="Terminal"
                value={fabricForm?.terminalId ?? ""}
                onChange={handleTerminalChange}
              >
                {fabricTerminals.map((terminal) => (
                  <MenuItem key={terminal.id} value={terminal.id}>
                    {terminal.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ ...fieldSx, minWidth: 150 }}>
              <InputLabel>Devices</InputLabel>
              <Select
                label="Devices"
                value={fabricForm?.deviceId ?? ""}
                onChange={handleDeviceChange}
                disabled={!fabricForm?.terminalId}
              >
                {fabricDevices.map((device) => (
                  <MenuItem key={device.id} value={device.id}>
                    {device.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ ...fieldSx, minWidth: 120 }}>
              <InputLabel>Segment</InputLabel>
              <Select
                label="Segment"
                value={fabricForm?.segment ?? ""}
                onChange={handleSegmentChange}
              >
                {["VSAT", "RADIO", "LTE", "FIBER"].map((segment) => (
                  <MenuItem key={segment} value={segment}>
                    {segment}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              size="small"
              type="number"
              label="Radio Width"
              value={fabricForm?.radioWidth ?? ""}
              onChange={handleRadioWidthChange}
              sx={{ ...fieldSx, minWidth: 126, width: 126 }}
              slotProps={{ htmlInput: { min: 1 } }}
            />
          </>
        )}

        <Tooltip title="Save JSON">
          <IconButton
            sx={{ ...iconButtonSx, color: "#0f766e" }}
            onClick={isSvgMode ? onFabricSave : onCanvasSave}
            aria-label="Save topology JSON"
          >
            <Save size={17} />
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  );
};

export default TopologyEditActions;
