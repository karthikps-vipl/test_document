import { useState } from "react";
import { ReactFlowProvider } from "@xyflow/react";
import CanvasTopology from "./CanvasTopology";
import FabricTopology from "./FabricTopology";

export default function TopologyWrapper(props) {
  const [topologyRenderMode, setTopologyRenderMode] = useState("canvas");

  if (topologyRenderMode === "svg") {
    return (
      <FabricTopology
        {...props}
        topologyRenderMode={topologyRenderMode}
        setTopologyRenderMode={setTopologyRenderMode}
      />
    );
  }

  return (
    <ReactFlowProvider>
      <CanvasTopology
        {...props}
        topologyRenderMode={topologyRenderMode}
        setTopologyRenderMode={setTopologyRenderMode}
      />
    </ReactFlowProvider>
  );
}
