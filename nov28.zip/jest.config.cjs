
module.exports = {
  // Root directory
  rootDir: ".",

  // Browser-like environment for React components
  testEnvironment: "jsdom",
  
  extensionsToTreatAsEsm: [".jsx"],

  // Discover test files only inside tests/
  testMatch: ["<rootDir>/tests/**/*.test.js", "<rootDir>/tests/**/*.test.jsx"],

  // Global test setup
setupFilesAfterEnv: ['<rootDir>/tests/setupTests.cjs'],

  // Transform JS and JSX using existing .babelrc
transform: {
  "^.+\\.[jt]sx?$": [
    "babel-jest",
    {
      configFile: "./babel.config.cjs",
      excludeJestPreset: true,
    },
  ],
  "^.+\\.svg$": "<rootDir>/tests/mocks/svgMockTransformer.cjs",
},

  // Module resolution
  moduleFileExtensions: ["js", "jsx", "json"],

  // Vite aliases and static asset handling
moduleNameMapper: {
  // Static assets
  "\\.(png|jpg|jpeg|gif|webp)$": "<rootDir>/tests/mocks/fileMock.cjs",
  "\\.(css|less|scss|sass)$": "identity-obj-proxy",
   "^@/assets/CNMS/Fit Screen\\.svg$":
    "<rootDir>/src/assets/CNMS/Fit screen.svg",

  // JSON mocks
  "^.*public/config\\.json$": "<rootDir>/tests/mocks/topologyConfigMock.json",
  "^.*JsonFile/ReportTreeView\\.json$": "<rootDir>/tests/mocks/ReportTreeView.json",

  // General aliases
  "^@/(.*)$": "<rootDir>/src/$1",
  "^@components/(.*)$": "<rootDir>/src/components/$1",
  "^@lib/(.*)$": "<rootDir>/src/lib/$1",

  "^@/assets/SVGIcons/ResourcecesSvg$":
    "<rootDir>/tests/mocks/ResourcecesSvgMock.jsx",
},

  // Use a single child worker and recycle it after each test file when its
  // heap crosses the threshold. Do not use --runInBand: that disables worker
  // recycling and lets memory accumulate across the entire test run.
  maxWorkers: 1,
  workerIdleMemoryLimit: '512MB',
  coverageProvider: 'v8',

  // Mock management
  clearMocks: true,
  restoreMocks: true,

  // Coverage configuration
  collectCoverage: true,

  // Collect coverage only from production code
  collectCoverageFrom: [
    "src/**/*.{js,jsx}",
    "!src/main.jsx",
    "!src/**/*.test.js",
    "!src/**/*.test.jsx",
    "!src/**/index.js",
  ],

  coverageDirectory: "coverage",

  coverageReporters: ["text", "lcov"],

  // Ignore generated directories
  coveragePathIgnorePatterns: ["/node_modules/", "/coverage/", "/dist/"],

  // Test discovery exclusions
  testPathIgnorePatterns: ["/node_modules/", "/coverage/", "/dist/"],

  // Do not silently pass without tests
  passWithNoTests: false,
};
