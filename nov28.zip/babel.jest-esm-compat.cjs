/**
 * Translate legacy Jest CJS-style mocks in native-ESM test files.
 * Each test file gets its own @jest/globals binding so relative
 * unstable_mockModule specifiers resolve from that test module, not setupTests.
 */
module.exports = function jestEsmCompat({ types: t }) {
  return {
    name: 'jest-esm-test-compat',
    visitor: {
      Program: {
        exit(path, state) {
         const filename = state.filename || state.file?.opts?.filename || '';
const normalized = filename.replace(/\\/g, '/');

if (/tests\/generated\/MapStats\.test\.jsx$/.test(normalized)) {
  console.log("[BABEL] Skipping MapStats test transformation");
  return;
}

if (!/(^|\/)tests\/.*\.test\.[jt]sx?$/.test(normalized)) return;

          const hasJestGlobalsImport = path.node.body.some((node) =>
            t.isImportDeclaration(node) &&
            node.source.value === '@jest/globals' &&
            node.specifiers.some((specifier) =>
              t.isImportSpecifier(specifier) &&
              ((t.isIdentifier(specifier.imported) && specifier.imported.name === 'jest') ||
               (t.isStringLiteral(specifier.imported) && specifier.imported.value === 'jest'))
            )
          );

          const body = [];
          for (const node of path.node.body) {
            if (t.isImportDeclaration(node)) {
              const source = node.source;
              if (node.specifiers.length === 0) {
                body.push(t.expressionStatement(
                  t.awaitExpression(t.callExpression(t.import(), [source]))
                ));
                continue;
              }

              const properties = node.specifiers.map((specifier) => {
                if (t.isImportNamespaceSpecifier(specifier)) return null;
                const imported = t.isImportDefaultSpecifier(specifier)
                  ? t.identifier('default')
                  : (t.isIdentifier(specifier.imported)
                      ? t.identifier(specifier.imported.name)
                      : t.stringLiteral(specifier.imported.value));
                return t.objectProperty(imported, t.cloneNode(specifier.local), false);
              }).filter(Boolean);

              const namespace = node.specifiers.find(t.isImportNamespaceSpecifier);
              if (namespace && node.specifiers.length === 1) {
                body.push(t.variableDeclaration('const', [
                  t.variableDeclarator(
                    t.cloneNode(namespace.local),
                    t.awaitExpression(t.callExpression(t.import(), [source]))
                  ),
                ]));
              } else {
                body.push(t.variableDeclaration('const', [
                  t.variableDeclarator(
                    t.objectPattern(properties),
                    t.awaitExpression(t.callExpression(t.import(), [source]))
                  ),
                ]));
                if (namespace) {
                  body.push(t.variableDeclaration('const', [
                    t.variableDeclarator(
                      t.cloneNode(namespace.local),
                      t.awaitExpression(t.callExpression(t.import(), [t.cloneNode(source)]))
                    ),
                  ]));
                }
              }
              continue;
            }
            body.push(node);
          }

          // Import the Jest API from inside this test module. Do not expose a
          // jest object from setupTests.cjs: that binds mock resolution to the
          // setup file and breaks every relative unstable_mockModule path.
          if (!hasJestGlobalsImport) {
            body.unshift(t.variableDeclaration('const', [
              t.variableDeclarator(
                t.objectPattern([t.objectProperty(t.identifier('jest'), t.identifier('jest'), false, true)]),
                t.awaitExpression(t.callExpression(t.import(), [t.stringLiteral('@jest/globals')]))
              ),
            ]));
          }

          path.node.body = body;
          path.traverse({
            CallExpression(callPath) {
              const callee = callPath.node.callee;
              if (
                t.isMemberExpression(callee) &&
                !callee.computed &&
                t.isIdentifier(callee.object, { name: 'jest' }) &&
                t.isIdentifier(callee.property, { name: 'mock' })
              ) {
                callee.property = t.identifier('unstable_mockModule');

                // CommonJS jest.mock() allowed a bare function factory for a
                // default export. Native ESM mocks must return an exports
                // object, so adapt only factories whose result is itself a
                // function (the common React-component / hook mock pattern).
                const factory = callPath.node.arguments[1];
                if (
                  (t.isArrowFunctionExpression(factory) || t.isFunctionExpression(factory)) &&
                  (t.isArrowFunctionExpression(factory.body) ||
                   t.isFunctionExpression(factory.body) ||
                   (t.isCallExpression(factory.body) &&
                    t.isMemberExpression(factory.body.callee) &&
                    t.isIdentifier(factory.body.callee.object, { name: 'jest' }) &&
                    t.isIdentifier(factory.body.callee.property, { name: 'fn' }))
                  )
                ) {
                  factory.body = t.objectExpression([
                    t.objectProperty(t.identifier('default'), factory.body),
                  ]);
                }
              }
            },
          });
        },
      },
    },
  };
};
