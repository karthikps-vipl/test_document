module.exports = {
  presets: [
    [
      '@babel/preset-env',
      {
        targets: { node: 'current' },
        modules: false,
      },
    ],
    [
      '@babel/preset-react',
      {
        runtime: 'automatic',
      },
    ],
  ],

  plugins: [
    function transformViteImportMeta() {
      return {
        name: 'transform-vite-import-meta-env',

        visitor: {
          MemberExpression(path) {
            const object = path.node.object;
            const property = path.node.property;

            if (
              object.type === 'MetaProperty' &&
              object.meta.name === 'import' &&
              object.property.name === 'meta' &&
              property.type === 'Identifier' &&
              property.name === 'env'
            ) {
              const t = require('@babel/types');

              path.replaceWith(
                t.memberExpression(
                  t.identifier('globalThis'),
                  t.identifier('__VITE_ENV__')
                )
              );
            }
          },
        },
      };
    },
    require('./babel.jest-esm-compat.cjs'),
  ],
};
