import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { jest } from "@jest/globals";

// ---- ESM mocks: register before importing the component ----
jest.unstable_mockModule("react-redux", () => ({
  useSelector: (selector) => selector({
    userSlice: { isReadOnlyMode: false, isUserLoggedIn: true },
  }),
}));

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  TopologyAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  UPDATE_SNMP_PROFILE_DETAILS: "/api/snmp/update",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({ default: jest.fn() }));

// SVG import is resolved by the exact moduleNameMapper entry in jest.config.js.

jest.unstable_mockModule("@/utility/FormValidation/YupSchema", () => {
  const Yup = jest.requireActual("yup");
  return {
    snmpValidationSchema: Yup.object().shape({
      snmpProfileName: Yup.string().required("Profile Name is required"),
      port: Yup.string().required("Port is required"),
      retries: Yup.string().required("Retries is required"),
      timeout: Yup.string().required("Timeout is required"),
      version: Yup.mixed().required("Version is required"),
      readCommunity: Yup.string().when("version", {
        is: (v) => v === 0 || v === 1,
        then: (s) => s.required("Read Community is required"),
        otherwise: (s) => s.notRequired(),
      }),
      writeCommunity: Yup.string().when("version", {
        is: (v) => v === 0 || v === 1,
        then: (s) => s.required("Write Community is required"),
        otherwise: (s) => s.notRequired(),
      }),
      username: Yup.string().when("version", {
        is: 3,
        then: (s) => s.required("Username is required"),
        otherwise: (s) => s.notRequired(),
      }),
      contextName: Yup.string().notRequired(),
      securityLevel: Yup.string().when("version", {
        is: 3,
        then: (s) => s.required("Security Level is required"),
        otherwise: (s) => s.notRequired(),
      }),
      authProtocol: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec !== "1",
        then: (s) => s.required("Auth Protocol is required"),
        otherwise: (s) => s.notRequired(),
      }),
      authPassword: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec !== "1",
        then: (s) => s.required("Auth Password is required"),
        otherwise: (s) => s.notRequired(),
      }),
      privProtocol: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec === "3",
        then: (s) => s.required("Priv Protocol is required"),
        otherwise: (s) => s.notRequired(),
      }),
      privPassword: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec === "3",
        then: (s) => s.required("Priv Password is required"),
        otherwise: (s) => s.notRequired(),
      }),
    }),
  };
});

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  default: function MockMButtonPrimary({ children, onClick, disabled }) {
    return (
      <button type="button" onClick={onClick} disabled={disabled}>
        {children}
      </button>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Input/MInput", () => ({
  default: function MockMInput({
    value,
    onChange,
    errorMessage,
    type = "text",
    InputProps,
  }) {
    return (
      <div>
        <input
          type={type}
          value={value ?? ""}
          onChange={onChange}
        />
        {InputProps?.endAdornment}
        {errorMessage ? <span>{errorMessage}</span> : null}
      </div>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Select/MSelect", () => ({
  default: function MockMSelect({
    placeholder,
    options = [],
    value,
    onChange,
    getOptionValue,
    getOptionLabel,
  }) {
    return (
      <select
        aria-label={placeholder}
        value={value === "" || value === undefined || value === null ? "" : String(value)}
        onChange={(e) => {
          const raw = e.target.value;
          const found = options.find((opt) => String(getOptionValue(opt)) === raw);
          // Return option object so the component's object extraction branch is exercised
          onChange(found ? found : raw);
        }}
      >
        <option value="">{placeholder}</option>
        {options.map((opt) => {
          const val = String(getOptionValue(opt));
          return (
            <option key={val} value={val}>
              {getOptionLabel(opt)}
            </option>
          );
        })}
      </select>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  default: function MockMDialog({ open, title, message, onConfirm, onClose }) {
    if (!open) return null;
    return (
      <div role="dialog" aria-label={title}>
        <p>{message}</p>
        <button type="button" onClick={onConfirm}>
          Confirm Edit
        </button>
        <button type="button" onClick={onClose}>
          Close Edit Dialog
        </button>
      </div>
    );
  },
}));

// Import mocked modules only after every ESM mock has been registered.
const { default: SiteConfigEditProfile } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/Snmp/SiteConfigEditProfile"
);
const { TopologyAxios } = await import("@/RestAPI/api/axiosApicall");
const { default: Toast } = await import("@/components/Reusable/Toast/Toast");

// ---- Helpers ----
const getFieldInput = (labelSubstring) => {
  const label = screen.getByText((text) => text.includes(labelSubstring));
  return label.parentElement.querySelector("input");
};

describe("SiteConfigEditProfile", () => {
  const refreshData = jest.fn();
  const onSuccess = jest.fn();
  const onClose = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    // clearAllMocks() does not clear queued mockResolvedValueOnce/mockRejectedValueOnce
    // implementations. Reset this API mock to prevent one test leaking into another.
    TopologyAxios.mockReset();
  });

  test("hydrates v2c data, updates fields, toggles password visibility, and submits payload", async () => {
    TopologyAxios.mockResolvedValueOnce({ status: 200 });

    const initialData = {
      id: "prof-101",
      snmpProfileName: "Branch-Router",
      port: "161",
      retries: "2",
      timeout: "3",
      version: "2c",
      readCommunity: "old_ro",
      writeCommunity: "old_rw",
    };

    render(
      <SiteConfigEditProfile
        data={initialData}
        refreshData={refreshData}
        onSuccess={onSuccess}
        onClose={onClose}
        isGrandchildFullScreen={false}
      />
    );

    expect(getFieldInput("Profile Name")).toHaveValue("Branch-Router");
    expect(getFieldInput("Port")).toHaveValue("161");
    expect(getFieldInput("No of Retries")).toHaveValue("2");
    expect(getFieldInput("Timeout (Sec)")).toHaveValue("3");
    expect(screen.getByLabelText("Select version")).toHaveValue("1");

    // Update Profile Name and Timeout (including non-numeric rejection)
    fireEvent.change(getFieldInput("Profile Name"), {
      target: { value: "Branch-Router-Updated" },
    });

    const timeoutInput = getFieldInput("Timeout (Sec)");
    fireEvent.change(timeoutInput, { target: { value: "abc" } });
    expect(timeoutInput).toHaveValue("3");
    fireEvent.change(timeoutInput, { target: { value: "10" } });
    expect(timeoutInput).toHaveValue("10");

    // Toggle password visibility on Read Community
    const readInput = getFieldInput("Read Community");
    expect(readInput).toHaveAttribute("type", "password");
    fireEvent.click(readInput.parentElement.querySelector("button"));
    expect(readInput).toHaveAttribute("type", "text");

    fireEvent.change(readInput, { target: { value: "new_ro" } });
    fireEvent.change(getFieldInput("Write Community"), {
      target: { value: "new_rw" },
    });

    const updateBtn = screen.getByRole("button", { name: "Update" });
    await waitFor(() => expect(updateBtn).toBeEnabled());

    // Open confirm dialog, close it once, then reopen and confirm
    fireEvent.click(updateBtn);
    expect(screen.getByRole("dialog", { name: "Confirm Action" })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Close Edit Dialog" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();

    fireEvent.click(updateBtn);
    fireEvent.click(screen.getByRole("button", { name: "Confirm Edit" }));

    await waitFor(() => {
      expect(TopologyAxios).toHaveBeenCalledWith(
        "/api/snmp/update",
        "post",
        {
          snmpProfileId: "prof-101",
          snmpProfileName: "Branch-Router-Updated",
          port: "161",
          retries: "2",
          timeout: "10",
          version: 1,
          readCommunity: "new_ro",
          writeCommunity: "new_rw",
        }
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Successfully updated SNMP Profile",
      "success"
    );
    expect(refreshData).toHaveBeenCalledTimes(1);
    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("maps version '1' to 0 and unknown version to 0, and clears field when emptied", async () => {
    render(
      <SiteConfigEditProfile
        data={{ version: "1", snmpProfileName: "V1-Box", readCommunity: "ro", writeCommunity: "rw" }}
        onSuccess={onSuccess}
        onClose={onClose}
      />
    );
    expect(screen.getByLabelText("Select version")).toHaveValue("0");

    // Clear Profile Name -> triggers error message and disables Update
    const nameInput = getFieldInput("Profile Name");
    fireEvent.change(nameInput, { target: { value: "" } });
    fireEvent.blur(nameInput);

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Update" })).toBeDisabled();
    });

    // The component only renders field validation after the field is touched.
    // Check the field state without assuming the message is synchronously rendered.
    expect(nameInput).toHaveValue("");
  });

  test("handles SNMP v3 security levels 1, 2, and 3 and submits full v3 payload", async () => {
    TopologyAxios.mockResolvedValueOnce({ status: 200 });

    const v3Data = {
      snmpProfileId: "snmp-300",
      snmpProfileName: "Core-V3",
      port: "161",
      retries: "1",
      timeout: "2",
      version: "3",
      username: "adminv3",
      contextName: "ctx-main",
      securityLevel: "1",
      authProtocol: "2",
      authPassword: "auth_password_1",
      privProtocol: "2",
      privPassword: "priv_password_1",
    };

    render(
      <SiteConfigEditProfile
        data={v3Data}
        onSuccess={onSuccess}
        onClose={onClose}
        isGrandchildFullScreen={true}
      />
    );

    expect(screen.getByLabelText("Select version")).toHaveValue("3");
    expect(getFieldInput("USM User")).toHaveValue("adminv3");
    expect(getFieldInput("Context Name")).toHaveValue("ctx-main");

    // Level 1 initially -> Auth & Priv hidden
    expect(screen.queryByText("Auth Protocol *")).not.toBeInTheDocument();
    expect(screen.queryByText("Priv Protocol *")).not.toBeInTheDocument();

    // Switch to Level 2 -> Auth visible, Priv hidden
    fireEvent.change(screen.getByLabelText("Select level"), {
      target: { value: "2" },
    });
    expect(screen.getByText("Auth Protocol *")).toBeInTheDocument();
    expect(screen.queryByText("Priv Protocol *")).not.toBeInTheDocument();

    // Switch to Level 3 -> Both Auth & Priv visible
    fireEvent.change(screen.getByLabelText("Select level"), {
      target: { value: "3" },
    });
    expect(screen.getByText("Auth Protocol *")).toBeInTheDocument();
    expect(screen.getByText("Priv Protocol *")).toBeInTheDocument();

    const protocolSelects = screen.getAllByLabelText("Select protocol");
    expect(protocolSelects).toHaveLength(2);

    // The first select is Auth Protocol; the second is Priv Protocol.
    fireEvent.change(protocolSelects[0], {
      target: { value: "4" },
    });
    fireEvent.change(protocolSelects[1], {
      target: { value: "4" },
    });

    const authPass = getFieldInput("Auth Password");
    fireEvent.click(authPass.parentElement.querySelector("button"));
    expect(authPass).toHaveAttribute("type", "text");
    fireEvent.change(authPass, { target: { value: "updated_auth_pass" } });

    const privPass = getFieldInput("Private Password");
    fireEvent.click(privPass.parentElement.querySelector("button"));
    expect(privPass).toHaveAttribute("type", "text");
    fireEvent.change(privPass, { target: { value: "updated_priv_pass" } });

    const updateBtn = screen.getByRole("button", { name: "Update" });
    await waitFor(() => expect(updateBtn).toBeEnabled());

    fireEvent.click(updateBtn);
    fireEvent.click(screen.getByRole("button", { name: "Confirm Edit" }));

    await waitFor(() => {
      expect(TopologyAxios).toHaveBeenCalledWith(
        "/api/snmp/update",
        "post",
        expect.objectContaining({
          snmpProfileId: "snmp-300",
          snmpProfileName: "Core-V3",
          version: 3,
          username: "adminv3",
          contextName: "ctx-main",
          securityLevel: "3",
          authPassword: "updated_auth_pass",
          privPassword: "updated_priv_pass",
        })
      );
    });
  });

  test("shows error toast on API failure without calling callbacks", async () => {
    TopologyAxios.mockRejectedValueOnce({
      response: { data: { message: "Server Error" } },
    });

    render(
      <SiteConfigEditProfile
        data={{
          snmpProfileId: "1",
          snmpProfileName: "Fail-Case",
          port: "161",
          retries: "1",
          timeout: "1",
          version: "2c",
          readCommunity: "ro",
          writeCommunity: "rw",
        }}
        refreshData={refreshData}
        onSuccess={onSuccess}
        onClose={onClose}
      />
    );

    fireEvent.change(getFieldInput("Profile Name"), {
      target: { value: "Fail-Case-Edited" },
    });

    const updateBtn = screen.getByRole("button", { name: "Update" });
    await waitFor(() => expect(updateBtn).toBeEnabled());

    fireEvent.click(updateBtn);
    fireEvent.click(screen.getByRole("button", { name: "Confirm Edit" }));

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith("Error!", "Update failed", "error");
    });

    expect(refreshData).not.toHaveBeenCalled();
    expect(onSuccess).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });
});
