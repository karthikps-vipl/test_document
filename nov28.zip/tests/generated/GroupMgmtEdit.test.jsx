import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";



/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
  SecurityAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL: "/fetch-terminal-resources",
  GET_ALL_PRIVILEGES: "/get-all-privileges",
  MODIFY_GROUP: "/modify-group",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.unstable_mockModule("@/components/Reusable/Form/FormField", () => ({
  __esModule: true,
  default: ({
    label,
    value,
    onChange,
    onBlur,
    disabled,
    error,
    errorMessage,
  }) => {
    const testIdBase = label.toLowerCase().replace(/\s+/g, "-");
    return (
      <div>
        <label htmlFor={testIdBase}>{label}</label>
        <input
          id={testIdBase}
          data-testid={`field-${testIdBase}`}
          value={value}
          disabled={disabled}
          onChange={onChange}
          onBlur={onBlur}
        />
        {error && <span data-testid={`error-${testIdBase}`}>{errorMessage}</span>}
      </div>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled, type }) => (
    <button
      type={type || "button"}
      data-testid="submit-btn"
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  ),
}));

let latestDialogProps;

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => {
    latestDialogProps = props;
    return props.open ? (
      <div data-testid="confirm-dialog">
        <span>{props.title}</span>
        <span>{props.message}</span>
        <button
          type="button"
          data-testid="dialog-confirm"
          onClick={props.onConfirm}
        >
          Confirm
        </button>
        <button
          type="button"
          data-testid="dialog-cancel"
          onClick={props.onClose}
        >
          Cancel
        </button>
      </div>
    ) : null;
  },
}));

jest.unstable_mockModule("@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/PrivilegeTree", () => ({
  __esModule: true,
  default: ({
    flatData,
    selectedIds,
    toggle,
    selectAll,
    allSelected,
  }) => (
    <div data-testid="privilege-tree">
      <span data-testid="selected-privileges">
        {JSON.stringify(selectedIds)}
      </span>
      <span data-testid="all-privileges-selected">{String(allSelected)}</span>
      <button type="button" data-testid="select-all-privs" onClick={selectAll}>
        Toggle All
      </button>
      <button type="button" data-testid="toggle-priv-1" onClick={() => toggle(1)}>
        Toggle Priv 1
      </button>
      <button type="button" data-testid="toggle-priv-2" onClick={() => toggle(2)}>
        Toggle Priv 2
      </button>
      <button type="button" data-testid="toggle-priv-3" onClick={() => toggle(3)}>
        Toggle Priv 3
      </button>
      <button type="button" data-testid="toggle-priv-4" onClick={() => toggle(4)}>
        Toggle Priv 4
      </button>
      <button
        type="button"
        data-testid="toggle-priv-nan"
        onClick={() => toggle("invalid")}
      >
        Toggle Invalid
      </button>
      <span data-testid="priv-count">{flatData.length}</span>
    </div>
  ),
}));

jest.unstable_mockModule("@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/DevicePrivilegesTable", () => ({
  __esModule: true,
  default: ({
    setSelectedDeviceIds,
    setSelectedTypeCapabilities,
  }) => (
    <div data-testid="device-privileges-table">
      <button
        type="button"
        data-testid="set-device-id"
        onClick={() => setSelectedDeviceIds([905])}
      >
        Select Device 905
      </button>
      <button
        type="button"
        data-testid="set-capabilities"
        onClick={() =>
          setSelectedTypeCapabilities({
            "901_inventory": true,
            "902_config": true,
            "903_add_maintain": true,
            "904_fault": false,
            "905_status": true,
            "906_cross_launch": true,
            "907_unknown": true,
            bad_format: true,
          })
        }
      >
        Set Capabilities
      </button>
    </div>
  ),
}));

/* -------------------------------------------------------
   HELPERS & SAMPLE DATA
------------------------------------------------------- */

// Import mocked modules only after all unstable_mockModule registrations.
// Native ESM evaluates static imports before test-file mock setup.
const { default: GroupMgmtEdit } = await import(
  "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtEdit"
);
const { InventoryAxios, SecurityAxios } = await import(
  "@/RestAPI/api/axiosApicall"
);
const {
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL,
  GET_ALL_PRIVILEGES,
  MODIFY_GROUP,
} = await import("@/RestAPI/url/endpoint");
const { default: Toast } = await import(
  "@/components/Reusable/Toast/Toast"
);
const { useSelector } = await import("react-redux");

const sampleTerminalTypes = [
  { label: "CNMS Server", value: 1 },
  { label: "Kiosk", value: 2 },
];

const sampleAllGroups = [
  { id: 10, groupName: "KioskGroup001" },
  { id: 50, groupName: "KioskGroup002Ops" },
  { id: 99, groupName: "KioskGroup005" },
];

// Hierarchy: 1 -> 2 -> (3 and 4)
const samplePrivileges = [
  { id: 1, parentId: null, name: "Root" },
  { id: 2, parentId: 1, name: "Branch" },
  { id: 3, parentId: 2, name: "Leaf A" },
  { id: 4, parentId: 2, name: "Leaf B" },
];

const sampleResources = [{ id: 901, name: "Router" }];

const sampleEditData = {
  id: 50,
  terminalId: 2,
  groupName: "KioskGroup002Ops",
  description: "Initial group description",
  privileges: [{ id: 1 }, { id: 2 }],
  devicePrivileges: JSON.stringify({
    "901_inventory": true,
    "902_configuration": true,
  }),
};

const defaultProps = (overrides = {}) => ({
  onClose: jest.fn(),
  onSuccess: jest.fn(),
  onRefresh: jest.fn(),
  data: sampleEditData,
  isGrandchildFullScreen: false,
  ...overrides,
});

const renderComponent = (
  props = {},
  storeOverrides = {
    terminalTypes: { terminalTypes: sampleTerminalTypes },
    groups: { allGroups: sampleAllGroups },
  }
) => {
  useSelector.mockImplementation((selector) => selector(storeOverrides));
  return render(<GroupMgmtEdit {...defaultProps(props)} />);
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("GroupMgmtEdit Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestDialogProps = undefined;

    SecurityAxios.mockImplementation((url) => {
      if (url.startsWith(GET_ALL_PRIVILEGES)) {
        return Promise.resolve({ status: 200, data: samplePrivileges });
      }
      if (url === MODIFY_GROUP) {
        return Promise.resolve({
          status: 200,
          data: { id: 50, message: "Updated" },
        });
      }
      return Promise.resolve({ status: 200, data: [] });
    });

    InventoryAxios.mockResolvedValue({
      status: 200,
      data: sampleResources,
    });

    jest.spyOn(console, "log").mockImplementation(() => {});
    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIALIZATION & DATA MAPPING
  ------------------------------------------------------- */

  describe("Initialization and data mapping", () => {
    it("initializes fields, suffix, and privileges from existing group data", async () => {
      renderComponent({ isGrandchildFullScreen: true });

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(
          `${GET_ALL_PRIVILEGES}/2`,
          "get"
        );
        expect(InventoryAxios).toHaveBeenCalledWith(
          `${FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL}/2`,
          "get"
        );
      });

      expect(screen.getByTestId("field-terminal")).toHaveValue("Kiosk");
      // Existing group names include KioskGroup005, so the generated prefix
      // is the next available sequence: KioskGroup006.
      expect(screen.getByTestId("field-group-name-prefix")).toHaveValue(
        "KioskGroup006"
      );
      expect(screen.getByTestId("field-group-name-suffix")).toHaveValue("Ops");
      expect(screen.getByTestId("field-description")).toHaveValue(
        "Initial group description"
      );
      expect(screen.getByTestId("submit-btn")).toBeDisabled();
      expect(latestDialogProps.isGrandchildFullScreen).toBe(true);
    });

    it("derives suffix via fallback regex when groupName does not start with generated prefix", async () => {
      renderComponent({
        data: {
          id: 50,
          terminalId: 2,
          terminalName: "Kiosk",
          groupName: "CustomPrefixGroup099Admin",
          description: "Fallback suffix test description",
          privileges: [{ id: 1 }],
          devicePrivileges: { "901_inventory": true },
        },
      });

      await waitFor(() => {
        expect(screen.getByTestId("field-group-name-suffix")).toHaveValue(
          "Admin"
        );
      });
    });

    it("handles malformed JSON in devicePrivileges and missing terminal types", async () => {
      renderComponent(
        {
          data: {
            id: 50,
            terminalId: 2,
            terminalTypeName: "Kiosk",
            groupName: "KioskGroup002Test",
            description: "Malformed JSON test description",
            privileges: [{ id: 1 }],
            devicePrivileges: "{invalid-json",
          },
        },
        { terminalTypes: null, groups: null }
      );

      await waitFor(() => {
        expect(console.error).toHaveBeenCalledWith(
          "Error parsing devicePrivileges:",
          expect.any(SyntaxError)
        );
      });
    });

    it("handles empty/failed privilege and resource fetches", async () => {
      SecurityAxios.mockResolvedValueOnce({ status: 400, data: null });
      InventoryAxios.mockRejectedValueOnce(new Error("Inventory error"));

      renderComponent();

      await waitFor(() => {
        expect(
          screen.getByText("No general privileges available.")
        ).toBeInTheDocument();
      });

      SecurityAxios.mockRejectedValueOnce(new Error("Privileges error"));
      InventoryAxios.mockResolvedValueOnce({ status: 204, data: null });

      renderComponent({
        data: { ...sampleEditData, id: 51 },
      });

      await waitFor(() => {
        expect(console.error).toHaveBeenCalled();
      });
    });

    it("hides Device Privileges tab for CNMS terminals", async () => {
      renderComponent({
        data: {
          ...sampleEditData,
          terminalId: 1,
          groupName: "CNMSServerGroup001Admin",
          devicePrivileges: "{}",
        },
      });

      await waitFor(() => {
        expect(screen.getByText("General Privileges")).toBeInTheDocument();
      });

      expect(screen.queryByText("Device Privileges")).not.toBeInTheDocument();
    });
  });

  /* -------------------------------------------------------
     VALIDATION & PRIVILEGE SELECTION
  ------------------------------------------------------- */

  describe("Validation and privilege selection", () => {
    it("shows validation errors on blur for invalid suffix and description", async () => {
      renderComponent();

      fireEvent.change(screen.getByTestId("field-group-name-suffix"), {
        target: { value: "x" },
      });
      fireEvent.blur(screen.getByTestId("field-group-name-suffix"));

      fireEvent.change(screen.getByTestId("field-description"), {
        target: { value: "bad!char" },
      });
      fireEvent.blur(screen.getByTestId("field-description"));

      await waitFor(() => {
        expect(screen.getByTestId("error-group-name-suffix")).toBeInTheDocument();
        expect(screen.getByTestId("error-description")).toBeInTheDocument();
      });
    });

    it("cascades toggles and auto-checks parent when all siblings are selected", async () => {
      renderComponent({
        data: {
          ...sampleEditData,
          privileges: [],
        },
      });

      await waitFor(() => {
        expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("toggle-priv-nan"));
      expect(screen.getByTestId("selected-privileges")).toHaveTextContent("[]");

      // Select sibling 3 and sibling 4 -> parent 2 should auto-check, and since 2 is the only child of 1, parent 1 should also auto-check
      fireEvent.click(screen.getByTestId("toggle-priv-3"));
      expect(screen.getByTestId("selected-privileges")).toHaveTextContent("[3]");

      fireEvent.click(screen.getByTestId("toggle-priv-4"));
      expect(screen.getByTestId("selected-privileges")).toHaveTextContent(
        "[3,4,2,1]"
      );

      // Deselecting 2 removes 2, 3, and 4
      fireEvent.click(screen.getByTestId("toggle-priv-2"));
      expect(screen.getByTestId("selected-privileges")).toHaveTextContent("[1]");

      // Select all / unselect all
      fireEvent.click(screen.getByTestId("select-all-privs"));
      expect(screen.getByTestId("all-privileges-selected")).toHaveTextContent(
        "true"
      );

      fireEvent.click(screen.getByTestId("select-all-privs"));
      expect(screen.getByTestId("selected-privileges")).toHaveTextContent("[]");
    });

    it("handles selectAll when privileges list is empty", async () => {
      SecurityAxios.mockResolvedValueOnce({ status: 200, data: [] });

      renderComponent();

      // The component intentionally does not render PrivilegeTree when the
      // API returns an empty privilege list.
      expect(
        await screen.findByText("No general privileges available.")
      ).toBeInTheDocument();
      expect(screen.queryByTestId("privilege-tree")).not.toBeInTheDocument();
      expect(screen.getByTestId("submit-btn")).toBeDisabled();
    });
  });

  /* -------------------------------------------------------
     CHANGE DETECTION, SUBMISSION & ERRORS
  ------------------------------------------------------- */

  describe("Change detection, submission, and error handling", () => {
    it("enables Update when text fields or device capabilities change and submits payload", async () => {
      const onRefresh = jest.fn().mockRejectedValueOnce(new Error("Refresh warn"));
      const props = defaultProps({ onRefresh });

      renderComponent(props);

      await waitFor(() => {
        expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      });

      expect(screen.getByTestId("submit-btn")).toBeDisabled();

      fireEvent.change(screen.getByTestId("field-group-name-suffix"), {
        target: { value: "OpsUpdated" },
      });
      fireEvent.change(screen.getByTestId("field-description"), {
        target: { value: "Updated group description 456" },
      });

      fireEvent.click(screen.getByText("Device Privileges"));
      fireEvent.click(screen.getByTestId("set-capabilities"));

      expect(screen.getByTestId("submit-btn")).toBeEnabled();

      fireEvent.click(screen.getByTestId("submit-btn"));
      expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();

      fireEvent.click(screen.getByTestId("dialog-cancel"));
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();

      fireEvent.click(screen.getByTestId("submit-btn"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(MODIFY_GROUP, "post", {
          id: 50,
          groupName: "OpsUpdated",
          terminalType: { id: 2 },
          description: "Updated group description 456",
          privileges: [{ id: 1 }, { id: 2 }],
          devicePrivileges: JSON.stringify({
            "901_inventory": true,
            "902_configuration": true,
            "903_add_delete": true,
            "905_status": true,
            "906_cross_launch": true,
          }),
        });
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success!",
        "Group updated successfully!",
        "success"
      );
      expect(props.onSuccess).toHaveBeenCalledWith({
        id: 50,
        message: "Updated",
      });
      expect(props.onClose).toHaveBeenCalledTimes(1);
    });

    it("handles MODIFY_GROUP errors with message, error, or fallback text", async () => {
      SecurityAxios.mockImplementation((url) => {
        if (url.startsWith(GET_ALL_PRIVILEGES)) {
          return Promise.resolve({ status: 200, data: samplePrivileges });
        }
        if (url === MODIFY_GROUP) {
          return Promise.reject({
            response: { data: { message: "Group already exists" } },
          });
        }
        return Promise.resolve({ status: 200, data: [] });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("field-description")).toBeInTheDocument();
      });

      fireEvent.change(screen.getByTestId("field-description"), {
        target: { value: "Changed description text" },
      });

      fireEvent.click(screen.getByTestId("submit-btn"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Group already exists",
          "error"
        );
      });

      SecurityAxios.mockImplementation((url) => {
        if (url.startsWith(GET_ALL_PRIVILEGES)) {
          return Promise.resolve({ status: 200, data: samplePrivileges });
        }
        if (url === MODIFY_GROUP) {
          return Promise.reject({
            response: { data: { error: "Conflict error" } },
          });
        }
        return Promise.resolve({ status: 200, data: [] });
      });

      fireEvent.click(screen.getByTestId("submit-btn"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith("Error!", "Conflict error", "error");
      });

      SecurityAxios.mockImplementation((url) => {
        if (url.startsWith(GET_ALL_PRIVILEGES)) {
          return Promise.resolve({ status: 200, data: samplePrivileges });
        }
        if (url === MODIFY_GROUP) {
          return Promise.reject(new Error("Server error"));
        }
        return Promise.resolve({ status: 200, data: [] });
      });

      fireEvent.click(screen.getByTestId("submit-btn"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to update group.",
          "error"
        );
      });
    });

    it("shows Updating... while request is in flight", async () => {
      let resolveUpdate;

      SecurityAxios.mockImplementation((url) => {
        if (url.startsWith(GET_ALL_PRIVILEGES)) {
          return Promise.resolve({ status: 200, data: samplePrivileges });
        }
        if (url === MODIFY_GROUP) {
          return new Promise((resolve) => {
            resolveUpdate = resolve;
          });
        }
        return Promise.resolve({ status: 200, data: [] });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("field-description")).toBeInTheDocument();
      });

      fireEvent.change(screen.getByTestId("field-description"), {
        target: { value: "Pending update description" },
      });

      fireEvent.click(screen.getByTestId("submit-btn"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      expect(screen.getByTestId("submit-btn")).toHaveTextContent("Updating...");
      expect(screen.getByTestId("submit-btn")).toBeDisabled();

      await act(async () => {
        resolveUpdate({ status: 201, data: {} });
      });

      await waitFor(() => {
        expect(screen.getByTestId("submit-btn")).toHaveTextContent("Update");
      });
    });
  });
});


