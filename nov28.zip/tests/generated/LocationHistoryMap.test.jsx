import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

const mockDivIcon = jest.fn((options) => options);

jest.unstable_mockModule("leaflet", () => ({
  __esModule: true,
  default: {
    divIcon: mockDivIcon,
  },
}));

jest.unstable_mockModule("@/RestAPI/url/baseUrl", () => ({
  GEO_SERVER_MAP_VIEW_URL: "/mock-map-url",
}));

jest.unstable_mockModule("react-leaflet", () => ({
  MapContainer: ({ children, center, zoom }) => (
    <div
      data-testid="map-container"
      data-center={JSON.stringify(center)}
      data-zoom={zoom}
    >
      {children}
    </div>
  ),

  TileLayer: (props) => (
    <div data-testid="tile-layer" data-url={props.url} />
  ),

  WMSTileLayer: (props) => (
    <div data-testid="wms-tile-layer" data-layers={props.layers} />
  ),

  Marker: ({ position, icon }) => (
    <div
      data-testid="map-marker"
      data-position={JSON.stringify(position)}
      data-icon={JSON.stringify(icon)}
    />
  ),

  Polyline: ({ positions, pathOptions }) => (
    <div
      data-testid="map-polyline"
      data-positions={JSON.stringify(positions)}
      data-color={pathOptions.color}
    />
  ),
}));

jest.unstable_mockModule(
  "@/Pages/CnmsDashboard/CnmsMap/components/LiveCoordinates",
  () => ({
    LiveCordinates: () => (
      <div data-testid="live-coordinates">Live Coordinates</div>
    ),
  })
);

const { default: LocationHistoryMap } = await import(
  "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/SiteLocationHistory/LocationHistoryMap"
);
const { default: L } = await import("leaflet");

// --------------------------------------------------
// Test Data
// --------------------------------------------------

const sampleData = [
  {
    serial: 1,
    siteId: "SITE001",
    lattitude: 20.5937,
    longitude: 78.9629,
  },
  {
    serial: 2,
    siteId: "SITE002",
    lattitude: 19.076,
    longitude: 72.8777,
  },
  {
    serial: 10,
    siteId: "SITE003",
    lattitude: 13.0827,
    longitude: 80.2707,
  },
];

// --------------------------------------------------
// Setup
// --------------------------------------------------

beforeEach(() => {
  jest.clearAllMocks();

  window.L = {
    CRS: {
      EPSG4326: {
        code: "EPSG:4326",
      },
    },
  };
});

// --------------------------------------------------
// Rendering Tests
// --------------------------------------------------

describe("LocationHistoryMap - Rendering", () => {
  test("renders map container", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("map-container")).toBeInTheDocument();
  });

  test("renders tile layer", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("tile-layer")).toBeInTheDocument();
  });

  test("renders WMS tile layer", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("wms-tile-layer")).toBeInTheDocument();

    expect(screen.getByTestId("wms-tile-layer")).toHaveAttribute(
      "data-layers",
      "MCT_LSV_GIS:MCT_LSV_Map"
    );
  });

  test("renders live coordinates component", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("live-coordinates")).toBeInTheDocument();
  });

  test("renders map with first record coordinates as center", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("map-container")).toHaveAttribute(
      "data-center",
      JSON.stringify([20.5937, 78.9629])
    );
  });

  test("renders map with zoom level 7", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("map-container")).toHaveAttribute(
      "data-zoom",
      "7"
    );
  });
});

// --------------------------------------------------
// Marker Tests
// --------------------------------------------------

describe("LocationHistoryMap - Markers", () => {
  test("renders a marker for every location record", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getAllByTestId("map-marker")).toHaveLength(3);
  });

  test("renders marker with correct coordinates", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    const markers = screen.getAllByTestId("map-marker");

    expect(markers[0]).toHaveAttribute(
      "data-position",
      JSON.stringify([20.5937, 78.9629])
    );

    expect(markers[1]).toHaveAttribute(
      "data-position",
      JSON.stringify([19.076, 72.8777])
    );
  });

  test("creates Leaflet divIcon for each marker", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(L.divIcon).toHaveBeenCalledTimes(6);
  });

  test("formats serial number below 10 with leading zero", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(L.divIcon).toHaveBeenCalledWith({
      html: '<span class="site-hist-marker" >01</span>',
    });

    expect(L.divIcon).toHaveBeenCalledWith({
      html: '<span class="site-hist-marker" >02</span>',
    });
  });

  test("does not add leading zero to serial number 10 or greater", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(L.divIcon).toHaveBeenCalledWith({
      html: '<span class="site-hist-marker" >10</span>',
    });
  });
});

// --------------------------------------------------
// Polyline Tests
// --------------------------------------------------

describe("LocationHistoryMap - Polyline", () => {
  test("renders polyline", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("map-polyline")).toBeInTheDocument();
  });

  test("renders polyline with green color", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("map-polyline")).toHaveAttribute(
      "data-color",
      "green"
    );
  });

  test("renders all location coordinates in polyline", () => {
    render(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getByTestId("map-polyline")).toHaveAttribute(
      "data-positions",
      JSON.stringify([
        [20.5937, 78.9629],
        [19.076, 72.8777],
        [13.0827, 80.2707],
      ])
    );
  });

  test("updates polyline when location data changes", () => {
    const { rerender } = render(
      <LocationHistoryMap finalTransformedData={[sampleData[0]]} />
    );

    expect(screen.getByTestId("map-polyline")).toHaveAttribute(
      "data-positions",
      JSON.stringify([[20.5937, 78.9629]])
    );

    rerender(<LocationHistoryMap finalTransformedData={[sampleData[1]]} />);

    expect(screen.getByTestId("map-polyline")).toHaveAttribute(
      "data-positions",
      JSON.stringify([[19.076, 72.8777]])
    );
  });

  test("updates markers when location data changes", () => {
    const { rerender } = render(
      <LocationHistoryMap finalTransformedData={[sampleData[0]]} />
    );

    expect(screen.getAllByTestId("map-marker")).toHaveLength(1);

    rerender(<LocationHistoryMap finalTransformedData={sampleData} />);

    expect(screen.getAllByTestId("map-marker")).toHaveLength(3);
  });

  test("renders empty polyline when data is empty", () => {
    render(<LocationHistoryMap finalTransformedData={[]} />);

    expect(screen.getByTestId("map-polyline")).toHaveAttribute(
      "data-positions",
      "[]"
    );

    expect(screen.queryAllByTestId("map-marker")).toHaveLength(0);
  });
});
