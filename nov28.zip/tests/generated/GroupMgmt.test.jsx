import React from "react";
import { jest } from "@jest/globals";
import {
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";
import "@testing-library/jest-dom";



/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
  SecurityAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  DELETE_GROUP: "/delete-group",
  FETCH_ALL_TERMINAL_TYPE_DETAILS: "/fetch-terminal-types",
  GET_ALL_GROUPS: "/get-all-groups",
  GET_USERS_BY_GROUP: "/get-users-by-group/",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

const mockDispatch = jest.fn();

jest.unstable_mockModule("react-redux", () => ({
  useDispatch: jest.fn(() => mockDispatch),
}));

jest.unstable_mockModule(
  "@/store/features/Cnms/remoteRepDetails/terminalTypeSlice",
  () => ({
    setTerminalTypesData: jest.fn((payload) => ({
      type: "terminalType/setTerminalTypesData",
      payload,
    })),
  })
);

jest.unstable_mockModule("@/store/features/Cnms/GetAllGroups/groupSlice", () => ({
  setAllGroups: jest.fn((payload) => ({
    type: "groups/setAllGroups",
    payload,
  })),
}));

let latestMultiSelectProps;

jest.unstable_mockModule("@/components/Reusable/Select/MMultiSelect", () => ({
  __esModule: true,
  default: (props) => {
    latestMultiSelectProps = props;
    return (
      <div data-testid="terminal-multiselect">
        <span data-testid="selected-terminals">
          {JSON.stringify(props.value)}
        </span>
        <button
          data-testid="select-terminal-1"
          onClick={() => props.onChange([1])}
        >
          Select Terminal 1
        </button>
        <button
          data-testid="select-all-terminals"
          onClick={() => props.onChange([1, 2])}
        >
          Select All Terminals
        </button>
        <button
          data-testid="clear-terminals"
          onClick={() => props.onChange([])}
        >
          Clear Terminals
        </button>
      </div>
    );
  },
}));

let latestTableProps;

jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => ({
  __esModule: true,
  default: (props) => {
    latestTableProps = props;
    const sampleRow = props.tableData[0];

    return (
      <div data-testid="mtable">
        <span data-testid="table-row-count">{props.tableData.length}</span>
        <span data-testid="table-row-names">
          {props.tableData.map((r) => r.groupName).join(",")}
        </span>
        {props.tableData.map((row) => (
          <div key={row.id} data-testid={`group-row-${row.id}`}>
            <span>{row.groupName}</span>
            <span data-testid={`delete-disabled-${row.id}`}>
              {String(props.deleteDisable(row))}
            </span>
            <span data-testid={`edit-disabled-${row.id}`}>
              {String(props.editDisable(row))}
            </span>
            <button
              data-testid={`delete-btn-${row.id}`}
              onClick={() => props.handleDelete(row)}
            >
              Delete {row.groupName}
            </button>
            <button
              data-testid={`edit-btn-${row.id}`}
              onClick={() => props.handleEdit(row)}
            >
              Edit {row.groupName}
            </button>
            <button
              data-testid={`view-btn-${row.id}`}
              onClick={() => props.handleView(row)}
            >
              View {row.groupName}
            </button>
          </div>
        ))}
        <button data-testid="add-group-btn" onClick={props.handleAdd}>
          {props.AddText}
        </button>
        {sampleRow && (
          <button
            data-testid="delete-first-row"
            onClick={() => props.handleDelete(sampleRow)}
          >
            Delete First
          </button>
        )}
      </div>
    );
  },
}));

let latestDialogProps;

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => {
    latestDialogProps = props;
    return props.open ? (
      <div data-testid="delete-dialog">
        <div data-testid="dialog-title">{props.title}</div>
        <div data-testid="dialog-message">{props.message}</div>
        <button
          data-testid="dialog-confirm"
          onClick={props.onConfirm}
        >
          Confirm
        </button>
        <button
          data-testid="dialog-cancel"
          onClick={props.onClose}
        >
          Cancel
        </button>
      </div>
    ) : null;
  },
}));

/* -------------------------------------------------------
   HELPERS & SAMPLE DATA
------------------------------------------------------- */

// Load the component and mocked dependencies after ESM mock registration.
const { default: GroupMgmt } = await import(
  "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmt"
);
const { InventoryAxios, SecurityAxios } = await import(
  "@/RestAPI/api/axiosApicall"
);
const {
  DELETE_GROUP,
  FETCH_ALL_TERMINAL_TYPE_DETAILS,
  GET_ALL_GROUPS,
  GET_USERS_BY_GROUP,
} = await import("@/RestAPI/url/endpoint");
const { default: Toast } = await import(
  "@/components/Reusable/Toast/Toast"
);
const { useDispatch } = await import("react-redux");
const { setTerminalTypesData } = await import(
  "@/store/features/Cnms/remoteRepDetails/terminalTypeSlice"
);
const { setAllGroups } = await import(
  "@/store/features/Cnms/GetAllGroups/groupSlice"
);

const sampleTerminals = [
  { id: 1, terminalTypeName: "POS Terminal" },
  { id: 2, terminalTypeName: "Kiosk" },
];

const sampleGroups = [
  {
    id: 101,
    groupName: "Admins",
    description: "System administrators",
    terminalType: { id: 1 },
    isDefaultGroup: true,
    privileges: ["READ", "WRITE"],
    devicePrivileges: ["REBOOT"],
  },
  {
    id: 102,
    groupName: "Operators",
    description: "Daily shift operators",
    terminalType: { id: 2 },
    isDefaultGroup: false,
    privileges: ["READ"],
    devicePrivileges: [],
  },
];

const defaultProps = (overrides = {}) => ({
  privilegeKey: "GROUP_MGMT",
  handleAdd: jest.fn(),
  handleEdit: jest.fn(),
  handleView: jest.fn(),
  refreshTrigger: 0,
  isChildFullScreen: false,
  ...overrides,
});

const renderGroupMgmt = (props = {}) =>
  render(<GroupMgmt {...defaultProps(props)} />);

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("GroupMgmt Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestMultiSelectProps = undefined;
    latestTableProps = undefined;
    latestDialogProps = undefined;

    useDispatch.mockReturnValue(mockDispatch);

    InventoryAxios.mockResolvedValue({
      data: sampleTerminals,
    });

    SecurityAxios.mockImplementation((url) => {
      if (url === GET_ALL_GROUPS) {
        return Promise.resolve({ data: sampleGroups });
      }
      if (url.startsWith(GET_USERS_BY_GROUP)) {
        return Promise.resolve({ data: [] });
      }
      if (url === DELETE_GROUP) {
        return Promise.resolve({ data: { status: 1 } });
      }
      return Promise.resolve({ data: [] });
    });

    jest.spyOn(console, "log").mockImplementation(() => {});
    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIAL RENDER & DATA LOADING
  ------------------------------------------------------- */

  describe("Initial rendering and data loading", () => {
    it("shows a loading spinner while groups are being fetched", () => {
      SecurityAxios.mockImplementationOnce(
        () => new Promise(() => {})
      );

      renderGroupMgmt();

      expect(screen.getByRole("progressbar")).toBeInTheDocument();
    });

    it("loads terminals, pre-selects all terminal IDs, and dispatches terminal types", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          FETCH_ALL_TERMINAL_TYPE_DETAILS,
          "get"
        );
      });

      const expectedFormatted = [
        { label: "POS Terminal", value: 1, raw: sampleTerminals[0] },
        { label: "Kiosk", value: 2, raw: sampleTerminals[1] },
      ];

      expect(setTerminalTypesData).toHaveBeenCalledWith(expectedFormatted);
      expect(mockDispatch).toHaveBeenCalledWith({
        type: "terminalType/setTerminalTypesData",
        payload: expectedFormatted,
      });
      expect(screen.getByTestId("selected-terminals")).toHaveTextContent(
        "[1,2]"
      );
    });

    it("handles empty or missing terminal response data", async () => {
      InventoryAxios.mockResolvedValueOnce({});

      renderGroupMgmt();

      await waitFor(() => {
        expect(setTerminalTypesData).toHaveBeenCalledWith([]);
      });
      expect(screen.getByTestId("selected-terminals")).toHaveTextContent("[]");
    });

    it("shows an error toast when loading terminals fails", async () => {
      InventoryAxios.mockRejectedValueOnce(new Error("Terminal API down"));

      renderGroupMgmt();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Error loading terminals",
          "error"
        );
      });
    });

    it("fetches groups, dispatches all groups, and processes table rows", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("mtable")).toBeInTheDocument();
      });

      expect(SecurityAxios).toHaveBeenCalledWith(GET_ALL_GROUPS, "get", 1);
      expect(setAllGroups).toHaveBeenCalledWith(sampleGroups);
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");
      expect(screen.getByTestId("table-row-names")).toHaveTextContent(
        "Admins,Operators"
      );

      expect(latestTableProps.tableData[0]).toEqual({
        sno: 1,
        groupName: "Admins",
        description: "System administrators",
        terminalId: 1,
        isDefaultGroup: true,
        id: 101,
        privileges: ["READ", "WRITE"],
        devicePrivileges: ["REBOOT"],
      });
    });

    it("handles null/undefined groups data and resets table on fetch failure", async () => {
      SecurityAxios.mockImplementationOnce(() =>
        Promise.resolve({ data: undefined })
      );

      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("mtable")).toBeInTheDocument();
      });

      expect(setAllGroups).toHaveBeenCalledWith([]);
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("0");

      SecurityAxios.mockImplementationOnce(() =>
        Promise.reject(new Error("Network error"))
      );

      renderGroupMgmt({ refreshTrigger: 1 });

      await waitFor(() => {
        expect(console.error).toHaveBeenCalled();
      });
    });

    it("re-fetches groups when refreshTrigger changes", async () => {
      const { rerender } = renderGroupMgmt({ refreshTrigger: 1 });

      await waitFor(() => {
        expect(screen.getByTestId("mtable")).toBeInTheDocument();
      });

      rerender(<GroupMgmt {...defaultProps({ refreshTrigger: 2 })} />);

      await waitFor(() => {
        const groupCalls = SecurityAxios.mock.calls.filter(
          ([url]) => url === GET_ALL_GROUPS
        );
        expect(groupCalls).toHaveLength(2);
      });
    });
  });

  /* -------------------------------------------------------
     TERMINAL FILTERING & TABLE ACTIONS
  ------------------------------------------------------- */

  describe("Terminal filtering and table actions", () => {
    it("filters groups when selected terminals change", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");
      });

      fireEvent.click(screen.getByTestId("select-terminal-1"));

      expect(screen.getByTestId("selected-terminals")).toHaveTextContent("[1]");
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("1");
      expect(screen.getByTestId("table-row-names")).toHaveTextContent("Admins");

      fireEvent.click(screen.getByTestId("clear-terminals"));

      expect(screen.getByTestId("table-row-count")).toHaveTextContent("0");

      fireEvent.click(screen.getByTestId("select-all-terminals"));

      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");
    });

    it("disables edit and delete for default groups and enables them for custom groups", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("group-row-101")).toBeInTheDocument();
      });

      expect(screen.getByTestId("delete-disabled-101")).toHaveTextContent("true");
      expect(screen.getByTestId("edit-disabled-101")).toHaveTextContent("true");

      expect(screen.getByTestId("delete-disabled-102")).toHaveTextContent("false");
      expect(screen.getByTestId("edit-disabled-102")).toHaveTextContent("false");
    });

    it("invokes handleAdd, handleEdit, and handleView with expected payloads", async () => {
      const props = defaultProps();
      renderGroupMgmt(props);

      await waitFor(() => {
        expect(screen.getByTestId("group-row-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("add-group-btn"));
      expect(props.handleAdd).toHaveBeenCalledWith({
        mode: "CREATE",
        title: "Add Group Details",
      });

      fireEvent.click(screen.getByTestId("edit-btn-102"));
      expect(props.handleEdit).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 102,
          groupName: "Operators",
          mode: "EDIT",
          title: "Edit Group: Operators",
        })
      );

      fireEvent.click(screen.getByTestId("view-btn-102"));
      expect(props.handleView).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 102,
          groupName: "Operators",
          mode: "VIEW",
          title: "View Group: Operators",
        })
      );
    });
  });

  /* -------------------------------------------------------
     DELETE FLOW & CONFIRMATION DIALOG
  ------------------------------------------------------- */

  describe("Delete confirmation and group deletion", () => {
    it("opens confirmation dialog without user list when group has no users", async () => {
      renderGroupMgmt({ isChildFullScreen: true });

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-102"));

      await waitFor(() => {
        expect(screen.getByTestId("delete-dialog")).toBeInTheDocument();
      });

      expect(SecurityAxios).toHaveBeenCalledWith(
        `${GET_USERS_BY_GROUP}102`,
        "get"
      );
      expect(latestDialogProps.isChildFullScreen).toBe(true);
      expect(latestDialogProps.variant).toBe("error");
      expect(latestDialogProps.mode).toBe("child");
      expect(screen.getByTestId("dialog-message")).toHaveTextContent(
        "Are you sure you want to delete Operators?"
      );
      expect(
        screen.queryByText(
          "Following users associated with the group will also be deleted:"
        )
      ).not.toBeInTheDocument();
    });

    it("displays associated users in the confirmation dialog when present", async () => {
      SecurityAxios.mockImplementation((url) => {
        if (url === GET_ALL_GROUPS) {
          return Promise.resolve({ data: sampleGroups });
        }
        if (url === `${GET_USERS_BY_GROUP}102`) {
          return Promise.resolve({
            data: [
              { id: 1, userName: "alice" },
              { userName: "bob" },
            ],
          });
        }
        return Promise.resolve({ data: {} });
      });

      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-102"));

      await waitFor(() => {
        expect(
          screen.getByText(
            "Following users associated with the group will also be deleted:"
          )
        ).toBeInTheDocument();
      });

      expect(screen.getByText("alice")).toBeInTheDocument();
      expect(screen.getByText("bob")).toBeInTheDocument();
    });

    it("closes confirmation dialog when cancelled without deleting", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-102"));

      await waitFor(() => {
        expect(screen.getByTestId("delete-dialog")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("dialog-cancel"));

      expect(screen.queryByTestId("delete-dialog")).not.toBeInTheDocument();
      expect(SecurityAxios).not.toHaveBeenCalledWith(
        DELETE_GROUP,
        expect.anything(),
        expect.anything()
      );
    });

    it("shows error toast when fetching users for a group fails", async () => {
      SecurityAxios.mockImplementation((url) => {
        if (url === GET_ALL_GROUPS) {
          return Promise.resolve({ data: sampleGroups });
        }
        if (url === `${GET_USERS_BY_GROUP}102`) {
          return Promise.reject(new Error("User lookup failed"));
        }
        return Promise.resolve({ data: {} });
      });

      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-102"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Could not verify users",
          "error"
        );
      });
      expect(screen.queryByTestId("delete-dialog")).not.toBeInTheDocument();
    });

    it("deletes group, updates table data, and shows success toast on confirm", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-102"));

      await waitFor(() => {
        expect(screen.getByTestId("dialog-confirm")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(DELETE_GROUP, "post", {
          id: 102,
          description: null,
          groupName: null,
          isDefaultGroup: null,
          privileges: null,
        });
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success!",
        "Group and associated user access deleted",
        "success"
      );
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("1");
      expect(screen.getByTestId("table-row-names")).toHaveTextContent("Admins");
      expect(screen.queryByTestId("delete-dialog")).not.toBeInTheDocument();
    });

    it("passes truthy isDefaultGroup in delete payload when deleting a default group", async () => {
      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-101")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-101"));

      await waitFor(() => {
        expect(screen.getByTestId("dialog-confirm")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(DELETE_GROUP, "post", {
          id: 101,
          description: null,
          groupName: null,
          isDefaultGroup: true,
          privileges: null,
        });
      });
    });

    it("shows error toast when group deletion fails", async () => {
      SecurityAxios.mockImplementation((url) => {
        if (url === GET_ALL_GROUPS) {
          return Promise.resolve({ data: sampleGroups });
        }
        if (url.startsWith(GET_USERS_BY_GROUP)) {
          return Promise.resolve({ data: [] });
        }
        if (url === DELETE_GROUP) {
          return Promise.reject(new Error("Delete failed"));
        }
        return Promise.resolve({ data: {} });
      });

      renderGroupMgmt();

      await waitFor(() => {
        expect(screen.getByTestId("delete-btn-102")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("delete-btn-102"));

      await waitFor(() => {
        expect(screen.getByTestId("dialog-confirm")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("dialog-confirm"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Failed to process deletion",
          "error"
        );
      });
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");
    });
  });
});
