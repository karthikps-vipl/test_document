import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

// --------------------------------------------------
// Stable Redux mock state
// --------------------------------------------------

const mockTerminalTypes = [];

const mockReduxState = {
  terminalTypes: {
    terminalTypes: mockTerminalTypes,
  },
  userSlice: {
    isReadOnlyMode: false,
    isUserLoggedIn: true,
  },
};

// --------------------------------------------------
// Mock react-redux before importing component
// --------------------------------------------------

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn((selector) => selector(mockReduxState)),
}));

// --------------------------------------------------
// Import component after registering mocks
// --------------------------------------------------

const { default: GroupMgmtAdd } = await import(
  "../../src/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtAdd"
);

// --------------------------------------------------
// Tests
// --------------------------------------------------

describe("GroupMgmtAdd", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders without crashing", () => {
    render(<GroupMgmtAdd />);

    expect(document.body).toBeInTheDocument();
  });

  test("renders with initialized terminal types", () => {
    render(<GroupMgmtAdd />);

    expect(document.body).toBeInTheDocument();
  });
});
