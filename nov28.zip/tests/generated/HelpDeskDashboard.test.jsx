import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent } from "@testing-library/react";

// --------------------------------------------------
// Mock child components before importing Dashboard
// --------------------------------------------------

jest.unstable_mockModule(
  "@/components/Reusable/Scrollbar/ScrollContainer",
  () => ({
    default: function MockScrollContainer({ children }) {
      return <div data-testid="scroll-container">{children}</div>;
    },
  })
);

jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskSeverity",
  () => ({
    default: function MockHelpDeskSeverity({ tableData = [] }) {
      return (
        <div
          data-testid="severity-widget"
          data-count={tableData.length}
        />
      );
    },
  })
);

jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskChart",
  () => ({
    default: function MockHelpDeskChart({ tableData = [] }) {
      return (
        <div
          data-testid="chart-widget"
          data-count={tableData.length}
        />
      );
    },
  })
);

jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/ReportAdvancedSearch",
  () => ({
    default: function MockReportAdvancedSearch({
      data = [],
      setFilteredData,
    }) {
      return (
        <button
          type="button"
          data-testid="apply-filter-btn"
          onClick={() => setFilteredData(data.slice(0, 1))}
        >
          Filter ({data.length})
        </button>
      );
    },
  })
);

jest.unstable_mockModule(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskTable",
  () => ({
    default: function MockHelpDeskTable({
      tableData = [],
      setTableData,
      handleAdd,
      handleView,
      handleHistory,
      handleReopenAction,
      handleCloseAction,
      handleInProgressAction,
      handlePendingAction,
      handleResolvedAction,
      refreshTrigger,
    }) {
      return (
        <div
          data-testid="helpdesk-table"
          data-refresh={String(refreshTrigger)}
        >
          <span data-testid="table-count">{tableData.length}</span>

          <button
            type="button"
            onClick={() =>
              setTableData([
                { id: 1, status: "Open", priority: "Major" },
                { id: 2, status: "Closed", priority: "Minor" },
              ])
            }
          >
            Load Rows
          </button>

          <button type="button" onClick={handleAdd}>
            Add Action
          </button>

          <button type="button" onClick={handleView}>
            View Action
          </button>

          <button
            type="button"
            onClick={() =>
              handleHistory({ id: 1, ticketNo: "TCK-1" })
            }
          >
            History Action
          </button>

          <button type="button" onClick={handleReopenAction}>
            Reopen Action
          </button>

          <button type="button" onClick={handleCloseAction}>
            Close Action
          </button>

          <button type="button" onClick={handleInProgressAction}>
            InProgress Action
          </button>

          <button type="button" onClick={handlePendingAction}>
            Pending Action
          </button>

          <button type="button" onClick={handleResolvedAction}>
            Resolved Action
          </button>
        </div>
      );
    },
  })
);

// Import component only after all ESM mocks are registered.
const { default: HelpDeskDashboard } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskDashboard"
);

// --------------------------------------------------
// Tests
// --------------------------------------------------

describe("HelpDeskDashboard", () => {
  const handlers = {
    handleAdd: jest.fn(),
    handleCloseAction: jest.fn(),
    handleView: jest.fn(),
    handleHistory: jest.fn(),
    handleReopenAction: jest.fn(),
    handleInProgressAction: jest.fn(),
    handlePendingAction: jest.fn(),
    handleResolvedAction: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders child sections, syncs table data, applies search filter, and triggers callbacks", () => {
    render(
      <HelpDeskDashboard
        {...handlers}
        refreshTrigger={3}
      />
    );

    // Initial rendering
    expect(screen.getByTestId("scroll-container")).toBeInTheDocument();

    expect(screen.getByTestId("helpdesk-table")).toHaveAttribute(
      "data-refresh",
      "3"
    );

    expect(screen.getByTestId("severity-widget")).toHaveAttribute(
      "data-count",
      "0"
    );

    expect(screen.getByTestId("chart-widget")).toHaveAttribute(
      "data-count",
      "0"
    );

    // Populate table data
    fireEvent.click(
      screen.getByRole("button", { name: "Load Rows" })
    );

    expect(screen.getByTestId("table-count")).toHaveTextContent("2");

    expect(screen.getByTestId("severity-widget")).toHaveAttribute(
      "data-count",
      "2"
    );

    expect(screen.getByTestId("chart-widget")).toHaveAttribute(
      "data-count",
      "2"
    );

    // Apply filter
    fireEvent.click(screen.getByTestId("apply-filter-btn"));

    expect(screen.getByTestId("table-count")).toHaveTextContent("1");

    expect(screen.getByTestId("severity-widget")).toHaveAttribute(
      "data-count",
      "1"
    );

    // Add action
    fireEvent.click(
      screen.getByRole("button", { name: "Add Action" })
    );

    expect(handlers.handleAdd).toHaveBeenCalledWith({
      mode: "CREATE",
      title: "Create Ticket",
    });

    // View action
    fireEvent.click(
      screen.getByRole("button", { name: "View Action" })
    );

    expect(handlers.handleView).toHaveBeenCalledWith({
      mode: "CREATE",
      title: "Create Ticket",
    });

    // History action
    fireEvent.click(
      screen.getByRole("button", { name: "History Action" })
    );

    expect(handlers.handleHistory).toHaveBeenCalledWith({
      id: 1,
      ticketNo: "TCK-1",
      mode: "HISTORY",
      title: "Ticket History",
    });

    // Reopen action
    fireEvent.click(
      screen.getByRole("button", { name: "Reopen Action" })
    );

    expect(handlers.handleReopenAction).toHaveBeenCalledWith({
      mode: "REOPEN",
      title: "Create Ticket",
    });

    // Close action
    fireEvent.click(
      screen.getByRole("button", { name: "Close Action" })
    );

    expect(handlers.handleCloseAction).toHaveBeenCalledWith({
      mode: "CLOSE",
      title: "Create Ticket",
    });

    // In-progress action
    fireEvent.click(
      screen.getByRole("button", { name: "InProgress Action" })
    );

    expect(handlers.handleInProgressAction).toHaveBeenCalledWith({
      mode: "INPROGRESS",
      title: "Create Ticket",
    });

    // Pending action
    fireEvent.click(
      screen.getByRole("button", { name: "Pending Action" })
    );

    expect(handlers.handlePendingAction).toHaveBeenCalledWith({
      mode: "PENDING",
      title: "Create Ticket",
    });

    // Resolved action
    fireEvent.click(
      screen.getByRole("button", { name: "Resolved Action" })
    );

    expect(handlers.handleResolvedAction).toHaveBeenCalledWith({
      mode: "PENDING",
      title: "Create Ticket",
    });
  });
});
