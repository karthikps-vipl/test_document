import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";
import { createTheme, ThemeProvider } from "@mui/material/styles";


/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  CertAxios: jest.fn(),
  ConfigurationAxios: jest.fn(),
  InventAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  DELETE_CSR_URL: "/delete-csr",
  DOWNLOAD_FILE_FOR_GIVEN_ID_URL: "/download-file-for-id",
  DOWNLOAD_PACKAGE_CERT_URL: "/download-package-cert",
  FETCH_CNMS_ADDRESS_DETAILS: "/fetch-cnms-address",
  GET_ALL_CERT: "/get-all-cert",
  UPLOAD_CERT: "/upload-cert",
  UPLOAD_CERT_TO_MODEM: "/upload-cert-to-modem",
  UPLOAD_PACKAGED_CRT_FILE_URL: "/upload-packaged-crt",
}));

jest.unstable_mockModule("@/RestAPI/url/baseUrl", () => ({
  CERT_URL: "https://cert-base.example.com",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

const mockDispatch = jest.fn();

jest.unstable_mockModule("react-redux", () => ({
  useDispatch: jest.fn(() => mockDispatch),
  useSelector: jest.fn(),
}));

jest.unstable_mockModule(
  "@/store/features/X509Certificate/certificateExportSlice",
  () => ({
    clearCertificateExportResponse: jest.fn(() => ({
      type: "certificateExport/clearCertificateExportResponse",
    })),
  })
);

jest.unstable_mockModule("@/Pages/Rnmsdashboard/RightUtilityDrawer/components/XCertificate/UploadRootOrSubCA", () => ({
  __esModule: true,
  default: () => <div data-testid="upload-root-sub-ca">UploadRootOrSubCA</div>,
}));

jest.unstable_mockModule("@/components/Reusable/Select/MAlarmSelect", () => ({
  __esModule: true,
  default: ({ value, onChange }) => (
    <div data-testid="alarm-select">
      <span data-testid="alarm-expiry-val">{JSON.stringify(value)}</span>
      <button
        type="button"
        data-testid="filter-expired"
        onClick={() => onChange(["expired"])}
      >
        Filter Expired
      </button>
      <button
        type="button"
        data-testid="filter-issued"
        onClick={() => onChange(["issued"])}
      >
        Filter Issued
      </button>
      <button
        type="button"
        data-testid="filter-30"
        onClick={() => onChange(["30"])}
      >
        Filter 30
      </button>
      <button
        type="button"
        data-testid="filter-90"
        onClick={() => onChange(["90"])}
      >
        Filter 90
      </button>
      <button
        type="button"
        data-testid="filter-180"
        onClick={() => onChange(["180"])}
      >
        Filter 180
      </button>
      <button
        type="button"
        data-testid="filter-365"
        onClick={() => onChange(["365"])}
      >
        Filter 365
      </button>
      <button
        type="button"
        data-testid="filter-unknown"
        onClick={() => onChange(["other"])}
      >
        Filter Other
      </button>
      <button
        type="button"
        data-testid="filter-single"
        onClick={() => onChange("30")}
      >
        Filter Single
      </button>
    </div>
  ),
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonSecondary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button
      type="button"
      data-testid="secondary-btn"
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  ),
}));

let latestTableProps;

jest.unstable_mockModule("@/components/Reusable/Table/MTable", () => ({
  __esModule: true,
  default: (props) => {
    latestTableProps = props;
    return (
      <div data-testid="mtable">
        <span data-testid="table-row-count">{props.tableData.length}</span>
        {props.filterMenu}
        {props.handleAdd && (
          <button
            type="button"
            data-testid="table-add-btn"
            onClick={props.handleAdd}
          >
            {props.AddText || "Add"}
          </button>
        )}
        {props.onRefreshClick && (
          <button
            type="button"
            data-testid="table-refresh-btn"
            onClick={props.onRefreshClick}
          >
            Refresh
          </button>
        )}
        {props.onExportClick && (
          <button
            type="button"
            data-testid="table-export-btn"
            onClick={props.onExportClick}
          >
            Export
          </button>
        )}
        {props.tableData.map((row, idx) => (
          <div key={row.id ?? idx} data-testid={`cert-row-${idx}`}>
            <span>{row.commonName}</span>
            {props.handleDownload && (
              <button
                type="button"
                data-testid={`row-download-${idx}`}
                onClick={() => props.handleDownload(row)}
              >
                Download Row
              </button>
            )}
            {props.handleDelete && (
              <button
                type="button"
                data-testid={`row-delete-${idx}`}
                onClick={() => props.handleDelete(row)}
              >
                Delete Row
              </button>
            )}
            {props.columns.map((col) =>
              col.render ? (
                <div key={col.uid} data-testid={`cell-${col.uid}-${idx}`}>
                  {col.render(row[col.uid], row)}
                </div>
              ) : null
            )}
          </div>
        ))}
      </div>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) =>
    props.open ? (
      <div data-testid="mdialog">
        <span>{props.title}</span>
        <span>{props.message}</span>
        <button
          type="button"
          data-testid="dialog-confirm"
          onClick={props.onConfirm}
        >
          Confirm
        </button>
        <button
          type="button"
          data-testid="dialog-cancel"
          onClick={props.onClose}
        >
          Cancel
        </button>
      </div>
    ) : null,
}));

jest.unstable_mockModule("@/assets/SVGIcons/Certificate_Download.svg", () => ({
  __esModule: true,
  default: "cert-dl.svg",
}));
jest.unstable_mockModule(
  "@/assets/SVGIcons/Certificate_Exporttomodem.svg",
  () => ({ __esModule: true, default: "cert-export.svg" })
);
jest.unstable_mockModule("@/assets/SVGIcons/Delete_Icon_.svg", () => ({
  __esModule: true,
  default: "delete-icon.svg",
}));

// The source component renders IconButton but does not import it.
// Provide a lightweight test-only global so its column renderers can execute
// without changing the application source.
globalThis.IconButton = ({ children, ...props }) =>
  React.createElement("button", props, children);

// Import only after all ESM mock registrations above.
const { CertAxios, ConfigurationAxios, InventAxios } = await import(
  "@/RestAPI/api/axiosApicall"
);
const {
  DELETE_CSR_URL,
  DOWNLOAD_FILE_FOR_GIVEN_ID_URL,
  DOWNLOAD_PACKAGE_CERT_URL,
  FETCH_CNMS_ADDRESS_DETAILS,
  GET_ALL_CERT,
  UPLOAD_CERT,
  UPLOAD_CERT_TO_MODEM,
  UPLOAD_PACKAGED_CRT_FILE_URL,
} = await import("@/RestAPI/url/endpoint");
const { default: Toast } = await import("@/components/Reusable/Toast/Toast");
const { useDispatch, useSelector } = await import("react-redux");
const { clearCertificateExportResponse } = await import(
  "@/store/features/X509Certificate/certificateExportSlice"
);
const { default: Xcertificate } = await import(
  "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/XCertificate/Xcerificate"
);

/* -------------------------------------------------------
   HELPERS & SAMPLE DATA
------------------------------------------------------- */

const daysFromNow = (offsetDays) => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString();
};

const sampleCertApiResponse = {
  certificateIssuedCount: 10,
  certficateExpiredCount: 2,
  certficateRequestedCount: 3,
  certifcateAboutExpireNext30DaysCount: 1,
  certifcateAboutExpireNext3MonthsCount: 4,
  certifcateAboutExpireNext6MonthsCount: 5,
  certifcateAboutExpireNext1YearCount: 6,
  certificateList: [
    {
      id: 1,
      terminal: "HUB-NMS",
      siteId: "SITE-1",
      commonName: "10.0.0.1",
      csrdate: "2025-01-01T10:00:00Z",
      certissuedate: "2025-01-02T10:00:00Z",
      certexpirydate: daysFromNow(15),
      modemAckStatus: null,
      modemAckDateTime: null,
      packagedcertFile: true,
      csr: "CSR_DATA_1",
      privateKey: "KEY_DATA_1",
    },
    {
      id: 2,
      terminal: "VSAT-MODEM",
      siteId: "SITE-2",
      commonName: "10.0.0.2",
      csrdate: "2024-01-01T10:00:00Z",
      certissuedate: "2024-01-02T10:00:00Z",
      certexpirydate: daysFromNow(-10),
      modemAckStatus: true,
      modemAckDateTime: "2024-01-03T12:00:00Z",
      packagedcertFile: false,
      packagedcertFileString: "PKG_STR",
    },
    {
      id: 3,
      terminal: "VSAT-MODEM",
      siteId: "SITE-3",
      commonName: "10.0.0.3",
      csrdate: "invalid-date",
      certissuedate: "",
      certexpirydate: daysFromNow(120),
      modemAckStatus: false,
      modemAckDateTime: "2025-02-01T08:00:00Z",
      packagedcertFile: false,
    },
  ],
};

const defaultStoreState = {
  certificateExport: { commandResponse: "" },
  nodeDetails: {
    repDetails: { id: 500 },
    siteDetails: { terminalTypeName: "VSAT" },
    isCnms: true,
  },
  userSlice: {
    userDetails: {
      data: { userName: "adminUser" },
    },
  },
};

const defaultProps = (overrides = {}) => ({
  privilegeKey: "CERT_PRIV",
  handleAdd: jest.fn(),
  handleEdit: jest.fn(),
  handleView: jest.fn(),
  refreshTrigger: 0,
  handleDelete: jest.fn(),
  isChildFullScreen: false,
  ...overrides,
});

const renderComponent = (props = {}, storeOverrides = {}, mode = "light") => {
  const mergedStore = {
    ...defaultStoreState,
    ...storeOverrides,
    nodeDetails: {
      ...defaultStoreState.nodeDetails,
      ...(storeOverrides.nodeDetails || {}),
    },
    userSlice: {
      ...defaultStoreState.userSlice,
      ...(storeOverrides.userSlice || {}),
    },
    certificateExport: {
      ...defaultStoreState.certificateExport,
      ...(storeOverrides.certificateExport || {}),
    },
  };

  useDispatch.mockReturnValue(mockDispatch);
  useSelector.mockImplementation((selector) => selector(mergedStore));

  const theme = createTheme({ palette: { mode } });

  return render(
    <ThemeProvider theme={theme}>
      <Xcertificate {...defaultProps(props)} />
    </ThemeProvider>
  );
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("Xcertificate Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestTableProps = undefined;

    if (!window.URL.createObjectURL) {
      window.URL.createObjectURL = jest.fn(() => "blob:mock-url");
    } else {
      jest.spyOn(window.URL, "createObjectURL").mockReturnValue("blob:mock-url");
    }

    if (!window.URL.revokeObjectURL) {
      window.URL.revokeObjectURL = jest.fn();
    } else {
      jest.spyOn(window.URL, "revokeObjectURL").mockImplementation(() => {});
    }

    InventAxios.mockResolvedValue({
      data: { address: "192.168.50.10" },
    });

    CertAxios.mockImplementation((url) => {
      if (url === GET_ALL_CERT) {
        return Promise.resolve({ data: sampleCertApiResponse });
      }
      if (url === DOWNLOAD_FILE_FOR_GIVEN_ID_URL) {
        return Promise.resolve({
          data: {
            csr: "CSR_CONTENT",
            privateKey: "KEY_CONTENT",
          },
        });
      }
      if (url.startsWith(DELETE_CSR_URL)) {
        return Promise.resolve({ data: { message: "Deleted successfully!" } });
      }
      return Promise.resolve({ data: { status: true, message: "OK" } });
    });

    ConfigurationAxios.mockResolvedValue({
      data: { statusCode: 1, status: "Exported" },
    });

    jest.spyOn(console, "log").mockImplementation(() => {});
    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIALIZATION, HOST FETCH & CERT FETCH
  ------------------------------------------------------- */

  describe("Initialization and certificate fetching", () => {
    it("clears certificate export response on mount and privilegeKey change", () => {
      const { rerender } = renderComponent({ privilegeKey: "KEY_1" });

      expect(clearCertificateExportResponse).toHaveBeenCalledTimes(1);
      expect(mockDispatch).toHaveBeenCalled();

      rerender(
        <ThemeProvider theme={createTheme()}>
          <Xcertificate {...defaultProps({ privilegeKey: "KEY_2" })} />
        </ThemeProvider>
      );

      expect(clearCertificateExportResponse).toHaveBeenCalledTimes(2);
    });

    it("shows spinner while loading certificates", () => {
      CertAxios.mockImplementationOnce(() => new Promise(() => {}));

      renderComponent();

      expect(screen.getByRole("progressbar")).toBeInTheDocument();
    });

    it("fetches CNMS address when not in CNMS mode and calls GET_ALL_CERT", async () => {
      renderComponent(
        {},
        {
          nodeDetails: {
            isCnms: false,
            repDetails: { id: 77 },
            siteDetails: { terminalTypeName: "RNMS" },
          },
        }
      );

      await waitFor(() => {
        expect(InventAxios).toHaveBeenCalledWith(
          FETCH_CNMS_ADDRESS_DETAILS,
          "get"
        );
      });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          GET_ALL_CERT,
          "post",
          { siteId: 77, terminal: "RNMS" },
          null,
          "192.168.50.10:9787"
        );
      });
    });

    it("keeps address intact when address already includes a port or fails to fetch", async () => {
      InventAxios.mockResolvedValueOnce({
        data: { address: "10.1.1.5:8443" },
      });

      const { unmount } = renderComponent(
        {},
        {
          nodeDetails: {
            isCnms: false,
            repDetails: { id: 88 },
            siteDetails: { terminalTypeName: "RNMS" },
          },
        }
      );

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          GET_ALL_CERT,
          "post",
          { siteId: 88, terminal: "RNMS" },
          null,
          "10.1.1.5:8443"
        );
      });
      unmount();

      InventAxios.mockRejectedValueOnce(new Error("Host fetch error"));
      renderComponent(
        {},
        {
          nodeDetails: {
            isCnms: false,
            repDetails: { id: 89 },
            siteDetails: { terminalTypeName: "RNMS" },
          },
        }
      );

      await waitFor(() => {
        expect(console.log).toHaveBeenCalled();
      });
    });

    it("handles GET_ALL_CERT error toast and empty list fallback", async () => {
      CertAxios.mockRejectedValueOnce(new Error("Cert fetch failed"));

      const { unmount } = renderComponent();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Cert fetch failed",
          "error"
        );
      });
      unmount();

      CertAxios.mockResolvedValueOnce({ data: {} });
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("0");
      });
    });
  });

  /* -------------------------------------------------------
     CNMS SUMMARY, TABS, FILTERING & DELETE
  ------------------------------------------------------- */

  describe("CNMS summary, tabs, filtering, and deletion", () => {
    it("renders CNMS summary counts, switches to ROOT Sub CA tab, and calls handleAdd", async () => {
      const props = defaultProps();
      renderComponent(props, {}, "dark");

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("3");
      });

      // Summary labels can also appear in the filter controls, so locate each
      // summary card by the label that has an h6 count beside it.
      const getSummaryCard = (label) => {
        const labelElement = screen
          .getAllByText(label)
          .find((element) => element.parentElement?.querySelector("h6"));
        expect(labelElement).toBeDefined();
        return labelElement.parentElement;
      };

      expect(getSummaryCard("Requested").querySelector("h6")).toHaveTextContent("3");
      expect(getSummaryCard("Issued").querySelector("h6")).toHaveTextContent("10");
      expect(getSummaryCard("Expired").querySelector("h6")).toHaveTextContent("2");

      fireEvent.click(screen.getByTestId("table-add-btn"));
      expect(props.handleAdd).toHaveBeenCalledWith({
        mode: "CREATE",
        title: "Add   Generate CSR Details",
      });

      fireEvent.click(screen.getByText("ROOT Sub CA"));
      expect(screen.getByTestId("upload-root-sub-ca")).toBeInTheDocument();

      fireEvent.click(screen.getByText("CSR"));
      expect(screen.getByTestId("mtable")).toBeInTheDocument();
    });

    it("filters certificates by expiry criteria and resets on refresh", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("3");
      });

      fireEvent.click(screen.getByTestId("filter-expired"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("1");

      fireEvent.click(screen.getByTestId("filter-issued"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");

      fireEvent.click(screen.getByTestId("filter-30"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("1");

      fireEvent.click(screen.getByTestId("filter-90"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("1");

      fireEvent.click(screen.getByTestId("filter-180"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");

      fireEvent.click(screen.getByTestId("filter-365"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");

      fireEvent.click(screen.getByTestId("filter-single"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("1");

      fireEvent.click(screen.getByTestId("filter-unknown"));
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("0");

      await act(async () => {
        fireEvent.click(screen.getByTestId("table-refresh-btn"));
      });

      await waitFor(() => {
        expect(screen.getByTestId("table-row-count")).toHaveTextContent("3");
      });
    });

    it("opens delete confirmation dialog, cancels, or confirms CSR deletion", async () => {
      renderComponent({ isChildFullScreen: true });

      await waitFor(() => {
        expect(screen.getByTestId("row-delete-0")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("row-delete-0"));
      expect(screen.getByTestId("mdialog")).toBeInTheDocument();

      fireEvent.click(screen.getByTestId("dialog-cancel"));
      expect(screen.queryByTestId("mdialog")).not.toBeInTheDocument();

      fireEvent.click(screen.getByTestId("row-delete-0"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          `${DELETE_CSR_URL}/1`,
          "post",
          null
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "Deleted successfully!",
        "success"
      );
      expect(screen.getByTestId("table-row-count")).toHaveTextContent("2");
    });

    it("shows delete failed toast when CSR deletion rejects", async () => {
      CertAxios.mockImplementation((url) => {
        if (url === GET_ALL_CERT) {
          return Promise.resolve({ data: sampleCertApiResponse });
        }
        if (url.startsWith(DELETE_CSR_URL)) {
          return Promise.reject(new Error("Delete denied"));
        }
        return Promise.resolve({ data: {} });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("row-delete-0")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("row-delete-0"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Delete Failed",
          "Delete denied",
          "error"
        );
      });
    });
  });

  /* -------------------------------------------------------
     DOWNLOAD MENU, CNMS UPLOAD & PACKAGING
  ------------------------------------------------------- */

  describe("Download menu, CNMS upload, and packaging", () => {
    it("opens download menu and triggers CSR and KEY downloads", async () => {
      const anchorClickSpy = jest
        .spyOn(HTMLAnchorElement.prototype, "click")
        .mockImplementation(() => {});

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("row-download-0")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("row-download-0"));

      await act(async () => {
        fireEvent.click(screen.getByRole("menuitem", { name: "CSR" }));
      });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          DOWNLOAD_FILE_FOR_GIVEN_ID_URL,
          "post",
          { id: 1, commonName: "10.0.0.1", downloadFileType: "CSR" }
        );
      });
      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "File downloaded successfully!",
        "success"
      );

      fireEvent.click(screen.getByTestId("row-download-0"));
      await act(async () => {
        fireEvent.click(screen.getByText("Private Key"));
      });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          DOWNLOAD_FILE_FOR_GIVEN_ID_URL,
          "post",
          { id: 1, commonName: "10.0.0.1", downloadFileType: "KEY" }
        );
      });

      anchorClickSpy.mockRestore();
    });

    it("uploads certificate file for a row and packages certificate on Generate click", async () => {
      const { container } = renderComponent();

      await waitFor(() => {
        expect(
          screen.getAllByTestId("cell-packagedcertFile-2").length
        ).toBeGreaterThan(0);
      });

      const fileInputs = container.querySelectorAll('input[type="file"]');
      const certFile = new File(["cert"], "device.crt", {
        type: "application/x-x509-ca-cert",
      });

      await act(async () => {
        fireEvent.change(fileInputs[2], { target: { files: [certFile] } });
      });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          UPLOAD_CERT,
          "post",
          expect.any(FormData)
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "Certificate File uploaded successfully!",
        "success"
      );

      const pkgCell = screen.getAllByTestId("cell-packageCertificate-2")[0];
      const pkgBtn = pkgCell.querySelector("button");

      await act(async () => {
        fireEvent.click(pkgBtn);
      });

      await waitFor(() => {
        expect(CertAxios).toHaveBeenCalledWith(
          UPLOAD_PACKAGED_CRT_FILE_URL,
          "post",
          expect.any(FormData)
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "Certificate packaged successfully!",
        "success"
      );
    });

    it("warns when packaging an unuploaded row and handles upload/package error messages", async () => {
      CertAxios.mockImplementation((url) => {
        if (url === GET_ALL_CERT) {
          return Promise.resolve({
            data: {
              ...sampleCertApiResponse,
              certificateList: [
                {
                  ...sampleCertApiResponse.certificateList[2],
                  packagedcertFile: false,
                  packagedcertFileString: "",
                },
              ],
            },
          });
        }
        if (url === UPLOAD_CERT) {
          return Promise.resolve({
            data: { errorMessage: "Cert rejected" },
          });
        }
        return Promise.resolve({ data: {} });
      });

      const { container } = renderComponent();

      await waitFor(() => {
        expect(
          screen.getAllByTestId("cell-packageCertificate-0").length
        ).toBeGreaterThan(0);
      });

      // The component disables Generate until the certificate is uploaded,
      // so the warning guard cannot be reached through a normal UI click.
      expect(
        screen.getAllByTestId("cell-packageCertificate-0")[0].querySelector("button")
      ).toBeDisabled();

      const fileInputs = container.querySelectorAll('input[type="file"]');
      await act(async () => {
        fireEvent.change(fileInputs[0], {
          target: { files: [new File(["x"], "a.crt")] },
        });
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Upload Failed",
          "Cert rejected",
          "error"
        );
      });
    });
  });

  /* -------------------------------------------------------
     NON-CNMS MODE & EXPORT TO MODEM
  ------------------------------------------------------- */

  describe("Non-CNMS mode and export to modem", () => {
    it("renders non-CNMS table, exports certificate to modem, and renders export output", async () => {
      const anchorClickSpy = jest
        .spyOn(HTMLAnchorElement.prototype, "click")
        .mockImplementation(() => {});

      renderComponent(
        {},
        {
          nodeDetails: {
            isCnms: false,
            repDetails: { id: 500 },
            siteDetails: { terminalTypeName: "VSAT" },
          },
          certificateExport: { commandResponse: "MODEM EXPORT LOG OUTPUT" },
        }
      );

      await waitFor(() => {
        expect(screen.getByTestId("table-export-btn")).toBeInTheDocument();
      });

      await act(async () => {
        fireEvent.click(screen.getByTestId("table-export-btn"));
      });

      await waitFor(() => {
        expect(ConfigurationAxios).toHaveBeenCalledWith(
          UPLOAD_CERT_TO_MODEM,
          "post",
          { timeout: 600000 },
          null
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "Exported",
        "success"
      );
      expect(
        screen.getByDisplayValue("MODEM EXPORT LOG OUTPUT")
      ).toBeInTheDocument();

      fireEvent.click(screen.getByText("Clear"));
      expect(clearCertificateExportResponse).toHaveBeenCalled();

      fireEvent.click(screen.getByTestId("row-download-0"));
      expect(Toast).toHaveBeenCalledWith(
        "Success",
        "File Downloaded Sucessfully!",
        "success"
      );

      anchorClickSpy.mockRestore();
    });

    it("handles export failure and exception toasts", async () => {
      ConfigurationAxios.mockResolvedValueOnce({
        data: { statusCode: 0, status: "Modem busy" },
      });

      const { unmount } = renderComponent(
        {},
        {
          nodeDetails: {
            isCnms: false,
            repDetails: { id: 500 },
            siteDetails: { terminalTypeName: "VSAT" },
          },
        }
      );

      await waitFor(() => {
        expect(screen.getByTestId("table-export-btn")).toBeInTheDocument();
      });

      await act(async () => {
        fireEvent.click(screen.getByTestId("table-export-btn"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Export Failed",
          "Modem busy",
          "error"
        );
      });
      unmount();

      ConfigurationAxios.mockRejectedValueOnce(new Error("Timeout"));

      renderComponent(
        {},
        {
          nodeDetails: {
            isCnms: false,
            repDetails: { id: 500 },
            siteDetails: { terminalTypeName: "VSAT" },
          },
        }
      );

      await waitFor(() => {
        expect(screen.getByTestId("table-export-btn")).toBeInTheDocument();
      });

      await act(async () => {
        fireEvent.click(screen.getByTestId("table-export-btn"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error",
          "Request failed or timed out",
          "error"
        );
      });
    });
  });
});
