import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import { jest } from "@jest/globals";

let GroupMgmtView;

let InventoryAxios;
let SecurityAxios;
let FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL;
let GET_ALL_PRIVILEGES;
let useSelector;

/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

await jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
  SecurityAxios: jest.fn(),
}));

await jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL: "/fetch-terminal-resources",
  GET_ALL_PRIVILEGES: "/get-all-privileges",
}));

await jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

let latestPrivilegeTreeProps;

await jest.unstable_mockModule("@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/PrivilegeTree", () => ({
  default: (props) => {
    latestPrivilegeTreeProps = props;
    return (
      <div data-testid="privilege-tree">
        <span data-testid="view-selected-privs">
          {JSON.stringify(props.selectedIds)}
        </span>
        <span data-testid="view-priv-count">{props.flatData.length}</span>
        <button
          type="button"
          data-testid="view-tree-noop-btn"
          onClick={() => {
            props.toggle(1);
            props.selectAll();
            props.onToggle(1);
            props.onSelectAll();
          }}
        >
          Trigger Noops
        </button>
      </div>
    );
  },
}));

let latestDeviceTableProps;

await jest.unstable_mockModule("@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/DevicePrivilegesTable", () => ({
  default: (props) => {
    latestDeviceTableProps = props;
    return (
      <div data-testid="device-privileges-table">
        <span data-testid="view-device-ids">
          {JSON.stringify(props.selectedDeviceIds)}
        </span>
        <span data-testid="view-type-caps">
          {JSON.stringify(props.selectedTypeCapabilities)}
        </span>
        <span data-testid="view-is-readonly">{String(props.isReadOnly)}</span>
        <button
          type="button"
          data-testid="view-table-noop-btn"
          onClick={() => {
            props.setSelectedDeviceIds([1]);
            props.setSelectedTypeCapabilities({});
          }}
        >
          Trigger Table Noops
        </button>
      </div>
    );
  },
}));

// Resolve mocked modules only after their native-ESM mocks have been registered.
({
  InventoryAxios,
  SecurityAxios,
} = await import("@/RestAPI/api/axiosApicall"));

({
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL,
  GET_ALL_PRIVILEGES,
} = await import("@/RestAPI/url/endpoint"));

({ useSelector } = await import("react-redux"));

GroupMgmtView = (
  await import("@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtView")
).default;

/* -------------------------------------------------------
   HELPERS & SAMPLE DATA
------------------------------------------------------- */

const sampleTerminalTypes = [
  { label: "CNMS Server", value: 1 },
  { label: "Kiosk", value: 2 },
  { terminalTypeName: "Edge Box", value: 3 },
];

const sampleAllGroups = [{ id: 10, groupName: "KioskGroup001" }];

const samplePrivileges = [
  { id: 1, name: "Read Group" },
  { id: 2, name: "Write Group" },
];

const sampleResources = [{ id: 901, name: "Switch" }];

const sampleViewData = {
  id: 25,
  terminalId: 2,
  privileges: [{ id: 1 }, { id: "bad" }],
  devicePrivileges: JSON.stringify({
    "901_inventory": true,
    "902_configuration": true,
    "903_add_delete": true,
    "904_fault": false,
    "905_status": true,
    "906_cross_launch": true,
    "907_unknown_cap": true,
    unmatched_key: true,
  }),
};

const renderComponent = (
  props = {},
  storeOverrides = {
    terminalTypes: { terminalTypes: sampleTerminalTypes },
    groups: { allGroups: sampleAllGroups },
  }
) => {
  useSelector.mockImplementation((selector) => selector(storeOverrides));
  return render(<GroupMgmtView {...props} />);
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("GroupMgmtView Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestPrivilegeTreeProps = undefined;
    latestDeviceTableProps = undefined;

    SecurityAxios.mockResolvedValue({
      status: 200,
      data: samplePrivileges,
    });

    InventoryAxios.mockResolvedValue({
      status: 200,
      data: sampleResources,
    });

    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIALIZATION & LOADING STATES
  ------------------------------------------------------- */

  describe("Initialization and loading states", () => {
    it("renders nothing when data or terminalId is missing", () => {
      const { container } = renderComponent({ data: null });
      expect(container.firstChild).toBeEmptyDOMElement();
      expect(SecurityAxios).not.toHaveBeenCalled();
      expect(InventoryAxios).not.toHaveBeenCalled();

      const { container: noTerminalContainer } = renderComponent({
        data: { id: 1, terminalId: null },
      });
      expect(noTerminalContainer.firstChild).toBeEmptyDOMElement();
    });

    it("shows a loading spinner while privileges or resources are loading", () => {
      SecurityAxios.mockImplementationOnce(() => new Promise(() => {}));
      InventoryAxios.mockImplementationOnce(() => new Promise(() => {}));

      renderComponent({ data: sampleViewData });

      expect(screen.getByRole("progressbar")).toBeInTheDocument();
    });

    it("loads privileges and resources and maps general and device privileges", async () => {
      renderComponent({ data: sampleViewData });

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(
          `${GET_ALL_PRIVILEGES}/2`,
          "get"
        );
        expect(InventoryAxios).toHaveBeenCalledWith(
          `${FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL}/2`,
          "get"
        );
      });

      expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      expect(screen.getByTestId("view-selected-privs")).toHaveTextContent(
        "[1]"
      );
      expect(screen.getByTestId("view-priv-count")).toHaveTextContent("2");
      expect(latestPrivilegeTreeProps.allSelected).toBe(false);
      expect(latestPrivilegeTreeProps.isReadOnly).toBe(false);

      // Safe noop callbacks should not throw
      fireEvent.click(screen.getByTestId("view-tree-noop-btn"));
    });

    it("supports object-shaped devicePrivileges and terminalTypeName/data fallbacks", async () => {
      renderComponent({
        data: {
          id: 30,
          terminalId: 3,
          privileges: null,
          devicePrivileges: {
            "910_configuration": true,
            "911_status": false,
          },
        },
      });

      await waitFor(() => {
        expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      });

      expect(screen.getByTestId("view-selected-privs")).toHaveTextContent("[]");

      fireEvent.click(screen.getByText("Device Privileges"));

      expect(screen.getByTestId("device-privileges-table")).toBeInTheDocument();
      expect(screen.getByTestId("view-device-ids")).toHaveTextContent("[910]");
      expect(screen.getByTestId("view-type-caps")).toHaveTextContent(
        '{"910_config":true,"911_status":false}'
      );
      expect(screen.getByTestId("view-is-readonly")).toHaveTextContent("true");

      fireEvent.click(screen.getByTestId("view-table-noop-btn"));
    });

    it("falls back to data.terminalName and data.terminalTypeName when not in store", async () => {
      const { unmount: unmountFirst } = renderComponent(
        {
          data: {
            id: 40,
            terminalId: 9,
            terminalName: "Fallback Terminal",
            privileges: [],
            devicePrivileges: "{}",
          },
        },
        { terminalTypes: null, groups: null }
      );

      await waitFor(() => {
        expect(screen.getByText("Device Privileges")).toBeInTheDocument();
      });

      // Remove the first instance before rendering the second fallback case.
      unmountFirst();

      renderComponent(
        {
          data: {
            id: 41,
            terminalId: 8,
            terminalTypeName: "CNMS Gateway",
            privileges: [],
            devicePrivileges: "{}",
          },
        },
        { terminalTypes: { terminalTypes: [] }, groups: { allGroups: [] } }
      );

      await waitFor(() => {
        expect(screen.getByText("General Privileges")).toBeInTheDocument();
      });

      expect(screen.queryByText("Device Privileges")).not.toBeInTheDocument();
    });

    it("handles malformed JSON in devicePrivileges gracefully", async () => {
      renderComponent({
        data: {
          ...sampleViewData,
          id: 55,
          devicePrivileges: "{bad-json",
        },
      });

      await waitFor(() => {
        expect(console.error).toHaveBeenCalledWith(
          "Error parsing devicePrivileges:",
          expect.any(SyntaxError)
        );
      });

      fireEvent.click(screen.getByText("Device Privileges"));
      expect(screen.getByTestId("view-device-ids")).toHaveTextContent("[]");
      expect(screen.getByTestId("view-type-caps")).toHaveTextContent("{}");
    });

    it("handles empty or failed privilege and resource responses", async () => {
      SecurityAxios.mockResolvedValueOnce({ status: 404, data: null });
      InventoryAxios.mockRejectedValueOnce(new Error("Resources error"));

      renderComponent({
        data: {
          id: 60,
          terminalId: 2,
          privileges: [],
          devicePrivileges: "{}",
        },
      });

      await waitFor(() => {
        expect(
          screen.getByText("No general privileges available.")
        ).toBeInTheDocument();
      });

      SecurityAxios.mockRejectedValueOnce(new Error("Privileges error"));
      InventoryAxios.mockResolvedValueOnce({ status: 204, data: null });

      renderComponent({
        data: {
          id: 61,
          terminalId: 2,
          privileges: [],
          devicePrivileges: "{}",
        },
      });

      await waitFor(() => {
        expect(console.error).toHaveBeenCalled();
      });
    });
  });

  /* -------------------------------------------------------
     TABS & CNMS BEHAVIOR
  ------------------------------------------------------- */

  describe("Tab switching and CNMS terminals", () => {
    it("switches between General Privileges and Device Privileges tabs", async () => {
      renderComponent({ data: sampleViewData });

      await waitFor(() => {
        expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByText("Device Privileges"));
      expect(screen.getByTestId("device-privileges-table")).toBeInTheDocument();
      expect(screen.queryByTestId("privilege-tree")).not.toBeInTheDocument();
      expect(latestDeviceTableProps.allGroups).toEqual(sampleAllGroups);

      fireEvent.click(screen.getByText("General Privileges"));
      expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      expect(
        screen.queryByTestId("device-privileges-table")
      ).not.toBeInTheDocument();
    });

    it("hides Device Privileges tab for terminal ID 1 (CNMS)", async () => {
      renderComponent({
        data: {
          id: 70,
          terminalId: 1,
          privileges: [{ id: 1 }],
          devicePrivileges: "{}",
        },
      });

      await waitFor(() => {
        expect(screen.getByTestId("privilege-tree")).toBeInTheDocument();
      });

      expect(screen.queryByText("Device Privileges")).not.toBeInTheDocument();
    });
  });
});
