import cnmsReducer, {
  setMountAbuDetails, setKasauliDetails, setRepresentatives,
  clearCnmsData, setLoading, setSavedRnmsDetails,
} from '../../src/store/features/Cnms/cnmsSlice';
import cnmsStatusReducer, {
  setHealthStatus, setCnmsLinkAvailable,
} from '../../src/store/features/LinkStatus/cnmsStatusSlice';
import terminalReducer, {
  setRnmsterminaltypesData, clearRnmsterminaltypesData,
} from '../../src/store/features/Cnms/remoteRepDetails/rnmsTerminalTypes';
import certificateReducer, {
  setCertificateExportResponse, clearCertificateExportResponse,
} from '../../src/store/features/X509Certificate/certificateExportSlice';
import nodeDetailsReducer, {
  setDeployedSiteDetails, setRepDetails, setSavedRnmsDetails as setNodeSavedRnmsDetails,
  setIsCnms, updateCnmsDetailsFromSidebar, setAllTerminalTypeDetails, updateRnmsLatLong,
} from '../../src/store/features/nodeDetailsSlice';
import delayReducer, {
  initDelayAndResponseChart, addDelayAndResponseChartPoint,
  clearDelayAndResponseChartData, setSubscribeToDelayAndResponsetSocket,
} from '../../src/store/features/Reports/PerformanceReports/delayAndResponseSlice';
import systemReducer, {
  initRealTimeChart, addRealtimeChartPoint, clearRealtimeChartData,
  setSubscribeToRealtimeReportSocket,
} from '../../src/store/features/Reports/PerformanceReports/realTimeSystemSlice';
import interfaceReducer, {
  initRealTimeInterfaceLevelChart, addRealtimeInterfaceLevelChartPoint,
  clearRealtimeInterfaceLevelChartData, setSubscribeToRealtimeInterfaceLevelReportSocket,
} from '../../src/store/features/Reports/PerformanceReports/realTimeInterfaceLevelSlice';

const silenceLogs = () => {
  jest.spyOn(console, 'log').mockImplementation(() => {});
};

beforeEach(() => silenceLogs());

describe('CNMS configuration slice', () => {
  test('updates site details, representatives and loading state, then clears the form', () => {
    let state = cnmsReducer(undefined, { type: '@@init' });
    expect(state).toMatchObject({ mountAbu: null, kasauli: null, loading: false, savedData: null });
    state = cnmsReducer(state, setMountAbuDetails({ id: 1 }));
    state = cnmsReducer(state, setKasauliDetails({ id: 2 }));
    state = cnmsReducer(state, setRepresentatives({ mountAbu: [{ id: 3 }], kasauli: [] }));
    state = cnmsReducer(state, setLoading(true));
    expect(state).toMatchObject({ mountAbu: { id: 1 }, kasauli: { id: 2 }, loading: true });
    state = cnmsReducer(state, clearCnmsData());
    expect(state).toMatchObject({ mountAbu: null, kasauli: null, representatives: { mountAbu: [], kasauli: [] } });
  });

  test('saves final RNMS details and resets temporary form data', () => {
    let state = cnmsReducer(undefined, setMountAbuDetails({ id: 1 }));
    state = cnmsReducer(state, setSavedRnmsDetails({ saved: true }));
    expect(state.savedData).toEqual({ saved: true });
    expect(state.mountAbu).toBeNull();
    expect(state.kasauli).toBeNull();
    expect(state.representatives).toEqual({ mountAbu: [], kasauli: [] });
  });
});

describe('CNMS status and terminal type slices', () => {
  test('tracks health timestamp and link availability', () => {
    let state = cnmsStatusReducer(undefined, { type: '@@init' });
    expect(state).toMatchObject({ healthStatus: 3, lastUpdateTime: null, cnmsLinkAvailable: false });
    state = cnmsStatusReducer(state, setHealthStatus({ status: 1, timestamp: '2026-11-22T10:00:00Z' }));
    state = cnmsStatusReducer(state, setCnmsLinkAvailable(true));
    expect(state).toMatchObject({ healthStatus: 1, lastUpdateTime: '2026-11-22T10:00:00Z', cnmsLinkAvailable: true });
  });

  test('sets and clears RNMS terminal type records', () => {
    let state = terminalReducer(undefined, setRnmsterminaltypesData([{ id: 1 }, { id: 2 }]));
    expect(state.rnmsterminaltypesData).toHaveLength(2);
    state = terminalReducer(state, clearRnmsterminaltypesData());
    expect(state.rnmsterminaltypesData).toEqual([]);
  });
});

describe('certificate export response slice', () => {
  test('stores a response, normalizes empty values and clears it', () => {
    let state = certificateReducer(undefined, setCertificateExportResponse('OK'));
    expect(state.commandResponse).toBe('OK');
    state = certificateReducer(state, setCertificateExportResponse(null));
    expect(state.commandResponse).toBe('');
    state = certificateReducer(state, setCertificateExportResponse('ERROR'));
    state = certificateReducer(state, clearCertificateExportResponse());
    expect(state.commandResponse).toBe('');
  });
});

describe('node details slice', () => {
  test('sets node details, updates matching sidebar records and ignores non-array updates', () => {
    let state = nodeDetailsReducer(undefined, setRepDetails([{ id: 1, name: 'old' }, { id: 2, name: 'keep' }]));
    state = nodeDetailsReducer(state, setDeployedSiteDetails({ siteId: 9 }));
    state = nodeDetailsReducer(state, setNodeSavedRnmsDetails({ saved: true }));
    state = nodeDetailsReducer(state, setIsCnms(true));
    state = nodeDetailsReducer(state, setAllTerminalTypeDetails([{ id: 'T1' }]));
    state = nodeDetailsReducer(state, updateCnmsDetailsFromSidebar([{ id: 1, name: 'new', status: 'up' }, { id: 3, name: 'not-added' }]));
    expect(state.repDetails).toEqual([{ id: 1, name: 'new', status: 'up' }, { id: 2, name: 'keep' }]);
    expect(state.siteDetails).toEqual({ siteId: 9 });
    expect(state.savedRnmsDetails).toEqual({ saved: true });
    expect(state.isCnms).toBe(true);
    expect(state.allTerminalTypeDetails).toEqual([{ id: 'T1' }]);
    state = nodeDetailsReducer(state, updateCnmsDetailsFromSidebar({ id: 1, name: 'ignored' }));
    expect(state.repDetails[0].name).toBe('new');
  });

  test('updates coordinates only when representative details exist', () => {
    let state = nodeDetailsReducer(undefined, updateRnmsLatLong({ latitude: 1, longitude: 2 }));
    expect(state.repDetails).toBeNull();
    state = nodeDetailsReducer(state, setRepDetails({ id: 4, latitude: 0, longitude: 0 }));
    state = nodeDetailsReducer(state, updateRnmsLatLong({ latitude: 12.5, longitude: 77.6 }));
    expect(state.repDetails).toMatchObject({ latitude: 12.5, longitude: 77.6 });
  });
});

const point = (minute, data = 1) => ({ date: `2026-01-01T00:${String(minute).padStart(2, '0')}:00.000Z`, data });

describe('delay and response chart slice', () => {
  test('initializes with a point and a valid window, with fallback for invalid window', () => {
    let state = delayReducer(undefined, initDelayAndResponseChart({ initialPoint: point(0), windowMinutes: '5' }));
    expect(state.delayAndResponseActiveWindowMinutes).toBe(5);
    expect(state.delayAndResponseChartData).toEqual([point(0)]);
    state = delayReducer(state, initDelayAndResponseChart({ initialPoint: null, windowMinutes: 'bad' }));
    expect(state.delayAndResponseActiveWindowMinutes).toBe(1);
    expect(state.delayAndResponseChartData).toEqual([]);
  });

  test('appends streaming points, evicts an expired oldest point, manages subscription and clears', () => {
    let state = delayReducer(undefined, initDelayAndResponseChart({ initialPoint: point(0), windowMinutes: 1 }));
    state = delayReducer(state, addDelayAndResponseChartPoint(point(2)));
    expect(state.delayAndResponseChartData).toEqual([point(2)]);
    state = delayReducer(state, setSubscribeToDelayAndResponsetSocket({ subscribe: true, resourceId: 'R1' }));
    expect(state).toMatchObject({ subscribeToDelayAndResponseSocket: true, currentDelayAndResponseResource: 'R1' });
    state = delayReducer(state, clearDelayAndResponseChartData());
    expect(state.delayAndResponseChartData).toEqual([]);
  });
});
test('real-time system chart initializes and processes streaming points', () => {
  let state = systemReducer(
    undefined,
    initRealTimeChart({
      initialPoint: null,
      windowMinutes: '2',
    })
  );

  expect(state.realtimeChartData).toEqual([]);

  state = systemReducer(
    state,
    addRealtimeChartPoint(point(2, '3'))
  );

  state = systemReducer(
    state,
    addRealtimeChartPoint(point(1, '4'))
  );

expect(state.realtimeChartData.map((p) => p.data)).toEqual([4, 3]);

  state = systemReducer(
    state,
    addRealtimeChartPoint(point(5, '5'))
  );

  expect(state.realtimeChartData.map((p) => p.data)).toEqual([5]);
});

describe('real-time system chart slice', () => {
  test('initializes, rejects invalid packets, normalizes, sorts, deduplicates and trims the time window', () => {
    let state = systemReducer(undefined, initRealTimeChart({ initialPoint: point(0, '1'), windowMinutes: '2' }));
    state = systemReducer(state, addRealtimeChartPoint({ data: 2 }));
    state = systemReducer(state, addRealtimeChartPoint({ date: 'invalid', data: 2 }));
    state = systemReducer(state, addRealtimeChartPoint({ date: point(1).date, data: 'not-number' }));
    expect(state.realtimeChartData).toHaveLength(1);
    state = systemReducer(state, addRealtimeChartPoint(point(2, '3')));
    state = systemReducer(state, addRealtimeChartPoint(point(1, '4')));
expect(state.realtimeChartData.map((p) => p.data)).toEqual(['1', 4, 3]);
    state = systemReducer(state, addRealtimeChartPoint(point(5, '5')));
    expect(state.realtimeChartData).toEqual([point(5, 5)]);
    state = systemReducer(state, setSubscribeToRealtimeReportSocket({ subscribe: true, resourceId: 'R2', paramId: 'P1' }));
    expect(state).toMatchObject({ subscribeToRealtimeReportSocket: true, realTimeCurrentDevice: 'R2', realTimeCurrentParamId: 'P1' });
    state = systemReducer(state, clearRealtimeChartData());
    expect(state.realtimeChartData).toEqual([]);
  });
});

describe('real-time interface chart slice', () => {
  test('validates packets, replaces duplicate timestamps, orders points and trims old data', () => {
    let state = interfaceReducer(undefined, initRealTimeInterfaceLevelChart({ initialPoint: point(0), windowMinutes: '2' }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({}));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: 'bad', data: 2 }));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint({ date: point(1).date, data: 'bad' }));
    expect(state.realtimeInterfaceLevelChartData).toHaveLength(1);
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint(point(2, '3')));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint(point(1, '4')));
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint(point(1, '7')));
    expect(state.realtimeInterfaceLevelChartData.map((p) => p.data)).toEqual([1, 7, 3]);
    state = interfaceReducer(state, addRealtimeInterfaceLevelChartPoint(point(5, '8')));
    expect(state.realtimeInterfaceLevelChartData).toEqual([point(5, 8)]);
    state = interfaceReducer(state, setSubscribeToRealtimeInterfaceLevelReportSocket({ subscribe: true, resourceId: 'R3', paramId: 'P2', portId: '9' }));
    expect(state).toMatchObject({ subscribeToRealtimeInterfaceLevelReportSocket: true, currentRealtimeInterfaceResource: 'R3', currentRealtimeInterfaceParamId: 'P2', currentRealtimeInterfacePortId: '9' });
    state = interfaceReducer(state, clearRealtimeInterfaceLevelChartData());
    expect(state.realtimeInterfaceLevelChartData).toEqual([]);
  });
});
