import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
  cleanup,
} from "@testing-library/react";
import "@testing-library/jest-dom";
import { jest } from "@jest/globals";

const fabricInstances = [];

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn((selector) =>
    selector({
      toolTipOptionsSlice: {
        topologyToolTipOptions: {
          remoteType: true,
          vehNumber: true,
          longitude: true,
          latitude: true,
          status: true,
          activeLink: true,
          remoteId: true,
          maintainance: true,
          siteName: true,
          vehRunTime: true,
        },
      },
    })
  ),
}));

jest.unstable_mockModule("@mui/material", () => ({
  CircularProgress: () => <div data-testid="loading" />,
  IconButton: ({ children, onClick, ...props }) => (
    <button onClick={onClick} {...props}>
      {children}
    </button>
  ),
  Tooltip: ({ title, children }) =>
    React.cloneElement(children, { title }),
  useTheme: () => ({
    palette: {
      mode: "light",
    },
  }),
}));

// Use the same @/assets paths that resolve the component's imports.
jest.unstable_mockModule(
  "../../src/assets/CNMS/birdEyeViewLegend/E1OFC.svg",
  () => ({ default: "e1.svg" }),
  { virtual: true }
);
jest.unstable_mockModule(
  "../../src/assets/CNMS/birdEyeViewLegend/NOTCONFIGURE.svg",
  () => ({ default: "notconfigure.svg" }),
  { virtual: true }
);
jest.unstable_mockModule(
  "../../src/assets/CNMS/birdEyeViewLegend/radio.svg",
  () => ({ default: "radio.svg" }),
  { virtual: true }
);
jest.unstable_mockModule(
  "../../src/assets/CNMS/birdEyeViewLegend/VSat.svg",
  () => ({ default: "vsat.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/rhombus.svg",
  () => ({ default: "rhombus.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/star.svg",
  () => ({ default: "star.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/mctr.svg",
  () => ({ default: "doctor.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/hexa.svg",
  () => ({ default: "hexa.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/triangle.svg",
  () => ({ default: "triangle.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/octa.svg",
  () => ({ default: "octa.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "../../src/assets/CNMS/pictorialView/square.svg",
  () => ({ default: "square.svg" }),
  { virtual: true }
);

jest.unstable_mockModule(
  "@/Pages/CnmsDashboard/BirdEyeView/SettingsFormPictorial",
  () => ({
    default: () => <div data-testid="settings-form">Settings Form</div>,
  })
);

jest.unstable_mockModule("fabric", () => {
  class MockCanvas {
    constructor(element, options) {
      this.element = element;
      this.options = options;
      this.objects = [];
      this.events = {};
      this.viewportTransform = [1, 0, 0, 1, 0, 0];
      this.width = 1000;
      this.height = 600;
      this.isDragging = false;
      fabricInstances.push(this);
    }

    on(event, callback) {
      // Fabric supports multiple listeners for the same event.
      // PictorialView registers site selection and dragging on mouse:down.
      const previous = this.events[event];

      if (!previous) {
        this.events[event] = callback;
        return;
      }

      this.events[event] = (payload) => {
        previous(payload);
        callback(payload);
      };
    }

    add(object) {
      this.objects.push(object);
    }

    clear() {
      this.objects = [];
    }

    getObjects() {
      return this.objects;
    }

    getZoom() {
      return this.viewportTransform[0];
    }

    zoomToPoint(point, zoom) {
      this.lastZoom = { point, zoom };
    }

    setViewportTransform(transform) {
      this.viewportTransform = transform;
    }

    requestRenderAll() {}
    renderAll() {}

    setDimensions = jest.fn((dimensions) => {
      this.width = dimensions.width;
      this.height = dimensions.height;
    });

    dispose() {
      this.disposed = true;
    }
  }

  class MockGroup {
    constructor(objects, options) {
      this.objects = objects;
      Object.assign(this, options);
    }

    getBoundingRect() {
      const left = Number(this.left ?? 0);
      const top = Number(this.top ?? 0);
      const width = Number(this.width ?? 350);
      const height = Number(this.height ?? 100);

      return { left, top, width, height };
    }
  }

  class MockLine {
    constructor(points, options) {
      this.points = points;
      Object.assign(this, options);
    }

    getBoundingRect() {
      return { left: 0, top: 0, width: 36, height: 3 };
    }
  }

  class MockRect {
    constructor(options) {
      Object.assign(this, options);
    }

    getBoundingRect() {
      return {
        left: this.left || 0,
        top: this.top || 0,
        width: this.width || 10,
        height: this.height || 10,
      };
    }
  }

  class MockText {
    constructor(text, options) {
      this.text = text;
      Object.assign(this, options);
    }
  }

  class MockFabricImage {
    constructor() {
      this.width = 25;
      this.height = 25;
    }

    set(options) {
      Object.assign(this, options);
    }

    getBoundingRect() {
      const scaleX = Number(this.scaleX ?? 1);
      const scaleY = Number(this.scaleY ?? 1);

      return {
        left: Number(this.left ?? 0),
        top: Number(this.top ?? 0),
        width: this.width * scaleX,
        height: this.height * scaleY,
      };
    }

    static async fromURL() {
      return new MockFabricImage();
    }
  }

  return {
    Canvas: MockCanvas,
    Group: MockGroup,
    Line: MockLine,
    Rect: MockRect,
    Text: MockText,
    FabricImage: MockFabricImage,
  };
});

// Import the component only after all ESM mocks are registered.
const { default: PictorialView } = await import(
  "@/Pages/CnmsDashboard/BirdEyeView/PictorialView"
);

// --------------------------------------------------
// Global browser mocks
// --------------------------------------------------

beforeAll(() => {
  Object.defineProperty(HTMLElement.prototype, "clientWidth", {
    configurable: true,
    get() {
      return this.tagName === "DIV" ? 1000 : 0;
    },
  });

  Object.defineProperty(HTMLElement.prototype, "clientHeight", {
    configurable: true,
    get() {
      return this.tagName === "DIV" ? 600 : 0;
    },
  });

  global.ResizeObserver = class {
    constructor(callback) {
      this.callback = callback;
    }

    observe() {
      this.callback?.();
    }

    disconnect() {}
  };

  global.requestAnimationFrame = (callback) =>
    setTimeout(() => callback(0), 0);

  global.cancelAnimationFrame = (id) => clearTimeout(id);

  global.fetch = jest.fn().mockResolvedValue({
    ok: true,
    status: 200,
    text: async () => '<svg fill="#000" stroke="#000"></svg>',
  });
});

beforeEach(() => {
  fabricInstances.length = 0;
  jest.clearAllMocks();
});

afterEach(() => {
  cleanup();
});

// --------------------------------------------------
// Test data
// --------------------------------------------------

const createSite = (overrides = {}) => ({
  siteId: 101,
  siteName: "Test Site",
  remoteNumber: 123,
  longitude: 72.8,
  latitude: 19.0,

  healthStatus: {
    id: 1,
    value: "UP",
  },

  maintenanceType: 1,
  isMaintainance: false,

  imTerminalType: {
    terminalTypeName: "DMRR",
    subTypeName: "Test Terminal",
  },

  imTerminalMode: {
    name: "LOCAL",
  },

  activeModeOfCommunication: 1,

  sysUpTime: "10 hours",

  ...overrides,
});

const renderComponent = (sites = []) =>
  render(
    <div style={{ width: 1000, height: 600 }}>
      <PictorialView
        sitesToDisplay={sites}
        setSelectedPath={jest.fn()}
      />
    </div>
  );

const getCanvas = () => fabricInstances[0];

// --------------------------------------------------
// Component rendering
// --------------------------------------------------

describe("PictorialView rendering", () => {
  test("renders component successfully", () => {
    renderComponent();

    expect(document.querySelector("canvas")).toBeInTheDocument();
  });

  test("renders terminal legend empty message", () => {
    renderComponent([]);

    expect(screen.getByText("No terminals available")).toBeInTheDocument();
  });

  test("renders terminal legend for configured sites", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(screen.getByText("DMRR")).toBeInTheDocument();
    });
  });

  test("renders site status legend", () => {
    renderComponent();

    expect(screen.getByText("Site Status")).toBeInTheDocument();
    expect(screen.getByText("Online")).toBeInTheDocument();
    expect(screen.getByText("Offline")).toBeInTheDocument();
    expect(screen.getByText("RNMS Down")).toBeInTheDocument();
    expect(screen.getByText("Maintenance Non-OPS")).toBeInTheDocument();
    expect(screen.getByText("Maintenance R-OPS")).toBeInTheDocument();
  });

  test("renders communication legend", () => {
    renderComponent();

    expect(screen.getByText("Radio")).toBeInTheDocument();
    expect(screen.getByText("V-SAT")).toBeInTheDocument();
    expect(screen.getByText("E1-OFC")).toBeInTheDocument();
    expect(screen.getByText("Not Configured")).toBeInTheDocument();
  });
});

// --------------------------------------------------
// Fabric initialization
// --------------------------------------------------

describe("Fabric initialization", () => {
  test("initializes canvas with correct configuration", () => {
    renderComponent();

    expect(getCanvas()).toBeDefined();

    expect(getCanvas().options).toEqual(
      expect.objectContaining({
        selection: false,
        preserveObjectStacking: true,
        stopContextMenu: true,
        fireRightClick: true,
      })
    );
  });

  test("registers canvas events", () => {
    renderComponent();

    const canvas = getCanvas();

    expect(canvas.events["mouse:over"]).toBeDefined();
    expect(canvas.events["mouse:out"]).toBeDefined();
    expect(canvas.events["mouse:down"]).toBeDefined();
    expect(canvas.events["mouse:wheel"]).toBeDefined();
    expect(canvas.events["mouse:move"]).toBeDefined();
    expect(canvas.events["mouse:up"]).toBeDefined();
  });

  test("disposes canvas on unmount", () => {
    const { unmount } = renderComponent();

    const canvas = getCanvas();

    unmount();

    expect(canvas.disposed).toBe(true);
  });
});

// --------------------------------------------------
// SVG loading
// --------------------------------------------------

describe("SVG loading", () => {
  test("loads SVG successfully", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalled();
    });

    expect(global.fetch).toHaveBeenCalledWith("rhombus.svg");
  });

  test("handles failed SVG response", async () => {
    global.fetch.mockResolvedValueOnce({
      ok: false,
      status: 404,
    });

    const consoleSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    renderComponent([createSite()]);

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalled();
    });

    consoleSpy.mockRestore();
  });

  test("handles rejected SVG fetch", async () => {
    global.fetch.mockRejectedValueOnce(new Error("Network error"));

    const consoleSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    renderComponent([createSite()]);

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalled();
    });

    consoleSpy.mockRestore();
  });

  test("handles missing terminal type", async () => {
    renderComponent([
      createSite({
        imTerminalType: null,
      }),
    ]);

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith("notconfigure.svg");
    });
  });
});

// --------------------------------------------------
// Site rendering
// --------------------------------------------------

describe("Site rendering", () => {
  test("renders independent LOCAL site", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData)
      ).toBe(true);
    });
  });

  test("renders connected LOCAL site with remote site", async () => {
    const local = createSite({
      remoteSite: createSite({
        siteId: 202,
        imTerminalMode: { name: "REMOTE" },
      }),
    });

    renderComponent([local]);

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData?.siteId === 202)
      ).toBe(true);
    });
  });

  test("renders connected LOCAL site with repeater 1", async () => {
    renderComponent([
      createSite({
        repeator1Site: createSite({ siteId: 201 }),
      }),
    ]);

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData?.siteId === 201)
      ).toBe(true);
    });
  });

  test("renders connected LOCAL site with repeater 2", async () => {
    renderComponent([
      createSite({
        repeator2Site: createSite({ siteId: 202 }),
      }),
    ]);

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData?.siteId === 202)
      ).toBe(true);
    });
  });

  test("renders multiple independent sites", async () => {
    renderComponent([
      createSite({ siteId: 1 }),
      createSite({ siteId: 2 }),
      createSite({ siteId: 3 }),
      createSite({ siteId: 4 }),
      createSite({ siteId: 5 }),
    ]);

    await waitFor(() => {
      const siteObjects = getCanvas().objects.filter(
        (object) => object.siteData
      );

      expect(siteObjects.length).toBe(5);
    });
  });

  test("renders unknown terminal type using fallback icon", async () => {
    renderComponent([
      createSite({
        imTerminalType: {
          terminalTypeName: "UNKNOWN_TERMINAL",
        },
      }),
    ]);

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith("notconfigure.svg");
    });
  });
});

// --------------------------------------------------
// Canvas interactions
// --------------------------------------------------

describe("Canvas interactions", () => {
  test("fits canvas to available content", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(getCanvas().objects.length).toBeGreaterThan(0);
    });

    await act(async () => {
      fireEvent.click(screen.getByTitle("Fit to Zoom"));
    });

    expect(getCanvas().viewportTransform).toBeDefined();
  });

  test("zooms canvas on mouse wheel", () => {
    renderComponent();

    const canvas = getCanvas();

    const preventDefault = jest.fn();
    const stopPropagation = jest.fn();

    act(() => {
      canvas.events["mouse:wheel"]({
        e: {
          deltaY: -100,
          offsetX: 100,
          offsetY: 100,
          preventDefault,
          stopPropagation,
        },
      });
    });

    expect(canvas.lastZoom.zoom).toBeGreaterThan(1);
    expect(preventDefault).toHaveBeenCalled();
    expect(stopPropagation).toHaveBeenCalled();
  });

  test("handles zoom out", () => {
    renderComponent();

    const canvas = getCanvas();

    act(() => {
      canvas.events["mouse:wheel"]({
        e: {
          deltaY: 100,
          offsetX: 100,
          offsetY: 100,
          preventDefault: jest.fn(),
          stopPropagation: jest.fn(),
        },
      });
    });

    expect(canvas.lastZoom.zoom).toBeLessThan(1);
  });

  test("starts and completes canvas dragging", () => {
    renderComponent();

    const canvas = getCanvas();

    act(() => {
      canvas.events["mouse:down"]({
        target: null,
        e: {
          clientX: 100,
          clientY: 100,
        },
      });
    });

    expect(canvas.isDragging).toBe(true);

    act(() => {
      canvas.events["mouse:move"]({
        e: {
          clientX: 150,
          clientY: 150,
        },
      });
    });

    expect(canvas.viewportTransform[4]).toBe(50);
    expect(canvas.viewportTransform[5]).toBe(50);

    act(() => {
      canvas.events["mouse:up"]();
    });

    expect(canvas.isDragging).toBe(false);
  });
});

// --------------------------------------------------
// Site interactions
// --------------------------------------------------

describe("Site interactions", () => {
  test("selects site on canvas click", async () => {
    const setSelectedPath = jest.fn();

    render(
      <PictorialView
        sitesToDisplay={[createSite()]}
        setSelectedPath={setSelectedPath}
      />
    );

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData)
      ).toBe(true);
    });

    const siteObject = getCanvas().objects.find(
      (object) => object.siteData
    );

    act(() => {
      getCanvas().events["mouse:down"]({
        target: siteObject,
      });
    });

    expect(setSelectedPath).toHaveBeenCalledWith("CNMS/101");
  });

  test("shows tooltip when hovering over site", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData)
      ).toBe(true);
    });

    const siteObject = getCanvas().objects.find(
      (object) => object.siteData
    );

    act(() => {
      getCanvas().events["mouse:over"]({
        target: siteObject,
        e: {
          offsetX: 100,
          offsetY: 120,
        },
      });
    });

    expect(await screen.findByText(/Remote Type:/)).toBeInTheDocument();
    expect(screen.getByText(/Veh\. Number:/)).toBeInTheDocument();
    expect(screen.getByText(/Longitude:/)).toBeInTheDocument();
    expect(screen.getByText(/Latitude:/)).toBeInTheDocument();
    expect(screen.getByText(/Site Name:/)).toBeInTheDocument();
  });

  test("hides tooltip on mouse out", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(
        getCanvas().objects.some((object) => object.siteData)
      ).toBe(true);
    });

    const siteObject = getCanvas().objects.find(
      (object) => object.siteData
    );

    act(() => {
      getCanvas().events["mouse:over"]({
        target: siteObject,
        e: {
          offsetX: 10,
          offsetY: 10,
        },
      });
    });

    act(() => {
      getCanvas().events["mouse:out"]({
        target: siteObject,
      });
    });

    expect(screen.queryByText(/Remote Type:/)).not.toBeInTheDocument();
  });

  test("does not display tooltip when no fields are enabled", () => {
    renderComponent([createSite()]);

    expect(screen.queryByText(/Remote Type:/)).not.toBeInTheDocument();
  });
});

// --------------------------------------------------
// Settings panel
// --------------------------------------------------

describe("Settings panel", () => {
  test("opens settings panel", () => {
    renderComponent();

    fireEvent.click(
      screen.getByTitle("Configuration Parameters")
    );

    expect(screen.getByTestId("settings-form")).toBeInTheDocument();
  });

  test("closes settings panel when clicked again", () => {
    renderComponent();

    const settingsButton = screen.getByTitle(
      "Configuration Parameters"
    );

    fireEvent.click(settingsButton);

    expect(screen.getByTestId("settings-form")).toBeInTheDocument();

    fireEvent.click(settingsButton);

    expect(screen.queryByTestId("settings-form")).not.toBeInTheDocument();
  });
});

// --------------------------------------------------
// Site status variations
// --------------------------------------------------

describe("Site status variations", () => {
  test.each([
    [0, false, 1],
    [1, false, 1],
    [2, false, 1],
    [3, false, 1],
    [3, false, 2],
    [3, false, 3],
    [null, true, 1],
    [null, true, 2],
    [null, true, 3],
    [null, false, null],
  ])(
    "renders site with health status %s and maintenance %s",
    async (statusId, isMaintainance, maintenanceType) => {
      renderComponent([
        createSite({
          healthStatus: statusId == null ? null : { id: statusId },
          isMaintainance,
          maintenanceType,
        }),
      ]);

      await waitFor(() => {
        expect(
          getCanvas().objects.some((object) => object.siteData)
        ).toBe(true);
      });
    }
  );
});

// --------------------------------------------------
// Communication modes
// --------------------------------------------------

describe("Communication modes", () => {
  test.each([1, 2, 3, null, "", 0, 4])(
    "handles communication mode %s",
    async (mode) => {
      renderComponent([
        createSite({
          activeModeOfCommunication: mode,
        }),
      ]);

      await waitFor(() => {
        expect(getCanvas()).toBeDefined();
      });
    }
  );
});

// --------------------------------------------------
// Resize and cleanup
// --------------------------------------------------

describe("Resize handling", () => {
  test("updates canvas dimensions", async () => {
    renderComponent([createSite()]);

    await waitFor(() => {
      expect(getCanvas().setDimensions).toHaveBeenCalled();
    });
  });

  test("cleans up component on unmount", () => {
    const { unmount } = renderComponent();

    const canvas = getCanvas();

    unmount();

    expect(canvas.disposed).toBe(true);
  });
});

// --------------------------------------------------
// Error handling
// --------------------------------------------------

describe("Drawing error handling", () => {
  test("handles SVG loading failure without crashing", async () => {
    global.fetch.mockRejectedValueOnce(new Error("SVG failed"));

    const consoleSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    expect(() => renderComponent([createSite()])).not.toThrow();

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalled();
    });

    consoleSpy.mockRestore();
  });
});
