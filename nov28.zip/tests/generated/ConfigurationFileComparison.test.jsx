import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

// --------------------------------------------------
// Mock functions
// --------------------------------------------------

const mockConfigurationAxios = jest.fn();
const mockInventoryAxios = jest.fn();

// --------------------------------------------------
// Redux mock
// --------------------------------------------------

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn((selector) =>
    selector({
      nodeDetails: {
        isCnms: false,
      },
    })
  ),
}));

// --------------------------------------------------
// API mocks
// --------------------------------------------------

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  ConfigurationAxios: (...args) => mockConfigurationAxios(...args),
  InventoryAxios: (...args) => mockInventoryAxios(...args),
}));

// --------------------------------------------------
// UI component mocks
// --------------------------------------------------

jest.unstable_mockModule(
  "@/components/Reusable/Form/MForm",
  () => ({
    default: ({ title, children }) => (
      <section aria-label={title}>
        <h2>{title}</h2>
        {children}
      </section>
    ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Select/MSelect",
  () => ({
    default: ({ label, options = [], onChange }) => (
      <label>
        {label}
        <select aria-label={label}>
          <option value="">Select One</option>
          {options.map((option, index) => (
            <option key={option.id ?? option.value ?? index}>
              {option.label ?? option.fileName ?? option.resourceName}
            </option>
          ))}
        </select>
      </label>
    ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: ({ children, onClick, disabled }) => (
      <button onClick={onClick} disabled={disabled}>
        {children}
      </button>
    ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Toast/Toast",
  () => ({
    default: jest.fn(),
  })
);

// --------------------------------------------------
// Import component after registering mocks
// --------------------------------------------------

const { default: ConfigurationFileComparison } = await import(
  "../../src/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/FileComparison/ConfigurationFileComparison"
);

// --------------------------------------------------
// Tests
// --------------------------------------------------

describe("ConfigurationFileComparison", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockConfigurationAxios.mockResolvedValue({
      data: {},
    });

    mockInventoryAxios.mockResolvedValue({
      data: [],
    });
  });

  test("renders without crashing", () => {
    render(<ConfigurationFileComparison />);

    expect(
      screen.getByRole("heading", { name: "File comparison" })
    ).toBeInTheDocument();
  });

  test("renders device and configuration comparison fields", () => {
    render(<ConfigurationFileComparison />);

    expect(
      screen.getByLabelText("Device Name*")
    ).toBeInTheDocument();

    expect(
      screen.getByLabelText("Config File 1*")
    ).toBeInTheDocument();

    expect(
      screen.getByRole("button", { name: "Preview" })
    ).toBeInTheDocument();
  });
});
