import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";

jest.unstable_mockModule("@/components/Reusable/Input/MInput", () => ({
  __esModule: true,
  default: function MockInput({
    value,
    onChange,
    placeholder,
    multiline,
    readOnly,
  }) {
    const commonProps = {
      "data-testid": multiline ? "selected-sites-input" : "site-search",
      value: value ?? "",
      onChange,
      placeholder,
      readOnly,
    };

    return multiline ? <textarea {...commonProps} /> : <input {...commonProps} />;
  },
}));

jest.unstable_mockModule("@/components/Reusable/Select/MMultiSelect", () => ({
  __esModule: true,
  default: function MockMultiSelect({ options, value, onChange }) {
    return (
      <select
        data-testid="group-select"
        multiple
        value={value}
        onChange={(e) =>
          onChange(
            Array.from(e.target.selectedOptions, (option) => option.value)
          )
        }
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Checkbox/MCheckbox", () => ({
  __esModule: true,
  default: function MockCheckbox({ checked, onChange, label }) {
    return (
      <label>
        {label}
        <input
          type="checkbox"
          aria-label={label || "site-checkbox"}
          checked={Boolean(checked)}
          onChange={onChange}
        />
      </label>
    );
  },
}));

jest.unstable_mockModule("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: function MockButton({ children, onClick }) {
    return <button onClick={onClick}>{children}</button>;
  },
}));

jest.unstable_mockModule("@/components/Reusable/Modal/MModal", () => ({
  __esModule: true,
  SquareIconButton: ({ children, onClick }) => (
    <button onClick={onClick} aria-label="Close Filter">
      {children}
    </button>
  ),
}));

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn((selector) =>
    selector({
      userSlice: {
        isReadOnlyMode: false,
        isUserLoggedIn: true,
      },
    })
  ),
}));

jest.unstable_mockModule("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");
  return {
    ...actual,
    Popover: ({ open, children, onClose }) =>
      open ? (
        <div data-testid="filter-popover">
          {children}
          <button data-testid="popover-close" onClick={onClose}>
            Close
          </button>
        </div>
      ) : null,
  };
});

const { default: FilterPopover } = await import(
  "../../src/Pages/CnmsDashboard/CnmsMap/components/FilterPopover"
);

describe("FilterPopover Component", () => {
  let anchorEl;
  let reduxSites;
  let allGroupSites;
  let siteGroups;
  let filteredSites;
  let SetFilteredSites;
  let setFilterInfo;
  let filterInfo;

  beforeEach(() => {
    jest.clearAllMocks();

    anchorEl = document.createElement("div");

    reduxSites = [
      { siteId: "SITE_001", healthStatus: { id: 1 } },
      { siteId: "SITE_002", healthStatus: { id: 0 } },
      { siteId: "SITE_003", healthStatus: { id: 2 } },
      { siteId: "SITE_004", healthStatus: { id: 3 } },
    ];

    allGroupSites = [
      { groupName: "Group A", siteId: "SITE_001" },
      { groupName: "Group A", siteId: "SITE_002" },
      { groupName: "Group B", siteId: "SITE_003" },
      { groupName: "Group B", siteId: "SITE_004" },
    ];

    siteGroups = [
      { groupName: "Group A" },
      { groupName: "Group B" },
      { groupName: null },
      {},
    ];

    filteredSites = [...reduxSites];

    SetFilteredSites = jest.fn();
    setFilterInfo = jest.fn();

    filterInfo = {
      selectedGroups: [],
      selectedStatus: [1, 0, 2, 3],
      sitesToFilter: [],
    };
  });

  const renderComponent = (props = {}) =>
    render(
      <FilterPopover
        anchorEl={anchorEl}
        onClose={jest.fn()}
        reduxSites={reduxSites}
        allGroupSites={allGroupSites}
        siteGroups={siteGroups}
        filteredSites={filteredSites}
        SetFilteredSites={SetFilteredSites}
        setFilterInfo={setFilterInfo}
        filterInfo={filterInfo}
        {...props}
      />
    );

  test("does not render when anchorEl is null", () => {
    renderComponent({ anchorEl: null });

    expect(screen.queryByTestId("filter-popover")).not.toBeInTheDocument();
  });

  test("renders when anchorEl is provided", () => {
    renderComponent();

    expect(screen.getByTestId("filter-popover")).toBeInTheDocument();
    expect(screen.getByText("Filter Sites")).toBeInTheDocument();
  });

  test("renders valid group options only", () => {
    renderComponent();

    const options = screen.getByTestId("group-select").options;

    expect(options).toHaveLength(2);
    expect(options[0].textContent).toBe("Group A");
    expect(options[1].textContent).toBe("Group B");
  });

  test("renders all sites initially", () => {
    renderComponent();

    expect(screen.getByText("SITE_001")).toBeInTheDocument();
    expect(screen.getByText("SITE_002")).toBeInTheDocument();
    expect(screen.getByText("SITE_003")).toBeInTheDocument();
    expect(screen.getByText("SITE_004")).toBeInTheDocument();
  });

  test("displays selected site count", () => {
    renderComponent();

    expect(screen.getByText("4 / 4 site(s) selected")).toBeInTheDocument();
  });

  test("displays selected sites in multiline input", () => {
    renderComponent();

    expect(screen.getByTestId("selected-sites-input")).toHaveValue(
      "SITE_001\nSITE_002\nSITE_003\nSITE_004"
    );
  });

  test("selects a group and filters available sites", async () => {
    renderComponent();

    fireEvent.change(screen.getByTestId("group-select"), {
      target: { value: ["Group A"] },
    });

    await waitFor(() => {
      expect(screen.getByText("SITE_001")).toBeInTheDocument();
      expect(screen.getByText("SITE_002")).toBeInTheDocument();

      expect(screen.queryByText("SITE_003")).not.toBeInTheDocument();
      expect(screen.queryByText("SITE_004")).not.toBeInTheDocument();
    });

    expect(SetFilteredSites).toHaveBeenCalledWith([
      reduxSites[0],
      reduxSites[1],
    ]);
  });

  test("clears group selection and displays all sites", async () => {
    renderComponent({
      filterInfo: {
        selectedGroups: ["Group A"],
        selectedStatus: [1, 0, 2, 3],
        sitesToFilter: [reduxSites[0], reduxSites[1]],
      },
      filteredSites: [reduxSites[0], reduxSites[1]],
    });

    fireEvent.change(screen.getByTestId("group-select"), {
      target: { value: [] },
    });

    await waitFor(() => {
      expect(screen.getByText("SITE_003")).toBeInTheDocument();
      expect(screen.getByText("SITE_004")).toBeInTheDocument();
    });

    // Clearing the group filter makes every site available, but it preserves
    // only the sites that were already selected before the group was cleared.
    expect(SetFilteredSites).toHaveBeenCalledWith([
      reduxSites[0],
      reduxSites[1],
    ]);
  });

  test("removes selected sites that do not belong to selected group", () => {
    renderComponent();

    fireEvent.change(screen.getByTestId("group-select"), {
      target: { value: ["Group B"] },
    });

    expect(SetFilteredSites).toHaveBeenCalledWith([
      reduxSites[2],
      reduxSites[3],
    ]);
  });

  test("searches sites by siteId", () => {
    renderComponent();

    fireEvent.change(screen.getByTestId("site-search"), {
      target: { value: "site_001" },
    });

    expect(screen.getByText("SITE_001")).toBeInTheDocument();
    expect(screen.queryByText("SITE_002")).not.toBeInTheDocument();
  });

  test("search is case insensitive", () => {
    renderComponent();

    fireEvent.change(screen.getByTestId("site-search"), {
      target: { value: "SITE_001" },
    });

    expect(screen.getByText("SITE_001")).toBeInTheDocument();
  });

  test("shows no sites found when search has no match", () => {
    renderComponent();

    fireEvent.change(screen.getByTestId("site-search"), {
      target: { value: "UNKNOWN" },
    });

    expect(screen.getByText("No sites found")).toBeInTheDocument();
  });

  test("selects all sites", () => {
    renderComponent({ filteredSites: [] });

    fireEvent.click(screen.getByLabelText("Select All"));

    expect(SetFilteredSites).toHaveBeenCalledWith(reduxSites);
  });

  test("deselects all sites", () => {
    renderComponent({ filteredSites: [...reduxSites] });

    fireEvent.click(screen.getByLabelText("Select All"));

    expect(SetFilteredSites).toHaveBeenLastCalledWith([]);
  });

  test("selects an individual site", () => {
    renderComponent({
      filteredSites: [reduxSites[0]],
    });

    const siteCheckboxes = screen.getAllByLabelText("site-checkbox");

    fireEvent.click(siteCheckboxes[1]);

    expect(SetFilteredSites).toHaveBeenCalledWith([
      reduxSites[0],
      reduxSites[1],
    ]);
  });

  test("does not add a duplicate when an already-selected site is checked", () => {
    renderComponent({
      filteredSites: [...reduxSites],
    });

    const siteCheckboxes = screen.getAllByLabelText("site-checkbox");

    // The checkbox is controlled and initially checked. Reset its DOM state
    // before clicking so the click event reaches the handler with checked=true.
    siteCheckboxes[0].checked = false;
    fireEvent.click(siteCheckboxes[0]);

    // The component calls the setter with the unchanged list; no duplicate
    // site is appended.
    expect(SetFilteredSites).toHaveBeenCalledWith(reduxSites);
    expect(SetFilteredSites.mock.calls[0][0]).toHaveLength(4);
  });

  test("removes an individual site", () => {
    renderComponent({
      filteredSites: [...reduxSites],
    });

    const siteCheckboxes = screen.getAllByLabelText("site-checkbox");

    fireEvent.click(siteCheckboxes[0]);

    expect(SetFilteredSites).toHaveBeenCalledWith([
      reduxSites[1],
      reduxSites[2],
      reduxSites[3],
    ]);
  });

  test("removes status when selected checkbox is clicked", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("Online"));

    expect(setFilterInfo).toHaveBeenCalled();

    const updater = setFilterInfo.mock.calls[0][0];

    expect(updater(filterInfo).selectedStatus).toEqual([0, 2, 3]);
  });

  test("adds status when unchecked checkbox is clicked", () => {
    renderComponent({
      filterInfo: {
        ...filterInfo,
        selectedStatus: [0, 2, 3],
      },
    });

    fireEvent.click(screen.getByLabelText("Online"));

    const updater = setFilterInfo.mock.calls[0][0];

    expect(updater(filterInfo).selectedStatus).toEqual([0, 2, 3, 1]);
  });

  test("toggles Offline status", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("Offline"));

    const updater = setFilterInfo.mock.calls[0][0];

    expect(updater(filterInfo).selectedStatus).toEqual([1, 2, 3]);
  });

  test("toggles RNMS Down status", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("RNMS Down"));

    const updater = setFilterInfo.mock.calls[0][0];

    expect(updater(filterInfo).selectedStatus).toEqual([1, 0, 3]);
  });

  test("toggles Maintenance status", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("Maintenance"));

    const updater = setFilterInfo.mock.calls[0][0];

    expect(updater(filterInfo).selectedStatus).toEqual([1, 0, 2]);
  });

  test("resets filters to default values", () => {
    renderComponent();

    fireEvent.change(screen.getByTestId("site-search"), {
      target: { value: "SITE_001" },
    });

    fireEvent.click(screen.getByText("Reset"));

    expect(SetFilteredSites).toHaveBeenCalledWith(reduxSites);

    expect(setFilterInfo).toHaveBeenCalledWith({
      selectedGroups: [],
      selectedStatus: [1, 0, 2, 3],
      sitesToFilter: reduxSites,
    });

    expect(screen.getByTestId("site-search")).toHaveValue("");
  });

  test("resets group selection", () => {
    renderComponent({
      filterInfo: {
        selectedGroups: ["Group A"],
        selectedStatus: [1],
        sitesToFilter: [reduxSites[0]],
      },
    });

    fireEvent.click(screen.getByText("Reset"));

    expect(setFilterInfo).toHaveBeenCalledWith(
      expect.objectContaining({
        selectedGroups: [],
      })
    );
  });

  test("resets selected statuses", () => {
    renderComponent({
      filterInfo: {
        selectedGroups: [],
        selectedStatus: [1],
        sitesToFilter: reduxSites,
      },
    });

    fireEvent.click(screen.getByText("Reset"));

    expect(setFilterInfo).toHaveBeenCalledWith(
      expect.objectContaining({
        selectedStatus: [1, 0, 2, 3],
      })
    );
  });

  test("uses filterInfo sitesToFilter when available", () => {
    renderComponent({
      filterInfo: {
        selectedGroups: [],
        selectedStatus: [1],
        sitesToFilter: [reduxSites[0]],
      },
    });

    expect(screen.getByText("SITE_001")).toBeInTheDocument();
    expect(screen.queryByText("SITE_002")).not.toBeInTheDocument();
  });

  test("uses reduxSites when sitesToFilter is empty", () => {
    renderComponent({
      filterInfo: {
        selectedGroups: [],
        selectedStatus: [1],
        sitesToFilter: [],
      },
    });

    expect(screen.getByText("SITE_001")).toBeInTheDocument();
    expect(screen.getByText("SITE_004")).toBeInTheDocument();
  });

  test("updates local state when popover opens with new filterInfo", async () => {
    const { rerender } = renderComponent({
      anchorEl: null,
    });

    rerender(
      <FilterPopover
        anchorEl={anchorEl}
        onClose={jest.fn()}
        reduxSites={reduxSites}
        allGroupSites={allGroupSites}
        siteGroups={siteGroups}
        filteredSites={filteredSites}
        SetFilteredSites={SetFilteredSites}
        setFilterInfo={setFilterInfo}
        filterInfo={{
          selectedGroups: ["Group A"],
          selectedStatus: [1],
          sitesToFilter: [reduxSites[0]],
        }}
      />
    );

    await waitFor(() => {
      expect(screen.getByTestId("group-select")).toHaveValue(["Group A"]);
    });
  });

  test("handles empty site list", () => {
    renderComponent({
      reduxSites: [],
      filteredSites: [],
      allGroupSites: [],
      siteGroups: [],
    });

    expect(screen.getByText("0 / 0 site(s) selected")).toBeInTheDocument();
  });

  test("handles a site without siteId during search", () => {
    renderComponent({
      reduxSites: [{ name: "Invalid Site" }],
      filteredSites: [],
    });

    // The component renders site.siteId, not the optional name property.
    expect(screen.queryByText("Invalid Site")).not.toBeInTheDocument();
    expect(screen.getAllByLabelText("site-checkbox")).toHaveLength(1);
    expect(screen.getByTestId("selected-sites-input")).toHaveValue("");

    fireEvent.change(screen.getByTestId("site-search"), {
      target: { value: "unknown" },
    });

    expect(screen.getByText("No sites found")).toBeInTheDocument();
  });

  test("handles empty group selection when allGroupSites is empty", () => {
    renderComponent({
      allGroupSites: [],
    });

    fireEvent.change(screen.getByTestId("group-select"), {
      target: { value: ["Group A"] },
    });

    expect(SetFilteredSites).toHaveBeenCalledWith([]);
  });

  test("closes filter popover", () => {
    const onClose = jest.fn();

    renderComponent({ onClose });

    fireEvent.click(screen.getByLabelText("Close Filter"));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("select all is unchecked when there are no sites", () => {
    renderComponent({
      reduxSites: [],
      filteredSites: [],
    });

    expect(screen.getByLabelText("Select All")).not.toBeChecked();
  });

  test("select all is checked when every available site is selected", async () => {
    renderComponent({
      reduxSites,
      filteredSites: reduxSites,
    });

    await waitFor(() => {
      expect(screen.getByLabelText("Select All")).toBeChecked();
    });
  });

  test("select all is unchecked when only some sites are selected", async () => {
    renderComponent({
      reduxSites,
      filteredSites: [reduxSites[0]],
    });

    await waitFor(() => {
      expect(screen.getByLabelText("Select All")).not.toBeChecked();
    });
  });
});
