import React from "react";
import { jest } from "@jest/globals";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { ThemeProvider, createTheme } from "@mui/material/styles";

const mockConfigurationAxios = jest.fn();

// --------------------------------------------------
// Mock dependencies before importing the component
// --------------------------------------------------

jest.unstable_mockModule("react-grid-layout", () => ({
  default: ({ children, ...props }) => (
    <div data-testid="grid-layout" {...props}>
      {children}
    </div>
  ),
}));

jest.unstable_mockModule(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23",
  () => ({
    WIDGET_REGISTRY: {},
    AVAILABLE_WIDGETS: [],
  })
);

jest.unstable_mockModule(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRenderer",
  () => ({
    default: () => <div data-testid="widget-renderer" />,
  })
);

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  ConfigurationAxios: (...args) => mockConfigurationAxios(...args),
}));

jest.unstable_mockModule(
  "@/components/Reusable/Select/MAlarmSelect",
  () => ({
    default: ({ label, options = [], value, onChange }) => (
      <select
        aria-label={label || "tab selector"}
        value={value ?? ""}
        onChange={(event) => onChange?.(event.target.value)}
      >
        {options.map((option) => (
          <option
            key={option.value ?? option.id}
            value={option.value ?? option.id}
          >
            {option.label ?? option.name}
          </option>
        ))}
      </select>
    ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Input/MInput",
  () => ({
    default: (props) => <input {...props} />,
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: ({ children, startIcon, ...props }) => (
      <button {...props}>
        {startIcon}
        {children}
      </button>
    ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonSecondary",
  () => ({
    default: ({ children, ...props }) => (
      <button {...props}>{children}</button>
    ),
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Modal/MModal",
  () => ({
    default: ({ open, title, children, handleClose }) =>
      open ? (
        <div role="dialog" aria-label={title}>
          {children}
          <button onClick={handleClose}>Close modal</button>
        </div>
      ) : null,
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Toast/Toast",
  () => ({
    default: jest.fn(),
  })
);

// Import component only after registering mocks.
const { default: ExcelConfigBuilder } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/ExcelConfigBuilder"
);

// --------------------------------------------------
// Theme
// --------------------------------------------------

const theme = createTheme({
  palette: {
    custom: {
      border: "1px solid #ddd",
      snmp: {
        snmmptitle: "#222",
        inputtitle: "#333",
      },
    },
  },
});

// --------------------------------------------------
// Render helper
// --------------------------------------------------

const renderBuilder = (props = {}) => {
  const defaultProps = {
    selectedDevice: {
      resourceId: 7,
      resourceName: "Router",
      imResourceType: {
        resourceTypeName: "Router",
      },
    },
    selectedTerminal: {
      id: 3,
    },
    tabs: [
      { name: "Configuration" },
      { name: "Status" },
    ],
    dialogType: "CONFIGURATION",
    onBack: jest.fn(),
    setActiveTabId: jest.fn(),
    activeTabIdx: 0,
    setActiveTabIdx: jest.fn(),
  };

  return render(
    <ThemeProvider theme={theme}>
      <ExcelConfigBuilder {...defaultProps} {...props} />
    </ThemeProvider>
  );
};

// --------------------------------------------------
// Tests
// --------------------------------------------------

describe("ExcelConfigBuilder component", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockConfigurationAxios.mockReset();
    mockConfigurationAxios.mockResolvedValue({
      data: { status: 1 },
    });

    global.ResizeObserver = class {
      observe = jest.fn();
      disconnect = jest.fn();
    };
  });

  afterEach(() => {
    delete global.ResizeObserver;
  });

 test("renders the selected device and initial tabs", async () => {
  renderBuilder();

  expect(
    await screen.findByRole("button", {
      name: "Create a New Layout Tab",
    })
  ).toBeInTheDocument();

  expect(
    screen.getByText(/Manage Tabs : Router/)
  ).toBeInTheDocument();

  expect(
    screen.getByRole("button", { name: "Back" })
  ).toBeInTheDocument();

  expect(
    screen.getByRole("button", { name: "Save Layout" })
  ).toBeInTheDocument();

  expect(
    screen.getByRole("tab", { name: "Configuration" })
  ).toBeInTheDocument();

  expect(
    screen.getByRole("tab", { name: "Status" })
  ).toBeInTheDocument();
});

test("adds a new tab to the layout editor", async () => {
  renderBuilder();

  fireEvent.click(
    await screen.findByRole("button", {
      name: "Create a New Layout Tab",
    })
  );

  expect(
    await screen.findByRole("option", { name: "Tab 3" })
  ).toBeInTheDocument();

  expect(
    screen.getByRole("tab", { name: "Tab 3" })
  ).toBeInTheDocument();
});
  test("saves an empty layout through the configuration API", async () => {
    renderBuilder();

    fireEvent.click(
      screen.getByRole("button", { name: "Save Layout" })
    );

    await waitFor(() => {
      expect(mockConfigurationAxios).toHaveBeenCalled();
    });

    expect(mockConfigurationAxios.mock.calls[0][1]).toBe("post");

    expect(mockConfigurationAxios.mock.calls[0][2]).toEqual(
      expect.objectContaining({
        layoutId: 10,
        resourceTypeName: "Router",
        terminalType: { id: 3 },
      })
    );
  });

  test("calls the supplied back callback", () => {
    const onBack = jest.fn();

    renderBuilder({ onBack });

    fireEvent.click(
      screen.getByRole("button", { name: "Back" })
    );

    expect(onBack).toHaveBeenCalledTimes(1);
  });
});
