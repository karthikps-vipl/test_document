/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
  TopologyAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  ASSIGN_PROFILE_TO_RESOURCES: "/assign-profile-to-resources",
  FETCH_RESOURCE_INFO_BY_SNMP_AND_SNMP_COMMUNICATION_TYPE:
    "/fetch-resource-info",
  FETCH_SNMP_PROFILE_DETAILS: "/fetch-snmp-profile-details",
}));

jest.mock("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.mock("@/components/Reusable/Pdf/downloadPdf", () => ({
  exportToCSV: jest.fn(),
  exportToPDF: jest.fn(),
}));

jest.mock("@/lib/utils", () => ({
  AUTH_PROTOCOL_MAP: {
    MD5: "MD5 Auth",
    SHA: "SHA Auth",
  },
  PRIV_PROTOCOL_MAP: {
    AES: "AES Priv",
    DES: "DES Priv",
  },
  SECURITY_LEVEL_MAP: {
    authPriv: "Auth + Priv",
    noAuthNoPriv: "No Auth No Priv",
  },
}));

jest.mock("@/assets/SVGIcons/question_mark.svg", () => ({
  __esModule: true,
  default: "question.svg",
}));

let latestTableProps;
let latestDialogProps;

jest.mock("@/components/Reusable/Table/MTable", () => ({
  __esModule: true,
  default: (props) => {
    latestTableProps = props;
    return (
      <div data-testid="m-table">
        <span data-testid="table-rows-count">
          {props.tableData?.length ?? 0}
        </span>
        <div data-testid="custom-dropdown">{props.customDropdown}</div>
        <div data-testid="custom-dropdown-1">{props.customDropdown1}</div>
        <div data-testid="custom-button">{props.customButton}</div>
        <button
          data-testid="export-pdf-btn"
          onClick={props.handleDownloadPDF}
        >
          Export PDF
        </button>
        <button
          data-testid="export-csv-btn"
          onClick={props.handleDownloadCSV}
        >
          Export CSV
        </button>
      </div>
    );
  },
}));

jest.mock("@/components/Reusable/Select/MMultiSelect", () => ({
  __esModule: true,
  default: ({ value, onChange, placeholder }) => (
    <div>
      <span data-testid="device-select-value">
        {JSON.stringify(value)}
      </span>
      <button
        data-testid="select-devices-objects"
        onClick={() =>
          onChange([
            { label: "Router-1", value: 101 },
            { label: "Switch-2", resourceId: 102 },
          ])
        }
      >
        Select Object Devices
      </button>
      <button
        data-testid="select-devices-primitives"
        onClick={() => onChange([201, "202", null, undefined])}
      >
        Select Primitive Devices
      </button>
      <button
        data-testid="select-devices-single-non-array"
        onClick={() => onChange(303)}
      >
        Select Single Non-Array Device
      </button>
      <button
        data-testid="clear-devices"
        onClick={() => onChange([])}
      >
        Clear Devices
      </button>
      <span data-testid="device-placeholder">{placeholder}</span>
    </div>
  ),
}));

jest.mock("@/components/Reusable/Select/MSelect", () => ({
  __esModule: true,
  default: ({ value, onChange, placeholder }) => (
    <div>
      <span data-testid="profile-select-value">
        {JSON.stringify(value)}
      </span>
      <button
        data-testid="select-profile-object-value"
        onClick={() => onChange([{ label: "SNMPv3", value: 55 }])}
      >
        Select Profile Object (.value)
      </button>
      <button
        data-testid="select-profile-object-id"
        onClick={() =>
          onChange([{ label: "SNMPv3-Alt", snmpProfileId: 66 }])
        }
      >
        Select Profile Object (.snmpProfileId)
      </button>
      <button
        data-testid="select-profile-primitive"
        onClick={() => onChange([77, null])}
      >
        Select Profile Primitive
      </button>
      <button
        data-testid="select-profile-non-array"
        onClick={() => onChange(88)}
      >
        Select Profile Non-Array
      </button>
      <button
        data-testid="clear-profile"
        onClick={() => onChange([])}
      >
        Clear Profile
      </button>
      <span data-testid="profile-placeholder">{placeholder}</span>
    </div>
  ),
}));

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button
      data-testid="submit-button"
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  ),
}));

jest.mock("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => {
    latestDialogProps = props;
    return props.open ? (
      <div data-testid="confirm-dialog">
        <span>{props.title}</span>
        <span>{props.message}</span>
        <button
          data-testid="confirm-update-btn"
          onClick={props.onConfirm}
          disabled={props.isSubmitting}
        >
          Confirm
        </button>
        <button
          data-testid="close-dialog-btn"
          onClick={props.onClose}
        >
          Close
        </button>
      </div>
    ) : null;
  },
}));

import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";

import SiteConfigAssignProfile from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/AssignProfile/SiteConfigAssignProfile"; // Update path if different

import {
  InventoryAxios,
  TopologyAxios,
} from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";

/* -------------------------------------------------------
   FIXTURES & HELPERS
------------------------------------------------------- */

const sampleResources = [
  {
    resourceId: 101,
    resourceName: "Router-1",
    resourceIp: "10.0.0.1",
    tmSnmpProfile: {
      snmpProfileId: 11,
      snmpProfileName: "Corp-SNMPv3",
      username: "snmpuser",
      version: 3,
      port: 161,
      securityLevel: "authPriv",
      contextName: "ctx1",
      retries: 2,
      timeout: 5000,
      authPassword: "secretAuthPassword",
      authProtocol: "SHA",
      privPassword: "secretPrivPassword",
      privProtocol: "AES",
      readCommunity: "public",
      writeCommunity: "private",
    },
  },
  {
    resourceId: 102,
    resourceName: "Switch-2",
    resourceIp: "",
    tmSnmpProfile: {
      snmpProfileId: 12,
      snmpProfileName: "Legacy-SNMPv2",
      version: 0,
      securityLevel: "CUSTOM_SEC",
      authProtocol: "CUSTOM_AUTH",
      privProtocol: "CUSTOM_PRIV",
    },
  },
  {
    resourceId: 103,
    resourceName: "Firewall-3",
    resourceIp: null,
    tmSnmpProfile: null,
  },
];

const sampleProfiles = [
  { snmpProfileId: 11, snmpProfileName: "Corp-SNMPv3" },
  { snmpProfileId: 12, snmpProfileName: "Legacy-SNMPv2" },
];

const defaultProps = (overrides = {}) => ({
  refreshTrigger: 0,
  privilegeKey: "SITE_CONFIG_WRITE",
  onRefresh: jest.fn(),
  isChildFullScreen: false,
  ...overrides,
});

const renderComponent = (props = {}) =>
  render(<SiteConfigAssignProfile {...defaultProps(props)} />);

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("SiteConfigAssignProfile Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestTableProps = undefined;
    latestDialogProps = undefined;

    InventoryAxios.mockImplementation((url) => {
      if (url === "/fetch-resource-info") {
        return Promise.resolve({ data: sampleResources });
      }
      if (url === "/assign-profile-to-resources") {
        return Promise.resolve({
          data: { status: 1, message: "Updated" },
        });
      }
      return Promise.resolve({ data: [] });
    });

    TopologyAxios.mockResolvedValue({
      data: sampleProfiles,
    });

    jest.spyOn(console, "log").mockImplementation(() => {});
    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIAL DATA FETCHING & RENDERING
  ------------------------------------------------------- */

  describe("Initial rendering and data fetching", () => {
    it("shows loading spinner while initial table data is being fetched", async () => {
      let resolveResources;
      InventoryAxios.mockImplementationOnce(
        () =>
          new Promise((resolve) => {
            resolveResources = resolve;
          })
      );

      renderComponent();

      expect(screen.getByRole("progressbar")).toBeInTheDocument();

      await act(async () => {
        resolveResources({ data: sampleResources });
      });

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });
    });

    it("fetches resources and SNMP profiles and processes table rows", async () => {
      renderComponent({ privilegeKey: "ADMIN_PRIV" });

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          "/fetch-resource-info",
          "get"
        );
        expect(TopologyAxios).toHaveBeenCalledWith(
          "/fetch-snmp-profile-details",
          "get"
        );
        expect(screen.getByTestId("table-rows-count")).toHaveTextContent(
          "3"
        );
      });

      expect(latestTableProps.privilegeKey).toBe("ADMIN_PRIV");
      expect(latestTableProps.tableData[0]).toMatchObject({
        sno: 1,
        resourceId: 101,
        ipAddress: "10.0.0.1",
        snmpProfileName: "Corp-SNMPv3",
        profileId: 11,
      });
      expect(latestTableProps.tableData[1]).toMatchObject({
        sno: 2,
        ipAddress: "NA",
        snmpProfileName: "Legacy-SNMPv2",
      });
      expect(latestTableProps.tableData[2]).toMatchObject({
        sno: 3,
        ipAddress: "NA",
        snmpProfileName: "NA",
        profileId: undefined,
      });

      expect(latestTableProps.customDropdown.props.options).toEqual([
        { label: "Router-1", value: 101 },
        { label: "Switch-2", value: 102 },
        { label: "Firewall-3", value: 103 },
      ]);

      expect(latestTableProps.customDropdown1.props.options).toEqual([
        { label: "Corp-SNMPv3", value: 11 },
        { label: "Legacy-SNMPv2", value: 12 },
      ]);
    });

    it("handles empty response data gracefully for resources and profiles", async () => {
      InventoryAxios.mockResolvedValueOnce({});
      TopologyAxios.mockResolvedValueOnce({});

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("table-rows-count")).toHaveTextContent(
          "0"
        );
      });

      expect(latestTableProps.customDropdown.props.options).toEqual([]);
      expect(latestTableProps.customDropdown1.props.options).toEqual([]);
    });

    it("re-fetches resource data when refreshTrigger changes", async () => {
      const { rerender } = renderComponent({ refreshTrigger: 1 });

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledTimes(1);
      });

      rerender(<SiteConfigAssignProfile {...defaultProps({ refreshTrigger: 2 })} />);

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledTimes(2);
      });
    });

    it("shows error toast and logs error when fetching SNMP resource details fails", async () => {
      InventoryAxios.mockRejectedValueOnce(new Error("Network error"));

      renderComponent();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to fetch Snmp Details",
          "error"
        );
      });

      expect(console.error).toHaveBeenCalledWith(
        "Error fetching Snmp Details:",
        expect.any(Error)
      );
      expect(screen.getByTestId("m-table")).toBeInTheDocument();
    });

    it("logs error without crashing when fetching SNMP profile list fails", async () => {
      TopologyAxios.mockRejectedValueOnce(new Error("Profile API down"));

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      expect(console.error).toHaveBeenCalledWith(
        "Error fetching Profile Master List:",
        expect.any(Error)
      );
      expect(latestTableProps.customDropdown1.props.options).toEqual([]);
    });
  });

  /* -------------------------------------------------------
     SELECTION & SUBMIT BUTTON STATE
  ------------------------------------------------------- */

  describe("Selection and submit button state", () => {
    it("disables Submit button initially and when only one selection is made", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("submit-button")).toBeDisabled();
      });

      fireEvent.click(screen.getByTestId("select-devices-objects"));
      expect(screen.getByTestId("submit-button")).toBeDisabled();

      fireEvent.click(screen.getByTestId("clear-devices"));
      fireEvent.click(screen.getByTestId("select-profile-object-value"));
      expect(screen.getByTestId("submit-button")).toBeDisabled();
    });

    it("enables Submit button when both device and profile are selected", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("select-devices-objects"));
      fireEvent.click(screen.getByTestId("select-profile-object-value"));

      expect(screen.getByTestId("submit-button")).toBeEnabled();
    });
  });

  /* -------------------------------------------------------
     CONFIRMATION DIALOG & SUBMISSION FLOWS
  ------------------------------------------------------- */

  describe("Dialog and profile assignment submission", () => {
    it("opens confirmation dialog with expected props and closes when cancelled", async () => {
      renderComponent({ isChildFullScreen: true });

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("select-devices-objects"));
      fireEvent.click(screen.getByTestId("select-profile-object-value"));
      fireEvent.click(screen.getByTestId("submit-button"));

      expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();
      expect(latestDialogProps).toMatchObject({
        open: true,
        variant: "info",
        title: "Confirm Action",
        message:
          "Are you sure you want to update the Assign Profile configuration?",
        mode: "child",
        isChildFullScreen: true,
      });

      fireEvent.click(screen.getByTestId("close-dialog-btn"));

      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
      expect(InventoryAxios).not.toHaveBeenCalledWith(
        "/assign-profile-to-resources",
        expect.anything(),
        expect.anything()
      );
    });

    it("submits payload with object device/profile values and calls onRefresh", async () => {
      const onRefresh = jest.fn();
      renderComponent({ onRefresh });

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("select-devices-objects"));
      fireEvent.click(screen.getByTestId("select-profile-object-value"));
      fireEvent.click(screen.getByTestId("submit-button"));
      fireEvent.click(screen.getByTestId("confirm-update-btn"));

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          "/assign-profile-to-resources",
          "post",
          {
            resources: [101, 102],
            snmpProfile: 55,
          }
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success!",
        "Configuration updated successfully",
        "success"
      );
      expect(onRefresh).toHaveBeenCalledTimes(1);
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
      expect(screen.getByTestId("submit-button")).toBeDisabled();
    });

    it("normalizes primitive IDs, snmpProfileId objects, and non-array selections", async () => {
      renderComponent({ onRefresh: "not-a-function" });

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("select-devices-primitives"));
      fireEvent.click(screen.getByTestId("select-profile-object-id"));
      fireEvent.click(screen.getByTestId("submit-button"));
      fireEvent.click(screen.getByTestId("confirm-update-btn"));

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          "/assign-profile-to-resources",
          "post",
          {
            resources: [201, "202"],
            snmpProfile: 66,
          }
        );
      });

      expect(console.error).toHaveBeenCalledWith(
        "onRefresh is NOT a function! Check the Drawer props."
      );

      // Test non-array device & primitive profile
      fireEvent.click(screen.getByTestId("select-devices-single-non-array"));
      fireEvent.click(screen.getByTestId("select-profile-primitive"));
      fireEvent.click(screen.getByTestId("submit-button"));
      fireEvent.click(screen.getByTestId("confirm-update-btn"));

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          "/assign-profile-to-resources",
          "post",
          {
            resources: [303],
            snmpProfile: 77,
          }
        );
      });

      // Test non-array profile
      fireEvent.click(screen.getByTestId("select-devices-single-non-array"));
      fireEvent.click(screen.getByTestId("select-profile-non-array"));
      fireEvent.click(screen.getByTestId("submit-button"));
      fireEvent.click(screen.getByTestId("confirm-update-btn"));

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          "/assign-profile-to-resources",
          "post",
          {
            resources: [303],
            snmpProfile: 88,
          }
        );
      });
    });

    it("does not show success toast or call onRefresh when update response is falsy", async () => {
      const onRefresh = jest.fn();
      InventoryAxios.mockImplementation((url) => {
        if (url === "/fetch-resource-info") {
          return Promise.resolve({ data: sampleResources });
        }
        if (url === "/assign-profile-to-resources") {
          return Promise.resolve(null);
        }
        return Promise.resolve({ data: [] });
      });

      renderComponent({ onRefresh });

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("select-devices-objects"));
      fireEvent.click(screen.getByTestId("select-profile-object-value"));
      fireEvent.click(screen.getByTestId("submit-button"));
      fireEvent.click(screen.getByTestId("confirm-update-btn"));

      await waitFor(() => {
        expect(InventoryAxios).toHaveBeenCalledWith(
          "/assign-profile-to-resources",
          "post",
          expect.any(Object)
        );
      });

      expect(Toast).not.toHaveBeenCalledWith(
        "Success!",
        expect.anything(),
        "success"
      );
      expect(onRefresh).not.toHaveBeenCalled();
    });

    it("shows error toast, logs error, and closes dialog when update API fails", async () => {
      const onRefresh = jest.fn();
      InventoryAxios.mockImplementation((url) => {
        if (url === "/fetch-resource-info") {
          return Promise.resolve({ data: sampleResources });
        }
        if (url === "/assign-profile-to-resources") {
          return Promise.reject(new Error("Assign failed"));
        }
        return Promise.resolve({ data: [] });
      });

      renderComponent({ onRefresh });

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("select-devices-objects"));
      fireEvent.click(screen.getByTestId("select-profile-object-value"));
      fireEvent.click(screen.getByTestId("submit-button"));
      fireEvent.click(screen.getByTestId("confirm-update-btn"));

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to update configuration",
          "error"
        );
      });

      expect(console.error).toHaveBeenCalledWith(
        "Update error:",
        expect.any(Error)
      );
      expect(onRefresh).not.toHaveBeenCalled();
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
    });
  });

  /* -------------------------------------------------------
     EXPORT CSV & PDF (INCLUDING getExportData MAPPING)
  ------------------------------------------------------- */

  describe("PDF and CSV export", () => {
    it("transforms rows with mapped and fallback SNMP fields on PDF and CSV export", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("m-table")).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId("export-pdf-btn"));

      expect(exportToPDF).toHaveBeenCalledTimes(1);
      const [pdfTitle, pdfColumns, pdfRows, pdfFileName] =
        exportToPDF.mock.calls[0];

      expect(pdfTitle).toBe("Assign Profile");
      expect(pdfFileName).toBe("Assign_Profile");
      expect(pdfColumns).toHaveLength(18);

      // Row 0: full profile with mapped values
      expect(pdfRows[0]).toMatchObject({
        username: "snmpuser",
        version: 3,
        port: 161,
        securityLevel: "Auth + Priv",
        contextName: "ctx1",
        retries: 2,
        timeout: 5000,
        authPassword: "secretAuthPassword",
        authProtocol: "SHA Auth",
        privPassword: "secretPrivPassword",
        privProtocol: "AES Priv",
        readCommunity: "public",
        writeCommunity: "private",
      });

      // Row 1: version 0 preserved via ??, unmapped protocol values fall back to raw string
      expect(pdfRows[1]).toMatchObject({
        username: "-",
        version: 0,
        port: "-",
        securityLevel: "CUSTOM_SEC",
        contextName: "-",
        retries: "-",
        timeout: "-",
        authPassword: "-",
        authProtocol: "CUSTOM_AUTH",
        privPassword: "-",
        privProtocol: "CUSTOM_PRIV",
        readCommunity: "-",
        writeCommunity: "-",
      });

      // Row 2: null profile falls back to "-"
      expect(pdfRows[2]).toMatchObject({
        username: "-",
        version: "-",
        port: "-",
        securityLevel: "-",
        authProtocol: "-",
        privProtocol: "-",
      });

      fireEvent.click(screen.getByTestId("export-csv-btn"));

      expect(exportToCSV).toHaveBeenCalledTimes(1);
      const [csvFileName, csvColumns, csvRows] = exportToCSV.mock.calls[0];
      expect(csvFileName).toBe("AssignProfile_Export");
      expect(csvColumns).toHaveLength(18);
      expect(csvRows).toHaveLength(3);
    });
  });
}); 
