const path = require("path");

module.exports = {
  process(sourceText, sourcePath) {
    const fileName = path.basename(sourcePath);

    return {
      code: `module.exports = ${JSON.stringify(fileName)};`,
    };
  },
};
