import React from "react";

const MockContainer = ({ children, ...props }) =>
  React.createElement("div", { "data-testid": "react-leaflet-mock", ...props }, children);

const noop = () => undefined;

export const useMap = () => ({
  setView: noop,
  fitBounds: noop,
  invalidateSize: noop,
  flyTo: noop,
  getZoom: () => 10,
  getCenter: () => ({ lat: 0, lng: 0 }),
  on: noop,
  off: noop,
});

export const useMapEvents = () => useMap();

export const MapContainer = MockContainer;
export const TileLayer = MockContainer;
export const WMSTileLayer = MockContainer;
export const Marker = MockContainer;
export const Popup = MockContainer;
export const Tooltip = MockContainer;
export const GeoJSON = MockContainer;
export const Circle = MockContainer;
export const CircleMarker = MockContainer;
export const FeatureGroup = MockContainer;
export const LayersControl = Object.assign(MockContainer, {
  BaseLayer: MockContainer,
  Overlay: MockContainer,
});
export const ScaleControl = MockContainer;
export const ZoomControl = MockContainer;
export const Pane = MockContainer;
export const Polyline = MockContainer;
