export default "confirm-icon.svg";
