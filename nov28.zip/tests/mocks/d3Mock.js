const d3 = {
    group: jest.fn((data, keyFn) => {
      const groups = new Map();
  
      data.forEach((item) => {
        const key = keyFn(item);
  
        if (!groups.has(key)) {
          groups.set(key, []);
        }
  
        groups.get(key).push(item);
      });
  
      return groups;
    }),
  
    hierarchy: jest.fn((data) => ({
      data,
      children: [],
      descendants: jest.fn(() => []),
      sum: jest.fn().mockReturnThis(),
      each: jest.fn(),
      ancestors: jest.fn(() => []),
    })),
  
    partition: jest.fn(() => ({
      size: jest.fn().mockReturnThis(),
    })),
  
    arc: jest.fn(() => ({
      startAngle: jest.fn().mockReturnThis(),
      endAngle: jest.fn().mockReturnThis(),
      innerRadius: jest.fn().mockReturnThis(),
      outerRadius: jest.fn().mockReturnThis(),
    })),
  
    select: jest.fn(() => ({
      select: jest.fn().mockReturnThis(),
      selectAll: jest.fn().mockReturnThis(),
      append: jest.fn().mockReturnThis(),
      attr: jest.fn().mockReturnThis(),
      style: jest.fn().mockReturnThis(),
      text: jest.fn().mockReturnThis(),
      data: jest.fn().mockReturnThis(),
      enter: jest.fn().mockReturnThis(),
      exit: jest.fn().mockReturnThis(),
      merge: jest.fn().mockReturnThis(),
      on: jest.fn().mockReturnThis(),
      transition: jest.fn().mockReturnThis(),
      duration: jest.fn().mockReturnThis(),
      ease: jest.fn().mockReturnThis(),
      attrTween: jest.fn().mockReturnThis(),
      remove: jest.fn().mockReturnThis(),
      empty: jest.fn(() => true),
    })),
  
    color: jest.fn(() => ({
      darker: jest.fn().mockReturnValue("#536a96"),
      brighter: jest.fn().mockReturnValue("#536a96"),
      toString: jest.fn().mockReturnValue("#536a96"),
    })),
  
    interpolate: jest.fn(() => jest.fn(() => ({}))),
  
    easeCubicOut: jest.fn(),
  };
  
  module.exports = d3;