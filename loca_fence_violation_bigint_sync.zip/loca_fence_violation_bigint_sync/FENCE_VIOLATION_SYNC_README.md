# Fence and Violation synchronization

## Behavior
- Fence add, edit and soft-delete enqueue a `FenceOutbox` event in the same service transaction as the fence update.
- Violation add enqueues a `ViolationOutbox` event in the same service transaction as the violation insert.
- `FenceOutboxDelivery` and `ViolationOutboxDelivery` independently track each ACTIVE peer node.
- `FenceViolationOutboxWorker` sends events to `/internal/sync/fence` and `/internal/sync/violation`, acknowledges successful HTTP responses, and retries failures with backoff.
- Receiving endpoints apply records idempotently by their BIGINT record IDs. Fence soft-delete is replicated as the fence status value `2`.
- Existing `sync_group_outbox` / `sync_outbox_delivery` group/location synchronization code is not used or changed by this implementation.

## BIGINT IDs
Fence and violation primary keys, API fence IDs, and the fence foreign key are now Java `Long` / PostgreSQL `BIGINT`. New IDs are timestamp-derived: epoch milliseconds multiplied by 1000, with a per-JVM sequence suffix to avoid collisions within the same JVM/millisecond. Existing integer values are preserved by the migration.

**Distributed uniqueness caveat:** independently running nodes can theoretically generate the same timestamp-derived value at the same time because their counters are local. If strict global uniqueness is mandatory, a shared ID allocation authority or a node-specific ID allocation scheme is required. The timestamp-only requirement by itself cannot mathematically guarantee uniqueness across isolated databases.

## Deployment
1. Back up every node database.
2. Run `FENCE_VIOLATION_SYNC_MIGRATION.sql` on every node before deploying the application. Verify the actual existing FK constraint name if the schema differs from the default Hibernate name.
3. Deploy the same application build to all nodes.
4. Confirm each node's `node_registry` contains the peer nodes with status `ACTIVE` and that the service port is reachable from every peer.
5. Test add/edit/delete fence and add violation on one node; verify rows and delivery acknowledgements on all other active nodes.

## Notes
- The receiver expects the referenced MDM user and, for violation events, the referenced fence to exist on the receiving node. Fence events are independently retried; ensure they are delivered before testing violation delivery, or implement a dependency-aware retry if event ordering cannot be guaranteed.
- The worker uses the same service port as the current node and HTTP, matching the existing `NodeSyncService` routing pattern. Apply your existing internal endpoint authentication/network restrictions to these new `/internal/sync/*` endpoints before production deployment.
- Build/integration tests must be run in the project's actual Maven environment. Maven was not installed in the packaging environment, so this archive has not been compiled here.




I compared the updated `loca_fence_violation_bigint_sync.zip` directly against your original `loca.zip`.

The actual file-level changes are **14 modified files and 19 newly added files. No original files were removed.**

## 1. Existing files modified — 14

| No. | File | Purpose of modification |
|---:|---|---|
| 1 | `config/SecurityConfig.java` | Security configuration for synchronization endpoints. |
| 2 | `controller/GisController.java` | Updated fence ID handling to BIGINT. |
| 3 | `dto/request/AddViolationRequest.java` | Changed fence ID to Long. |
| 4 | `dto/request/EditFenceRequest.java` | Changed fence ID to Long. |
| 5 | `dto/response/FenceCreationResponse.java` | Updated ID type to Long. |
| 6 | `dto/response/FencingListResponse.java` | Updated ID type to Long. |
| 7 | `dto/response/ViolationListResponse.java` | Updated ID type to Long. |
| 8 | `entity/LaaGisFencing.java` | Changed primary key to BIGINT and added timestamp-based ID generation. |
| 9 | `entity/LaaGisFencingViolation.java` | Changed primary key to BIGINT and added timestamp-based ID generation. |
| 10 | `repository/LaaGisFencingRepository.java` | Changed repository ID type to Long. |
| 11 | `repository/LaaGisFencingViolationRepository.java` | Changed repository ID type to Long. |
| 12 | `service/GisService.java` | Updated fence ID method parameter to Long. |
| 13 | `service/impl/GisServiceImpl.java` | Updated fence operations and synchronization integration. |
| 14 | `service/impl/ViolationServiceImpl.java` | Added violation synchronization integration. |

## 2. New files added — 19

### A. Configuration and controller

| No. | File |
|---:|---|
| 1 | `config/AsyncConfig.java` |
| 2 | `controller/FenceViolationSyncController.java` |

### B. Outbox entities

| No. | File |
|---:|---|
| 3 | `entity/FenceOutbox.java` |
| 4 | `entity/FenceOutboxDelivery.java` |
| 5 | `entity/ViolationOutbox.java` |
| 6 | `entity/ViolationOutboxDelivery.java` |

### C. Repositories

| No. | File |
|---:|---|
| 7 | `repository/FenceOutboxDeliveryRepository.java` |
| 8 | `repository/FenceOutboxRepository.java` |
| 9 | `repository/ViolationOutboxDeliveryRepository.java` |
| 10 | `repository/ViolationOutboxRepository.java` |

### D. Synchronization services

| No. | File |
|---:|---|
| 11 | `service/impl/FenceViolationOutboxService.java` |
| 12 | `service/impl/FenceViolationOutboxWorker.java` |
| 13 | `service/impl/FenceViolationSyncReceiver.java` |

### E. Synchronization DTOs and events

| No. | File |
|---:|---|
| 14 | `sync/FenceSyncPayload.java` |
| 15 | `sync/ViolationSyncPayload.java` |
| 16 | `sync/FenceViolationSyncWakeupEvent.java` |

### F. ID generation

| No. | File |
|---:|---|
| 17 | `util/TimestampBigIntIdGenerator.java` |

### G. SQL migration and documentation

| No. | File |
|---:|---|
| 18 | `FENCE_VIOLATION_SYNC_MIGRATION.sql` |
| 19 | `FENCE_VIOLATION_SYNC_README.md` |

## 3. Summary

| Category | Count |
|---|---:|
| Existing files modified | 14 |
| New files added | 19 |
| Files removed | 0 |
| **Total changes** | **33** |

## 4. Important observations

A few points I want to highlight:

1. `ViolationController.java` is unchanged. The synchronization integration is implemented in `ViolationServiceImpl.java`.
2. `GisController.java` is modified for the BIGINT ID changes.
3. The four new outbox tables are independent of the existing location synchronization tables.
4. The migration SQL is included in the ZIP.

**One clarification:** This is a file comparison, not a compilation or runtime verification. I recommend checking the repository queries, entity relationships, and migration against your actual PostgreSQL schema before deploying.
