-- Run this migration on EVERY node database before deploying the new application.
-- Back up the database first. Existing integer IDs are preserved as BIGINT values.

BEGIN;

-- Remove the existing FK before changing both sides of the relationship.
DO $$
DECLARE fk_name TEXT;
BEGIN
    FOR fk_name IN
        SELECT conname FROM pg_constraint
        WHERE conrelid = 'tcs_laa.laa_gis_fencing_violation'::regclass
          AND confrelid = 'tcs_laa.laa_gis_fencing'::regclass
          AND contype = 'f'
    LOOP
        EXECUTE format('ALTER TABLE tcs_laa.laa_gis_fencing_violation DROP CONSTRAINT %I', fk_name);
    END LOOP;
END $$;

-- The application now supplies timestamp-derived BIGINT IDs itself.
ALTER TABLE tcs_laa.laa_gis_fencing ALTER COLUMN id DROP IDENTITY IF EXISTS;
ALTER TABLE tcs_laa.laa_gis_fencing ALTER COLUMN id DROP DEFAULT;
ALTER TABLE tcs_laa.laa_gis_fencing ALTER COLUMN id TYPE BIGINT USING id::BIGINT;

ALTER TABLE tcs_laa.laa_gis_fencing_violation ALTER COLUMN id DROP IDENTITY IF EXISTS;
ALTER TABLE tcs_laa.laa_gis_fencing_violation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE tcs_laa.laa_gis_fencing_violation ALTER COLUMN id TYPE BIGINT USING id::BIGINT;
ALTER TABLE tcs_laa.laa_gis_fencing_violation
    ALTER COLUMN laa_gis_fencing__id TYPE BIGINT USING laa_gis_fencing__id::BIGINT;

ALTER TABLE tcs_laa.laa_gis_fencing_violation
    ADD CONSTRAINT laa_gis_fencing_violation_laa_gis_fencing__id_fkey
    FOREIGN KEY (laa_gis_fencing__id)
    REFERENCES tcs_laa.laa_gis_fencing(id);

CREATE TABLE IF NOT EXISTS tcs_laa.fence_outbox (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL UNIQUE,
    event_type VARCHAR(40) NOT NULL,
    source_node_id VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    status VARCHAR(20) NOT NULL,
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL,
    last_error TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_fence_outbox_ready
    ON tcs_laa.fence_outbox(status, next_retry_at, created_at);

CREATE TABLE IF NOT EXISTS tcs_laa.fence_outbox_delivery (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL,
    target_node_id VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL,
    acknowledged_at TIMESTAMP NULL,
    last_error TEXT NULL,
    CONSTRAINT uk_fence_delivery_event_node UNIQUE(event_id, target_node_id)
);
CREATE INDEX IF NOT EXISTS idx_fence_delivery_retry
    ON tcs_laa.fence_outbox_delivery(status, next_retry_at);

CREATE TABLE IF NOT EXISTS tcs_laa.violation_outbox (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL UNIQUE,
    event_type VARCHAR(40) NOT NULL,
    source_node_id VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    status VARCHAR(20) NOT NULL,
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL,
    last_error TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_violation_outbox_ready
    ON tcs_laa.violation_outbox(status, next_retry_at, created_at);

CREATE TABLE IF NOT EXISTS tcs_laa.violation_outbox_delivery (
    id BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL,
    target_node_id VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL,
    acknowledged_at TIMESTAMP NULL,
    last_error TEXT NULL,
    CONSTRAINT uk_violation_delivery_event_node UNIQUE(event_id, target_node_id)
);
CREATE INDEX IF NOT EXISTS idx_violation_delivery_retry
    ON tcs_laa.violation_outbox_delivery(status, next_retry_at);

COMMIT;
