package org.bel.locationService.dto.request;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EditFenceRequest {
	@NotNull(message = "Fence Id is required")
	private Long fenceId;
	
	@NotNull(message = "User id is required")
	private Long userId;
	
	@NotBlank(message = "User Name is required")
    private String usrName;
	
    @NotBlank(message = "Fence name is required")
    private String fenceName; // Matches exact JSON key from Node.js req.body
    
    @NotNull(message = "Fencing boundary is required")
    private List<List<Double>> fencingBoundary; // Will accept the JSON array as a String (mapped to jsonb in DB)

}
