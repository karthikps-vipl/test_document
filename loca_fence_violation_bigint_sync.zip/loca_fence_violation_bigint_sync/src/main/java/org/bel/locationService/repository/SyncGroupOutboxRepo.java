package org.bel.locationService.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.bel.locationService.entity.SyncGroupOutbox;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SyncGroupOutboxRepo extends JpaRepository<SyncGroupOutbox, Long> {
	@Query("SELECT s FROM SyncGroupOutbox s WHERE s.status='PENDING' OR (s.status='FAILED' AND (s.nextRetryAt IS NULL OR s.nextRetryAt<=:now)) ORDER BY s.createdAt")
	List<SyncGroupOutbox> findEventsToProcess(@Param("now") LocalDateTime now);
}
