package org.bel.locationService.sync;

import org.springframework.context.ApplicationEvent;

public class SyncWakeupEvent extends ApplicationEvent {
    public SyncWakeupEvent(Object source) {
        super(source);
    }
}
