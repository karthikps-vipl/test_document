package org.bel.locationService.dto.response;

import org.bel.locationService.entity.LaaGisFencing;
import org.bel.locationService.entity.MdmUser;

import com.fasterxml.jackson.annotation.JsonRawValue;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FencingListResponse {
	private Long id;
	private String fenceName;
	private Integer fenceStatus;

	@JsonRawValue // <-- This ensures the String outputs as pure JSON, not an escaped string
    private String fencingBoundary;
	private Long mdmUserId;
	private Integer mdmRoleId;
	private Integer sortOrder;
	
	public FencingListResponse(LaaGisFencing fence, MdmUser user) {
        this.id = fence.getId();
        this.fenceName = fence.getFenceName();
        this.fenceStatus = fence.getFenceStatus();
        this.fencingBoundary = fence.getFencingBoundary();
        this.mdmUserId = fence.getMdmUser().getId();
        
        // Populate user/role details safely
        if (user != null) {
            this.mdmRoleId = user.getMdmRole().getId();
        }
    }
}
