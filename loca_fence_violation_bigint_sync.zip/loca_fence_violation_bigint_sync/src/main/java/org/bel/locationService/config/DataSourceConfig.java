package org.bel.locationService.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceConfig {

    // --- PRIMARY DATA SOURCE CONFIG ---
    @Value("${spring.datasource.url}")
    private String mainUrl;
    @Value("${spring.datasource.username}")
    private String mainUsername;
    @Value("${spring.datasource.password}")
    private String mainPassword;

    // --- ROUTING DATA SOURCE CONFIG ---
    @Value("${routing.datasource.url}")
    private String routingUrl;
    @Value("${routing.datasource.username}")
    private String routingUsername;
    @Value("${routing.datasource.password}")
    private String routingPassword;

    // 1. Main DataSource Bean
    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource")
    public DataSource mainDataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(mainUrl);
        dataSource.setUsername(mainUsername);
        dataSource.setPassword(mainPassword);
        dataSource.setDriverClassName("org.postgresql.Driver");
        return dataSource;
    }

    @Bean(name = "mainJdbcTemplate")
    @Primary
    public JdbcTemplate mainJdbcTemplate(@Qualifier("mainDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }

    // 2. Routing (GIS) DataSource Bean
    @Bean(name = "routingDataSource")
    public DataSource routingDataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(routingUrl);
        dataSource.setUsername(routingUsername);
        dataSource.setPassword(routingPassword);
        dataSource.setDriverClassName("org.postgresql.Driver");
        return dataSource;
    }

    @Bean(name = "routingJdbcTemplate")
    public JdbcTemplate routingJdbcTemplate(@Qualifier("routingDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}