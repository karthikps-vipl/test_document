package org.bel.locationService.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddShareRequest {
	@NotNull(message = "User ID is required")
    private Long userId;

    @NotBlank(message = "Username is required")
    private String usrName;

    @NotNull(message = "Shared User ID is required")
    private Long sharedMdmUserId;

    @NotNull(message = "Shared location is required")
    private LocationCoordinates sharedLocation;

    @Data
    public static class LocationCoordinates {
        private Double latitude;
        private Double longitude;
    }
}
