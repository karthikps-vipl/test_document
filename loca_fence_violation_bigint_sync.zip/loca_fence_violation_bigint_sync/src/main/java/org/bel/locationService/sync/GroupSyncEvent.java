package org.bel.locationService.sync;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GroupSyncEvent {
    private String action; // CREATE, EDIT, STATUS_CHANGE, INVITE_STATUS
    private Object payload; // e.g., AddGroupRequest or EditGroupRequest
    private String groupUuid; // Included for Edit/Status changes
    private Long targetUserId;
}
