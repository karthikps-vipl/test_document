package org.bel.locationService.dto.response;

import java.time.Instant;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LatestLocationResponse {
	private Long mdm_ue__id;
	private Long mdm_user__id; // mdm_user__id
	private String service_id; // service_id
	private String usr_name; // usr_name
	private String mdm_node__id; // mdm_node__id
	private Instant created_time; // created_time
	private String device_id; // device_id
	private String device_name;// device_name
	private Integer userTypeId; // usr_type
	private String usr_type; // usr_type
	private String symbol;
	private Integer mdm_role__id; // mdm_role_id
	private String role_name; // role_name

	private Geom geom;

	@Data
	@Builder
	public static class Geom {
		private String type;
		private Crs crs;
		private List<Double> coordinates;
	}

	@Data
	@Builder
	public static class Crs {
		private String type;
		private Properties properties;
	}

	@Data
	@Builder
	public static class Properties {
		private String name;
	}
}
