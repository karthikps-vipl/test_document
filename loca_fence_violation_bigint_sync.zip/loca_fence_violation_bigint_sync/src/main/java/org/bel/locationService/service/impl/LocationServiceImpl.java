package org.bel.locationService.service.impl;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

import org.bel.locationService.dto.request.AddLocationRequest;
import org.bel.locationService.dto.request.AddShareRequest;
import org.bel.locationService.dto.request.LocationHistoryRequest;
import org.bel.locationService.dto.response.DeviceResponse;
import org.bel.locationService.dto.response.LatestLocationProjection;
import org.bel.locationService.dto.response.LatestLocationResponse;
import org.bel.locationService.dto.response.LocationHistoryResponse;
import org.bel.locationService.dto.response.MdmUserResponse;
import org.bel.locationService.dto.response.ShareListResponse;
import org.bel.locationService.dto.response.ShortestPathResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.entity.LaaGisLocationShare;
import org.bel.locationService.entity.LaaUeLocationHist;
import org.bel.locationService.entity.MdmRole;
import org.bel.locationService.entity.MdmUe;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.entity.MdmUserUeMapping;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaGisLocationShareRepository;
import org.bel.locationService.repository.LaaUeLocationHistRepostiory;
import org.bel.locationService.repository.MdmRoleRepository;
import org.bel.locationService.repository.MdmUeRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.repository.MdmUserUeMappingRepository;
import org.bel.locationService.repository.UserLocationLatestRepository;
import org.bel.locationService.service.LocationService;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.PrecisionModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class LocationServiceImpl implements LocationService {

	private final NodeRegistryService nodeRegistryService;
	private final LaaUeLocationHistRepostiory histRepostiory;
	private final MdmUserRepository mdmUserRepository;
	private final MdmUserUeMappingRepository userUeMappingRepository;
	private final MdmUeRepository ueRepository;
	private final LaaGisLocationShareRepository shareRepository;
	private final JdbcTemplate jdbcTemplate;
	private final UserLocationLatestRepository latestRepository;
	private final MdmRoleRepository roleRepository;

	@Qualifier("routingJdbcTemplate")
	private final JdbcTemplate routingJdbcTemplate;

	@Transactional
	public SingleResponse<String> addLocationHistory(AddLocationRequest request) {
		LaaUeLocationHist history = new LaaUeLocationHist();

		// 1. Map Relationships (Fetch the actual entities from DB)
		history.setMdmUser(mdmUserRepository.findById(request.getMdmUserId())
				.orElseThrow(() -> new RuntimeException("User not found")));

		history.setMdmUe(
				ueRepository.findById(request.getMdmUeId()).orElseThrow(() -> new RuntimeException("UE not found")));

		log.info("DEBUG: Current node is :{}",nodeRegistryService.getCurrentNode());
		log.info("DEBUG: Current node Id is :{}",nodeRegistryService.getCurrentNode().getNodeId());
		history.setNode(nodeRegistryService.getCurrentNode());

		// 2. Set Coordinates
		history.setLatitude(request.getLatitude());
		history.setLongitude(request.getLongitude());
		history.setCreatedTime(request.getCreatedTime());

		// 3. Handle Spatial Data (The "geom" field)
		GeometryFactory geometryFactory = new GeometryFactory(new PrecisionModel(), 4326);
		Point point = geometryFactory.createPoint(new Coordinate(request.getLongitude(), request.getLatitude()));
		history.setGeom(point);

		// 4. Save using Repository
		histRepostiory.save(history);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	public SingleResponse<List<LocationHistoryResponse>> getLocationHistory(LocationHistoryRequest request) {

		LocalDateTime fromDate = request.getFromDateAndTime();
		LocalDateTime toDate = request.getToDateAndTime();
		Long userId = request.getUserId();

		if (toDate.isBefore(fromDate)) {
			throw new CustomException(null, CustomStatus.INVALID_DATE_RANGE, 400);
		}

		// 2. Convert LocalDateTime to OffsetDateTime
		// We add the system default offset (e.g., +05:30)
		OffsetDateTime fromOffset = fromDate.atZone(ZoneId.systemDefault()).toOffsetDateTime();
		OffsetDateTime toOffset = toDate.atZone(ZoneId.systemDefault()).toOffsetDateTime();
		// 2. Use the Repository instead of JdbcTemplate
		// This returns the actual Entity objects, making it much easier to use the data
		List<LaaUeLocationHist> historyList = histRepostiory
				.findByMdmUserIdAndCreatedTimeBetweenOrderByCreatedTimeAsc(request.getUserId(), fromOffset, toOffset);
		MdmUser user = mdmUserRepository.findById(userId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));

		List<LocationHistoryResponse> response = historyList.stream().map(history -> {
			LocationHistoryResponse historyResponse = new LocationHistoryResponse();

			MdmUserResponse userResponse = new MdmUserResponse();
			userResponse.setUserId(user.getId());
			userResponse.setRoleId(user.getMdmRole().getId());
			userResponse.setRoleName(user.getMdmRole().getRoleName());
			userResponse.setServiceId(user.getServiceId());
			userResponse.setUserName(user.getUsrName());
			userResponse.setUserType(user.getMdmUserType().getUsrType());
			DeviceResponse deviceResponse = new DeviceResponse();
			MdmUserUeMapping userUeMapping = userUeMappingRepository.findMdmUserUeMappingByMdmUserId(userId)
					.orElseThrow(() -> new CustomException(CustomStatus.UE_MAPPING_NOT_FOUND, 404));

			MdmUe device = ueRepository.findById(userUeMapping.getMdmUeId().getId())
					.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));

			deviceResponse.setDeviceId(device.getDeviceId());
			deviceResponse.setDeviceName(device.getDeviceName());
			deviceResponse.setMdmUeId(device.getId());
			userResponse.setDeviceResponse(deviceResponse);

			historyResponse.setUserResponse(userResponse);
			historyResponse.setLongitude(history.getLongitude());
			historyResponse.setLatitude(history.getLatitude());
			historyResponse.setCreatedTime(history.getCreatedTime());

			return historyResponse;
		}).toList();

		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<List<LatestLocationResponse>> getLatestLocation(Long callerUserId, String roleId) {
		Integer sortOrder = getSortOrderBasedOnRoleId(roleId);
		log.info("[GET_LATEST_LOCATION] Caller UserId: {}, SortOrder: {}", callerUserId, sortOrder);

		// Fallback default sort order to 4 (group level restricted view) if null
		int effectiveSortOrder = (sortOrder != null) ? sortOrder : 4;

		List<LatestLocationProjection> records = latestRepository.findLatestLocations(callerUserId, effectiveSortOrder);

		List<LatestLocationResponse> responses = records.stream().map(this::mapToResponse).collect(Collectors.toList());

		return new SingleResponse<>(responses, CustomStatus.SUCCESS);
	}

	private LatestLocationResponse mapToResponse(LatestLocationProjection p) {
		 // 1. Construct the GeoJSON object if coordinates exist
        LatestLocationResponse.Geom geomObj = null;
        if (p.getLatitude() != null && p.getLongitude() != null) {
            geomObj = LatestLocationResponse.Geom.builder()
                    .type("Point")
                    .crs(LatestLocationResponse.Crs.builder()
                            .type("name")
                            .properties(LatestLocationResponse.Properties.builder()
                                    .name("EPSG:4326")
                                    .build())
                            .build())
                    // GeoJSON format mandates [Longitude, Latitude] order
                    .coordinates(List.of(p.getLongitude(), p.getLatitude()))
                    .build();
        }

        // 2. Build and return the full response
        return LatestLocationResponse.builder()
        		.mdm_ue__id(p.getMdmUeId())
                .mdm_user__id(p.getUserId())
                .service_id(p.getServiceId())
                .usr_name(p.getUserName())
                .mdm_node__id(p.getNodeId())
//                .nodeName(p.getNodeName())
                .created_time(p.getLocationTimestamp())
                .device_id(p.getDeviceId())
                .device_name(p.getDeviceName())
                .userTypeId(p.getUserTypeId())
                .usr_type(p.getUserType())
                .symbol(p.getSymbol())
                .mdm_role__id(p.getRoleId())
                .role_name(p.getRoleName())
                .geom(geomObj) // Attach the newly created nested object
                .build();
	}

	@Override
	@Transactional
	public SingleResponse<String> addShare(AddShareRequest request) {
		MdmUser sender = mdmUserRepository.findById(request.getUserId())
				.orElseThrow(() -> new CustomException(null, CustomStatus.SENDER_ACCOUNT_NOT_FOUND, 404));

		MdmUser recipient = mdmUserRepository.findById(request.getUserId())
				.orElseThrow(() -> new CustomException(null, CustomStatus.RECIPIENT_ACCOUNT_NOT_FOUND, 404));

		LaaGisLocationShare share = new LaaGisLocationShare();
		share.setMdmUser(sender);
		share.setSharedMdmUser(recipient);
		share.setCreatedBy(request.getUsrName());

		// Convert the incoming Lat/Lng JSON into a PostGIS Point
		share.setLocation(request.getSharedLocation().getLatitude(), request.getSharedLocation().getLongitude());

		shareRepository.save(share);

		return new SingleResponse<>("Your location has been shared", CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<List<ShareListResponse>> shareList(Long userId) {
		List<LaaGisLocationShare> shares = shareRepository.findByMdmUser_IdOrderByCreatedAtDesc(userId);

		List<ShareListResponse> response = shares.stream().map(ShareListResponse::new).collect(Collectors.toList());

		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> deleteShare(Integer shareId) {
		LaaGisLocationShare share = shareRepository.findById(shareId)
				.orElseThrow(() -> new CustomException("Shared location not found for ID " + shareId,
						CustomStatus.LOCATION_NOT_FOUND, 404));

		shareRepository.delete(share);

		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<ShortestPathResponse> findShortestPath(Double startLon, Double startLat, Double endLon,
			Double endLat) {
		
		String targetDb = "tcs_laa";
//		mainDataSource.queryForList(
//			    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = ? AND pid <> pg_backend_pid()",targetDb); 
		
		// 1. Find Nearest Start Node
		String startNodeQuery = """
				SELECT id FROM roads_topology_vertices_pgr
				ORDER BY the_geom <-> ST_SetSRID(ST_MakePoint(?, ?), 4326)
				LIMIT 1
				""";
		Integer startNodeId;
		try {
			startNodeId = routingJdbcTemplate.queryForObject(startNodeQuery, Integer.class, startLon, startLat);
		} catch (EmptyResultDataAccessException e) {
			throw new CustomException("Could not find nearest start node", CustomStatus.START_NODE_NOT_FOUND, 404);
		}

		// 2. Find Nearest End Node
		String endNodeQuery = """
				SELECT id FROM roads_topology_vertices_pgr
				ORDER BY the_geom <-> ST_SetSRID(ST_MakePoint(?, ?), 4326)
				LIMIT 1
				""";
		Integer endNodeId;
		try {
			endNodeId = routingJdbcTemplate.queryForObject(endNodeQuery, Integer.class, endLon, endLat);
		} catch (EmptyResultDataAccessException e) {
			throw new CustomException("Could not find nearest end node", CustomStatus.END_NODE_NOT_FOUND, 404);
		}

		// 3. Execute pgRouting Dijkstra Algorithm
		String shortestPathQuery = """
				WITH route_segments AS (
				  SELECT DISTINCT ON (route.path_seq, route.edge)
				    route.path_seq,
				    route.node,
				    route.edge,
				    r.source,
				    r.target,
				    r.geom,
				    CASE
				      WHEN route.node = r.source THEN r.geom
				      ELSE ST_Reverse(r.geom)
				    END AS directed_geom
				  FROM pgr_dijkstra(
				    'SELECT id, source::integer, target::integer, cost, reverse_cost FROM roads_topology',
				    ?::integer,
				    ?::integer,
				    true
				  ) AS route
				  JOIN roads_topology r ON route.edge = r.id
				  WHERE route.edge > 0
				  ORDER BY route.path_seq, route.edge
				)
				SELECT
				  ST_AsGeoJSON(ST_MakeLine(directed_geom ORDER BY path_seq)) as geojson,
				  COUNT(*) as segment_count
				FROM route_segments;
				""";

		return routingJdbcTemplate.query(shortestPathQuery, rs -> {
			if (rs.next()) {
				String geojson = rs.getString("geojson");
				Integer segmentCount = rs.getInt("segment_count");

				if (geojson == null) {
					throw new CustomException("No route found between coordinates", CustomStatus.ROUTE_NOT_FOUND, 404);
				}

				ShortestPathResponse response = new ShortestPathResponse();
				response.setFromNode(startNodeId);
				response.setToNode(endNodeId);
				response.setRouteGeojson(geojson);
				response.setTotalSegments(segmentCount);

				log.info("Shortest path found. Nodes: {} -> {}. Segments: {}", startNodeId, endNodeId, segmentCount);

				return new SingleResponse<>(response, CustomStatus.SUCCESS);
			} else {
				throw new CustomException("No route found", CustomStatus.ROUTE_NOT_FOUND, 404);
			}
		}, startNodeId, endNodeId);
	}

	public Integer getSortOrderBasedOnRoleId(String roleId) {
		MdmRole role = roleRepository.findById(Integer.parseInt(roleId))
				.orElseThrow(() -> new CustomException(CustomStatus.ROLE_NOT_FOUND, 404));
		return role.getSortOrder();
	}
}
