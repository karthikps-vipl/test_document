package org.bel.locationService.dto.response;

import com.fasterxml.jackson.annotation.JsonRawValue;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FenceCreationResponse {
	private Long id;
    private String fenceName;
    private Integer fenceStatus;
    
    @JsonRawValue // Ensures the string is returned to the frontend as a pure JSON array, not an escaped string
    private String fencingBoundary;
    
    private Long mdmUserId;
    private String createdBy;
}
