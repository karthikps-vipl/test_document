package org.bel.locationService.dto.response;

import java.util.UUID;

public record SyncAckResponse(UUID eventId, String status, String nodeId) {
}
