package org.bel.locationService.repository;

import java.time.OffsetDateTime;
import java.util.List;

import org.bel.locationService.dto.response.LocationTrackingProjection;
import org.bel.locationService.entity.LaaUeLocationHist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaUeLocationHistRepostiory extends JpaRepository<LaaUeLocationHist, Integer> {
	List<LaaUeLocationHist> findByMdmUserIdAndCreatedTimeBetweenOrderByCreatedTimeAsc(Long mdmUeId,
			OffsetDateTime startTime, OffsetDateTime endTime);

	@Query(value = """
			SELECT DISTINCT ON (h.mdm_ue_id, h.mdm_user_id)
			    h, u, e, ut, r
			FROM laa_ue_location_hist h
			JOIN mdm_user u ON u.id = h.mdm_user_id
			JOIN mdm_ue e ON e.id = h.mdm_ue_id
			JOIN mdm_user_type ut ON ut.id = u.mdm_user_type_id
			JOIN mdm_role r ON r.id = u.mdm_role_id
			WHERE h.mdm_ue_id != :ueId
			  AND h.mdm_user_id != :userId
			  AND h.geom IS NOT NULL
			  AND (:sortOrderCondition)
			ORDER BY h.mdm_ue_id, h.mdm_user_id, h.created_time DESC
			""", nativeQuery = true)
	List<Object[]> getLatestLocationsByCriteria(@Param("ueId") Integer ueId, 
												@Param("userId") Long userId, 
												@Param("sortOrderCondition") String conditionPlaceholder);
	
//	@Query(value = "Select * from tcs_laa.laa_ue_location_hist where id = :userId", nativeQuery = true)
	@Query(value = "SELECT * FROM tcs_laa.laa_ue_location_hist " +
            "WHERE mdm_user__id = :userId " + 
            "ORDER BY created_at DESC LIMIT 1", 
    nativeQuery = true)
	LaaUeLocationHist findUserLocationHistByUserId(Integer userId);
	
	@Query(value = "SELECT DISTINCT ON (h.mdm_ue__id, h.mdm_user__id) " +
	           "h.id as id, h.mdm_ue__id as mdm_ue__id, h.created_time as created_time, " +
	           "h.node as node, h.mdm_user__id as mdm_user__id, " +
	           "u.service_id as service_id, u.usr_name as usr_name, " +
	           "e.device_id as device_id, e.device_name as device_name, " +
	           "ut.usr_type as usr_type, ut.symbol as symbol, " +
	           "u.mdm_role__id as mdm_role__id, r.role_name as role_name, " +
	           "l.latitude as latitude, l.longitude as longitude " + // JOINING LATEST TABLE HERE
	           "FROM tcs_laa.laa_ue_location_hist h " +
	           "INNER JOIN tcs_mdm.mdm_user u ON u.id = h.mdm_user__id " +
	           "INNER JOIN tcs_mdm.mdm_ue e ON e.id = h.mdm_ue__id " +
	           "INNER JOIN tcs_mdm.mdm_user_type ut ON ut.id = u.mdm_user_type__id " +
	           "INNER JOIN tcs_mdm.mdm_role r ON r.id = u.mdm_role__id " +
	           "INNER JOIN tcs_laa.user_location_latest l ON l.user_id = h.mdm_user__id " + // The link
	           "WHERE h.mdm_ue__id != :ueId AND h.mdm_user__id != :mdmUserId " +
	           "AND h.geom IS NOT NULL " +
	           "ORDER BY h.mdm_ue__id, h.mdm_user__id, h.created_time DESC", 
	           nativeQuery = true)
	    List<LocationTrackingProjection> findTrackingLocations(
	        @Param("ueId") Integer ueId, 
	        @Param("mdmUserId") Integer mdmUserId
	    );
}
