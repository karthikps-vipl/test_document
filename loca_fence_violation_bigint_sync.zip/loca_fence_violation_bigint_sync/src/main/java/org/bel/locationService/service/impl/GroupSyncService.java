package org.bel.locationService.service.impl;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.bel.locationService.client.NotificationClient;
import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.dto.request.AddGroupRequest;
import org.bel.locationService.dto.request.ChangeGroupStatusRequest;
import org.bel.locationService.dto.request.EditGroupRequest;
import org.bel.locationService.dto.request.GroupInviteStatusRequest;
import org.bel.locationService.dto.request.NotificationPayload;
import org.bel.locationService.dto.response.SyncAckResponse;
import org.bel.locationService.entity.LaaGroupTracking;
import org.bel.locationService.entity.LaaGroupTrackingDtl;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.entity.ProcessedSyncEvent;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaGroupTrackingDtlRepository;
import org.bel.locationService.repository.LaaGroupTrackingRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.repository.ProcessedSyncEventRepository;
import org.bel.locationService.sync.GroupSyncEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class GroupSyncService {

	private final ProcessedSyncEventRepository processedRepo;
	private final NodeRegistryService nodeRegistryService;
	private final ObjectMapper mapper;
	private final LaaGroupTrackingRepository groupTrackingRepository;
	private final MdmUserRepository userRepository;
	private final LaaGroupTrackingDtlRepository groupTrackingDtlRepository;
	private final NotificationClient notificationClient;

	@Transactional
	public SyncAckResponse processSync(String eventIdStr, GroupSyncEvent event) {
		UUID eventId = UUID.fromString(eventIdStr);
		String current = nodeRegistryService.getCurrentNodeId();

		if (processedRepo.existsById(eventId)) {
			return new SyncAckResponse(eventId, AppConstants.ACKNOWLEDGED, current);
		}

		try {
			log.info("Processing Sync Action: {} for Group UUID: {}", event.getAction(), event.getGroupUuid());
			switch (event.getAction()) {
			case "GROUP_CREATE":
				syncCreateGroup(event);
				break;
			case "GROUP_EDIT":
				syncEditGroup(event);
				break;
			case "GROUP_STATUS":
				syncChangeStatus(event);
				break;
			case "INVITE_STATUS":
				syncInviteStatus(event);
				break;
			default:
				log.warn("Unknown sync action: {}", event.getAction());
			}
		} catch (Exception e) {
			log.error("Sync processing failed for event {}", eventId, e);
		}

		processedRepo.save(ProcessedSyncEvent.builder().eventId(eventId).eventType(event.getAction())
				.sourceNodeId(current).processedAt(OffsetDateTime.now()).build());

		return new SyncAckResponse(eventId, AppConstants.ACKNOWLEDGED, current);
	}

	private void syncCreateGroup(GroupSyncEvent event) {
		AddGroupRequest request = mapper.convertValue(event.getPayload(), AddGroupRequest.class);

		MdmUser creator = userRepository.findById(request.getMdm_user__id()).orElseThrow();
		LaaGroupTracking group = new LaaGroupTracking();

		// NO MORE ID CLASHES: Only save the UUID, let PostgreSQL generate the int ID
		group.setGroupUuid(event.getGroupUuid());
		group.setGroupName(request.getGroup_name());
		group.setGroupStats(request.getGroup_stats());
		group.setMdmUser(creator);
		group.setExpiryHour(request.getExpiry_hour() != null ? request.getExpiry_hour() : 96);
		group.setCreatedBy(AppConstants.SYSTEM_SYNC);

		List<LaaGroupTrackingDtl> detailsList = new ArrayList<>();
		if (request.getMembers() != null) {
			for (AddGroupRequest.GroupMemberRequest memberReq : request.getMembers()) {
				MdmUser memberUser = userRepository.getReferenceById(memberReq.getId());
				LaaGroupTrackingDtl detail = new LaaGroupTrackingDtl();
				detail.setMdmUser(memberUser);
				detail.setLaaGroupTracking(group);
				detail.setIsObserver(memberReq.getIs_observer() != null ? memberReq.getIs_observer() : 0);
				detail.setStatus(AppConstants.INVITED);
				detail.setCreatedBy(AppConstants.SYSTEM_SYNC);
				detailsList.add(detail);
			}
		}

		group.setDetails(detailsList);
		groupTrackingRepository.save(group);

		if (request.getMembers() != null) {
			request.getMembers().forEach(member -> {
				NotificationPayload payload = new NotificationPayload();
				payload.setTargetUserId(member.getId());
				payload.setEventType("groupUpdate");
				payload.setPayload("You have been invited to join '" + group.getGroupName() + "'");
				notificationClient.sendPrivateNotification(payload);
			});
		}
	}

	private void syncEditGroup(GroupSyncEvent event) {
		LaaGroupTracking group = groupTrackingRepository.findByGroupUuid(event.getGroupUuid()).orElse(null);

		if (group == null)
			return;

		EditGroupRequest request = mapper.convertValue(event.getPayload(), EditGroupRequest.class);

		updateGroupMetadata(group, request);
		synchronizeGroupMembers(group, request);
		handleActiveGroupCleanup(group, request);

		groupTrackingRepository.save(group);

	    sendSyncNotifications(group.getGroupName(), request.getMembers());
	}

	private void syncChangeStatus(GroupSyncEvent event) {
		LaaGroupTracking group = groupTrackingRepository.findByGroupUuid(event.getGroupUuid()).orElse(null);
		if (group != null) {
			ChangeGroupStatusRequest request = mapper.convertValue(event.getPayload(), ChangeGroupStatusRequest.class);
			group.setGroupStats(request.getStatus());
			group.setUpdatedBy(AppConstants.SYSTEM_SYNC);
			groupTrackingRepository.save(group);
		}
	}

	private void syncInviteStatus(GroupSyncEvent event) {
		// Read the target user ID specifically tracked for invites
		Long targetUserId = event.getTargetUserId();

		LaaGroupTrackingDtl grpDetail = groupTrackingDtlRepository
				.findByLaaGroupTrackingGroupUuidAndMdmUser_Id(event.getGroupUuid(), targetUserId)
				.orElseThrow(() -> new CustomException("Invitation record not found for this group",
						CustomStatus.USER_NOT_FOUND, 404));
		if (grpDetail != null) {
			GroupInviteStatusRequest request = mapper.convertValue(event.getPayload(), GroupInviteStatusRequest.class);
			grpDetail.setStatus(request.getStatus());
			grpDetail.setUpdatedBy(AppConstants.SYSTEM_SYNC);
			groupTrackingDtlRepository.save(grpDetail);
		}
	}

	private void updateGroupMetadata(LaaGroupTracking group, EditGroupRequest request) {
		group.setGroupName(request.getGroup_name());
		group.setGroupStats(request.getGroup_stats());
		group.setExpiryHour(request.getExpiry_hour() != null ? request.getExpiry_hour() : 96);
		group.setUpdatedBy(AppConstants.SYSTEM_SYNC);

		if (!group.getMdmUser().getId().equals(request.getMdm_user__id())) {
			group.setMdmUser(userRepository.getReferenceById(request.getMdm_user__id()));
		}
	}

	private void synchronizeGroupMembers(LaaGroupTracking group, EditGroupRequest request) {
		if (request.getMembers() == null)
			return;

		List<LaaGroupTrackingDtl> existingDetails = group.getDetails();
		Map<Long, LaaGroupTrackingDtl> existingMap = existingDetails.stream()
				.collect(Collectors.toMap(d -> d.getMdmUser().getId(), d -> d));

		for (EditGroupRequest.GroupMemberRequest incoming : request.getMembers()) {
			LaaGroupTrackingDtl existing = existingMap.get(incoming.getId());
			if (existing != null) {
				updateMember(existing, incoming);
			} else {
				addNewMember(group, existingDetails, incoming);
			}
		}
	}

	private void updateMember(LaaGroupTrackingDtl existing, EditGroupRequest.GroupMemberRequest incoming) {
		existing.setIsObserver(incoming.getIs_observer() != null ? incoming.getIs_observer() : 0);
		existing.setUpdatedBy(AppConstants.SYSTEM_SYNC);
	}

	private void addNewMember(LaaGroupTracking group, List<LaaGroupTrackingDtl> details,
			EditGroupRequest.GroupMemberRequest incoming) {
		LaaGroupTrackingDtl newDetail = new LaaGroupTrackingDtl();
		newDetail.setMdmUser(userRepository.getReferenceById(incoming.getId()));
		newDetail.setLaaGroupTracking(group);
		newDetail.setIsObserver(incoming.getIs_observer() != null ? incoming.getIs_observer() : 0);
		newDetail.setStatus(AppConstants.INVITED);
		newDetail.setCreatedBy(AppConstants.SYSTEM_SYNC);
		details.add(newDetail);
	}

	private void handleActiveGroupCleanup(LaaGroupTracking group, EditGroupRequest request) {
		if (request.getGroup_stats() != null && request.getGroup_stats() == 1) {
			group.getDetails()
					.removeIf(detail -> groupTrackingDtlRepository
							.existsByMdmUser_IdAndLaaGroupTracking_GroupStatsAndLaaGroupTracking_IdNot(
									detail.getMdmUser().getId(), 1, group.getId()));
		}
	}

	private void sendSyncNotifications(String groupName, List<EditGroupRequest.GroupMemberRequest> members) {
		if (members == null)
			return;
		for (EditGroupRequest.GroupMemberRequest member : members) {
			NotificationPayload payload = new NotificationPayload();
			payload.setTargetUserId(member.getId());
			payload.setEventType("groupUpdate");
			payload.setPayload("Group '" + groupName + "' info was updated.");
			notificationClient.sendPrivateNotification(payload);
		}
	}
}