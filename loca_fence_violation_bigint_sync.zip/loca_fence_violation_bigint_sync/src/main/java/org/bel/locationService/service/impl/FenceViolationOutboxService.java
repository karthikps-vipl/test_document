package org.bel.locationService.service.impl;
import java.time.LocalDateTime; import java.util.UUID;
import org.bel.locationService.entity.*; import org.bel.locationService.repository.*; import org.bel.locationService.sync.*;
import org.bel.locationService.constants.AppConstants; import org.bel.locationService.exception.*; import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.util.TimestampBigIntIdGenerator; import org.springframework.context.ApplicationEventPublisher; import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper; import lombok.RequiredArgsConstructor;
@Service @RequiredArgsConstructor
public class FenceViolationOutboxService {
 private final FenceOutboxRepository fenceOutbox; private final ViolationOutboxRepository violationOutbox; private final NodeRegistryService nodes; private final ObjectMapper mapper; private final ApplicationEventPublisher publisher;
 public void enqueueFence(FenceSyncPayload p) { saveFence(p); }
 public void enqueueViolation(ViolationSyncPayload p) { try { LocalDateTime now=LocalDateTime.now(); violationOutbox.save(ViolationOutbox.builder().eventId(UUID.randomUUID()).eventType("VIOLATION_ADD").sourceNodeId(nodes.getCurrentNodeId()).payload(mapper.writeValueAsString(p)).status(AppConstants.PENDING).retryCount(0).createdAt(now).build()); publisher.publishEvent(new FenceViolationSyncWakeupEvent()); } catch(Exception e){throw new IllegalStateException("Unable to queue violation sync",e);} }
 private void saveFence(FenceSyncPayload p) { try { LocalDateTime now=LocalDateTime.now(); fenceOutbox.save(FenceOutbox.builder().eventId(UUID.randomUUID()).eventType("FENCE_"+p.getAction()).sourceNodeId(nodes.getCurrentNodeId()).payload(mapper.writeValueAsString(p)).status(AppConstants.PENDING).retryCount(0).createdAt(now).build()); publisher.publishEvent(new FenceViolationSyncWakeupEvent()); } catch(Exception e){throw new IllegalStateException("Unable to queue fence sync",e);} }
}
