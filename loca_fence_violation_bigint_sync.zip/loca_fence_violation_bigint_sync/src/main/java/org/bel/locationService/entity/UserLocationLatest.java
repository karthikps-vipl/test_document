package org.bel.locationService.entity;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user_location_latest", schema = "tcs_laa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLocationLatest {
	@Id
	@Column(name = "user_id")
	private Long userId;
	
	@Column(name = "node_id", nullable = false)
	private String nodeId;
	
	@Column(nullable = false)
	@Min(-90)
	@Max(90)
	private Double latitude;
	
	@Column(nullable = false)
	@Min(-180)
	@Max(180)
	private Double longitude;
	
	@Column(name = "location_timestamp", nullable = false)
	private OffsetDateTime locationTimestamp;
	
	@Column(name = "location_version", nullable = false)
	private Long locationVersion;
	
	@Column(name = "updated_at", nullable = false)
	private OffsetDateTime updatedAt;
}
