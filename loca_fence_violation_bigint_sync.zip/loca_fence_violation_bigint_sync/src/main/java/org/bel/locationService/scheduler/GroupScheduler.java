package org.bel.locationService.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class GroupScheduler {

    private static final Logger log = LoggerFactory.getLogger(GroupScheduler.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Runs every hour (cron = "0 0 * * * *"). Adjust as needed!
    // To test it every 1 minute, use: @Scheduled(cron = "0 * * * * *")
    @Scheduled(cron = "0 0 * * * *") 
    public void deactivateExpiredGroups() {
        log.info("Checking for expired groups...");

        String query = """
            UPDATE tcs_laa.laa_group_tracking
            SET group_stats = 0
            WHERE group_stats = 1 AND group_stats != 2
              AND NOW() > created_at + (expiry_hour || ' hours')::interval
            RETURNING id;
        """;

        try {
            List<Integer> updatedIds = jdbcTemplate.queryForList(query, Integer.class);
            
            if (!updatedIds.isEmpty()) {
                log.info("{} groups expired and updated to inactive. IDs: {}", updatedIds.size(), updatedIds);
            } else {
                log.info("No expired groups found.");
            }
        } catch (Exception e) {
            log.error("Error deactivating expired groups: ", e);
        }
    }
}
