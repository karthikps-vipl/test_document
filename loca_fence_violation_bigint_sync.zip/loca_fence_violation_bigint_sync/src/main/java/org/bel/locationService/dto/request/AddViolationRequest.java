package org.bel.locationService.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddViolationRequest {
	@NotNull(message = "User ID is required")
    private Long userId;

    @NotBlank(message = "Username is required")
    private String usrName;

    @NotNull(message = "Fence ID is required")
    private Long fenceId;
}
