package org.bel.locationService.repository;

import java.util.UUID;

import org.bel.locationService.entity.ProcessedSyncEvent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcessedSyncEventRepository extends JpaRepository<ProcessedSyncEvent, UUID> {
}
