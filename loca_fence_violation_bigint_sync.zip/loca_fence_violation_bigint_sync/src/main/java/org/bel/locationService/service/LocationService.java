package org.bel.locationService.service;

import java.util.List;

import org.bel.locationService.dto.request.AddLocationRequest;
import org.bel.locationService.dto.request.AddShareRequest;
import org.bel.locationService.dto.request.LocationHistoryRequest;
import org.bel.locationService.dto.response.LatestLocationResponse;
import org.bel.locationService.dto.response.LocationHistoryResponse;
import org.bel.locationService.dto.response.ShareListResponse;
import org.bel.locationService.dto.response.ShortestPathResponse;
import org.bel.locationService.dto.response.SingleResponse;

import jakarta.validation.Valid;

public interface LocationService {

	SingleResponse<String> addLocationHistory(@Valid AddLocationRequest request);

	SingleResponse<List<LocationHistoryResponse>> getLocationHistory(@Valid LocationHistoryRequest request);

	SingleResponse<String> addShare(@Valid AddShareRequest request);

	SingleResponse<List<ShareListResponse>> shareList(Long userId);

	SingleResponse<String> deleteShare(Integer shareId);

	SingleResponse<ShortestPathResponse> findShortestPath(Double startLon, 
														  Double startLat, 
														  Double endLon,
														  Double endLat);

	SingleResponse<List<LatestLocationResponse>> getLatestLocation(Long userId, String roleId);
}
