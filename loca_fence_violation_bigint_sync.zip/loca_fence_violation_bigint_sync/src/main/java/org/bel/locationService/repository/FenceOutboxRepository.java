package org.bel.locationService.repository;
import java.time.LocalDateTime; import java.util.List; import java.util.Optional; import java.util.UUID;
import org.bel.locationService.entity.FenceOutbox; import org.springframework.data.jpa.repository.*; import org.springframework.data.repository.query.Param;
public interface FenceOutboxRepository extends JpaRepository<FenceOutbox,Long> {
 @Query("select e from FenceOutbox e where e.status='PENDING' or (e.status='FAILED' and (e.nextRetryAt is null or e.nextRetryAt<=:now)) order by e.createdAt") List<FenceOutbox> findReady(@Param("now") LocalDateTime now);
 Optional<FenceOutbox> findByEventId(UUID eventId);
}
