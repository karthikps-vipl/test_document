package org.bel.locationService.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.dto.request.AddFenceRequest;
import org.bel.locationService.dto.request.EditFenceRequest;
import org.bel.locationService.dto.response.FenceCreationResponse;
import org.bel.locationService.dto.response.FencingListResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.entity.LaaGisFencing;
import org.bel.locationService.entity.LaaGroupTrackingDtl;
import org.bel.locationService.entity.MdmRole;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaGisFencingRepository;
import org.bel.locationService.repository.LaaGroupTrackingDtlRepository;
import org.bel.locationService.repository.MdmRoleRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.service.GisService;
import org.bel.locationService.sync.FenceSyncPayload;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class GisServiceImpl implements GisService {

	private final LaaGisFencingRepository fencingRepository;
	private final MdmUserRepository userRepository;
	private final ObjectMapper objectMapper;
	private final LaaGroupTrackingDtlRepository groupTrackingDtlRepository;
	private final ModelMapper modelMapper;
	private final MdmRoleRepository roleRepository;
	private final FenceViolationOutboxService syncOutboxService;

	@Override
	@Transactional
	public SingleResponse<List<FencingListResponse>> getFencingList(Long userId, String roleId) {

		Integer sortOrder = getSortOrderBasedOnRoleId(roleId);

		log.info("Fetching fence list for user: {} with sortOrder: {} for roleId: {}", userId, sortOrder, roleId);

		List<LaaGisFencing> fences;
		if (sortOrder < 4) {
			// Super Admin: Fetch all active fences
			fences = fencingRepository.findAllByFenceStatusNotOrderByCreatedAtDesc(2);

		} else if (sortOrder == 4) {
			// Group Admin: Fetch only their own active fences
			fences = fencingRepository.findByMdmUser_IdAndFenceStatusNotOrderByCreatedAtDesc(userId, 2);

		} else {
			// Regular User: Fetch active group owner's active fences
			Optional<LaaGroupTrackingDtl> activeGroup = groupTrackingDtlRepository
					.findFirstByMdmUserIdAndStatusIgnoreCaseAndLaaGroupTracking_GroupStats(userId, AppConstants.ACCEPTED, 1);

			if (activeGroup.isPresent()) {
				Long groupOwnerId = activeGroup.get().getLaaGroupTracking().getMdmUser().getId();
				fences = fencingRepository.findByMdmUser_IdAndFenceStatusNotOrderByCreatedAtDesc(groupOwnerId, 2);
			} else {
				fences = new ArrayList<>();
			}
		}

		List<FencingListResponse> responseList = fences.stream().map(fence -> {
			MdmUser fenceOwner = userRepository.findById(fence.getMdmUser().getId()).orElse(null);
			return new FencingListResponse(fence, fenceOwner);
		}).collect(Collectors.toList());

		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<FenceCreationResponse> addFence(AddFenceRequest request) {

		// 1. Fetch User
		MdmUser user = userRepository.findById(request.getUserId())
				.orElseThrow(() -> new CustomException("Account not found", CustomStatus.ACCOUNT_NOT_FOUND, 404));

		// 2. Validate Statuses
		if (user.getUserStats() == 2) {
			throw new CustomException("User deleted", CustomStatus.ACCOUNT_DELETED, 409);
		}
		if (user.getUserStats() == 0) {
			throw new CustomException("User is deactivated", CustomStatus.USER_DEACTIVATED, 400);
		}

		// 3. Create and Save Fence
		LaaGisFencing fence = new LaaGisFencing();
		fence.setMdmUser(user);
		fence.setFenceName(request.getFence_name());

		try {
			String boundaryJson = objectMapper.writeValueAsString(request.getFencing_boundary());
			fence.setFencingBoundary(boundaryJson);
		} catch (Exception e) {
			throw new CustomException("Invalid boundary format", CustomStatus.INVALID_BOUNDARY_FORMAT, 400);
		}

		fence.setFenceStatus(1); // Default status per your Node.js and Entity logic
		fence.setCreatedBy(request.getUsrName());

		// Note: createdAt and updatedAt are automatically handled by @CreationTimestamp
		// / @UpdateTimestamp in your entity
		fence = fencingRepository.save(fence);
		syncOutboxService.enqueueFence(FenceSyncPayload.builder().action("ADD").fenceId(fence.getId()).userId(user.getId()).createdBy(fence.getCreatedBy()).fenceStatus(fence.getFenceStatus()).fenceName(fence.getFenceName()).fencingBoundary(fence.getFencingBoundary()).build());

		// 4. Build Response
		FenceCreationResponse response = new FenceCreationResponse();
		response.setId(fence.getId());
		response.setFenceName(fence.getFenceName());
		response.setFenceStatus(fence.getFenceStatus());
		response.setFencingBoundary(fence.getFencingBoundary());
		response.setMdmUserId(user.getId());
		response.setCreatedBy(fence.getCreatedBy());

		log.info("Fence '{}' created successfully for user {}", fence.getFenceName(), user.getUsrName());

		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<FencingListResponse> editFence(EditFenceRequest request) {

		// 1. Fetch User
		MdmUser user = userRepository.findById(request.getUserId())
				.orElseThrow(() -> new CustomException("Account not found", CustomStatus.ACCOUNT_NOT_FOUND, 404));

		// 2. Validate Statuses
		if (user.getUserStats() == 2) {
			throw new CustomException("User deleted", CustomStatus.ACCOUNT_DELETED, 409);
		}
		if (user.getUserStats() == 0) {
			throw new CustomException("User is deactivated", CustomStatus.USER_DEACTIVATED, 400);
		}

		// 3. Fetch Existing Fence
		LaaGisFencing fence = fencingRepository.findById(request.getFenceId())
				.orElseThrow(() -> new CustomException(null, CustomStatus.FENCE_NOT_FOUND, 404));

		// 4. Update Fields
		fence.setFenceName(request.getFenceName());

		try {
			String boundaryJson = objectMapper.writeValueAsString(request.getFencingBoundary());
			fence.setFencingBoundary(boundaryJson);
		} catch (Exception e) {
			throw new CustomException("Invalid boundary format", CustomStatus.INVALID_BOUNDARY_FORMAT, 400);
		}

//        fence.setFencingBoundary(request.getFencingBoundary().toString()); // Convert JsonNode back to String for JSONB
		fence.setUpdatedBy(request.getUsrName());

		// Note: mdmUser is NOT updated here because a fence's original creator/owner
		// shouldn't change just because someone else edits it.

		fence = fencingRepository.save(fence);
		syncOutboxService.enqueueFence(FenceSyncPayload.builder().action("EDIT").fenceId(fence.getId()).userId(fence.getMdmUser().getId()).createdBy(fence.getCreatedBy()).updatedBy(fence.getUpdatedBy()).fenceStatus(fence.getFenceStatus()).fenceName(fence.getFenceName()).fencingBoundary(fence.getFencingBoundary()).build());

		// 5. Build Response
		FencingListResponse response = modelMapper.map(fence, FencingListResponse.class);

		log.info("Fence '{}' updated successfully by user {}", fence.getFenceName(), request.getUsrName());

		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> deleteFence(Long fenceId) {

		// 1. Fetch Existing Fence
		LaaGisFencing fence = fencingRepository.findById(fenceId).orElseThrow(
				() -> new CustomException("Fence not found for ID: " + fenceId, CustomStatus.FENCE_NOT_FOUND, 404));

		if (fence.getFenceStatus() != null && fence.getFenceStatus() == 2) {
			throw new CustomException("Fence is already deleted", CustomStatus.BAD_REQUEST, 400);
		}

		String deletedName = fence.getFenceName();

		// 2. Perform Soft Delete
		fence.setFenceStatus(2); // 2 = Deleted
		fencingRepository.save(fence);
		syncOutboxService.enqueueFence(FenceSyncPayload.builder().action("DELETE").fenceId(fence.getId()).userId(fence.getMdmUser().getId()).createdBy(fence.getCreatedBy()).updatedBy(fence.getUpdatedBy()).fenceStatus(fence.getFenceStatus()).fenceName(fence.getFenceName()).fencingBoundary(fence.getFencingBoundary()).build());

		log.info("Fence '{}' soft-deleted successfully", deletedName);

		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	public Integer getSortOrderBasedOnRoleId(String roleId) {
		MdmRole role = roleRepository.findById(Integer.parseInt(roleId))
				.orElseThrow(() -> new CustomException(CustomStatus.ROLE_NOT_FOUND, 404));
		return role.getSortOrder();
	}
}
