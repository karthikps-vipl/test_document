package org.bel.locationService.repository;

import org.bel.locationService.entity.MdmRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmRoleRepository extends JpaRepository<MdmRole, Integer> {

}
