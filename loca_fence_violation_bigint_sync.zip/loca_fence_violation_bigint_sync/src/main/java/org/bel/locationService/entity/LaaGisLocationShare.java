package org.bel.locationService.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "laa_gis_location_share", schema = "tcs_laa")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LaaGisLocationShare {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mdm_user__id", nullable = false)
    private MdmUser mdmUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shared_mdm_user__id", nullable = false)
    private MdmUser sharedMdmUser;

    @Column(name = "shared_location", columnDefinition = "geometry(Point,4326)")
    private Point sharedLocation;

    @Column(name = "created_by", length = 50, nullable = false)
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_by", length = 50)
    private String updatedBy;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updateAt;
    
    @Column(name = "share_status", nullable = false)
    private Integer shareStatus = 1;
    
    // Helper method to set Point from Lat/Lng
    public void setLocation(Double latitude, Double longitude) {
        GeometryFactory geometryFactory = new GeometryFactory();
        this.sharedLocation = geometryFactory.createPoint(new Coordinate(longitude, latitude));
        this.sharedLocation.setSRID(4326);
    }
}