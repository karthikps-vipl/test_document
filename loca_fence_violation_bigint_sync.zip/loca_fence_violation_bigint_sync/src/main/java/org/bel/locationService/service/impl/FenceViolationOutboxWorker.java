package org.bel.locationService.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.entity.*;
import org.bel.locationService.repository.*;
import org.bel.locationService.sync.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class FenceViolationOutboxWorker {
    private final FenceOutboxRepository fenceOutbox;
    private final ViolationOutboxRepository violationOutbox;
    private final FenceOutboxDeliveryRepository fenceDeliveries;
    private final ViolationOutboxDeliveryRepository violationDeliveries;
    private final NodeRegistryService nodeRegistry;
    private final RestClient restClient;
    private final ObjectMapper mapper;
    private final AtomicBoolean running = new AtomicBoolean(false);

    @Async("syncExecutor")
    @EventListener
    public void wake(FenceViolationSyncWakeupEvent event) { process(); }

    @Scheduled(fixedDelayString = "${sync.fence-violation.fixed-delay-ms:30000}")
    public void process() {
        if (!running.compareAndSet(false, true)) return;
        try {
            fenceOutbox.findReady(LocalDateTime.now()).stream().limit(100).forEach(this::sendFence);
            violationOutbox.findReady(LocalDateTime.now()).stream().limit(100).forEach(this::sendViolation);
        } finally { running.set(false); }
    }

    private void sendFence(FenceOutbox event) {
        List<NodeRegistry> targets = nodeRegistry.getOtherActiveNodes();
        for (NodeRegistry target : targets) {
            FenceOutboxDelivery delivery = fenceDeliveries.findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
                .orElseGet(() -> fenceDeliveries.save(FenceOutboxDelivery.builder().eventId(event.getEventId()).targetNodeId(target.getNodeId()).status(AppConstants.PENDING).retryCount(0).createdAt(LocalDateTime.now()).build()));
            if (AppConstants.ACKNOWLEDGED.equals(delivery.getStatus()) || waitRetry(delivery.getStatus(), delivery.getNextRetryAt())) continue;
            try {
                FenceSyncPayload payload = mapper.readValue(event.getPayload(), FenceSyncPayload.class);
                restClient.post().uri(url(target, "/internal/sync/fence")).body(payload).retrieve().toBodilessEntity();
                delivery.setStatus(AppConstants.ACKNOWLEDGED); delivery.setAcknowledgedAt(LocalDateTime.now()); delivery.setLastError(null); delivery.setNextRetryAt(null);
            } catch (Exception ex) { fail(delivery, ex); }
            fenceDeliveries.save(delivery);
        }
        boolean complete = targets.stream().allMatch(n -> fenceDeliveries.findByEventIdAndTargetNodeId(event.getEventId(), n.getNodeId()).map(d -> AppConstants.ACKNOWLEDGED.equals(d.getStatus())).orElse(false));
        event.setStatus(complete ? "SENT" : AppConstants.FAILED);
        event.setNextRetryAt(complete ? null : LocalDateTime.now().plusSeconds(30));
        fenceOutbox.save(event);
    }

    private void sendViolation(ViolationOutbox event) {
        List<NodeRegistry> targets = nodeRegistry.getOtherActiveNodes();
        for (NodeRegistry target : targets) {
            ViolationOutboxDelivery delivery = violationDeliveries.findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
                .orElseGet(() -> violationDeliveries.save(ViolationOutboxDelivery.builder().eventId(event.getEventId()).targetNodeId(target.getNodeId()).status(AppConstants.PENDING).retryCount(0).createdAt(LocalDateTime.now()).build()));
            if (AppConstants.ACKNOWLEDGED.equals(delivery.getStatus()) || waitRetry(delivery.getStatus(), delivery.getNextRetryAt())) continue;
            try {
                ViolationSyncPayload payload = mapper.readValue(event.getPayload(), ViolationSyncPayload.class);
                restClient.post().uri(url(target, "/internal/sync/violation")).body(payload).retrieve().toBodilessEntity();
                delivery.setStatus(AppConstants.ACKNOWLEDGED); delivery.setAcknowledgedAt(LocalDateTime.now()); delivery.setLastError(null); delivery.setNextRetryAt(null);
            } catch (Exception ex) { fail(delivery, ex); }
            violationDeliveries.save(delivery);
        }
        boolean complete = targets.stream().allMatch(n -> violationDeliveries.findByEventIdAndTargetNodeId(event.getEventId(), n.getNodeId()).map(d -> AppConstants.ACKNOWLEDGED.equals(d.getStatus())).orElse(false));
        event.setStatus(complete ? "SENT" : AppConstants.FAILED);
        event.setNextRetryAt(complete ? null : LocalDateTime.now().plusSeconds(30));
        violationOutbox.save(event);
    }

    private String url(NodeRegistry node, String path) { return "http://" + node.getIpAddress() + ":" + node.getPort() + path; }
    private boolean waitRetry(String status, LocalDateTime next) { return AppConstants.FAILED.equals(status) && next != null && next.isAfter(LocalDateTime.now()); }
    private void fail(FenceOutboxDelivery d, Exception ex) { int retry=(d.getRetryCount()==null?0:d.getRetryCount())+1; d.setRetryCount(retry); d.setStatus(AppConstants.FAILED); d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300,10L*retry))); d.setLastError(error(ex)); }
    private void fail(ViolationOutboxDelivery d, Exception ex) { int retry=(d.getRetryCount()==null?0:d.getRetryCount())+1; d.setRetryCount(retry); d.setStatus(AppConstants.FAILED); d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300,10L*retry))); d.setLastError(error(ex)); }
    private String error(Exception ex) { String m=ex.getMessage(); return m==null?ex.getClass().getSimpleName():m.substring(0,Math.min(2000,m.length())); }
}
