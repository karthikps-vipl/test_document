package org.bel.locationService.service.impl;

import java.time.LocalDateTime;

import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.dto.response.SyncAckResponse;
import org.bel.locationService.entity.NodeRegistry;
import org.bel.locationService.entity.SyncGroupOutbox;
import org.bel.locationService.entity.SyncOutboxDelivery;
import org.bel.locationService.repository.SyncOutboxDeliveryRepository;
import org.bel.locationService.sync.GroupSyncEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeSyncService {

	private final RestClient restClient;
	private final SyncOutboxDeliveryRepository deliveryRepo;
	private final ObjectMapper mapper;
	@Value("${server.port}")
	private Integer port;

	@Async("syncExecutor")
	public void send(SyncGroupOutbox outbox, SyncOutboxDelivery delivery, NodeRegistry target) {

		try {
			// Optional safety check: Ensure we only process group events
			if (!"GROUP".equals(outbox.getEntityType())) {
				log.debug("Skipping non-group event: {}", outbox.getEventId());
				return;
			}

			// 1. Route strictly to the Group Sync endpoint
			String url = "http://" + target.getIpAddress() + ":" + port + "/internal/sync/group?eventId=" + outbox.getEventId();
			GroupSyncEvent payloadToSync = mapper.readValue(outbox.getPayload(), GroupSyncEvent.class);

			// 2. Send the HTTP POST request to the target Node
			ResponseEntity<SyncAckResponse> response = restClient.post()
					.uri(url)
					.body(payloadToSync)
					.retrieve()
					.toEntity(SyncAckResponse.class);

			// 3. Handle Acknowledgement
			if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
				LocalDateTime now = LocalDateTime.now();
				delivery.setStatus(AppConstants.ACKNOWLEDGED);
				delivery.setSentAt(now);
				delivery.setAcknowledgedAt(now);
				delivery.setLastError(null);

				deliveryRepo.save(delivery);
			} else {
				fail(delivery, new IllegalStateException("Invalid or empty sync acknowledgement"));
			}

		} catch (Exception ex) {
			fail(delivery, ex);
		}
	}

	private void fail(SyncOutboxDelivery d, Exception ex) {
		int retry = (d.getRetryCount() == null ? 0 : d.getRetryCount()) + 1;

		d.setRetryCount(retry);
		d.setStatus(AppConstants.FAILED);
		// Exponential backoff: Max 5 minutes (300 seconds)
		d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300, 10L * retry)));

		String msg = ex.getMessage();
		d.setLastError(msg != null && msg.length() > 2000 ? msg.substring(0, 2000) : msg);

		deliveryRepo.save(d);
	}
}