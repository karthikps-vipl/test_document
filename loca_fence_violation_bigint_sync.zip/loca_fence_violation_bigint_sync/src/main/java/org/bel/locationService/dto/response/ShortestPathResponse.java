package org.bel.locationService.dto.response;

import com.fasterxml.jackson.annotation.JsonRawValue;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ShortestPathResponse {
	private Integer fromNode;
	private Integer toNode;

	@JsonRawValue // Prevents the GeoJSON string from being escaped with slashes
	private String routeGeojson;

	private Integer totalSegments;
}
