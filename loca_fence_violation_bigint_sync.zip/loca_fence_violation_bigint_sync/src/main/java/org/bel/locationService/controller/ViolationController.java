package org.bel.locationService.controller;

import java.util.List;

import org.bel.locationService.dto.request.AddViolationRequest;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.dto.response.ViolationListResponse;
import org.bel.locationService.service.ViolationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/violation")
@RequiredArgsConstructor
public class ViolationController {
	
	private final ViolationService violationService;
	
	@PostMapping("/add")
    public ResponseEntity<SingleResponse<String>> addViolation(@Valid @RequestBody AddViolationRequest request) {
        return ResponseEntity.ok(violationService.addViolation(request));
    }

    @GetMapping("/list")
    public ResponseEntity<SingleResponse<List<ViolationListResponse>>> violationList(
            @RequestHeader("X-User-Id") Long userId) {
        return ResponseEntity.ok(violationService.violationList(userId));
    }
}
