package org.bel.locationService.sync;
import java.time.LocalDateTime; import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ViolationSyncPayload { private Long violationId; private Long userId; private Long fenceId; private LocalDateTime violatedAt; private String createdBy; }
