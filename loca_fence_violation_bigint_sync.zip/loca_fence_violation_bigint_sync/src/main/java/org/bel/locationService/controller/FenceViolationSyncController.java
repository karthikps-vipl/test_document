package org.bel.locationService.controller;
import org.bel.locationService.sync.*; import org.bel.locationService.service.impl.FenceViolationSyncReceiver; import org.bel.locationService.dto.response.SyncAckResponse;
import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*; import lombok.RequiredArgsConstructor;
@RestController @RequestMapping("/internal/sync") @RequiredArgsConstructor
public class FenceViolationSyncController {
 private final FenceViolationSyncReceiver receiver;
 @PostMapping("/fence") public ResponseEntity<SyncAckResponse> fence(@RequestBody FenceSyncPayload p){receiver.applyFence(p);return ResponseEntity.ok(new SyncAckResponse(null,"APPLIED",null));}
 @PostMapping("/violation") public ResponseEntity<SyncAckResponse> violation(@RequestBody ViolationSyncPayload p){receiver.applyViolation(p);return ResponseEntity.ok(new SyncAckResponse(null,"APPLIED",null));}
}
