package org.bel.locationService.repository;

import java.util.List;

import org.bel.locationService.entity.LaaGisLocationShare;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaGisLocationShareRepository extends JpaRepository<LaaGisLocationShare, Integer> {
    List<LaaGisLocationShare> findByMdmUser_IdOrderByCreatedAtDesc(Long mdmUserId);
}
