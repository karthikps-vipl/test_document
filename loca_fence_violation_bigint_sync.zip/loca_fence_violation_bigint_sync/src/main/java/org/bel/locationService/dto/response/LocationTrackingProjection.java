package org.bel.locationService.dto.response;

import java.time.Instant;

public interface LocationTrackingProjection {
	Integer getId();
    Integer getMdm_ue__id();
    String getGeom(); // This will come as WKT or Hex depending on driver
    Instant getCreated_time();
    String node();
    Integer getMdm_user__id();
    String getService_id();
    String getUsr_name();
    String getDevice_id();
    String getDevice_name();
    String getUsr_type();
    String getSymbol();
    Integer getMdm_role__id();
    String getRole_name();
    
    // We will manually add lat/long from the 'latest' table later
    Double getLatitude();
    Double getLongitude();
}
