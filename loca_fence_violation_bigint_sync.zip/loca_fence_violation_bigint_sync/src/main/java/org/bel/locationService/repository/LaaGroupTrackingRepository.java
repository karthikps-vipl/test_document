package org.bel.locationService.repository;

import java.util.List;
import java.util.Optional;

import org.bel.locationService.entity.LaaGroupTracking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LaaGroupTrackingRepository extends JpaRepository<LaaGroupTracking, Integer> {
	// For sortOrder == 4 (Fetch only groups created by this user)
    @Query("SELECT DISTINCT g FROM LaaGroupTracking g " +
           "LEFT JOIN FETCH g.details d " +
           "WHERE g.mdmUser.id = :userId " +
           "AND g.groupStats != 2 " +
           "AND (:groupStats IS NULL OR g.groupStats = :groupStats) " +
           "ORDER BY g.createdAt DESC")
    List<LaaGroupTracking> findGroupsForAdmin(@Param("userId") Long userId, @Param("groupStats") Integer groupStats);

    // For sortOrder < 4 (Fetch all groups in the system)
    @Query("SELECT DISTINCT g FROM LaaGroupTracking g " +
           "LEFT JOIN FETCH g.details d " +
           "WHERE g.groupStats != 2 " +
           "AND (:groupStats IS NULL OR g.groupStats = :groupStats) " +
           "ORDER BY g.createdAt DESC")
    List<LaaGroupTracking> findAllGroups(@Param("groupStats") Integer groupStats);
    
    boolean existsByMdmUser_IdAndGroupStats(Long userId, Integer groupStats);
    
 // Checks if the user has a group with this status, EXCLUDING a specific group ID
    boolean existsByMdmUser_IdAndGroupStatsAndIdNot(Long userId, Integer groupStats, Integer excludeGroupId);

	Optional<LaaGroupTracking> findByGroupUuid(String groupUuid);
}
