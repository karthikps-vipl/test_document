package org.bel.locationService.service.impl;
import org.bel.locationService.entity.*; import org.bel.locationService.repository.*; import org.bel.locationService.sync.*; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional; import lombok.RequiredArgsConstructor;
@Service @RequiredArgsConstructor
public class FenceViolationSyncReceiver {
 private final LaaGisFencingRepository fences; private final LaaGisFencingViolationRepository violations; private final MdmUserRepository users;
 @Transactional public void applyFence(FenceSyncPayload p){
  LaaGisFencing f=fences.findById(p.getFenceId()).orElseGet(LaaGisFencing::new); f.setId(p.getFenceId());
  f.setMdmUser(users.getReferenceById(p.getUserId())); f.setCreatedBy(p.getCreatedBy()); f.setUpdatedBy(p.getUpdatedBy()); f.setFenceStatus(p.getFenceStatus()); f.setFenceName(p.getFenceName()); f.setFencingBoundary(p.getFencingBoundary()); fences.save(f);
 }
 @Transactional public void applyViolation(ViolationSyncPayload p){
  if(violations.existsById(p.getViolationId())) return;
  LaaGisFencing f=fences.findById(p.getFenceId()).orElseThrow(()->new IllegalStateException("Referenced fence is not present: "+p.getFenceId()));
  LaaGisFencingViolation v=new LaaGisFencingViolation(); v.setId(p.getViolationId()); v.setMdmUser(users.getReferenceById(p.getUserId())); v.setLaaGisFencing(f); v.setViolatedAt(p.getViolatedAt()); v.setCreatedBy(p.getCreatedBy()); violations.save(v);
 }
}
