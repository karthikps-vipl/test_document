package org.bel.locationService.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Entity
@Table(name = "laa_notification", schema = "tcs_laa")
@Data
public class LaaNotification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "mdm_user__id", nullable = false)
    private Integer mdmUserId; 

    @Column(name = "laa_group_tracking__id")
    private Integer laaGroupTrackingId;

    @Column(name = "event_type", nullable = false)
    private Integer eventType; 

    @Column(name = "latitude", nullable = false)
    @Min(-90)
    @Max(90)
    private Double latitude;

    @Column(name = "longitude", nullable = false)
    @Min(-180)
    @Max(180)
    private Double longitude;

    @Column(name = "violator_service__id", length = 255)
    private String violatorServiceId;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}