package org.bel.locationService.dto.response;

import org.bel.locationService.enums.CustomStatus;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SingleResponse<T> {
    private T data;
    private Response response;

    public SingleResponse(T data, CustomStatus status){
        this.data = data;
        this.response = new Response(status.getCode(), status.getMessage());
    }
    
    public SingleResponse(T data, Response response) {
        this.data = data;
        this.response = response;
    }
}
