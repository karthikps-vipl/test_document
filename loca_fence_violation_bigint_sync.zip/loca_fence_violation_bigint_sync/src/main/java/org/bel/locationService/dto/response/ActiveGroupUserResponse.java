package org.bel.locationService.dto.response;

import org.bel.locationService.entity.MdmUser;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ActiveGroupUserResponse {
	private Long id;
    private String service_id;
    private String usr_name;
    private String node_name;
    private Integer mdm_user_type__id;
    private Integer user_stats;

    public ActiveGroupUserResponse(MdmUser user) {
        this.id = user.getId();
        this.service_id = user.getServiceId();
        this.usr_name = user.getUsrName();
        this.user_stats = user.getUserStats();
        
        if (user.getNode() != null) {
            this.node_name = user.getNode().getNodeName();
        }
        
        if (user.getMdmUserType() != null) {
            this.mdm_user_type__id = user.getMdmUserType().getId();
        }
    }
}
