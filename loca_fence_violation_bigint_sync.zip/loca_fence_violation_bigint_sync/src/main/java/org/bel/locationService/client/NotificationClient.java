package org.bel.locationService.client;

import org.bel.locationService.dto.request.NotificationPayload;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "notificationService")
public interface NotificationClient {

	@PostMapping("/api/notifications/send_private")
	void sendPrivateNotification(NotificationPayload notificationPayload);

}
