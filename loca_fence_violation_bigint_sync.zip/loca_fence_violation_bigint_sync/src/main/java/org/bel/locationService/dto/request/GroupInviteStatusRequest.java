package org.bel.locationService.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class GroupInviteStatusRequest {

    @NotBlank(message = "Status is required (e.g., 'Accepted', 'Rejected')")
    private String status;

    private String updated_by;
    
    private String groupuuid;
}