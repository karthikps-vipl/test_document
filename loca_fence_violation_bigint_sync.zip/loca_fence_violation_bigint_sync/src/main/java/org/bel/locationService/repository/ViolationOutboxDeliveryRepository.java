package org.bel.locationService.repository;
import java.util.*; import org.bel.locationService.entity.ViolationOutboxDelivery; import org.springframework.data.jpa.repository.JpaRepository;
public interface ViolationOutboxDeliveryRepository extends JpaRepository<ViolationOutboxDelivery,Long> { Optional<ViolationOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId,String targetNodeId); }
