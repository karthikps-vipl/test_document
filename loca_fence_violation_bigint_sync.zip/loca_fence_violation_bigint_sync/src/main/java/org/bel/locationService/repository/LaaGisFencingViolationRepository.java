package org.bel.locationService.repository;

import java.util.List;

import org.bel.locationService.entity.LaaGisFencingViolation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LaaGisFencingViolationRepository extends JpaRepository<LaaGisFencingViolation, Long> {
	@Query("SELECT v FROM LaaGisFencingViolation v " +
	           "JOIN FETCH v.laaGisFencing f " +
	           "JOIN FETCH v.mdmUser u " +
	           "WHERE u.id = :userId " +
	           "ORDER BY f.createdAt DESC")
	    List<LaaGisFencingViolation> findViolationsByUserId(@Param("userId") Long userId);
}
