package org.bel.locationService.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.bel.locationService.dto.request.AddViolationRequest;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.dto.response.ViolationListResponse;
import org.bel.locationService.entity.LaaGisFencing;
import org.bel.locationService.entity.LaaGisFencingViolation;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaGisFencingRepository;
import org.bel.locationService.repository.LaaGisFencingViolationRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.service.ViolationService;
import org.bel.locationService.sync.ViolationSyncPayload;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class ViolationServiceImpl implements ViolationService{

	private final LaaGisFencingViolationRepository violationRepository;
	private final MdmUserRepository userRepository;
	private final LaaGisFencingRepository fencingRepository;
	private final FenceViolationOutboxService syncOutboxService;

    @Override
    @Transactional
    public SingleResponse<String> addViolation(AddViolationRequest request) {
        
        // 1. Fetch User
        MdmUser user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new CustomException("Account not found", CustomStatus.ACCOUNT_NOT_FOUND, 404));

        // 2. Fetch the Fence being violated
        LaaGisFencing fence = fencingRepository.findById(request.getFenceId())
                .orElseThrow(() -> new CustomException("Fence not found for ID: " + request.getFenceId(), CustomStatus.FENCE_NOT_FOUND, 404));

        // 3. Create Violation Record
        LaaGisFencingViolation violation = new LaaGisFencingViolation();
        violation.setMdmUser(user);
        violation.setLaaGisFencing(fence);
        violation.setCreatedBy(request.getUsrName());
        violation.setViolatedAt(LocalDateTime.now()); // Explicitly set violation time
        
        violation = violationRepository.save(violation);
        syncOutboxService.enqueueViolation(ViolationSyncPayload.builder().violationId(violation.getId()).userId(user.getId()).fenceId(fence.getId()).violatedAt(violation.getViolatedAt()).createdBy(violation.getCreatedBy()).build());

        log.info("Fence violation recorded for user {} on fence {}", request.getUsrName(), fence.getFenceName());

        return new SingleResponse<>(null, CustomStatus.SUCCESS);
    }

    @Override
    @Transactional
    public SingleResponse<List<ViolationListResponse>> violationList(Long userId) {
        
        // 1. Fetch Violations using optimized JPQL query
        List<LaaGisFencingViolation> violations = violationRepository.findViolationsByUserId(userId);

        // 2. Map Entity to flat DTO
        List<ViolationListResponse> responseList = violations.stream()
                .map(ViolationListResponse::new)
                .collect(Collectors.toList());

        return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
    }
}
