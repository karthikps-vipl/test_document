package org.bel.locationService.util;
import java.util.concurrent.atomic.AtomicLong;
/** Timestamp-millisecond based BIGINT ID; sequence suffix prevents same-JVM same-ms collisions. */
public final class TimestampBigIntIdGenerator {
 private static final AtomicLong LAST = new AtomicLong(0);
 private TimestampBigIntIdGenerator() {}
 public static long nextId() {
  while (true) {
   long prev=LAST.get(), now=System.currentTimeMillis();
   long millis=Math.max(now, prev/1000L);
   long seq=(millis==prev/1000L)?(prev%1000L)+1L:0L;
   if(seq>999L){millis++;seq=0L;}
   long candidate=millis*1000L+seq;
   if(LAST.compareAndSet(prev,candidate)) return candidate;
  }
 }
}
