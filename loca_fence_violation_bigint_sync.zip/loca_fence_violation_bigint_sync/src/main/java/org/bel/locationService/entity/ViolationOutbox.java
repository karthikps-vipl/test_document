package org.bel.locationService.entity;
import java.time.LocalDateTime; import java.util.UUID;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.JdbcTypeCode; import org.hibernate.type.SqlTypes;
@Entity @Table(name="violation_outbox",schema="tcs_laa") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ViolationOutbox {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(name="event_id",nullable=false,unique=true) private UUID eventId;
 @Column(name="event_type",nullable=false) private String eventType;
 @Column(name="source_node_id",nullable=false) private String sourceNodeId;
 @JdbcTypeCode(SqlTypes.JSON) @Column(nullable=false,columnDefinition="jsonb") private String payload;
 @Column(nullable=false) private String status;
 @Column(name="retry_count",nullable=false) private Integer retryCount;
 @Column(name="next_retry_at") private LocalDateTime nextRetryAt;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
 @Column(name="last_error",columnDefinition="text") private String lastError;
}
