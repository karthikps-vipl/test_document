package org.bel.locationService.service.impl;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicBoolean;

import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.entity.NodeRegistry;
import org.bel.locationService.entity.SyncGroupOutbox;
import org.bel.locationService.entity.SyncOutboxDelivery;
import org.bel.locationService.repository.SyncGroupOutboxRepo;
import org.bel.locationService.repository.SyncOutboxDeliveryRepository;
import org.bel.locationService.sync.SyncWakeupEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class SyncOutboxWorker {

    private final SyncGroupOutboxRepo groupOutboxRepo;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final NodeRegistryService nodeRegistryService;
    private final NodeSyncService nodeSyncService;

    // PREVENTS DATABASE CONCURRENCY ERRORS
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);

    @Async("syncExecutor")
    @EventListener
    public void handleWakeupEvent(SyncWakeupEvent event) {
        processOutbox();
    }

//    @Scheduled(fixedDelayString = "300000") // 5 mins
    @Scheduled(fixedDelayString = "30000")
    public void processOutbox() {
        if (!isProcessing.compareAndSet(false, true)) {
            return;
        }

        try {
            groupOutboxRepo.findEventsToProcess(LocalDateTime.now())
                    .stream()
                    .limit(100)
                    .forEach(this::processEvent);
        } finally {
            isProcessing.set(false);
        }
    }

    private void processEvent(SyncGroupOutbox event) {
        for (NodeRegistry target : nodeRegistryService.getOtherActiveNodes()) {
            SyncOutboxDelivery d = deliveryRepo.findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
                    .orElseGet(() -> deliveryRepo.save(SyncOutboxDelivery.builder()
                            .eventId(event.getEventId())
                            .targetNodeId(target.getNodeId())
                            .status(AppConstants.PENDING)
                            .retryCount(0)
                            .createdAt(LocalDateTime.now())
                            .build()));

            if (AppConstants.ACKNOWLEDGED.equals(d.getStatus()) || 
               (AppConstants.FAILED.equals(d.getStatus()) && d.getNextRetryAt() != null && d.getNextRetryAt().isAfter(LocalDateTime.now()))) {
                continue;
            }

            nodeSyncService.send(event, d, target);
        }
    }
}