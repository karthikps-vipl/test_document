package org.bel.locationService.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.bel.locationService.client.NotificationClient;
import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.dto.request.ActivateGroupRequest;
import org.bel.locationService.dto.request.AddGroupRequest;
import org.bel.locationService.dto.request.ChangeGroupStatusRequest;
import org.bel.locationService.dto.request.EditGroupRequest;
import org.bel.locationService.dto.request.GroupInviteStatusRequest;
import org.bel.locationService.dto.request.NotificationPayload;
import org.bel.locationService.dto.response.ActiveGroupUserResponse;
import org.bel.locationService.dto.response.GroupListResponse;
import org.bel.locationService.dto.response.GroupMemberResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.dto.response.UserNotInGroupResponse;
import org.bel.locationService.entity.LaaGroupTracking;
import org.bel.locationService.entity.LaaGroupTrackingDtl;
import org.bel.locationService.entity.MdmRole;
import org.bel.locationService.entity.MdmUser;
import org.bel.locationService.entity.SyncGroupOutbox;
import org.bel.locationService.enums.CustomStatus;
import org.bel.locationService.exception.CustomException;
import org.bel.locationService.repository.LaaGroupTrackingDtlRepository;
import org.bel.locationService.repository.LaaGroupTrackingRepository;
import org.bel.locationService.repository.MdmRoleRepository;
import org.bel.locationService.repository.MdmUserRepository;
import org.bel.locationService.repository.SyncGroupOutboxRepo;
import org.bel.locationService.service.GroupService;
import org.bel.locationService.sync.GroupSyncEvent;
import org.bel.locationService.sync.SyncWakeupEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class GroupServiceImpl implements GroupService {

	private final LaaGroupTrackingRepository groupTrackingRepository;
	private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	private final MdmUserRepository userRepository;
	private final MdmRoleRepository roleRepository;
	private final LaaGroupTrackingDtlRepository groupTrackingDtlRepository;
	private final NotificationClient notificationClient;
	private final SyncGroupOutboxRepo groupOutboxRepo;
	private final NodeRegistryService nodeRegistryService;
	private final ApplicationEventPublisher eventPublisher;
	private final ObjectMapper mapper;

	@Override
	@Transactional
	public SingleResponse<List<GroupListResponse>> groupList(Long userId, String roleId, Integer filterOption) {
		Integer sortOrder = getSortOrderBasedOnRoleId(roleId);
		List<LaaGroupTracking> groups = (sortOrder != null && sortOrder == 4)
				? groupTrackingRepository.findGroupsForAdmin(userId, filterOption)
				: groupTrackingRepository.findAllGroups(filterOption);

		List<GroupListResponse> responseList = groups.stream().map(group -> {
			GroupListResponse dto = new GroupListResponse();
			dto.setId(group.getId());
			dto.setGroupUuid(group.getGroupUuid()); // Map the UUID
			dto.setGroup_name(group.getGroupName());
			dto.setStatus(group.getGroupStats());
			dto.setExpiry_hour(group.getExpiryHour());
			if (group.getMdmUser() != null) {
				dto.setMdm_user__id(group.getMdmUser().getId());
				dto.setUsr_name(group.getMdmUser().getUsrName());
			}
			dto.setCreated_at(group.getCreatedAt() != null ? group.getCreatedAt().format(dateFormatter) : null);

			if (group.getDetails() != null) {
				List<GroupMemberResponse> members = group.getDetails().stream().map(detail -> {
					GroupMemberResponse memberDto = new GroupMemberResponse();
					memberDto.setMdm_user__id(detail.getMdmUser().getId());
					memberDto.setService_id(detail.getMdmUser().getServiceId());
					memberDto.setUsr_name(detail.getMdmUser().getUsrName());
					memberDto.setStatus(detail.getStatus());
					memberDto.setIs_observer(detail.getIsObserver());
					if (detail.getMdmUser().getNode() != null) {
						memberDto.setNode_id(detail.getMdmUser().getNode().getNodeId());
						memberDto.setNode_name(detail.getMdmUser().getNode().getNodeName());
					}
					return memberDto;
				}).collect(Collectors.toList());
				dto.setMembers(members);
			}
			return dto;
		}).collect(Collectors.toList());

		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<List<UserNotInGroupResponse>> getUsersNotInActiveGroup(Integer grpId, Long userId,
			String roleId) {
		// ... existing code (No UUID changes needed here as it's a read)
		Integer sortOrder = getSortOrderBasedOnRoleId(roleId);
		List<MdmUser> availableUsers = userRepository.findUsersNotInActiveGroup(sortOrder, 1, userId, 1, grpId);
		List<UserNotInGroupResponse> responseList = availableUsers.stream().map(UserNotInGroupResponse::new)
				.collect(Collectors.toList());
		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> addGroup(AddGroupRequest request) {
		if (request.getMembers() != null && request.getMembers().size() > 10)
			throw new CustomException("Limit 10 members", CustomStatus.MEMBERS_LIMITATION, 400);
		if (request.getMembers().stream().filter(m -> m.getIs_observer() != null && m.getIs_observer() == 1)
				.count() > 1)
			throw new CustomException("Limit 1 observer", CustomStatus.ONE_MEMBER_AS_OBSERVER, 400);
		if (groupTrackingRepository.existsByMdmUser_IdAndGroupStats(request.getUserId(), 1))
			throw new CustomException("User already has active group", CustomStatus.USER_ALREADY_IN_GROUP, 400);

		MdmUser creator = userRepository.findById(request.getMdm_user__id()).orElseThrow();

		LaaGroupTracking group = new LaaGroupTracking();
		group.setGroupUuid(UUID.randomUUID().toString());
		group.setGroupName(request.getGroup_name());
		group.setGroupStats(request.getGroup_stats());
		group.setMdmUser(creator);
		group.setExpiryHour(request.getExpiry_hour() != null ? request.getExpiry_hour() : 96);
		group.setCreatedBy(AppConstants.SYSTEM);

		List<LaaGroupTrackingDtl> detailsList = new ArrayList<>();
		for (AddGroupRequest.GroupMemberRequest memberReq : request.getMembers()) {
			MdmUser memberUser = userRepository.getReferenceById(memberReq.getId());
			LaaGroupTrackingDtl detail = new LaaGroupTrackingDtl();
			detail.setMdmUser(memberUser);
			detail.setLaaGroupTracking(group);
			detail.setIsObserver(memberReq.getIs_observer() != null ? memberReq.getIs_observer() : 0);
			detail.setStatus(AppConstants.INVITED);
			detail.setCreatedBy(AppConstants.SYSTEM);
			detailsList.add(detail);
		}
		group.setDetails(detailsList);
		groupTrackingRepository.save(group);

		detailsList.forEach(detail -> {
			String messageText = (detail.getIsObserver() != null && detail.getIsObserver() == 1)
					? String.format("You have been invited to join '%s' as an Observer.",
							detail.getLaaGroupTracking().getGroupName())
					: String.format("You have been invited to join '%s'.", detail.getLaaGroupTracking().getGroupName());

			NotificationPayload payload = new NotificationPayload();
			payload.setTargetUserId(detail.getMdmUser().getId());
			payload.setEventType("groupInvitation");
			payload.setPayload(messageText);
			notificationClient.sendPrivateNotification(payload);
		});

		createOutboxEvent(AppConstants.GROUP_CREATE, request, group.getGroupUuid(), null);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> editGroup(String groupUuid, EditGroupRequest request) {

		validateRequest(request);

		// FETCH BY UUID
		LaaGroupTracking group = groupTrackingRepository.findByGroupUuid(groupUuid)
				.orElseThrow(() -> new CustomException("Group not found", CustomStatus.GROUP_NOT_FOUND, 404));

		updateGroupMetadata(group, request);

		synchronizeMembers(group, request.getMembers());

		handleGroupStatsActivation(group, request.getGroup_stats());

		groupTrackingRepository.save(group);

		sendMemberNotifications(group.getGroupName(), request.getMembers());

		createOutboxEvent(AppConstants.GROUP_EDIT, request, groupUuid, null);

		return new SingleResponse<>("The group has been updated", CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> changeStatus(String groupUuid, Long userId, ChangeGroupStatusRequest request) {

		// FETCH BY UUID
		LaaGroupTracking group = groupTrackingRepository.findByGroupUuid(groupUuid)
				.orElseThrow(() -> new CustomException("Group not found", CustomStatus.GROUP_NOT_FOUND, 404));

		Integer newStatus = request.getStatus();

		if (newStatus == 1) {
			boolean hasOtherActive = groupTrackingRepository.existsByMdmUser_IdAndGroupStatsAndIdNot(userId, 1,
					group.getId());
			if (hasOtherActive)
				throw new CustomException("User already has an active group", CustomStatus.BAD_REQUEST, 400);

			List<LaaGroupTrackingDtl> members = group.getDetails();
			Iterator<LaaGroupTrackingDtl> iterator = members.iterator();
			int validCount = 0;

			while (iterator.hasNext()) {
				LaaGroupTrackingDtl member = iterator.next();
				boolean inAnotherActiveGroup = groupTrackingDtlRepository
						.existsByMdmUser_IdAndLaaGroupTracking_GroupStatsAndLaaGroupTracking_IdNot(
								member.getMdmUser().getId(), 1, group.getId());
				if (inAnotherActiveGroup)
					iterator.remove();
				else
					validCount++;
			}
			if (validCount == 0)
				throw new CustomException("No valid members to activate group", CustomStatus.BAD_REQUEST, 400);
		}

		group.setGroupStats(newStatus);
		group.setUpdatedBy(AppConstants.SYSTEM);
		groupTrackingRepository.save(group);
		
		String statusLabel;
		if (newStatus == 1) {
			statusLabel = AppConstants.ACTIVE_STATUS;
		} else {
			statusLabel = AppConstants.DEACTIVE_STATUS;
		}

		String notificationMsg;
		if (newStatus == 2) {
			notificationMsg = String.format("The group '%s' has been deleted.", request.getName());
		} else {
			notificationMsg = String.format("The group '%s' is now %s.", request.getName(), statusLabel);
		}

		group.getDetails().forEach(member -> {
			NotificationPayload payload = new NotificationPayload();
			payload.setTargetUserId(member.getMdmUser().getId());
			payload.setEventType(AppConstants.GROUP_UPDATE_EVENT_TYPE);
			payload.setPayload(notificationMsg);
			notificationClient.sendPrivateNotification(payload);
		});

		createOutboxEvent(AppConstants.GROUP_STATUS, request, groupUuid, null);
		return new SingleResponse<>(notificationMsg, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<List<ActiveGroupUserResponse>> activateGroupUsers(ActivateGroupRequest request) {
		// Unchanged Read method
		List<MdmUser> validUsers = userRepository.findValidUsersForActivation(request.getIds());
		List<ActiveGroupUserResponse> mappedUsers = validUsers.stream().map(ActiveGroupUserResponse::new)
				.collect(Collectors.toList());
		Map<Long, ActiveGroupUserResponse> uniqueUsersMap = new LinkedHashMap<>();
		for (ActiveGroupUserResponse user : mappedUsers)
			uniqueUsersMap.putIfAbsent(user.getId(), user);
		return new SingleResponse<>(new ArrayList<>(uniqueUsersMap.values()), CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> updateInviteStatus(Long targetUserId, GroupInviteStatusRequest request) {

		// 1. Find the detail record using BOTH the groupUuid (from frontend) and the
		// targetUserId
		// You may need to add: findByLaaGroupTrackingGroupUuidAndMdmUserId(String uuid,
		// Integer userId)
		// to your LaaGroupTrackingDtlRepository

		LaaGroupTrackingDtl grpDetail = groupTrackingDtlRepository
				.findByLaaGroupTrackingGroupUuidAndMdmUser_Id(request.getGroupuuid(), targetUserId)
				.orElseThrow(() -> new CustomException("Invitation record not found for this group",
						CustomStatus.USER_NOT_FOUND, 404));

		grpDetail.setStatus(request.getStatus());
		grpDetail.setUpdatedBy(request.getUpdated_by() != null ? request.getUpdated_by() : AppConstants.SYSTEM);
		groupTrackingDtlRepository.save(grpDetail);

		LaaGroupTracking group = grpDetail.getLaaGroupTracking();
		Long groupOwnerId = group.getMdmUser().getId();

		if (!targetUserId.equals(groupOwnerId)) {
			String notificationMsg = String.format("A user has %s your invitation for the group '%s'.",
					request.getStatus().toLowerCase(), group.getGroupName());

			NotificationPayload payload = new NotificationPayload();
			payload.setTargetUserId(groupOwnerId);
			payload.setEventType(AppConstants.GROUP_UPDATE_EVENT_TYPE);
			payload.setPayload(notificationMsg);
			notificationClient.sendPrivateNotification(payload);
		}

		// 2. Pass the actual groupUuid to the outbox event
		createOutboxEvent(AppConstants.INVITE_STATUS, request, group.getGroupUuid(), targetUserId);

		return new SingleResponse<>(String.format("Status updated to %s successfully", request.getStatus()),
				CustomStatus.SUCCESS);
	}

	public Integer getSortOrderBasedOnRoleId(String roleId) {
		MdmRole role = roleRepository.findById(Integer.parseInt(roleId)).orElseThrow();
		return role.getSortOrder();
	}

	@Async
	private void createOutboxEvent(String action, Object payloadData, String groupUuid, Long targetUserId) {
		try {
			GroupSyncEvent syncEvent = new GroupSyncEvent(action, payloadData, groupUuid, targetUserId);
			String node = nodeRegistryService.getCurrentNodeId();

			groupOutboxRepo.save(SyncGroupOutbox.builder().eventId(UUID.randomUUID()).eventType(action)
					.entityType(AppConstants.GROUP).groupUuid(groupUuid) // Safe to hardcode to 0 since we now use
																			// payload GroupUUID
					.sourceNodeId(node).payload(mapper.writeValueAsString(syncEvent)).status(AppConstants.PENDING)
					.retryCount(0).createdAt(LocalDateTime.now()).build());

			eventPublisher.publishEvent(new SyncWakeupEvent(this));
		} catch (Exception e) {
			log.error("Failed to create outbox event", e);
		}
	}

	// HELPER METHODS
	private void validateRequest(EditGroupRequest request) {
		if (request.getMembers() != null && request.getMembers().size() > 10) {
			throw new CustomException("Limit 10 members", CustomStatus.MEMBERS_LIMITATION, 400);
		}
		long observerCount = request.getMembers().stream()
				.filter(m -> m.getIs_observer() != null && m.getIs_observer() == 1).count();
		if (observerCount > 1) {
			throw new CustomException("Limit 1 observer", CustomStatus.ONE_MEMBER_AS_OBSERVER, 400);
		}
	}

	private void updateGroupMetadata(LaaGroupTracking group, EditGroupRequest request) {
		group.setGroupName(request.getGroup_name());
		group.setGroupStats(request.getGroup_stats());
		group.setExpiryHour(request.getExpiry_hour() != null ? request.getExpiry_hour() : 96);
		group.setUpdatedBy(AppConstants.SYSTEM);

		if (!group.getMdmUser().getId().equals(request.getMdm_user__id())) {
			group.setMdmUser(userRepository.getReferenceById(request.getMdm_user__id()));
		}
	}

	private void synchronizeMembers(LaaGroupTracking group, List<EditGroupRequest.GroupMemberRequest> members) {
		if (members == null)
			return;

		Map<Long, LaaGroupTrackingDtl> existingMap = group.getDetails().stream()
				.collect(Collectors.toMap(d -> d.getMdmUser().getId(), d -> d));

		for (EditGroupRequest.GroupMemberRequest incoming : members) {
			LaaGroupTrackingDtl detail = existingMap.get(incoming.getId());

			if (detail != null) {
				updateExistingMember(detail, incoming);
			} else {
				addNewMember(group, incoming);
			}
		}
	}

	private void updateExistingMember(LaaGroupTrackingDtl detail, EditGroupRequest.GroupMemberRequest incoming) {
		detail.setIsObserver(incoming.getIs_observer() != null ? incoming.getIs_observer() : 0);
		detail.setUpdatedBy(AppConstants.SYSTEM);
	}

	private void addNewMember(LaaGroupTracking group, EditGroupRequest.GroupMemberRequest incoming) {
		LaaGroupTrackingDtl newDetail = new LaaGroupTrackingDtl();
		newDetail.setMdmUser(userRepository.getReferenceById(incoming.getId()));
		newDetail.setLaaGroupTracking(group);
		newDetail.setIsObserver(incoming.getIs_observer() != null ? incoming.getIs_observer() : 0);
		newDetail.setStatus(AppConstants.INVITED);
		newDetail.setCreatedBy(AppConstants.SYSTEM);
		group.getDetails().add(newDetail);
	}

	private void handleGroupStatsActivation(LaaGroupTracking group, Integer groupStats) {
		if (groupStats == null || groupStats != 1)
			return;

		List<LaaGroupTrackingDtl> details = group.getDetails();
		details.removeIf(detail -> groupTrackingDtlRepository
				.existsByMdmUser_IdAndLaaGroupTracking_GroupStatsAndLaaGroupTracking_IdNot(detail.getMdmUser().getId(),
						1, group.getId()));

		if (details.isEmpty()) {
			throw new CustomException("No valid members left to activate", CustomStatus.BAD_REQUEST, 400);
		}
	}

	private void sendMemberNotifications(String groupName, List<EditGroupRequest.GroupMemberRequest> members) {
		if (members == null)
			return;
		for (EditGroupRequest.GroupMemberRequest memberReq : members) {
			NotificationPayload payload = new NotificationPayload();
			payload.setTargetUserId(memberReq.getId());
			payload.setEventType(AppConstants.GROUP_UPDATE_EVENT_TYPE);
			payload.setPayload("Group '" + groupName + "' info has been updated.");
			notificationClient.sendPrivateNotification(payload);
		}
	}
}