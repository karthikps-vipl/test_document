package org.bel.locationService.repository;

import java.util.List;
import java.util.Optional;

import org.bel.locationService.entity.NodeRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface NodeRegistryRepository extends JpaRepository<NodeRegistry, String> {
	// We use a native query to force the cast to 'inet'
    @Query(value = "SELECT * FROM tcs_laa.node_registry WHERE ip_address = CAST(?1 AS inet)", nativeQuery = true)
    Optional<NodeRegistry> findByIpAddress(String ipAddress);

    List<NodeRegistry> findByStatusAndNodeIdNot(String status, String nodeId);

	Optional<NodeRegistry> findByNodeId(String nodeId);
}
