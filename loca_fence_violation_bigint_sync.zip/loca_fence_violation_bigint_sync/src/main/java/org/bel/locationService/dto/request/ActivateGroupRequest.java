package org.bel.locationService.dto.request;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class ActivateGroupRequest {
	@NotEmpty(message = "Ids parameter must be an array of integers and cannot be empty")
    private List<Long> ids;
}
