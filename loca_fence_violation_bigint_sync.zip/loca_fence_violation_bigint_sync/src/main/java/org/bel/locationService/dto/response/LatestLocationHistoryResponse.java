package org.bel.locationService.dto.response;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LatestLocationHistoryResponse {
	private Integer mdm_ue__id;
	private Object geom;
	private OffsetDateTime created_time;
	private Integer mdm_node__id;
	private Integer mdm_user__id;

	// Fields coming from joined tables/logic
	private String service_id;
	private String usr_name;
	private String device_id;
	private String device_name;
	private String usr_type;
	private String symbol;
	private Integer mdm_role__id;
	private String role_name;
}
