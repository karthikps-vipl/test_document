package org.bel.locationService.repository;
import java.time.LocalDateTime; import java.util.List; import java.util.Optional; import java.util.UUID;
import org.bel.locationService.entity.ViolationOutbox; import org.springframework.data.jpa.repository.*; import org.springframework.data.repository.query.Param;
public interface ViolationOutboxRepository extends JpaRepository<ViolationOutbox,Long> {
 @Query("select e from ViolationOutbox e where e.status='PENDING' or (e.status='FAILED' and (e.nextRetryAt is null or e.nextRetryAt<=:now)) order by e.createdAt") List<ViolationOutbox> findReady(@Param("now") LocalDateTime now);
 Optional<ViolationOutbox> findByEventId(UUID eventId);
}
