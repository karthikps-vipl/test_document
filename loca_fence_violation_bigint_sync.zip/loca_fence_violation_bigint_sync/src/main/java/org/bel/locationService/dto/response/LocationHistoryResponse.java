package org.bel.locationService.dto.response;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LocationHistoryResponse {
	private MdmUserResponse userResponse;
	private Double latitude;
	private Double longitude;
	private OffsetDateTime createdTime;
}
