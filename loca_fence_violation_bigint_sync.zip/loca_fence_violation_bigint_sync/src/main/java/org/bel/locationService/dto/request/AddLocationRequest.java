package org.bel.locationService.dto.request;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddLocationRequest {
	@NotNull(message = "Provide mdm User id")
	private Long mdmUserId;

	@NotNull(message = "Latitude value is required")
	@Digits(integer = 2, fraction = 6, message = "Latitude must have up to 2 integer digits and 6 decimal places")
	private Double latitude;

	@NotNull(message = "Longitude value is required")
	@Digits(integer = 3, fraction = 6, message = "Latitude must have up to 3 integer digits and 6 decimal places")
	private Double longitude;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
	private OffsetDateTime createdTime;


	@NotNull(message = "Mdm Ue Id is required")
	private Long mdmUeId;

}
