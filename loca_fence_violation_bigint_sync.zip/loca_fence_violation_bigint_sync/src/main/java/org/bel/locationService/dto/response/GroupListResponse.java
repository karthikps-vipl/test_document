package org.bel.locationService.dto.response;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GroupListResponse {
	    private Integer id;
	    private String groupUuid;
	    private String group_name;
	    private Integer status;
	    private Integer expiry_hour;
	    private Long mdm_user__id;
	    private String usr_name;
	    private String created_at; // Formatted date string
	    private List<GroupMemberResponse> members = new ArrayList<>();
}
