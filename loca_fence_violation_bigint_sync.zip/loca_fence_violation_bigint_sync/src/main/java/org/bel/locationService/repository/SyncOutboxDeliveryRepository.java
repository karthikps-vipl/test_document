package org.bel.locationService.repository;

import java.util.Optional;
import java.util.UUID;

import org.bel.locationService.entity.SyncOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SyncOutboxDeliveryRepository extends JpaRepository<SyncOutboxDelivery, Long> {
	Optional<SyncOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);
}
