package org.bel.locationService.repository;

import java.util.List;

import org.bel.locationService.dto.response.LatestLocationProjection;
import org.bel.locationService.entity.UserLocationLatest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserLocationLatestRepository extends JpaRepository<UserLocationLatest, Integer> {
	UserLocationLatest findByUserId(Integer userId);

	@Query(value = """
			SELECT
			ull.user_id AS userId,
			ull.node_id AS nodeId,
			eu.id AS mdmUeId,
			ull.latitude AS latitude,
			ull.longitude AS longitude,
			ull.location_timestamp AS locationTimestamp,
			u.service_id AS serviceId,
			u.usr_name AS userName,
			eu.device_id AS deviceId,
			eu.device_name AS deviceName,
			ut.id AS userTypeId,
			ut.usr_type AS userType,
			ut.symbol AS symbol,
			r.id AS roleId,
			r.role_name AS roleName
			FROM tcs_laa.user_location_latest ull
			INNER JOIN tcs_mdm.mdm_user u ON u.id = CAST(ull.user_id AS BIGINT)
			LEFT JOIN tcs_laa.node_registry n ON n.node_id = u.node_id
			-- NEW: Join the mapping table first
			LEFT JOIN tcs_mdm.mdm_user_ue_mapping eu_map ON eu_map.mdm_user__id = u.id
			-- NEW: Join the UE table via the mapping table
			LEFT JOIN tcs_mdm.mdm_ue eu ON eu_map.mdm_ue__id = eu.id
			LEFT JOIN tcs_mdm.mdm_user_type ut ON ut.id = u.mdm_user_type__id
			LEFT JOIN tcs_mdm.mdm_role r ON r.id = u.mdm_role__id
			WHERE
			u.id != :callerUserId
			AND ull.latitude IS NOT NULL
			AND ull.longitude IS NOT NULL
			AND (
			-- Rule 1: Group Admin (sort_order = 4) -> Only accepted members in active groups
			(:sortOrder = 4 AND u.id IN (
			SELECT gd.mdm_user__id
			FROM tcs_laa.laa_group_tracking_dtl gd
			INNER JOIN tcs_laa.laa_group_tracking g ON g.id = gd.laa_group_tracking__id
			WHERE g.group_stats = 1
			AND g.mdm_user__id = :callerUserId
			AND UPPER(gd.status) = 'ACCEPTED'
			))
			OR
			-- Rule 2: Restricted Viewers (sort_order > 4) -> Specific user types only
			(:sortOrder > 4 AND ut.id IN (2, 3, 4, 5))
			OR
			-- Rule 3: Top-level Admins (sort_order < 4) -> Unrestricted global view
			(:sortOrder < 4)
			)
			ORDER BY ull.location_timestamp DESC
			""", nativeQuery = true)
	List<LatestLocationProjection> findLatestLocations(@Param("callerUserId") Long callerUserId,@Param("sortOrder") Integer sortOrder);
}
