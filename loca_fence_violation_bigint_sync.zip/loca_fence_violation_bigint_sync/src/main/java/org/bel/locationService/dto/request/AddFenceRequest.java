package org.bel.locationService.dto.request;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddFenceRequest {
	@NotNull(message = "User id is required")
	private Long userId;
	
	@NotBlank(message = "User Name is required")
    private String usrName;
	
    @NotBlank(message = "Fence name is required")
    private String fence_name; // Matches exact JSON key from Node.js req.body
    
    @NotNull(message = "Fencing boundary is required")
    private List<List<Double>> fencing_boundary;
}
