package org.bel.locationService.controller;

import org.bel.locationService.dto.response.SyncAckResponse;
import org.bel.locationService.service.impl.GroupSyncService;
import org.bel.locationService.sync.GroupSyncEvent;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/internal/sync/group")
@RequiredArgsConstructor
public class GroupSyncController {
    private final GroupSyncService groupSyncService;

    @PostMapping
    public ResponseEntity<SyncAckResponse> receiveGroupSync(@RequestBody GroupSyncEvent event, @RequestParam("eventId") String eventId) {
        return ResponseEntity.ok(groupSyncService.processSync(eventId, event));
    }
}