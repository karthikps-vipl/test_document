package org.bel.locationService.dto.response;

import java.time.LocalDateTime;

import org.bel.locationService.entity.LaaGisLocationShare;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ShareListResponse {
    private Integer id;
    private Long mdmUserId;
    private Long sharedMdmUserId;
    private Double latitude;
    private Double longitude;
    private LocalDateTime createdAt;

    public ShareListResponse(LaaGisLocationShare share) {
        this.id = share.getId();
        this.mdmUserId = share.getMdmUser().getId();
        this.sharedMdmUserId = share.getSharedMdmUser().getId();
        this.createdAt = share.getCreatedAt();
        if (share.getSharedLocation() != null) {
            this.latitude = share.getSharedLocation().getY();
            this.longitude = share.getSharedLocation().getX();
        }
    }
}
