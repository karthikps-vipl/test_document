package org.bel.locationService.dto.response;

import java.time.Instant;

public interface LatestLocationProjection {
    Long getMdmUeId(); 
    Long getUserId();
    String getServiceId();
    String getUserName();
    String getNodeId();
    String getNodeName();
    Double getLatitude();
    Double getLongitude();
    Instant getLocationTimestamp();
    String getDeviceId();
    String getDeviceName();
    Integer getUserTypeId();
    String getUserType();
    String getSymbol();
    Integer getRoleId();
    String getRoleName();
    
}
