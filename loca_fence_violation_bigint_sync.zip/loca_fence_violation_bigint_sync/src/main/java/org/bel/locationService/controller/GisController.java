package org.bel.locationService.controller;

import java.util.List;

import org.bel.locationService.dto.request.AddFenceRequest;
import org.bel.locationService.dto.request.EditFenceRequest;
import org.bel.locationService.dto.response.FenceCreationResponse;
import org.bel.locationService.dto.response.FencingListResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.service.GisService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/fence")
@RequiredArgsConstructor
public class GisController {
	
	private final GisService gisService;
	
	@GetMapping("/list")
	public ResponseEntity<SingleResponse<List<FencingListResponse>>> getFencinglist(@RequestHeader("X-User-Id") Long mdmUserId, 
																			  @RequestHeader("X-User-Role") String roleId 
																			){
		return ResponseEntity.ok(gisService.getFencingList(mdmUserId, roleId));
	}
	
	@PostMapping("/add")
    public ResponseEntity<SingleResponse<FenceCreationResponse>> addFence(@Valid @RequestBody AddFenceRequest request) {
        return ResponseEntity.ok(gisService.addFence(request));
    }
	
	@PutMapping("/edit")
    public ResponseEntity<SingleResponse<FencingListResponse>> editFence(@Valid @RequestBody EditFenceRequest request) {
        return ResponseEntity.ok(gisService.editFence(request));
    }
	
	@DeleteMapping("/delete/{fenceId}")
    public ResponseEntity<SingleResponse<String>> deleteFence(@PathVariable Long fenceId) {
        return ResponseEntity.ok(gisService.deleteFence(fenceId));
    }
}
