package org.bel.locationService.sync; public class FenceViolationSyncWakeupEvent {}
