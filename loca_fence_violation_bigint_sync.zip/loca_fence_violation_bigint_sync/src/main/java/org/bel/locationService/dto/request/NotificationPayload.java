package org.bel.locationService.dto.request;

import lombok.Data;

@Data
public class NotificationPayload {
	private Long targetUserId;
    private String eventType; // e.g., "groupInvitation"
    private Object payload;
}
