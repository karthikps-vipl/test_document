package org.bel.locationService.constants;

import org.springframework.stereotype.Component;

@Component
public class AppConstants {

	private AppConstants() {
	}

	public static final String PENDING = "PENDING";
	public static final String LOCATION_UPDATED = "LOCATION_UPDATED";
	public static final String SENDING = "SENDING";
	public static final String USER_LOCATION = "USER_LOCATION";
	public static final String ACTIVE_STATUS = "ACTIVE";
	public static final String DEACTIVE_STATUS = "DEACTIVE";
	public static final String ACKNOWLEDGED = "ACKNOWLEDGED";
	public static final String ACTIVE = "ACTIVE";
	public static final String UP = "UP";
	public static final String DOWN = "DOWN";
	public static final String WAITING_FOR_NODE = "WAITING_FOR_NODE";
	public static final String STALE_IGNORED = "STALE_IGNORED";
	public static final String INACTIVE_IN_REGISTRY = "INACTIVE_IN_REGISTRY";
	public static final String UNKNOWN = "UNKNOWN";
	public static final String FAILED = "FAILED";
	public static final String ACCEPTED = "ACCEPTED";
	public static final String INVITED = "invited";
	public static final String GROUP_CREATE = "GROUP_CREATE";
	public static final String GROUP_EDIT = "GROUP_EDIT";
	public static final String GROUP_STATUS = "GROUP_STATUS";
	public static final String INVITE_STATUS = "INVITE_STATUS";
	public static final String GROUP = "GROUP";
	public static final String SYSTEM = "SYSTEM";
	public static final String GROUP_UPDATE_EVENT_TYPE = "groupUpdate";
	public static final String SYSTEM_SYNC = "SYSTEM_SYNC";
}
