package org.bel.locationService.repository;

import java.util.List;

import org.bel.locationService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmUserRepository extends JpaRepository<MdmUser, Long>{
		@Query("SELECT u FROM MdmUser u " +
		           "JOIN FETCH u.node n " +
		           "JOIN u.mdmRole mr " +
		           "WHERE mr.sortOrder > :sortOrder " +
		           "AND u.userStats = :uStatus " +
		           "AND u.id != :userId " +
		           "AND NOT EXISTS (" +
		           "   SELECT 1 FROM LaaGroupTrackingDtl d " +
		           "   JOIN d.laaGroupTracking gt " +
		           "   WHERE d.mdmUser.id = u.id " +
		           "   AND gt.groupStats = :groupStats " +
		           "   AND gt.id != :editGrpId" +
		           ") " +
		           "ORDER BY u.serviceId")
		    List<MdmUser> findUsersNotInActiveGroup(
		            @Param("sortOrder") Integer sortOrder,
		            @Param("uStatus") Integer uStatus,
		            @Param("userId") Long userId,
		            @Param("groupStats") Integer groupStats,
		            @Param("editGrpId") Integer editGrpId);
		
	    @Query("SELECT u FROM MdmUser u " +
	           "JOIN FETCH u.node n " +
	           "WHERE u.id IN :ids " +
	           "AND u.id NOT IN (" +
	           "   SELECT d.mdmUser.id FROM LaaGroupTrackingDtl d " +
	           "   JOIN d.laaGroupTracking gt " +
	           "   WHERE gt.groupStats = 1 AND d.mdmUser.id IN :ids" +
	           ") " +
	           "ORDER BY u.id")
	    List<MdmUser> findValidUsersForActivation(@Param("ids") List<Long> ids);
}
