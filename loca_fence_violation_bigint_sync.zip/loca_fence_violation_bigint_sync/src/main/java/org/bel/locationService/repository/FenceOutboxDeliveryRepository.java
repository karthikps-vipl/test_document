package org.bel.locationService.repository;
import java.util.*; import org.bel.locationService.entity.FenceOutboxDelivery; import org.springframework.data.jpa.repository.JpaRepository;
public interface FenceOutboxDeliveryRepository extends JpaRepository<FenceOutboxDelivery,Long> { Optional<FenceOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId,String targetNodeId); }
