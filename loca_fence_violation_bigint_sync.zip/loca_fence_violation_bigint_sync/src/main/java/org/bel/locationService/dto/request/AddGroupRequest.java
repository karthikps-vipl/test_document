package org.bel.locationService.dto.request;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddGroupRequest {
	
	@NotNull(message = "The ID of the person making the request is required")
	private Long userId;
	
	@NotBlank(message = "Group name is required")
    private String group_name;

    @NotNull(message = "Group status is required")
    private Integer group_stats;

    @NotNull(message = "MDM User ID is required")
    private Long mdm_user__id;

    private Integer expiry_hour = 96; // Default to 96 if not provided in request

    @NotNull(message = "Members list cannot be null")
    private List<GroupMemberRequest> members;

    @Data
    public static class GroupMemberRequest {
        private Long id; // Maps to the member's mdm_user__id
        private Integer is_observer;
    }
}
