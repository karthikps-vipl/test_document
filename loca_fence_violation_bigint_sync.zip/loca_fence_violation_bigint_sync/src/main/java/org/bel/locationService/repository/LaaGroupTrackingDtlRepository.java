package org.bel.locationService.repository;

import java.util.Optional;

import org.bel.locationService.entity.LaaGroupTrackingDtl;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LaaGroupTrackingDtlRepository extends JpaRepository<LaaGroupTrackingDtl, Integer>{
	// Finds the accepted active group for a user
    Optional<LaaGroupTrackingDtl> findFirstByMdmUserIdAndStatusIgnoreCaseAndLaaGroupTracking_GroupStats(
    		Long mdmUserId, String status, Integer groupStats);
    
 // Checks if the user is in an active group (groupStats = 1) EXCEPT for the group currently being edited
    boolean existsByMdmUser_IdAndLaaGroupTracking_GroupStatsAndLaaGroupTracking_IdNot(
    		Long userId, 
            Integer groupStats, 
            Integer excludeGroupId
    );
    
    Optional<LaaGroupTrackingDtl> findFirstByMdmUser_Id(Integer mdmUserId);

	Optional<LaaGroupTrackingDtl> findByLaaGroupTrackingGroupUuidAndMdmUser_Id(String groupuuid, Long targetUserId);
}
