package org.bel.locationService.service.impl;

import java.util.List;

import org.bel.locationService.constants.AppConstants;
import org.bel.locationService.entity.NodeRegistry;
import org.bel.locationService.repository.NodeRegistryRepository;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeRegistryService {
	private final NodeRegistryRepository repo;
	private final CurrentNodeResolver resolver;

	public NodeRegistry getCurrentNode() {
		return resolver.getCurrentNode();
	}

	public String getCurrentNodeId() {
		return resolver.getCurrentNodeId();
	}

	public List<NodeRegistry> getOtherActiveNodes() {
		log.info("currrent Node id:{}", resolver.getCurrentNode());
		return repo.findByStatusAndNodeIdNot(AppConstants.ACTIVE, resolver.getCurrentNodeId());
	}
}
