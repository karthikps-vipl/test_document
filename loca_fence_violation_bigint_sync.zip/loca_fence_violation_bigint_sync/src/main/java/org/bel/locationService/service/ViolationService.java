package org.bel.locationService.service;

import java.util.List;

import org.bel.locationService.dto.request.AddViolationRequest;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.dto.response.ViolationListResponse;
import org.jspecify.annotations.Nullable;

import jakarta.validation.Valid;

public interface ViolationService {

	SingleResponse<String> addViolation(@Valid AddViolationRequest request);

	SingleResponse<List<ViolationListResponse>> violationList(Long userId);

}
