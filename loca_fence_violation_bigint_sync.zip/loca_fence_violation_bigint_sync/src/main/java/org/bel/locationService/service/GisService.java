package org.bel.locationService.service;

import java.util.List;

import org.bel.locationService.dto.request.AddFenceRequest;
import org.bel.locationService.dto.request.EditFenceRequest;
import org.bel.locationService.dto.response.FenceCreationResponse;
import org.bel.locationService.dto.response.FencingListResponse;
import org.bel.locationService.dto.response.SingleResponse;

import jakarta.validation.Valid;

public interface GisService {

	SingleResponse<List<FencingListResponse>> getFencingList(Long mdmUserId, String roleId);

	SingleResponse<FenceCreationResponse> addFence(AddFenceRequest request);

	SingleResponse<FencingListResponse> editFence(@Valid EditFenceRequest request);

	SingleResponse<String> deleteFence(Long fenceId);
}
