package org.bel.locationService.controller;

import java.util.List;

import org.bel.locationService.dto.request.ActivateGroupRequest;
import org.bel.locationService.dto.request.AddGroupRequest;
import org.bel.locationService.dto.request.ChangeGroupStatusRequest;
import org.bel.locationService.dto.request.EditGroupRequest;
import org.bel.locationService.dto.request.GroupInviteStatusRequest;
import org.bel.locationService.dto.response.ActiveGroupUserResponse;
import org.bel.locationService.dto.response.GroupListResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.dto.response.UserNotInGroupResponse;
import org.bel.locationService.service.GroupService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/group")
@RequiredArgsConstructor
public class GroupController {
	private final GroupService groupService;

    @GetMapping("/list")
    public ResponseEntity<SingleResponse<List<GroupListResponse>>> groupList(
																            @RequestHeader("X-User-Id") Long userId,
																            @RequestHeader("X-User-Role") String roleId,
																            @RequestParam(value = "filter", required = false) Integer filterOption
																            ){
        return ResponseEntity.ok(groupService.groupList(userId, roleId, filterOption));
    }
    
    @GetMapping("/usersNotInActiveGroup")
    public ResponseEntity<SingleResponse<List<UserNotInGroupResponse>>> getUsersNotInActiveGroup(
																					            @RequestParam("grpId") Integer grpId,
																					            @RequestHeader("X-User-Id") Long userId,
																					            @RequestHeader("X-User-Role") String roleId 
																					            ){
        return ResponseEntity.ok(groupService.getUsersNotInActiveGroup(grpId, userId, roleId));
    }
    
    @PostMapping("/add")
    public ResponseEntity<SingleResponse<String>> addGroup(@Valid @RequestBody AddGroupRequest request) {
        return ResponseEntity.ok(groupService.addGroup(request));
    }
    
    @PutMapping("/edit/{groupUuid}")
    public ResponseEntity<SingleResponse<String>> editGroup(
												            @PathVariable("groupUuid") String groupUuid,
												            @Valid @RequestBody EditGroupRequest request
												            ){
            return ResponseEntity.ok(groupService.editGroup(groupUuid, request));
    }
    
    @PutMapping("/changeStatus/{groupUuid}")
    public ResponseEntity<SingleResponse<String>> changeStatus(
													            @PathVariable("groupUuid") String groupUuid,
													            @RequestHeader("X-User-Id") Long userId,
													            @Valid @RequestBody ChangeGroupStatusRequest request
													            ){
            return ResponseEntity.ok(groupService.changeStatus(groupUuid, userId, request));
    }
    
    @PostMapping("/activeUsersList")
    public ResponseEntity<SingleResponse<List<ActiveGroupUserResponse>>> activateGroupUsers(@Valid @RequestBody ActivateGroupRequest request) {
        return ResponseEntity.ok(groupService.activateGroupUsers(request));
    }
    
    @PutMapping("/inviteStatus")
    public ResponseEntity<SingleResponse<String>> updateInviteStatus(
														    		@RequestHeader("X-User-Id") Long userId, // This 'id' refers to the mdm_user__id
														            @Valid @RequestBody GroupInviteStatusRequest request
														            ){
        return ResponseEntity.ok(groupService.updateInviteStatus(userId, request));
    }
}
