package org.bel.locationService.controller;


import java.util.List;

import org.bel.locationService.dto.request.AddLocationRequest;
import org.bel.locationService.dto.request.AddShareRequest;
import org.bel.locationService.dto.request.LocationHistoryRequest;
import org.bel.locationService.dto.response.LatestLocationResponse;
import org.bel.locationService.dto.response.LocationHistoryResponse;
import org.bel.locationService.dto.response.ShareListResponse;
import org.bel.locationService.dto.response.ShortestPathResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.service.LocationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/location")
@RequiredArgsConstructor
public class LocationController {

	private final LocationService locationService;

	@PostMapping("/v1/add") // NOT REQUIRED
	public ResponseEntity<SingleResponse<String>> addLocationHistory(@Valid @RequestBody AddLocationRequest request) {
		
		return ResponseEntity.ok(locationService.addLocationHistory(request));
	}

	@PostMapping("/history")
	public ResponseEntity<SingleResponse<List<LocationHistoryResponse>>> getLocationHistory(@Valid @RequestBody LocationHistoryRequest request) {
		return ResponseEntity.ok(locationService.getLocationHistory(request));
	}
	
	@GetMapping("/latest")
	public ResponseEntity<SingleResponse<List<LatestLocationResponse>>> getLatestLocation(@RequestHeader("X-User-Id")Long userId, 
															   						@RequestHeader("X-User-Role")String roleId){
		return ResponseEntity.ok(locationService.getLatestLocation(userId, roleId));
	}
	
	@PostMapping("/share/add")
    public ResponseEntity<SingleResponse<String>> addShare(@Valid @RequestBody AddShareRequest request) {
        return ResponseEntity.ok(locationService.addShare(request));
    }

    @GetMapping("/share/list")
    public ResponseEntity<SingleResponse<List<ShareListResponse>>> shareList(@RequestHeader("X-User-Id") Long userId) {
        return ResponseEntity.ok(locationService.shareList(userId));
    }

    @DeleteMapping("/share/delete/{shareId}")
    public ResponseEntity<SingleResponse<String>> deleteShare(@PathVariable Integer shareId) {
        return ResponseEntity.ok(locationService.deleteShare(shareId));
    }
    
    @GetMapping("/pathFinder")
    public ResponseEntity<SingleResponse<ShortestPathResponse>> findShortestPath(
																	            @RequestParam("startLon") Double startLon,
																	            @RequestParam("startLat") Double startLat,
																	            @RequestParam("endLon") Double endLon,
																	            @RequestParam("endLat") Double endLat
																	            ){
        return ResponseEntity.ok(locationService.findShortestPath(startLon, startLat, endLon, endLat));
    }
}
