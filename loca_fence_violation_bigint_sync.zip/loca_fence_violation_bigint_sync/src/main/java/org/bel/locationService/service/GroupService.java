package org.bel.locationService.service;

import java.util.List;

import org.bel.locationService.dto.request.ActivateGroupRequest;
import org.bel.locationService.dto.request.AddGroupRequest;
import org.bel.locationService.dto.request.ChangeGroupStatusRequest;
import org.bel.locationService.dto.request.EditGroupRequest;
import org.bel.locationService.dto.request.GroupInviteStatusRequest;
import org.bel.locationService.dto.response.ActiveGroupUserResponse;
import org.bel.locationService.dto.response.GroupListResponse;
import org.bel.locationService.dto.response.SingleResponse;
import org.bel.locationService.dto.response.UserNotInGroupResponse;

import jakarta.validation.Valid;

public interface GroupService {

	SingleResponse<List<GroupListResponse>> groupList(Long userId, String roleId, Integer filterOption);

	SingleResponse<List<UserNotInGroupResponse>> getUsersNotInActiveGroup(Integer grpId, Long userId, String roleId);

	SingleResponse<String> addGroup(@Valid AddGroupRequest request);
	
SingleResponse<String> editGroup(String groupUuid, @Valid EditGroupRequest request);
	
	SingleResponse<String> changeStatus(String groupUuid, Long userId, ChangeGroupStatusRequest request);

	SingleResponse<List<ActiveGroupUserResponse>> activateGroupUsers(@Valid ActivateGroupRequest request);
	
	SingleResponse<String> updateInviteStatus(Long targetUserId, GroupInviteStatusRequest request);
}
