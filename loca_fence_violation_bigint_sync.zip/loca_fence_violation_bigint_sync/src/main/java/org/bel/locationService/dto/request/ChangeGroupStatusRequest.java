package org.bel.locationService.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChangeGroupStatusRequest {
	@NotNull(message = "Status is required")
    private Integer status;

    @NotBlank(message = "Group name is required")
    private String name;
}
