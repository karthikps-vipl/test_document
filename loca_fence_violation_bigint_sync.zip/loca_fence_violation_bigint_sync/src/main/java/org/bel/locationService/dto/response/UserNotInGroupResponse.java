package org.bel.locationService.dto.response;

import org.bel.locationService.entity.MdmUser;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserNotInGroupResponse {
	private Long id;
    private String service_id;
    private String usr_name;
    private String mdm_node__id;
    private String node_name;
    private Integer mdm_user_type__id;
    private Integer user_stats;

    // Constructor to map directly from the MdmUser entity
    public UserNotInGroupResponse(MdmUser user) {
        this.id = user.getId();
        this.service_id = user.getServiceId();
        this.usr_name = user.getUsrName();
        this.user_stats = user.getUserStats();
        
        if (user.getNode() != null) {
            this.mdm_node__id = user.getNode().getNodeId();
            this.node_name = user.getNode().getNodeName();
        }
        
        if (user.getMdmUserType() != null) {
            this.mdm_user_type__id = user.getMdmUserType().getId();
        }
    }
}
