package org.bel.locationService.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CustomStatus {
	
	NO_TOKEN_PROVIDED(1, "Token is not provided"), 
	INVALID_SESSION(2, "Session is invalid"),
	SESSION_EXPIRED(3, "Session is expired"), 
	USER_NOT_FOUND(4, "User not found"),
	INTERNAL_SERVER_ERROR(5, "Internal server error occurred"), 
	BAD_REQUEST(6, "Bad request"),
	FORBIDDEN(7, "Forbidden"), 
	INVALID_PIN(8, "Invalid PIN format. Must be a 6-digit number."),
	DEVICE_NOT_FOUND(9, "Device not found"),
	DEVICE_LOCKED(10, "Device is locked due to multiple incorrect PIN attempts"),
	INVALID_PASSWORD(11, "Wrong password"),
	INCORRECT_OLD_PIN(12, "Provided old pin is incorrect"),
	INCORRECT_PIN(13,"Incorrect pin"),
	UE_MAPPING_NOT_FOUND(14, "None of the UE is mapped to this user"),
	OLD_AND_NEW_PIN_SAME(15,"New pin and the old pin cannot be same"),
	USER_ALREADY_SIGNED_UP(16, "User already signed up"),
	USER_ALREADY_EXISTS(17, "User already exists"),
	UNAUTHORISED(18, "You are not authorised to perform this action"),
	DEVICE_TYPE_NOT_FOUND(19, "Device type not found"),
	MDM_USER_UE_MAPPING_NOT_FOUND(20, "No Devices mapped for this user"),
	DEVICE_LOCATION_HISTORY_NOT_FOUND(21, "Device location history not found"),
	ACCOUNT_NOT_FOUND(22, "Provided account details is not found"),
	ACCOUNT_DELETED(23, "User account is deleted"),
	USER_LOCKED(24, "User is locked"),
	SIGNUP_INCOMPLETE(25, "Sign is incomplete"),
	USER_DEACTIVATED(26, "User account is in 'DEACTIVATED' state"),
    INVALID_DATE_RANGE(27, "The 'To Date and Time' cannot be earlier than the 'From Date and Time'."),
    FENCE_NOT_FOUND(28, "Provided fence details is not found."),
    LOCATION_NOT_FOUND(29, "Provided Location not found in the DB"),
    START_NODE_NOT_FOUND(30, "Could not find nearest start node"),
    END_NODE_NOT_FOUND(31, "Could not find nearest end node"),
    ROUTE_NOT_FOUND(32, "No route found between coordinates"),
    USER_ALREADY_IN_GROUP(33, "User already has an active group"),
    ONE_MEMBER_AS_OBSERVER(34, "Only one member can be marked as observer in a group"),
    ROLE_NOT_FOUND(35, "Provided role Id not found."),
	SENDER_ACCOUNT_NOT_FOUND(36, "Provided sender account details is not found"),
	RECIPIENT_ACCOUNT_NOT_FOUND(37, "Provided recipient account details is not found"),
    GROUP_NOT_FOUND(38, "Group not found"),
    DEVICE_ALREADY_EXISTS(39, "Device already exists"),
    MDM_NODE_NOT_FOUND(40, "Node not found"),
    MDM_USER_TYPE_NOT_FOUND(41, "User type not found"),
    REFRESH_TOKEN_EXPIRED(42, "Token expired login again."),
    INVALID_REFRESH_TOKEN(43, "Refresh token is invalid."),
    INVALID_IP_ADDRESS(44, "The IP address provided is not a valid IPv4/IPv6 address."),
	DUPLICATE_IP(45, "This IP address is already assigned to another node."),
	NODE_NOT_FOUND(46, "Provided node details not found in the records."),
	IP_ADDRESS_ALREADY_IN_USE(47, "IP address is already in use by another active node."),
	INVALID_BOUNDARY_FORMAT(48,"Invalid boundary format"),
	MEMBERS_LIMITATION(49,"Only 10 members can be in a group"),

	SUCCESS(1, "SUCCESS"),
	FAILURE(0, "FAILURE"),
	// 503
	SERVICE_UNAVAILABLE(-101, "Requested service is unavailable."),
	// 502
	MICROSERVICE_CALL_FAILED(-100, "Microservice call failed.");

	private final int code;
	private final String message;

	public static CustomStatus fromCode(int code) {
		for (CustomStatus status : CustomStatus.values()) {
			if (status.getCode() == code) {
				return status;
			}
		}
		// Fallback if the downstream code isn't explicitly defined in this gateway service enum
		return CustomStatus.MICROSERVICE_CALL_FAILED;
	}
}