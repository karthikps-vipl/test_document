package org.bel.locationService.dto.response;

import java.time.LocalDateTime;

import org.bel.locationService.entity.LaaGisFencingViolation;

import com.fasterxml.jackson.annotation.JsonRawValue;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ViolationListResponse {
	private Long id;
    private LocalDateTime violatedAt;
    private String fenceName;
    private Integer fenceStatus;
    
    @JsonRawValue
    private String fencingBoundary;
    
    private Integer mdmRoleId;
    private Long mdmUserId;

    // Constructor to cleanly map the nested Entity data into a flat JSON structure
    public ViolationListResponse(LaaGisFencingViolation violation) {
        this.id = violation.getId();
        this.violatedAt = violation.getViolatedAt();
        this.fenceName = violation.getLaaGisFencing().getFenceName();
        this.fenceStatus = violation.getLaaGisFencing().getFenceStatus();
        this.fencingBoundary = violation.getLaaGisFencing().getFencingBoundary();
        
        if (violation.getMdmUser() != null) {
            this.mdmUserId = violation.getMdmUser().getId();
            if (violation.getMdmUser().getMdmRole().getId() != null) {
                this.mdmRoleId = violation.getMdmUser().getMdmRole().getId();
            }
        }
    }
}
