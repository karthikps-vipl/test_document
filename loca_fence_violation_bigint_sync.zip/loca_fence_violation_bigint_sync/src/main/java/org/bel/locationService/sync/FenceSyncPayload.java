package org.bel.locationService.sync;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class FenceSyncPayload { private String action; private Long fenceId; private Long userId; private String createdBy; private String updatedBy; private Integer fenceStatus; private String fenceName; private String fencingBoundary; }
