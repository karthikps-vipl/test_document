package org.bel.locationService.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GroupMemberResponse {
	private Long mdm_user__id;
    private String service_id;
    private String usr_name;
    private String status;
    private String node_id;
    private String node_name;
    private Integer is_observer;
}
