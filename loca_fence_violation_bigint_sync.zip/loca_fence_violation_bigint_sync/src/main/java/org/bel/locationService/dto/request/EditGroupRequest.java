package org.bel.locationService.dto.request;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EditGroupRequest {

    @NotBlank(message = "Group name is required")
    private String group_name;

    @NotNull(message = "Group status is required")
    private Integer group_stats;

    @NotNull(message = "MDM User ID is required")
    private Long mdm_user__id;

    private Integer expiry_hour = 96;

    @NotNull(message = "Members list cannot be null")
    private List<GroupMemberRequest> members;

    @Data
    public static class GroupMemberRequest {
        private Long id; // mdm_user__id
        private Integer is_observer;
    }
}
