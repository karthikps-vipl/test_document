import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";
import "@testing-library/jest-dom";

// --------------------------------------------------
// ESM MOCKS - Register before importing component
// --------------------------------------------------

jest.unstable_mockModule("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.unstable_mockModule("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");

  return {
    ...actual,
    useTheme: jest.fn(() => ({
      palette: { mode: "light" },
    })),
  };
});

jest.unstable_mockModule("antd/es/input/TextArea", () => ({
  default: function MockTextArea({
    value,
    onChange,
    placeholder,
    rows,
    className,
    style,
  }) {
    return (
      <textarea
        data-testid="status-textarea"
        rows={rows}
        value={value}
        placeholder={placeholder}
        className={className}
        style={style}
        onChange={onChange}
      />
    );
  },
}));

jest.unstable_mockModule("@/RestAPI/api/axiosApicall", () => ({
  HelpDeskAxios: jest.fn(),
}));

jest.unstable_mockModule("@/RestAPI/url/endpoint", () => ({
  UPDATE_TICKET: "/api/ticket/update",
}));

jest.unstable_mockModule("@/components/Reusable/Toast/Toast", () => ({
  default: jest.fn(),
}));

jest.unstable_mockModule("@/assets/SVGIcons/question_mark.svg", () => ({
  default: "confirm-icon.svg",
}));

jest.unstable_mockModule(
  "@/components/Reusable/Button/MButtonPrimary",
  () => ({
    default: function MockMButtonPrimary({
      children,
      onClick,
      disabled,
    }) {
      return (
        <button
          type="button"
          onClick={onClick}
          disabled={disabled}
        >
          {children}
        </button>
      );
    },
  })
);

jest.unstable_mockModule(
  "@/components/Reusable/Dialog/MDialog",
  () => ({
    default: function MockMDialog({
      open,
      title,
      message,
      onConfirm,
      onClose,
      isChildFullScreen,
    }) {
      if (!open) return null;

      return (
        <div
          role="dialog"
          aria-label={title}
          data-fullscreen={String(Boolean(isChildFullScreen))}
        >
          <p>{message}</p>

          <button type="button" onClick={onConfirm}>
            Confirm Status
          </button>

          <button type="button" onClick={onClose}>
            Cancel Status
          </button>
        </div>
      );
    },
  })
);

// --------------------------------------------------
// DYNAMIC IMPORTS - After ESM mocks
// --------------------------------------------------

const { useSelector } = await import("react-redux");
const { useTheme } = await import("@mui/material");

const { HelpDeskAxios } = await import(
  "@/RestAPI/api/axiosApicall"
);

const { default: Toast } = await import(
  "@/components/Reusable/Toast/Toast"
);

const { default: HandleStatusUpdateAction } = await import(
  "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleStatusUpdateAction"
);

// --------------------------------------------------
// TESTS
// --------------------------------------------------

describe("HandleStatusUpdateAction", () => {
  const onClose = jest.fn();
  const onRefresh = jest.fn();

  const defaultState = {
    userSlice: {
      userDetails: {
        data: {
          userName: "alex.ops",
        },
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();

    useSelector.mockImplementation((selectorFn) =>
      selectorFn(defaultState)
    );

    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    HelpDeskAxios.mockResolvedValue({
      status: 200,
    });
  });

  test("renders initial state with Update disabled and formatted mode placeholder", () => {
    render(
      <HandleStatusUpdateAction
        id="101"
        mode="IN_PROGRESS"
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    expect(
      screen.getByText("Status Update Remark *")
    ).toBeInTheDocument();

    expect(screen.getByText("0/255")).toBeInTheDocument();

    const textarea = screen.getByTestId("status-textarea");

    expect(textarea).toHaveValue("");

    expect(textarea).toHaveAttribute(
      "placeholder",
      "Enter comments to move to in progress..."
    );

    expect(
      screen.getByRole("button", { name: "Update" })
    ).toBeDisabled();
  });

  // The original description-validation test remains commented out.

  test("applies dark theme styles, opens/closes confirm dialog, and sets isChildFullScreen", () => {
    useTheme.mockReturnValue({
      palette: { mode: "dark" },
    });

    render(
      <HandleStatusUpdateAction
        id="101"
        mode="PENDING"
        isChildFullScreen={true}
      />
    );

    const textarea = screen.getByTestId("status-textarea");

    expect(textarea).toHaveClass("dark-ant-textarea");
    expect(textarea.style.background).toBe("rgb(51, 51, 51)");
    expect(textarea.style.color).toBe("rgb(255, 255, 255)");

    fireEvent.change(textarea, {
      target: { value: "Waiting on vendor" },
    });

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    const dialog = screen.getByRole("dialog", {
      name: "Confirm Status Change",
    });

    expect(dialog).toHaveAttribute("data-fullscreen", "true");

    expect(
      screen.getByText(
        "Are you sure you want to update this ticket to pending?"
      )
    ).toBeInTheDocument();

    fireEvent.click(
      screen.getByRole("button", { name: "Cancel Status" })
    );

    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  test("submits RESOLVED with ticketData.ticketId, latest subDetail, and 201 response", async () => {
    HelpDeskAxios.mockResolvedValueOnce({
      status: 201,
    });

    const ticketData = {
      ticketId: "TICKET-900",
      hdTicketSubDetails: [
        {
          sequenceNum: 1,
          loggedinUser: "first.user",
        },
        {
          sequenceNum: 5,
          loggedinUser: "latest.engineer",
        },
      ],
    };

    render(
      <HandleStatusUpdateAction
        id="STATUS-1"
        mode="RESOLVED"
        ticketData={ticketData}
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    fireEvent.change(
      screen.getByTestId("status-textarea"),
      {
        target: { value: "Root cause fixed" },
      }
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Status" })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        {
          hdTicketStatus: { id: "4" },
          hdTicketDetail: { id: "TICKET-900" },
          sequenceNum: 5,
          statement: "Root cause fixed",
          loggedinUser: "latest.engineer",
        }
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket moved to Resolved successfully!",
      "success"
    );

    expect(onRefresh).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("handles IN_PROGRESS and PENDING modes with fallback id, userName, and 200 response", async () => {
    HelpDeskAxios.mockResolvedValueOnce({
      status: 200,
    });

    render(
      <HandleStatusUpdateAction
        id="42"
        mode="in-progress"
        ticketData={{ hdTicketSubDetails: [] }}
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    fireEvent.change(
      screen.getByTestId("status-textarea"),
      {
        target: { value: "Investigating alert" },
      }
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Status" })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        {
          hdTicketStatus: { id: "2" },
          hdTicketDetail: { id: "42" },
          sequenceNum: 1,
          statement: "Investigating alert",
          loggedinUser: "alex.ops",
        }
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket moved to In Progress successfully!",
      "success"
    );
  });

  test("handles invalid mode, non-200/201 status, API rejection, and missing id", async () => {
    const errSpy = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    const alertSpy = jest
      .spyOn(window, "alert")
      .mockImplementation(() => {});

    // 1. Invalid mode
    const { rerender } = render(
      <HandleStatusUpdateAction
        id="10"
        mode="UNKNOWN_MODE"
      />
    );

    fireEvent.change(
      screen.getByTestId("status-textarea"),
      {
        target: { value: "Testing invalid mode" },
      }
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Status" })
    );

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error",
        "Invalid status mode selected",
        "error"
      );
    });

    // 2. Non-200/201 response + empty userName -> system
    useSelector.mockImplementation((selectorFn) =>
      selectorFn({
        userSlice: {
          userDetails: {
            data: {
              userName: "",
            },
          },
        },
      })
    );

    HelpDeskAxios.mockResolvedValueOnce({
      status: 422,
    });

    rerender(
      <HandleStatusUpdateAction
        id="10"
        mode="PENDING"
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Status" })
    );

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        expect.objectContaining({
          loggedinUser: "system",
          hdTicketStatus: { id: "3" },
        })
      );

      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Failed to update status",
        "error"
      );
    });

    // 3. API rejection
    HelpDeskAxios.mockRejectedValueOnce(
      new Error("Server error")
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Status" })
    );

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "An error occurred while updating",
        "error"
      );
    });

    // 4. Missing ID
    rerender(
      <HandleStatusUpdateAction mode="PENDING" />
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Update" })
    );

    fireEvent.click(
      screen.getByRole("button", { name: "Confirm Status" })
    );

    expect(alertSpy).toHaveBeenCalledWith(
      "Error: Missing Ticket ID"
    );

    errSpy.mockRestore();
    alertSpy.mockRestore();
  });
});
