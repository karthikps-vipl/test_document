import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as fabricModule from "fabric";
import TopologyEditActions from "./TopologyEditActions";
import portAdminDownSvg from "./assets/port-admin-down.svg?raw";
import portDownSvg from "./assets/port-down.svg?raw";
import portNotConfiguredSvg from "./assets/port-not-configured.svg?raw";
import portUpSvg from "./assets/port-up.svg?raw";

const fabric = fabricModule;

fabric.FabricObject.customProperties = ["id", "shapeType", "metadata"];

const STATUS_COLORS = {
  up: "#16a34a",
  down: "#dc2626",
  maintenance: "#d97706",
  notDiscovered: "#2563eb",
};

const PORT_STATUS_SVGS = {
  up: portUpSvg,
  adminDown: portAdminDownSvg,
  down: portDownSvg,
  notConfigured: portNotConfiguredSvg,
};

const PORT_STATUS_STYLES = {
  up: {
    fill: "#16a34a",
    stroke: "#0f5132",
    lineStroke: "#dcfce7",
  },
  adminDown: {
    fill: "#dc2626",
    stroke: "#7f1d1d",
    lineStroke: "#fee2e2",
  },
  down: {
    fill: "#f97316",
    stroke: "#9a3412",
    lineStroke: "#ffedd5",
  },
  notConfigured: {
    fill: "#9ca3af",
    stroke: "#4b5563",
    lineStroke: "#f3f4f6",
  },
};

const SWITCH_24_DEVICE_ID = "switch-24-ports";
const PORT_STATUS_KEYS = ["up", "adminDown", "down", "notConfigured"];
const SWITCH_PORT_ORDER = [
  1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20,
  22, 24,
];

const SAMPLE_TERMINALS = [
  {
    id: "terminal-north",
    name: "North Terminal",
    devices: [
      {
        id: "vsat-101",
        name: "VSAT-101",
        ipAddress: "10.10.10.11",
        status: "up",
        segment: "VSAT",
      },
      {
        id: "radio-108",
        name: "RADIO-108",
        ipAddress: "10.10.10.18",
        status: "maintenance",
        segment: "RADIO",
      },
      {
        id: SWITCH_24_DEVICE_ID,
        name: "Switch 24-Ports",
        ipAddress: "10.10.10.24",
        status: "up",
        segment: "SWITCH",
        type: "switch24",
      },
    ],
  },
  {
    id: "terminal-south",
    name: "South Terminal",
    devices: [
      {
        id: "vsat-209",
        name: "VSAT-209",
        ipAddress: "10.20.20.9",
        status: "down",
        segment: "VSAT",
      },
      {
        id: "radio-216",
        name: "RADIO-216",
        ipAddress: "10.20.20.16",
        status: "notDiscovered",
        segment: "RADIO",
      },
    ],
  },
];

const makeId = (prefix) =>
  `${prefix}-${Math.random().toString(36).slice(2, 10)}`;

const normalizeStatus = (status) => {
  const value = `${status ?? ""}`.trim().toLowerCase();

  if (value === "up") {
    return "up";
  }

  if (value === "down") {
    return "down";
  }

  if (value === "maintenance") {
    return "maintenance";
  }

  return "notDiscovered";
};

const resolvePortStatus = ({ opStatus, adminStatus }) => {
  if (adminStatus === 3 || adminStatus === 0) {
    return "notConfigured";
  }

  if (opStatus === 1 && adminStatus === 1) {
    return "up";
  }

  if (opStatus === 1 && adminStatus === 2) {
    return "adminDown";
  }

  if (opStatus === 2 && (adminStatus === 1 || adminStatus === 2)) {
    return "down";
  }

  return "notConfigured";
};

const getRandomPortState = () => {
  const candidates = [
    { opStatus: 1, adminStatus: 1 },
    { opStatus: 1, adminStatus: 2 },
    { opStatus: 2, adminStatus: 1 },
    { opStatus: 2, adminStatus: 2 },
    { opStatus: 3, adminStatus: 3 },
    { opStatus: 2, adminStatus: 0 },
    { opStatus: 1, adminStatus: 3 },
    { opStatus: 0, adminStatus: 0 },
  ];

  const state = candidates[Math.floor(Math.random() * candidates.length)];

  return {
    ...state,
    statusKey: resolvePortStatus(state),
  };
};

const getRandomNextPortState = (currentStatusKey) => {
  const nextStatusKeys = PORT_STATUS_KEYS.filter(
    (statusKey) => statusKey !== currentStatusKey,
  );
  const nextStatusKey =
    nextStatusKeys[Math.floor(Math.random() * nextStatusKeys.length)];

  if (nextStatusKey === "up") {
    return { opStatus: 1, adminStatus: 1, statusKey: "up" };
  }

  if (nextStatusKey === "adminDown") {
    return { opStatus: 1, adminStatus: 2, statusKey: "adminDown" };
  }

  if (nextStatusKey === "down") {
    return {
      opStatus: 2,
      adminStatus: Math.random() > 0.5 ? 1 : 2,
      statusKey: "down",
    };
  }

  return {
    opStatus: [0, 1, 2, 3][Math.floor(Math.random() * 4)],
    adminStatus: Math.random() > 0.5 ? 0 : 3,
    statusKey: "notConfigured",
  };
};

const loadFabricImage = async (src) => {
  const majorVersion = Number.parseInt(
    `${fabric.version ?? "6"}`.split(".")[0],
    10,
  );

  if (majorVersion >= 6) {
    return fabric.Image.fromURL(src, { crossOrigin: "anonymous" });
  }

  return new Promise((resolve) => {
    fabric.Image.fromURL(src, (image) => resolve(image), {
      crossOrigin: "anonymous",
    });
  });
};

const loadSvgGroup = async (svgString) => {
  const parsed = await fabric.loadSVGFromString(svgString);
  const objects = (parsed.objects ?? []).filter(Boolean);
  const options = parsed.options ?? {};

  return fabric.util.groupSVGElements(objects, options);
};

const getFabricObjectChildren = (object) =>
  object.getObjects?.() ?? object._objects ?? [];

const applyPortChildVisualState = (object, style) => {
  const objectType = `${object.type ?? ""}`.toLowerCase();
  const children = getFabricObjectChildren(object);

  if (objectType === "rect") {
    object.set({
      fill: style.fill,
      stroke: style.stroke,
    });
    object.dirty = true;
  }

  if (objectType === "path" || objectType === "line") {
    object.set({
      stroke: style.lineStroke,
    });
    object.dirty = true;
  }

  children.forEach((child) => applyPortChildVisualState(child, style));
};

const applyPortVisualState = (portObject, portState) => {
  const style = PORT_STATUS_STYLES[portState.statusKey];

  applyPortChildVisualState(portObject, style);
  portObject.set({
    opacity: 1,
    metadata: {
      ...portObject.metadata,
      opStatus: portState.opStatus,
      adminStatus: portState.adminStatus,
      statusKey: portState.statusKey,
      lastMockUpdateAt: new Date().toISOString(),
    },
  });
  portObject.dirty = true;
  portObject.setCoords();
};

const createSwitchPortObject = async ({
  markerId,
  portNumber,
  rowIndex,
  columnIndex,
}) => {
  const portState = getRandomPortState();
  const portObject = await loadSvgGroup(PORT_STATUS_SVGS[portState.statusKey]);
  const left = -170 + columnIndex * 31;
  const top = rowIndex === 0 ? -20 : 23;

  portObject.set({
    id: `${markerId}-port-${portNumber}`,
    shapeType: "switch24Port",
    left,
    top,
    originX: "center",
    originY: "center",
    selectable: false,
    evented: false,
    objectCaching: false,
    metadata: {
      kind: "switch24-port",
      markerId,
      portNumber,
      opStatus: portState.opStatus,
      adminStatus: portState.adminStatus,
      statusKey: portState.statusKey,
    },
  });

  return portObject;
};

const createSwitchPortLabel = ({
  markerId,
  portNumber,
  rowIndex,
  columnIndex,
}) =>
  new fabric.Text(`${portNumber}`, {
    id: `${markerId}-port-label-${portNumber}`,
    shapeType: "switch24PortLabel",
    left: -170 + columnIndex * 31,
    top: rowIndex === 0 ? -38 : 5,
    originX: "center",
    originY: "center",
    fontSize: 8,
    fontFamily: "Arial",
    fill: "#334155",
    selectable: false,
    evented: false,
    metadata: {
      kind: "switch24-port-label",
      markerId,
      portNumber,
    },
  });

const buildSwitch24Object = async ({ terminal, device, segment }) => {
  const markerId = makeId("switch24");
  const baseRect = new fabric.Rect({
    left: 0,
    top: 0,
    width: 390,
    height: 124,
    fill: "rgba(255,255,255,0)",
    stroke: "#111827",
    strokeWidth: 2,
    rx: 6,
    ry: 6,
    originX: "center",
    originY: "center",
    selectable: false,
    evented: false,
  });
  const title = new fabric.Text("Switch 24-Ports", {
    left: 0,
    top: -52,
    originX: "center",
    originY: "center",
    fontSize: 12,
    fontFamily: "Arial",
    fontWeight: "bold",
    fill: "#0f172a",
    selectable: false,
    evented: false,
  });
  const portObjects = [];

  for (const [index, portNumber] of SWITCH_PORT_ORDER.entries()) {
    const rowIndex = index < 12 ? 0 : 1;
    const columnIndex = index % 12;

    portObjects.push(
      createSwitchPortLabel({ markerId, portNumber, rowIndex, columnIndex }),
    );
    portObjects.push(
      await createSwitchPortObject({
        markerId,
        portNumber,
        rowIndex,
        columnIndex,
      }),
    );
  }

  const switchObject = new fabric.Group([baseRect, title, ...portObjects], {
    ...selectableDefaults,
    id: markerId,
    shapeType: "switch24",
    left: 260,
    top: 150,
    originX: "center",
    originY: "center",
    subTargetCheck: false,
    objectCaching: false,
    metadata: {
      kind: "switch24",
      terminalId: terminal?.id,
      terminalName: terminal?.name,
      deviceId: device?.id,
      deviceName: device?.name,
      ipAddress: device?.ipAddress,
      segment: segment || device?.segment,
      portOrder: SWITCH_PORT_ORDER,
    },
  });

  return switchObject;
};

const buildMockPortTelemetryBatch = (ports) => {
  const updateCount = Math.min(ports.length, 8);
  const shuffledPorts = [...ports].sort(() => Math.random() - 0.5);

  return shuffledPorts.slice(0, updateCount).map((portObject) => ({
    portObject,
    portNumber: portObject.metadata?.portNumber,
    ...getRandomNextPortState(portObject.metadata?.statusKey),
  }));
};

const updateRandomSwitchPorts = (switchObject) => {
  const ports = getFabricObjectChildren(switchObject).filter(
    (child) => child.shapeType === "switch24Port",
  );

  if (!ports.length) {
    return;
  }

  const telemetryBatch = buildMockPortTelemetryBatch(ports);

  telemetryBatch.forEach(({ portObject, ...portState }) => {
    applyPortVisualState(portObject, portState);
  });
  switchObject.set({
    metadata: {
      ...switchObject.metadata,
      lastMockTelemetry: telemetryBatch.map(
        ({ portNumber, opStatus, adminStatus, statusKey }) => ({
          portNumber,
          opStatus,
          adminStatus,
          statusKey,
        }),
      ),
      lastMockUpdateAt: new Date().toISOString(),
    },
  });
  switchObject.set("dirty", true);
  switchObject.dirty = true;
  switchObject.setCoords();
};

const getImageNaturalSize = (image) => {
  const sourceElement = image.getElement?.();

  return {
    width: sourceElement?.naturalWidth || image.width || 1680,
    height: sourceElement?.naturalHeight || image.height || 720,
  };
};

const setHighQualityCanvasRendering = (canvas) => {
  canvas.imageSmoothingEnabled = true;

  [canvas.contextContainer, canvas.contextTop].forEach((context) => {
    if (!context) {
      return;
    }

    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
  });
};

const fitTopologyImageToCanvas = (canvas, host, image) => {
  const { width, height } = getImageNaturalSize(image);
  const bounds = host?.getBoundingClientRect();
  const canvasWidth = Math.max(Math.round(bounds?.width || 0), 360);
  const canvasHeight = Math.max(Math.round(bounds?.height || 0), 280);
  const scale = Math.min(canvasWidth / width, canvasHeight / height);
  const fittedWidth = width * scale;
  const fittedHeight = height * scale;

  canvas.setDimensions({ width: canvasWidth, height: canvasHeight });
  canvas.setZoom(1);
  canvas.viewportTransform = [1, 0, 0, 1, 0, 0];
  setHighQualityCanvasRendering(canvas);

  image.set({
    left: (canvasWidth - fittedWidth) / 2,
    top: (canvasHeight - fittedHeight) / 2,
    originX: "left",
    originY: "top",
    scaleX: scale,
    scaleY: scale,
    selectable: false,
    evented: false,
    excludeFromExport: false,
    objectCaching: false,
    noScaleCache: true,
    metadata: {
      originalWidth: width,
      originalHeight: height,
      renderScale: scale,
    },
  });

  canvas.backgroundImage = image;
  canvas.calcOffset();
  canvas.requestRenderAll();
};

const selectableDefaults = {
  transparentCorners: false,
  cornerColor: "#0f766e",
  borderColor: "#0f766e",
  cornerStyle: "circle",
  padding: 4,
  lockUniScaling: false,
  snapAngle: 90,
};

const buildLineObject = (lineType) => {
  const line = new fabric.Line([-90, 0, 90, 0], {
    stroke: "#111827",
    strokeWidth: 4,
    strokeLineCap: "round",
    originX: "center",
    originY: "center",
  });
  const objects = [line];

  if (lineType === "arrow" || lineType === "doubleArrow") {
    objects.push(
      new fabric.Triangle({
        width: 16,
        height: 20,
        left: 96,
        top: 0,
        fill: "#111827",
        angle: 90,
        originX: "center",
        originY: "center",
      }),
    );
  }

  if (lineType === "doubleArrow") {
    objects.push(
      new fabric.Triangle({
        width: 16,
        height: 20,
        left: -96,
        top: 0,
        fill: "#111827",
        angle: -90,
        originX: "center",
        originY: "center",
      }),
    );
  }

  return new fabric.Group(objects, {
    ...selectableDefaults,
    id: makeId(lineType),
    shapeType: lineType,
    left: 120,
    top: 120,
    originX: "center",
    originY: "center",
    metadata: {
      kind: "connector",
      lineType,
    },
  });
};

const buildDeviceObjects = ({ terminal, device, segment, radioWidth }) => {
  const statusKey = normalizeStatus(device?.status);
  const markerId = makeId("device");
  const indicatorRadius = Number(radioWidth) > 0 ? Number(radioWidth) : 8;
  const metadata = {
    kind: "device",
    markerId,
    terminalId: terminal?.id,
    terminalName: terminal?.name,
    deviceId: device?.id,
    deviceName: device?.name,
    ipAddress: device?.ipAddress,
    status: statusKey,
    segment: segment || device?.segment,
    radioWidth: indicatorRadius,
  };
  const rect = new fabric.Rect({
    ...selectableDefaults,
    id: `${markerId}-rectangle`,
    shapeType: "deviceRectangle",
    left: 120,
    top: 96,
    width: 144,
    height: 58,
    fill: "rgba(255,255,255,0)",
    stroke: "#111827",
    strokeWidth: 2,
    originX: "center",
    originY: "center",
    metadata: {
      ...metadata,
      kind: "device-rectangle",
    },
  });
  const indicator = new fabric.Circle({
    ...selectableDefaults,
    id: `${markerId}-status`,
    shapeType: "deviceStatus",
    left: 62,
    top: 78,
    radius: indicatorRadius,
    fill: STATUS_COLORS[statusKey],
    stroke: "#ffffff",
    strokeWidth: 2,
    originX: "center",
    originY: "center",
    metadata: {
      ...metadata,
      kind: "device-status-indicator",
    },
  });

  return { rect, indicator };
};

const downloadJson = (payload) => {
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = `fabric-topology-${Date.now()}.json`;
  link.click();
  URL.revokeObjectURL(url);
};

const saveTopologyJson = async (payload) => {
  const response = await fetch("/api/save-topology", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      fileName: `fabric-topology-${Date.now()}`,
      topology: payload,
    }),
  });

  const result = await response.json();

  if (!response.ok || !result.ok) {
    throw new Error(result.message || "Unable to save topology JSON");
  }

  return result;
};

const FabricTopology = ({
  topologyRenderMode = "svg",
  setTopologyRenderMode,
  terminals,
}) => {
  const canvasElementRef = useRef(null);
  const canvasHostRef = useRef(null);
  const fabricCanvasRef = useRef(null);
  const backgroundImageRef = useRef(null);
  const lastCreatedDeviceKeyRef = useRef("");
  const switch24ObjectsRef = useRef(new Map());

  const [fabricForm, setFabricForm] = useState({
    terminalId: "",
    deviceId: "",
    segment: "",
    radioWidth: "8",
  });
  const [selectedObject, setSelectedObject] = useState(null);
  const [backgroundImageSource, setBackgroundImageSource] = useState("");
  const [notice, setNotice] = useState(
    "Upload a JPG topology image to start marking devices.",
  );
  const [tooltip, setTooltip] = useState(null);

  const fabricTerminals = terminals?.length ? terminals : SAMPLE_TERMINALS;

  const selectedTerminal = useMemo(
    () =>
      fabricTerminals.find((terminal) => terminal.id === fabricForm.terminalId),
    [fabricForm.terminalId, fabricTerminals],
  );
  const fabricDevices = selectedTerminal?.devices ?? [];

  const resizeCanvas = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    const host = canvasHostRef.current;

    if (!canvas || !host) {
      return;
    }

    const bounds = host.getBoundingClientRect();

    if (backgroundImageRef.current) {
      fitTopologyImageToCanvas(canvas, host, backgroundImageRef.current);
      return;
    }

    canvas.setDimensions({
      width: Math.max(Math.round(bounds.width), 1680),
      height: Math.max(Math.round(bounds.height), 720),
    });

    canvas.requestRenderAll();
  }, []);

  useEffect(() => {
    const canvas = new fabric.Canvas(canvasElementRef.current, {
      backgroundColor: "#ffffff",
      enableRetinaScaling: true,
      preserveObjectStacking: true,
      selection: true,
    });

    fabricCanvasRef.current = canvas;

    const handleSelection = () => {
      const activeObject = canvas.getActiveObject() ?? null;

      setSelectedObject(activeObject);

      if (activeObject?.shapeType === "deviceStatus") {
        setFabricForm((current) => ({
          ...current,
          radioWidth: `${activeObject.radius ?? 8}`,
        }));
      }
    };
    const clearSelection = () => setSelectedObject(null);
    const showTooltip = (event) => {
      const metadata = event.target?.metadata;

      if (!metadata?.kind?.startsWith("device")) {
        return;
      }

      setTooltip({
        x: event.e.offsetX + 14,
        y: event.e.offsetY + 14,
        metadata,
      });
    };
    const moveTooltip = (event) => {
      setTooltip((current) =>
        current
          ? {
              ...current,
              x: event.e.offsetX + 14,
              y: event.e.offsetY + 14,
            }
          : current,
      );
    };

    canvas.on("selection:created", handleSelection);
    canvas.on("selection:updated", handleSelection);
    canvas.on("selection:cleared", clearSelection);
    canvas.on("mouse:over", showTooltip);
    canvas.on("mouse:move", moveTooltip);
    canvas.on("mouse:out", () => setTooltip(null));

    const switchPortTimer = window.setInterval(() => {
      if (!switch24ObjectsRef.current.size) {
        return;
      }

      switch24ObjectsRef.current.forEach((switchObject) => {
        updateRandomSwitchPorts(switchObject);
      });
      canvas.requestRenderAll();
    }, 500);

    resizeCanvas();

    const observer = new ResizeObserver(resizeCanvas);

    if (canvasHostRef.current) {
      observer.observe(canvasHostRef.current);
    }

    return () => {
      window.clearInterval(switchPortTimer);
      observer.disconnect();
      canvas.dispose();
      fabricCanvasRef.current = null;
      switch24ObjectsRef.current.clear();
    };
  }, [resizeCanvas]);

  const handleFabricUpload = useCallback(async (event) => {
    const file = event.target.files?.[0];

    if (!file) {
      return;
    }

    if (!/jpe?g$/i.test(file.name) && file.type !== "image/jpeg") {
      setNotice("Please upload only JPG topology images.");
      event.target.value = "";
      return;
    }

    const reader = new FileReader();

    reader.onload = async () => {
      const imageSource = reader.result;
      const canvas = fabricCanvasRef.current;

      if (!canvas || !imageSource) {
        return;
      }

      const image = await loadFabricImage(imageSource);
      backgroundImageRef.current = image;
      setBackgroundImageSource(imageSource);
      fitTopologyImageToCanvas(canvas, canvasHostRef.current, image);
      setNotice(
        "Image uploaded and fitted responsively with high-quality rendering.",
      );
    };

    reader.readAsDataURL(file);
    event.target.value = "";
  }, []);

  const handleAddLine = useCallback((lineType) => {
    const canvas = fabricCanvasRef.current;

    if (!canvas) {
      return;
    }

    const lineObject = buildLineObject(lineType);
    canvas.add(lineObject);
    canvas.setActiveObject(lineObject);
    canvas.requestRenderAll();
    setSelectedObject(lineObject);
    setNotice(
      "Connector added. Drag, resize, or rotate it over the topology image.",
    );
  }, []);

  const handleDeleteSelected = useCallback(() => {
    const canvas = fabricCanvasRef.current;

    if (!canvas) {
      return;
    }

    canvas.getActiveObjects().forEach((object) => {
      if (object.shapeType === "switch24") {
        switch24ObjectsRef.current.delete(object.id);
      }

      canvas.remove(object);
    });
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    setSelectedObject(null);
    setNotice("Selected object deleted.");
  }, []);

  const createDeviceMarker = useCallback(
    async (nextForm) => {
      const canvas = fabricCanvasRef.current;
      const terminal = fabricTerminals.find(
        (item) => item.id === nextForm.terminalId,
      );
      const device = terminal?.devices.find(
        (item) => item.id === nextForm.deviceId,
      );

      if (!canvas || !terminal || !device) {
        return;
      }

      if (device.type === "switch24" || device.id === SWITCH_24_DEVICE_ID) {
        const switchObject = await buildSwitch24Object({
          terminal,
          device,
          segment: nextForm.segment || device.segment,
        });

        canvas.add(switchObject);
        canvas.setActiveObject(switchObject);
        canvas.requestRenderAll();
        switch24ObjectsRef.current.set(switchObject.id, switchObject);
        setSelectedObject(switchObject);
        window.setTimeout(() => {
          updateRandomSwitchPorts(switchObject);
          canvas.requestRenderAll();
        }, 250);
        setNotice(
          "Switch 24-Ports added. Port colors update randomly until websocket data is available.",
        );
        return;
      }

      const { rect, indicator } = buildDeviceObjects({
        terminal,
        device,
        segment: nextForm.segment || device.segment,
        radioWidth: nextForm.radioWidth,
      });

      canvas.add(rect, indicator);
      canvas.setActiveObject(rect);
      canvas.requestRenderAll();
      setSelectedObject(rect);
      setNotice(
        "Device rectangle and status circle added separately. Place each one where needed.",
      );
    },
    [fabricTerminals],
  );

  const handleFabricFieldChange = useCallback(
    (field, value) => {
      if (field === "terminalId") {
        lastCreatedDeviceKeyRef.current = "";
        setFabricForm((current) => ({
          ...current,
          terminalId: value,
          deviceId: "",
        }));
        return;
      }

      if (field === "deviceId") {
        const terminal = fabricTerminals.find(
          (item) => item.id === fabricForm.terminalId,
        );
        const device = terminal?.devices.find((item) => item.id === value);
        const nextForm = {
          ...fabricForm,
          deviceId: value,
          segment: fabricForm.segment || device?.segment || "",
        };
        const creationKey = `${nextForm.terminalId}|${nextForm.deviceId}`;

        setFabricForm(nextForm);

        if (creationKey && lastCreatedDeviceKeyRef.current !== creationKey) {
          lastCreatedDeviceKeyRef.current = creationKey;
          void createDeviceMarker(nextForm);
        }
        return;
      }

      if (field === "radioWidth") {
        const canvas = fabricCanvasRef.current;
        const activeObject = canvas?.getActiveObject();
        const nextRadius = Number(value);

        setFabricForm((current) => ({
          ...current,
          radioWidth: value,
        }));

        if (
          activeObject?.shapeType === "deviceStatus" &&
          Number.isFinite(nextRadius) &&
          nextRadius > 0
        ) {
          activeObject.set({
            radius: nextRadius,
            width: nextRadius * 2,
            height: nextRadius * 2,
            metadata: {
              ...activeObject.metadata,
              radioWidth: nextRadius,
            },
          });
          activeObject.setCoords();
          canvas.requestRenderAll();
          setSelectedObject(activeObject);
          setNotice("Selected status circle size updated.");
        }
        return;
      }

      setFabricForm((current) => ({
        ...current,
        [field]: value,
      }));
    },
    [createDeviceMarker, fabricForm, fabricTerminals],
  );

  const handleSaveFabric = useCallback(async () => {
    const canvas = fabricCanvasRef.current;

    if (!canvas) {
      return;
    }

    const payload = {
      module: "topology",
      renderer: "fabric",
      version: 1,
      savedAt: new Date().toISOString(),
      backgroundImage: backgroundImageSource,
      canvas: canvas.toJSON(["id", "shapeType", "metadata"]),
    };

    try {
      const result = await saveTopologyJson(payload);
      setNotice(`Fabric topology saved to ${result.relativePath}.`);
    } catch (error) {
      downloadJson(payload);
      setNotice(
        "Local folder save failed, so the topology JSON was downloaded instead.",
      );
      console.error("Unable to save topology JSON in src/saveTopology", error);
    }
  }, [backgroundImageSource]);

  return (
    <section className="topology-surface">
      <div className="topology-toolbar">
        <TopologyEditActions
          currentViewTopology
          topologyRenderMode={topologyRenderMode}
          setTopologyRenderMode={setTopologyRenderMode}
          fabricTerminals={fabricTerminals}
          fabricDevices={fabricDevices}
          fabricForm={fabricForm}
          fabricSelectedObject={selectedObject}
          onFabricUpload={handleFabricUpload}
          onFabricAddLine={handleAddLine}
          onFabricDeleteSelected={handleDeleteSelected}
          onFabricSave={handleSaveFabric}
          onFabricFieldChange={handleFabricFieldChange}
        />
      </div>

      <div ref={canvasHostRef} className="fabric-canvas-host">
        <canvas ref={canvasElementRef} />

        {tooltip && (
          <div
            className="fabric-tooltip"
            style={{ left: tooltip.x, top: tooltip.y }}
          >
            <strong>{tooltip.metadata.deviceName}</strong>
            <span>IP: {tooltip.metadata.ipAddress ?? "-"}</span>
            <span>Status: {tooltip.metadata.status}</span>
            <span>Segment: {tooltip.metadata.segment ?? "-"}</span>
            <span>Terminal: {tooltip.metadata.terminalName ?? "-"}</span>
          </div>
        )}

        <div className="fabric-notice">{notice}</div>
      </div>
    </section>
  );
};

export default memo(FabricTopology);
