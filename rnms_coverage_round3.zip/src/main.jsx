/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : src
   File Name                : main.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\main.jsx
   Purpose                  : Defined the entire project's Dependency in this file..
   Created Date             : 19-01-2026
 *******************************************************************************************/
import "./polyfills";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import "./assets/css/App.css";

import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { store, persistor } from "../src/store/store.js";
import { BrowserRouter } from "react-router-dom";
import { ConfigProvider } from "antd";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { CustomThemeProvider } from "./utility/DarkTheme/ThemeProvider";
import { CacheProvider } from "@emotion/react";
import createCache from '@emotion/cache';


const muiTheme = createTheme({
  palette: {
    primary: { main: "#1677ff" },
  },
});

// Retrieve the nonce from the meta tag
const nonceMeta = document.querySelector('meta[property="csp-nonce"]');
const nonce = nonceMeta ? nonceMeta.getAttribute('content') : "iaf-nms";
// Create the Emotion cache passing the nonce
const emotionCache = createCache({
 key: 'mui',
 nonce: nonce,
 prepend: true, // Ensures Tailwind overrides work seamlessly with MUI
});


createRoot(document.getElementById("root")).render(
  <StrictMode>
    <CacheProvider value={emotionCache}>
    <Provider store={store} value="">
      <ThemeProvider theme={muiTheme}>
        <ConfigProvider>
          <PersistGate loading={null} persistor={persistor}>
            <CustomThemeProvider>
              <BrowserRouter>
                <App />
              </BrowserRouter>
            </CustomThemeProvider>
          </PersistGate>
        </ConfigProvider>
      </ThemeProvider>
    </Provider>
    </CacheProvider>
  </StrictMode>
);
