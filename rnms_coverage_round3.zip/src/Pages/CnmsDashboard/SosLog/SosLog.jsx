
import React, { useEffect, useMemo, useState } from "react";
import { Box, CircularProgress, Typography, useTheme } from "@mui/material";
import { useSelector, } from "react-redux";

import { DbAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall";
import {
    RESTORE_SITE_DB_BACKUP,
} from "@/RestAPI/url/cnmsEndPoint";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";
import MTable from "@/components/Reusable/Table/MTable";
import { GET_SOS_ALERTS_LOG_BY_SITE_AND_DATE } from "@/RestAPI/url/endpoint";
 import DateTimePicker from "@/components/Reusable/DateTime/DateTimePicker";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
const SosLog = ({ isChildFullScreen,refreshTrigger, privilegeKey, onRefresh }) => {
    // --- Redux State ---
    const allTerminalTypes = useSelector((state) => state.nodeDetails.allTerminalTypeDetails) || [];
    const allSites = useSelector((state) => state.remoteRepDetails.fetchSiteDetails) || [];
    console.log("allSites", allSites)
    // --- Local State ---
    const [siteReStore, setSiteReStore] = useState([]);
    const [selectedTerminalValues, setSelectedTerminalValues] = useState([]);
    const [selectedSiteValues, setSelectedSiteValues] = useState([]);
    const [filteredSites, setFilteredSites] = useState([]);
    const [selectedRowId, setSelectedRowId] = useState(null);
    const [loading, setLoading] = useState(false);
    // const [isSubmitting, setIsSubmitting] = useState(false);
    const [openDialog, setOpenDialog] = useState(false);
    // const [isRestored, setIsRestored] = useState(false);
    const [isFormTouched, setIsFormTouched] = useState(false);
      const theme = useTheme();
    
    const isDark = theme.palette.mode === 'dark';

    // --- Date States ---
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [hasFetched, setHasFetched] = useState(false); // Controls table visibility
    // Replace your existing isFormValid with this:
    const isFormValid =
        selectedTerminalValues?.length > 0 &&
        selectedSiteValues?.length > 0 
      
        ;  

    const getValidationError = () => {
        if (selectedTerminalValues.length === 0) return " ";
        if (selectedSiteValues.length === 0) return " ";
        // if (!fromDate) return " ";
        // if (!toDate) return " ";
        return "";
    };
    // --- Column Definitions ---
    // --- Column Definitions ---
    const columns = [
        { name: "S.No", uid: "sno", width: "73px" },
        { name: "Terminal ", uid: "terminal", width: "130px"  },

        { name: " Site ID", uid: "siteId" },
        { name: "Latitude", uid: "latitude", width: "90px"  },
        { name: "Longitude", uid: "longitude" , width: "100px" },
        { name: "Alert Datetime", uid: "alertTime", width: "210px"  },
        { name: "Acknowledge Datetime", uid: "acknowledgedTime" , width: "220px" },
    ];
    // Filter Sites based on selected Terminal Type
    useEffect(() => {
        if (selectedTerminalValues.length === 0 || !Array.isArray(allSites)) {
            setFilteredSites([]);
            return;
        }
        const selectedTerminalNames = allTerminalTypes
            .filter(t => (t.terminalId || t.id) && selectedTerminalValues.includes(t.terminalId || t.id))
            .map(t => t.terminalTypeName);

        const sitesToDisplay = allSites.filter(site =>
            site.imTerminalType?.terminalTypeName &&
            selectedTerminalNames.includes(site.imTerminalType.terminalTypeName)
        );

        setFilteredSites(sitesToDisplay);
        setSelectedSiteValues([]);
    }, [selectedTerminalValues, allSites, allTerminalTypes]);

    const formatDateTimeForPayload = (dateString, mode = 'current') => {
        if (!dateString) return "";

        // 1. Create a date object from the input (e.g., "2023-10-25")
        // We split the string to avoid UTC/Timezone shifts caused by new Date("YYYY-MM-DD")
        const [year, month, day] = dateString.split('-').map(Number);

        // 2. Create a new Date object using local time components
        // month is 0-indexed in JS (January is 0)
        const date = new Date(year, month - 1, day);

        // 3. Get the CURRENT system time
        const now = new Date();

        const pad = (num) => num.toString().padStart(2, '0');

        let hours, minutes, seconds;

        if (mode === 'start') {
            // Start of the day: 00:00:00
            hours = "00";
            minutes = "00";
            seconds = "00";
        } else if (mode === 'end') {
            // End of the day: 23:59:59
            hours = "23";
            minutes = "59";
            seconds = "59";
        } else {
            // CURRENT SYSTEM TIME: Use the actual hours/mins/secs from the clock
            hours = pad(now.getHours());
            minutes = pad(now.getMinutes());
            seconds = pad(now.getSeconds());
        }

        const yyyy = date.getFullYear();
        const mm = pad(date.getMonth() + 1);
        const dd = pad(date.getDate());

        return `${yyyy}-${mm}-${dd} ${hours}:${minutes}:${seconds}`;
    };
    const handleFetchData = async () => {
        setLoading(true);
        try {
            const siteIdsPayload = selectedSiteValues.map(val =>
                typeof val === 'object' ? (val.id || val.value) : val
            );
            const requestPayload = {
                fromDate: formatDateTimeForPayload(fromDate),
                toDate: formatDateTimeForPayload(toDate),
                siteIds: siteIdsPayload
            };

            const response = await SecurityAxios(GET_SOS_ALERTS_LOG_BY_SITE_AND_DATE, "post", requestPayload);

            // 1. Check the ROOT status from the API response
            if (response?.data?.status === 1) {

                const rawData = Array.isArray(response.data.data) ? response.data.data : [];

                // 2. Map and Merge with allSites data
                const processedData = rawData.map((item, index) => {

                    // --- MERGE LOGIC START ---
                    // Find the site details in the 'allSites' array that matches this log's siteId
                    const siteDetails = allSites.find(s => s.siteId === item.siteId);

                    // Extract details if site is found, otherwise use defaults
                    const lat = siteDetails?.latitude || "N/A";
                    const lon = siteDetails?.longitude || "N/A";

                    // Get Terminal Name from the imTerminalType object inside the siteDetails
                    const terminalName = siteDetails?.imTerminalType?.terminalTypeName || "N/A";
                    // --- MERGE LOGIC END ---

                    return {
                        id: item.id || `row-${index}-${item.siteId}`,
                        sno: index + 1,
                        terminal: terminalName, // Taken from allSites
                        siteId: item.siteId || "N/A",
                        latitude: lat,            // Taken from allSites
                        longitude: lon,           // Taken from allSites
                        alertTime: typeof formatDisplayDate === 'function'
                            ? formatDisplayDate(item.alertTime)
                            : item.alertTime,
                        acknowledgedTime: typeof formatDisplayDate === 'function'
                            ? formatDisplayDate(item.acknowledgedTime)
                            : item.acknowledgedTime,
                        acknowledged: item.acknowledged
                    };
                });

                setSiteReStore(processedData);
                setHasFetched(true);
            } else {
                setSiteReStore([]);
                setHasFetched(true);
                Toast("", response?.data?.message || "No data found", "info");
            }
        } catch (error) {
            console.error("Fetch Error:", error);
            Toast("", "Failed to fetch data", "error");
            setSiteReStore([]);
        } finally {
            setLoading(false);
        }
    };
    const handleTerminalChange = (vals) => {
        setIsFormTouched(true);
        setSelectedTerminalValues(vals);
        setSelectedSiteValues([]);
        setHasFetched(false); // Hide table when filters change
    };

    const handleSiteChange = (vals) => {
        setIsFormTouched(true);
        setSelectedSiteValues(vals);
        setHasFetched(false); // Hide table when filters change
    };



    const handleSubmit = async () => {
        const selectedRowData = siteReStore.find((row) => row.id === selectedRowId);
        if (!isFormValid) {
            setIsFormTouched(true);
            return;
        }

        try {
            // setIsSubmitting(true);
            const tId = selectedTerminalValues[0];
            const sId = selectedSiteValues[0];
            const fullFileNameWithExtension = `${selectedRowData.fileName}.dump`;
            const dynamicRestoreUrl = `${RESTORE_SITE_DB_BACKUP}/${tId}/${sId}/${fullFileNameWithExtension}`;

            const res = await DbAxios(dynamicRestoreUrl, "get");
            if (res && (res.status === 200 || res.status === 201)) {
                Toast("", "Database restored successfully", "success");
                // setIsRestored(true);
                setOpenDialog(false);
                if (onRefresh) onRefresh();
            }
        } catch (error) {
            Toast("", error?.message || "Something went wrong", "error");
        } finally {
            // setIsSubmitting(false);
        }
    };

    const terminalOptions = useMemo(() =>
        allTerminalTypes
            .filter((t) => t.terminalTypeName !== "CNMS")
            .map((t) => ({
                id: t.terminalId || t.id,
                value: t.terminalId || t.id,
                label: t.terminalTypeName
            })), [allTerminalTypes]
    );

    const siteOptions = useMemo(() =>
        filteredSites.map((s) => ({
            id: s.siteId,
            value: s.siteId,
            label: s.siteId
        })), [filteredSites]
    );

    return (
        <Box sx={{
            width: "100%",
            padding: "20px",
            border: "2px solid #eee",
            borderRadius: "10px",
            boxSizing: "border-box"
        }}>
            {/* ROW 1: MultiSelects */}
            <Box sx={{ display: "flex", gap: "15px", mb: 2, width: "100%" }}>

                <MAlarmSelect
                    label="Terminal *"
                    options={terminalOptions}
                    // DO NOT pass null here. Always pass the array.
                    value={selectedTerminalValues}
                    onChange={handleTerminalChange}
                    isDark = {isDark}
                    error={isFormTouched && selectedTerminalValues.length === 0}
                  
                />

                <MAlarmSelect
                    label="Site ID *"
                    options={siteOptions}
                    // DO NOT pass null here. Always pass the array.
                    value={selectedSiteValues}
                    onChange={handleSiteChange}
                    isDark = {isDark}
                  
                    disabled={selectedTerminalValues.length === 0}
                    error={isFormTouched && selectedSiteValues.length === 0 && selectedTerminalValues.length > 0}
                />
            </Box>

          {/* ROW 2: Date Inputs */}
<Box sx={{ display: "flex", gap: "15px", mb: 1, width: "100%" }}>
    <DateTimePicker
        label="From Date"
        type="date"
        format="DD-MMMM-YYYY HH:mm:ss"
        value={fromDate}
        onChange={(val) => {
            setIsFormTouched(true);
            // val is a Date object from your component. 
            // Convert it to 'YYYY-MM-DD' string so your formatDateTimeForPayload works.
            if (val && !isNaN(val.getTime())) {
                const year = val.getFullYear();
                const month = String(val.getMonth() + 1).padStart(2, '0');
                const day = String(val.getDate()).padStart(2, '0');
                setFromDate(`${year}-${month}-${day}`);
            } else {
                setFromDate("");
            }
        }}
        errorMessage={isFormTouched && !fromDate}
        sx={{ flex: 1, minWidth: 0 }}
    />
    <DateTimePicker
        label="To Date"
        type="date"
        value={toDate}
        onChange={(val) => {
            // setIsFormTouched(true);
            // FIXED: Changed from setFromDate to setToDate
            if (val && !isNaN(val.getTime())) {
                const year = val.getFullYear();
                const month = String(val.getMonth() + 1).padStart(2, '0');
                const day = String(val.getDate()).padStart(2, '0');
                setToDate(`${year}-${month}-${day}`);
            } else {
                setToDate("");
            }
        }}
        format="DD-MMMM-YYYY HH:mm:ss"
        // errorMessage={isFormTouched && !toDate}
        sx={{ flex: 1, minWidth: 0 }}
    />
</Box>

            {/* ROW 3: Fetch Button & Error Message */}
            <Box sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-end",
                width: "100%",
                mb: 3
            }}>
                {/* Error message only shows if the user has interacted (isFormTouched) 
                    AND the form is not valid */}
                {isFormTouched && !isFormValid && (
                    <Typography
                        variant="caption"
                        sx={{ color: 'error.main', mb: 1, fontWeight: 'bold' }}
                    >
                        {getValidationError()}
                    </Typography>
                )}

                <MButtonPrimary
                    onClick={handleFetchData}
                    disabled={!isFormValid || loading}
                    sx={{ minWidth: '120px', height: '45px' }}
                >
                    {loading ? <CircularProgress size={24} color="inherit" /> : "Fetch"}
                </MButtonPrimary>
            </Box>
            {/* Data Table Section */}
            {hasFetched && (
                <MTable
                    privilegeKey={privilegeKey}
                    columns={columns}
                    tableData={siteReStore}
                    showPagination={true}
                    refreshTrigger={refreshTrigger}
                />
            )}

            {/* Loading State */}
            {loading && !hasFetched && (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
                    <CircularProgress size={30} />
                </Box>
            )}

            <MDialog
                open={openDialog}
                onClose={() => setOpenDialog(false)}
                title="Confirm Restore"
                message={`Are you sure you want to restore the database for Site ${selectedSiteValues[0]}?`}
                onConfirm={handleSubmit}
                mode="child"
                icon={confirmIcon}
                isChildFullScreen={isChildFullScreen}
            />
        </Box>
    );
};

export default SosLog;