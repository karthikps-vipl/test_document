import React from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Label,
} from "recharts";

import { Box } from "@mui/material";
import { useTheme } from "@mui/material/styles";

const CustomizedAxisTick = ({ x, y, payload, theme }) => {
  const MAX_LENGTH = 12;

  const formatValue = (value) => {
    if (!value) return "";

    const stringValue = String(value);

    return stringValue.length > MAX_LENGTH
      ? `${stringValue.substring(0, MAX_LENGTH)}...`
      : stringValue;
  };

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        x={0}
        y={0}
        dy={8}
        textAnchor="middle"
        fill={theme.palette.text.secondary}
        fontSize={10}
        fontWeight={500}
      >
        {formatValue(payload.value)}
      </text>
    </g>
  );
};

const CustomLegend = ({ payload = [] }) => {
  const theme = useTheme();

  const gradientMap = {
    ACK: "url(#cnmsAckGrad)",
    NOT_ACK: "url(#cnmsNotAckGrad)",
  };

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-end",
        gap: 1,
        background: theme.palette.background.cardbg,
        pb: 0,
      }}
    >
      <ul className="flex gap-4 list-none m-0 p-0">
        {payload.map((entry, index) => {
          const colorToUse =
            gradientMap[entry.value] || entry.color || entry.payload?.fill;

          return (
            <li
              key={`workflow-legend-${index}`}
              className="flex items-center gap-2"
            >
              <Box sx={{ width: 12, height: 12, flexShrink: 0 }}>
                <svg width="12" height="12" viewBox="0 0 12 12">
                  <circle cx="6" cy="6" r="5" fill={colorToUse} />
                </svg>
              </Box>

              <span
                style={{
                  color: theme.palette.text.primary,
                  fontSize: 12,
                  fontWeight: 500,
                }}
              >
                {entry.value}
              </span>
            </li>
          );
        })}
      </ul>
    </Box>
  );
};

const AlarmWorkflowChart = ({ data = [] }) => {
  const theme = useTheme();

  const chartColors = theme.palette.custom?.chart || {};

  const gradients = (
    <defs>
      {/* ACK - Green gradient */}
      <linearGradient
        id="cnmsAckGrad"
        x1="0"
        y1="0"
        x2="1"
        y2="0"
      >
        <stop offset="19%" stopColor="#198754" />
        <stop offset="100%" stopColor="#8BE0AE" />
      </linearGradient>

      {/* NOT_ACK - Orange gradient */}
      <linearGradient
        id="cnmsNotAckGrad"
        x1="0"
        y1="0"
        x2="1"
        y2="0"
      >
        <stop offset="19%" stopColor="#E67E22" />
        <stop offset="100%" stopColor="#FFD08A" />
      </linearGradient>
    </defs>
  );

  return (
    <Box
      sx={{
        width: "100%",
        height: "300px",
        borderRadius: "12px",
        padding: "8px",
        boxSizing: "border-box",
        background: theme.palette.custom.chart.chartbg,
        border: theme.palette.custom.commonBorder,
      }}
      className="rounded-[12px] p-4 shadow-sm"
    >

      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{
            top: 0,
            right: 8,
            left: 0,
            bottom: 20,
          }}
          barGap={8}
          barSize={30}
        >
          {gradients}

          <CartesianGrid
            vertical={false}
            stroke={chartColors.grid || theme.palette.divider}
          />

          <XAxis
            dataKey="terminal"
            axisLine={false}
            tickLine={false}
            interval={0}
            tick={<CustomizedAxisTick theme={theme} />}
          >
            <Label
              value="Terminal Types"
              position="bottom"
              offset={10}
              style={{
                textAnchor: "middle",
                fontSize: 11,
                fill: theme.palette.text.primary,
              }}
            />
          </XAxis>

          <YAxis
            fontSize={10}
            axisLine={false}
            tickLine={false}
            allowDecimals={false}
            tick={{
              fill:
                chartColors.text || theme.palette.text.secondary,
            }}
          >
            <Label
              value="Alarm Count"
              angle={-90}
              position="insideLeft"
              style={{
                textAnchor: "middle",
                fontSize: 11,
                fill: theme.palette.text.primary,
              }}
            />
          </YAxis>

          <Tooltip
            cursor={{
              fill:
                chartColors.cursor || "rgba(128,128,128,0.08)",
            }}
            formatter={(value, name) => [
              value,
              name,
            ]}
            labelFormatter={(label) => `Terminal: ${label}`}
            contentStyle={{
              borderRadius: "8px",
              border: "none",
              boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
              backgroundColor:
                chartColors.tooltipBg ||
                theme.palette.background.paper,
              color:
                chartColors.tooltipText ||
                theme.palette.text.primary,
            }}
            labelStyle={{
              color: chartColors.tooltipText || theme.palette.text.primary,
              fontWeight: "bold",
              marginBottom: "4px"
            }}
            // This ensures the item text (the number) matches
            itemStyle={{
              color: chartColors.tooltipText || theme.palette.text.primary,
            }}
          />

          <Legend
            verticalAlign="top"
            align="right"
            content={(props) => <CustomLegend {...props} />}
          />

          {/* Stacked ACK / NOT_ACK bars */}
          <Bar
            dataKey="ack"
            name="ACK"
            stackId="workflowStack"
            fill="url(#cnmsAckGrad)"
          />

          <Bar
            dataKey="notAck"
            name="NOT_ACK"
            stackId="workflowStack"
            fill="url(#cnmsNotAckGrad)"
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
};

export default AlarmWorkflowChart;
