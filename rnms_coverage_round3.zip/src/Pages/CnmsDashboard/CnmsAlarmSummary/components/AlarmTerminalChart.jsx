import React from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Label,
} from "recharts";
import { Box } from "@mui/material";
import { useTheme } from "@mui/material/styles";

const CustomizedAxisTick = ({ x, y, payload, theme }) => {
  const MAX_LENGTH = 12;

  const formatValue = (value) => {
    if (!value) {
      return "";
    }

    const stringValue = String(value);

    return stringValue.length > MAX_LENGTH
      ? `${stringValue.substring(0, MAX_LENGTH)}...`
      : stringValue;
  };

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        x={0}
        y={0}
        dy={8}
        textAnchor="middle"
        fill={theme.palette.text.secondary}
        fontSize={10}
        fontWeight={500}
      >
        {formatValue(payload.value)}
      </text>
    </g>
  );
};

const CustomLegend = (props) => {
  const { payload, title } = props;
  const theme = useTheme();
 
  const gradientMap = {
    Major: "url(#cnmsMajorGrad)",
    Minor: "url(#cnmsMinorGrad)",
    Warning: "url(#cnmsWarningGrad)",
  };

  return (
    <Box className="flex items-center justify-between gap-6   "  sx={{background:theme.palette.background.cardbg}}>
      <span 
        className="text-[11px] font-bold uppercase tracking-widest pb-4"
        style={{ color: theme.palette.text.secondary }}
      >
        {title}
      </span>
      <span className="invisible text-[11px] pb-4">Placeholder</span>
      <ul className="flex gap-4 list-none m-0 pb-4">
        {payload.map((entry, index) => {
          const colorToUse = gradientMap[entry.value] || entry.fill;
          return (
            <li key={`item-${index}`} className="flex items-center gap-2">
              <Box className="w-3 h-3">
                <svg width="15" height="15" viewBox="0 0 12 12">
                  <circle cx="6" cy="6" r="5" fill={colorToUse} />
                </svg>
              </Box>
              <span 
                className="text-xs font-medium"
                style={{ color: theme.palette.text.primary }}
              >
                {entry.value}
              </span>
            </li>
          );
        })}
      </ul>
    </Box>
  );
};

const AlarmTerminalChart = ({ data = [] }) => {
  const theme = useTheme();

  const chartColors = theme.palette.custom?.chart || {};

  // const colors = {
  //   major: "#D75961",
  //   minor: "#BDBD32",
  //   warning: "#007C7C",
  // };

  const gradients = (
    <defs>
      <linearGradient id="cnmsMajorGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#D75961" />
        <stop offset="100%" stopColor="#FFCED2" />
      </linearGradient>

      <linearGradient id="cnmsMinorGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#BDBD32" />
        <stop offset="100%" stopColor="#FFFF00" />
      </linearGradient>

      <linearGradient id="cnmsWarningGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#007C7C" />
        <stop offset="100%" stopColor="#72FFFF" />
      </linearGradient>
    </defs>
  );

  return (
    <Box
      sx={{
        width: "100%",
        height: "300px",
        borderRadius: "12px",
        padding: "8px",
        boxSizing: "border-box",
        background:theme.palette.custom.chart.chartbg,border:theme.palette.custom.commonBorder
      }}
      className="rounded-[12px] p-4 shadow-sm "

    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 0,
            left: 0,
            bottom: 20,
          }}
          barGap={8}
          barSize={30}
        >
          {gradients}

          <CartesianGrid
            vertical={false}
            stroke={chartColors.grid || theme.palette.divider}
          />

          <XAxis
            dataKey="terminal"
            axisLine={false}
            tickLine={false}
            interval={0}
            tick={<CustomizedAxisTick theme={theme} />}
          >
            <Label
              value="Terminal Types"
              position="bottom"
              offset={10}
              style={{
                textAnchor: "middle",
                fontSize: 11,
                fill: theme.palette.text.primary,
              }}
            />
          </XAxis>

          <YAxis
            fontSize={10}
            axisLine={false}
            tickLine={false}
            allowDecimals={false}
            tick={{
              fill: chartColors.text || theme.palette.text.secondary,
            }}
          >
            <Label
              value="Alarm Count"
              angle={-90}
              position="insideLeft"
              style={{
                textAnchor: "middle",
                fontSize: 11,
                fill: theme.palette.text.primary,
              }}
            />
          </YAxis>

          <Tooltip
            cursor={{
              fill: chartColors.cursor || "rgba(128,128,128,0.08)",
            }}
            contentStyle={{
              borderRadius: "8px",
              border: "none",
              boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
              backgroundColor:
                chartColors.tooltipBg || theme.palette.background.paper,
              color: chartColors.tooltipText || theme.palette.text.primary,
            }}
            labelStyle={{
              color: chartColors.tooltipText || theme.palette.text.primary,
              fontWeight: "bold",
              marginBottom: "4px"
            }}
            // This ensures the item text (the number) matches
            itemStyle={{
              color: chartColors.tooltipText || theme.palette.text.primary,
            }}
          />

          <Legend
            verticalAlign="top"
            align="right"
            content={(props) => <CustomLegend {...props} theme={theme} />}
            wrapperStyle={{
              paddingBottom: "4px",
            }}
          />

          {/* ==================================================
              STACKED BAR
              ================================================== */}

          <Bar
            dataKey="major"
            name="Major"
            stackId="terminalStack"
            fill="url(#cnmsMajorGrad)"
          />

          <Bar
            dataKey="minor"
            name="Minor"
            stackId="terminalStack"
            fill="url(#cnmsMinorGrad)"
          />

          <Bar
            dataKey="warning"
            name="Warning"
            stackId="terminalStack"
            fill="url(#cnmsWarningGrad)"
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
};

export default AlarmTerminalChart;
