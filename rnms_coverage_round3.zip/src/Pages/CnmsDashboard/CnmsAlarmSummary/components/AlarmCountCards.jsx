import React from "react";
import { Box } from "@mui/material";
import { useTheme } from "@mui/material/styles";

import Warning from "../../../../assets/svg/FaultIcon/warning.svg";
import Major from "../../../../assets/svg/FaultIcon/major.svg";
import Minor from "../../../../assets/svg/FaultIcon/minor.svg";
import Active from "../../../../assets/svg/FaultIcon/active alram.svg";

const AlarmCard = ({
  title,
  value,
  bgColor,
  image,
}) => {
  const theme = useTheme();

  return (
    <Box className="flex flex-row items-center justify-between rounded-lg pl-2 pr-2 pt-1 pb-1 h-auto" sx={{background:theme.palette.background.cardbg,border:theme.palette.custom.commonBorder}}  >
      <div className="flex flex-row justify-between items-center gap-2 w-full  ">
        <div className="flex flex-row items-center gap-3">
          {/* Using the 'secondary' text color defined in your theme */}
          <span 
            className="flex justify-start text-xl" 
            style={{ color: theme.palette.text.tabcolor }}
          >
            {title}:
          </span>
          
          {/* Using the 'primary' text color defined in your theme */}
          <span 
            className="flex justify-start font-extrabold text-xl"
            style={{ color: theme.palette.text.primary }}
          >
            {value}
          </span>
        </div>
        <div className="flex justify-start p-1">
          <img
            src={image}
            className="p-1 rounded-lg size-10"
            style={{ backgroundColor: bgColor }}
            alt={title}
          />
        </div>
      </div>
    </Box>
  );
};

const AlarmCountCards = ({ summary }) => {
  const cards = [
    {
      title: "Total Alarms",
      value: summary?.total || 0,
      backgroundColor: "#DBFFEE",
      image: Active,
    },
    {
      title: "Major",
      value: summary?.major || 0,
      backgroundColor: "#FFEBEC",
      image: Major,
    },
    {
      title: "Minor",
      value: summary?.minor || 0,
      backgroundColor: "#FFFFC9",
      image: Minor,
    },
    {
      title: "Warning",
      value: summary?.warning || 0,
      backgroundColor: "#D0FFFF",
      image: Warning,
    },
  ];

  return (
    <Box
      sx={{
        display: "grid",
        gridTemplateColumns: {
          xs: "1fr",
          sm: "repeat(2, 1fr)",
          lg: "repeat(4, 1fr)",
        },
        gap: 2,
        width: "100%",
      }}
    >
      {cards.map((card) => (
        <AlarmCard
          key={card.title}
          title={card.title}
          value={card.value}
          bgColor={card.backgroundColor}
          image={card.image}
        />
      ))}
    </Box>
  );
};

export default AlarmCountCards;
