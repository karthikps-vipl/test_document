import React, { useMemo, useState } from "react";

import { Box, IconButton, Tooltip } from "@mui/material";

import { NorthEast } from "@mui/icons-material";

import { useTheme } from "@mui/material/styles";

import MTable from "@/components/Reusable/Table/MTable";
import CNMSAlarmDetailsModal from "../CnmsAlarmModals/CNMSAlarmDetailsModal";


const AlarmSummaryTable = ({ data = [] }) => {
  const theme = useTheme();

  const [selectedTerminal, setSelectedTerminal] = useState(null);

  const [alarmModalOpen, setAlarmModalOpen] = useState(false);

  const columns = useMemo(
    () => [
      {
        name: "Terminal",
        uid: "terminal",
        sortable: true,
        searchName: true,
        width: "150px",
      },
      {
        name: "Major",
        uid: "major",
        sortable: true,
        width: "100px",
      },
      {
        name: "Minor",
        uid: "minor",
        sortable: true,
        width: "100px",
      },
      {
        name: "Warning",
        uid: "warning",
        sortable: true,
        width: "100px",
      },
      {
        name: "ACK",
        uid: "ack",
        sortable: true,
        width: "100px",
      },
      {
        name: "NOT_ACK",
        uid: "notAck",
        sortable: true,
        width: "110px",
      },
      {
        name: "Total Alarms",
        uid: "total",
        sortable: true,
        width: "130px",
      },
      {
        name: "Action",
        uid: "action",
        width: "90px",
      },
    ],
    []
  );

  const handleViewDetails = (row) => {
    setSelectedTerminal(row);
    setAlarmModalOpen(true);
  };

  const tableData = useMemo(() => {
    return data.map((row) => ({
      ...row,

      action: (
        <Tooltip title="View Alarm Details">
          <IconButton
            size="small"
            onClick={(event) => {
              event.stopPropagation();

              handleViewDetails(row);
            }}
            sx={{
              color: theme.palette.primary.main,
            }}
          >
            <NorthEast fontSize="small" />
          </IconButton>
        </Tooltip>
      ),
    }));
  }, [data, theme]);

  const [visibleColumns, setVisibleColumns] = useState(
    new Set(columns.map((column) => column.uid))
  );

  const headerColumns = useMemo(() => {
    return columns.filter((column) => visibleColumns.has(column.uid));
  }, [columns, visibleColumns]);

  return (
    <>
      <Box
        sx={{
          width: "100%",
        }}
      >
        <MTable
          columns={headerColumns}
          tableData={tableData}
          tableTitle="Alarm Summary"
          showPagination
          showSearch
          showVisibleContent={false}
          showMaximazed={false}
          showSelect={false}
          typeHeight="configuration"
        />
      </Box>

      <CNMSAlarmDetailsModal
        open={alarmModalOpen}
        onClose={() => setAlarmModalOpen(false)}
        terminal={selectedTerminal}
      />
    </>
  );
};

export default AlarmSummaryTable;
