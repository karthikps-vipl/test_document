import React from "react";
import { Box, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";

import { CustomLineChart } from "@/components/Charts/CustomLineChart";

const AlarmTrafficChart = () => {
  const theme = useTheme();

  /*
   * ------------------------------------------------------------
   * TEMPORARY DUMMY DATA
   * ------------------------------------------------------------
   *
   * We will replace this when the actual Alarm Traffic
   * requirement is finalized.
   */
  const dummyTrafficData = [
    {
      date: "10:00",
      major: 4,
      minor: 8,
      warning: 3,
    },
    {
      date: "11:00",
      major: 7,
      minor: 5,
      warning: 4,
    },
    {
      date: "12:00",
      major: 5,
      minor: 10,
      warning: 6,
    },
    {
      date: "13:00",
      major: 9,
      minor: 7,
      warning: 3,
    },
    {
      date: "14:00",
      major: 6,
      minor: 11,
      warning: 5,
    },
    {
      date: "15:00",
      major: 10,
      minor: 8,
      warning: 7,
    },
  ];

  const chartConfig = [
    {
      dataKey: "major",
      label: "Major",
      color: "#D75961",
    },
    {
      dataKey: "minor",
      label: "Minor",
      color: "#BDBD32",
    },
    {
      dataKey: "warning",
      label: "Warning",
      color: "#007C7C",
    },
  ];

  return (
    <Box
      sx={{
        width: "100%",
        height: "300px",
        borderRadius: "12px",
        padding: "8px",
        boxSizing: "border-box",
        background:theme.palette.custom.chart.chartbg,border:theme.palette.custom.commonBorder
      }}
      className="rounded-[12px] p-4 shadow-sm "
    >
      <Typography
        variant="subtitle1"
        sx={{
          fontWeight: 600,
          color: theme.palette.text.primary,
          mb: 1,
        }}
      >
        Alarm Traffic
      </Typography>

      <CustomLineChart
        data={dummyTrafficData}
        xAxisKey="date"
        lines={chartConfig}
        height={280}
        xAxisLabel="Date Time"
        yAxisLabel="Alarm Count"
      />
    </Box>
  );
};

export default AlarmTrafficChart;
