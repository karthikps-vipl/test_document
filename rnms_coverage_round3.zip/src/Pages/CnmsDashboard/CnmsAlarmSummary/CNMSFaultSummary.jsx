import React, { useMemo, useState } from "react";
import {
  Box,
  IconButton,
  Tooltip,
  Typography,
  Popover,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { useSelector } from "react-redux";
import { useTheme } from "@mui/material/styles";

import danger from "@/assets/SVGIcons/danger.svg";

const severityConfig = {
  2: {
    label: "Major",
    dotGradient: "linear-gradient(135deg, #ffced2 0%, #d75961 100%)",
  },
  1: {
    label: "Minor",
    dotGradient: "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)",
  },
  0: {
    label: "Warning",
    dotGradient: "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)",
  },
};

const severityRows = [
  { severity: 2, label: "Major" },
  { severity: 1, label: "Minor" },
  { severity: 0, label: "Warning" },
];

const CNMSFaultSummary = () => {
  const theme = useTheme();
  const [anchorEl, setAnchorEl] = useState(null);

  // CNMS state only. Does not read or modify RNMS alarmSlice.
  const alarms = useSelector(
    (state) => state.remoteRepDetails?.cnmsOpenAlarm ?? []
  );

  const tablePalette = theme.palette.custom?.table ?? {};

  // Recalculate automatically whenever the CNMS alarm list changes.
  const severityCounts = useMemo(() => {
    const counts = {
      2: 0, // Major
      1: 0, // Minor
      0: 0, // Warning
    };

    if (!Array.isArray(alarms)) {
      return counts;
    }

    alarms.forEach((alarm) => {
      const severity = Number(alarm?.severity);

      if (Object.prototype.hasOwnProperty.call(counts, severity)) {
        counts[severity] += 1;
      }
    });

    return counts;
  }, [alarms]);



  const totalAlarms = useMemo(
    () => severityCounts[2] + severityCounts[1] + severityCounts[0],
    [severityCounts]
  );

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const popoverId = open ? "cnms-fault-summary-popover" : undefined;

  return (
    <Box sx={{ display: "inline-flex", alignItems: "center" }}>
      <Tooltip title="Fault Summary" arrow>
        <IconButton
          onClick={handleClick}
          aria-describedby={popoverId}
          aria-label={`Fault Summary: ${totalAlarms} active alarms`}
          sx={{ position: "relative" }}
        >
          <Box
            component="img"
            src={danger}
            alt=""
            sx={{
              width: 24,
              height: 24,
              objectFit: "contain",
            }}
          />

          <Box
            component="span"
            sx={{
              position: "absolute",
              top: -2,
              right: -2,
              minWidth: 17,
              height: 17,
              px: 0.25,
              boxSizing: "border-box",
              bgcolor: "#dc2626",
              color: "#fff",
              fontSize: 10,
              lineHeight: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "50%",
              fontWeight: 600,
            }}
          >
            {totalAlarms}
          </Box>
        </IconButton>
      </Tooltip>

      <Popover
        id={popoverId}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        slotProps={{
          paper: {
            sx: {
              width: 300,
              maxWidth: "calc(100vw - 24px)",
              borderRadius: "16px",
              overflow: "hidden",
              boxShadow: "0 4px 20px rgba(0,0,0,0.12)",
            },
          },
        }}
      >
        <Box sx={{ p: 1.5 }}>
          <Typography
            sx={{
              color: tablePalette.headerText ?? "text.primary",
              fontWeight: 600,
              mb: 1,
            }}
          >
            Alarm Summary
          </Typography>

          <TableContainer
            sx={{
              borderRadius: "10px",
              overflow: "hidden",
              border: `1px solid ${
                tablePalette.border ?? theme.palette.divider
              }`,
            }}
          >
            <Table size="small">
              <TableHead>
                <TableRow>
                  {["Color", "Severity", "Count"].map((label) => (
                    <TableCell
                      key={label}
                      sx={{
                        bgcolor:
                          tablePalette.headerBg ?? theme.palette.action.hover,
                        color:
                          tablePalette.headerText ?? theme.palette.text.primary,
                        borderRight: `1px solid ${
                          tablePalette.border ?? theme.palette.divider
                        }`,
                        fontWeight: 600,
                        whiteSpace: "nowrap",
                      }}
                    >
                      {label}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>

              <TableBody>
                {severityRows.map((row) => {
                  const config = severityConfig[row.severity];

                  return (
                    <TableRow key={row.severity} hover>
                      <TableCell
                        sx={{
                          textAlign: "center",
                          borderRight: `1px solid ${
                            tablePalette.border ?? theme.palette.divider
                          }`,
                        }}
                      >
                        <Box
                          component="span"
                          sx={{
                            display: "inline-block",
                            width: 12,
                            height: 12,
                            borderRadius: "50%",
                            background: config.dotGradient,
                          }}
                        />
                      </TableCell>

                      <TableCell
                        sx={{
                          borderRight: `1px solid ${
                            tablePalette.border ?? theme.palette.divider
                          }`,
                        }}
                      >
                        {config.label}
                      </TableCell>

                      <TableCell
                        align="center"
                        sx={{ fontVariantNumeric: "tabular-nums" }}
                      >
                        {severityCounts[row.severity]}
                      </TableCell>
                    </TableRow>
                  );
                })}

                <TableRow>
                  <TableCell colSpan={2} sx={{ fontWeight: 700 }}>
                    Total
                  </TableCell>
                  <TableCell align="center" sx={{ fontWeight: 700 }}>
                    {totalAlarms}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Popover>
    </Box>
  );
};

export default CNMSFaultSummary;
