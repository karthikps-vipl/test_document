import { useCallback } from "react";
import { useDispatch } from "react-redux";

import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { setCnmsOpenAlarm } from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import { FETCH_ALL_OPEN_ALARM_CNMS } from "@/RestAPI/url/cnmsEndPoint";


const FetchCnmsAlarmData = () => {
  const dispatch = useDispatch();

  const fetchCnmsAlarmData = useCallback(async () => {
    try {
      const res = await FaultAxios(FETCH_ALL_OPEN_ALARM_CNMS, "get");

      if (res?.status === 200) {
        const alarms = Array.isArray(res?.data) ? res.data : [];

        dispatch(setCnmsOpenAlarm(alarms));

        console.log("CNMS OPEN ALARMS:", alarms);

        return alarms;
      }
    } catch (error) {
      console.error("Failed to fetch CNMS alarms:", error);
    }

    return [];
  }, [dispatch]);

  return {
    fetchCnmsAlarmData,
  };
};

export default FetchCnmsAlarmData;
