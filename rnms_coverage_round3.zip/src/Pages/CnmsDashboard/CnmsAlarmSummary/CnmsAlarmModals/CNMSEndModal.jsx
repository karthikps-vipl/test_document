import React, { useEffect, useState } from "react";

import { Box, Grid, Typography, CircularProgress, useTheme } from "@mui/material";

import { Update } from "@mui/icons-material";

import { useDispatch, useSelector } from "react-redux";

import MModal from "@/components/Reusable/Modal/MModal";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MTable from "@/components/Reusable/Table/MTable";

import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { UPDATE_WORKFLOW_CNMS } from "@/RestAPI/url/cnmsEndPoint";


import Toast from "@/components/Reusable/Toast/Toast";
import { updateSingleCnmsAlarm } from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";

const CNMSEndModal = ({ open, onClose, alarms = [] }) => {
  const dispatch = useDispatch();
  const theme = useTheme();

  const { userDetails } = useSelector((state) => state.userSlice);

  const userName = userDetails?.data?.userName;

  const [comment, setComment] = useState("");

  const [helperMessage, setHelperMessage] = useState(
    "Must be length of 4 - 512"
  );

  const [isError, setIsError] = useState(true);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setComment("");
      setHelperMessage("Must be length of 4 - 512");
      setIsError(true);
    }
  }, [open]);

  const validateComment = (value) => {
    const trimmed = value.trim();

    let error = false;
    let message = "";

    if (!trimmed.length) {
      error = true;
      message = "Must be length of 4 - 512";
    } else if (trimmed.length < 4) {
      error = true;
      message = `${4 - trimmed.length} more character(s) needed`;
    } else if (value.length <= 512) {
      message = `${512 - value.length} characters remaining`;
    } else {
      error = true;
      message = `${value.length - 512} characters exceeded`;
    }

    setComment(value);
    setIsError(error);
    setHelperMessage(message);
  };

  const handleSubmit = async () => {
    if (isError || !alarms.length) {
      return;
    }

    setLoading(true);

    try {
      const payload = alarms.map((alarm) => ({
        ...alarm,

        /*
         * END / CLOSED
         */
        workflow: 2,

        /*
         * Remove from active alarms
         */
        alarmState: 0,

        endWorkFlowComments: comment,

        workFlowOperation: true,

        userName,
      }));

      const response = await FaultAxios(
        `${UPDATE_WORKFLOW_CNMS}/${userName}`,
        "post",
        payload
      );

      if (response?.status === 200 || response?.status === 201) {
        /*
         * Remove immediately from Redux.
         */
        payload.forEach((alarm) => {
          dispatch(updateSingleCnmsAlarm(alarm));
        });

        Toast("Success", "Alarm ended successfully", "success");

        onClose();
      } else {
        Toast("Failed", "Failed to end alarm", "error");
      }
    } catch (error) {
      console.error("CNMS END failed:", error);

      Toast("Error", "An unexpected error occurred", "error");
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      name: "SITE ID",
      uid: "siteId",
    },
    {
      name: "SITE NAME",
      uid: "siteName",
    },
    {
      name: "ALARM NAME",
      uid: "alarmName",
    },
    {
      name: "DESCRIPTION",
      uid: "alarmDescription",
    },
  ];

  return (
    <MModal
      open={open}
      title="TERMINATE ALARM (END)"
      handleClose={onClose}
      fullWidth
      customWidth="100%"
      enableFullScreen
    >
      <Typography
        variant="subtitle2"
        sx={{
          mb: 1,
          fontWeight: "bold",
          color: theme.palette.text.secondary,
        }}
      >
        Alarms to End ({alarms.length})
      </Typography>

      <MTable
        tableData={alarms}
        columns={columns}
        tableTitle="End Fault"
        showPagination
        showSearch
      />

      {/* <Grid container spacing={2} sx={{ mt: 1 }}>
        <Grid item xs={12} md={6}>
          <Typography variant="caption">Status</Typography>

          <MInput fullWidth value="ACK" disabled />
        </Grid>

        <Grid item xs={12} md={6}>
          <Typography variant="caption">Comments</Typography>

          <MInput
            fullWidth
            placeholder="Describe the action taken..."
            value={comment}
            onChange={(event) => validateComment(event.target.value)}
            error={isError}
            helperText={helperMessage}
            inputProps={{
              maxLength: 512,
            }}
          />
        </Grid>
      </Grid> */}
        <Grid className="grid grid-cols-2 gap-2 w-full mt-1">
          <Grid item xs={12} md={6}>
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography variant="caption" sx={{ mb: 0.5 }}>
                Status
              </Typography>
              <MInput fullWidth value={"ACK"} disabled />
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography variant="caption" sx={{ mb: 0.5 }}>
                Comments
              </Typography>
              <MInput
                fullWidth
                placeholder="Describe the action taken..."
                value={comment}
                onChange={(e) => validateComment(e.target.value)}
                error={isError}
                helperText={helperMessage}
                inputProps={{ maxLength: 512 }}
              />
            </Box>
          </Grid>
        </Grid>
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          mt: 2,
        }}
      >
        <MButtonPrimary
          variant="contained"
          disabled={isError || !alarms.length || loading}
          onClick={handleSubmit}
          startIcon={
            loading ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              <Update />
            )
          }
          sx={{
            borderRadius: "8px",
            px: 4,
          }}
        >
          Update
        </MButtonPrimary>
      </Box>
    </MModal>
  );
};

export default CNMSEndModal;
