import React, { useCallback, useEffect, useState } from "react";
import { Box, Grid, Typography, useTheme } from "@mui/material";

import MModal from "@/components/Reusable/Modal/MModal";
import MTable from "@/components/Reusable/Table/MTable";
import MTextAreaAntD from "@/components/Reusable/Texarea/MTextArea";
import { GET_ALARM_AUGMENTATION } from "@/RestAPI/url/cnmsEndPoint";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";

const CNMSAlarmTimeline = ({ open, onClose, alarm }) => {
  const [tableRows, setTableRows] = useState([]);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    siteId: "",
    siteName: "",
    device: "",
    alarmName: "",
    // alarmDescription: "",
    severity: "",
  });

  const columns = [
    {
      name: "COUNT",
      uid: "alarmCount",
      sortable: true,
    },
    {
      name: "ALARM DESCRIPTION",
      uid: "alarmDescription",
      sortable: true,
    },
    {
      name: "DATE TIME",
      uid: "dateTime",
      sortable: true,
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      width: "115px",

      filterOptions: [
        {
          label: "MAJOR",
          value: "2",
          color: "#D75961",
        },
        {
          label: "MINOR",
          value: "1",
          color: "#BDBD32",
        },
        {
          label: "WARNING",
          value: "0",
          color: "#007C7C",
        },
      ],
    },
  ];

  useEffect(() => {
    if (!open || !alarm) return;

    setFormData({
      siteId: alarm.siteId ?? "NA",
      siteName: alarm.siteName ?? "NA",
      device: alarm.resourceName ?? "NA",
      alarmName: alarm.alarmName ?? "NA",
      // alarmDescription: alarm.alarmDescription ?? "NA",
      severity: alarm.severity ?? "NA",
    });
  }, [open, alarm]);

  const fetchTimeline = useCallback(async () => {
    if (!open || !alarm) return;

    setLoading(true);
    setTableRows([]);

    try {
      const response = await FaultAxios(GET_ALARM_AUGMENTATION, "post", alarm);

      if (response?.data && Array.isArray(response.data)) {
        const sortedData = [...response.data].sort((a, b) => {
          return a.alarmCount - b.alarmCount;
        });
        setTableRows(sortedData);
      } else {
        console.warn("API response did not contain a data array!", response);
        setTableRows([]);
      }
    } catch (error) {
      console.error("Error fetching CNMS alarm timeline:", error);
      setTableRows([]);
    } finally {
      setLoading(false);
    }
  }, [open, alarm]);

  useEffect(() => {
    fetchTimeline();
  }, [fetchTimeline]);
  const theme = useTheme();
  const isdark = theme.palette.mode === "dark";

  return (
    <MModal
      open={open}
      title="ALARM TIMELINE"
      handleClose={onClose}
      fullWidth
      customWidth="100%"
      enableFullScreen
    >
      <Grid
        container
        spacing={2}
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "0.32fr 1fr",
          },
          gap: 2,
          alignItems: "start",
        }}
      >
        <Grid
          item
          xs={12}
          sx={{
            borderRight: {
              xs: "none",
              md: "2px solid #c1c1c1",
            },
            borderBottom: {
              xs: "2px solid #c1c1c1",
              md: "none",
            },
            pr: 1,
            pb: 1,
          }}
        >
          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            Alarm Details
          </Typography>

          {[
            ["Site ID", formData.siteId],
            ["Site Name", formData.siteName],
            ["Device", formData.device],
            ["Alarm Name", formData.alarmName],
            // ["Description", formData.alarmDescription],
            // ["Severity", formData.severity],
          ].map(([label, value]) => (
            <Box key={label} sx={{ mb: 1 }}>
              <Typography variant="body2">{label}</Typography>
              <MTextAreaAntD
                fullWidth
                value={String(value)}
                disabled
                autoSize={{ minRows: 1 }}
                style={{
                  color: isdark ? "#E0E0E0" : "#555",
                }}
              />
            </Box>
          ))}
        </Grid>

        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            Occurrence Statistics
          </Typography>

          <Box sx={{ borderRadius: "12px", overflow: "hidden" }}>
            <MTable
              tableData={tableRows}
              columns={columns}
              tableTitle="Alarm Timeline"
              showPagination
              showSearch
            />
          </Box>

          {loading && (
            <Typography variant="caption">Loading alarm timeline...</Typography>
          )}

          {!loading && tableRows.length === 0 && (
            <Typography variant="caption">
              No timeline occurrences found.
            </Typography>
          )}
        </Grid>
      </Grid>
    </MModal>
  );
};

export default CNMSAlarmTimeline;
