import React, { useEffect, useMemo, useState } from "react";

import {
  Box,
  IconButton,
  MenuItem,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";

import {
  TrendingUp,
} from "@mui/icons-material";

import { useSelector } from "react-redux";
import { useTheme } from "@mui/material/styles";

import MModal from "@/components/Reusable/Modal/MModal";
import CNMSAckModal from "./CNMSAckModal";
import CNMSEndModal from "./CNMSEndModal";
import MTable from "@/components/Reusable/Table/MTable";
import CNMSAlarmTimeline from "./CNMSAlarmTimeline";
import Ack_Tick_Icon from "@/assets/SVGIcons/Ack_Tick_Icon_org.svg";
import End_Icon from "@/assets/SVGIcons/End_Icon.svg";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
const CNMSAlarmDetailsModal = ({ open, onClose, terminal }) => {
  const theme = useTheme();
  const isdark = theme.palette.mode === "dark";

  /*
   * CNMS alarms from Redux.
   */
  const alarms = useSelector(
    (state) => state.remoteRepDetails?.cnmsOpenAlarm || []
  );

  /*
   * Store ONLY alarm IDs here.
   *
   * Example:
   *
   * [
   *   101,
   *   102,
   *   105
   * ]
   */
  const [selectedRows, setSelectedRows] = useState([]);

  /*
   * Right-click context menu.
   */
  const [contextMenu, setContextMenu] = useState(null);

  const [ackOpen, setAckOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);
  const [timelineOpen, setTimelineOpen] = useState(false);
  const [timelineAlarm, setTimelineAlarm] = useState(null);
  /*
   * Only show alarms belonging to the selected terminal.
   */
  const terminalAlarms = useMemo(() => {
    if (!terminal) {
      return [];
    }

    return alarms.filter(
      (alarm) =>
        String(alarm?.terminalTypeName || "")
          .trim()
          .toLowerCase() ===
        String(terminal?.terminal || "")
          .trim()
          .toLowerCase()
    );
  }, [alarms, terminal]);

  /*
   * Reset selection when modal closes.
   */
  useEffect(() => {
    if (!open) {
      setSelectedRows([]);
      setContextMenu(null);
    }
  }, [open]);

  /*
   * Remove selected IDs which no longer exist.
   *
   * This is especially important after END because
   * updateSingleCnmsAlarm() may remove the alarm from Redux.
   */
  useEffect(() => {
    const existingIds = new Set(
      terminalAlarms.map((alarm) => String(alarm.alarmId))
    );

    setSelectedRows((previous) =>
      previous.filter((id) => existingIds.has(String(id)))
    );
  }, [terminalAlarms]);

  /*
   * Convert selected IDs back into complete alarm objects.
   */
  const selectedAlarms = useMemo(() => {
    const selectedIds = new Set(selectedRows.map((id) => String(id)));

    return terminalAlarms.filter((alarm) =>
      selectedIds.has(String(alarm.alarmId))
    );
  }, [terminalAlarms, selectedRows]);

  /*
   * Determine which actions are available.
   */
  const hasNotAck = selectedAlarms.some(
    (alarm) => Number(alarm.workflow) === 0
  );

  const hasAck = selectedAlarms.some((alarm) => Number(alarm.workflow) === 1);
  const isSingleSelection = selectedAlarms.length === 1;

  const selectedAlarm = isSingleSelection ? selectedAlarms[0] : null;

  const canShowTimeline =
    isSingleSelection && Number(selectedAlarm?.alarmCount) > 1;
  /*
   * Generic MTable row selection.
   *
   * IMPORTANT:
   * MTable passes the actual row ID and checked state.
   */

  const handleRowSelect = (rowId, checked) => {
    const normalizedId = String(rowId);

    setSelectedRows((previous) => {
      const next = new Set(previous.map((id) => String(id)));

      if (checked) {
        next.add(normalizedId);
      } else {
        next.delete(normalizedId);
      }

      return Array.from(next);
    });
  };

  /*
   * Select / deselect all visible rows.
   */
  const handleSelectAll = (checked) => {
    if (checked) {
      const visibleIds = terminalAlarms.map((alarm) => String(alarm.alarmId));

      setSelectedRows(visibleIds);
    } else {
      setSelectedRows([]);
    }
  };

  /*
   * Right-click handler coming from MTable.
   *
   * IMPORTANT:
   * MTable only calls this when the row is already selected.
   */
  const handleRowContextMenu = (event, row) => {
    event.preventDefault();

    /*
     * Make sure the right-clicked row is selected.
     */
    const rowId = String(row.alarmId);
    const selectedIds = selectedRows.map((id) => String(id));
    if (!selectedIds.includes(rowId)) {
      return;
    }
    setContextMenu({
      mouseX: event.clientX,
      mouseY: event.clientY,
      row,
    });
  };

  const closeContextMenu = () => {
    setContextMenu(null);
  };

  /*
   * ACK
   */
  const handleAck = () => {
    closeContextMenu();

    const notAckRows = selectedAlarms.filter(
      (alarm) => Number(alarm.workflow) === 0
    );

    if (!notAckRows.length) {
      return;
    }

    setAckOpen(true);
  };

  /*
   * END
   */
  const handleEnd = () => {
    closeContextMenu();

    const ackRows = selectedAlarms.filter(
      (alarm) => Number(alarm.workflow) === 1
    );

    if (!ackRows.length) {
      return;
    }

    setEndOpen(true);
  };
  const handleTimeline = () => {
    if (!canShowTimeline || !selectedAlarm) {
      closeContextMenu();
      return;
    }

    setTimelineAlarm(selectedAlarm);
    closeContextMenu();
    setTimelineOpen(true);
  };
  const headerActions = (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1,
      }}
    >
      {hasNotAck && (
        <Tooltip title="Acknowledge Alarm">
          <span>
            <IconButton
              size="small"
              onClick={handleAck}
              sx={{
                border: "1px solid",
                borderColor: "divider",
                borderRadius: "8px",
                width: 36,
                height: 36,
              }}
            >
              <img
                src={Ack_Tick_Icon}
                alt="ACK"
                style={{
                  width: 22,
                  height: 22,
                  filter: theme.palette.custom.icon.iconFilter,
                }}
              />
            </IconButton>
          </span>
        </Tooltip>
      )}

      {hasAck && (
        <Tooltip title="End Alarm">
          <span>
            <IconButton
              size="small"
              onClick={handleEnd}
              sx={{
                border: "1px solid",
                borderColor: "divider",
                borderRadius: "8px",
                width: 36,
                height: 36,
              }}
            >
              <img
                src={End_Icon}
                alt="END"
                style={{
                  width: 15,
                  height: 15,
                  filter: theme.palette.custom.icon.iconFilter,
                }}
              />
            </IconButton>
          </span>
        </Tooltip>
      )}

      {canShowTimeline && (
        <Tooltip title="Alarm Timeline">
          <span>
            <IconButton
              size="small"
              onClick={handleTimeline}
              sx={{
                border: "1px solid",
                borderColor: "divider",
                borderRadius: "8px",
                width: 36,
                height: 36,
                color: isdark ? "#ffffff" : "#344d96", 
              }}
            >
              <TrendingUp
              />
            </IconButton>
          </span>
        </Tooltip>
      )}
    </Box>
  );
  const columns = [
    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
    },
    {
      name: "Site Name",
      uid: "siteName",
      sortable: true,
    },
    {
      name: "Device Name",
      uid: "resourceName",
      sortable: true,
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      width: "115px",

      filterOptions: [
        {
          label: "MAJOR",
          value: "2",
          color: "#D75961",
        },
        {
          label: "MINOR",
          value: "1",
          color: "#BDBD32",
        },
        {
          label: "WARNING",
          value: "0",
          color: "#007C7C",
        },
      ],
    },
    {
      name: "Work Flow",
      uid: "workflow",
      filterType: "dropdown",
      width: "125px",

      filterOptions: [
        {
          label: "ACK",
          value: 1,
        },
        {
          label: "NOT_ACK",
          value: 0,
        },
      ],
    },
    {
      name: "Date Time",
      uid: "dateTime",
      sortable: true,
    },
    {
      name: "Count",
      uid: "alarmCount",
      sortable: true,
    },
  ];
  return (
    <>
      <MModal
        open={open}
        title={`ALARMS - ${terminal?.terminal || ""}`}
        handleClose={onClose}
        fullWidth
        customWidth="100%"
        enableFullScreen
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 1,
          }}
        >
          <Typography
            variant="subtitle2"
            sx={{
              fontWeight: "bold",
              color: theme.palette.text.secondary,
            }}
          >
            Terminal: {terminal?.terminal || "-"}
          </Typography>

          <Typography
            variant="caption"
            sx={{
              color: theme.palette.text.secondary,
            }}
          >
            Selected: {selectedAlarms.length}
          </Typography>
        </Box>

        <Box
          sx={{
            width: "100%",
            border: "1px solid rgba(0,0,0,0.10)",
            borderRadius: "8px",
            overflow: "hidden",
          }}
        >
          <MTable
            tableData={terminalAlarms}
            columns={columns}
            showPagination
            showSearch
            enableRowSelection
            rowIdKey="alarmId"
            selectedRowsNew={new Set(selectedRows)}
            onRowSelect={handleRowSelect}
            onSelectAll={handleSelectAll}
            onRowContextMenu={handleRowContextMenu}
            showHeaderActions={selectedAlarms.length > 0}
            headerActions={headerActions}
            handleDownloadPDF={() => {
              const alarmNameRepo = `ALL_ALARM_${terminal?.terminal}`;
              const sanitizedName = alarmNameRepo.replace(/\s+/g, "_");
              exportToPDF(
                `${alarmNameRepo} Report`,
                columns,
                terminalAlarms,
                `${sanitizedName}_Report`
              );
            }}
          />
        </Box>

        <Typography
          variant="caption"
          sx={{
            display: "block",
            mt: 1,
            color: theme.palette.text.secondary,
          }}
        >
          Select one or more alarms, then right-click a selected alarm to ACK or
          END.
        </Typography>
      </MModal>

      {contextMenu && (
        <Paper
          sx={{
            position: "fixed",
            top: contextMenu.mouseY,
            left: contextMenu.mouseX,
            zIndex: 99999,
            minWidth: 180,
            boxShadow: 4,
          }}
          onMouseLeave={closeContextMenu}
        >
          {hasNotAck && (
            <MenuItem onClick={handleAck}>
              <img
                src={Ack_Tick_Icon}
                alt="ACK"
                style={{
                  filter: theme.palette.custom.icon.iconFilter,
                }}
              />{" "}
              ACK
            </MenuItem>
          )}

          {hasAck && (
            <MenuItem onClick={handleEnd}>
              <img
                src={End_Icon}
                alt="END"
                style={{
                  filter: theme.palette.custom.icon.iconFilter,
                  paddingRight: "6px",
                }}
              />{" "}
              END
            </MenuItem>
          )}
          {canShowTimeline && (
            <MenuItem onClick={handleTimeline}>
              <TrendingUp
                style={{
                  filter: theme.palette.custom.icon.iconFilter,
                  color: isdark ? "#fff" : "#344d96",
                }}
              />
              ALARM TIMELINE
            </MenuItem>
          )}
        </Paper>
      )}

      <CNMSAckModal
        open={ackOpen}
        onClose={() => setAckOpen(false)}
        alarms={selectedAlarms.filter((alarm) => Number(alarm.workflow) === 0)}
      />

      <CNMSEndModal
        open={endOpen}
        onClose={() => setEndOpen(false)}
        alarms={selectedAlarms.filter((alarm) => Number(alarm.workflow) === 1)}
      />

      <CNMSAlarmTimeline
        open={timelineOpen}
        onClose={() => {
          setTimelineOpen(false);
          setTimelineAlarm(null);
        }}
        alarm={timelineAlarm}
      />
    </>
  );
};

export default CNMSAlarmDetailsModal;
