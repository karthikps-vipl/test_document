import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { GET_ALL_ALARM_NOTIFICATION } from "@/RestAPI/url/endpoint";
import { setAlarmNotificationSettings } from "@/store/features/Fault/alarmSlice";

export const fetchAlarmNotificationSettings = async (dispatch) => {
  const response = await FaultAxios(GET_ALL_ALARM_NOTIFICATION, "get");

  const rawData = Array.isArray(response.data)
    ? response.data
    : Object.values(response.data || {});

  const notificationSettings = {};

  rawData.forEach((item) => {
    notificationSettings[Number(item.severity)] = {
      audioFileName: item.audioFileName,
      isMute: item.isMute,
      isPopup: item.isPopup,
    };
  });

  dispatch(setAlarmNotificationSettings(notificationSettings));

  return notificationSettings;
};
