import React, { useMemo } from "react";
import { Box } from "@mui/material";
import { useSelector } from "react-redux";

import AlarmCountCards from "./components/AlarmCountCards";
import AlarmTerminalChart from "./components/AlarmTerminalChart";
import AlarmSummaryTable from "./components/AlarmSummaryTable";
import AlarmWorkflowChart from "./components/AlarmWorkflowChart";

const AlarmDashboardCNMS = () => {
  const alarms = useSelector(
    (state) => state.remoteRepDetails?.cnmsOpenAlarm || []
  );

  const terminalTypes = useSelector(
    (state) =>
      state.inventory?.terminalTypes ||
      state.remoteRepDetails?.fetchAllTerminalTypeAlongWithSite ||
      []
  );
  const alarmSummary = useMemo(() => {
    const summary = {
      total: 0,
      major: 0,
      minor: 0,
      warning: 0,
      ack: 0,
      notAck: 0,
    };

    if (!Array.isArray(alarms)) {
      return summary;
    }

    alarms.forEach((alarm) => {
      const count = Number(alarm?.alarmCount) || 0;

      // Total alarms
      summary.total += count;

      // Severity
      switch (Number(alarm?.severity)) {
        case 2:
          summary.major += count;
          break;

        case 1:
          summary.minor += count;
          break;

        case 0:
          summary.warning += count;
          break;

        default:
          break;
      }

      // Workflow
      if (Number(alarm?.workflow) === 1) {
        summary.ack += count;
      } else if (Number(alarm?.workflow) === 0) {
        summary.notAck += count;
      }
    });

    return summary;
  }, [alarms]);

  // const terminalSummary = useMemo(() => {
  //   if (!Array.isArray(terminalTypes)) {
  //     return [];
  //   }

  //   if (!Array.isArray(alarms)) {
  //     return [];
  //   }

  //   return terminalTypes
  //     .map((terminal) => {
  //       const terminalName = terminal?.terminalTypeName;

  //       if (!terminalName) {
  //         return null;
  //       }

  //       const terminalAlarms = alarms.filter(
  //         (alarm) =>
  //           String(alarm?.terminalTypeName || "")
  //             .trim()
  //             .toLowerCase() === String(terminalName).trim().toLowerCase()
  //       );

  //       const summary = {
  //         terminal: terminalName,
  //         major: 0,
  //         minor: 0,
  //         warning: 0,
  //         ack: 0,
  //         notAck: 0,
  //         total: 0,
  //       };

  //       terminalAlarms.forEach((alarm) => {
  //         const count = Number(alarm?.alarmCount) || 0;
  //         summary.total += count;
  //         switch (Number(alarm?.severity)) {
  //           case 2:
  //             summary.major += count;
  //             break;

  //           case 1:
  //             summary.minor += count;
  //             break;

  //           case 0:
  //             summary.warning += count;
  //             break;

  //           default:
  //             break;
  //         }

  //         if (Number(alarm?.workflow) === 1) {
  //           summary.ack += count;
  //         } else if (Number(alarm?.workflow) === 0) {
  //           summary.notAck += count;
  //         }
  //       });

  //       return summary;
  //     })
  //     .filter(Boolean);
  // }, [alarms, terminalTypes]);
  const terminalSummary = useMemo(() => {
    if (!Array.isArray(terminalTypes) || !Array.isArray(alarms)) {
      return [];
    }
  
    return terminalTypes
      .map((terminal) => {
        const terminalName = terminal?.terminalTypeName;
  
        if (!terminalName) {
          return null;
        }
  
        const terminalAlarms = alarms.filter(
          (alarm) =>
            String(alarm?.terminalTypeName || "")
              .trim()
              .toLowerCase() ===
            String(terminalName).trim().toLowerCase()
        );
  
        const summary = {
          terminal: terminalName,
          major: 0,
          minor: 0,
          warning: 0,
          ack: 0,
          notAck: 0,
          total: 0,
        };
  
        terminalAlarms.forEach((alarm) => {
          const count = Number(alarm?.alarmCount) || 0;
  
          summary.total += count;
  
          switch (Number(alarm?.severity)) {
            case 2:
              summary.major += count;
              break;
            case 1:
              summary.minor += count;
              break;
            case 0:
              summary.warning += count;
              break;
            default:
              break;
          }
  
          if (Number(alarm?.workflow) === 1) {
            summary.ack += count;
          } else if (Number(alarm?.workflow) === 0) {
            summary.notAck += count;
          }
        });
  
        return summary;
      })
      .filter((row) => row && row.total > 0);
  }, [alarms, terminalTypes]);
  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        p: 1,
        backgroundColor: "background.paper",
        overflow: "auto",
      }}
    >
      <Box sx={{ mb: 1 }}>
        <AlarmCountCards summary={alarmSummary} />
      </Box>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "1fr 1fr",
          },
          gap: 2,
          mb: 1,
        }}
      >
        <AlarmTerminalChart data={terminalSummary} />

        <AlarmWorkflowChart  data={terminalSummary}/>
      </Box>
      <Box sx={{ width: "100%" }}>
        <AlarmSummaryTable data={terminalSummary} />
      </Box>
    </Box>
  );
};

export default AlarmDashboardCNMS;
