import React, { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";

import MajorSound from "@/assets/audio/MAJOR.wav";
import MinorSound from "@/assets/audio/MINOR.wav";
import WarningSound from "@/assets/audio/WARNING.wav";

import { clearCnmsAlarmNotificationEvent } from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";

import Toast from "@/components/Reusable/Toast/Toast";

const ALARM_SOUNDS = {
  "MAJOR.wav": MajorSound,
  "MINOR.wav": MinorSound,
  "WARNING.wav": WarningSound,
};

const TOAST_TYPES = {
  2: "error",
  1: "warning",
  0: "info",
};

const GlobalCnmsAlarmNotifications = () => {
  const dispatch = useDispatch();

  const notificationEvent = useSelector(
    (state) => state.remoteRepDetails?.cnmsAlarmNotificationEvent
  );

  const alarmNotificationSettings = useSelector(
    (state) => state.alarmSlice?.alarmNotificationSettings
  );

  // Prevent the same event from being processed repeatedly.
  const processedEventRef = useRef(null);

  useEffect(() => {
    if (!notificationEvent) return;

    const alarm = notificationEvent;
    const severity = Number(alarm.severity);

    // Read the latest settings directly from Redux.
    const settings = alarmNotificationSettings?.[severity];

    if (!settings) return;

    // const eventId = alarm.eventId ?? alarm.socketEventId ?? alarm.alarmId;

    // const normalizedEventId = eventId != null ? String(eventId) : null;

    // // Avoid processing the same identifiable event twice.
    // if (
    //   normalizedEventId !== null &&
    //   processedEventRef.current === normalizedEventId
    // ) {
    //   dispatch(clearCnmsAlarmNotificationEvent());
    //   return;
    // }

    // if (normalizedEventId !== null) {
    //   processedEventRef.current = normalizedEventId;
    // }
    const notificationId = alarm.notificationEventId;
    if (
      notificationId != null &&
      processedEventRef.current === String(notificationId)
    ) {
      dispatch(clearCnmsAlarmNotificationEvent());
      return;
    }

    if (notificationId != null) {
      processedEventRef.current = String(notificationId);
    }
    const siteId =
      alarm.siteId ?? alarm.siteID ?? alarm.site_id ?? "Unknown Site";

    const deviceName =
      alarm.deviceName ??
      alarm.resourceName ??
      alarm.terminalName ??
      alarm.terminalTypeName ??
      "Unknown Device";

    const alarmName = alarm.alarmName ?? "Alarm";

    const description = alarm.alarmDescription ?? "No description available";

    // 1. Show toast only when popup notifications are enabled.
    if (settings.isPopup === true) {
      Toast(
        String(siteId),
        <>
          <div>
            <strong>{deviceName}</strong>
            <br />
            {alarmName}
          </div>
          <div>{description}</div>
        </>,
        TOAST_TYPES[severity] ?? "info"
      );
    }

    // 2. Play sound only when mute is disabled.
    if (settings.isMute === false) {
      const sound = ALARM_SOUNDS[settings.audioFileName];

      if (sound) {
        const audio = new Audio(sound);

        audio.play().catch((error) => {
          console.warn("Unable to play CNMS alarm sound:", error);
        });
      }
    }

    // 3. Consume the event after processing.
    dispatch(clearCnmsAlarmNotificationEvent());
  }, [notificationEvent, alarmNotificationSettings, dispatch]);

  return null;
};

export default GlobalCnmsAlarmNotifications;
