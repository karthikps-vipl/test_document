import React, { useEffect, useMemo, useState } from "react";
import { Box, CircularProgress, Tooltip } from "@mui/material";
import download from "@/assets/SVGIcons/download.svg";
import SiteSummaryCards from "./SiteSummaryCards";
import SiteTerminalChart from "./SiteTerminalChart";
import SiteSummaryTable from "./SiteSummaryTable";
import ActiveCommunicationChart from "./ActiveCommunicationChart";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  COUNT_SITE_ACTIVE_MODE_OF_COMM_SUMMARY,
  FETCH_SITE_SUMMARY_DETAILS,
} from "@/RestAPI/url/cnmsEndPoint";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import { useDispatch, useSelector } from "react-redux";
import { setSiteSummary } from "@/store/features/Cnms/SiteSummary/siteSummarySlice";

const SITE_STATUS = {
  OFFLINE: 0,
  ONLINE: 1,
  RNMS_DOWN: 2,
  MAINTENANCE: 3,
};

const getSiteStatus = (site) => {
  const statusId = Number(site?.healthStatus?.id);

  const statusValue = String(site?.healthStatus?.value || "")
    .trim()
    .toUpperCase();

  // Maintenance is handled separately.
  // if (statusId === SITE_STATUS.MAINTENANCE || statusValue === "MAINTENANCE") {
  //   return "MAINTENANCE";
  // }

  if (statusId === SITE_STATUS.RNMS_DOWN) {
    return "RNMS DOWN";
  }

  if (statusId === SITE_STATUS.ONLINE) {
    return "ONLINE";
  }

  if (statusId === SITE_STATUS.OFFLINE) {
    return "OFFLINE";
  }

  if (statusValue === "RNMS DOWN") {
    return "RNMS DOWN";
  }

  if (statusValue === "UP") {
    return "ONLINE";
  }

  if (statusValue === "DOWN") {
    return "OFFLINE";
  }

  return "OFFLINE";
};

// const getMaintenanceStatus = (site) => {
//   const statusId = Number(site?.healthStatus?.id);

//   const statusValue = String(site?.healthStatus?.value || "")
//     .trim()
//     .toUpperCase();

//   const isMaintenance =
//     statusId === SITE_STATUS.MAINTENANCE || statusValue === "MAINTENANCE";

//   if (!isMaintenance) {
//     return null;
//   }

//   const maintenanceType = Number(site?.maintenanceType);

//   if (maintenanceType === 1) {
//     return "MAINTENANCE_NON_OPS";
//   }

//   if (maintenanceType === 2) {
//     return "MAINTENANCE_R_OPS";
//   }

//   return null;
// };

// const getMaintenanceStatus = (site) => {
//   const isMaintenance = Boolean(site?.isMaintainance);

//   if (!isMaintenance) {
//     return null;
//   }

//   const maintenanceType = Number(site?.maintenanceType);

//   if (maintenanceType === 1) {
//     return "MAINTENANCE_NON_OPS";
//   }

//   if (maintenanceType === 2) {
//     return "MAINTENANCE_R_OPS";
//   }

//   return null;
// };
const getMaintenanceStatus = (site) => {
  if (!site?.isMaintainance) {
    return null;
  }

  const maintenanceType = Number(site?.maintenanceType);

  if (maintenanceType === 1) {
    return "MAINTENANCE_NON_OPS";
  }

  if (maintenanceType === 2) {
    return "MAINTENANCE_R_OPS";
  }

  return null;
};
const getActiveCommunicationName = (value) => {
  const mode = Number(value);

  if (mode === 1) {
    return "VSAT";
  }

  if (mode === 2 || mode === 3) {
    return "E1/LOS";
  }

  if (mode === 4) {
    return "UNKNOWN";
  }

  return "-";
};
const SiteSummaryDashboard = () => {
  // const [siteSummaryDetails, setSiteSummaryDetails] = useState([]);
  const dispatch = useDispatch();

  const siteSummaryDetails = useSelector((state) => state.siteSummary.sites);
  const [activeModeSummary, setActiveModeSummary] = useState(null);

  const [excludedStatuses, setExcludedStatuses] = useState([]);
  const [excludedTerminalTypes, setExcludedTerminalTypes] = useState([]);

  const [loading, setLoading] = useState(true);
  // const [error, setError] = useState(null);

  const fetchSiteSummary = async () => {
    try {
      setLoading(true);
      // setError(null);

      const [siteSummaryResponse, communicationResponse] = await Promise.all([
        InventoryAxios(FETCH_SITE_SUMMARY_DETAILS, "get"),
        InventoryAxios(COUNT_SITE_ACTIVE_MODE_OF_COMM_SUMMARY, "get"),
      ]);

      const siteData = Array.isArray(siteSummaryResponse?.data)
        ? siteSummaryResponse.data
        : [];

      dispatch(setSiteSummary(siteData));

      setActiveModeSummary(communicationResponse?.data || null);
    } catch (err) {
      console.error("Error fetching Site Summary:", err);

      // setError(
      //   err?.response?.data?.message ||
      //     err?.message ||
      //     "Failed to fetch site summary details."
      // );

      dispatch(setSiteSummary([]));
      setActiveModeSummary(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSiteSummary();
  }, []);

  const dashboardData = useMemo(() => {
    const sites = Array.isArray(siteSummaryDetails) ? siteSummaryDetails : [];

    const counts = {
      total: sites.length,
      online: 0,
      offline: 0,
      rnmsDown: 0,
      maintenanceNonOpsDown: 0,
      maintenanceROps: 0,
    };

    const terminalMap = {};

    const tableRows = sites.map((site, index) => {
      const status = getSiteStatus(site);
      const maintenanceStatus = getMaintenanceStatus(site);

      /*
       * Maintenance gets priority.
       * A maintenance site should NOT also increase
       * online/offline/rnmsDown.
       */
      if (maintenanceStatus === "MAINTENANCE_NON_OPS") {
        counts.maintenanceNonOpsDown++;
      } else if (maintenanceStatus === "MAINTENANCE_R_OPS") {
        counts.maintenanceROps++;
      } else if (status === "ONLINE") {
        counts.online++;
      } else if (status === "OFFLINE") {
        counts.offline++;
      } else if (status === "RNMS DOWN") {
        counts.rnmsDown++;
      }

      const terminalType = site?.imTerminalType?.terminalTypeName?.trim();

      if (terminalType) {
        if (!terminalMap[terminalType]) {
          terminalMap[terminalType] = {
            name: terminalType,
            online: 0,
            offline: 0,
            rnmsDown: 0,
            maintenanceNonOpsDown: 0,
            maintenanceROps: 0,
          };
        }

        /*
         * Same priority logic for terminal charts.
         */
        if (maintenanceStatus === "MAINTENANCE_NON_OPS") {
          terminalMap[terminalType].maintenanceNonOpsDown++;
        } else if (maintenanceStatus === "MAINTENANCE_R_OPS") {
          terminalMap[terminalType].maintenanceROps++;
        } else if (status === "ONLINE") {
          terminalMap[terminalType].online++;
        } else if (status === "OFFLINE") {
          terminalMap[terminalType].offline++;
        } else if (status === "RNMS DOWN") {
          terminalMap[terminalType].rnmsDown++;
        }
      }

      return {
        sno: index + 1,

        siteId: site?.siteId ?? "-",
        siteIdRemoteNumber: site?.remoteNumber ?? "-",

        siteName: site?.siteName ?? "-",

        ipAddress: site?.ipaddress ?? "-",

        latitude: site?.latitude ?? null,

        longitude: site?.longitude ?? null,

        latLong:
          site?.latitude != null && site?.longitude != null
            ? `${site.latitude} - ${site.longitude}`
            : "-",

        mode: site?.imTerminalMode?.name ?? "-",
        activeModeOfCommunication: getActiveCommunicationName(
          site?.activeModeOfCommunication
        ),
        status,
        filterStatus: maintenanceStatus || status,
        displayStatus:
          maintenanceStatus === "MAINTENANCE_NON_OPS"
            ? "MAINTENANCE NON-OPS"
            : maintenanceStatus === "MAINTENANCE_R_OPS"
            ? "MAINTENANCE R-OPS"
            : status,
        statusId: site?.healthStatus?.id ?? null,

        deviceStatus: site?.healthStatus?.value ?? "-",

        terminalType: site?.imTerminalType?.terminalTypeName ?? "-",

        maintenanceType: site?.maintenanceType ?? null,

        isMaintainance: Boolean(site?.isMaintainance),
      };
    });

    return {
      counts,
      tableRows,
      terminalCharts: Object.values(terminalMap),
    };
  }, [siteSummaryDetails]);

  const communicationPieData = useMemo(() => {
    const counts = {
      VSAT: 0,
      "E1/LOS": 0,
      Down: 0,
    };

    const sites = Array.isArray(siteSummaryDetails) ? siteSummaryDetails : [];

    sites.forEach((site) => {
      const mode = Number(site?.activeModeOfCommunication);

      if (mode === 1) {
        counts.VSAT++;
      } else if (mode === 2 || mode === 3) {
        counts["E1/LOS"]++;
      } else if (mode === 4) {
        counts.Down++;
      }
    });

    return [
      {
        name: "VSAT",
        value: counts.VSAT,
        color: "#FFF841",
      },
      {
        name: "E1/LOS",
        value: counts["E1/LOS"],
        color: "#5AFF74",
      },
      {
        name: "Down",
        value: counts.Down,
        color: "#FF6EDA",
      },
    ];
  }, [siteSummaryDetails]);

  const cards = useMemo(() => {
    return [
      {
        title: "Total",
        filterKey: "ALL",
        value: dashboardData.counts.total,
        bgColor: "#EDE4FF",
      },
      {
        title: "Online",
        filterKey: "ONLINE",
        value: dashboardData.counts.online,
        bgColor: "#DBFFED",
      },
      {
        title: "Offline",
        filterKey: "OFFLINE",
        value: dashboardData.counts.offline,
        bgColor: "#FFE0E2",
      },
      {
        title: "RNMS Down",
        filterKey: "RNMS DOWN",
        value: dashboardData.counts.rnmsDown,
        bgColor: "#FFFFCF",
      },
      {
        title: "Maintenance Non-OPS",
        filterKey: "MAINTENANCE_NON_OPS",
        value: dashboardData.counts.maintenanceNonOpsDown,
        bgColor: "#FFEEE3",
      },
      {
        title: "Maintenance R-OPS",
        filterKey: "MAINTENANCE_R_OPS",
        value: dashboardData.counts.maintenanceROps,
        bgColor: "#CBFFFF",
      },
    ];
  }, [dashboardData.counts]);

  const toggleStatusFilter = (status) => {
    if (status === "ALL") {
      // Select all statuses again
      setExcludedStatuses([]);
      return;
    }

    setExcludedStatuses((previous) => {
      if (previous.includes(status)) {
        // Currently excluded -> include it again
        return previous.filter((item) => item !== status);
      }

      // Currently included -> exclude it
      return [...previous, status];
    });
  };

  const toggleTerminalFilter = (terminalType) => {
    setExcludedTerminalTypes((previous) => {
      if (previous.includes(terminalType)) {
        // Include again
        return previous.filter((item) => item !== terminalType);
      }

      // Exclude
      return [...previous, terminalType];
    });
  };
  const filteredTableRows = useMemo(() => {
    let rows = dashboardData.tableRows;

    // Remove excluded statuses
    if (excludedStatuses.length > 0) {
      rows = rows.filter((row) => !excludedStatuses.includes(row.filterStatus));
    }

    // Remove excluded terminal types
    if (excludedTerminalTypes.length > 0) {
      rows = rows.filter(
        (row) => !excludedTerminalTypes.includes(row.terminalType)
      );
    }

    return rows;
  }, [dashboardData.tableRows, excludedStatuses, excludedTerminalTypes]);
  const pdfSummaryData = useMemo(() => {
    const terminalMap = {};

    // IMPORTANT:
    // Summary overview must always use ALL rows,
    // not filtered rows.
    dashboardData.tableRows.forEach((row) => {
      const terminalType = row.terminalType;

      if (!terminalType || terminalType === "-") {
        return;
      }

      if (!terminalMap[terminalType]) {
        terminalMap[terminalType] = {
          terminal: terminalType,
          online: 0,
          offline: 0,
          rnmsDown: 0,
          maintenance: 0,
          total: 0,
        };
      }

      const summary = terminalMap[terminalType];

      if (row.filterStatus === "ONLINE") {
        summary.online++;
      } else if (row.filterStatus === "OFFLINE") {
        summary.offline++;
      } else if (row.filterStatus === "RNMS DOWN") {
        summary.rnmsDown++;
      } else if (
        row.filterStatus === "MAINTENANCE_NON_OPS" ||
        row.filterStatus === "MAINTENANCE_R_OPS"
      ) {
        summary.maintenance++;
      }

      summary.total++;
    });

    const rows = Object.values(terminalMap);

    const totals = rows.reduce(
      (acc, row) => ({
        online: acc.online + row.online,
        offline: acc.offline + row.offline,
        rnmsDown: acc.rnmsDown + row.rnmsDown,
        maintenance: acc.maintenance + row.maintenance,
        total: acc.total + row.total,
      }),
      {
        online: 0,
        offline: 0,
        rnmsDown: 0,
        maintenance: 0,
        total: 0,
      }
    );

    return {
      rows,
      totals,
    };
  }, [dashboardData.tableRows]);
  const handleDownloadPDF = async () => {
    await exportToPDF(
      "CNMS SITE SUMMARY",

      [
        {
          uid: "sno",
          name: "S.No",
        },
        {
          uid: "siteIdRemoteNumber",
          name: "Site ID",
        },
        {
          uid: "siteName",
          name: "Site Name",
        },
        {
          uid: "ipAddress",
          name: "IP Address",
        },
        {
          uid: "latLong",
          name: "Lat-Long",
        },
        {
          uid: "mode",
          name: "Mode",
        },
        {
          uid: "displayStatus",
          name: "Status",
        },
        {
          uid: "activeModeOfCommunication",
          name: "Active Mode of Communication",
        },
      ],

      filteredTableRows,

      "CNMS SITE SUMMARY",

      [],
      [],
      null,

      pdfSummaryData
    );
  };

  if (loading) {
    return (
      <Box
        className="w-full flex items-center justify-center"
        sx={{
          minHeight: "400px",
        }}
      >
        <CircularProgress size={32} />
      </Box>
    );
  }

  return (
    <Box
      className="w-full p-3"
      sx={{
        backgroundColor: "background.paper",
      }}
    >
      <Box
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          mb: 1,
        }}
      >
        <Box
          sx={{
            fontSize: "18px",
            fontWeight: 700,
            color: "text.primary",
          }}
        >
          Site Summary
        </Box>

        <Box
          sx={{
            position: "absolute",
            right: 0,
          }}
        >
          {/* Download button will go here */}
          <Tooltip title="Download PDF">
            <Box
              onClick={handleDownloadPDF}
              sx={{
                color: "#2563EB",
                border: "1px solid",
                borderColor: "divider",
                borderRadius: "8px",
                padding: 1,
                marginRight: 1,
                cursor: "pointer",
              }}
            >
              <img src={download} alt="download" />
            </Box>
          </Tooltip>
        </Box>
      </Box>
      {/* =====================================================
    SUMMARY CARDS
===================================================== */}

      <SiteSummaryCards
        cards={cards}
        excludedStatuses={excludedStatuses}
        onCardClick={toggleStatusFilter}
      />

      {/* =====================================================
    TOP ROW
    PIE + FIRST TWO TERMINAL CHARTS
===================================================== */}

      <Box
        className="
    grid
    grid-cols-1
    md:grid-cols-2
    xl:grid-cols-3
    gap-3
    sm:gap-2
    mt-3
    sm:mt-1
    min-w-0
  "
      >
        {/* PIE */}
        <Box
          className="
      min-w-0
      rounded-[12px]
      shadow-sm
      p-1
    "
          sx={{
            background: "background.paper",
          }}
        >
          <ActiveCommunicationChart
            data={communicationPieData}
            total={Number(activeModeSummary?.totalCount) || 0}
          />
        </Box>

        {/* TERMINAL CHART 1 */}
        {dashboardData.terminalCharts[0] && (
          <SiteTerminalChart
            data={dashboardData.terminalCharts[0]}
            compact={false}
            active={
              !excludedTerminalTypes.includes(
                dashboardData.terminalCharts[0].name
              )
            }
            onClick={() =>
              toggleTerminalFilter(dashboardData.terminalCharts[0].name)
            }
          />
        )}

        {/* TERMINAL CHART 2 */}
        {dashboardData.terminalCharts[1] && (
          <SiteTerminalChart
            data={dashboardData.terminalCharts[1]}
            compact={false}
            active={
              !excludedTerminalTypes.includes(
                dashboardData.terminalCharts[1].name
              )
            }
            onClick={() =>
              toggleTerminalFilter(dashboardData.terminalCharts[1].name)
            }
          />
        )}
      </Box>

      {/* =====================================================
    TABLE + REMAINING TERMINAL CHARTS
===================================================== */}

      {(() => {
        const remainingTerminalCharts = dashboardData.terminalCharts.slice(2);

        const hasSideCharts = remainingTerminalCharts.length > 0;

        return (
          <Box
            className={`
        grid
        grid-cols-1
        ${
          hasSideCharts
            ? "xl:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)]"
            : "xl:grid-cols-1"
        }
        gap-3
        sm:gap-3
        mt-3
        sm:mt-2
        min-w-0
        items-start
      `}
          >
            {/* TABLE */}
            <Box className="min-w-0 overflow-auto">
              <SiteSummaryTable rows={filteredTableRows} />
            </Box>

            {/* REMAINING CHARTS */}
            {hasSideCharts && (
              <Box
                className="
            min-w-0
            flex
            flex-col
            gap-3
            sm:gap-4
          "
              >
                {remainingTerminalCharts.map((terminal) => (
                  <SiteTerminalChart
                    key={terminal.name}
                    data={terminal}
                    compact={true}
                    active={!excludedTerminalTypes.includes(terminal.name)}
                    onClick={() => toggleTerminalFilter(terminal.name)}
                  />
                ))}
              </Box>
            )}
          </Box>
        );
      })()}
    </Box>
  );
};

export default SiteSummaryDashboard;
