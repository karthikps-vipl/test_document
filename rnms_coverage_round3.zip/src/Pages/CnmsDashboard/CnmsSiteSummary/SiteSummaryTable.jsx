import React, { useMemo } from "react";
import { Box, Chip, Typography } from "@mui/material";
import MTable from "@/components/Reusable/Table/MTable";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { useDispatch, useSelector } from "react-redux";
// import MTable from "@/components/Table/MTable"; // adjust path

const StatusChip = ({ status }) => {
  const normalizedStatus = String(status || "").toUpperCase();
  let backgroundColor = "#64748B";

  if (normalizedStatus === "ONLINE" || normalizedStatus === "UP") {
    backgroundColor = "#2E7D32";
  }

  if (normalizedStatus === "OFFLINE" || normalizedStatus === "DOWN") {
    backgroundColor = "#D32F2F";
  }

  if (normalizedStatus === "RNMS DOWN") {
    backgroundColor = "#F3C106";
  }
  if (normalizedStatus === "MAINTENANCE NON-OPS") {
    backgroundColor = "#B8860B";
  }

  if (normalizedStatus === "MAINTENANCE R-OPS") {
    backgroundColor = "#34B8B8";
  }
  return (
    <Chip
      label={status || "-"}
      size="small"
      sx={{
        height: 24,
        fontSize: "10px",
        fontWeight: 600,
        color: "#FFFFFF",
        backgroundColor,
      }}
    />
  );
};

const CommunicationChip = ({ value, count }) => {
  const normalized = String(value || "").toUpperCase();

  let backgroundColor = "#64748B";

  if (normalized === "VSAT") {
    backgroundColor = "#2563EB";
  }

  if (normalized === "LOS") {
    backgroundColor = "#F59E0B";
  }

  if (normalized === "E1") {
    backgroundColor = "#16A34A";
  }

  if (normalized === "DOWN") {
    backgroundColor = "#DC2626";
  }

  const chipLabel = `${value}${count !== undefined ? ` (${count})` : ""}`;

  return (
    <Chip
      // label={`${value}${count !== undefined ? ` (${count})` : ""}`}
      label={chipLabel}
      size="small"
      sx={{
        height: 24,
        fontSize: "10px",
        fontWeight: 600,
        color: "#fff",
        backgroundColor,
      }}
    />
  );
};

/**
 * COLUMN CONFIGURATION
 * Moved outside the component to resolve SonarQube "Useless Assignment" 
 * and "Move component definition out of parent" issues.
 */
const COLUMNS_CONFIG = [
  {
    uid: "sno",
    name: "S.No",
    width: "70px",
  },
  {
    uid: "siteIdRemoteNumber",
    name: "Site ID",
    width: "130px",
  },
  {
    uid: "siteName",
    name: "Site Name",
  },
  {
    uid: "ipAddress",
    name: "IP Address",
    width: "150px",
    cell: (row) => (
      <Typography
        variant="caption"
        sx={{
          whiteSpace: "nowrap",
          fontFamily: "monospace",
        }}
      >
        {row.ipAddress || "-"}
      </Typography>
    ),
  },
  {
    uid: "latLong",
    name: "Lat-Long",
    cell: (row) => (
      <Typography
        variant="caption"
        sx={{
          whiteSpace: "nowrap",
        }}
      >
        {row.latLong || "-"}
      </Typography>
    ),
  },
  {
    uid: "mode",
    name: "Mode",
    width: "130px",
  },
  {
    uid: "status",
    name: "Status",
    width: "184px",
    cell: (row) => <StatusChip status={row.displayStatus} />,
  },
  {
    uid: "activeModeOfCommunication",
    name: "Active Mode of Communication",
    width: "260px",
  },
];
const SiteSummaryTable = ({ rows = [] }) => {
  const dispatch = useDispatch();
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const toggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  // const columns = useMemo(
  //   () => [
  //     {
  //       uid: "sno",
  //       name: "S.No",
  //       width: "70px",
  //     },
  //     {
  //       uid: "siteIdRemoteNumber",
  //       name: "Site ID",
  //       width: "130px",
  //     },
  //     {
  //       uid: "siteName",
  //       name: "Site Name",
  //       // width: "180px",
  //     },
  //     {
  //       uid: "ipAddress",
  //       name: "IP Address",
  //       width: "150px",
  //       cell: (row) => (
  //         <Typography
  //           variant="caption"
  //           sx={{
  //             whiteSpace: "nowrap",
  //             fontFamily: "monospace",
  //           }}
  //         >
  //           {row.ipAddress || "-"}
  //         </Typography>
  //       ),
  //     },
  //     {
  //       uid: "latLong",
  //       name: "Lat-Long",
  //       // width: "150px",
  //       cell: (row) => (
  //         <Typography
  //           variant="caption"
  //           sx={{
  //             whiteSpace: "nowrap",
  //           }}
  //         >
  //           {row.latLong || "-"}
  //         </Typography>
  //       ),
  //     },
  //     {
  //       uid: "mode",
  //       name: "Mode",
  //       width: "130px",
  //     },
  //     {
  //       uid: "status",
  //       name: "Status",
  //       width: "184px",
  //       cell: (row) => <StatusChip status={row.displayStatus} />,
  //     },
  //     {
  //       uid: "activeModeOfCommunication",
  //       name: "Active Mode of Communication",
  //       width: "260px",
  //       // cell: (row) => <CommunicationSummary row={row} />,
  //     },
  //   ],
  //   []
  // );




  // We still use useMemo here just in case the table component 
  // requires a stable reference, but it now points to the external constant.
  const columns = useMemo(() => COLUMNS_CONFIG, []);

  return (
    <Box
      sx={{
        position: isMaximized ? "fixed" : "relative",
        top: isMaximized ? 0 : "auto",
        left: isMaximized ? 0 : "auto",
        width: isMaximized ? "100vw" : "100%",
        height: isMaximized ? "100vh" : "auto",
        zIndex: isMaximized ? 1000 : "auto",
        backgroundColor: isMaximized ? "background.paper" : "transparent",
        overflow: isMaximized ? "hidden" : "visible",
        p: isMaximized ? 1 : 0,
      }}
    >
      <MTable
        tableData={rows}
        columns={columns}
        showPagination={true}
        showSearch={true}
        showMaximazed={true}
        isMaximized={isMaximized}
        toggleMaximize={toggleMaximize}
        typeHeight="siteSummaryTable"
      />
    </Box>
  );
};

export default SiteSummaryTable;
