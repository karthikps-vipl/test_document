import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  Label,
} from "recharts";
import { Box, useTheme } from "@mui/material";
import { CheckCircleOutline } from "@mui/icons-material";

const STATUS_COLORS = {
  ONLINE: {
    start: "#2E7D32",
    end: "#47C24E",
  },

  OFFLINE: {
    start: "#D32F2F",
    end: "#D35D5D",
  },

  RNMS_DOWN: {
    start: "#F3C106",
    end: "#F3E14D",
  },

  NON_OPS: {
    start: "#B8860B",
    end: "#E0A13E",
  },

  R_OPS: {
    start: "#34B8B8",
    end: "#6CB8B5",
  },
};

const CustomXAxisTick = ({ x, y, payload, fill, active }) => {
  const words = String(payload?.value || "").split(" ");

  let firstLine = "";
  let secondLine = "";

  if (words.length > 2) {
    const midpoint = Math.ceil(words.length / 2);

    firstLine = words.slice(0, midpoint).join(" ");
    secondLine = words.slice(midpoint).join(" ");
  } else {
    firstLine = String(payload?.value || "");
  }

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        textAnchor="middle"
        fill={active ? "#2563EB" : fill}
        fontSize={9}
        fontWeight={active ? 700 : 400}
      >
        <tspan x="0" dy="10">
          {firstLine}
        </tspan>

        {secondLine && (
          <tspan x="0" dy="17">
            {secondLine}
          </tspan>
        )}
      </text>
    </g>
  );
};

const SiteTerminalChart = ({
  data,
  compact = false,
  active = false,
  onClick,
}) => {
  const theme = useTheme();

  const chartColors = theme.palette.custom?.chart || {};

  const chartData = useMemo(() => {
    return [
      {
        name: "Online",
        count: Number(data?.online) || 0,
        gradient: "url(#onlineGrad)",
      },
      {
        name: "Offline",
        count: Number(data?.offline) || 0,
        gradient: "url(#offlineGrad)",
      },
      {
        name: "RNMS Down",
        count: Number(data?.rnmsDown) || 0,
        gradient: "url(#rnmsDownGrad)",
      },
      {
        name: "Non-OPS",
        count: Number(data?.maintenanceNonOpsDown) || 0,
        gradient: "url(#nonOpsGrad)",
      },
      {
        name: "R-OPS",
        count: Number(data?.maintenanceROps) || 0,
        gradient: "url(#rOpsGrad)",
      },
    ];
  }, [data]);

  const totalCount = useMemo(() => {
    return chartData.reduce((sum, item) => sum + Number(item.count || 0), 0);
  }, [chartData]);

  const Gradients = (
    <defs>
      <linearGradient id="onlineGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={STATUS_COLORS.ONLINE.start} />
        <stop offset="100%" stopColor={STATUS_COLORS.ONLINE.end} />
      </linearGradient>

      <linearGradient id="offlineGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={STATUS_COLORS.OFFLINE.start} />
        <stop offset="100%" stopColor={STATUS_COLORS.OFFLINE.end} />
      </linearGradient>

      <linearGradient id="rnmsDownGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={STATUS_COLORS.RNMS_DOWN.start} />
        <stop offset="100%" stopColor={STATUS_COLORS.RNMS_DOWN.end} />
      </linearGradient>

      <linearGradient id="nonOpsGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={STATUS_COLORS.NON_OPS.start} />
        <stop offset="100%" stopColor={STATUS_COLORS.NON_OPS.end} />
      </linearGradient>

      <linearGradient id="rOpsGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={STATUS_COLORS.R_OPS.start} />
        <stop offset="100%" stopColor={STATUS_COLORS.R_OPS.end} />
      </linearGradient>
    </defs>
  );

  const renderTick = (props) => (
    <CustomXAxisTick
      {...props}
      fill={chartColors.text || theme.palette.text.secondary}
      active={active}
    />
  );

  return (
    <Box
      onClick={onClick}
      className="
        rounded-[12px]
        p-3
        sm:p-4
        shadow-sm
        w-full
        min-w-0
        cursor-pointer
      "
      sx={{
        position: "relative",
        background: chartColors.chartbg || theme.palette.background.paper,

        border: active
          ? "2px solid #2563EB"
          : theme.palette.custom?.commonBorder ||
            `1px solid ${theme.palette.divider}`,

        transition: "all 0.2s ease",

        "&:hover": {
          boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
        },
      }}
    >
      {active && (
        <Box
          sx={{
            position: "absolute",
            top: -8,
            right: -6,
            width: 20,
            height: 20,
            borderRadius: "50%",
            backgroundColor: "#2563EB",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 20,
            border: `2px solid ${theme.palette.background.paper}`,
          }}
        >
          <CheckCircleOutline
            sx={{
              fontSize: 13,
              color: "#FFFFFF",
            }}
          />
        </Box>
      )}

      {/* TITLE */}
      <Box
        className="
          text-xs
          sm:text-sm
          font-semibold
          mb-2
          truncate
        "
        title={data?.name}
        sx={{
          color: active ? "#2563EB" : theme.palette.text.primary,
        }}
      >
        {data?.name || "Unknown Terminal"} ({totalCount})
      </Box>

      {/* CHART */}
      {/* <Box className={`w-full ${compact ? "h-[200px]" : "h-[200px]"}`}> */}
      <Box className="w-full h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            margin={{
              top: 10,
              right: 10,
              left: 5,
              bottom: 43,
            }}
            barGap={8}
          >
            {Gradients}

            <CartesianGrid
              vertical={false}
              stroke={chartColors.grid || theme.palette.divider}
            />

            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
              interval={0}
              height={4}
              tick={renderTick}
              // tick={(props) => (
              //   <CustomXAxisTick
              //     {...props}
              //     fill={chartColors.text || theme.palette.text.secondary}
              //     active={active}
              //   />
              // )}
            >
              <Label
                value="Terminal Status"
                position="bottom"
                offset={28}
                style={{
                  textAnchor: "middle",
                  fontSize: 11,
                  fill: theme.palette.text.primary,
                }}
              />
            </XAxis>

            <YAxis
              type="number"
              allowDecimals={false}
              axisLine={false}
              tickLine={false}
              fontSize={10}
              tick={{
                fill: chartColors.text || theme.palette.text.secondary,
              }}
            >
              <Label
                value="Count"
                angle={-90}
                position="insideLeft"
                style={{
                  textAnchor: "middle",
                  fontSize: 11,
                  fill: theme.palette.text.primary,
                }}
              />
            </YAxis>

            <Tooltip
              cursor={{
                fill: chartColors.cursor || "rgba(100,116,139,0.08)",
              }}
              formatter={(value) => [value, "Count"]}
              contentStyle={{
                borderRadius: "8px",
                border: "none",
                boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                backgroundColor:
                  chartColors.tooltipBg || theme.palette.background.paper,
                color: chartColors.tooltipText || theme.palette.text.primary,
              }}
              labelStyle={{
                color: chartColors.tooltipText || theme.palette.text.primary,
                fontWeight: "bold",
                marginBottom: "4px",
              }}
              // This ensures the item text (the number) matches
              itemStyle={{
                color: chartColors.tooltipText || theme.palette.text.primary,
              }}
            />

            <Bar
              dataKey="count"
              radius={[5, 5, 0, 0]}
              barSize={compact ? 26 : 32}
            >
              {/* {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.gradient} />
              ))} */}
              {chartData.map((entry) => (
                // We use entry.name because it is unique to each data point
                <Cell key={`cell-${entry.name}`} fill={entry.gradient} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Box>
    </Box>
  );
};

export default SiteTerminalChart;
