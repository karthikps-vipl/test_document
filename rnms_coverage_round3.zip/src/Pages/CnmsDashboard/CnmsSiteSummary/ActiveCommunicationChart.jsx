import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from "recharts";
import { Box, Typography, useTheme } from "@mui/material";

const ActiveCommunicationChart = ({ data = [], total = 0 }) => {
  const theme = useTheme();

  // ==========================================================
  // ALWAYS KEEP THESE THREE ITEMS
  // ==========================================================

  const chartData = useMemo(() => {
    const defaultData = [
      {
        name: "VSAT",
        value: 0,
        color: "#FFF841",
      },
      {
        name: "E1/LOS",
        value: 0,
        color: "#5AFF74",
      },
      {
        name: "Down",
        value: 0,
        color: "#FF6EDA",
      },
    ];

    if (!Array.isArray(data) || data.length === 0) {
      return defaultData;
    }

    return defaultData.map((defaultItem) => {
      const found = data.find((item) => item?.name === defaultItem.name);

      return {
        ...defaultItem,
        value: Number(found?.value) || 0,
        color: found?.color || defaultItem.color,
      };
    });
  }, [data]);

  // ==========================================================
  // TOTAL
  // ==========================================================

  const totalValue = useMemo(() => {
    return chartData.reduce((sum, item) => sum + Number(item.value || 0), 0);
  }, [chartData]);

  const hasData = totalValue > 0;

  // ==========================================================
  // DONUT DATA
  //
  // Recharts does not render zero-value Pie sectors.
  // Therefore, when everything is zero, render one grey
  // background sector, but keep the legend based on chartData.
  // ==========================================================

  const pieData = useMemo(() => {
    if (!hasData) {
      return [
        {
          name: "No Data",
          value: 1,
          color: "#CBD5E1",
          isNoData: true,
        },
      ];
    }

    return chartData.filter((item) => Number(item.value) > 0);
  }, [chartData, hasData]);

  // ==========================================================
  // TOOLTIP
  // ==========================================================

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || !payload.length) {
      return null;
    }

    const item = payload[0]?.payload;

    if (!item || item.isNoData) {
      return null;
    }

    return (
      <Box
        sx={{
          background: theme.palette.background.paper,
          border: `1px solid ${theme.palette.divider}`,
          borderRadius: "8px",
          px: 1.5,
          py: 1,
          boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
        }}
      >
        <Typography
          variant="caption"
          sx={{
            fontWeight: 600,
          }}
        >
          {item.name}
        </Typography>

        <Typography
          variant="caption"
          display="block"
          sx={{
            color: theme.palette.text.secondary,
          }}
        >
          Count: {item.value}
        </Typography>
      </Box>
    );
  };

  const chartColors = theme.palette.custom?.chart || {};

  // ==========================================================
  // CUSTOM LABEL
  //
  // Shows count in the actual donut region.
  // ==========================================================

  const renderCenterLabel = (props) => {
    const { cx, cy, midAngle, innerRadius, outerRadius, value, payload } =
      props;

    if (!hasData || !value || payload?.isNoData) {
      return null;
    }

    const RADIAN = Math.PI / 180;

    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;

    const x = cx + radius * Math.cos(-midAngle * RADIAN);

    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="#000000"
        textAnchor="middle"
        dominantBaseline="central"
        fontSize={12}
        fontWeight={700}
      >
        {value}
      </text>
    );
  };

  // ==========================================================
  // CUSTOM LEGEND
  //
  // We don't use Recharts' automatic legend because we want
  // all three labels even when their values are 0.
  // ==========================================================

  const renderLegend = () => {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 2,
          flexWrap: "wrap",
          mt: 0.5,
        }}
      >
        {chartData.map((item) => (
          <Box
            key={item.name}
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 0.5,
            }}
          >
            <Box
              sx={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                backgroundColor: item.color,
                flexShrink: 0,
              }}
            />

            <Typography
              variant="caption"
              sx={{
                fontSize: "11px",
                color: theme.palette.text.primary, 
                fontWeight: 500,
              }}
            >
              {item.name}
            </Typography>
          </Box>
        ))}
      </Box>
    );
  };

  return (
    <Box
      className="
        w-full
        h-full
        min-h-[200px]
        flex
        flex-col
        items-center
      "
      sx={{
        background: chartColors.chartbg || theme.palette.background.paper,
      }}
    >
      {/* ====================================================
          TITLE
      ==================================================== */}

      <Typography
        variant="body2"
        sx={{
          fontWeight: 700,
          color: theme.palette.text.primary,
          mb: 1,
        }}
      >
        Active Mode of Communication
      </Typography>

      {/* ====================================================
          CHART
      ==================================================== */}

      <Box
        className="
          w-full
          h-[200px]
          sm:h-[200px]
        "
      >
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={pieData}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="45%"
              innerRadius={hasData ? 55 : 60}
              outerRadius={85}
              paddingAngle={hasData ? 3 : 0}
              isAnimationActive={false}
              labelLine={false}
              label={renderCenterLabel}
            >
              {pieData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.color}
                  style={{
                    outline: "none",
                  }}
                />
              ))}
            </Pie>

            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </Box>

      {/* ====================================================
          LEGEND
      ==================================================== */}

      {renderLegend()}
    </Box>
  );
};

export default ActiveCommunicationChart;
