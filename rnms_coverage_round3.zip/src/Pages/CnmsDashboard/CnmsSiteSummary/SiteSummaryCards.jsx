import React from "react";
import { Box, useTheme } from "@mui/material";

import TotalIcon from "@/assets/SVGIcons/Site_Summary_Total.svg";
import OnlineIcon from "@/assets/SVGIcons/Site_Summary_Online.svg";
import OfflineIcon from "@/assets/SVGIcons/Site_Summary_Offline.svg";
import RnmsDownIcon from "@/assets/SVGIcons/Site_Summary_RNMS_Down.svg";
import NonOpsIcon from "@/assets/SVGIcons/Site_Summary_Non_OPS_Down.svg";
import ROpsIcon from "@/assets/SVGIcons/Site_Summary_R_OPS.svg";
import { CheckCircleOutline } from "@mui/icons-material";

const ICON_MAP = {
    Total: TotalIcon,
    Online: OnlineIcon,
    Offline: OfflineIcon,
    "RNMS Down": RnmsDownIcon,
    "Maintenance Non-OPS": NonOpsIcon,
    "Maintenance R-OPS": ROpsIcon,
  };

  const Card = ({
    title,
    value,
    bgColor,
    image,
    filterKey,
    active,
    onClick,
  }) => {
    const theme = useTheme();
  
    return (
      <Box
        onClick={() => onClick?.(filterKey)}
        className="
          relative
          flex
          flex-row
          items-center
          justify-between
          border
          rounded-lg
          pl-2
          pr-1
          py-1
          min-w-0
          shadow-sm
          cursor-pointer
          transition-all
          duration-200
        "
        sx={{
          background: theme.palette.background.cardbg,
  
          border: active
          ? "1px solid #2563EB"
          : `1px solid ${theme.palette.divider}`,
  
          // borderWidth: active ? 2 : 1,
  
          transition: "all 0.2s ease",
  
          "&:hover": {
            boxShadow: "0 4px 10px rgba(0,0,0,0.12)",
          },
        }}
      >
        {/* ACTIVE CHECKMARK */}
        {active && (
          <Box
            sx={{
              position: "absolute",
              top: -7,
              right: -7,
              width: 18,
              height: 18,
              borderRadius: "50%",
              backgroundColor: "#2563EB",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 2,
              border: `2px solid ${theme.palette.background.paper}`,
            }}
          >
            <CheckCircleOutline
              sx={{
                fontSize: 12,
                color: "#FFFFFF",
              }}
            />
          </Box>
        )}
  
        <Box className="flex flex-col min-w-0 flex-1 pr-2">
          <Box
            className="
              text-[10px]
              sm:text-xs
              leading-tight
              truncate
            "
            sx={{
              color: theme.palette.text.secondary,
            }}
          >
            {title}
          </Box>
  
          <Box
            className="
              text-sm
              sm:text-base
              font-semibold
              leading-tight
              mt-1
            "
            sx={{
              color: theme.palette.text.primary,
            }}
          >
            {value}
          </Box>
        </Box>
  
        <Box
          className="
            shrink-0
            flex
            items-center
            justify-center
            rounded-lg
            w-8
            h-8
            sm:w-9
            sm:h-9
          "
          style={{
            backgroundColor: bgColor || "#64748B",
          }}
        >
          {image ? (
            <img
              src={image}
              alt={title}
              className="
                w-5
                h-5
                sm:w-6
                sm:h-6
                object-contain
              "
            />
          ) : (
            <span
              className="
                text-[8px]
                sm:text-[10px]
                text-white
                font-bold
              "
            >
              N/A
            </span>
          )}
        </Box>
      </Box>
    );
  };
  
  
  const SiteSummaryCards = ({
    cards = [],
    excludedStatuses = [],
    onCardClick,
  }) => {
    return (
      <Box className="p-0">
        <Box
          className="
            grid
            grid-cols-1
            sm:grid-cols-2
            md:grid-cols-3
            lg:grid-cols-6
            gap-2
            sm:gap-3
          "
        >
          {cards.map((item, index) => {
            const isTotal = item.filterKey === "ALL";
  
            const active = isTotal
            ? excludedStatuses.length === 0
            : !excludedStatuses.includes(item.filterKey);
  
            return (
              <Card
                key={`${item.title}-${index}`}
                title={item.title}
                value={item.value}
                bgColor={item.bgColor}
                image={
                  item.image ||
                  ICON_MAP[item.title]
                }
                filterKey={item.filterKey}
                active={active}
                onClick={onCardClick}
              />
            );
          })}
        </Box>
      </Box>
    );
  };
  

export default SiteSummaryCards;
