import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import vehicle from "../../../assets/CNMS/birdEyeViewLegend/vehicle.svg";
import E1OFC from "../../../assets/CNMS/birdEyeViewLegend/E1OFC.svg";
import NOTCONFIGURE from "../../../assets/CNMS/birdEyeViewLegend/NOTCONFIGURE.svg";
import radio from "../../../assets/CNMS/birdEyeViewLegend/radio.svg";
import VSat from "../../../assets/CNMS/birdEyeViewLegend/VSat.svg";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";

// ============================================================
// HELPER: Get Icon
// ============================================================

const getIconForMode = (mode) => {
  switch (mode) {
    case 1:
      return <img src={VSat} alt="V-Sat" style={{ width: 24, height: 24 }} />;
    case 2:
      return <img src={radio} alt="Radio" style={{ width: 20, height: 20 }} />;
    case 3:
      return <img src={E1OFC} alt="E1-OFC" style={{ width: 22, height: 14 }} />;
    // Combine case 4 and default here
    case 4:
    default:
      return (
        <img
          src={NOTCONFIGURE}
          alt="Not Configured"
          style={{
            width: 18,
            height: 18,
          }}
        />
      );
  }
};

// ============================================================
// SITE NODE
// ============================================================

const SiteNodeItem = ({
  site,
  renderSiteTooltip,
  getStatusColor,
  highlight,
}) => {
  const [hovered, setHovered] = useState(false);

  const [pos, setPos] = useState({
    x: 0,
    y: 0,
  });

  const handleMouseMove = (e) => {
    setPos({
      x: e.clientX,
      y: e.clientY,
    });
  };

  const statusColor = getStatusColor(site);

  const icon = getIconForMode(site.activeModeOfCommunication);

  return (
    <>
      <div style={styles.siteNodeWrapper}>
        {icon && <div style={styles.iconContainer}>{icon}</div>}

        {/* Change div to button */}
        <button
          type="button" // Always specify type="button" to prevent accidental form submits
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
          onMouseMove={handleMouseMove}
          style={{
            ...styles.siteBox,
            backgroundColor: statusColor,
            borderColor: "transparent",
          }}
        >
          <img
            src={vehicle}
            alt="vehicle"
            style={{
              width: 16,
              height: 16,
            }}
          />
          <span style={styles.siteIdText}>{highlight(site.siteId)}</span>
        </button>
      </div>

      {hovered &&
        createPortal(
          <div
            style={{
              ...styles.tooltipWrapper,
              position: "fixed",
              left: pos.x + 15,
              top: pos.y + 15,
            }}
          >
            {renderSiteTooltip(site)}
          </div>,
          document.body
        )}
    </>
  );
};

// ============================================================
// SITE CHAIN
// ============================================================

const SiteChain = ({ site, ...props }) => {
  const chain = [site];

  console.log("sitesite222", site);

  if (site.repeator1Site) {
    chain.push(site.repeator1Site);
  }

  if (site.repeator2Site) {
    chain.push(site.repeator2Site);
  }

  if (site.remoteSite) {
    chain.push(site.remoteSite);
  }

  return (
    <div style={styles.chainContainer}>
      {chain.map((node, idx) => (
        <SiteNodeItem key={node.siteId || idx} site={node} {...props} />
      ))}
    </div>
  );
};

// ============================================================
// MAIN COMPONENT
// ============================================================

const RightSidePanel = ({
  selectedPath,
  selectedNode,
  statusColors = {},
  allSites = [],
  onClose,
}) => {
  const [query, setQuery] = useState("");

  useEffect(() => {
    setQuery("");
  }, [selectedPath]);

  const children = selectedNode?.children || [];

  const isSiteNode = !!selectedNode?.siteId;

  const hasSiteChildren = children.some((c) => c.siteId);

  const isTerminalNode = !isSiteNode && hasSiteChildren;

  const isRootNode = selectedPath === "CNMS" && !selectedNode;

  // ==========================================================
  // SEARCH
  // ==========================================================

  const q = query.trim().toLowerCase();

  // ==========================================================
  // TERMINAL SITES
  // ==========================================================

  const filteredSites = useMemo(() => {
    if (!isTerminalNode) {
      return [];
    }

    if (!q) {
      return children;
    }

    return children.filter((site) => {
      const id = (site.siteId || "").toLowerCase();

      const nm = (site.siteName || "").toLowerCase();

      return id.includes(q) || nm.includes(q);
    });
  }, [children, isTerminalNode, q]);

  // ==========================================================
  // ROOT SITES
  // ==========================================================

  const rootSites = useMemo(() => {
    if (!isRootNode) {
      return [];
    }

    const localSites = allSites.filter(
      (site) => site.imTerminalMode?.name === "LOCAL"
    );

    if (!q) {
      return localSites;
    }

    return localSites.filter((site) => {
      const matchLocal =
        (site.siteId || "").toLowerCase().includes(q) ||
        (site.siteName || "").toLowerCase().includes(q);

      if (matchLocal) {
        return true;
      }

      const matchRep1 =
        site.repeator1Site &&
        (site.repeator1Site.siteId || "").toLowerCase().includes(q);

      if (matchRep1) {
        return true;
      }

      const matchRep2 =
        site.repeator2Site &&
        (site.repeator2Site.siteId || "").toLowerCase().includes(q);

      if (matchRep2) {
        return true;
      }

      const matchRemote =
        site.remoteSite &&
        (site.remoteSite.siteId || "").toLowerCase().includes(q);

      if (matchRemote) {
        return true;
      }

      return false;
    });
  }, [isRootNode, allSites, q]);

  const directionSites = useMemo(() => {
    if (isSiteNode || hasSiteChildren || isRootNode) return [];

    const sites = children.flatMap((terminal) => terminal.children || []);

    if (!q) return sites;

    return sites.filter((site) => {
      const siteId = (site.siteId || site.name || "").toLowerCase();
      const siteName = (site.siteName || "").toLowerCase();

      return siteId.includes(q) || siteName.includes(q);
    });
  }, [children, isSiteNode, hasSiteChildren, isRootNode, q]);

  // ==========================================================
  // COUNTS
  // ==========================================================

  const totalVisible = isSiteNode
    ? 1
    : hasSiteChildren
    ? filteredSites.length
    : isRootNode
    ? rootSites.length
    : directionSites.length;

  const showNoResults = q && totalVisible === 0;

  const totalSitesCount = useMemo(() => {
    if (isRootNode) {
      return rootSites.length;
    }

    if (isTerminalNode) {
      return filteredSites.length;
    }

    if (isSiteNode) {
      return 1;
    }

    return 0;
  }, [isRootNode, rootSites, isTerminalNode, filteredSites, isSiteNode]);

  // ==========================================================
  // HIGHLIGHT
  // ==========================================================

  const highlight = (text) => {
    if (!q) {
      return text;
    }

    const str = String(text ?? "");

    const idx = str.toLowerCase().indexOf(q);

    if (idx === -1) {
      return str;
    }

    return (
      <>
        {str.slice(0, idx)}

        <mark style={styles.mark}>{str.slice(idx, idx + q.length)}</mark>

        {str.slice(idx + q.length)}
      </>
    );
  };

  const getHealthStatus = (site) => {
    const statusId = site?.healthStatus?.id;

    // Logic based on healthStatus.id
    switch (statusId) {
      case 0:
        return "DOWN";
      case 1:
        return "UP";
      case 2:
        return "RNMS DOWN";
      case 3:
        // Check maintenanceType for id 3
        if (site?.maintenanceType === 1) {
          return "Maintenance Non-OPS";
        } else if (site?.maintenanceType === 2) {
          return "Maintenance R-OPS";
        } else {
          return "Maintenance Unknown";
        }
      default:
        return "UNKNOWN";
    }
  };

  const getStatusColor = (site) => {
    const statusValue = getHealthStatus(site);
    const statusUpper = statusValue.toUpperCase();

    // Define a mapping to match your statusColors object keys
    // This ensures that "Maintenance Non-OPS" maps to the correct color key
    const statusMapping = {
      DOWN: "Offline",
      UP: "Online",
      "RNMS DOWN": "RNMS Down",
      "MAINTENANCE NON-OPS": "Maintenance Non-OPS",
      "MAINTENANCE R-OPS": "Maintenance R-OPS",
    };

    // Get the lookup key (either from the mapping or the status itself)
    const colorKey = statusMapping[statusUpper] || statusUpper;

    // Return the color from your statusColors object,
    // or a fallback color if not found
    return statusColors[colorKey] || "#94a3b8";
  };

  const renderSiteTooltip = (site) => {
    if (!site) {
      return null;
    }

    const healthStatus = getHealthStatus(site);

    const bgColor = getStatusColor(site);
    console.log("bgcolortool", bgColor);

    return (
      <div style={styles.siteTooltip}>
        <div style={styles.tooltipTitle}>{site.siteName || "Unknown Site"}</div>

        <div style={styles.tooltipDivider} />

        <div style={styles.tooltipRow}>
          <span style={styles.tooltipLabel}>Site Id</span>

          <span style={styles.tooltipValue}>{site.siteId || "-"}</span>
        </div>

        <div style={styles.tooltipRow}>
          <span style={styles.tooltipLabel}>Remote No.</span>

          <span style={styles.tooltipValue}>{site.remoteNumber ?? "-"}</span>
        </div>

        <div style={styles.tooltipRow}>
          <span style={styles.tooltipLabel}>Lat - Lng</span>

          <span style={styles.tooltipValue}>
            {site.latitude != null ? Number(site.latitude).toFixed(3) : "-"}
            {" , "}
            {site.longitude != null ? Number(site.longitude).toFixed(3) : "-"}
          </span>
        </div>

        <div style={styles.tooltipRow}>
          <span style={styles.tooltipLabel}>Health Status</span>

          <span
            style={{
              ...styles.tooltipStatus,
              backgroundColor: bgColor,
              color: "black",
              border: "none",
            }}
          >
            {healthStatus}
          </span>
        </div>

        <div style={styles.tooltipRow}>
          <span style={styles.tooltipLabel}>Mode</span>

          <span style={styles.tooltipValue}>
            {site.imTerminalMode?.name || "-"}
          </span>
        </div>
      </div>
    );
  };

  // ==========================================================
  // RENDER
  // ==========================================================

  return (
    <div style={styles.sidebarContainer}>
      {/* FULL-WIDTH HEADER */}
      <div style={styles.panelHeader}>
        <div style={styles.headerTitleSection}>
          <h3 style={styles.breadcrumbText}>{selectedPath || "CNMS"}</h3>
          <div style={styles.searchWrapper}>
            <span style={styles.searchIcon}>⌕</span>

            <input
              type="text"
              placeholder="Search Here"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={styles.searchInput}
            />

            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                style={styles.clearBtn}
                aria-label="Clear search"
              >
                ×
              </button>
            )}
          </div>
          <div style={styles.headerActions}>
            {totalSitesCount > 0 && (
              <span style={styles.remoteCount}>
                {totalSitesCount} Total Site(s)
              </span>
            )}

            <CustomeFullscreen onClose={onClose} isFullScreenvisible={false} />
          </div>
        </div>
      </div>

      {/* BODY: CNMS BAR + SCROLLABLE CONTENT */}
      <div style={styles.panelBody}>
        <div style={styles.verticalBar}>
          <span style={styles.verticalText}>CNMS</span>
        </div>

        <div style={styles.contentArea}>
          <div style={styles.scrollContent}>
            <div style={styles.cardsContainer}>
              {/* ROOT NODE */}

              {isRootNode && (
                <>
                  {rootSites.map((site, idx) => (
                    <SiteChain
                      key={site.siteId || idx}
                      site={site}
                      renderSiteTooltip={renderSiteTooltip}
                      getStatusColor={getStatusColor}
                      highlight={highlight}
                    />
                  ))}
                </>
              )}

              {/* SITE NODE */}

              {isSiteNode && (!q || totalVisible > 0) && (
                <>
                  {/* <div style={styles.sectionTitle}>
                  {selectedNode.imTerminalType?.terminalTypeName}
                </div> */}

                  <SiteChain
                    site={selectedNode}
                    renderSiteTooltip={renderSiteTooltip}
                    getStatusColor={getStatusColor}
                    highlight={highlight}
                  />
                </>
              )}

              {/* TERMINAL NODE */}

              {isTerminalNode && (
                <>
                  {/* <div style={styles.sectionTitle}>{selectedNode.name}</div> */}

                  {filteredSites.map((site, idx) => (
                    <SiteChain
                      key={site.siteId || idx}
                      site={site}
                      renderSiteTooltip={renderSiteTooltip}
                      getStatusColor={getStatusColor}
                      highlight={highlight}
                    />
                  ))}
                </>
              )}

              {/* DIRECTION NODE */}

              {!isSiteNode && !hasSiteChildren && !isRootNode && (
                <>
                  {/* <div style={styles.sectionTitle}>
                  {selectedNode?.name || "Sites"}
                </div> */}

                  {directionSites.map((site, idx) => (
                    <SiteChain
                      key={site.siteId || idx}
                      site={site}
                      renderSiteTooltip={renderSiteTooltip}
                      getStatusColor={getStatusColor}
                      highlight={highlight}
                    />
                  ))}
                </>
              )}

              {/* EMPTY */}

              {showNoResults && (
                <div style={styles.emptyState}>
                  <div style={styles.emptyTitle}>No results found</div>
                  <div style={styles.emptySub}>
                    Nothing matches "<strong>{query}</strong>"
                  </div>
                </div>
              )}

              {/* NO DATA */}

              {!isSiteNode && !q && children.length === 0 && !isRootNode && (
                <p
                  style={{
                    fontSize: "12px",
                    color: "#888",
                  }}
                >
                  No data available
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// STYLES
// ============================================================

const styles = {
  sidebarContainer: {
    width: "100%",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#fff",
    position: "relative",
    overflow: "hidden",
    borderLeft: "1px solid #e5eaee",
  },

  verticalBar: {
    width: "34px",
    flex: "0 0 34px",
    backgroundColor: "#dbe6ff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRight: "1px solid #cbd8f1",
    height: "calc(100% - 20px)",
    marginTop: "20px",
    borderTopRightRadius: "15px",
  },

  verticalText: {
    writingMode: "vertical-rl",
    transform: "rotate(180deg)",
    color: "#3f51b5",
    fontSize: "12px",
    fontWeight: "bold",
    letterSpacing: "2px",
  },

  contentArea: {
    flex: 1,
    minWidth: 0,
    minHeight: 0,
    display: "flex",
    flexDirection: "column",
    padding: "12px",
    overflow: "hidden",
    marginTop: "15px",
  },

  panelHeader: {
    width: "100%",
    boxSizing: "border-box",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    padding: "14px 16px",
    margin: 0,
    flexShrink: 0,
    backgroundColor: "#e8efff",
    borderBottom: "1px solid #d5e0f5",
  },

  headerTitleSection: {
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
    minWidth: 0,
  },

  titleWrapper: {
    minWidth: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    flex: 1,
  },

  breadcrumbText: {
    margin: 0,
    fontSize: "15px",
    color: "#1a7f9e",
    fontWeight: 700,
    wordBreak: "break-word",
    minWidth: 0,
    overflowWrap: "anywhere",
  },

  remoteCount: {
    fontSize: "11px",
    color: "#8a97a1",
    whiteSpace: "nowrap",
  },

  searchWrapper: {
    position: "relative",
    display: "flex",
    alignItems: "center",
  },

  searchIcon: {
    position: "absolute",
    left: "10px",
    fontSize: "15px",
    color: "#9aa7b1",
    pointerEvents: "none",
  },

  searchInput: {
    width: "100%",
    boxSizing: "border-box",
    padding: "8px 30px 8px 30px",
    borderRadius: "18px",
    border: "1px solid #dfe6ec",
    fontSize: "13px",
    outline: "none",
    backgroundColor: "#f7f9fb",
    color: "#1a2e3a",
  },

  clearBtn: {
    position: "absolute",
    right: "8px",
    border: "none",
    background: "transparent",
    fontSize: "16px",
    lineHeight: 1,
    color: "#8a97a1",
    cursor: "pointer",
    padding: "0 4px",
  },

  scrollContent: {
    flex: 1,
    minHeight: 0,
    overflowY: "auto",
    overflowX: "hidden",
    paddingBottom: "16px",
    scrollbarWidth: "thin",
  },

  cardsContainer: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },

  sectionTitle: {
    fontSize: "13px",
    fontWeight: 700,
    color: "#0d4d63",
    marginBottom: "4px",
    paddingBottom: "4px",
    borderBottom: "1px solid #eef2f5",
  },
  legendDock: {
    position: "absolute",
    right: "8px",
    bottom: "8px",
    zIndex: 20,

    display: "flex",
    flexDirection: "column",
    alignItems: "stretch",
    gap: "6px",

    width: "30%",

    padding: "8px",

    backgroundColor: "rgba(255,255,255,0.96)",

    border: "1px solid #e2e8ee",

    borderRadius: "8px",

    boxShadow: "0 3px 12px rgba(0,0,0,0.10)",

    backdropFilter: "blur(4px)",
  },

  legendCard: {
    display: "flex",
    flexDirection: "column",
    gap: "5px",
  },

  legendTitle: {
    fontSize: "10px",
    fontWeight: 700,
    color: "#0d4d63",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    marginBottom: "2px",
  },

  technicalLegend: {
    display: "flex",
    flexDirection: "column",
    gap: "5px",
  },

  techLegendItem: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    minHeight: "18px",
  },

  techLegendText: {
    fontSize: "12.5px",
    fontWeight: 500,
    color: "#1a2e3a",
  },

  legendIcon: {
    width: "24px",
    height: "24px",
    objectFit: "contain",
    flexShrink: 0,
  },

  statusLegend: {
    display: "flex",
    flexDirection: "column",
    gap: "5px",
  },

  legendItem: {
    display: "flex",
    alignItems: "center",
    gap: "7px",
    minHeight: "16px",
  },

  legendText: {
    fontSize: "10.5px",
    fontWeight: 500,
    color: "#1a2e3a",
  },

  dot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    flexShrink: 0,
  },

  chainContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: "8px",
    flexWrap: "wrap",
    marginBottom: "8px",
  },

  siteNodeWrapper: {
    display: "flex",
    alignItems: "center",
  },

  iconContainer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: "20px",
  },

  siteBox: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    padding: "6px 3px",
    borderRadius: "6px",
    border: "1px solid transparent",
    minWidth: "fit-content",
    cursor: "pointer",
    transition: "all 0.15s ease",
  },

  siteIdText: {
    fontSize: "13px",
    fontWeight: 600,
    color: "#1a2e3a",
    // color:'white'
  },

  tooltipWrapper: {
    zIndex: 9999,
    pointerEvents: "none",
  },

  siteTooltip: {
    width: "260px",
    padding: "12px 14px",
    backgroundColor: "rgba(13, 44, 56, 0.97)",
    color: "#ffffff",
    borderRadius: "8px",
    boxShadow: "0 6px 20px rgba(0,0,0,0.22)",
    fontSize: "12px",
  },

  tooltipTitle: {
    fontSize: "14px",
    fontWeight: 700,
    color: "#ffffff",
    marginBottom: "6px",
  },

  tooltipDivider: {
    height: "1px",
    backgroundColor: "rgba(255,255,255,0.18)",
    marginBottom: "8px",
  },

  tooltipRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
    marginBottom: "6px",
  },

  tooltipLabel: {
    color: "#aebfc7",
    fontSize: "11px",
    whiteSpace: "nowrap",
  },

  tooltipValue: {
    color: "#ffffff",
    fontSize: "11px",
    fontWeight: 600,
    textAlign: "right",
    wordBreak: "break-word",
  },

  tooltipStatus: {
    color: "#ffffff",
    padding: "2px 7px",
    borderRadius: "10px",
    fontSize: "10px",
    fontWeight: 700,
  },

  terminalBadge: {
    padding: "8px 12px",
    borderRadius: "6px",
    backgroundColor: "#f1f6ff",
    border: "1px solid #dbe4fa",
    fontSize: "13px",
    fontWeight: 600,
    color: "#1a7f9e",
    width: "fit-content",
    minWidth: "140px",
  },

  mark: {
    backgroundColor: "#ffe58a",
    color: "#1a2e3a",
    padding: "0 1px",
    borderRadius: 2,
  },

  emptyState: {
    marginTop: "20px",
    padding: "20px 12px",
    textAlign: "center",
    color: "#8a97a1",
  },

  emptyIcon: {
    fontSize: "22px",
    marginBottom: "6px",
  },

  emptyTitle: {
    fontSize: "13px",
    fontWeight: 700,
    color: "#3d4f5c",
    marginBottom: "4px",
  },

  emptySub: {
    fontSize: "12px",
    color: "#8a97a1",
  },
  headerActions: {
    display: "flex",
    alignItems: "center",
    gap: "4px",
  },
  panelBody: {
    flex: 1,
    minHeight: 0,
    minWidth: 0,
    display: "flex",
    overflow: "hidden",
  },
};

export default RightSidePanel;
