import React, { useEffect, useRef, useState, useMemo } from "react";
import * as d3 from "d3";
import { useSelector } from "react-redux";
import { getCompassDirection } from "geolib";
import RightSidePanel from "./RightSidePanel";

import PictorialView from "./PictorialView";

import {
  Box,
  Divider,
  IconButton,
  Menu,
  MenuItem,
  Tooltip,
  useTheme,
} from "@mui/material";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import FullscreenIcon from "@mui/icons-material/Fullscreen";
import FullscreenExitIcon from "@mui/icons-material/FullscreenExit";
import PrintIcon from "@mui/icons-material/Print";
import DownloadIcon from "@mui/icons-material/Download";

import MAlarmSelect from "@/components/Dialogs/AlarmSuppression/MAlarmSelect";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

import E1OFC from "../../../assets/CNMS/birdEyeViewLegend/E1OFC.svg";
import NOTCONFIGURE from "../../../assets/CNMS/birdEyeViewLegend/NOTCONFIGURE.svg";
import radio from "../../../assets/CNMS/birdEyeViewLegend/radio.svg";
import VSat from "../../../assets/CNMS/birdEyeViewLegend/VSat.svg";

// ============================================================
// Constants
// ============================================================

const technicalLegends = [
  { label: "E1-OFC", icon: E1OFC },
  { label: "Radio", icon: radio },
  { label: "V-Sat", icon: VSat },
  { label: "Not Configured", icon: NOTCONFIGURE },
];

const CENTER_LAT_LNG = {
  latitude: "20.5937",
  longitude: "78.9029",
};

const DIRECTION_ORDER = ["N", "E", "S", "W"];

const DIRECTION_NAMES = {
  N: "North",
  E: "East",
  S: "South",
  W: "West",
};

const DIRECTION_COLORS = {
  N: "#65a4e4",
  E: "#3effff",
  S: "#e96667",
  W: "#db66e9",
};

const CNMS_COLOR = "#536a96";

const LABEL_FILL = ["#ffffff", "#ffffff", "#0d2c38", "#0d2c38"];

const filterTypeOptions = [
  { label: "All", value: "All" },
  { label: "Terminal", value: "Terminal" },
  { label: "Remote Group", value: "Remote Group" },
];

const getChartSvgForExport = (svgElement) => {
  if (!svgElement) {
    throw new Error("Chart SVG is not available.");
  }

  const svg = svgElement.cloneNode(true);
  const rect = svgElement.getBoundingClientRect();

  const width =
    Number(svgElement.getAttribute("width")) || Math.round(rect.width) || 800;

  const height =
    Number(svgElement.getAttribute("height")) || Math.round(rect.height) || 600;

  svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  svg.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
  svg.setAttribute("width", width);
  svg.setAttribute("height", height);
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);

  // Use explicit SVG dimensions so exported images have
  // predictable sizing outside the React layout.
  svg.style.width = `${width}px`;
  svg.style.height = `${height}px`;
  svg.style.display = "block";

  return {
    svg,
    width,
    height,
    svgText: new XMLSerializer().serializeToString(svg),
  };
};

const downloadBlob = (blob, filename) => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

const exportChartImage = async (svgElement, format) => {
  const { svgText, width, height } = getChartSvgForExport(svgElement);

  if (format === "svg") {
    downloadBlob(
      new Blob([svgText], {
        type: "image/svg+xml;charset=utf-8",
      }),
      "bird-eye-view.svg"
    );
    return;
  }

  const svgBlob = new Blob([svgText], {
    type: "image/svg+xml;charset=utf-8",
  });

  const svgUrl = URL.createObjectURL(svgBlob);

  try {
    const image = new Image();

    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () =>
        reject(new Error("Unable to render chart for export."));
      image.src = svgUrl;
    });

    const scale = 2;
    const canvas = document.createElement("canvas");

    canvas.width = width * scale;
    canvas.height = height * scale;

    const context = canvas.getContext("2d");

    if (!context) {
      throw new Error("Canvas is not supported.");
    }

    // JPEG does not support transparency.
    if (format === "jpeg") {
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
    }

    context.scale(scale, scale);
    context.drawImage(image, 0, 0, width, height);

    const mimeType = format === "jpeg" ? "image/jpeg" : "image/png";

    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob(
        (result) =>
          result ? resolve(result) : reject(new Error("Image export failed.")),
        mimeType,
        0.95
      );
    });

    downloadBlob(blob, `bird-eye-view.${format}`);
  } finally {
    URL.revokeObjectURL(svgUrl);
  }
};

const printChart = (svgElement) => {
  const { svgText } = getChartSvgForExport(svgElement);
  const printWindow = window.open("", "_blank");

  if (!printWindow) {
    window.alert(
      "The print window was blocked. Please allow pop-ups and try again."
    );
    return;
  }

  printWindow.document.open();
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Bird Eye View</title>
        <style>
          @page { size: landscape; margin: 10mm; }
          body {
            margin: 0;
            padding: 10px;
            background: #fff;
          }
          svg {
            display: block;
            width: 100%;
            height: auto;
            max-height: 95vh;
          }
        </style>
      </head>
      <body>${svgText}</body>
    </html>
  `);
  printWindow.document.close();

  printWindow.onload = () => {
    printWindow.focus();
    printWindow.print();
  };
};

const BirdEyeView = () => {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const prevNodesRef = useRef(null);

  const myRef = useRef(null);
  const [selectedPath, setSelectedPath] = useState("CNMS");
  const [selectedNode, setSelectedNode] = useState(null);
  const [drillPath, setDrillPath] = useState([]);
  const [tooltip, setTooltip] = useState(null);
  const [size, setSize] = useState({ w: 0, h: 0 });

  const [isRightPanelOpen, setIsRightPanelOpen] = useState(false);

  const [isPictorialView, setIsPictorialView] = useState(false);
  const [isChartFullscreen, setIsChartFullscreen] = useState(false);

  // Controls whether the RightSidePanel is visible
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  const theme = useTheme();

  // ==========================================================
  // Filter States
  // ==========================================================

  const [filterType, setFilterType] = useState("All");
  const [selectedGroups, setSelectedGroups] = useState([]);
  const [selectedSites, setSelectedSites] = useState([]);
  const [selectedTerminals, setSelectedTerminals] = useState([]);

  const [appliedFilters, setAppliedFilters] = useState({
    type: "All",
    groups: [],
    sites: [],
    terminals: [],
  });

  // ==========================================================
  // Redux data
  // ==========================================================

  const remoteRepDetails = useSelector((state) => state.remoteRepDetails) || {};

  const fetchSiteDetails = remoteRepDetails.fetchSiteDetails || [];
  const sites = fetchSiteDetails;

  console.log("sitessites", sites);

  const { allSiteGroups } = useSelector((state) => state.mapViewSlice);

  const [chartMenuAnchor, setChartMenuAnchor] = useState(null);

  const isChartMenuOpen = Boolean(chartMenuAnchor);

  const handleChartMenuOpen = (event) => {
    setChartMenuAnchor(event.currentTarget);
  };

  const handleChartMenuClose = () => {
    setChartMenuAnchor(null);
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsChartFullscreen(document.fullscreenElement === containerRef.current);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  const handleChartAction = async (action) => {
    handleChartMenuClose();

    try {
      if (action === "fullscreen") {
        if (document.fullscreenElement) {
          await document.exitFullscreen();
        } else if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        }
        return;
      }

      if (action === "print") {
        printChart(svgRef.current);
        return;
      }

      if (["png", "jpeg", "svg"].includes(action)) {
        await exportChartImage(svgRef.current, action);
      }
    } catch (error) {
      console.error("Bird Eye View chart action failed:", error);
      window.alert("Unable to complete the chart action. Please try again.");
    }
  };

  const statusColors = {
    Online: "#2e7d32",
    Offline: "#d32f2f",
    "RNMS Down": "#f3c106",
    "Maintenance Non-OPS": "#b8860b",
    "Maintenance R-OPS": "#34b8b8",
  };

  // ==========================================================
  // Filter Options
  // ==========================================================

  const groupOptions = useMemo(() => {
    return (allSiteGroups || []).map((g) => ({
      label: g.groupName,
      value: g.groupName,
    }));
  }, [allSiteGroups]);

  const siteOptions = useMemo(() => {
    if (!selectedGroups.length) return [];

    const sitesInGroups = [];

    selectedGroups.forEach((groupName) => {
      const group = (allSiteGroups || []).find(
        (g) => g.groupName === groupName
      );

      if (group?.sites) {
        group.sites.forEach((site) => {
          if (!sitesInGroups.includes(site.siteId)) {
            sitesInGroups.push(site.siteId);
          }
        });
      }
    });

    return sitesInGroups.map((id) => ({
      label: id,
      value: id,
    }));
  }, [selectedGroups, allSiteGroups]);

  const terminalOptions = useMemo(() => {
    const terminalSet = new Set();

    (sites || []).forEach((site) => {
      if (site.imTerminalType?.terminalTypeName) {
        terminalSet.add(site.imTerminalType.terminalTypeName);
      }
    });

    return Array.from(terminalSet).map((name) => ({
      label: name,
      value: name,
    }));
  }, [sites]);

  // ==========================================================
  // Filter Handlers
  // ==========================================================

  const handleFilterTypeChange = (e) => {
    const type = e.target.value;

    setFilterType(type);
    setSelectedGroups([]);
    setSelectedSites([]);
    setSelectedTerminals([]);

    if (type === "All") {
      setAppliedFilters({
        type: "All",
        groups: [],
        sites: [],
        terminals: [],
      });
    }
  };

  const handleApplyFilter = () => {
    setAppliedFilters({
      type: filterType,
      groups: selectedGroups,
      sites: selectedSites,
      terminals: selectedTerminals,
    });
  };

  // ==========================================================
  // Filtered Data
  // ==========================================================

  const filteredSitesForChart = useMemo(() => {
    if (appliedFilters.type === "All") {
      return sites;
    }

    if (appliedFilters.type === "Remote Group") {
      if (!appliedFilters.sites.length) return [];

      return sites.filter((site) => appliedFilters.sites.includes(site.siteId));
    }

    if (appliedFilters.type === "Terminal") {
      if (!appliedFilters.terminals.length) return [];

      return sites.filter((site) =>
        appliedFilters.terminals.includes(site.imTerminalType?.terminalTypeName)
      );
    }

    return sites;
  }, [sites, appliedFilters]);

  const getHierarchyNodeByPath = (root, path) => {
    let current = root;
    for (const name of path) {
      const next = current.children?.find((child) => child.data.name === name);

      if (!next) {
        return null;
      }

      current = next;
      console.log("bbbcurrent", current);
    }

    return current;
  };

  // Direction calculation
  const getDirections = (siteList) => {
    const directionMap = {
      N: [],
      E: [],
      S: [],
      W: [],
    };

    (siteList || []).forEach((site) => {
      if (site?.latitude == null || site.longitude == null || !site.siteId) {
        return;
      }

      try {
        const direction = getCompassDirection(CENTER_LAT_LNG, {
          latitude: site.latitude,
          longitude: site.longitude,
        });

        const directionKey = direction?.charAt(0);

        if (directionMap[directionKey]) {
          directionMap[directionKey].push(site.siteId);
        }
      } catch (error) {
        console.error(
          `Unable to calculate direction for site ${site.siteId}`,
          error
        );
      }
    });

    return directionMap;
  };

  const buildHierarchy = (siteList) => {
    const validLocalSites = (siteList || []).filter(
      (site) =>
        site?.latitude != null &&
        site?.longitude != null &&
        site?.imTerminalMode?.name === "LOCAL"
    );

    if (!validLocalSites.length) {
      return {
        name: "CNMS",
        children: [],
      };
    }

    const directionMap = getDirections(validLocalSites);
    const directionChildren = [];

    DIRECTION_ORDER.forEach((direction) => {
      const siteIdsInDirection = directionMap[direction] || [];

      if (!siteIdsInDirection.length) return;

      const directionSiteIdSet = new Set(siteIdsInDirection);

      const sitesInDirection = validLocalSites.filter((site) =>
        directionSiteIdSet.has(site.siteId)
      );

      const terminalGroups = d3.group(
        sitesInDirection,
        (site) => site.imTerminalType?.terminalTypeName || "Unknown"
      );

      const terminalChildren = Array.from(terminalGroups.entries()).map(
        ([terminalName, terminalSites]) => ({
          name: terminalName,
          terminal: terminalName,
          dir: direction,
          children: terminalSites.map((site) => ({
            ...site,
            name: site.siteId,
            siteId: site.siteId,
            terminal: terminalName,
            dir: direction,
          })),
        })
      );

      directionChildren.push({
        name: DIRECTION_NAMES[direction],
        dir: direction,
        children: terminalChildren,
      });
    });

    return {
      name: "CNMS",
      children: directionChildren,
    };
  };

  useEffect(() => {
    if (!drillPath.length) {
      return;
    }

    const hierarchyData = buildHierarchy(filteredSitesForChart);

    const root = d3
      .hierarchy(hierarchyData)
      .sum((node) => (node.children?.length ? 0 : 1));

    const resolvedNode = getHierarchyNodeByPath(root, drillPath);

    if (!resolvedNode) {
      setDrillPath([]);
      setSelectedPath("CNMS");
      setSelectedNode(null);
    }
  }, [filteredSitesForChart]);

  // Resize observer
  useEffect(() => {
    if (!containerRef.current) return;

    const updateSize = () => {
      if (!containerRef.current) return;

      setSize({
        w: containerRef.current.clientWidth,
        h: containerRef.current.clientHeight,
      });
    };

    updateSize();

    const observer = new ResizeObserver(updateSize);
    observer.observe(containerRef.current);

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const timer = requestAnimationFrame(() => {
      if (!containerRef.current) return;

      setSize({
        w: containerRef.current.clientWidth,
        h: containerRef.current.clientHeight,
      });
    });

    return () => cancelAnimationFrame(timer);
  }, [isPanelOpen]);
  // ==========================================================
  // Tooltip
  // ==========================================================

  const buildTooltip = (node) => {
    const data = node.data;

    if (data.siteId) {
      return (
        <div>
          <div style={{ fontWeight: 700, marginBottom: 2 }}>{data.siteId}</div>

          <div style={{ fontSize: 11, color: "#cbd5e1" }}>
            {data.siteName || "Unknown Site"} ·{" "}
            {data.healthStatus?.value || "UNKNOWN"}
          </div>

          <div
            style={{
              fontSize: 10,
              color: "#94a3b8",
              marginTop: 2,
            }}
          >
            lat {Number(data.latitude).toFixed(3)} · lng{" "}
            {Number(data.longitude).toFixed(3)}
          </div>

          <div
            style={{
              fontSize: 10,
              color: "#94a3b8",
              marginTop: 2,
            }}
          >
            Direction: {DIRECTION_NAMES[data.dir] || data.dir || "UNKNOWN"}
          </div>
        </div>
      );
    }

    if (data.children?.some((child) => child.siteId)) {
      const count = data.children.length;

      return (
        <div>
          <div style={{ fontWeight: 700, marginBottom: 2 }}>{data.name}</div>

          <div style={{ fontSize: 11, color: "#cbd5e1" }}>
            {count} local site{count > 1 ? "s" : ""}
          </div>
        </div>
      );
    }

    const terminalCount = node.children?.length || 0;

    return (
      <div>
        <div style={{ fontWeight: 700, marginBottom: 2 }}>{data.name}</div>

        <div style={{ fontSize: 11, color: "#cbd5e1" }}>
          {terminalCount} terminal type
          {terminalCount === 1 ? "" : "s"}
        </div>
      </div>
    );
  };

  // ==========================================================
  // Draw Sunburst
  // ==========================================================

  useEffect(() => {
    if (!svgRef.current || !size.w || !size.h) return;

    const width = size.w;
    const height = size.h;

    const radius = Math.min(width, height) / 2 - 40;

    const svg = d3.select(svgRef.current);

    let gRoot = svg.select("g.sunburst-root");

    if (gRoot.empty()) {
      gRoot = svg.append("g").attr("class", "sunburst-root");
    }

    gRoot.attr("transform", `translate(${width / 2}, ${height / 2})`);

    const hierarchyData = buildHierarchy(filteredSitesForChart);

    const fullRoot = d3
      .hierarchy(hierarchyData)
      // .sum((node) => (node.children && node.children.length ? 0 : 1));
      .sum((node) => (node.children?.length ? 0 : 1));
    let zoomRoot = fullRoot;

    if (drillPath.length) {
      const resolvedNode = getHierarchyNodeByPath(fullRoot, drillPath);

      if (resolvedNode) {
        zoomRoot = resolvedNode;
      } else {
        // The currently selected path no longer exists
        // after filtering. Return safely to CNMS.
        zoomRoot = fullRoot;

        // Keep React state consistent with the hierarchy.
        queueMicrotask(() => {
          setDrillPath([]);
          setSelectedPath("CNMS");
          setSelectedNode(null);
        });
      }
    }

    const depthOffset = zoomRoot.depth;
    const maxRelDepth = zoomRoot.height + 1;

    const ringWidth = maxRelDepth > 0 ? radius / maxRelDepth : radius;

    d3.partition().size([2 * Math.PI, radius])(zoomRoot);

    zoomRoot.each((node) => {
      const relativeDepth = node.depth - depthOffset;

      node.y0 = relativeDepth * ringWidth;
      node.y1 = (relativeDepth + 1) * ringWidth;

      node.relDepth = relativeDepth;

      node.pathKey = node
        .ancestors()
        .reverse()
        .map((ancestor) => ancestor.data.name)
        .join("|");
    });

    const nodes = zoomRoot.descendants();

    const previousPositions = new Map();

    if (prevNodesRef.current) {
      prevNodesRef.current.forEach((node) => {
        previousPositions.set(node.pathKey, {
          x0: node.x0,
          x1: node.x1,
          y0: node.y0,
          y1: node.y1,
        });
      });
    }

    const arc = d3
      .arc()
      .startAngle((node) => node.x0)
      .endAngle((node) => node.x1)
      .innerRadius((node) => node.y0)
      .outerRadius((node) => node.y1);

    const visibleNodes = nodes.filter((node) => node.depth > 0);

    const getSliceColor = (node) => {
      if (node.relDepth === 0) {
        return CNMS_COLOR;
      }

      const baseColor = DIRECTION_COLORS[node.data.dir] || "#ccc";

      if (node.relDepth === 1) {
        return baseColor;
      }

      const darkenFactor = node.relDepth === 2 ? 0.2 : 0.4;

      return d3.color(baseColor).darker(darkenFactor).toString();
    };

    const slices = gRoot
      .selectAll("path.slice")
      .data(visibleNodes, (node) => node.pathKey);

    slices.exit().transition().duration(500).style("opacity", 0).remove();

    const enter = slices
      .enter()
      .append("path")
      .attr("class", "slice")
      .style("cursor", "pointer")
      .style("opacity", 0)
      .attr("stroke", "#ffffff")
      .attr("stroke-width", 1.5)

      // ======================================================
      // Slice hover
      // ======================================================

      .on("mouseenter", function (event, node) {
        d3.select(this).attr(
          "fill",
          d3.color(getSliceColor(node)).brighter(0.3).toString()
        );

        if (!containerRef.current) return;

        const rect = containerRef.current.getBoundingClientRect();

        setTooltip({
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
          content: buildTooltip(node),
        });
      })

      .on("mousemove", function (event) {
        if (!containerRef.current) return;

        const rect = containerRef.current.getBoundingClientRect();

        setTooltip((previous) =>
          previous
            ? {
                ...previous,
                x: event.clientX - rect.left,
                y: event.clientY - rect.top,
              }
            : previous
        );
      })

      .on("mouseleave", function (_, node) {
        d3.select(this).attr("fill", getSliceColor(node));

        setTooltip(null);
      })

      // ======================================================
      // Slice click
      // ======================================================

      .on("click", function (_, node) {
        const pathArr = node
          .ancestors()
          .reverse()
          .slice(1)
          .map((ancestor) => ancestor.data.name);

        // const nextPath =
        //   pathArr.length > 0 ? ["CNMS", ...pathArr].join("/") : "CNMS";
        // setSelectedPath(nextPath);
        // setSelectedNode(node.data);

        const displayPathArr = pathArr.map((part, index) => {
          if (index === pathArr.length - 1 && node.data.siteId) {
            return node.data.siteName || part;
          }

          return part;
        });

        const nextPath =
          displayPathArr.length > 0
            ? ["CNMS", ...displayPathArr].join("/")
            : "CNMS";

        setSelectedPath(nextPath);
        setSelectedNode(node.data);

        setIsPanelOpen(true);
        setIsRightPanelOpen(true);

        if (node.children?.length) {
          setDrillPath(pathArr);
        }
      });
    enter
      .merge(slices)
      .attr("fill", (node) => getSliceColor(node))
      .transition()
      .duration(750)
      .ease(d3.easeCubicOut)
      .style("opacity", 1)
      .attrTween("d", function (node) {
        const target = {
          x0: node.x0,
          x1: node.x1,
          y0: node.y0,
          y1: node.y1,
        };

        const previous = previousPositions.get(node.pathKey) ||
          (node.parent && previousPositions.get(node.parent.pathKey)) || {
            x0: node.x0,
            x1: node.x0,
            y0: 0,
            y1: 0,
          };

        const interpolator = d3.interpolate(previous, target);

        return (t) => arc(interpolator(t));
      });

    // ========================================================
    // Labels
    // ========================================================

    const labelNodes = visibleNodes.filter((node) => node.x1 - node.x0 > 0.02);

    const labels = gRoot
      .selectAll("text.slice-label")
      .data(labelNodes, (node) => node.pathKey);

    labels.exit().transition().duration(300).style("opacity", 0).remove();

    const labelEnter = labels
      .enter()
      .append("text")
      .attr("class", "slice-label")
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em")
      .style("pointer-events", "none")
      .style("opacity", 0)
      .style("font-family", "sans-serif");

    labelEnter
      .merge(labels)
      .text((node) => {
        const arcLength = (node.x1 - node.x0) * ((node.y0 + node.y1) / 2);

        const fontSize =
          node.relDepth === 1 ? 12 : node.relDepth === 2 ? 11 : 9;

        const maxChars = Math.floor(arcLength / (fontSize * 0.65));
        const text = node?.data?.name;

        if (text.length <= maxChars) {
          return text;
        }

        return text.substring(0, Math.max(0, maxChars - 3)) + "...";
      })
      .style("font-size", (node) =>
        node.relDepth === 1 ? "12px" : node.relDepth === 2 ? "11px" : "9px"
      )
      .style("font-weight", (node) => (node.relDepth <= 1 ? 700 : 600))
      .style("letter-spacing", "0.2px")
      .style("fill", (node) => LABEL_FILL[node.relDepth] || "#0d2c38")
      .transition()
      .duration(750)
      .ease(d3.easeCubicOut)
      .style("opacity", 1)
      .attrTween("transform", function (node) {
        const radiusMid = (node.y0 + node.y1) / 2;

        const angleMid = (node.x0 + node.x1) / 2;

        const angleDeg = (angleMid * 180) / Math.PI;

        const flip = angleDeg < 180 ? 90 : -90;

        const transform = `rotate(${
          angleDeg - 90
        }) translate(${radiusMid}, 0) rotate(${flip})`;

        return () => transform;
      });

    // ========================================================
    // CNMS Center Circle
    // ========================================================

    let centerCircle = gRoot.select("circle.center");

    if (centerCircle.empty()) {
      centerCircle = gRoot
        .append("circle")
        .attr("class", "center")
        .style("cursor", "pointer");
    }

    centerCircle.on("click", () => {
      setDrillPath((previous) => {
        // Already at CNMS
        if (previous.length === 0) {
          setSelectedPath("CNMS");
          setSelectedNode(null);

          setIsPanelOpen(true);
          setIsRightPanelOpen(true);

          return [];
        }

        // Remove the current node and go to its parent.
        const parentPath = previous.slice(0, -1);

        // Resolve the parent against the CURRENT filtered hierarchy.
        const parentNode = getHierarchyNodeByPath(fullRoot, parentPath);

        // If filtering removed the parent path,
        // safely reset to CNMS.
        if (!parentNode) {
          setSelectedPath("CNMS");
          setSelectedNode(null);

          setIsPanelOpen(true);
          setIsRightPanelOpen(true);

          return [];
        }

        const parentSelectedPath =
          parentPath.length > 0 ? ["CNMS", ...parentPath].join("/") : "CNMS";
        console.log("parentSelectedPath", parentSelectedPath);
        if (parentPath.length === 0) {
          setSelectedNode(null);
          setSelectedPath("CNMS");
        } else {
          setSelectedNode(parentNode.data);
          setSelectedPath(parentSelectedPath);
        }

        setIsPanelOpen(true);
        setIsRightPanelOpen(true);

        return parentPath;
      });
    });
    centerCircle
      .attr("fill", CNMS_COLOR)
      .attr("stroke", "#ffffff")
      .attr("stroke-width", 1.5)
      .transition()
      .duration(750)
      .attr("r", ringWidth);

    // ========================================================
    // Center Text
    // ========================================================

    let centerText = gRoot.select("text.center-text");

    if (centerText.empty()) {
      centerText = gRoot
        .append("text")
        .attr("class", "center-text")
        .attr("text-anchor", "middle")
        .attr("dy", ".35em")
        .style("fill", "#ffffff")
        .style("font-weight", "bold")
        .style("font-size", "13px")
        .style("pointer-events", "none")
        .style("font-family", "sans-serif");
    }
    centerText.text(zoomRoot.data.name);

    // ========================================================
    // Save positions
    // ========================================================

    prevNodesRef.current = nodes.map((node) => ({
      pathKey: node.pathKey,
      x0: node.x0,
      x1: node.x1,
      y0: node.y0,
      y1: node.y1,
    }));
  }, [filteredSitesForChart, drillPath, size]);

  // ==========================================================
  // Breadcrumb
  // ==========================================================

  const breadcrumbParts = ["CNMS", ...drillPath];

  // ==========================================================
  // Filter Button
  // ==========================================================

  const isFilterDisabled =
    filterType === "All"
      ? false
      : filterType === "Remote Group"
      ? !selectedSites.length
      : filterType === "Terminal"
      ? !selectedTerminals.length
      : false;

  const buttonBgColor =
    selectedSites.length > 0 || selectedTerminals.length > 0
      ? "#1a3d8f"
      : "#cccccc";

  useEffect(() => {
    if (isPictorialView || !containerRef.current) return;

    setSize({
      w: containerRef.current.clientWidth,
      h: containerRef.current.clientHeight,
    });
  }, [isPictorialView]);

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div style={styles.topRow}>
          <div style={styles.filterBar}>
            <MSelect
              label="Filter Type"
              options={filterTypeOptions}
              value={filterType}
              onChange={(selectedOption) => {
                const value =
                  typeof selectedOption === "object"
                    ? selectedOption.value
                    : selectedOption;

                handleFilterTypeChange({
                  target: {
                    value,
                  },
                });
              }}
              placeholder="Select Type"
              style={{
                width: 200,
              }}
            />

            {filterType === "Remote Group" && (
              <>
                <Box
                  style={{
                    width: 200,
                  }}
                >
                  <MAlarmSelect
                    label="Remote Group"
                    options={groupOptions}
                    value={selectedGroups}
                    onChange={setSelectedGroups}
                  />
                </Box>

                {selectedGroups.length > 0 && (
                  <Box
                    style={{
                      width: 200,
                    }}
                  >
                    <MAlarmSelect
                      label="Site ID"
                      options={siteOptions}
                      value={selectedSites}
                      onChange={setSelectedSites}
                    />
                  </Box>
                )}
              </>
            )}

            {filterType === "Terminal" && (
              <Box
                style={{
                  width: 200,
                }}
              >
                <MAlarmSelect
                  label="Terminal"
                  options={terminalOptions}
                  value={selectedTerminals}
                  onChange={setSelectedTerminals}
                />
              </Box>
            )}

            <MButtonPrimary
              variant="contained"
              onClick={handleApplyFilter}
              disabled={isFilterDisabled}
              style={{
                height: "38px",
                color: "white",
                backgroundColor: buttonBgColor,
                boxShadow: "none",
              }}
            >
              Filter
            </MButtonPrimary>
          </div>

          <div style={styles.toggleGroup}>
            <span
              style={{
                ...styles.toggleLabel,
                ...(isPictorialView ? {} : styles.toggleActiveLabel),
              }}
            >
              Chart View
            </span>

            <button
              type="button"
              // onClick={() => setIsPictorialView((prev) => !prev)}
              onClick={() => {
                setIsPictorialView((prev) => !prev);
                setIsRightPanelOpen(false);
                setIsPanelOpen(false);
              }}
              style={{
                ...styles.toggleSwitch,
                backgroundColor: isPictorialView ? "#1a7f9e" : "#e3e8ec",
                border: "none",
                cursor: "pointer",
              }}
              aria-label="Toggle Bird's Eye View"
            >
              <div
                style={{
                  ...styles.toggleCircle,
                  left: isPictorialView ? "18px" : "2px",
                }}
              />
            </button>

            <span
              style={{
                ...styles.toggleLabel,
                ...(isPictorialView ? styles.toggleActiveLabel : {}),
              }}
            >
              Pictorial View
            </span>
          </div>
        </div>

        {/* ====================================================
            FILTER BAR
        ==================================================== */}
      </div>

      {/* ====================================================
          MAIN CONTENT
      ==================================================== */}

      {/* {isPictorialView ? (
        <PictorialView
          sitesToDisplay={filteredSitesForChart}
          filterType={filterType}
        />
      ) : ( */}

      <div
        style={{
          ...styles.contentLayout,
          gap: "0",
          position: "relative",
        }}
      >
        <div
          // ref={isPictorialView ? undefined : undefined}
          ref={isPictorialView ? myRef : undefined}
          style={{
            ...styles.contentLayout,
            display: isPictorialView ? "none" : "flex",
            flex: 1,
            minWidth: 0,
            minHeight: 0,
            marginTop: 0,
          }}
        >
          {/* ==================================================
            BIRD EYE CHART
        ================================================== */}

          <div
            ref={containerRef}
            style={{
              ...styles.chartContainer,
              flex: isPanelOpen ? "1 1 0" : "1 1 100%",
              width: "auto",
              minWidth: 0,
            }}
          >
            {/* Breadcrumb */}
            {/* CHART OPTIONS */}

            {!isChartFullscreen && (
              <Tooltip title="Chart options" placement="left">
                <IconButton
                  onClick={handleChartMenuOpen}
                  aria-label="Bird Eye View chart options"
                  aria-controls={
                    isChartMenuOpen ? "chart-options-menu" : undefined
                  }
                  aria-haspopup="true"
                  aria-expanded={isChartMenuOpen ? "true" : undefined}
                  size="medium"
                  sx={{
                    position: "absolute",
                    top: 8,
                    right: 8,
                    zIndex: 20,
                    border: "1px solid #e2e8ee",
                    boxShadow: "0 2px 6px rgba(0,0,0,0.08)",
                    color: "#1a7f9e",
                    "&:hover": {
                      backgroundColor: "#eef6fa",
                    },
                  }}
                >
                  <MoreVertIcon />
                </IconButton>
              </Tooltip>
            )}
            <Menu
              id="chart-options-menu"
              anchorEl={chartMenuAnchor}
              open={isChartMenuOpen}
              onClose={handleChartMenuClose}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "right",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
              slotProps={{
                paper: {
                  sx: {
                    minWidth: 220,
                    mt: 0.5,
                    borderRadius: 2,
                    boxShadow: "0 6px 22px rgba(0,0,0,0.12)",
                  },
                },
              }}
            >
              <MenuItem onClick={() => handleChartAction("print")}>
                <PrintIcon fontSize="small" sx={{ mr: 1.5 }} />
                Print Chart
              </MenuItem>

              <MenuItem onClick={() => handleChartAction("png")}>
                <DownloadIcon fontSize="small" sx={{ mr: 1.5 }} />
                Download PNG Image
              </MenuItem>

              <MenuItem onClick={() => handleChartAction("jpeg")}>
                <DownloadIcon fontSize="small" sx={{ mr: 1.5 }} />
                Download JPEG Image
              </MenuItem>

              <MenuItem onClick={() => handleChartAction("svg")}>
                <DownloadIcon fontSize="small" sx={{ mr: 1.5 }} />
                Download SVG Vector Image
              </MenuItem>
            </Menu>
            <Box
              onClick={() => handleChartAction("fullscreen")}
              sx={{
                cursor: "pointer",
                display: "inline-flex",
                // --- ADD THESE TWO LINES TO CENTER ---
                alignItems: "center",
                justifyContent: "center",
                // -------------------------------------
                position: "absolute",
                top: !isChartFullscreen ? 62 : 10,
                right: 14,
                zIndex: 20,
                backgroundColor: (theme) =>
                  theme.palette.mode === "light" ? "#D7EEFF" : "#3e3b3b",
                borderRadius: "20%",
                width: "30px",
                height: "30px",
                padding: "0",
                margin: "0",
                color: (theme) => theme.palette.text.primary,
                "&:hover": {
                  backgroundColor: (theme) =>
                    theme.palette.mode === "light" ? "#BEE3F8" : "#3D3D3D",
                },
              }}
            >
              {isChartFullscreen ? (
                <FullscreenExitIcon fontSize="medium" />
              ) : (
                <FullscreenIcon fontSize="medium" />
              )}
            </Box>

            <div style={styles.breadcrumbBar}>
              {/* {breadcrumbParts.map((part, index) => (
                <React.Fragment key={index}>
                  {index > 0 && <span style={styles.crumbSep}>›</span>}

                  <span
                    style={{
                      ...styles.crumb,
                      ...(index === breadcrumbParts.length - 1
                        ? styles.crumbActive
                        : {}),
                    }}
                    onClick={() => {
                      const nextPath =
                        index === 0 ? [] : drillPath.slice(0, index);

                      setDrillPath(nextPath);

                      if (nextPath.length === 0) {
                        setSelectedPath("CNMS");
                        setSelectedNode(null);
                        return;
                      }

                      const hierarchyData = buildHierarchy(
                        filteredSitesForChart
                      );

                      const root = d3
                        .hierarchy(hierarchyData)
                        .sum((node) => (node.children?.length ? 0 : 1));

                      const node = getHierarchyNodeByPath(root, nextPath);

                      if (node) {
                        setSelectedPath(["CNMS", ...nextPath].join("/"));
                        setSelectedNode(node.data);
                      }
                    }}
                  >
                    {part}
                  </span>
                </React.Fragment>
              ))} */}
              {breadcrumbParts.map((part, index) => {
                // Use a unique key from the data if possible
                const uniqueKey = part || index;

                return (
                  <React.Fragment key={uniqueKey}>
                    {index > 0 && (
                      <span style={styles.crumbSep} aria-hidden="true">
                        ›
                      </span>
                    )}

                    <a
                      href="#!" // Use "#!" to prevent jumping to the top of the page
                      style={{
                        ...styles.crumb,
                        ...(index === breadcrumbParts.length - 1
                          ? styles.crumbActive
                          : {}),
                        // Ensure link styles don't break your design
                        textDecoration: "none",
                        color: "inherit",
                        display: "inline-block",
                      }}
                      onClick={(e) => {
                        e.preventDefault(); // VERY IMPORTANT: Prevents the browser from following the href

                        const nextPath =
                          index === 0 ? [] : drillPath.slice(0, index);
                        setDrillPath(nextPath);

                        if (nextPath.length === 0) {
                          setSelectedPath("CNMS");
                          setSelectedNode(null);
                          return;
                        }

                        const hierarchyData = buildHierarchy(
                          filteredSitesForChart
                        );
                        const root = d3
                          .hierarchy(hierarchyData)
                          .sum((node) => (node.children?.length ? 0 : 1));
                        const node = getHierarchyNodeByPath(root, nextPath);

                        if (node) {
                          setSelectedPath(["CNMS", ...nextPath].join("/"));
                          setSelectedNode(node.data);
                        }
                      }}
                    >
                      {part}
                    </a>
                  </React.Fragment>
                );
              })}
            </div>

            <svg
              ref={svgRef}
              style={{
                width: "100%",
                height: "100%",
                display: "block",
              }}
            />

            {/* Tooltip */}

            {tooltip && (
              <div
                style={{
                  ...styles.tooltip,
                  left: tooltip.x + 14,
                  top: tooltip.y + 14,
                }}
              >
                {tooltip.content}
              </div>
            )}
          </div>

          {/* ==================================================
            RIGHT SIDE PANEL
        ================================================== */}

          {isPanelOpen && (
            <div style={styles.panelWrapper}>
              {isRightPanelOpen && (
                <RightSidePanel
                  selectedPath={selectedPath}
                  selectedNode={selectedNode}
                  statusColors={statusColors}
                  allSites={filteredSitesForChart}
                  onClose={() => {
                    setIsRightPanelOpen(false);
                    setIsPanelOpen(false);
                  }}
                />
              )}
            </div>
          )}

          {/* ==================================================
    EXTERNAL LEGENDS — THIRD COLUMN
================================================== */}

          {isPanelOpen && (
            <div style={styles.externalLegendColumn}>
              <div style={styles.externalLegendDock}>
                {/* COMMUNICATION TYPE */}
                <div style={styles.legendCard}>
                  <div
                    style={{
                      ...styles.legendTitle,
                      color:
                        theme.palette.mode === "dark" ? "#ffffff" : "#0d4d63",
                    }}
                  >
                    Communication Type
                  </div>

                  <div style={styles.technicalLegend}>
                    {technicalLegends.map((item) => (
                      <div key={item.label} style={styles.techLegendItem}>
                        <span
                          style={{
                            ...styles.techLegendText,
                            color:
                              theme.palette.mode === "dark"
                                ? "#ffffff"
                                : "#1a2e3a",
                          }}
                        >
                          {item.label}
                        </span>

                        <img
                          src={item.icon}
                          alt={item.label}
                          style={styles.legendIcon}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <Divider sx={{ my: 0.5 }} />

                {/* STATUS */}
                <div style={styles.legendCard}>
                  <div
                    style={{
                      ...styles.legendTitle,
                      color:
                        theme.palette.mode === "dark" ? "#ffffff" : "#0d4d63",
                    }}
                  >
                    Status
                  </div>

                  <div style={styles.statusLegend}>
                    {Object.entries(statusColors).map(([key, color]) => (
                      <div key={key} style={styles.legendItem}>
                        <span
                          style={{
                            ...styles.dot,
                            backgroundColor: color,
                          }}
                        />

                        <span
                          style={{
                            ...styles.legendText,
                            color:
                              theme.palette.mode === "dark"
                                ? "#ffffff"
                                : "#1a2e3a",
                          }}
                        >
                          {key}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* PICTORIAL VIEW */}
        <div
          style={{
            display: isPictorialView ? "flex" : "none",
            flex: 1,
            width: "100%",
            minWidth: 0,
            minHeight: 0,
            overflow: "hidden",
          }}
        >
          <PictorialView
            sitesToDisplay={filteredSitesForChart}
            setSelectedPath={setSelectedPath}
          />
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    height: "100%",
    width: "100%",
    minHeight: 0,
    display: "flex",
    flexDirection: "column",
    padding: "16px 20px",
    boxSizing: "border-box",
    overflow: "hidden",
    // backgroundColor: "#fff",
    fontFamily: "Inter, system-ui, -apple-system, sans-serif",
    color: "#1a2e3a",
  },
  header: {
    display: "flex",
    flexDirection: "column",
    gap: "14px",
    marginBottom: "10px",
  },

  topRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },

  title: {
    margin: 0,
    fontSize: "1.05rem",
    fontWeight: 700,
    color: "#1a7f9e",
    letterSpacing: "0.2px",
  },

  toggleGroup: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    fontSize: "0.78rem",
    color: "#5b6b78",
  },

  toggleLabel: {
    color: "#5b6b78",
  },

  toggleSwitch: {
    width: "34px",
    height: "18px",
    backgroundColor: "#e3e8ec",
    borderRadius: "10px",
    position: "relative",
  },

  toggleCircle: {
    width: "14px",
    height: "14px",
    backgroundColor: "#fff",
    borderRadius: "50%",
    position: "absolute",
    top: "2px",
    left: "2px",
    boxShadow: "0 1px 2px rgba(0,0,0,0.15)",
  },

  filterBar: {
    display: "flex",
    gap: "20px",
    alignItems: "flex-end",
  },

  contentLayout: {
    display: "flex",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    marginTop: "6px",
    minHeight: 0,
    gap: "16px",
  },

  chartContainer: {
    position: "relative",
    border: "1px solid #e5eaee",
    borderRadius: "6px",
    // backgroundColor: "#ffffff",
    overflow: "hidden",
    minWidth: 0,
    transition: "flex 0.25s ease, width 0.25s ease",
  },

  panelWrapper: {
    // flex: "0 0 clamp(320px, 38%, 520px)",
    flex: "0 0 clamp(600px, 80%, 850px)",
    width: "auto",
    minWidth: 0,
    height: "100%",
    position: "relative",
    overflow: "hidden",
    border: "1px solid #e5eaee",
    borderRadius: "8px",
    // backgroundColor: "#ffffff",
  },

  breadcrumbBar: {
    position: "absolute",
    top: "10px",
    left: "50%",
    transform: "translateX(-50%)",
    display: "flex",
    alignItems: "center",
    gap: "6px",
    fontSize: "12px",
    zIndex: 5,
    backgroundColor: "rgba(255,255,255,0.9)",
    padding: "4px 12px",
    borderRadius: "16px",
    boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
    color: "#1a7f9e",
    fontWeight: 600,
  },

  crumb: {
    color: "#1a7f9e",
    cursor: "pointer",
    fontWeight: 600,
    padding: "2px 4px",
    borderRadius: 4,
  },

  crumbActive: {
    color: "#0d4d63",
    fontWeight: 700,
    cursor: "default",
  },

  crumbSep: {
    color: "#b8c3cb",
  },

  tooltip: {
    position: "absolute",
    pointerEvents: "none",
    backgroundColor: "rgba(13, 44, 56, 0.94)",
    color: "#fff",
    padding: "8px 10px",
    borderRadius: 6,
    fontSize: 12,
    boxShadow: "0 4px 14px rgba(0,0,0,0.18)",
    zIndex: 10,
    maxWidth: 220,
  },
  toggleActiveLabel: {
    color: "#1a7f9e",
    fontWeight: 700,
  },
  externalLegendColumn: {
    flex: "0 0 150px",
    width: "150px",
    minWidth: 0,
    minHeight: 0,
    height: "100%",
    position: "relative",
    alignSelf: "stretch",
  },

  externalLegendDock: {
    position: "absolute",
    right: 0,
    bottom: 0,
    width: "100%",
    maxHeight: "85%",
    boxSizing: "border-box",
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    padding: "12px",
    // backgroundColor: "rgba(255,255,255,0.98)",
    border: "1px solid #e2e8ee",
    borderRadius: "10px",
    // boxShadow: "0 4px 16px rgba(15,23,42,0.10)",
    backdropFilter: "blur(6px)",
  },

  legendCard: {
    display: "flex",
    flexDirection: "column",
    gap: "7px",
  },

  legendTitle: {
    fontSize: "11px",
    fontWeight: 700,
    // color: "#0d4d63",
    textTransform: "uppercase",
    letterSpacing: "0.4px",
    marginBottom: "2px",
  },

  technicalLegend: {
    display: "flex",
    flexDirection: "column",
    gap: "7px",
  },

  techLegendItem: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    minHeight: "22px",
  },

  techLegendText: {
    fontSize: "14px",
    fontWeight: 600,
    // color: "#1a2e3a",
  },

  legendIcon: {
    width: "24px",
    height: "24px",
    objectFit: "contain",
    flexShrink: 0,
  },

  statusLegend: {
    display: "flex",
    flexDirection: "column",
    gap: "7px",
  },

  legendItem: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    minHeight: "18px",
  },

  legendText: {
    fontSize: "13px",
    fontWeight: 600,
    // color: "#1a2e3a",
  },

  dot: {
    width: "12px",
    height: "12px",
    borderRadius: "50%",
    flexShrink: 0,
  },
};

export default BirdEyeView;
