import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Canvas, Group, Line, Rect, Text, FabricImage } from "fabric";
import { useSelector } from "react-redux";
import { CircularProgress, IconButton, Tooltip, useTheme } from "@mui/material";

import RestoreIcon from "@mui/icons-material/ZoomOutMap";
import E1OFC from "../../../assets/CNMS/birdEyeViewLegend/E1OFC.svg";
import NOTCONFIGURE from "../../../assets/CNMS/birdEyeViewLegend/NOTCONFIGURE.svg";
import radio from "../../../assets/CNMS/birdEyeViewLegend/radio.svg";
import VSat from "../../../assets/CNMS/birdEyeViewLegend/VSat.svg";

import rhombus from "../../../assets/CNMS/pictorialView/rhombus.svg";
import star from "../../../assets/CNMS/pictorialView/star.svg";
import doctor from "../../../assets/CNMS/pictorialView/mctr.svg";
import hexa from "../../../assets/CNMS/pictorialView/hexa.svg";
import triangle from "../../../assets/CNMS/pictorialView/triangle.svg";
import octa from "../../../assets/CNMS/pictorialView/octa.svg";
import square from "../../../assets/CNMS/pictorialView/square.svg";
import SettingsIcon from "@mui/icons-material/Settings";
import SettingsFormPictorial from "./SettingsFormPictorial";

const WIDTH_OF_CENTER = 350;
const CENTER_MIN_HEIGHT = 100;

const SITE_WIDTH = 42;
const SITE_HEIGHT = 48;
const SITE_GAP_X = 8;

const COMM_ICON_WIDTH = 28;
const COMM_ICON_HEIGHT = 18;

// Remote number position inside the icon
const TERMINAL_ICON_CENTER_Y = 24;

// Global site positioning (NOC remains fixed)
const SITES_OFFSET_X = -155; // + right, - left
const SITES_OFFSET_Y = -18; // + down, - up

// Terminal icon size
const TERMINAL_ICON_WIDTH = 38;
const TERMINAL_ICON_HEIGHT = 38;

const INDEPENDENT_GAP_TOP = 3; // Gap between NOC and top sites
const INDEPENDENT_GAP_BOTTOM = 8; // Gap between NOC and bottom sites
const INDEPENDENT_ROW_SPACING = 60;

// Communication icon spacing
const INDEPENDENT_COMM_GAP_Y = 21;

// Connected site-to-site spacing---
const CONNECTED_SITE_GAP_X = 24;

const CONNECTED_LOCAL_GAP_LEFT = 28;
const CONNECTED_LOCAL_GAP_RIGHT = 28;

const TERMINAL_ICON_MAP = {
  DMRR: rhombus,
  "MCT-MK-I": rhombus,
  "MCT-MK-III": triangle,
  "MCT-MK-II": hexa, // Replace with carh.svg when imported
  "HUB-NMS": octa, // Replace with mcttac.svg when imported
  "MCT-LSV": star,
  "MCT-R": doctor,
  "MCT-LSV-ALPHA": triangle, // Replace with lltr.svg when imported
  "MCT-TAC": octa,
  "MCT-CARH": hexa,
  "MCT-CARR": square,
};

// ==========================================================
// Connected LOCAL site communication icon positioning
// Applies ONLY to connected sites on the left/right of NOC
// ==========================================================

const CONNECTED_LEFT_ICON = {
  gapX: 0, // Horizontal gap from the site toward NOC
  gapY: 0, // Vertical adjustment: + down, - up

  // Additional manual positioning
  left: 6, // + right, - left
  right: 30, // + left, - right
  top: 0, // + down, - up
  bottom: 23, // + up, - down
  // Horizontal line controls for LEFT connected sites
  lineLeft: 0, // Move line left
  lineRight: 0, // Move line right
  lineTop: 0, // Move line up
  lineBottom: 8, // Move line down
  lineWidth: 36,
};

const CONNECTED_RIGHT_ICON = {
  gapX: 8,
  gapY: 0,
  //icon move
  left: 0,
  right: 8,
  top: 0,
  bottom: 23,
  // Horizontal line controls for RIGHT connected sites
  lineLeft: 0,
  lineRight: 0,
  lineTop: 0,
  lineBottom: 8,
  lineWidth: 36,
};

const getTerminalIconSource = (site) => {
  console.log("iconlogosite", site?.imTerminalType?.terminalTypeName);

  const terminalType = site?.imTerminalType?.terminalTypeName || "";

  return TERMINAL_ICON_MAP[terminalType.trim().toUpperCase()] || NOTCONFIGURE;
};

const CNMS_COLOR = "#ff0000";

const LINK_ASSETS = {
  1: VSat,
  2: radio,
  3: E1OFC,
  NULL: NOTCONFIGURE,
};

const LINK_NAME_MAP = {
  1: "V-SAT",
  2: "LOS Radio",
  3: "E1-OFC",
  NULL: "Not Configured",
};

const CNMS_SITE_ICON_MAP = {
  DMRR: rhombus,
  "MCT-MK-I": rhombus,
  "MCT-MK-II": hexa,
  "MCT-MK-III": triangle,
  "HUB-NMS": octa,
  "MCT-LSV": star,
  "MCT-R": doctor,
  "MCT-LSV-ALPHA": triangle,
  "MCT-TAC": octa,
  "MCT-CARH": hexa,
  "MCT-CARR": square,
};

const STATUS_COLORS = {
  Online: "#2e7d32",
  Offline: "#d32f2f",
  "RNMS Down": "#f3c106",
  "Maintenance Non-OPS": "#b8860b",
  "Maintenance R-OPS": "#34b8b8",
  // Fallback/Default colors
  UNKNOWN: "#94a3b8",
  MAINTENANCE_UNKNOWN: "#b8860b",
  DEFAULT_GREY: "#536a96",
};

const getHealthStatusKey = (site) => {
  const statusId = site?.healthStatus?.id;

  switch (statusId) {
    case 0:
      return "Offline";
    case 1:
      return "Online";
    case 2:
      return "RNMS Down";
    case 3: {
      // <--- Added opening brace for block scope
      const mType = Number(site?.maintenanceType);
      if (mType === 1) {
        return "Maintenance Non-OPS";
      }
      if (mType === 2) {
        return "Maintenance R-OPS";
      }
      return "Maintenance Unknown";
    } // <--- Added closing brace
    default: {
      // <--- Added opening brace for default block scope
      if (site?.isMaintainance) {
        const mType = Number(site?.maintenanceType);
        if (mType === 1) return "Maintenance Non-OPS";
        if (mType === 2) return "Maintenance R-OPS";
        return "Maintenance Unknown";
      }
      return "Unknown";
    } // <--- Added closing brace
  }
};

/**
 * Step 2: The main function used in your component to get the color.
 */
const getSiteHealthColor = (site) => {
  if (!site) return STATUS_COLORS.DEFAULT_GREY;

  const statusKey = getHealthStatusKey(site);

  // Return logic:
  // 1. Try to find color by the standardized key (e.g., "Online")
  // 2. Try to find color by uppercase version (e.g., "ONLINE")
  // 3. Handle specific Maintenance Unknown fallback
  // 4. Final fallback to default grey
  return (
    STATUS_COLORS[statusKey] ||
    STATUS_COLORS[statusKey.toUpperCase()] ||
    (statusKey === "Maintenance Unknown"
      ? STATUS_COLORS.MAINTENANCE_UNKNOWN
      : STATUS_COLORS.UNKNOWN) ||
    STATUS_COLORS.DEFAULT_GREY
  );
};

const getTerminalName = (site) =>
  site?.imTerminalType?.terminalTypeName || "Unknown";

const getCommunicationType = (site) => {
  const value = site?.activeModeOfCommunication;

  if (value === null || value === undefined || value === "") {
    return null;
  }

  const mode = Number(value);

  return [1, 2, 3].includes(mode) ? mode : null;
};

const SITE_STATUS_LEGEND = [
  { label: "Online", color: "#248000" },
  { label: "Offline", color: "#f60003" },
  { label: "RNMS Down", color: "#f3c106" },
  { label: "Maintenance Non-OPS", color: "darkgoldenrod" },
  { label: "Maintenance R-OPS", color: "#80C7DF" },
];

const SiteStatusLegend = ({ theme }) => (
  <div style={styles.statusLegend}>
    <div style={styles.legendTitle}>Site Status</div>

    {SITE_STATUS_LEGEND.map(({ label, color }) => (
      <div key={label} style={styles.statusLegendRow}>
        <span
          style={{
            ...styles.statusDot,
            backgroundColor: color,
          }}
        />
        <span
          style={{
            color:
              theme.palette.mode === "dark" ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
          }}
        >
          {label}
        </span>
      </div>
    ))}
  </div>
);

const centerXForDrawing = (center) => center.x + center.width / 2;

const getCommunicationIconColor = (site, type) => {
  // Connected LOCAL sites and their related sites stay green for now.
  if (type === "CONNECTED") {
    return "#248000";
  }

  // Independent LOCAL sites:
  // Red only when health status indicates DOWN.
  const rawStatus = site?.healthStatus?.value;

  const status = String(rawStatus ?? "")
    .trim()
    .toUpperCase();

  const isDown = ["DOWN"].includes(status);

  return isDown ? "#f60003" : "#248000";
};

const PictorialView = ({ sitesToDisplay = [], setSelectedPath }) => {
  const canvasElementRef = useRef(null);
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  const objectMapRef = useRef(new Map());
  const resizeObserverRef = useRef(null);

  const [loading, setLoading] = useState(false);
  // const [selectedNode, setSelectedNode] = useState(null);
  const [tooltip, setTooltip] = useState(null);
  const [canvasSize, setCanvasSize] = useState({
    width: 0,
    height: 0,
  });

  const theme = useTheme();

  const [isPanelOpen, setIsPanelOpen] = useState(false);
  // const [isRightPanelOpen, setIsRightPanelOpen] = useState(false);

  const { topologyToolTipOptions } = useSelector(
    (state) => state.toolTipOptionsSlice
  );

  console.log("pictopologyToolTipOptions", topologyToolTipOptions);
  console.log("sitesToDisplay", sitesToDisplay);

  const [showSettingsModal, setShowSettingsModal] = useState(null);

  const terminalLegendItems = useMemo(() => {
    const terminalTypes = [
      ...new Set(
        sitesToDisplay
          .map((site) => site?.imTerminalType?.terminalTypeName?.trim())
          .filter(Boolean)
      ),
    ];

    return terminalTypes.sort((a, b) => a.localeCompare(b));
  }, [sitesToDisplay]);

  useEffect(() => {
    if (!containerRef.current) {
      return;
    }

    const updateSize = () => {
      if (!containerRef.current) {
        return;
      }

      setCanvasSize({
        width: containerRef.current.clientWidth,
        height: containerRef.current.clientHeight,
      });
    };

    updateSize();

    resizeObserverRef.current = new ResizeObserver(updateSize);

    resizeObserverRef.current.observe(containerRef.current);

    return () => {
      resizeObserverRef.current?.disconnect();
    };
  }, []);

  useEffect(() => {
    const timer = requestAnimationFrame(() => {
      if (!containerRef.current) {
        return;
      }

      setCanvasSize({
        width: containerRef.current.clientWidth,
        height: containerRef.current.clientHeight,
      });
    });

    return () => cancelAnimationFrame(timer);
  }, [isPanelOpen]);

  // ==========================================================
  // Initialize Fabric
  // ==========================================================

  useEffect(() => {
    if (!canvasElementRef.current) {
      return;
    }

    const canvas = new Canvas(canvasElementRef.current, {
      selection: false,
      preserveObjectStacking: true,
      stopContextMenu: true,
      fireRightClick: true,
    });

    canvasRef.current = canvas;

    // --------------------------------------------------------
    // Hover
    // --------------------------------------------------------
    canvas.on("mouse:over", (event) => {
      const target = event.target;

      if (!target?.siteData) return;

      setTooltip({
        x: event.e.offsetX,
        y: event.e.offsetY,
        site: target.siteData,
      });
    });

    canvas.on("mouse:out", (event) => {
      if (event.target?.siteData) {
        setTooltip(null);
      }
    });

    // --------------------------------------------------------
    // Click
    // --------------------------------------------------------

    canvas.on("mouse:down", (event) => {
      const target = event.target;

      if (target?.siteData) {
        const site = target.siteData;

        // setSelectedNode(site);

        setSelectedPath?.(`CNMS/${site.siteId}`);

        setIsPanelOpen(true);
        // setIsRightPanelOpen(true);
      }
    });

    // --------------------------------------------------------
    // Zoom
    // --------------------------------------------------------

    canvas.on("mouse:wheel", (event) => {
      const delta = event.e.deltaY;

      let zoom = canvas.getZoom();

      zoom *= 0.999 ** delta;

      zoom = Math.min(Math.max(zoom, 0.1), 4);

      canvas.zoomToPoint(
        {
          x: event.e.offsetX,
          y: event.e.offsetY,
        },
        zoom
      );

      event.e.preventDefault();
      event.e.stopPropagation();
    });

    // --------------------------------------------------------
    // Pan
    // --------------------------------------------------------

    canvas.on("mouse:down", (event) => {
      if (event.target) {
        return;
      }

      canvas.isDragging = true;

      canvas.lastPosX = event.e.clientX;
      canvas.lastPosY = event.e.clientY;
    });

    canvas.on("mouse:move", (event) => {
      if (!canvas.isDragging) {
        return;
      }

      const currentX = event.e.clientX;
      const currentY = event.e.clientY;

      const deltaX = currentX - canvas.lastPosX;
      const deltaY = currentY - canvas.lastPosY;

      const viewportTransform = canvas.viewportTransform;

      viewportTransform[4] += deltaX;
      viewportTransform[5] += deltaY;

      canvas.requestRenderAll();

      canvas.lastPosX = currentX;
      canvas.lastPosY = currentY;
    });

    canvas.on("mouse:up", () => {
      canvas.isDragging = false;

      canvas.setViewportTransform(canvas.viewportTransform);
    });

    return () => {
      canvas.dispose();
      canvasRef.current = null;
    };
  }, [setSelectedPath]);

  // ==========================================================
  // SVG loader
  // ==========================================================

  const loadSvg = useCallback(async (svgSource, tintColor = null) => {
    if (!svgSource) return null;

    try {
      const response = await fetch(svgSource);
      if (!response.ok) {
        throw new Error(`Failed to load SVG: ${response.status}`);
      }

      let svgText = await response.text();

      if (tintColor) {
        // 1. Replace explicit fill attributes.
        // Preserve fill="none" and URL-based gradients.
        svgText = svgText.replace(
          /(\bfill\s*=\s*["'])(?!none\s*["']|url\()[^"']*(["'])/gi,
          `$1${tintColor}$2`
        );

        // 2. Replace explicit stroke attributes.
        svgText = svgText.replace(
          /(\bstroke\s*=\s*["'])(?!none\s*["']|url\()[^"']*(["'])/gi,
          `$1${tintColor}$2`
        );

        // 3. Handle inline CSS and SVG style blocks.
        // This also handles class-based CSS rules.
        svgText = svgText.replace(
          /(\bfill\s*:\s*)(?!none\b|url\()[^;}]+/gi,
          `$1${tintColor}`
        );

        svgText = svgText.replace(
          /(\bstroke\s*:\s*)(?!none\b|url\()[^;}]+/gi,
          `$1${tintColor}`
        );

        // 4. Handle SVGs that use currentColor.
        svgText = svgText.replace(/currentColor/gi, tintColor);
      }

      return await FabricImage.fromURL(
        `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgText)}`
      );
    } catch (error) {
      console.error("Unable to load SVG:", error);
      return null;
    }
  }, []);

  // ==========================================================
  // Add terminal object
  // ==========================================================

  const addSiteObject = useCallback(
    async (site, x, y, scale = 1) => {
      const canvas = canvasRef.current;
      if (!canvas || !site) return null;

      const color = getSiteHealthColor(site);
      const icon = await loadSvg(getTerminalIconSource(site), color);

      if (!icon) return null;

      const terminalText =
        site.remoteNumber != null ? String(site.remoteNumber) : "";

      // Terminal icon: centered inside the site object.
      icon.set({
        left: (SITE_WIDTH * scale) / 2,
        top: TERMINAL_ICON_CENTER_Y * scale,
        originX: "center",
        originY: "center",
        scaleX: (TERMINAL_ICON_WIDTH * scale) / (icon.width || 25),
        scaleY: (TERMINAL_ICON_HEIGHT * scale) / (icon.height || 25),
        selectable: false,
        evented: false,
      });

      // Remote number: centered over the terminal icon.
      const label = new Text(terminalText, {
        left: (SITE_WIDTH * scale) / 2,
        top: 24 * scale,
        fontSize: 11 * scale,
        fontFamily: "Inter, sans-serif",
        fontWeight: "800",
        fill: "#ffffff",
        stroke: "#172b34",
        strokeWidth: 0.35 * scale,
        paintFirst: "stroke",
        originX: "center",
        originY: "center",
        selectable: false,
        evented: false,
      });

      // The label comes after the icon so it renders on top.
      const group = new Group([icon, label], {
        left: x,
        top: y,
        selectable: false,
        evented: true,
        subTargetCheck: false,
      });

      group.siteData = site;
      group.siteId = site.siteId;
      group.name = site.siteId;

      canvas.add(group);
      objectMapRef.current.set(site.siteId, group);

      return group;
    },
    [loadSvg]
  );

  const addConnectedCommunicationIcon = useCallback(
    async (site, x, y, side) => {
      const canvas = canvasRef.current;
      if (!canvas || !site) return null;

      const mode = getCommunicationType(site);
      // const color = getCommunicationIconColor(site, "CONNECTED");

      // const icon = await loadSvg(LINK_ASSETS[mode] ?? NOTCONFIGURE, color);

      const color =
        mode === "NULL" ? null : getCommunicationIconColor(site, "CONNECTED");

      const icon = await loadSvg(LINK_ASSETS[mode] ?? NOTCONFIGURE, color);

      if (!icon) return null;

      // Use separate settings for the left and right sides of NOC.
      const config =
        side === "left" ? CONNECTED_LEFT_ICON : CONNECTED_RIGHT_ICON;

      // Calculate the icon's horizontal center.
      // Left-side site: icon sits to the right of the site.
      // Right-side site: icon sits to the left of the site.
      const baseX =
        side === "left"
          ? x + SITE_WIDTH + config.gapX + COMM_ICON_WIDTH / 2
          : x - config.gapX - COMM_ICON_WIDTH / 2;

      // Calculate the icon's vertical center.
      const baseY = y + SITE_HEIGHT / 2;

      // Apply manual adjustments.
      const iconX = baseX + config.left - config.right;

      const iconY = baseY + config.gapY + config.top - config.bottom;

      icon.set({
        left: iconX,
        top: iconY,
        originX: "center",
        originY: "center",
        scaleX: COMM_ICON_WIDTH / (icon.width || COMM_ICON_WIDTH),
        scaleY: COMM_ICON_HEIGHT / (icon.height || COMM_ICON_HEIGHT),
        selectable: false,
        evented: false,
      });

      // Short horizontal line across the upper edge of the
      // communication icon. This function is only used for
      // connected sites, so independent sites remain unaffected.
      // Horizontal line positioning
      const lineWidth = config.lineWidth ?? 16;

      // Horizontal movement: positive left/right settings move
      // the line in their named direction.
      const lineOffsetX = (config.lineRight ?? 0) - (config.lineLeft ?? 0);

      // Vertical movement: positive bottom moves down,
      // positive top moves up.
      const lineOffsetY = (config.lineBottom ?? 0) - (config.lineTop ?? 0);

      const lineY = iconY - COMM_ICON_HEIGHT / 2 + 1 + lineOffsetY;

      const communicationLine = new Line(
        [
          iconX + lineOffsetX - lineWidth / 2,
          lineY,
          iconX + lineOffsetX + lineWidth / 2,
          lineY,
        ],
        {
          stroke: "#008000",
          strokeWidth: 3.0,
          selectable: false,
          evented: false,
          objectCaching: false,
        }
      );

      // Line behind the icon; icon remains visible on top.
      canvas.add(communicationLine);
      canvas.add(icon);

      return icon;
    },
    [loadSvg]
  );

  const addCommunicationMarker = useCallback(
    async (site, x, y) => {
      const canvas = canvasRef.current;
      if (!canvas || !site) return null;

      const mode = getCommunicationType(site);

      // const color = getCommunicationIconColor(site, "INDEPENDENT");

      // const icon = await loadSvg(LINK_ASSETS[mode] ?? NOTCONFIGURE, color);

      const color =
        mode === "NULL" ? null : getCommunicationIconColor(site, "INDEPENDENT");

      const icon = await loadSvg(LINK_ASSETS[mode] ?? NOTCONFIGURE, color);
      if (!icon) return null;

      // Place the icon directly above the *visible* terminal icon,
      // not above the group's (empty) bounding-box top.
      const iconTop =
        y +
        TERMINAL_ICON_CENTER_Y -
        TERMINAL_ICON_HEIGHT / 2 -
        COMM_ICON_HEIGHT / 2 -
        INDEPENDENT_COMM_GAP_Y;

      icon.set({
        left: x + SITE_WIDTH / 75, // centered over the site
        top: iconTop - 3, // ✅ tight to the top of the site icon
        originX: "center",
        originY: "center",
        scaleX: COMM_ICON_WIDTH / (icon.width || COMM_ICON_WIDTH),
        scaleY: COMM_ICON_HEIGHT / (icon.height || COMM_ICON_HEIGHT),
        selectable: false,
        evented: false,
      });

      canvas.add(icon);
      return icon;
    },
    [loadSvg]
  );

  const calculateLayout = useCallback(
    (siteList) => {
      const width = canvasSize.width || 1000;
      const height = canvasSize.height || 600;

      const centerX = width / 2;
      const centerY = height / 2;

      const localSites = siteList.filter(
        (site) => site?.imTerminalMode?.name === "LOCAL"
      );

      const localIndependent = [];
      const localWithRelations = [];
      // const remotes = [];
      // const repeater1 = [];
      // const repeater2 = [];

      localSites.forEach((site) => {
        if (!site.remoteSite && !site.repeator1Site && !site.repeator2Site) {
          localIndependent.push(site);
        } else {
          localWithRelations.push(site);
        }
      });

      // siteList.forEach((site) => {
      //   if (site?.imTerminalMode?.name === "REMOTE") {
      //     remotes.push(site);
      //   }

      //   if (site?.imTerminalMode?.name === "REPEATOR1") {
      //     repeater1.push(site);
      //   }

      //   if (site?.imTerminalMode?.name === "REPEATOR2") {
      //     repeater2.push(site);
      //   }
      // });

      // ------------------------------------------------------
      // NOC size: provide a separate lane for each connected
      // local site, with paired lanes on the left and right.
      // ------------------------------------------------------

      const connectedRows = Math.max(
        1,
        Math.ceil(localWithRelations.length / 2)
      );

      const centerHeight = Math.max(
        CENTER_MIN_HEIGHT,
        connectedRows * SITE_HEIGHT
      );

      const center = {
        x: centerX - WIDTH_OF_CENTER / 2,
        y: centerY - centerHeight / 2,
        width: WIDTH_OF_CENTER,
        height: centerHeight,
      };

      const nodes = [];

      // ------------------------------------------------------
      // Connected local sites: horizontal chains on both sides
      // ------------------------------------------------------

      localWithRelations.forEach((localSite, index) => {
        const side = index % 2 === 0 ? "left" : "right";
        const row = Math.floor(index / 2);

        const connectedRows = Math.max(
          1,
          Math.ceil(localWithRelations.length / 2)
        );

        const laneY = center.y + ((row + 0.5) * center.height) / connectedRows;

        const localX =
          side === "left"
            ? center.x - SITE_WIDTH - CONNECTED_LOCAL_GAP_LEFT
            : center.x + center.width + CONNECTED_LOCAL_GAP_RIGHT;

        const localY = laneY - SITE_HEIGHT / 2;

        nodes.push({
          site: localSite,
          x: localX,
          y: localY,
          type: "LOCAL",
          side,
        });

        const relatedSites = [
          { site: localSite.repeator1Site, type: "R1" },
          { site: localSite.repeator2Site, type: "R2" },
          { site: localSite.remoteSite, type: "REMOTE" },
        ].filter(({ site }) => site);

        relatedSites.forEach(({ site, type }, relationIndex) => {
          const direction = side === "left" ? -1 : 1;

          nodes.push({
            site,
            x:
              localX +
              direction *
                (relationIndex + 1) *
                (SITE_WIDTH + CONNECTED_SITE_GAP_X),
            y: localY,
            type,
            parent: localSite,
            side,
          });
        });
      });

      // ------------------------------------------------------
      // Independent LOCAL sites: split equally above/below NOC
      // ------------------------------------------------------

      const siteSlotWidth = SITE_WIDTH + SITE_GAP_X;

      const independentColumns = Math.max(
        1,
        Math.floor((center.width + SITE_GAP_X) / siteSlotWidth)
      );

      // Split by number of sites, not by number of rows.
      // If the count is odd, the top receives one extra site.
      const topCount = Math.ceil(localIndependent.length / 2);

      const topSites = localIndependent.slice(0, topCount);
      const bottomSites = localIndependent.slice(topCount);

      const rowSpacing = INDEPENDENT_ROW_SPACING;

      const addIndependentSites = (sites, position) => {
        sites.forEach((site, index) => {
          const row = Math.floor(index / independentColumns);
          const column = index % independentColumns;

          const sitesInThisRow = Math.min(
            independentColumns,
            sites.length - row * independentColumns
          );

          const rowWidth =
            sitesInThisRow * SITE_WIDTH + (sitesInThisRow - 1) * SITE_GAP_X;

          // Center every row horizontally relative to the NOC.
          const rowStartX = center.x + (center.width - rowWidth) / 2;

          const x = rowStartX + column * siteSlotWidth;

          // Row 0 is closest to the NOC on either side.
          const y =
            position === "top"
              ? center.y - SITE_HEIGHT - INDEPENDENT_GAP_TOP - row * rowSpacing
              : center.y +
                center.height +
                INDEPENDENT_GAP_BOTTOM +
                row * rowSpacing;

          nodes.push({
            site,
            x,
            y,
            type: "INDEPENDENT",
            side: position,
          });
        });
      };

      addIndependentSites(topSites, "top");
      addIndependentSites(bottomSites, "bottom");

      // Move every site while keeping the NOC center fixed.
      const adjustedNodes = nodes.map((node) => ({
        ...node,
        x: node.x + SITES_OFFSET_X,
        y: node.y + SITES_OFFSET_Y,
      }));

      return {
        center,
        nodes: adjustedNodes,
      };
    },
    [canvasSize]
  );

  const fitCanvas = useCallback(() => {
    const canvas = canvasRef.current;

    if (!canvas?.width || !canvas?.height) return;

    const objects = canvas.getObjects();

    if (!objects.length) {
      canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
      canvas.requestRenderAll();
      return;
    }

    const bounds = objects.reduce(
      (acc, object) => {
        const rect = object.getBoundingRect();

        acc.left = Math.min(acc.left, rect.left);
        acc.top = Math.min(acc.top, rect.top);
        acc.right = Math.max(acc.right, rect.left + rect.width);
        acc.bottom = Math.max(acc.bottom, rect.top + rect.height);

        return acc;
      },
      {
        left: Infinity,
        top: Infinity,
        right: -Infinity,
        bottom: -Infinity,
      }
    );

    const contentWidth = bounds.right - bounds.left;
    const contentHeight = bounds.bottom - bounds.top;

    if (contentWidth <= 0 || contentHeight <= 0) return;

    const padding = 48;

    const scaleX = (canvas.width - padding * 2) / contentWidth;
    const scaleY = (canvas.height - padding * 2) / contentHeight;

    const zoom = Math.min(scaleX, scaleY, 1, 4);

    const offsetX =
      (canvas.width - contentWidth * zoom) / 2 - bounds.left * zoom;

    const offsetY =
      (canvas.height - contentHeight * zoom) / 2 - bounds.top * zoom;

    canvas.setViewportTransform([zoom, 0, 0, zoom, offsetX, offsetY]);

    canvas.requestRenderAll();
  }, []);

  // ==========================================================
  // Draw pictorial view
  // ==========================================================

  useEffect(() => {
    const canvas = canvasRef.current;

    if (!canvas || !canvasSize.width) {
      return;
    }

    let cancelled = false;

    const draw = async () => {
      setLoading(true);

      try {
        canvas.clear();

        objectMapRef.current.clear();
        const { center, nodes } = calculateLayout(sitesToDisplay);

        // ------------------------------------------------------
        // CNMS center
        // ------------------------------------------------------

        const centerRect = new Rect({
          left: center.x,
          top: center.y,
          width: center.width,
          height: center.height,
          fill: CNMS_COLOR,
          rx: 8,
          ry: 8,
          selectable: false,
          evented: false,
        });

        const centerText = new Text("NOC", {
          left: center.x + center.width / 65,
          top: center.y + center.height / 28,
          fontSize: 22,
          fontFamily: "Inter, sans-serif",
          fontWeight: "700",
          fill: "#ffffff",
          originX: "center",
          originY: "center",
          selectable: false,
          evented: false,
        });

        const centerGroup = new Group([centerRect, centerText], {
          selectable: false,
          evented: false,
        });

        centerGroup.name = "NOC";

        canvas.add(centerGroup);

        // ------------------------------------------------------
        // Draw terminal icons and remote numbers.
        // ------------------------------------------------------

        for (const node of nodes) {
          if (cancelled) return;

          await addSiteObject(node.site, node.x, node.y, 1);
        }

        canvas.renderAll();

        requestAnimationFrame(() => {
          if (!cancelled) {
            fitCanvas();
          }
        });

        for (const node of nodes) {
          if (cancelled) return;

          if (node.type === "INDEPENDENT") {
            // Independent local: icon at the TOP.
            await addCommunicationMarker(node.site, node.x, node.y);
          } else if (node.type === "LOCAL" || node.parent) {
            // Then place the communication icon on top of the line.
            await addConnectedCommunicationIcon(
              node.site,
              node.x,
              node.y,
              node.side
            );
          }
          //  else if (node.parent) {
          //   // Remote/repeater: retain the existing above-site placement.
          //   await addCommunicationMarker(node.site, node.x, node.y);
          // }
        }

        canvas.renderAll();

        requestAnimationFrame(() => {
          if (!cancelled) {
            fitCanvas();
          }
        });
      } catch (error) {
        console.error("Failed to draw pictorial view:", error);
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    draw();

    return () => {
      cancelled = true;
    };
  }, [
    sitesToDisplay,
    canvasSize,
    calculateLayout,
    addSiteObject,
    addCommunicationMarker,
    fitCanvas,
    addConnectedCommunicationIcon,
  ]);

  useEffect(() => {
    const canvas = canvasRef.current;

    if (!canvas) {
      return;
    }

    canvas.setDimensions({
      width: canvasSize.width,
      height: canvasSize.height,
    });

    canvas.renderAll();
  }, [canvasSize]);

  /**
   * Converts raw health status into a human-readable status name
   */
  const getFriendlyStatusName = (site) => {
    if (!site) return "N/A";

    const rawStatus = site?.healthStatus?.value || site?.healthStatus || "";
    const statusUpper = String(rawStatus).trim().toUpperCase();

    // 1. Handle Maintenance Logic
    if (site.isMaintainance) {
      if (Number(site.maintenanceType) === 1) {
        return "Maintenance Non-OPS";
      }
      if (Number(site.maintenanceType) === 2) {
        return "Maintenance R-OPS";
      }
      return "Maintenance";
    }

    // 2. Map standard acronyms/codes to friendly names
    const statusMapping = {
      UP: "Online",
      ONLINE: "Online",
      DOWN: "Offline",
      OFFLINE: "Offline",
      "RNMS DOWN": "RNMS Down",
      "OPERATIONAL DOWN": "RNMS Down",
    };

    return statusMapping[statusUpper] || rawStatus || "N/A";
  };

  // ==========================================================
  // Tooltip
  // ==========================================================

  const renderTooltip = () => {
    if (!tooltip?.site) {
      return null;
    }

    const site = tooltip.site;
    const options = topologyToolTipOptions || {};

    const getDisplayValue = (value) => {
      if (value === null || value === undefined || value === "") {
        return "N/A";
      }

      if (typeof value === "object") {
        return (
          value.value ??
          value.name ??
          value.terminalTypeName ??
          value.subTypeName ??
          JSON.stringify(value)
        );
      }

      return String(value);
    };

    const activeLink =
      site.activeModeOfCommunication ??
      site.activeCommunicationMode ??
      site.communicationMode;

    const vehicleRuntime =
      site.sysUpTime ?? site.vehicleUptimeLog ?? site.siteUptimeLog;

    const tooltipFields = [
      {
        key: "remoteType",
        label: "Remote Type",
        value:
          site.imTerminalType?.terminalTypeName ??
          site.imTerminalType?.subTypeName,
      },
      {
        key: "vehNumber",
        label: "Veh. Number",
        value: site.remoteNumber,
      },
      {
        key: "longitude",
        label: "Longitude",
        value: site.longitude,
      },
      {
        key: "latitude",
        label: "Latitude",
        value: site.latitude,
      },
      {
        key: "status",
        label: "Status",
        value: getFriendlyStatusName(site),
      },
      {
        key: "activeLink",
        label: "Active Link",
        value: activeLink ? LINK_NAME_MAP[getCommunicationType(site)] : null,
      },
      {
        key: "remoteId",
        label: "Remote Id",
        value: site.siteId,
      },
      {
        key: "maintainance",
        label: "Maintainance",
        value:
          site.isMaintainance === true
            ? "Yes"
            : site.isMaintainance === false
            ? "No"
            : null,
      },
      {
        key: "siteName",
        label: "Site Name",
        value: site.siteName,
      },
      {
        key: "vehRunTime",
        label: "Veh. Run Time",
        value: vehicleRuntime,
      },
    ];

    const visibleFields = tooltipFields.filter(
      ({ key }) => options[key] === true
    );

    if (visibleFields.length === 0) {
      return null;
    }

    return (
      <div
        style={{
          ...styles.tooltip,
          left: tooltip.x + 14,
          top: tooltip.y + 14,
        }}
      >
        {visibleFields.map(({ key, label, value }) => (
          <div
            key={key}
            style={{
              ...styles.tooltipLine,
              overflowWrap: "anywhere",
            }}
          >
            <strong>{label}:</strong> {getDisplayValue(value)}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={styles.container}>
      <div
        style={{
          ...styles.contentLayout,
          gap: isPanelOpen ? "16px" : "0",
        }}
      >
        <div
          ref={containerRef}
          style={{
            ...styles.chartContainer,
            flex: isPanelOpen ? "1 1 40%" : "1 1 100%",
          }}
        >
          {loading && (
            <div style={styles.loading}>
              <CircularProgress size={28} />
            </div>
          )}

          <div style={styles.toolbar}>
            <Tooltip title="Fit to Zoom">
              <IconButton size="small" onClick={fitCanvas} color="primary">
                <RestoreIcon fontSize="small" />
              </IconButton>
            </Tooltip>

            <Tooltip title="Configuration Parameters">
              <IconButton
                size="small"
                color="primary"
                onClick={() => setShowSettingsModal((previous) => !previous)}
              >
                <SettingsIcon fontSize="small" />
              </IconButton>
            </Tooltip>

            {showSettingsModal && (
              <div style={styles.settingsPanel}>
                <SettingsFormPictorial
                  setShowSettingsModal={setShowSettingsModal}
                />
              </div>
            )}
          </div>

          <canvas ref={canvasElementRef} />

          {renderTooltip()}
          <SiteStatusLegend theme={theme} />
          {/* ==================================================
              LEGEND
          ================================================== */}

          <div style={styles.legend}>
            <div style={styles.legendTitle}>Legend</div>

            {/* Terminal types: name on left, icon on right */}
            <div style={styles.terminalLegendSection}>
              {/* <div style={styles.terminalLegendHeading}>Terminal Types</div> */}

              {terminalLegendItems.length === 0 ? (
                <div style={styles.terminalLegendEmpty}>
                  No terminals available
                </div>
              ) : (
                terminalLegendItems.map((terminalName) => {
                  const iconSrc =
                    CNMS_SITE_ICON_MAP[terminalName.trim().toUpperCase()] ||
                    NOTCONFIGURE;

                  return (
                    <div
                      key={terminalName}
                      style={{
                        ...styles.terminalLegendRow,
                        color:
                          theme.palette.mode === "dark"
                            ? "#ffffff"
                            : "rgba(0, 0, 0, 0.88)",
                      }}
                    >
                      <span style={styles.terminalLegendName}>
                        {terminalName}
                      </span>

                      <img
                        src={iconSrc}
                        alt={terminalName}
                        width={22}
                        height={22}
                        style={{
                          objectFit: "contain",
                          flexShrink: 0,
                        }}
                      />
                    </div>
                  );
                })
              )}
            </div>

            <div style={styles.legendDivider} />
            <div style={{
                ...styles.legendRow,
                color:
                  theme.palette.mode === "dark"
                    ? "#ffffff"
                    : "rgba(0, 0, 0, 0.88)",
              }}>
              <span>Radio</span>
              <img src={radio} width="30" height="18" alt="Radio" />
            </div>

            <div style={{
                ...styles.legendRow,
                color:
                  theme.palette.mode === "dark"
                    ? "#ffffff"
                    : "rgba(0, 0, 0, 0.88)",
              }}>
              <span>V-SAT</span>
              <img src={VSat} width="30" height="22" alt="V-SAT" />
            </div>

            <div style={{
                ...styles.legendRow,
                color:
                  theme.palette.mode === "dark"
                    ? "#ffffff"
                    : "rgba(0, 0, 0, 0.88)",
              }}>
              <span>E1-OFC</span>
              <img src={E1OFC} width="30" height="22" alt="E1-OFC" />
            </div>

            <div
              style={{
                ...styles.legendRow,
                color:
                  theme.palette.mode === "dark"
                    ? "#ffffff"
                    : "rgba(0, 0, 0, 0.88)",
              }}
            >
              <span>Not Configured</span>
              <img
                src={NOTCONFIGURE}
                width="25"
                height="20"
                alt="Not Configured"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// Styles
// ============================================================

const styles = {
  container: {
    height: "100%",
    width: "100%",
    minHeight: 0,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    padding: 0,
    boxSizing: "border-box",
    overflow: "hidden",
    // backgroundColor: "#fff",
    fontFamily: "Inter, system-ui, -apple-system, sans-serif",
    color: "#1a2e3a",
  },

  header: {
    display: "flex",
    flexDirection: "column",
    gap: "14px",
    marginBottom: "10px",
  },

  topRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottom: "1px solid #e5eaee",
    paddingBottom: "10px",
  },

  title: {
    margin: 0,
    fontSize: "1.05rem",
    fontWeight: 700,
    color: "#1a7f9e",
    letterSpacing: "0.2px",
  },

  toggleGroup: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    fontSize: "0.78rem",
  },

  toggleLabel: {
    color: "#5b6b78",
  },

  toggleSwitch: {
    width: "34px",
    height: "18px",
    backgroundColor: "#1a7f9e",
    border: "none",
    borderRadius: "10px",
    position: "relative",
    cursor: "pointer",
    padding: 0,
  },

  toggleCircle: {
    width: "14px",
    height: "14px",
    backgroundColor: "#fff",
    borderRadius: "50%",
    position: "absolute",
    top: "2px",
    right: "2px",
    boxShadow: "0 1px 2px rgba(0,0,0,0.15)",
  },

  filterBar: {
    display: "flex",
    gap: "20px",
    alignItems: "flex-end",
    flexWrap: "wrap",
  },

  contentLayout: {
    display: "flex",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    marginTop: "6px",
    minHeight: 0,
  },

  chartContainer: {
    position: "relative",
    border: "1px solid #e5eaee",
    borderRadius: "6px",
    // backgroundColor: "#ffffff",
    overflow: "hidden",
    minWidth: 0,
    transition: "flex 0.25s ease, width 0.25s ease",
  },

  panelWrapper: {
    flex: "0 0 60%",
    width: "60%",
    minWidth: 0,
    height: "100%",
    position: "relative",
  },

  toolbar: {
    position: "absolute",
    top: "10px",
    left: "10px",
    zIndex: 50,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    background: "rgba(255,255,255,0.9)",
    borderRadius: "6px",
    boxShadow: "0 1px 5px rgba(0,0,0,0.12)",
  },

  loading: {
    position: "absolute",
    inset: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "rgba(255,255,255,0.55)",
    zIndex: 30,
  },

  tooltip: {
    position: "absolute",
    pointerEvents: "none",
    backgroundColor: "rgba(13,44,56,0.95)",
    color: "#fff",
    padding: "8px 10px",
    borderRadius: "6px",
    fontSize: "12px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.18)",
    zIndex: 40,
    maxWidth: "240px",
  },

  tooltipTitle: {
    fontWeight: 700,
    marginBottom: "4px",
  },

  tooltipLine: {
    fontSize: "10px",
    color: "#cbd5e1",
    marginTop: "2px",
  },

  legend: {
    position: "absolute",
    left: "12px",
    bottom: "12px",
    width: "170px",
    padding: "10px 12px",
    // background: "rgba(255,255,255,0.94)",
    border: "1px solid #e5eaee",
    borderRadius: "6px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
    zIndex: 15,
  },

  legendTitle: {
    fontSize: "13px",
    fontWeight: 700,
    color: "#1a7f9e",
    marginBottom: "7px",
  },

  legendRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    minHeight: "27px",
    fontSize: "11px",
    fontWeight: 700,
  },
  settingsPanel: {
    position: "absolute",
    top: "100%",
    left: 0,
    marginTop: "8px",
    width: "300px",
    maxWidth: "calc(100vw - 40px)",
    zIndex: 60,
  },
  statusLegend: {
    position: "absolute",
    right: "12px",
    bottom: "12px",
    width: "190px",
    padding: "10px 12px",
    // background: "rgba(255,255,255,0.96)",
    border: "1px solid #e5eaee",
    borderRadius: "6px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
    zIndex: 15,
    fontSize: "11px",
    color: "#475569",
  },

  statusLegendRow: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    minHeight: "24px",
  },

  statusDot: {
    width: "11px",
    height: "11px",
    flexShrink: 0,
    borderRadius: "50%",
    border: "1px solid rgba(0,0,0,0.15)",
  },
  terminalLegendSection: {
    display: "flex",
    flexDirection: "column",
    gap: "5px",
    marginBottom: "8px",
  },

  terminalLegendHeading: {
    fontSize: "11px",
    fontWeight: 700,
    color: "#475569",
    marginBottom: "2px",
  },

  terminalLegendRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "12px",
    minHeight: "25px",
    fontSize: "11px",
    // color: "#475569",
  },

  terminalLegendName: {
    flex: 1,
    minWidth: 0,
    overflowWrap: "anywhere",
    textAlign: "left",
    // fontSize:'13px',
    fontWeight: 700,
  },

  terminalLegendEmpty: {
    fontSize: "10px",
    color: "#94a3b8",
    padding: "4px 0",
  },

  legendDivider: {
    height: "1px",
    backgroundColor: "#e5eaee",
    margin: "7px 0",
  },
};

export default PictorialView;
