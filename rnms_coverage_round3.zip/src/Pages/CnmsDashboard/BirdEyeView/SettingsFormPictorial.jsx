import React, { useEffect, useState } from "react";
import {
  FormGroup,
  FormControlLabel,
  Checkbox,
  Paper,
  Typography,
  Divider,
  Box,
  useTheme,
} from "@mui/material";

import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { SAVE_TOOLTIP_OPTIONS } from "@/RestAPI/url/endpoint";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { useDispatch, useSelector } from "react-redux";
import { setTopologyTooltipOptions } from "@/store/features/Tooltip/toolTipSlice";
import Toast from "@/components/Reusable/Toast/Toast";

// Keep the order exactly as requested.
const TOOLTIP_DEFAULTS = {
  remoteType: true,
  vehNumber: true,
  longitude: true,
  latitude: true,
  status: true,
  activeLink: true,
  remoteId: true,
  maintainance: true,
  siteName: true,
  vehRunTime: true,
  selectAll: true,
};

const TOOLTIP_LABELS = {
  remoteType: "Remote Type",
  vehNumber: "Veh. Number",
  longitude: "Longitude",
  latitude: "Latitude",
  status: "Status",
  activeLink: "Active Link",
  remoteId: "Remote Id",
  maintainance: "Maintainance",
  siteName: "Site Name",
  vehRunTime: "Veh. Run Time",
};

const getInitialOptions = (savedOptions) => {
  const hasNewOptions =
    savedOptions &&
    Object.keys(TOOLTIP_LABELS).some((key) =>
      Object.prototype.hasOwnProperty.call(savedOptions, key)
    );

  // Ignore legacy resource-related keys. Use saved new preferences
  // when present; otherwise initialize the new fields as enabled.
  const options = hasNewOptions
    ? { ...TOOLTIP_DEFAULTS, ...savedOptions }
    : { ...TOOLTIP_DEFAULTS };

  // Only keep the 10 supported fields and Select All.
  const result = {};

  Object.keys(TOOLTIP_LABELS).forEach((key) => {
    result[key] = options[key] === true;
  });

  result.selectAll = Object.values(result).every(Boolean);

  return result;
};

const SettingsFormPictorial = ({ setShowSettingsModal }) => {
  const { topologyToolTipOptions } = useSelector(
    (state) => state.toolTipOptionsSlice
  );

    const theme = useTheme();

  const dispatch = useDispatch();

  const [formData, setFormData] = useState(() =>
    getInitialOptions(topologyToolTipOptions)
  );

  useEffect(() => {
    setFormData(getInitialOptions(topologyToolTipOptions));
  }, [topologyToolTipOptions]);

  const keys = Object.keys(TOOLTIP_LABELS);

  const isAllChecked = keys.every((key) => formData[key]);

  const isIndeterminate =
    keys.some((key) => formData[key]) && !isAllChecked;

  const handleCheck = (key) => (event) => {
    const updatedData = {
      ...formData,
      [key]: event.target.checked,
    };

    updatedData.selectAll = keys.every((item) => updatedData[item]);

    setFormData(updatedData);
  };

  const handleSelectAll = (event) => {
    const checked = event.target.checked;
    const updatedData = {};

    keys.forEach((key) => {
      updatedData[key] = checked;
    });

    updatedData.selectAll = checked;

    setFormData(updatedData);
  };

  const SaveSettings = async () => {
    try {
      // Persist only the supported tooltip settings.
      const payload = {
        id: 2,
        value: JSON.stringify(formData),
      };

      const res = await InventoryAxios(
        SAVE_TOOLTIP_OPTIONS,
        "post",
        payload
      );

      if (res.status === 200) {
        dispatch(setTopologyTooltipOptions(formData));

        Toast(
          "Success",
          "Settings saved successfully!",
          "success"
        );
      } else {
        Toast("Failed", "Failed to save settings", "error");
      }
    } catch (error) {
      console.error("Error:", error);

      Toast("Failed", "Failed to save settings", "error");
    }

    setShowSettingsModal(null);
  };

  return (
    <Paper
      elevation={3}
      sx={{
        display: "flex",
        flexDirection: "column",
        maxHeight: "450px",
        width: "100%",
        overflow: "hidden",
      }}
    >
      <Box sx={{ p: 2}}>
        <Typography
          variant="subtitle1"
          fontWeight="bold"
          sx={{color:theme.palette.mode === "dark" ? "#ffffff" : "#14348d" }}
        >
          CONFIGURABLE PARAMETERS
        </Typography>
      </Box>

      <Divider />

      <Box
        sx={{
          flexGrow: 1,
          overflowY: "auto",
          p: 1,
          "&::-webkit-scrollbar": { width: "6px" },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#ccc",
            borderRadius: "10px",
          },
        }}
      >
        <FormControlLabel
          label={
            <strong style={{ fontSize: "0.9rem" }}>
              Select All
            </strong>
          }
          control={
            <Checkbox
              checked={isAllChecked}
              indeterminate={isIndeterminate}
              onChange={handleSelectAll}
              color="primary"
              size="small"
            />
          }
        />

        <Divider sx={{ my: 1 }} />

        <FormGroup>
          {keys.map((key) => (
            <FormControlLabel
              key={key}
              label={
                <Typography variant="body2">
                  {TOOLTIP_LABELS[key]}
                </Typography>
              }
              control={
                <Checkbox
                  checked={Boolean(formData[key])}
                  onChange={handleCheck(key)}
                  size="small"
                />
              }
              sx={{ mb: -0.5 }}
            />
          ))}
        </FormGroup>
      </Box>

      <Divider />

      <Box
        sx={{
          py: 1,
          px: 2,
          display: "flex",
          justifyContent: "flex-end",
        }}
      >
        <MButtonPrimary
          onClick={SaveSettings}
          sx={{ minWidth: "100px" }}
        >
          Save
        </MButtonPrimary>
      </Box>
    </Paper>
  );
};

export default SettingsFormPictorial;