import React from "react";
import MapIndex from "./MapIndex";

const CnmsMap = () => {
  return (
    <div style={{width:'100%',height:'100%'}}>
      <MapIndex />
    </div>
  );
};

export default CnmsMap;
