import React, { useEffect, useRef, useState } from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  WMSTileLayer,
  Tooltip,
} from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-cluster";
import "leaflet/dist/leaflet.css";
import { GEO_SERVER_MAP_VIEW_URL } from "@/RestAPI/url/baseUrl";
import { MapControls } from "./components/MapControls";
import { InfoTable } from "./components/InfoTable";
import { ConfigPopover } from "./components/ConfigPopover";
import { MinimapLeaflet } from "./components/MinimapLeaflet";

import { useDispatch, useSelector } from "react-redux";
import {
  getCnmsIcon,
  getCommaSeparatedGroupNames,
  getSiteIcon,
} from "./components/maputils";
import { FilterPopover } from "./components/FilterPopover";
import MapStats from "./components/MapStats";
import MapTopRightControls from "./components/MapTopRightControls";
import {
  clearFilterResetFlag,
  setViewOnMap,
} from "@/store/features/Cnms/mapViewSlice";
import { LiveCordinates } from "./components/LiveCoordinates";

const MapIndex = () => {
  const isInitialMount = useRef(true);
  const hasInitializedView = useRef(false);
  const dispatch = useDispatch();
  const allCnms = useSelector((state) => state.nodeDetails.repDetails);
  const allSites = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails
  );
  const { viewOnMap, allSiteGroups, shouldResetFilters } = useSelector(
    (state) => state.mapViewSlice
  );

  const blinkingSites = useSelector(
    (state) => state.remoteRepDetails.blinkingSites
  );

  console.log(blinkingSites, "blinkingSites");

  const [selectedEntity, setSelectedEntity] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [filteredSites, setFilteredSites] = useState([]);

  const [filterAnchorEl, setFilterAnchorEl] = useState(null); // Added Filter Anchor State
  const [configAnchorEl, setConfigAnchorEl] = useState(null); // Changed to Anchor Element State

  const [isMiniMapOpen, setIsMiniMapOpen] = useState(false);
  const [filterInfo, setFilterInfo] = useState({
    selectedGroups: [],
    selectedStatus: [1, 0, 2, 3, 4], // Adjust health status IDs based on your data
    sitesToFilter: [],
  });
  const [sitesToDisplay, setSitesToDisplay] = useState([]);
  console.log("sitesToDisplay=", sitesToDisplay, "allSites=", allSites);

  const [map, setMap] = useState(null);
  const previousDisplayIds = useRef([]);

  const [availableParams, setAvailableParams] = useState([
    { key: "id", label: "ID", checked: true },
    { key: "name", label: "Name", checked: true },
    { key: "unitName", label: "Unit Name", checked: true },
    { key: "longitude", label: "Longitude", checked: true },
    { key: "latitude", label: "Latitude", checked: true },
    { key: "status", label: "Status", checked: true },
  ]);

  // Sync Redux allSites updates into local filter states
  useEffect(() => {
    if (allSites.length > 0) {
      if (filteredSites.length === 0) {
        setFilteredSites([...allSites]);
      } else {
        let prvsSites = {};
        filteredSites.forEach((item) => {
          prvsSites[item.siteId] = item;
        });
        allSites.forEach((item) => {
          if (prvsSites[item.siteId]) prvsSites[item.siteId] = item;
        });
        setFilteredSites([...Object.values(prvsSites)]);
      }
    }
  }, [allSites]);

  // Apply filtering logic whenever filterInfo or filteredSites changes
  useEffect(() => {
    if (allSites.length > 0) {
      let selectedSiteIds = {};
      filteredSites.forEach((item) => {
        if (item.siteId) selectedSiteIds[item.siteId] = 1;
      });

      const newSelectedSites = allSites.filter(
        (item) => selectedSiteIds[item.siteId]
      );

      // const arr = newSelectedSites.filter((item) =>
      //   filterInfo.selectedStatus.includes(item.healthStatus?.id ?? 0)
      // );

      const arr = newSelectedSites.filter((item) => {
        const statusId = item.healthStatus?.id ?? 0;

        return filterInfo.selectedStatus.includes(statusId);
      });

      setSitesToDisplay(arr);
    } else {
      setSitesToDisplay([]);
    }
  }, [filterInfo, filteredSites, allSites]);

  // Group sites parser
  let allGroupSites = [];
  allSiteGroups.forEach((group) => {
    group.sites?.forEach((site) => {
      allGroupSites.push({
        groupName: group.groupName,
        siteId: site.siteId,
        healthStatus: site.healthStatus?.value,
      });
    });
  });

  const handleToggleFullscreen = () => {
    const elem = document.getElementById("nms-map-container");
    if (!document.fullscreenElement) {
      elem.requestFullscreen().catch((err) => {
        alert(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleConfigSave = (params) => {
    setAvailableParams(params);
  };

  useEffect(() => {
    if (map !== null && viewOnMap.length > 0) {
      map.flyTo(viewOnMap, 11);
      dispatch(setViewOnMap([]));
    }
  }, [viewOnMap, map]);

  // comment this useEffect code if you dont want zoomeffect,this cause zooming to sites when add,move to maintain,socket update happens
  useEffect(() => {
    if (map !== null && blinkingSites.length > 0) {
      const blinkingSiteLatLang = sitesToDisplay.find(
        (item) => item.siteId === blinkingSites[0].siteId
      );

      map.flyTo(
        [blinkingSiteLatLang.latitude, blinkingSiteLatLang.longitude],
        11
      );
    }
  }, [blinkingSites, map]);

  // =====================================================
  // ZOOM TO SITES
  // =====================================================

  const zoomToSites = (sites) => {
    if (!map || !sites?.length) return;

    const validSites = sites.filter(
      (site) =>
        typeof site.latitude === "number" && typeof site.longitude === "number"
    );

    if (!validSites.length) return;

    // Single site
    if (validSites.length === 1) {
      const site = validSites[0];

      map.flyTo([site.latitude, site.longitude], 11, {
        duration: 1,
      });

      return;
    }

    // Multiple sites
    const bounds = validSites.map((site) => [site.latitude, site.longitude]);

    map.fitBounds(bounds, {
      padding: [60, 60],
      maxZoom: 11,
      animate: true,
    });
  };

  // =====================================================
  // ZOOM WHEN FILTERED RESULT CHANGES
  // =====================================================

  useEffect(() => {
    if (!map) return;

    const currentIds = sitesToDisplay
      .map((site) => site.siteId)
      .sort((a, b) => a.localeCompare(b));

    // Skip zoom on initial mount if desired
    if (isInitialMount.current) {
      isInitialMount.current = false;
      previousDisplayIds.current = currentIds;
      return;
    }

    const previousIds = [...previousDisplayIds.current].sort((a, b) =>
      a.localeCompare(b)
    );
    const changed =
      currentIds.length !== previousIds.length ||
      currentIds.some((id, index) => id !== previousIds[index]);

    if (changed) {
      zoomToSites(sitesToDisplay);
    }

    previousDisplayIds.current = currentIds;
  }, [sitesToDisplay, map]);

  useEffect(() => {
    if (!map) return;

    // Check if we have data loaded and haven't initialized the view yet
    if (
      !hasInitializedView.current &&
      (allCnms.length > 0 || allSites.length > 0)
    ) {
      hasInitializedView.current = true;
      map.setView([20.5937, 78.9029], 5);
    }
  }, [map, allCnms, allSites]);

  // =====================================================
  // 1. HANDLE RESET TRIGGER FROM REDUX FLAG
  // =====================================================
  useEffect(() => {
    if (shouldResetFilters) {
      // Reset Filter Info to defaults
      setFilterInfo({
        selectedGroups: [],
        selectedStatus: [1, 0, 2, 3], // Match your FilterPopover defaults
        sitesToFilter: [],
      });

      // Reset the local filtered list to ALL current sites
      setFilteredSites([...allSites]);

      // Mark the flag as false so the effect doesn't run again immediately
      dispatch(clearFilterResetFlag());
    }
  }, [shouldResetFilters, allSites, dispatch]);

  useEffect(() => {
    // Check if map instance is ready
    if (!map) return;

    map.setView([23.5937, 78.9029], 5);
  }, [map]); // Dependency is ONLY 'map'. It runs once when map is assigned.

  return (
    <div
      id="nms-map-container"
      style={{
        width: "100%",
        height: "100%",
        position: "relative",
        background: "#fff",
      }}
    >
      <MapContainer
        preferCanvas={true}
        center={[20.5937, 78.9029]}
        zoom={7} //default zoom level
        maxZoom={15}
        minZoom={4}
        style={{ width: "100%", height: "100%", zIndex: 0 }}
        attributionControl={false}
        ref={setMap}
      >
        <TileLayer url={GEO_SERVER_MAP_VIEW_URL} ed={10} />
        <WMSTileLayer // WMS layer to get India map from geoserver; all parameters are attached in url
          url={GEO_SERVER_MAP_VIEW_URL}
          version={"1.1.1"} // WMS Version
          format="image/png"
          transparent={true}
          layers={"MCT_LSV_GIS:MCT_LSV_Map"} //layer name from geoserver
          tiled={true}
          srs={window.L.CRS.EPSG4326.code}
          uppercase={true}
        />

        <MapControls
          allCnms={allCnms}
          allSites={allSites}
          onToggleFullscreen={handleToggleFullscreen}
          isFullscreen={isFullscreen}
          onToggleMiniMap={() => setIsMiniMapOpen(!isMiniMapOpen)}
          isMiniMapOpen={isMiniMapOpen}
        />

        {isMiniMapOpen && <MinimapLeaflet />}
        <LiveCordinates />

        {/* 1. Render CNMS Markers */}
        {allCnms.map((cnms) => (
          <Marker
            key={cnms.id}
            position={[cnms.latitude, cnms.longitude]}
            icon={getCnmsIcon(cnms)}
            eventHandlers={{
              click: () => setSelectedEntity({ type: "CNMS", data: cnms }),
            }}
          />
        ))}

        {/* 2. Render Sites with Marker Cluster */}
        <MarkerClusterGroup
          maxClusterRadius={40}
          spiderfyOnMaxZoom={true}
          spiderfyDistanceMultiplier={3}
          zoomToBoundsOnClick={true}
          spiderfyOnEveryZoom={false}
          showCoverageOnHover={true}
          spiderLegPolylineOptions={{
            color: "blue",
            opacity: 1,
            weight: 3,
          }}
        >
          {sitesToDisplay.map((site) => {
            const currentStatusNum = site.healthStatus?.id;

            const blinkingSite = blinkingSites.find(
              (item) => item.siteId === site.siteId
            );

            const isBlinking = Boolean(blinkingSite);

            const blinkingMaintenanceType =
              blinkingSite?.maintenanceType ?? null;

            return (
              <Marker
                key={site.siteId}
                position={[site.latitude, site.longitude]}
                icon={getSiteIcon(
                  site,
                  currentStatusNum,
                  isBlinking,
                  blinkingMaintenanceType
                )}
                eventHandlers={{
                  click: () =>
                    setSelectedEntity({
                      type: "Site",
                      data: site,
                    }),
                }}
              >
                <Tooltip direction="bottom" offset={[0, -15]} permanent>
                  <div>
                    {site.siteId}
                    <div>
                      {getCommaSeparatedGroupNames(site.groupList) && (
                        <span>
                          {" "}
                          ({getCommaSeparatedGroupNames(site.groupList)})
                        </span>
                      )}
                    </div>
                  </div>
                </Tooltip>
              </Marker>
            );
          })}
        </MarkerClusterGroup>
      </MapContainer>

      {/* Info Table */}
      <InfoTable
        selectedEntity={selectedEntity}
        availableParams={availableParams}
        onClose={() => setSelectedEntity(null)}
      />

      {/* sites count and status table  */}
      <MapStats sitesToDisplay={sitesToDisplay} fullScreen={isFullscreen} />

      {/* <Box
        sx={{
          position: "absolute",
          bottom: isFullscreen ? "50px" : "28px",
          left: "20px",
          zIndex: 100,
          borderRadius: "4px",
        }}
      >
        <MapLegend />
      </Box> */}

      {/* Filter Popover Component */}
      <FilterPopover
        anchorEl={filterAnchorEl}
        onClose={() => setFilterAnchorEl(null)}
        reduxSites={allSites}
        allGroupSites={allGroupSites}
        siteGroups={allSiteGroups}
        filteredSites={filteredSites}
        SetFilteredSites={setFilteredSites}
        setFilterInfo={setFilterInfo}
        filterInfo={filterInfo}
      />

      {/* Configurable parameters component */}
      <ConfigPopover
        anchorEl={configAnchorEl}
        onClose={() => setConfigAnchorEl(null)}
        availableParams={availableParams}
        onSave={handleConfigSave}
      />

      {/* map filter , minmpa etc buttons component */}
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={isMiniMapOpen}
      />
    </div>
  );
};

export default MapIndex;
