import React from "react";
import SettingsIcon from "@/assets/CNMS/Filter site.svg";
import Filter from "@/assets/CNMS/Filter Birdeye.svg";
import UpIcon from "@/assets/SVGIcons/ALL_Reports_View.svg";
import { Box } from "@mui/material";

const MapTopRightControls = ({
  setFilterAnchorEl,
  setConfigAnchorEl,
  setIsMiniMapOpen,
  isMiniMapOpen,
}) => {
  return (
    <Box
      sx={{
        display: "flex",
        gap: "3px",
        position: "absolute",
        top: 10,
        right: 10,
        zIndex: 1,
      }}
    >
      <button
        onClick={(e) => setFilterAnchorEl(e.currentTarget)}
        title="Filter"
        className="map-util-icons"
      >
        <img
          src={Filter}
          style={{ width: "25px", height: "25px" }}
          alt="filter"
        />
      </button>
      <button
        size="small"
        onClick={(e) => setConfigAnchorEl(e.currentTarget)}
        title="Settings"
        className="map-util-icons"
      >
        <img
          src={SettingsIcon}
          style={{ width: "25px", height: "25px" }}
          alt="settings"
        />
      </button>
      <button
        onClick={() => setIsMiniMapOpen(!isMiniMapOpen)}
        title="Min map"
        className="map-util-icons"
      >
        <img
          style={{
            transform: isMiniMapOpen ? "rotate(90deg)" : "rotate(-90deg)",
            transition: "transform 0.3s ease-in-out",
          }}
          src={UpIcon}
          alt="min map"
        />
      </button>
    </Box>
  );
};

export default MapTopRightControls;
