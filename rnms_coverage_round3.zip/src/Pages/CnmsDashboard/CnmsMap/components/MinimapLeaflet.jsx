import React, { useState, useMemo, useCallback, useEffect } from "react";
import {
  MapContainer,
  TileLayer,
  WMSTileLayer,
  useMapEvent,
  useMap,
  Rectangle,
} from "react-leaflet";
import { useEventHandlers } from "@react-leaflet/core";

import { GEO_SERVER_MAP_VIEW_URL } from "@/RestAPI/url/baseUrl";

function MinimapBounds({ parentMap, zoom, setZoomlevel }) {
  const arr = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];
  const minimap = useMap();
  const [bounds, setBounds] = useState(parentMap.getBounds());

  useEffect(() => {
    const currentZoomIndex = arr.indexOf(Math.round(parentMap.getZoom()));
    if (currentZoomIndex !== -1) setZoomlevel(currentZoomIndex);
    minimap.setView(parentMap.getCenter(), zoom);
  }, [zoom, parentMap.getZoom(), minimap]);

  const onClick = useCallback(
    (e) => {
      parentMap.setView(e.latlng, parentMap.getZoom());
    },
    [parentMap]
  );
  useMapEvent("click", onClick);

  const onChange = useCallback(() => {
    setBounds(parentMap.getBounds());
    const currentZoomIndex = arr.indexOf(Math.round(parentMap.getZoom()));
    if (currentZoomIndex !== -1) setZoomlevel(currentZoomIndex);
    minimap.setView(parentMap.getCenter(), zoom);
  }, [minimap, parentMap, zoom]);

  const handlers = useMemo(
    () => ({ move: onChange, zoom: onChange }),
    [onChange]
  );
  useEventHandlers({ instance: parentMap }, handlers);

  return (
    <Rectangle dragging={true} bounds={bounds} pathOptions={{ weight: 2 }} />
  );
}

export const MinimapLeaflet = () => {
  const parentMap = useMap();

  const [zoomlevel, setZoomlevel] = useState(2);

  return (
    <div
      className={"leaflet-top leaflet-right"}
      style={{ top: "40px", right: "20px" }}
    >
      <div
        className="leaflet-control leaflet-bar"
        style={{
          border: "black solid 2px",
          padding: "4px",
          backgroundColor: "white",
        }}
      >
        <MapContainer
          style={{ height: "18vh", width: "20vw" }}
          center={parentMap.getCenter()}
          zoom={zoomlevel}
          dragging={false}
          doubleClickZoom={false}
          scrollWheelZoom={false}
          attributionControl={false}
          zoomControl={false}
          minZoom={zoomlevel}
          maxZoom={13}
        >
          <TileLayer url={GEO_SERVER_MAP_VIEW_URL} ed={10} />
          <WMSTileLayer
            url={GEO_SERVER_MAP_VIEW_URL}
            version={"1.1.1"}
            format="image/png"
            transparent={true}
            layers={"MCT_LSV_GIS:MCT_LSV_Map"}
            tiled={true}
            srs={window.L.CRS.EPSG4326.code}
            uppercase={true}
          />
          <MinimapBounds
            parentMap={parentMap}
            zoom={zoomlevel}
            setZoomlevel={setZoomlevel}
          />
        </MapContainer>
      </div>
    </div>
  );
};
