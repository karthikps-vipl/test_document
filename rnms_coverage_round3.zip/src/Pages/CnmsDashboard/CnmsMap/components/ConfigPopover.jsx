import React, { useEffect, useState } from "react";
import {
  Popover,
  Box,
  FormControlLabel,
  Checkbox,
  IconButton,
  Typography,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";

export const ConfigPopover = ({
  anchorEl,
  onClose,
  availableParams,
  onSave,
}) => {
  const open = Boolean(anchorEl);

  // Local/draft configuration
  const [draftParams, setDraftParams] = useState([]);

  // Initialize draft whenever popover opens
  useEffect(() => {
    if (open) {
      setDraftParams(availableParams);
    }
  }, [open, availableParams]);

  const handleParamToggle = (key) => {
    setDraftParams((prev) =>
      prev.map((param) =>
        param.key === key ? { ...param, checked: !param.checked } : param
      )
    );
  };

  const isAllSelected =
    draftParams.length > 0 && draftParams.every((param) => param.checked);

  const handleSelectAllToggle = () => {
    const newState = !isAllSelected;

    setDraftParams((prev) =>
      prev.map((param) => ({
        ...param,
        checked: newState,
      }))
    );
  };

  const handleSave = () => {
    onSave(draftParams);
    onClose();
    Toast("", "Selected parameters saved", "success");
  };

  const handleClose = () => {
    // Don't save draft changes
    setDraftParams(availableParams);
    onClose();
  };

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "right",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      elevation={4}
      sx={{ mt: 1 }}
    >
      <Box sx={{ p: 2, width: 240 }}>
        {/* Header */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #eee",
            // pb: 1,
          }}
        >
          <Typography variant="subtitle2" sx={{ fontWeight: "bold" }}>
            Configure Parameters
          </Typography>

          <IconButton onClick={handleClose} size="small">
            <CloseIcon fontSize="small" />
          </IconButton>
        </Box>

        {/* Select All */}
        <Box
          sx={{
            // mb: 1,
            borderBottom: "1px solid #f0f0f0",
          }}
        >
          <FormControlLabel
            control={
              <Checkbox
                checked={isAllSelected}
                onChange={handleSelectAllToggle}
                size="small"
              />
            }
            label={
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>
                Select All
              </Typography>
            }
          />
        </Box>

        {/* Parameters */}
        <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5 }}>
          {draftParams.map((param) => (
            <FormControlLabel
              key={param.key}
              control={
                <Checkbox
                  checked={param.checked}
                  onChange={() => handleParamToggle(param.key)}
                  size="small"
                />
              }
              label={<Typography variant="body2">{param.label}</Typography>}
            />
          ))}
        </Box>

        {/* Save / Cancel */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            gap: 1,
            // mt: 2,
            pt: 1,
            borderTop: "1px solid #eee",
          }}
        >
          {/* <Button size="small" variant="outlined" onClick={handleClose}>
            Cancel
          </Button> */}

          <MButtonPrimary size="small" variant="contained" onClick={handleSave}>
            Save
          </MButtonPrimary>
        </Box>
      </Box>
    </Popover>
  );
};
