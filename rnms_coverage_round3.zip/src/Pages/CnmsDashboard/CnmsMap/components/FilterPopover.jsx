import React, { useEffect, useState } from "react";
import { Popover, Box, Typography, InputAdornment } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";

import MInput from "@/components/Reusable/Input/MInput";
import MMultiSelect from "@/components/Reusable/Select/MMultiSelect";
import MCheckbox from "@/components/Reusable/Checkbox/MCheckbox";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { SquareIconButton } from "@/components/Reusable/Modal/MModal";

const STATUS_OPTIONS = [
  { value: 1, label: "Online" },
  { value: 0, label: "Offline" },
  { value: 2, label: "RNMS Down" },
  { value: 3, label: "Maintenance" },
];

export const FilterPopover = ({
  anchorEl,
  onClose,
  reduxSites = [],
  allGroupSites = [],
  siteGroups = [],
  filteredSites = [],
  SetFilteredSites,
  setFilterInfo,
  filterInfo,
}) => {
  const [textFilter, setTextFilter] = useState("");

  const [selectedGroups, setSelectedGroups] = useState(
    filterInfo?.selectedGroups || []
  );

  const [selectedStatus, setSelectedStatus] = useState(
    filterInfo?.selectedStatus || [1, 0, 2, 3]
  );

  const [sitesToFilter, setSitesToFilter] = useState(
    filterInfo?.sitesToFilter?.length ? filterInfo.sitesToFilter : reduxSites
  );

  const [selectAll, setSelectAll] = useState(false);

  // -------------------------------------------------------
  // Sync local state whenever filter popover is opened
  // -------------------------------------------------------

  useEffect(() => {
    if (!anchorEl) return;

    setSelectedGroups(filterInfo?.selectedGroups || []);

    setSelectedStatus(filterInfo?.selectedStatus || [1, 0, 2, 3]);

    setSitesToFilter(
      filterInfo?.sitesToFilter?.length ? filterInfo.sitesToFilter : reduxSites
    );
  }, [anchorEl, filterInfo, reduxSites]);

  // -------------------------------------------------------
  // Select All state
  // -------------------------------------------------------

  useEffect(() => {
    if (!sitesToFilter.length) {
      setSelectAll(false);
      return;
    }

    const allSelected = sitesToFilter.every((site) =>
      filteredSites.some((selectedSite) => selectedSite.siteId === site.siteId)
    );

    setSelectAll(allSelected);
  }, [sitesToFilter, filteredSites]);

  // -------------------------------------------------------
  // Group options
  // -------------------------------------------------------

  const groupOptions = siteGroups
    .filter((group) => group?.groupName)
    .map((group) => ({
      value: group.groupName,
      label: group.groupName,
    }));

  // -------------------------------------------------------
  // Group change
  // -------------------------------------------------------

  const handleGroupChange = (groups) => {
    const selectedGroupNames = groups || [];

    setSelectedGroups(selectedGroupNames);

    let finalSites;

    // No group selected = all sites
    if (selectedGroupNames.length === 0) {
      finalSites = [...reduxSites];
    } else {
      const siteIds = {};

      allGroupSites.forEach((item) => {
        if (selectedGroupNames.includes(item.groupName)) {
          siteIds[item.siteId] = true;
        }
      });

      finalSites = reduxSites.filter((site) => siteIds[site.siteId]);
    }

    setSitesToFilter(finalSites);

    // Remove selected sites that no longer belong
    // to the selected groups
    const availableIds = new Set(finalSites.map((site) => site.siteId));

    const updatedSelectedSites = filteredSites.filter((site) =>
      availableIds.has(site.siteId)
    );

    SetFilteredSites(updatedSelectedSites);
  };

  // -------------------------------------------------------
  // Status checkbox change
  // -------------------------------------------------------

  const handleStatusChange = (statusId) => {
    setSelectedStatus((prev) => {
      const updatedStatus = prev.includes(statusId)
        ? prev.filter((id) => id !== statusId)
        : [...prev, statusId];

      // Apply status filter immediately
      setFilterInfo((prevInfo) => ({
        ...prevInfo,
        selectedStatus: updatedStatus,
      }));

      return updatedStatus;
    });
  };

  // -------------------------------------------------------
  // Select all sites
  // -------------------------------------------------------

  const handleSelectAll = (checked) => {
    setSelectAll(checked);

    if (checked) {
      SetFilteredSites([...sitesToFilter]);
    } else {
      SetFilteredSites([]);
    }
  };

  // -------------------------------------------------------
  // Individual site checkbox
  // -------------------------------------------------------

  const handleSiteChange = (site, checked) => {
    let updatedSites = [...filteredSites];

    if (checked) {
      const alreadySelected = updatedSites.some(
        (item) => item.siteId === site.siteId
      );

      if (!alreadySelected) {
        updatedSites.push(site);
      }
    } else {
      updatedSites = updatedSites.filter((item) => item.siteId !== site.siteId);
    }

    SetFilteredSites(updatedSites);
  };

  // -------------------------------------------------------
  // Apply
  // -------------------------------------------------------

  // const handleApplyFilter = () => {
  //   setFilterInfo({
  //     selectedGroups,
  //     selectedStatus,
  //     sitesToFilter,
  //   });

  //   onClose();
  // };

  // -------------------------------------------------------
  // Reset
  // -------------------------------------------------------

  const handleReset = () => {
    const allStatuses = STATUS_OPTIONS.map((status) => status.value);

    setSelectedGroups([]);
    setSelectedStatus(allStatuses);
    setSitesToFilter([...reduxSites]);

    SetFilteredSites([...reduxSites]);

    setFilterInfo({
      selectedGroups: [],
      selectedStatus: allStatuses,
      sitesToFilter: [...reduxSites],
    });

    setTextFilter("");
  };

  // -------------------------------------------------------
  // Site search
  // -------------------------------------------------------

  const visibleSites = sitesToFilter.filter((site) =>
    String(site?.siteId || "")
      .toLowerCase()
      .includes(textFilter.toLowerCase())
  );

  // -------------------------------------------------------
  // Selected sites multiline value
  // -------------------------------------------------------

  const selectedSiteText = filteredSites
    .map((site) => site.siteId)
    .filter(Boolean)
    .join("\n");

  return (
    <Popover
      open={Boolean(anchorEl)}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "right",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
    >
      <Box
        sx={{
          width: 400,
          p: 2,
          bgcolor: "background.paper",
        }}
      >
        {/* ================================================= */}
        {/* HEADER */}
        {/* ================================================= */}

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
            pb: 1,
            borderBottom: "1px solid #eee",
          }}
        >
          <Typography variant="subtitle1" sx={{ fontWeight: "bold" }}>
            Filter Sites
          </Typography>

          <SquareIconButton onClick={onClose}>
            <CloseIcon />
          </SquareIconButton>
        </Box>

        {/* ================================================= */}
        {/* GROUP NAMES */}
        {/* ================================================= */}

        <Box sx={{ mb: 2 }}>
          <Typography
            variant="caption"
            sx={{
              display: "block",
              mb: 0.5,
              fontWeight: 500,
            }}
          >
            Group Names
          </Typography>

          <MMultiSelect
            options={groupOptions}
            value={selectedGroups}
            onChange={handleGroupChange}
            placeholder="All Sites"
            // isCompact
          />
        </Box>

        {/* ================================================= */}
        {/* SITE SEARCH + SELECT ALL */}
        {/* ================================================= */}

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 1,
            mb: 1,
          }}
        >
          <Box sx={{ width: "62%" }}>
            <MInput
              size="small"
              placeholder="Search Site..."
              value={textFilter}
              onChange={(e) => setTextFilter(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon fontSize="small" />
                  </InputAdornment>
                ),
              }}
            />
          </Box>

          <MCheckbox
            checked={selectAll}
            onChange={(e) => handleSelectAll(e.target.checked)}
            label="Select All"
            size="small"
          />
        </Box>

        {/* ================================================= */}
        {/* SITE COUNT */}
        {/* ================================================= */}

        <Typography
          variant="caption"
          color="textSecondary"
          sx={{
            mb: 1,
            display: "block",
          }}
        >
          {filteredSites.length} / {sitesToFilter.length} site(s) selected
        </Typography>

        {/* ================================================= */}
        {/* SITE LIST */}
        {/* ================================================= */}

        <Box
          sx={{
            border: "1px solid #ddd",
            borderRadius: "4px",
            maxHeight: 180,
            overflowY: "auto",
            p: 1,
            mb: 1,
          }}
        >
          {visibleSites.length > 0 ? (
            visibleSites.map((site) => {
              const checked = filteredSites.some(
                (selectedSite) => selectedSite.siteId === site.siteId
              );

              return (
                <Box
                  key={site.siteId}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    minHeight: 32,
                  }}
                >
                  <Typography variant="body2">{site.siteId}</Typography>

                  <MCheckbox
                    checked={checked}
                    onChange={(e) => handleSiteChange(site, e.target.checked)}
                    size="small"
                    label=""
                  />
                </Box>
              );
            })
          ) : (
            <Typography
              variant="body2"
              color="textSecondary"
              sx={{
                p: 1,
                textAlign: "center",
              }}
            >
              No sites found
            </Typography>
          )}
        </Box>

        {/* ================================================= */}
        {/* SELECTED SITES - MULTILINE INPUT                  */}
        {/* ================================================= */}

        <Box sx={{ mb: 2 }}>
          <Typography
            variant="caption"
            sx={{
              display: "block",
              mb: 0.5,
              fontWeight: 500,
            }}
          >
            Selected Sites
          </Typography>

          <MInput
            multiline
            minRows={3}
            maxRows={6}
            value={selectedSiteText}
            placeholder="Selected sites"
            readOnly
            sx={{
              width: "100%",

              "& .MuiInputBase-input": {
                fontSize: "0.85rem",
              },

              "& .MuiOutlinedInput-root": {
                alignItems: "flex-start",
              },
            }}
          />
        </Box>

        {/* ================================================= */}
        {/* STATUS - SEPARATE CHECKBOXES                     */}
        {/* ================================================= */}

        <Box
          sx={{
            // border: "1px solid #ddd",
            // borderRadius: "5px",
            // p: 1,
            mb: 2,
          }}
        >
          <Typography
            variant="caption"
            sx={{
              display: "block",
              mb: 0.5,
              fontWeight: 500,
            }}
          >
            Filter By Status
          </Typography>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexWrap: "wrap",
              columnGap: 1,
              rowGap: 0.5,
            }}
          >
            {/* Online */}
            <MCheckbox
              checked={selectedStatus.includes(1)}
              onChange={() => handleStatusChange(1)}
              label="Online"
              size="small"
            />

            {/* Offline */}
            <MCheckbox
              checked={selectedStatus.includes(0)}
              onChange={() => handleStatusChange(0)}
              label="Offline"
              size="small"
            />

            {/* RNMS Down */}
            <MCheckbox
              checked={selectedStatus.includes(2)}
              onChange={() => handleStatusChange(2)}
              label="RNMS Down"
              size="small"
            />

            {/* Maintenance */}
            <MCheckbox
              checked={selectedStatus.includes(3)}
              onChange={() => handleStatusChange(3)}
              label="Maintenance"
              size="small"
            />
          </Box>
        </Box>

        {/* ================================================= */}
        {/* BUTTONS */}
        {/* ================================================= */}

        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "flex-end",

            gap: 1,
          }}
        >
          <MButtonPrimary variant="outlined" size="small" onClick={handleReset}>
            Reset
          </MButtonPrimary>

          {/* <MButtonPrimary
            variant="contained"
            size="small"
            onClick={handleApplyFilter}
          >
            Apply Filter
          </MButtonPrimary> */}
        </Box>
      </Box>
    </Popover>
  );
};

export default FilterPopover;
