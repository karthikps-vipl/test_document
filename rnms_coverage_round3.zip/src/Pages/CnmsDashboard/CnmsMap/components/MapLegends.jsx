import { Grid } from "@mui/material";
import { colorMapUsingId } from "./maputils";

export const MapLegend = () => {
  return (
    <Grid>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <span className="map-legend-item-cont">
          <div
            style={{
              backgroundColor: colorMapUsingId[1],
            }}
          ></div>
          <p>Online </p>
        </span>
        <span className="map-legend-item-cont">
          <div
            style={{
              backgroundColor: colorMapUsingId[0],
            }}
          ></div>
          <p>Offline</p>
        </span>
        <span className="map-legend-item-cont">
          <div style={{ backgroundColor: colorMapUsingId[2] }}></div>
          <p>RNMS Down </p>
        </span>
        <span className="map-legend-item-cont">
          <div style={{ backgroundColor: colorMapUsingId[3] }}></div>
          <p>Maintenance Non-OPS</p>
        </span>
        <span className="map-legend-item-cont">
          <div style={{ backgroundColor: colorMapUsingId[4] }}></div>
          <p>Maintenance R-OPS</p>
        </span>
      </div>
    </Grid>
  );
};
