import React from "react";
import {
  Paper,
  Box,
  Typography,
  IconButton,
  Table,
  TableBody,
  TableRow,
  TableCell,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import HomeIcon from "@mui/icons-material/Home";
import LocationOnIcon from "@mui/icons-material/LocationOn";

export const InfoTable = ({ selectedEntity, availableParams, onClose }) => {
  if (!selectedEntity) return null;

  const getEntityValue = (key, entity) => {
    const data = entity?.data;
    console.log(data, "jhjhjrhd");

    switch (key) {
      case "id":
        return data?.id || data?.siteId || "N/A";
      case "name":
        return data?.siteName || "N/A";
      case "unitName":
        if (entity?.type === "CNMS") {
          return data?.resRepDetails?.[0]?.unit || "N/A";
        }
        return data?.siteNickName || "N/A";
      case "longitude":
        return data?.longitude !== undefined ? data?.longitude : "N/A";
      case "latitude":
        return data?.latitude !== undefined ? data?.latitude : "N/A";
      case "status":
        if (data?.isMaintainance) {
          return "Maintenance";
        }
        if (entity.type === "CNMS") {
          return data?.isActive ? "OPERATIONAL" : "NON-OPERATIONAL";
        } else {
          return data?.healthStatus?.id === 1
            ? "OPERATIONAL"
            : "NON-OPERATIONAL";
        }
      // return data.healthStatus?.value || "N/A";
      default:
        return "N/A";
    }
  };

  return (
    <Paper
      elevation={4}
      sx={{
        position: "absolute",
        bottom: 25,
        right: 25,
        zIndex: 1000,
        p: 1,
        minWidth: 280,
        maxWidth: 350,
        borderRadius: 2,
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 1,
          pb: 1,
          borderBottom: "1px solid #eee",
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            // color: "#14348d",
            // fontWeight: "bold",
          }}
        >
          {selectedEntity.type === "CNMS" ? (
            <HomeIcon fontSize="small" />
          ) : (
            <LocationOnIcon fontSize="small" />
          )}
          <Typography variant="subtitle2" component="span">
            {selectedEntity.type} Details
          </Typography>
        </Box>
        <IconButton onClick={onClose} size="small">
          <CloseIcon fontSize="small" />
        </IconButton>
      </Box>

      <Table size="small">
        <TableBody>
          {availableParams
            .filter((param) => param.checked)
            .map((param) => (
              <TableRow key={param.key}>
                <TableCell
                  sx={{
                    fontWeight: "600",
                    color: "text.secondary",
                    borderBottom: "none",
                    py: 0.5,
                    width: "40%",
                    whiteSpace: "nowrap",
                  }}
                >
                  {param.label}:
                </TableCell>
                <TableCell
                  sx={{
                    color: "text.primary",
                    borderBottom: "none",
                    py: 0.5,
                    textAlign: "right",
                    whiteSpace: "nowrap",
                  }}
                >
                  {getEntityValue(param.key, selectedEntity)}
                </TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    </Paper>
  );
};
