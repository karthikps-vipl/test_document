import L from "leaflet";
import DCicon from "@/assets/CNMS/DCicon.png";

export const colorMapUsingId = {
  0: "#d32f2f", // DOWN
  1: "#2e7d32", // UP
  2: "#f3c106", // RNMS DOWN / Operational Down
  3: "#b8860b", // Maintenance Non-OPS (maintenanceType = 1 from backend)
  4: "#34b8b8", // Maintenance R-OPS (maintenanceType = 2 from backend)
};

export const healthStatusMap = {
  UP: 1,
  DOWN: 0,
  OPERATIONAL_DOWN: 2,
  MAINTENANCE: 3,
  "R-OPS": 4,
};

const getStatusColor = (currentStatusNum, site) => {
  console.log(currentStatusNum, "sdfjkdhfgd");

  switch (currentStatusNum) {
    case 1:
      return colorMapUsingId[1]; // return "#2e7d32"; // Green
    case 0:
      return colorMapUsingId[0]; // return "#d32f2f"; // Red
    case 2:
      return colorMapUsingId[2]; // return "#f3c106";
    case 3: //MAINTENANCE true
      if (site.maintenanceType == 1) {
        return colorMapUsingId[3]; // return "#b8860b"; // Orange
      } else if (site.maintenanceType == 2) {
        return colorMapUsingId[4]; // return "#34b8b8";
      }
      break;
    default:
      return "#757575"; // Grey (Default/Unknown)
  }
};

const getBlinkColor = (maintenanceType) => {
  console.log(maintenanceType, "dfmbhfgjfdh");

  if (maintenanceType === 1) {
    return colorMapUsingId[3]; // Non-OPS
  }

  if (maintenanceType === 2) {
    return colorMapUsingId[4]; // R-OPS
  }

  if (maintenanceType == 0) {
    return colorMapUsingId[1];
  }

  if (maintenanceType == "UP") {
    return colorMapUsingId[1];
  }
  if (maintenanceType == "DOWN") {
    return colorMapUsingId[0];
  }
  if (maintenanceType == "NMSDOWN") {
    return colorMapUsingId[2];
  }

  return "#f3c108";
};

// Create dynamic CNMS Icon using SVG
export const getCnmsIcon = (cnms) => {
  const terminalType = cnms.imTerminalType?.terminalTypeName || "CNMS";
  const siteName = cnms.siteName || "";
  return L.divIcon({
    className: "custom-cnms-svg-icon",
    html: `
      <div style="display: flex; flex-direction: column; align-items: center;">
        <div style="display: flex; align-items: center; justify-content: center; ">
            <img src="${DCicon}" alt="CNMS" style="width: 20px; height: 20px;" />
        </div>
        <div style=" text-align: center;  white-space: nowrap; color:black ">
          ${terminalType} ${siteName}
        </div>
      </div>
        `,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
};

export const getCommaSeparatedGroupNames = (groupList) => {
  if (!Array.isArray(groupList)) {
    return "";
  }

  return groupList
    .map((group) => group.groupName)
    .filter((name) => name && name.trim() !== "") // Added trim check for safety
    .join(", ");
};

// Create dynamic Site Map Pin Icon with real-time WebSocket status color
export const getSiteIcon = (
  site,
  currentStatusNum,
  isBlinking = false,
  maintenanceType = null
) => {
  const pinColor = getStatusColor(currentStatusNum, site);
  const blinkColor = getBlinkColor(maintenanceType);
  // const groupNames = getCommaSeparatedGroupNames(site?.groupList);
  return L.divIcon({
    className: "custom-site-svg-icon",
    html: `
    <div
      class="${isBlinking ? "maintenance-blink-ring" : ""}"
      style="
        --blink-color: ${blinkColor};
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 50%;
      "
    >
      <svg
        viewBox="0 0 24 24"
        width="30"
        height="30"
        fill="${pinColor}"
        style="filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.3));"
      >
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
      </svg>
    </div>
  `,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
  });
};
