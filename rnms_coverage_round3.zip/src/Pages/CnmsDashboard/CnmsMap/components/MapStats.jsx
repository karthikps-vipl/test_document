import React, { useMemo } from "react";
import { Box } from "@mui/material";
import { colorMapUsingId, healthStatusMap } from "./maputils";

const STATUS_CONFIG = [
  {
    id: healthStatusMap.UP,
    name: "Online",
    color: colorMapUsingId[healthStatusMap.UP],
  },
  {
    id: healthStatusMap.DOWN,
    name: "Offline",
    color: colorMapUsingId[healthStatusMap.DOWN],
  },
  {
    id: healthStatusMap.OPERATIONAL_DOWN,
    name: "RNMS Down",
    color: colorMapUsingId[healthStatusMap.OPERATIONAL_DOWN],
  },
  {
    id: healthStatusMap.MAINTENANCE,
    name: "Maintenance Non-OPS",
    color: colorMapUsingId[healthStatusMap.MAINTENANCE],
  },
  {
    id: healthStatusMap["R-OPS"],
    name: "Maintenance R-OPS",
    color: colorMapUsingId[healthStatusMap["R-OPS"]],
  },
];

const EMPTY_COUNTS = {
  0: 0,
  1: 0,
  2: 0,
  MAN: 0,
  ROPS: 0,
};

const getSiteStatusKey = (site) => {
  if (site.isMaintainance) {
    return site.maintenanceType === 1 ? "MAN" : "ROPS";
  }

  return String(site.healthStatus?.id ?? 0);
};

const MapStats = ({ sitesToDisplay = [], fullScreen = false }) => {
  const { counts, totalCount } = useMemo(() => {
    const terminalCounts = {};
    const totals = {
      0: 0,
      1: 0,
      2: 0,
      MAN: 0,
      ROPS: 0,
    };

    sitesToDisplay.forEach((site) => {
      // CNMS should not be included in the site statistics.
      const terminalType = site.imTerminalType?.terminalTypeName;

      if (terminalType === "CNMS") {
        return;
      }

      const status = getSiteStatusKey(site);

      // Create terminal bucket.
      if (!terminalCounts[terminalType]) {
        terminalCounts[terminalType] = {
          ...EMPTY_COUNTS,
        };
      }

      // Increment terminal count.
      if (terminalCounts[terminalType][status] !== undefined) {
        terminalCounts[terminalType][status] += 1;
      }

      // Increment overall count.
      if (totals[status] !== undefined) {
        totals[status] += 1;
      }
    });

    return {
      counts: terminalCounts,
      totalCount: totals,
    };
  }, [sitesToDisplay]);

  const getTerminalTotal = (terminalCount) => {
    return (
      terminalCount[healthStatusMap.UP] +
      terminalCount[healthStatusMap.DOWN] +
      terminalCount[healthStatusMap.OPERATIONAL_DOWN] +
      terminalCount.MAN +
      terminalCount.ROPS
    );
  };

  const grandTotal =
    totalCount[healthStatusMap.UP] +
    totalCount[healthStatusMap.DOWN] +
    totalCount[healthStatusMap.OPERATIONAL_DOWN] +
    totalCount.MAN +
    totalCount.ROPS;

  if (!Object.keys(counts).length) {
    return null;
  }

  return (
    <Box
      sx={{
        position: "absolute",
        bottom: fullScreen ? "40px" : "20px",
        right: "20px",
        zIndex: 10,
        backgroundColor: "background.paper",
        borderRadius: "15px",
        overflow: "hidden",
        // boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
        border: "1px solid grey",
      }}
    >
      <table
        style={{
          borderCollapse: "collapse",
          fontSize: "0.7rem",
        }}
      >
        <thead>
          <tr>
            <th style={col1Style}>Terminal</th>

            {STATUS_CONFIG.map((status) => (
              <th
                key={status.id}
                style={{
                  backgroundColor: status.color,
                  paddingLeft: "5px",
                  paddingRight: "5px",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    gap: "4px",
                    alignItems: "center",
                    justifyContent: "center",
                    whiteSpace: "nowrap",
                  }}
                >
                  <span>{status.name}</span>
                </Box>
              </th>
            ))}

            <th style={col1Style}>Total</th>
          </tr>
        </thead>

        <tbody>
          {Object.entries(counts).map(([terminalType, terminalCount]) => (
            <tr key={terminalType}>
              <td style={cellStyle}>{terminalType}</td>

              <td style={cellStyle}>{terminalCount[healthStatusMap.UP]}</td>

              <td style={cellStyle}>{terminalCount[healthStatusMap.DOWN]}</td>

              <td style={cellStyle}>
                {terminalCount[healthStatusMap.OPERATIONAL_DOWN]}
              </td>

              <td style={cellStyle}>{terminalCount.MAN}</td>

              <td style={cellStyle}>{terminalCount.ROPS}</td>

              <td
                style={{
                  ...cellStyle,
                  fontWeight: "bold",
                }}
              >
                {getTerminalTotal(terminalCount)}
              </td>
            </tr>
          ))}

          {/* GRAND TOTAL */}
          <tr>
            <td
              style={{
                ...cellStyle,
                fontWeight: "bold",
              }}
            >
              Total
            </td>

            <td style={boldCellStyle}>{totalCount[healthStatusMap.UP]}</td>

            <td style={boldCellStyle}>{totalCount[healthStatusMap.DOWN]}</td>

            <td style={boldCellStyle}>
              {totalCount[healthStatusMap.OPERATIONAL_DOWN]}
            </td>

            <td style={boldCellStyle}>{totalCount.MAN}</td>

            <td style={boldCellStyle}>{totalCount.ROPS}</td>

            <td style={boldCellStyle}>{grandTotal}</td>
          </tr>
        </tbody>
      </table>
    </Box>
  );
};

const cellStyle = {
  fontSize: "0.7rem",
  padding: "5px 7px",
  border: "1px solid #bdbdbd",
  textAlign: "center",
  whiteSpace: "nowrap",
};

const col1Style = {
  fontSize: "0.7rem",
  padding: "5px 7px",

  textAlign: "center",
  whiteSpace: "nowrap",
};

const headerCellStyle = {
  ...cellStyle,
  fontWeight: "bold",
  borderColor: "rgba(255,255,255,0.3)",
};

const boldCellStyle = {
  ...cellStyle,
  fontWeight: "bold",
};

export default MapStats;
