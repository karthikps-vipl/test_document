import { Box } from "@mui/material";
import { useEffect, useState } from "react";
import { useMap } from "react-leaflet";

export const LiveCordinates = () => {
  const map = useMap();

  const [cordinate, setCordinate] = useState({});

  useEffect(() => {
    if (!map) return;
    map.addEventListener("mousemove", (e) => {
      setCordinate({ lat: e.latlng.lat, lng: e.latlng.lng });
    });
  }, [cordinate]);

  return (
    <Box
      data-testid="live-coordinates"
      display={"block"}
      zIndex={1000}
      fontSize={"sm"}
      padding={"3px"}
      position={"absolute"}
      left={"10px"}
      bottom={"5px"}
      width={"auto"}
      borderRadius={"2px"}
      color={"black"}
    >
      Latitude: {cordinate?.lat?.toFixed(4)} | Longitude:
      {cordinate?.lng?.toFixed(4)}
    </Box>
  );
};
