import React from "react";
import { useMap } from "react-leaflet";
import { Box, useTheme } from "@mui/material";

import FullscreenIcon from "@mui/icons-material/Fullscreen";

import FitScreen from "@/assets/CNMS/Fit Screen.svg";

import { FullscreenExit } from "@mui/icons-material";
import { SquareIconButton } from "@/components/Reusable/Modal/MModal";

export const MapControls = ({
  allCnms,
  allSites,
  onToggleFullscreen,
  isFullscreen,
}) => {
  const map = useMap();
  const theme = useTheme();

  const handleFitView = () => {
    const points = [];
    allCnms.forEach((c) => points.push([c.latitude, c.longitude]));
    allSites.forEach((s) => points.push([s.latitude, s.longitude]));

    if (points.length > 0) {
      // const bounds = L.latLngBounds(points);
      // map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
      map.setView([23.5937, 78.9029], 5);
    }
  };

  return (
    <Box
      sx={{
        position: "absolute",
        top: 80,
        left: "10px",
        zIndex: 1000,
        display: "flex",
        flexDirection: "column",
        gap: 1,
      }}
    >
      <button
        onClick={handleFitView}
        title="Fit to Screen"
        style={{
          backgroundColor: "#ffffff",
          display: "flex",
          justifyContent: "center",
          width: "33.6px",
          height: "33px",
          border: "2px solid rgba(0,0,0,0.2)",
          backgroundClip: "padding-box",
          borderRadius: "4px",
          marginTop: "3px",
        }}
      >
        <img src={FitScreen} width={"100%"} height={"auto"} alt="fit-screen" />
      </button>

      <SquareIconButton
        onClick={onToggleFullscreen}
        sx={{
          backgroundColor: theme.palette.mode === "dark" ? "black" : "white",
          display: "flex",
          justifyContent: "center",
          width: "33.6px",
          height: "33px",
          border: "2px solid rgba(0,0,0,0.2)",
          backgroundClip: "padding-box",
          borderRadius: "4px",
        }}
        title={`${isFullscreen ? "Exit full screen" : "Enter full screen"}`}
      >
        {isFullscreen ? (
          <FullscreenExit size={20} />
        ) : (
          <FullscreenIcon size={20} />
        )}
      </SquareIconButton>
    </Box>
  );
};
