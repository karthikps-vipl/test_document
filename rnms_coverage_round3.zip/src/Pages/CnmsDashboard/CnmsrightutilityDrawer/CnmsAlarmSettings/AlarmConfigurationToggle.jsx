import React from "react";
import { useSelector } from "react-redux";
import AlarmConfigurationCnms from "./AlarmConfigurationCnms";
import AlarmConfiguration from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/AlarmSettings/AlarmConfiguration";

const AlarmConfigurationToggle = () => {
  const { isCnms } = useSelector((state) => state.nodeDetails);

  return (
    <>{isCnms ? <AlarmConfigurationCnms /> : <AlarmConfiguration />}</>
  );
};

export default AlarmConfigurationToggle;
