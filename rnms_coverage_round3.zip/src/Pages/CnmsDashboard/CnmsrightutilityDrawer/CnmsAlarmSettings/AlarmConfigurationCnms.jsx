import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Checkbox,
  CircularProgress,
  MenuItem,
  Select,
  useTheme,
} from "@mui/material";
import { Update } from "@mui/icons-material";
import { useSelector } from "react-redux";

import MTable from "@/components/Reusable/Table/MTable";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";

import { severityConfig } from "@/lib/utils";
import {
  ALL_ALARM_TYPE_CNMS_BY_TERMINAL_TYPE_ID,
  FETCH_RESOURCE_MASTER_TYPE_BASED_ON_TERMINAL_ID,
  GET_ALL_ALARM_TYPE_CNMS,
  UPDATE_ALARM_TYPE_CNMS,
} from "@/RestAPI/url/cnmsEndPoint";
import { FaultAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";

const AlarmConfigurationCnms = ({ privilegeKey }) => {
    const theme = useTheme();
    const isDark = theme.palette.mode === 'dark';
  const terminalList = useSelector(
    (state) => state.remoteRepDetails?.fetchAllTerminalTypeAlongWithSite || []
  );
  console.log("terminalList", terminalList);
  const [selectedTerminal, setSelectedTerminal] = useState(null);
  const [selectedDevice, setSelectedDevice] = useState(null);

  const [deviceOptions, setDeviceOptions] = useState([]);

  const [alarmData, setAlarmData] = useState([]);
  const [originalAlarmData, setOriginalAlarmData] = useState([]);

  const [selectedRows, setSelectedRows] = useState(new Set());

  const [loadingDevices, setLoadingDevices] = useState(false);
  const [loadingTable, setLoadingTable] = useState(false);
  const [updating, setUpdating] = useState(false);

  const terminalOptions = useMemo(() => {
    if (!Array.isArray(terminalList)) {
      return [];
    }

    return terminalList.map((terminal) => ({
      label:
        terminal?.terminalTypeName ||
        terminal?.terminalNickname ||
        terminal?.name ||
        `Terminal ${terminal?.id}`,
      value: terminal?.id,
      ...terminal,
    }));
  }, [terminalList]);
  const cnmsTerminalId = useMemo(() => {
    const cnmsTerminal = terminalOptions.find(
      (terminal) =>
        String(terminal?.terminalTypeName || "")
          .trim()
          .toUpperCase() === "CNMS"
    );

    return cnmsTerminal?.id ?? cnmsTerminal?.value ?? null;
  }, [terminalOptions]);

  const isCnmsTerminal =
    cnmsTerminalId != null &&
    String(selectedTerminal?.id) === String(cnmsTerminalId);
  // const severityOptions = [
  //   {
  //     label: "Warning",
  //     value: 0,
  //   },
  //   {
  //     label: "Minor",
  //     value: 1,
  //   },
  //   {
  //     label: "Major",
  //     value: 2,
  //   },
  // ];

  // useEffect(() => {
  //   const fetchDevices = async () => {
  //     setSelectedDevice(null);
  //     setDeviceOptions([]);
  //     setAlarmData([]);
  //     setOriginalAlarmData([]);
  //     setSelectedRows(new Set());

  //     if (!selectedTerminal?.id) {
  //       return;
  //     }

  //     try {
  //       setLoadingDevices(true);

  //       const response = await InventoryAxios(
  //         `${FETCH_RESOURCE_MASTER_TYPE_BASED_ON_TERMINAL_ID}/${selectedTerminal.id}`,
  //         "get"
  //       );

  //       const rawData = Array.isArray(response.data)
  //         ? response.data
  //         : Object.values(response.data || {});

  //       const formattedDevices = rawData.map((item) => ({
  //         label:
  //           item?.resourceNickName ||
  //           item?.resourceTypeName ||
  //           `Device ${item?.resourceTypeId}`,

  //         value: item?.resourceTypeId,

  //         resourceTypeId: item?.resourceTypeId,
  //         resourceNickName: item?.resourceNickName,
  //         resourceTypeName: item?.resourceTypeName,

  //         make: item?.make,
  //         model: item?.model,

  //         terminalId: item?.terminalId?.id || selectedTerminal?.id,

  //         terminalDetails: item?.terminalId,

  //         ...item,
  //       }));

  //       setDeviceOptions(formattedDevices);
  //     } catch (error) {
  //       console.error("Error fetching devices:", error);
  //       Toast("Error", "Failed to load devices", "error");
  //       setDeviceOptions([]);
  //     } finally {
  //       setLoadingDevices(false);
  //     }
  //   };

  //   fetchDevices();
  // }, [selectedTerminal]);
  useEffect(() => {
    const fetchDevices = async () => {
      setSelectedDevice(null);
      setDeviceOptions([]);
      setAlarmData([]);
      setOriginalAlarmData([]);
      setSelectedRows(new Set());

      if (selectedTerminal?.id == null) {
        return;
      }

      // CNMS: fetch alarm types directly using the terminal ID.
      if (isCnmsTerminal) {
        setLoadingDevices(false);
        setLoadingTable(true);

        try {
          const response = await FaultAxios(
            `${ALL_ALARM_TYPE_CNMS_BY_TERMINAL_TYPE_ID}/${selectedTerminal.id}`,
            "get"
          );

          const rawData = Array.isArray(response.data)
            ? response.data
            : Object.values(response.data || {});

          const formattedData = rawData.map((alarm, index) => ({
            ...alarm,
            sln: index + 1,
            id: alarm?.alarmTypeId ?? `cnms-${index}`,
            alarmName: alarm?.alarmName || "",
            alarmDescription: alarm?.alarmDescription || "",
            alarmTypeId: alarm?.alarmTypeId,
            severity: alarm?.severity != null ? Number(alarm.severity) : 0,
            isForwardHigherNms: Boolean(alarm?.isForwardHigherNms),
            isLocalProcessing: Boolean(alarm?.isLocalProcessing),
            imTerminalType: alarm?.imTerminalType || selectedTerminal,
          }));

          setAlarmData(formattedData);
          setOriginalAlarmData(formattedData);
        } catch (error) {
          console.error("Error fetching CNMS alarm details:", error);
          Toast("Error", "Failed to load alarm configuration", "error");
          setAlarmData([]);
          setOriginalAlarmData([]);
        } finally {
          setLoadingTable(false);
        }

        return;
      }

      // Other terminals: retain the existing device-fetching API.
      try {
        setLoadingDevices(true);

        const response = await InventoryAxios(
          `${FETCH_RESOURCE_MASTER_TYPE_BASED_ON_TERMINAL_ID}/${selectedTerminal.id}`,
          "get"
        );

        const rawData = Array.isArray(response.data)
          ? response.data
          : Object.values(response.data || {});

        const formattedDevices = rawData.map((item) => ({
          label:
            item?.resourceNickName ||
            item?.resourceTypeName ||
            `Device ${item?.resourceTypeId}`,
          value: item?.resourceTypeId,
          resourceTypeId: item?.resourceTypeId,
          resourceNickName: item?.resourceNickName,
          resourceTypeName: item?.resourceTypeName,
          make: item?.make,
          model: item?.model,
          terminalId: item?.terminalId?.id || selectedTerminal.id,
          terminalDetails: item?.terminalId,
          ...item,
        }));

        setDeviceOptions(formattedDevices);
      } catch (error) {
        console.error("Error fetching devices:", error);
        Toast("Error", "Failed to load devices", "error");
        setDeviceOptions([]);
      } finally {
        setLoadingDevices(false);
      }
    };

    fetchDevices();
  }, [selectedTerminal, isCnmsTerminal]);

  useEffect(() => {
    const fetchAlarmDetails = async () => {
      if (isCnmsTerminal) {
        return;
      }
      if (!selectedTerminal?.id || !selectedDevice?.resourceTypeId) {
        setAlarmData([]);
        setOriginalAlarmData([]);
        setSelectedRows(new Set());
        return;
      }

      try {
        setLoadingTable(true);
        setSelectedRows(new Set());

        const terminalId = selectedDevice?.terminalId || selectedTerminal?.id;

        const resourceTypeId = selectedDevice?.resourceTypeId;
        const url = `${GET_ALL_ALARM_TYPE_CNMS}/${terminalId?.id}/${resourceTypeId}`;
        console.log("selectedDeviceselectedDevice", selectedDevice);
        const response = await FaultAxios(url, "get");

        const rawData = Array.isArray(response.data)
          ? response.data
          : Object.values(response.data || {});

        const formattedData = rawData.map((alarm, index) => {
          return {
            ...alarm,

            sln: index + 1,
            id: alarm?.alarmTypeId || `${resourceTypeId}-${index}`,

            alarmName: alarm?.alarmName || "",
            alarmDescription: alarm?.alarmDescription || "",

            alarmTypeId: alarm?.alarmTypeId,

            severity:
              alarm?.severity !== null && alarm?.severity !== undefined
                ? Number(alarm.severity)
                : 0,

            isForwardHigherNms: Boolean(alarm?.isForwardHigherNms),

            isLocalProcessing: Boolean(alarm?.isLocalProcessing),
            imResourceType: alarm?.imResourceType || selectedDevice,

            imTerminalType: alarm?.imTerminalType || selectedTerminal,
          };
        });

        setAlarmData(formattedData);
        setOriginalAlarmData(formattedData);
      } catch (error) {
        console.error("Error fetching CNMS alarm details:", error);

        Toast("Error", "Failed to load alarm configuration", "error");

        setAlarmData([]);
        setOriginalAlarmData([]);
      } finally {
        setLoadingTable(false);
      }
    };

    fetchAlarmDetails();
  }, [selectedTerminal, selectedDevice, isCnmsTerminal]);

  const handleRowSelect = (id, checked) => {
    const stringId = String(id);

    const updated = new Set(selectedRows);

    if (checked) {
      updated.add(stringId);
    } else {
      updated.delete(stringId);
    }

    setSelectedRows(updated);
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      const allIds = new Set(alarmData.map((row) => String(row.id)));

      setSelectedRows(allIds);
    } else {
      setSelectedRows(new Set());
    }
  };
  const handleSeverityChange = (id, newSeverity) => {
    setAlarmData((prev) =>
      prev.map((row) =>
        String(row.id) === String(id)
          ? {
              ...row,
              severity: Number(newSeverity),
            }
          : row
      )
    );
  };
  const handleBooleanChange = (id, field, value) => {
    setAlarmData((prev) =>
      prev.map((row) =>
        String(row.id) === String(id)
          ? {
              ...row,
              [field]: Boolean(value),
            }
          : row
      )
    );
  };
  const isDirty = useMemo(() => {
    return JSON.stringify(alarmData) !== JSON.stringify(originalAlarmData);
  }, [alarmData, originalAlarmData]);

  const handleUpdate = async () => {
    const selectedAlarmRows = alarmData.filter((row) =>
      selectedRows.has(String(row.id))
    );

    if (selectedAlarmRows.length === 0) {
      Toast("Info", "Please select at least one row to update", "info");
      return;
    }

    try {
      setUpdating(true);

      /*
       * Build exactly the payload expected by:
       *
       * POST /fault/updateAlarmTypeCnms
       */

      const payload = selectedAlarmRows.map((row) => {
        const terminalId = selectedTerminal?.id || row?.imTerminalType?.id;

        const resourceTypeId =
          selectedDevice?.resourceTypeId || row?.imResourceType?.resourceTypeId;

        const resourceTypeObject = row?.imResourceType || selectedDevice;

        const terminalObject = row?.imTerminalType || selectedTerminal;

        return {
          alarmDescription: row?.alarmDescription || "",
          alarmName: row?.alarmName || "",

          alarmTypeId: row?.alarmTypeId,

          imResourceType: {
            ...resourceTypeObject,

            resourceTypeId:
              resourceTypeObject?.resourceTypeId || resourceTypeId,

            terminalId: resourceTypeObject?.terminalId ||
              selectedDevice?.terminalDetails || {
                id: terminalId,
              },
          },

          imTerminalType: {
            ...terminalObject,

            id: terminalObject?.id || terminalId,
          },

          isClear: row?.isClear ?? false,

          isConfigurable: row?.isConfigurable ?? true,

          isForwardHigherNms: Boolean(row?.isForwardHigherNms),

          isLocalProcessing: Boolean(row?.isLocalProcessing),

          severity: Number(row?.severity),

          trapOid: row?.trapOid || null,
        };
      });

      console.log("UPDATE_ALARM_TYPE_CNMS payload:", payload);

      const response = await FaultAxios(
        UPDATE_ALARM_TYPE_CNMS,
        "post",
        payload
      );

      console.log("UPDATE_ALARM_TYPE_CNMS response:", response);
      if (response?.data === true || response?.data === "true") {
        Toast("Success", "Alarm configuration updated successfully", "success");
        setOriginalAlarmData(JSON.parse(JSON.stringify(alarmData)));

        setSelectedRows(new Set());
      } else {
        Toast("Error", "Failed to update alarm configuration", "error");
      }
    } catch (error) {
      console.error("Error updating CNMS alarm configuration:", error);

      Toast("Error", "Failed to update alarm configuration", "error");
    } finally {
      setUpdating(false);
    }
  };

  const columns = [
    {
      name: "S. No",
      uid: "sln",
      width: "80px",
    },

    {
      name: "Alarm Name",
      uid: "alarmName",
    },

    {
      name: "Description",
      uid: "alarmDescription",
      width: "250px",
    },

    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      width: "160px",

      render: (value, row) => {
        const rowSelected = selectedRows.has(String(row.id));

        const currentSeverity = Number(value ?? 0);

        return (
          <Select
            size="small"
            value={currentSeverity}
            disabled={!rowSelected}
            onChange={(e) =>
              handleSeverityChange(row.id, Number(e.target.value))
            }
            renderValue={(selected) => {
              const config = severityConfig[String(selected)];

              if (!config) {
                return selected;
              }

              return (
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  }}
                >
                  <Box
                    sx={{
                      width: 12,
                      height: 12,
                      borderRadius: "50%",
                      flexShrink: 0,
                      background: `linear-gradient(
                          135deg,
                          ${config.gradient[0]},
                          ${config.gradient[1]}
                        )`,
                    }}
                  />

                  <span>{config.label}</span>
                </Box>
              );
            }}
            sx={{
              width: "130px",
              height: "36px",

              "& .MuiOutlinedInput-notchedOutline": {
                border: rowSelected ? "1px solid #ccc" : "none",
              },

              "&:hover .MuiOutlinedInput-notchedOutline": {
                border: rowSelected ? "1px solid #999" : "none",
              },

              "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                border: "1px solid #1976d2",
              },

              "& .MuiSelect-select": {
                padding: "6px 32px 6px 10px",
                display: "flex",
                alignItems: "center",
              },
            }}
          >
            {Object.entries(severityConfig)
              .filter(([key]) => ["0", "1", "2"].includes(key))
              .map(([key, config]) => (
                <MenuItem key={key} value={Number(key)}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <Box
                      sx={{
                        width: 12,
                        height: 12,
                        borderRadius: "50%",
                        flexShrink: 0,
                        background: `linear-gradient(
                            135deg,
                            ${config.gradient[0]},
                            ${config.gradient[1]}
                          )`,
                      }}
                    />

                    <span>{config.label}</span>
                  </Box>
                </MenuItem>
              ))}
          </Select>
        );
      },
    },

    {
      name: "Forward to CNMS",
      uid: "isForwardHigherNms",
      width: "170px",
      filterType: "dropdown", // Added filter type
      filterOptions: [
        // Added filter options
        { label: "Yes", value: true },
        { label: "No", value: false },
      ],
      render: (value, row) => {
        const rowSelected = selectedRows.has(String(row.id));

        return (
          <Checkbox
            checked={Boolean(value)}
            disabled={!rowSelected}
            onChange={(e) =>
              handleBooleanChange(
                row.id,
                "isForwardHigherNms",
                e.target.checked
              )
            }
          />
        );
      },
    },

    {
      name: "Process at RNMS",
      uid: "isLocalProcessing",
      width: "170px",
      filterType: "dropdown", // Added filter type
      filterOptions: [
        // Added filter options
        { label: "Yes", value: true },
        { label: "No", value: false },
      ],
      render: (value, row) => {
        const rowSelected = selectedRows.has(String(row.id));

        return (
          <Checkbox
            checked={Boolean(value)}
            disabled={!rowSelected}
            onChange={(e) =>
              handleBooleanChange(row.id, "isLocalProcessing", e.target.checked)
            }
          />
        );
      },
    },
  ];

  return (
    <Box>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 2,
          mb: 2,
        }}
      >
        {/* TERMINAL */}

        <MAlarmSelect
          label="Select Terminal *"
          options={terminalOptions}
          value={selectedTerminal ? selectedTerminal.id : ""}
          onChange={(value) => {
            const terminal = terminalOptions.find(
              (option) => option.value === value
            );

            setSelectedTerminal(terminal || null);
          }}
          multiple={false}
          style={{
            width: "220px",
            height: "40px",
          }}
          isDark={isDark}

        />

        {/* DEVICE */}

        {!isCnmsTerminal && (
          <MAlarmSelect
          label="Select Device *"
            options={deviceOptions}
            value={selectedDevice ? selectedDevice.resourceTypeId : ""}
            onChange={(value) => {
              const device = deviceOptions.find(
                (option) => option.value === value
              );

              setSelectedDevice(device || null);
            }}
            multiple={false}
            disabled={!selectedTerminal || loadingDevices}
            style={{
              width: "220px",
              height: "40px",
            }}
            isDark={isDark}
          />
        )}

        {loadingDevices && <CircularProgress size={22} />}
      </Box>

      {loadingTable ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <>
          <MTable
            privilegeKey={privilegeKey}
            tableTitle="Alarm Configuration"
            columns={columns}
            tableData={alarmData}
            showPagination={true}
            showSearch={true}
            enableRowSelection={true}
            selectedRowsNew={selectedRows}
            onRowSelect={handleRowSelect}
            onSelectAll={handleSelectAll}
            rowIdKey="id"
          />
          <Box
            sx={{
              m: 1,
              display: "flex",
              justifyContent: "flex-end",
              gap: 2,
            }}
          >
            <MButtonPrimary
              variant="contained"
              color="primary"
              sx={{
                borderRadius: "8px",
                px: 4,
              }}
              onClick={handleUpdate}
              disabled={!isDirty || updating || selectedRows.size === 0}
              startIcon={
                updating ? (
                  <CircularProgress size={20} color="inherit" />
                ) : (
                  <Update />
                )
              }
            >
              {updating ? "Updating..." : "Update"}
            </MButtonPrimary>
          </Box>
        </>
      )}
    </Box>
  );
};

export default AlarmConfigurationCnms;
