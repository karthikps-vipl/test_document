import React, { useEffect, useMemo, useState, useCallback } from "react";
import { Box, Typography, CircularProgress, Tabs, Tab } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";

import Toast from "@/components/Reusable/Toast/Toast";

import { InventoryAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL,
  GET_ALL_PRIVILEGES,
  ADD_GROUP,
} from "@/RestAPI/url/endpoint";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MSelect from "@/components/Reusable/Select/MSelect";
import FormField from "@/components/Reusable/Form/FormField";
import PrivilegeTree from "../UserManagement/PrivilegeTree";
import DevicePrivilegesTable from "../UserManagement/DevicePrivilegesTable";

const CAPABILITY_SUFFIXES = [
  "cross_launch",
  "add_maintain",
  "inventory",
  "fault",
  "status",
  "config",
];

const BACKEND_CAPABILITY_MAP = {
  inventory: "inventory",
  fault: "fault",
  status: "status",
  config: "configuration",
  cross_launch: "cross_launch",
  add_maintain: "add_delete",
};

const parseCapabilityKey = (key) => {
  for (const cap of CAPABILITY_SUFFIXES) {
    const suffix = `_${cap}`;
    if (key.endsWith(suffix)) {
      return {
        resourceTypeId: key.slice(0, -suffix.length),
        capability: cap,
      };
    }
  }
  return null;
};

const GroupMgmtAdd = ({
  onClose,
  onSuccess,
  onRefresh,
  groupData = [],
  isGrandchildFullScreen,
}) => {
  /* =========================================================
     REDUX
  ========================================================= */

  const AllterminalTypes = useSelector(
    (state) => state.terminalTypes?.terminalTypes || []
  );

  const allGroups = useSelector((state) => state.groups?.allGroups || []);

  /* =========================================================
     LOCAL STATE
  ========================================================= */

  const [terminalTypes, setTerminalTypes] = useState([]);
  const [selectedTerminalId, setSelectedTerminalId] = useState(null);
  const [resources, setResources] = useState([]);
  const [loadingResources, setLoadingResources] = useState(false);
  const [privileges, setPrivileges] = useState([]);
  const [loadingPrivileges, setLoadingPrivileges] = useState(false);

  // Always numbers
  const [selectedPrivilegeIds, setSelectedPrivilegeIds] = useState([]);
  const [selectedDeviceIds, setSelectedDeviceIds] = useState([]);

  /*
   * Composite capability map built by DevicePrivilegesTable:
   *   { "901_inventory": true, "904_cross_launch": true, ... }
   * This is ALREADY in the backend key format.
   */
  const [selectedTypeCapabilities, setSelectedTypeCapabilities] = useState({});

  const [tabValue, setTabValue] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  /* =========================================================
     INITIAL FORM DATA
  ========================================================= */

  const InitialData = {
    terminalTypeName: "",
    rnmsDetailId: "",
    siteNameId: "",
    groupName: "",
    userName: "",
    lastName: "",
  };

  /* =========================================================
     VALIDATION
  ========================================================= */

  const schema = Yup.object({
    terminalTypeName: Yup.string().trim().required("Terminal is required"),

    userName: Yup.string()
      .trim()
      .required("Suffix is required")
      .min(3, "  Name should be between 3-10 Characters.")
      .max(10, " Name  should be between 3-10 Characters."),

    lastName: Yup.string()
      .trim()
      .required("Description is required")
      .min(10, "Description should be between 10-256 alphanumeric Characters.")
      .max(256, "Description should be between 10-256 alphanumeric Characters.")
      .matches(/^[a-zA-Z0-9 ]*$/, "Description must be alphanumeric"),
  });

  /* =========================================================
     FORMIK
  ========================================================= */

  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: async (values) => {
      await handleSuccess(values);
    },
  });

  /* =========================================================
     TERMINAL TYPES
  ========================================================= */

  useEffect(() => {
    if (Array.isArray(AllterminalTypes)) {
      setTerminalTypes(AllterminalTypes);
    }
  }, [AllterminalTypes]);

  /* =========================================================
     CNMS
  ========================================================= */

  const isCNMS = useMemo(() => {
    const name = formik.values.terminalTypeName || "";
    return name.toUpperCase().includes("CNMS");
  }, [formik.values.terminalTypeName]);

  const isCNMSTerminal = isCNMS || String(selectedTerminalId) === "1";

  /* =========================================================
     FORM ERROR
  ========================================================= */

  const getError = (field) => {
    if (!formik.touched[field]) return "";
    return formik.errors[field] || "";
  };

  /* =========================================================
     INPUT CHANGE
  ========================================================= */

  const handleInputChange = (field) => (event) => {
    let value = event?.target?.value ?? "";
    if (field === "userName") {
      if (value.length > 10) {
        value = value.slice(0, 10); // Force the value to stop at 10 chars
      }
    }

    if (field === "lastName") {
      if (value.length > 256) {
        value = value.slice(0, 256); // Force the value to stop at 10 chars
      }
    }
    formik.setFieldValue(field, value, true);
    formik.setFieldTouched(field, true, true);
  };

  /* =========================================================
     GENERAL PRIVILEGE — cascade parent -> children
  ========================================================= */

  const getDescendantPrivilegeIds = useCallback((parentId, list) => {
    const result = [];
    const visited = new Set();

    const walk = (pid) => {
      list.forEach((item) => {
        const itemParentId =
          item?.parentId ??
          item?.parent_id ??
          item?.parentPrivilegeId ??
          item?.parent;

        if (itemParentId === null || itemParentId === undefined) return;
        if (String(itemParentId) !== String(pid)) return;

        const childId = Number(item?.id);
        if (Number.isNaN(childId) || visited.has(childId)) return;

        visited.add(childId);
        result.push(childId);
        walk(childId);
      });
    };

    walk(parentId);
    return result;
  }, []);

  const handleTogglePrivilege = (id) => {
    const numericId = Number(id);
    if (Number.isNaN(numericId)) return;

    setSelectedPrivilegeIds((previous) => {
      const current = previous.map(Number);

      const descendantIds = getDescendantPrivilegeIds(numericId, privileges);

      if (current.includes(numericId)) {
        const removeSet = new Set([numericId, ...descendantIds]);
        return current.filter((item) => !removeSet.has(item));
      }

      const nextSet = new Set([...current, numericId, ...descendantIds]);
      return Array.from(nextSet);
    });
  };

  /* =========================================================
     GENERAL PRIVILEGE — SELECT ALL
  ========================================================= */

  const handleSelectAll = () => {
    const allIds = privileges
      .map((privilege) => Number(privilege.id))
      .filter((id) => !Number.isNaN(id));

    if (allIds.length === 0) {
      setSelectedPrivilegeIds([]);
      return;
    }

    const selectedIds = selectedPrivilegeIds.map(Number);

    const allSelected = allIds.every((id) => selectedIds.includes(id));

    setSelectedPrivilegeIds(allSelected ? [] : allIds);
  };

  const allGeneralPrivilegesSelected = useMemo(() => {
    if (privileges.length === 0) return false;

    const allIds = privileges.map((p) => Number(p.id));
    const selectedIds = selectedPrivilegeIds.map(Number);

    return allIds.every((id) => selectedIds.includes(id));
  }, [privileges, selectedPrivilegeIds]);

  /* =========================================================
     FETCH GENERAL PRIVILEGES
  ========================================================= */

  const fetchPrivileges = async (terminalId) => {
    if (!terminalId) {
      setPrivileges([]);
      setSelectedPrivilegeIds([]);
      return;
    }

    setLoadingPrivileges(true);

    try {
      const res = await SecurityAxios(
        `${GET_ALL_PRIVILEGES}/${terminalId}`,
        "get"
      );

      if (res?.status === 200 && Array.isArray(res?.data)) {
        setPrivileges(res.data);
      } else {
        setPrivileges([]);
      }
    } catch (error) {
      console.error("Error fetching privileges:", error);
      setPrivileges([]);
    } finally {
      setLoadingPrivileges(false);
    }
  };

  /* =========================================================
     FETCH DEVICE RESOURCES
  ========================================================= */

  const fetchDeviceResources = async (terminalId) => {
    if (!terminalId) {
      setResources([]);
      return;
    }

    setLoadingResources(true);

    try {
      const res = await InventoryAxios(
        `${FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL}/${terminalId}`,
        "get"
      );

      if (res?.status === 200 && Array.isArray(res?.data)) {
        setResources(res.data);
      } else {
        setResources([]);
      }
    } catch (error) {
      console.error("Error fetching resources:", error);
      setResources([]);
    } finally {
      setLoadingResources(false);
    }
  };

  /* =========================================================
     GENERATE GROUP NAME
  ========================================================= */

  const generateGroupName = (terminalLabel) => {
    const cleanTerminalName = terminalLabel.replace(/[\s-()]/g, "");

    let largestIndex = 0;

    if (Array.isArray(allGroups)) {
      allGroups.forEach((grp) => {
        if (!grp?.groupName) return;

        const prefix = `${cleanTerminalName}Group`;

        if (grp.groupName.startsWith(prefix)) {
          const match = grp.groupName.match(/\d+/);
          if (match) {
            const number = parseInt(match[0], 10);
            if (number > largestIndex) {
              largestIndex = number;
            }
          }
        }
      });
    }

    const nextNumber = String(largestIndex + 1).padStart(3, "0");

    return `${cleanTerminalName}Group${nextNumber}`;
  };

  /* =========================================================
     TERMINAL CHANGE
  ========================================================= */

  const handleTerminalChange = async (newValue) => {
    const selectedId =
      typeof newValue === "object" ? newValue?.value : newValue;

    setSelectedTerminalId(selectedId);

    setSelectedPrivilegeIds([]);
    setSelectedDeviceIds([]);
    setSelectedTypeCapabilities({});
    setPrivileges([]);
    setResources([]);
    setTabValue(0);

    if (!selectedId) {
      formik.resetForm();
      return;
    }

    const selectedTerminal = terminalTypes.find(
      (t) => String(t.value) === String(selectedId)
    );

    const terminalLabel =
      selectedTerminal?.label || selectedTerminal?.terminalTypeName || "";

    const generatedGroupName = generateGroupName(terminalLabel);

    formik.setValues(
      {
        terminalTypeName: terminalLabel,
        rnmsDetailId: "",
        siteNameId: "",
        groupName: generatedGroupName,
        userName: "",
        lastName: "",
      },
      false
    );

    formik.setTouched(
      {
        terminalTypeName: true,
        groupName: false,
        userName: false,
        lastName: false,
      },
      false
    );

    await Promise.all([
      fetchPrivileges(selectedId),
      fetchDeviceResources(selectedId),
    ]);
  };

  /* =========================================================
     TAB
  ========================================================= */

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  /* =========================================================
     BUILD DEVICE PRIVILEGES PAYLOAD
     ---------------------------------------------------------
     selectedTypeCapabilities is ALREADY in the shape
       { "901_inventory": true, "904_add_maintain": true, ... }

     We only need to rename the capability suffix where the
     backend uses a different token:
         config       -> configuration
         add_maintain -> add_delete
     Everything else (inventory, fault, status, cross_launch)
     passes through unchanged.
  ========================================================= */

  const buildDevicePrivileges = () => {
    if (isCNMSTerminal) return {};

    if (
      !selectedTypeCapabilities ||
      typeof selectedTypeCapabilities !== "object" ||
      Array.isArray(selectedTypeCapabilities)
    ) {
      return {};
    }

    const devicePrivileges = {};

    Object.entries(selectedTypeCapabilities).forEach(([key, isChecked]) => {
      if (!isChecked) return;

      const parsed = parseCapabilityKey(key);
      if (!parsed) {
        console.warn("Unknown capability key:", key);
        return;
      }

      const backendCapability = BACKEND_CAPABILITY_MAP[parsed.capability];
      if (!backendCapability) {
        console.warn("Unknown capability:", parsed.capability);
        return;
      }

      devicePrivileges[`${parsed.resourceTypeId}_${backendCapability}`] = true;
    });

    return devicePrivileges;
  };

  /* =========================================================
     DEVICE PRIVILEGE VALIDATION
  ========================================================= */

  const hasDevicePrivileges = () => {
    if (isCNMSTerminal) return true;

    if (Array.isArray(selectedDeviceIds) && selectedDeviceIds.length > 0) {
      return true;
    }

    if (
      selectedTypeCapabilities &&
      typeof selectedTypeCapabilities === "object" &&
      !Array.isArray(selectedTypeCapabilities) &&
      Object.values(selectedTypeCapabilities).some(Boolean)
    ) {
      return true;
    }

    return false;
  };

  /* =========================================================
     FORM VALIDATION
  ========================================================= */

  const isFormValid = useMemo(() => {
    const terminal = (formik.values.terminalTypeName || "").trim();
    const suffix = (formik.values.userName || "").trim();
    const description = (formik.values.lastName || "").trim();

    const terminalValid = terminal.length > 0;
    const suffixValid = suffix.length >= 3 && suffix.length <= 10;

    const descriptionValid =
      description.length >= 10 &&
      description.length <= 256 &&
      /^[a-zA-Z0-9 ]*$/.test(description);

    const generalValid =
      Array.isArray(selectedPrivilegeIds) && selectedPrivilegeIds.length > 0;

    const deviceValid = hasDevicePrivileges();

    return (
      terminalValid &&
      suffixValid &&
      descriptionValid &&
      generalValid &&
      deviceValid &&
      !loadingPrivileges &&
      !loadingResources
    );
  }, [
    formik.values.terminalTypeName,
    formik.values.groupName,
    formik.values.userName,
    formik.values.lastName,
    selectedPrivilegeIds,
    selectedDeviceIds,
    selectedTypeCapabilities,
    selectedTerminalId,
    loadingPrivileges,
    loadingResources,
    isCNMSTerminal,
  ]);

  const isAddDisabled = !isFormValid || submitting;

  /* =========================================================
     PAYLOAD
  ========================================================= */

  const buildAddPayload = (values) => {
    return {
      groupName: String(values.userName || "").trim(),

      terminalType: {
        id: Number(selectedTerminalId),
      },

      description: String(values.lastName || "").trim(),

      privileges: selectedPrivilegeIds.map((id) => ({
        id: Number(id),
      })),

      devicePrivileges: JSON.stringify(buildDevicePrivileges()),
    };
  };

  /* =========================================================
     ADD API
  ========================================================= */

  const handleSuccess = async (values) => {
    try {
      setSubmitting(true);

      const errors = await formik.validateForm();

      if (Object.keys(errors).length > 0) {
        await formik.setTouched(
          {
            terminalTypeName: true,
            groupName: true,
            userName: true,
            lastName: true,
          },
          true
        );
        return;
      }

      if (selectedPrivilegeIds.length === 0) {
        Toast(
          "Error!",
          "Please select at least one general privilege.",
          "error"
        );
        return;
      }

      if (!hasDevicePrivileges()) {
        Toast(
          "Error!",
          "Please select at least one device privilege.",
          "error"
        );
        return;
      }

      const payload = buildAddPayload(values);

      console.log("========== REQUEST ==========");
      console.log(JSON.stringify(payload, null, 2));
      console.log("==============================");

      const response = await SecurityAxios(ADD_GROUP, "post", payload);

      console.log("API RESPONSE:", response);

      if (response?.status === 200 || response?.status === 201) {
        Toast("Success!", "Group added successfully!", "success");

        if (typeof onRefresh === "function") onRefresh();
        if (typeof onSuccess === "function") onSuccess(response.data);

        setShowConfirm(false);
        formik.resetForm();

        setSelectedTerminalId(null);
        setSelectedPrivilegeIds([]);
        setSelectedDeviceIds([]);
        setSelectedTypeCapabilities({});
        setResources([]);
        setPrivileges([]);
        setTabValue(0);

        if (typeof onClose === "function") onClose();
      }
    } catch (error) {
      console.error("ADD GROUP STATUS:", error?.response?.status);
      console.error("ADD GROUP RESPONSE:", error?.response?.data);
      console.error("ADD GROUP ERROR:", error);

      Toast(
        "Error!",
        error?.response?.data?.message ||
          error?.response?.data?.error ||
          "Failed to add group.",
        "error"
      );
    } finally {
      setSubmitting(false);
    }
  };

  /* =========================================================
     CONFIRM
  ========================================================= */

  const handleConfirmAdd = async () => {
    const errors = await formik.validateForm();

    await formik.setTouched(
      {
        terminalTypeName: true,
        groupName: true,
        userName: true,
        lastName: true,
      },
      true
    );

    if (Object.keys(errors).length > 0) {
      setShowConfirm(false);
      return;
    }

    if (selectedPrivilegeIds.length === 0) {
      setShowConfirm(false);
      Toast("Error!", "Please select at least one general privilege.", "error");
      return;
    }

    if (!hasDevicePrivileges()) {
      setShowConfirm(false);
      Toast("Error!", "Please select at least one device privilege.", "error");
      return;
    }

    setShowConfirm(false);

    await handleSuccess(formik.values);
  };

  /* =========================================================
     RENDER
  ========================================================= */

  return (
    <Box
      component="form"
      onSubmit={(event) => {
        event.preventDefault();
        if (!isFormValid) return;
        setShowConfirm(true);
      }}
      className="flex flex-col gap-5"
    >
      <Box sx={{ display: "flex", flexDirection: "column", ml: 3, mr: 5 }}>
        {/* TERMINAL */}
        <Box sx={{ display: "flex", flexDirection: "column", mb: 2 }}>
          <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>
            Terminal *
          </Typography>

          <MSelect
            options={terminalTypes}
            value={selectedTerminalId}
            onChange={handleTerminalChange}
            placeholder="Select Terminal Type"
            error={getError("terminalTypeName")}
            errorMessage={getError("terminalTypeName")}
            disabled={terminalTypes.length === 0}
          />
        </Box>

        {/* PREFIX (read-only, auto-generated) */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="Group Name Prefix"
            required
            disabled
            value={formik.values.groupName || ""}
            onChange={handleInputChange("groupName")}
            onBlur={() => formik.setFieldTouched("groupName", true, true)}
            error={getError("groupName")}
            errorMessage={getError("groupName")}
          />
        </Box>

        {/* SUFFIX */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="Group Name Suffix"
            required
            value={formik.values.userName || ""}
            onChange={handleInputChange("userName")}
            onBlur={() => formik.setFieldTouched("userName", true, true)}
            error={getError("userName")}
            errorMessage={getError("userName")}
            maxLength={10}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="Description"
            required
            value={formik.values.lastName || ""}
            onChange={handleInputChange("lastName")}
            onBlur={() => formik.setFieldTouched("lastName", true, true)}
            error={getError("lastName")}
            errorMessage={getError("lastName")}
          />
        </Box>

        <Box>
          {selectedTerminalId && (
            <>
              {(tabValue === -1 || tabValue === 0) &&
                selectedPrivilegeIds.length === 0 && (
                  <Typography
                    sx={{
                      fontSize: "0.85rem",
                      color: "error.main",

                      borderRadius: 1,
                      p: 1,
                      mt: 1,
                    }}
                  >
                    Please select at least one General Privilege.
                  </Typography>
                )}

              {/* Show Device Error if on Device Tab (and not CNMS) */}
              {tabValue === 1 &&
                !isCNMSTerminal &&
                selectedDeviceIds.length === 0 &&
                !hasDevicePrivileges() && (
                  <Typography
                    sx={{
                      color: "error.main",

                      fontSize: "0.85rem",
                      p: 1,

                      borderRadius: 1,
                    }}
                  >
                    Please select at least one Device Privilege.
                  </Typography>
                )}
            </>
          )}
        </Box>
        {/* ---------------- END NEW SECTION ---------------- */}

        {/* PRIVILEGES */}
        {selectedTerminalId && (
          <Box sx={{ border: "1px solid #e0e0e0", borderRadius: 1 }}>
            {" "}
            {/* Added padding 'p: 2' */}
            <Box sx={{ borderColor: "divider" }}>
              <Tabs
                value={tabValue}
                onChange={handleTabChange}
                variant="fullWidth"
              >
                <Tab label="General Privileges" />
                {!isCNMSTerminal && <Tab label="Device Privileges" />}
              </Tabs>
            </Box>
            <Box sx={{ p: 1, minHeight: "300px" }}>
              {loadingPrivileges || loadingResources ? (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    p: 5,
                  }}
                >
                  <CircularProgress />
                </Box>
              ) : (
                <>
                  {/* Note: We removed the internal error messages here because they are now handled above */}

                  {tabValue === 0 && (
                    <Box
                      sx={{
                        border: "1px solid #eee",
                        borderRadius: 1,
                        p: 1,
                        bgcolor:
                          "background:theme.palette.custom.rightUtilityDrawer.bg",
                      }}
                    >
                      {privileges.length > 0 ? (
                        <PrivilegeTree
                          flatData={privileges}
                          selectedIds={selectedPrivilegeIds}
                          toggle={handleTogglePrivilege}
                          selectAll={handleSelectAll}
                          onToggle={handleTogglePrivilege}
                          onSelectAll={handleSelectAll}
                          allSelected={allGeneralPrivilegesSelected}
                          isReadOnly={false}
                        />
                      ) : (
                        <Typography
                          variant="body2"
                          color="textSecondary"
                          sx={{ p: 2 }}
                        >
                          No general privileges available.
                        </Typography>
                      )}
                    </Box>
                  )}

                  {tabValue === 1 && !isCNMSTerminal && (
                    <Box sx={{ border: "1px solid #eee", borderRadius: 1 }}>
                      <DevicePrivilegesTable
                        resources={resources}
                        allGroups={allGroups}
                        selectedDeviceIds={selectedDeviceIds}
                        setSelectedDeviceIds={setSelectedDeviceIds}
                        terminalId={selectedTerminalId}
                        selectedTypeCapabilities={selectedTypeCapabilities}
                        setSelectedTypeCapabilities={
                          setSelectedTypeCapabilities
                        }
                      />
                    </Box>
                  )}
                </>
              )}
            </Box>
          </Box>
        )}

        {/* ADD BUTTON */}
        <Box sx={{ display: "flex", mt: 3, justifyContent: "flex-end" }}>
          <MButtonPrimary
            type="submit"
            disabled={isAddDisabled}
            onClick={(event) => {
              if (isAddDisabled) {
                event.preventDefault();
                return;
              }
              setShowConfirm(true);
            }}
          >
            {submitting ? "Adding..." : "Add"}
          </MButtonPrimary>
        </Box>
      </Box>

      <MDialog
        open={showConfirm}
        variant="warning"
        title="Confirm Action"
        icon={question_mark}
        message="Are you sure you want to add this group?"
        onConfirm={handleConfirmAdd}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default GroupMgmtAdd;
