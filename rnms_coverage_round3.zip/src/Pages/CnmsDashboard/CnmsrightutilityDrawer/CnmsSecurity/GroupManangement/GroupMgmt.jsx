
import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useState } from "react";
import { InventoryAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall";
import {
  DELETE_GROUP,
  FETCH_ALL_TERMINAL_TYPE_DETAILS,
  GET_ALL_GROUPS,
  GET_USERS_BY_GROUP,
} from "@/RestAPI/url/endpoint";
import { Box, CircularProgress, Divider, Typography } from "@mui/material";
import Toast from "@/components/Reusable/Toast/Toast";
import MMultiSelect from "@/components/Reusable/Select/MMultiSelect";
import { useDispatch } from "react-redux";
import { setTerminalTypesData } from "@/store/features/Cnms/remoteRepDetails/terminalTypeSlice";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { PersonOutlined } from "@mui/icons-material";
import { setAllGroups } from "@/store/features/Cnms/GetAllGroups/groupSlice";

const GroupMgmt = ({
  privilegeKey,
  handleAdd,
  handleEdit,
  handleView,
  refreshTrigger,
  isChildFullScreen
}) => {
  const dispatch = useDispatch();
  const [ipData, setIpData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [terminalTypes, setTerminalTypes] = useState([]);

  const [rowToDelete, setRowToDelete] = useState({
    visible: false,
    row: null,
    users: [],
  });
  // const [isDeleting, setIsDeleting] = useState(false);

  const [selectedTerminalIds, setSelectedTerminalIds] = useState([]);

  const columns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Group Name", uid: "groupName" },
    { name: "Description", uid: "description" },
    {
      name: "Actions",
      uid: "actions",
      sortable: false,
      cellClassName: "sticky-actions",
      headerClassName: "sticky-actions",
    },
  ];

  /* =========================================================
     LOAD TERMINALS + PRE-SELECT ALL
  ========================================================= */
  useEffect(() => {
    const loadTerminals = async () => {
      try {
        const res = await InventoryAxios(FETCH_ALL_TERMINAL_TYPE_DETAILS, "get");
        const formattedData = (res?.data || []).map((t) => ({
          label: t.terminalTypeName,
          value: t.id,
          raw: t,
        }));

        dispatch(setTerminalTypesData(formattedData));
        setTerminalTypes(formattedData);

        setSelectedTerminalIds(formattedData.map((item) => item.value));
      } catch (err) {
        Toast("Error!", `Error loading terminals`, "error");
      }
    };
    loadTerminals();
  }, [dispatch]);

  const handleTerminalChange = (newValue) => {
    setSelectedTerminalIds(newValue);
  };

  /* =========================================================
     FETCH GROUPS
  ========================================================= */
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const { data } = await SecurityAxios(GET_ALL_GROUPS, "get", 1);
        console.log("Raw API data:", data);

        dispatch(setAllGroups(data || []));

        const processedData = (data || []).map((item, index) => ({
          sno: index + 1,
          groupName: item.groupName,
          description: item.description,
          terminalId: item.terminalType?.id,
          isDefaultGroup: item.isDefaultGroup,
          id: item.id,
          privileges: item.privileges,
          devicePrivileges: item.devicePrivileges,
        }));

        setIpData(processedData);
      } catch (error) {
        console.error("Error fetching IP data:", error);
        setIpData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [dispatch, refreshTrigger]);

  /* =========================================================
     FILTER
  ========================================================= */
  const filteredTableData = ipData.filter((group) =>
    selectedTerminalIds.includes(group.terminalId)
  );

  const checkDeleteDisabled = (row) => row.isDefaultGroup;
  const checkEditDisabled = (row) => row.isDefaultGroup;

  /* =========================================================
     USER LIST (for delete dialog)
  ========================================================= */
  const UserListDisplay = ({ users }) => {
    // 1. Guard clause for empty states
    if (!users || users.length === 0) return null;
  
    return (
      <Box
        sx={{
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
           maxHeight: "300px", 
        }}
      >
        <Typography 
          variant="body2" // Use variant for consistent typography scaling
          sx={{ 
            display: "block", 
            mb: 1, 
            p: 1, 
            textAlign: "center",
            fontWeight: 500 
          }}
        >
          Following users associated with the group will also be deleted:
        </Typography>
  
        {users.map((user) => (
          <Box
             
            key={user.id || user.userName} 
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              mb: 0.5,
            }}
          >
            <PersonOutlined sx={{ fontSize: 22, mr: 1, display: "inline-block" }} />
            <Typography>{user.userName}</Typography>
          </Box>
        ))}
      </Box>
    );
  };

  /* =========================================================
     DELETE
  ========================================================= */
  const handleDeleteRow = async (row) => {
    try {
      // setIsDeleting(true);

      const deletePayload = {
        id: row.id,
        description: null,
        groupName: null,
        isDefaultGroup: row.isDefaultGroup || null,
        privileges: null,
      };

      await SecurityAxios(DELETE_GROUP, "post", deletePayload);

      setIpData((prevData) => prevData.filter((item) => item.id !== row.id));
      Toast("Success!", "Group and associated user access deleted", "success");
    } catch (error) {
      console.error("Delete process failed:", error);
      Toast("Error", "Failed to process deletion", "error");
    } finally {
      // setIsDeleting(false);
    }
  };

  /* =========================================================
     RENDER
  ========================================================= */
  return (
    <Box>
      {loading ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
          }}
        >
          <CircularProgress />
        </Box>
      ) : (
        <Box
          sx={{
            marginBottom: 2,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Box sx={{ width: "100%", mb: 3, display: "flex" }}>
            <MMultiSelect
              isCompact={false}
              menuWidth="500px"
              label="Select Terminal(s) *"
              options={terminalTypes}
              value={selectedTerminalIds}
              onChange={handleTerminalChange}
              placeholder="Choose terminal type(s)..."
              sx={{
                width: "100%",
                minWidth: "auto",
                "& .MuiSelect-select": {
                  padding: "4px 12px",
                  textAlign: "left",
                },
              }}
            />
          </Box>

          <MTable
            privilegeKey={privilegeKey}
            columns={columns}
            tableData={filteredTableData}
            showPagination={true}
            showSearch={true}
            hideAdd={false}
            AddText="Add Group"
            deleteDisable={checkDeleteDisabled}
            editDisable={checkEditDisabled}
            handleAdd={() =>
              handleAdd({ mode: "CREATE", title: "Add Group Details" })
            }
            handleDelete={async (row) => {
              try {
                const res = await SecurityAxios(
                  `${GET_USERS_BY_GROUP}${row.id}`,
                  "get"
                );
                const users = res?.data || [];

                setRowToDelete({
                  visible: true,
                  row: row,
                  users: users,
                  customMessage: `Are you sure you want to delete ${row.groupName}?`,
                });
              } catch (err) {
                Toast("Error", "Could not verify users", "error");
              }
            }}
            handleEdit={(row) =>
              handleEdit({
                ...row,
                mode: "EDIT",
                title: `Edit Group: ${row.groupName}`,
              })
            }
            handleView={(row) =>
              handleView({
                ...row,
                mode: "VIEW",
                title: `View Group: ${row.groupName}`,
              })
            }
          />
        </Box>
      )}

      {rowToDelete.visible && (
        <MDialog
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          icon={Delete_Icon_}
          mode="child"
          isChildFullScreen={isChildFullScreen}
          message={
            <Box sx={{ textAlign: "center" }}>
              <Typography variant="body1" sx={{ mb: 1 }}>
                {rowToDelete.customMessage}
              </Typography>

              {rowToDelete.users.length > 0 && (
                <>
                  <Divider sx={{ my: 1 }} />
                  <UserListDisplay users={rowToDelete.users} />
                </>
              )}
            </Box>
          }
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null, users: [] });
          }}
          onClose={() =>
            setRowToDelete({ visible: false, row: null, users: [] })
          }
        />
      )}
    </Box>
  );
};

export default GroupMgmt;



