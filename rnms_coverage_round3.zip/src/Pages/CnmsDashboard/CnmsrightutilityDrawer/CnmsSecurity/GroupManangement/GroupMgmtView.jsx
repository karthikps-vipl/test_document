
import React, {
  useEffect,
  useState,
  useRef,
  useCallback,
} from "react";
import { Box, Typography, CircularProgress, Tabs, Tab } from "@mui/material";
import { useSelector } from "react-redux";

import { InventoryAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL,
  GET_ALL_PRIVILEGES,
} from "@/RestAPI/url/endpoint";

import PrivilegeTree from "../UserManagement/PrivilegeTree";
import DevicePrivilegesTable from "../UserManagement/DevicePrivilegesTable";

/* =========================================================
   CAPABILITY CONSTANTS
========================================================= */
const UI_CAPABILITY_SUFFIXES = [
  "cross_launch",
  "add_maintain",
  "inventory",
  "fault",
  "status",
  "config",
];

const BACKEND_CAPABILITY_SUFFIXES = [
  "cross_launch",
  "add_delete",
  "inventory",
  "fault",
  "status",
  "configuration",
];

const BACKEND_TO_UI_CAPABILITY = {
  inventory: "inventory",
  fault: "fault",
  status: "status",
  configuration: "config",
  cross_launch: "cross_launch",
  add_delete: "add_maintain",
};

const parseUiCapabilityKey = (key) => {
  for (const cap of UI_CAPABILITY_SUFFIXES) {
    const suffix = `_${cap}`;
    if (key.endsWith(suffix)) {
      return {
        resourceTypeId: key.slice(0, -suffix.length),
        capability: cap,
      };
    }
  }
  return null;
};

const parseBackendCapabilityKey = (key) => {
  for (const cap of BACKEND_CAPABILITY_SUFFIXES) {
    const suffix = `_${cap}`;
    if (key.endsWith(suffix)) {
      return {
        resourceTypeId: key.slice(0, -suffix.length),
        backendCapability: cap,
      };
    }
  }
  return null;
};

/* =========================================================
   COMPONENT
========================================================= */
const GroupMgmtView = ({ data = null }) => {
  const AllterminalTypes = useSelector(
    (state) => state.terminalTypes?.terminalTypes || []
  );
  const allGroups = useSelector((state) => state.groups?.allGroups || []);

  const [selectedTerminalId, setSelectedTerminalId] = useState(
    data?.terminalId ?? null
  );
  const [terminalLabel, setTerminalLabel] = useState("");

  const [resources, setResources] = useState([]);
  const [loadingResources, setLoadingResources] = useState(false);

  const [privileges, setPrivileges] = useState([]);
  const [loadingPrivileges, setLoadingPrivileges] = useState(false);

  const [selectedPrivilegeIds, setSelectedPrivilegeIds] = useState([]);
  const [selectedDeviceIds, setSelectedDeviceIds] = useState([]);
  const [selectedTypeCapabilities, setSelectedTypeCapabilities] = useState({});

  const [tabValue, setTabValue] = useState(0);

  const initializedRef = useRef(false);

  /* ---------------- CNMS ---------------- */
  const isCNMSTerminal =
    String(selectedTerminalId) === "1" ||
    (terminalLabel || "").toUpperCase().includes("CNMS");

  /* ---------------- FETCHERS ---------------- */
  const fetchPrivileges = async (terminalId) => {
    if (!terminalId) {
      setPrivileges([]);
      return;
    }
    setLoadingPrivileges(true);
    try {
      const res = await SecurityAxios(
        `${GET_ALL_PRIVILEGES}/${terminalId}`,
        "get"
      );
      setPrivileges(
        res?.status === 200 && Array.isArray(res.data) ? res.data : []
      );
    } catch (error) {
      console.error("Error fetching privileges:", error);
      setPrivileges([]);
    } finally {
      setLoadingPrivileges(false);
    }
  };

  const fetchDeviceResources = async (terminalId) => {
    if (!terminalId) {
      setResources([]);
      return;
    }
    setLoadingResources(true);
    try {
      const res = await InventoryAxios(
        `${FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL}/${terminalId}`,
        "get"
      );
      setResources(
        res?.status === 200 && Array.isArray(res.data) ? res.data : []
      );
    } catch (error) {
      console.error("Error fetching resources:", error);
      setResources([]);
    } finally {
      setLoadingResources(false);
    }
  };

  /* ---------------- INIT FROM data ---------------- */
  useEffect(() => {
    if (initializedRef.current) return;
    if (!data?.id) return;

    const terminalId = data.terminalId;
    setSelectedTerminalId(terminalId);

    const selectedTerminal = (AllterminalTypes || []).find(
      (t) => String(t.value) === String(terminalId)
    );
    setTerminalLabel(
      selectedTerminal?.label ||
        selectedTerminal?.terminalTypeName ||
        data?.terminalName ||
        data?.terminalTypeName ||
        ""
    );

    /* General privileges */
    const initialPrivIds = (data.privileges || [])
      .map((p) => Number(p.id))
      .filter((id) => !Number.isNaN(id));
    setSelectedPrivilegeIds(initialPrivIds);

    /* Device privileges (reverse map backend -> UI) */
    try {
      const parsed =
        typeof data.devicePrivileges === "string"
          ? JSON.parse(data.devicePrivileges || "{}")
          : data.devicePrivileges || {};

      const uiCaps = {};
      Object.entries(parsed).forEach(([key, val]) => {
        const p = parseBackendCapabilityKey(key);
        if (!p) return;
        const uiCap = BACKEND_TO_UI_CAPABILITY[p.backendCapability];
        if (!uiCap) return;
        uiCaps[`${p.resourceTypeId}_${uiCap}`] = val === true;
      });
      setSelectedTypeCapabilities(uiCaps);

      const ids = new Set();
      Object.entries(uiCaps).forEach(([key, isChecked]) => {
        if (!isChecked) return;
        const p = parseUiCapabilityKey(key);
        if (!p) return;
        const id = Number(p.resourceTypeId);
        if (!Number.isNaN(id)) ids.add(id);
      });
      setSelectedDeviceIds(Array.from(ids));
    } catch (err) {
      console.error("Error parsing devicePrivileges:", err);
      setSelectedTypeCapabilities({});
      setSelectedDeviceIds([]);
    }

    fetchPrivileges(terminalId);
    fetchDeviceResources(terminalId);

    initializedRef.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, AllterminalTypes]);

  const handleTabChange = (event, newValue) => setTabValue(newValue);

  const noop = useCallback(() => {}, []);

  const isLoading = loadingPrivileges || loadingResources;

  /* ---------------- RENDER ---------------- */
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        minWidth: 0,
   
        maxHeight:"90vh"
      }}
    >
      {selectedTerminalId && (
        <Box
          sx={{
            border: "1px solid #e0e0e0",
            borderRadius: 1,
            display: "flex",
            flexDirection: "column",
           height: "90vh",
          }}
        >
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <Tabs
              value={tabValue}
              onChange={handleTabChange}
              variant="fullWidth"
            >
              <Tab label="General Privileges" />
              {!isCNMSTerminal && <Tab label="Device Privileges" />}
            </Tabs>
          </Box>

          {/* ---------- SINGLE SCROLL CONTAINER ---------- */}
          <Box
            sx={{
          
              flex: 1,
              minHeight: 0,
            
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            {isLoading ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  p: 5,
                }}
              >
                <CircularProgress />
              </Box>
            ) : (
              <>
                {/* =====================
                    GENERAL PRIVILEGES (read-only)
                ===================== */}
                {tabValue === 0 && (
                  <Box
                    sx={{
                     
                      borderRadius: 1,
                    
                      bgcolor: "#fafafa",
                   height:"90vh",

                      /* make the inner tree non-clickable but
                         allow the OUTER box to still scroll */
                      "& .MuiCheckbox-root, & .MuiFormControlLabel-root, & .MuiTreeItem-content":
                        {
                          pointerEvents: "none !important",
                        },

                      /* grey disabled checkboxes */
                      "& .Mui-disabled": {
                        opacity: "1 !important",
                        color: "inherit !important",
                      },
                      "& .MuiCheckbox-root.Mui-disabled": {
                        color: "#9e9e9e !important",
                      },
                      "& .MuiCheckbox-root.Mui-disabled .MuiSvgIcon-root": {
                        color: "#9e9e9e !important",
                      },
                      "& .MuiCheckbox-root.Mui-checked.Mui-disabled": {
                        color: "#9e9e9e !important",
                      },
                      "& .MuiCheckbox-root.Mui-checked.Mui-disabled .MuiSvgIcon-root":
                        {
                          color: "#9e9e9e !important",
                        },
                    }}
                  >
                    {privileges.length > 0 ? (
                      <PrivilegeTree
                        flatData={privileges}
                        selectedIds={selectedPrivilegeIds}
                        toggle={noop}
                        selectAll={noop}
                        onToggle={noop}
                        onSelectAll={noop}
                        allSelected={false}
                        isReadOnly={false}
                      />
                    ) : (
                      <Typography
                        variant="body2"
                        color="textSecondary"
                        sx={{ p: 2 }}
                      >
                        No general privileges available.
                      </Typography>
                    )}
                  </Box>
                )}

                {/* =====================
                    DEVICE PRIVILEGES (read-only)
                ===================== */}
                {tabValue === 1 && !isCNMSTerminal && (
                  <Box
                    sx={{
                      border: "1px solid #eee",
                      borderRadius: 1,

                      /* grey disabled checkboxes */
                      "& .MuiCheckbox-root.Mui-disabled": {
                        color: "#9e9e9e !important",
                      },
                      "& .MuiCheckbox-root.Mui-disabled .MuiSvgIcon-root": {
                        color: "#9e9e9e !important",
                      },
                      "& .MuiCheckbox-root.Mui-checked.Mui-disabled": {
                        color: "#9e9e9e !important",
                      },
                    }}
                  >
                    <DevicePrivilegesTable
                      resources={resources}
                      allGroups={allGroups}
                      selectedDeviceIds={selectedDeviceIds}
                      setSelectedDeviceIds={noop}
                      terminalId={selectedTerminalId}
                      selectedTypeCapabilities={selectedTypeCapabilities}
                      setSelectedTypeCapabilities={noop}
                      isReadOnly={true}
                    />
                  </Box>
                )}
              </>
            )}
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default GroupMgmtView;

