import React, {
  useEffect,
  useMemo,
  useState,
  useRef,
  useCallback,
} from "react";
import { Box, Typography, CircularProgress, Tabs, Tab } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";

import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL,
  GET_ALL_PRIVILEGES,
  MODIFY_GROUP,
} from "@/RestAPI/url/endpoint";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import FormField from "@/components/Reusable/Form/FormField";
import PrivilegeTree from "../UserManagement/PrivilegeTree";
import DevicePrivilegesTable from "../UserManagement/DevicePrivilegesTable";

/* =========================================================
   CAPABILITY CONSTANTS
========================================================= */
const UI_CAPABILITY_SUFFIXES = [
  "cross_launch",
  "add_maintain",
  "inventory",
  "fault",
  "status",
  "config",
];

const BACKEND_CAPABILITY_SUFFIXES = [
  "cross_launch",
  "add_delete",
  "inventory",
  "fault",
  "status",
  "configuration",
];

const UI_TO_BACKEND_CAPABILITY = {
  inventory: "inventory",
  fault: "fault",
  status: "status",
  config: "configuration",
  cross_launch: "cross_launch",
  add_maintain: "add_delete",
};

const BACKEND_TO_UI_CAPABILITY = {
  inventory: "inventory",
  fault: "fault",
  status: "status",
  configuration: "config",
  cross_launch: "cross_launch",
  add_delete: "add_maintain",
};

const parseUiCapabilityKey = (key) => {
  for (const cap of UI_CAPABILITY_SUFFIXES) {
    const suffix = `_${cap}`;
    if (key.endsWith(suffix)) {
      return {
        resourceTypeId: key.slice(0, -suffix.length),
        capability: cap,
      };
    }
  }
  return null;
};

const parseBackendCapabilityKey = (key) => {
  for (const cap of BACKEND_CAPABILITY_SUFFIXES) {
    const suffix = `_${cap}`;
    if (key.endsWith(suffix)) {
      return {
        resourceTypeId: key.slice(0, -suffix.length),
        backendCapability: cap,
      };
    }
  }
  return null;
};

const getParentRef = (item) =>
  item?.parentId ??
  item?.parent_id ??
  item?.parentPrivilegeId ??
  item?.parent ??
  null;

const GroupMgmtEdit = ({
  onClose,
  onSuccess,
  onRefresh,
  data = null,
  isGrandchildFullScreen,
}) => {
  const AllterminalTypes = useSelector(
    (state) => state.terminalTypes?.terminalTypes || []
  );
  const allGroups = useSelector((state) => state.groups?.allGroups || []);

  const [selectedTerminalId, setSelectedTerminalId] = useState(
    data?.terminalId ?? null
  );

  const [resources, setResources] = useState([]);
  const [loadingResources, setLoadingResources] = useState(false);

  const [privileges, setPrivileges] = useState([]);
  const [loadingPrivileges, setLoadingPrivileges] = useState(false);

  const [selectedPrivilegeIds, setSelectedPrivilegeIds] = useState([]);
  const [selectedDeviceIds, setSelectedDeviceIds] = useState([]);
  const [selectedTypeCapabilities, setSelectedTypeCapabilities] = useState({});

  const [tabValue, setTabValue] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const initializedRef = useRef(false);
  const originalValuesRef = useRef(null);
  /* =========================================================
     INITIAL FORM DATA
  ========================================================= */
  const InitialData = {
    terminalTypeName: "",
    rnmsDetailId: "",
    siteNameId: "",
    groupName: "",
    userName: "",
    lastName: "",
  };

  /* =========================================================
     VALIDATION
  ========================================================= */
  const schema = Yup.object({
    terminalTypeName: Yup.string().trim().required("Terminal is required"),

    userName: Yup.string()
      .trim()
      .required("Suffix is required")
      .min(3, "Name  should be between 3-10 Characters.")
      .max(10, "Name should be between 3-10 Characters."),

    lastName: Yup.string()
      .trim()
      .required("Description is required")
      .min(10, "Description should be between 10-256 alphanumeric Characters.")
      .max(256, "Description should be between 10-256 alphanumeric Characters.")
      .matches(/^[a-zA-Z0-9 ]*$/, "Description must be alphanumeric"),
  });

  /* =========================================================
     FORMIK
  ========================================================= */
  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: async (values) => {
      await handleSubmit(values);
    },
  });

  /* =========================================================
     CNMS
  ========================================================= */
  const isCNMS = useMemo(() => {
    const name = formik.values.terminalTypeName || "";
    return name.toUpperCase().includes("CNMS");
  }, [formik.values.terminalTypeName]);

  const isCNMSTerminal = isCNMS || String(selectedTerminalId) === "1";

  /* =========================================================
     FORM ERROR
  ========================================================= */
  const getError = (field) => {
    if (!formik.touched[field]) return "";
    return formik.errors[field] || "";
  };

  /* =========================================================
     INPUT CHANGE
  ========================================================= */
  const handleInputChange = (field) => (event) => {
    const value = event?.target?.value ?? "";
    formik.setFieldValue(field, value, true);
    formik.setFieldTouched(field, true, true);
  };

  /* =========================================================
     FIND CHILDREN OF A PRIVILEGE
  ========================================================= */
  const getDescendantPrivilegeIds = useCallback((parentId, list) => {
    const result = [];
    const visited = new Set();

    const walk = (pid) => {
      list.forEach((item) => {
        const itemParentId = getParentRef(item);
        if (itemParentId === null || itemParentId === undefined) return;
        if (String(itemParentId) !== String(pid)) return;

        const childId = Number(item?.id);
        if (Number.isNaN(childId) || visited.has(childId)) return;

        visited.add(childId);
        result.push(childId);
        walk(childId);
      });
    };

    walk(parentId);
    return result;
  }, []);

  /* =========================================================
     FIX #3b — AUTO-CHECK PARENTS
     ---------------------------------------------------------
     For every privilege that has a parent, if ALL siblings of
     that privilege are selected, add the parent to the
     selection. Runs repeatedly until no change (handles
     deeper trees).
  ========================================================= */
  const syncParentSelection = useCallback((selectedIds, list) => {
    const selected = new Set(selectedIds.map(Number));

    let changed = true;
    let guard = 0;

    while (changed && guard < 20) {
      changed = false;
      guard += 1;

      // Group by parent
      const childrenByParent = new Map();
      list.forEach((item) => {
        const parentRef = getParentRef(item);
        if (parentRef === null || parentRef === undefined) return;

        const parentNum = Number(parentRef);
        if (Number.isNaN(parentNum)) return;

        if (!childrenByParent.has(parentNum)) {
          childrenByParent.set(parentNum, []);
        }
        childrenByParent.get(parentNum).push(Number(item.id));
      });

      childrenByParent.forEach((childIds, parentId) => {
        // If all siblings are selected and the parent is not,
        // select the parent.
        const allChildrenSelected = childIds.every((id) => selected.has(id));

        if (allChildrenSelected && !selected.has(parentId)) {
          // Ensure the parent actually exists in the privilege list
          const parentExists = list.some(
            (item) => Number(item.id) === parentId
          );
          if (parentExists) {
            selected.add(parentId);
            changed = true;
          }
        }
      });
    }

    return Array.from(selected);
  }, []);

  /* =========================================================
     TOGGLE PRIVILEGE — parent -> children AND children -> parent
  ========================================================= */
  const handleTogglePrivilege = (id) => {
    const numericId = Number(id);
    if (Number.isNaN(numericId)) return;

    setSelectedPrivilegeIds((previous) => {
      const current = previous.map(Number);
      const descendantIds = getDescendantPrivilegeIds(numericId, privileges);

      let next;

      if (current.includes(numericId)) {
        // Deselect parent + its descendants
        const removeSet = new Set([numericId, ...descendantIds]);
        next = current.filter((item) => !removeSet.has(item));
      } else {
        // Select parent + its descendants
        const nextSet = new Set([...current, numericId, ...descendantIds]);
        next = Array.from(nextSet);
      }

      // FIX #3b: auto-check parents when all their children are ticked
      return syncParentSelection(next, privileges);
    });
  };

  /* =========================================================
     GENERAL PRIVILEGE — SELECT ALL
  ========================================================= */
  const handleSelectAll = () => {
    const allIds = privileges
      .map((p) => Number(p.id))
      .filter((id) => !Number.isNaN(id));

    if (allIds.length === 0) {
      setSelectedPrivilegeIds([]);
      return;
    }

    const selectedIds = selectedPrivilegeIds.map(Number);
    const allSelected = allIds.every((id) => selectedIds.includes(id));

    setSelectedPrivilegeIds(allSelected ? [] : allIds);
  };

  const allGeneralPrivilegesSelected = useMemo(() => {
    if (privileges.length === 0) return false;
    const allIds = privileges.map((p) => Number(p.id));
    const selectedIds = selectedPrivilegeIds.map(Number);
    return allIds.every((id) => selectedIds.includes(id));
  }, [privileges, selectedPrivilegeIds]);

  /* =========================================================
     FETCHERS
  ========================================================= */
  const fetchPrivileges = async (terminalId) => {
    if (!terminalId) {
      setPrivileges([]);
      return;
    }
    setLoadingPrivileges(true);
    try {
      const res = await SecurityAxios(
        `${GET_ALL_PRIVILEGES}/${terminalId}`,
        "get"
      );
      setPrivileges(
        res?.status === 200 && Array.isArray(res.data) ? res.data : []
      );
    } catch (error) {
      console.error("Error fetching privileges:", error);
      setPrivileges([]);
    } finally {
      setLoadingPrivileges(false);
    }
  };

  const fetchDeviceResources = async (terminalId) => {
    if (!terminalId) {
      setResources([]);
      return;
    }
    setLoadingResources(true);
    try {
      const res = await InventoryAxios(
        `${FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL}/${terminalId}`,
        "get"
      );
      setResources(
        res?.status === 200 && Array.isArray(res.data) ? res.data : []
      );
    } catch (error) {
      console.error("Error fetching resources:", error);
      setResources([]);
    } finally {
      setLoadingResources(false);
    }
  };

  /* =========================================================
     GENERATE PREFIX (used for the derived suffix)
  ========================================================= */
  const generateGroupName = (terminalLabel) => {
    const cleanTerminalName = (terminalLabel || "").replace(/[\s-()]/g, "");

    let largestIndex = 0;
    if (Array.isArray(allGroups)) {
      allGroups.forEach((grp) => {
        if (!grp?.groupName) return;
        if (data?.id && grp.id === data.id) return;

        const prefix = `${cleanTerminalName}Group`;
        if (grp.groupName.startsWith(prefix)) {
          const match = grp.groupName.match(/\d+/);
          if (match) {
            const number = parseInt(match[0], 10);
            if (number > largestIndex) largestIndex = number;
          }
        }
      });
    }

    const nextNumber = String(largestIndex + 1).padStart(3, "0");
    return `${cleanTerminalName}Group${nextNumber}`;
  };

  /* =========================================================
     DERIVE SUFFIX FROM FULL GROUP NAME
     ---------------------------------------------------------
     Given fullName "MKTIIIGroup002abcde" and prefix
     "MKTIIIGroup002", returns "abcde".
  ========================================================= */
  const deriveSuffix = (fullName, prefix) => {
    const safeFull = String(fullName || "");
    const safePrefix = String(prefix || "");

    if (safePrefix && safeFull.startsWith(safePrefix)) {
      return safeFull.slice(safePrefix.length);
    }

    // Fallback: strip any "<something>Group<digits>" prefix
    return safeFull.replace(/^.*?Group\d+/i, "");
  };

  /* =========================================================
     INIT FROM data
  ========================================================= */
  useEffect(() => {
    // 1. Prevent re-initialization if already done
    if (initializedRef.current) return;
    // 2. Don't run if there is no data
    if (!data?.id) return;

    const terminalId = data.terminalId;
    setSelectedTerminalId(terminalId);

    // --- Existing Logic for Terminal Label ---
    const selectedTerminal = (AllterminalTypes || []).find(
      (t) => String(t.value) === String(terminalId)
    );
    const terminalLabel =
      selectedTerminal?.label ||
      selectedTerminal?.terminalTypeName ||
      data?.terminalName ||
      data?.terminalTypeName ||
      "";

    // --- Existing Logic for Group Name Generation ---
    const generatedGroupName = generateGroupName(terminalLabel);

    // --- Existing Logic for Suffix derivation ---
    const suffix = deriveSuffix(data.groupName, generatedGroupName);

    // 3. CREATE THE INITIAL STATE OBJECT
    const initialValuesToSet = {
      terminalTypeName: terminalLabel,
      rnmsDetailId: "",
      siteNameId: "",
      groupName: generatedGroupName,
      userName: suffix,
      lastName: data.description || "",
    };

    // 4. CRITICAL: Store the initial state in the Ref for the "Update" button comparison
    originalValuesRef.current = { ...initialValuesToSet };

    // 5. Update Formik
    formik.setValues(initialValuesToSet, false);

    formik.setTouched(
      {
        terminalTypeName: true,
        groupName: false,
        userName: false,
        lastName: false,
      },
      false
    );

    // --- Existing Logic for General Privileges ---
    const initialPrivIds = (data.privileges || [])
      .map((p) => Number(p.id))
      .filter((id) => !Number.isNaN(id));
    setSelectedPrivilegeIds(initialPrivIds);

    // --- Existing Logic for Device Privileges ---
    try {
      const parsed =
        typeof data.devicePrivileges === "string"
          ? JSON.parse(data.devicePrivileges || "{}")
          : data.devicePrivileges || {};

      const uiCaps = {};
      Object.entries(parsed).forEach(([key, val]) => {
        const p = parseBackendCapabilityKey(key);
        if (!p) return;
        const uiCap = BACKEND_TO_UI_CAPABILITY[p.backendCapability];
        if (!uiCap) return;
        uiCaps[`${p.resourceTypeId}_${uiCap}`] = val === true;
      });
      setSelectedTypeCapabilities(uiCaps);

      const ids = new Set();
      Object.entries(uiCaps).forEach(([key, isChecked]) => {
        if (!isChecked) return;
        const p = parseUiCapabilityKey(key);
        if (!p) return;
        const id = Number(p.resourceTypeId);
        if (!Number.isNaN(id)) ids.add(id);
      });
      setSelectedDeviceIds(Array.from(ids));
    } catch (err) {
      console.error("Error parsing devicePrivileges:", err);
      setSelectedTypeCapabilities({});
      setSelectedDeviceIds([]);
    }

    // --- Fetching remote data ---
    fetchPrivileges(terminalId);
    fetchDeviceResources(terminalId);

    // 6. Mark as initialized
    initializedRef.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, AllterminalTypes]);

  /* =========================================================
     Once privileges are loaded, run a one-time parent sync
     so previously-loaded selections also surface their parents.
  ========================================================= */
  useEffect(() => {
    if (privileges.length === 0) return;
    setSelectedPrivilegeIds((prev) => syncParentSelection(prev, privileges));
  }, [privileges, syncParentSelection]);

  /* =========================================================
     TAB
  ========================================================= */
  const handleTabChange = (event, newValue) => setTabValue(newValue);

  /* =========================================================
     BUILD DEVICE PRIVILEGES PAYLOAD
  ========================================================= */
  const buildDevicePrivileges = () => {
    if (isCNMSTerminal) return {};

    if (
      !selectedTypeCapabilities ||
      typeof selectedTypeCapabilities !== "object" ||
      Array.isArray(selectedTypeCapabilities)
    ) {
      return {};
    }

    const devicePrivileges = {};

    Object.entries(selectedTypeCapabilities).forEach(([key, isChecked]) => {
      if (!isChecked) return;

      const parsed = parseUiCapabilityKey(key);
      if (!parsed) return;

      const backendCapability = UI_TO_BACKEND_CAPABILITY[parsed.capability];
      if (!backendCapability) return;

      devicePrivileges[`${parsed.resourceTypeId}_${backendCapability}`] = true;
    });

    return devicePrivileges;
  };

  /* =========================================================
     DEVICE PRIVILEGE VALIDATION
  ========================================================= */
  const hasDevicePrivileges = () => {
    if (isCNMSTerminal) return true;

    if (Array.isArray(selectedDeviceIds) && selectedDeviceIds.length > 0) {
      return true;
    }

    if (
      selectedTypeCapabilities &&
      typeof selectedTypeCapabilities === "object" &&
      !Array.isArray(selectedTypeCapabilities) &&
      Object.values(selectedTypeCapabilities).some(Boolean)
    ) {
      return true;
    }

    return false;
  };

  /* =========================================================
     VALIDITY GATE
  ========================================================= */
  const isSubmitDisabled = useMemo(() => {
    const terminal = (formik.values.terminalTypeName || "").trim();
    const suffix = (formik.values.userName || "").trim();
    const description = (formik.values.lastName || "").trim();

    // 1. Basic Validation: Are fields filled?
    const allFilled =
      terminal.length > 0 &&
      suffix.length > 0 &&
      description.length > 0 &&
      Array.isArray(selectedPrivilegeIds) &&
      selectedPrivilegeIds.length > 0 &&
      hasDevicePrivileges();

    if (!allFilled || submitting) return true;

    // 2. Deep Comparison: Has anything actually changed?

    // Check Text Fields
    const textFieldsChanged =
      formik.values.userName !== originalValuesRef.current?.userName ||
      formik.values.lastName !== originalValuesRef.current?.lastName;

    // Check General Privileges (Compare current IDs to initial data IDs)
    const initialPrivilegeIds = (data.privileges || [])
      .map((p) => Number(p.id))
      .sort((a, b) => a - b);

    const currentPrivilegeIds = [...selectedPrivilegeIds]
      .map(Number)
      .sort((a, b) => a - b);
    const privilegesChanged =
      JSON.stringify(initialPrivilegeIds) !==
      JSON.stringify(currentPrivilegeIds);

    // Check Device Privileges (Compare current vs initial)
    let devicePrivilegesChanged = false;
    try {
      const initialDevicePrivs =
        typeof data.devicePrivileges === "string"
          ? JSON.parse(data.devicePrivileges)
          : data.devicePrivileges;

      // Convert current state to string for easy comparison
      const currentDevicePrivsStr = JSON.stringify(buildDevicePrivileges());
      const initialDevicePrivsStr = JSON.stringify(initialDevicePrivs || {});

      devicePrivilegesChanged = currentDevicePrivsStr !== initialDevicePrivsStr;
    } catch (e) {
      devicePrivilegesChanged = true;
    }

    // The button is DISABLED if NO changes were detected
    const hasChanges =
      textFieldsChanged || privilegesChanged || devicePrivilegesChanged;

    return !hasChanges;
  }, [
    formik.values,
    selectedPrivilegeIds,
    selectedTypeCapabilities,
    selectedDeviceIds,
    submitting,
    data, // Added data to dependencies to allow comparison
  ]);

  /* =========================================================
     PAYLOAD
  ========================================================= */
  const buildUpdatePayload = (values) => {
    return {
      id: Number(data.id),

      groupName: String(values.userName || "").trim(),

      terminalType: {
        id: Number(selectedTerminalId),
      },

      description: String(values.lastName || "").trim(),

      privileges: selectedPrivilegeIds.map((id) => ({
        id: Number(id),
      })),

      devicePrivileges: JSON.stringify(buildDevicePrivileges()),
    };
  };

  /* =========================================================
     SUBMIT
  ========================================================= */
  const handleSubmit = async (values) => {
    try {
      setSubmitting(true);

      const errors = await formik.validateForm();

      if (Object.keys(errors).length > 0) {
        await formik.setTouched(
          {
            terminalTypeName: true,
            groupName: true,
            userName: true,
            lastName: true,
          },
          true
        );
        return;
      }

      if (selectedPrivilegeIds.length === 0) {
        Toast(
          "Error!",
          "Please select at least one general privilege.",
          "error"
        );
        return;
      }

      if (!hasDevicePrivileges()) {
        Toast(
          "Error!",
          "Please select at least one device privilege.",
          "error"
        );
        return;
      }

      const payload = buildUpdatePayload(values);
      console.log("UPDATE PAYLOAD:", JSON.stringify(payload, null, 2));

      const response = await SecurityAxios(MODIFY_GROUP, "post", payload);
      console.log("UPDATE RESPONSE:", response);

      if (response?.status === 200 || response?.status === 201) {
        Toast("Success!", "Group updated successfully!", "success");

        if (typeof onRefresh === "function") {
          try {
            await onRefresh();
          } catch (e) {
            console.error("onRefresh error:", e);
          }
        }

        if (typeof onSuccess === "function") onSuccess(response.data);
        setShowConfirm(false);
        if (typeof onClose === "function") onClose();
      }
    } catch (error) {
      console.error("UPDATE ERROR:", error);

      Toast(
        "Error!",
        error?.response?.data?.message ||
          error?.response?.data?.error ||
          "Failed to update group.",
        "error"
      );
    } finally {
      setSubmitting(false);
    }
  };

  /* =========================================================
     CONFIRM DIALOG
  ========================================================= */
  const handleConfirmUpdate = async () => {
    const errors = await formik.validateForm();

    await formik.setTouched(
      {
        terminalTypeName: true,
        groupName: true,
        userName: true,
        lastName: true,
      },
      true
    );

    if (Object.keys(errors).length > 0) {
      setShowConfirm(false);
      return;
    }

    if (selectedPrivilegeIds.length === 0) {
      setShowConfirm(false);
      Toast("Error!", "Please select at least one general privilege.", "error");
      return;
    }

    if (!hasDevicePrivileges()) {
      setShowConfirm(false);
      Toast("Error!", "Please select at least one device privilege.", "error");
      return;
    }

    setShowConfirm(false);
    await handleSubmit(formik.values);
  };

  /* =========================================================
     RENDER
  ========================================================= */
  return (
    <Box
      component="form"
      onSubmit={(event) => {
        event.preventDefault();
        if (isSubmitDisabled) return;
        setShowConfirm(true);
      }}
    >
      <Box sx={{ display: "flex", flexDirection: "column" }}>
        {/* TERMINAL */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="Terminal"
            required
            disabled
            value={formik.values.terminalTypeName || ""}
          />
        </Box>

        {/* PREFIX (read-only) */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="Group Name Prefix"
            required
            disabled
            value={formik.values.groupName || ""}
          />
        </Box>

        {/* SUFFIX (FIX #2 — now shows only the suffix) */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="Group Name Suffix"
            required
            value={formik.values.userName || ""}
            onChange={handleInputChange("userName")}
            onBlur={() => formik.setFieldTouched("userName", true, true)}
            error={getError("userName")}
            errorMessage={getError("userName")}
          />
        </Box>

        {/* DESCRIPTION */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="Description"
            required
            value={formik.values.lastName || ""}
            onChange={handleInputChange("lastName")}
            onBlur={() => formik.setFieldTouched("lastName", true, true)}
            error={getError("lastName")}
            errorMessage={getError("lastName")}
          />
        </Box>

        {/* PRIVILEGES */}
        {selectedTerminalId && (
          <Box
            sx={{
              mt: 3,
              border: "1px solid #e0e0e0",
              borderRadius: 1,
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <Tabs
                value={tabValue}
                onChange={handleTabChange}
                variant="fullWidth"
              >
                <Tab label="General Privileges" />
                {!isCNMSTerminal && <Tab label="Device Privileges" />}
              </Tabs>
            </Box>

            {/* FIX #3a — single bounded scroll container for both tabs */}
            <Box
              sx={{
                p: 1,
                maxHeight: "60vh",
                overflowY: "auto",
                overflowX: "hidden",
              }}
            >
              {loadingPrivileges || loadingResources ? (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    p: 5,
                  }}
                >
                  <CircularProgress />
                </Box>
              ) : (
                <>
                  {tabValue === 0 && (
                    <Box
                      sx={{
                        border: "1px solid #eee",
                        borderRadius: 1,
                        p: 1,
                        bgcolor: "theme.palette.custom.rightUtilityDrawer.bg",
                      }}
                    >
                      {privileges.length > 0 ? (
                        <PrivilegeTree
                          flatData={privileges}
                          selectedIds={selectedPrivilegeIds}
                          toggle={handleTogglePrivilege}
                          selectAll={handleSelectAll}
                          onToggle={handleTogglePrivilege}
                          onSelectAll={handleSelectAll}
                          allSelected={allGeneralPrivilegesSelected}
                          isReadOnly={false}
                        />
                      ) : (
                        <Typography
                          variant="body2"
                          color="textSecondary"
                          sx={{ p: 2 }}
                        >
                          No general privileges available.
                        </Typography>
                      )}
                    </Box>
                  )}

                  {tabValue === 1 && !isCNMSTerminal && (
                    <Box sx={{ border: "1px solid #eee", borderRadius: 1 }}>
                      <DevicePrivilegesTable
                        resources={resources}
                        allGroups={allGroups}
                        selectedDeviceIds={selectedDeviceIds}
                        setSelectedDeviceIds={setSelectedDeviceIds}
                        terminalId={selectedTerminalId}
                        selectedTypeCapabilities={selectedTypeCapabilities}
                        setSelectedTypeCapabilities={
                          setSelectedTypeCapabilities
                        }
                      />
                    </Box>
                  )}
                </>
              )}
            </Box>
          </Box>
        )}

        {/* UPDATE BUTTON */}
        <Box sx={{ display: "flex", mt: 3, justifyContent: "flex-end" }}>
          <MButtonPrimary
            type="submit"
            disabled={isSubmitDisabled}
            onClick={(event) => {
              if (isSubmitDisabled) {
                event.preventDefault();
                return;
              }
              setShowConfirm(true);
            }}
          >
            {submitting ? "Updating..." : "Update"}
          </MButtonPrimary>
        </Box>
      </Box>

      <MDialog
        open={showConfirm}
        variant="warning"
        title="Confirm Action"
        icon={question_mark}
        message="Are you sure you want to update this group?"
        onConfirm={handleConfirmUpdate}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default GroupMgmtEdit;
