
import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Checkbox,
  Typography,
  Paper,
  Box,
  CircularProgress,
} from "@mui/material";
import { GET_RESOURCE_TYPE_BY_SEGMENT } from "@/RestAPI/url/endpoint";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";

/* =========================================================
   Styled cells
========================================================= */
const TableCellNew1 = (props) => (
  <TableCell
    align="left"
    style={{
      border: "solid 1px #e0e0e0",
      padding: "5px",
      fontSize: "0.875rem",
    }}
    {...props}
  />
);

const TableCellNew = (props) => (
  <TableCell
    align="center"
    style={{ border: "solid 1px #e0e0e0", padding: "5px" }}
    {...props}
  />
);


const CAPABILITY_SUFFIXES = [
  "cross_launch",
  "add_maintain",
  "inventory",
  "fault",
  "status",
  "config",
];

const parseCapabilityKey = (key) => {
  for (const cap of CAPABILITY_SUFFIXES) {
    const suffix = `_${cap}`;
    if (key.endsWith(suffix)) {
      return {
        resourceTypeId: key.slice(0, -suffix.length),
        capability: cap,
      };
    }
  }
  return null;
};

const DevicePrivilegesTable = ({
  resources,
  terminalId,
  setSelectedDeviceIds,
  selectedTypeCapabilities,
  setSelectedTypeCapabilities,
  isReadOnly = false,
}) => {
  const [segmentMapping, setSegmentMapping] = useState([]);
  const [loadingMapping, setLoadingMapping] = useState(false);

  const columns = [
    { label: "Inventory", key: "inventory" },
    { label: "Fault", key: "fault" },
    { label: "Status", key: "status" },
    { label: "Config", key: "config" },
    { label: "Cross Launch", key: "cross_launch" },
    { label: "Add/Maintain", key: "add_maintain" },
  ];

  /* =========================================================
     FETCH SEGMENT MAPPING
  ========================================================= */
  useEffect(() => {
    const fetchMapping = async () => {
      if (!terminalId) {
        setSegmentMapping([]);
        return;
      }

      setLoadingMapping(true);

      try {
        const url = `${GET_RESOURCE_TYPE_BY_SEGMENT}/${terminalId}`;
        const res = await InventoryAxios(url, "get");

        if (res.status === 200 && Array.isArray(res.data)) {
          setSegmentMapping(res.data);
        } else {
          setSegmentMapping([]);
        }
      } catch (error) {
        console.error("Error fetching mapping:", error);
        setSegmentMapping([]);
      } finally {
        setLoadingMapping(false);
      }
    };

    fetchMapping();
  }, [terminalId]);

  /* =========================================================
     CAPABILITY ENABLED CHECK
     ---------------------------------------------------------
     inventory / fault / add_maintain are ALWAYS available
     for every resource type (this includes DG Set which has
     no capability `data` object).

     status / config / cross_launch depend on the `data` flags.
  ========================================================= */
  const isColumnEnabledForType = (resourceTypeObj, colKey) => {
    if (
      colKey === "inventory" ||
      colKey === "fault" ||
      colKey === "add_maintain"
    ) {
      return true;
    }

    const data = resourceTypeObj?.data;
    if (!data) return false;

    switch (colKey) {
      case "status":
        return data.status === true;
      case "config":
        return data.configured === true;
      case "cross_launch":
        return !!(data.ssh || data.web || data.telnet);
      default:
        return false;
    }
  };

  /* =========================================================
     SYNC SELECTED DEVICE IDS
     ---------------------------------------------------------
     Keys are now "<resourceTypeId>_<capability>", so the id
     is read directly from the key — no name-based lookup.
  ========================================================= */
  const syncSelectedDevices = (currentSelection) => {
    const deviceIds = new Set();

    Object.entries(currentSelection).forEach(([key, isChecked]) => {
      if (!isChecked) return;

      const parsed = parseCapabilityKey(key);
      if (!parsed) return;

      const id = Number(parsed.resourceTypeId);
      if (!Number.isNaN(id)) {
        deviceIds.add(id);
      }
    });

    setSelectedDeviceIds(Array.from(deviceIds));
  };

  /* =========================================================
     TOGGLE SINGLE CAPABILITY
  ========================================================= */
  const handleToggleType = (resourceTypeId, colKey) => {
    if (isReadOnly) return;

    const key = `${resourceTypeId}_${colKey}`;

    const newSelection = {
      ...selectedTypeCapabilities,
      [key]: !selectedTypeCapabilities[key],
    };

    setSelectedTypeCapabilities(newSelection);
    syncSelectedDevices(newSelection);
  };

  /* =========================================================
     TOGGLE SEGMENT
  ========================================================= */
  const handleSegmentToggle = (segmentResourceTypes) => {
    if (isReadOnly) return;

    const newSelection = { ...selectedTypeCapabilities };

    let segmentIsCurrentlySelected = true;

    segmentResourceTypes.forEach((type) => {
      columns.forEach((col) => {
        if (
          isColumnEnabledForType(type, col.key) &&
          !selectedTypeCapabilities[`${type.resourceTypeId}_${col.key}`]
        ) {
          segmentIsCurrentlySelected = false;
        }
      });
    });

    segmentResourceTypes.forEach((type) => {
      columns.forEach((col) => {
        if (isColumnEnabledForType(type, col.key)) {
          newSelection[`${type.resourceTypeId}_${col.key}`] =
            !segmentIsCurrentlySelected;
        }
      });
    });

    setSelectedTypeCapabilities(newSelection);
    syncSelectedDevices(newSelection);
  };

  /* =========================================================
     SELECT ALL TABLE
  ========================================================= */
  const handleSelectAllTable = () => {
    if (isReadOnly) return;

    const newSelection = {};

    const isCurrentlyAllSelected = segmentMapping.every((segment) =>
      (segment?.resourceTypes || []).every((type) =>
        columns.every(
          (col) =>
            !isColumnEnabledForType(type, col.key) ||
            !!selectedTypeCapabilities[`${type.resourceTypeId}_${col.key}`]
        )
      )
    );

    const targetValue = !isCurrentlyAllSelected;

    segmentMapping.forEach((seg) => {
      (seg?.resourceTypes || []).forEach((type) => {
        columns.forEach((col) => {
          if (isColumnEnabledForType(type, col.key)) {
            newSelection[`${type.resourceTypeId}_${col.key}`] =
              targetValue;
          }
        });
      });
    });

    setSelectedTypeCapabilities(newSelection);
    syncSelectedDevices(newSelection);
  };

  /* =========================================================
     SEGMENT CHECKED STATE
  ========================================================= */
  const isSegmentChecked = (segment) => {
    const capableTypes = (segment?.resourceTypes || []).filter((type) =>
      columns.some((col) => isColumnEnabledForType(type, col.key))
    );

    if (capableTypes.length === 0) return false;

    return capableTypes.every((type) =>
      columns.every(
        (col) =>
          !isColumnEnabledForType(type, col.key) ||
          !!selectedTypeCapabilities[`${type.resourceTypeId}_${col.key}`]
      )
    );
  };

  /* =========================================================
     GLOBAL "ALL CAPABLE SELECTED" STATE
  ========================================================= */
  const isAllCapableSelected = () => {
    let hasAnyCapableItem = false;

    const allMatch = segmentMapping.every((segment) =>
      (segment?.resourceTypes || []).every((type) =>
        columns.every((col) => {
          const enabled = isColumnEnabledForType(type, col.key);

          if (enabled) {
            hasAnyCapableItem = true;
            return !!selectedTypeCapabilities[
              `${type.resourceTypeId}_${col.key}`
            ];
          }

          return true;
        })
      )
    );

    return hasAnyCapableItem && allMatch;
  };

  if (loadingMapping) {
    return (
      <Box sx={{ p: 3, textAlign: "center" }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ width: "100%", mt: 1 }}>
      <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
        <Checkbox
          size="small"
          disabled={isReadOnly}
          checked={isAllCapableSelected()}
          onChange={handleSelectAllTable}
        />
        <Typography variant="body2">Select All Capable Types</Typography>
      </Box>

      <TableContainer component={Paper} sx={{ border: "1px solid #e0e0e0" }}>
        <Table size="small" stickyHeader>
          <TableHead>
            <TableRow>
              <TableCellNew1>Type / Name</TableCellNew1>
              {columns.map((col) => (
                <TableCellNew key={col.key}>{col.label}</TableCellNew>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {segmentMapping.map((segment) => (
              <React.Fragment key={segment.segmentId}>
                <TableRow sx={{ backgroundColor: "#c2c7ca" ,}}>
                  <TableCellNew1
                    sx={{
                      fontWeight: "bold",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <Checkbox
                      size="small"
                      disabled={isReadOnly}
                      checked={isSegmentChecked(segment)}
                      onChange={() =>
                        handleSegmentToggle(segment.resourceTypes || [])
                      }
                    />
                    {String(segment.segmentName || "").toUpperCase()}
                  </TableCellNew1>

                  {columns.map((col) => (
                    <TableCellNew
                      key={col.key}
                      sx={{ backgroundColor: "#c2c7ca" }}
                    />
                  ))}
                </TableRow>

                {(segment.resourceTypes || []).map((type) => (
                  <TableRow key={type.resourceTypeId} hover>
                    <TableCellNew1>{type.resourceTypeName}</TableCellNew1>

                    {columns.map((col) => {
                      const enabled = isColumnEnabledForType(type, col.key);
                      const isChecked =
                        !!selectedTypeCapabilities[
                          `${type.resourceTypeId}_${col.key}`
                        ];

                      return (
                        <TableCellNew key={col.key}>
                          <Checkbox
                            size="small"
                            disabled={!enabled || isReadOnly}
                            checked={isChecked}
                            onChange={() =>
                              handleToggleType(type.resourceTypeId, col.key)
                            }
                          />
                        </TableCellNew>
                      );
                    })}
                  </TableRow>
                ))}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default DevicePrivilegesTable;

