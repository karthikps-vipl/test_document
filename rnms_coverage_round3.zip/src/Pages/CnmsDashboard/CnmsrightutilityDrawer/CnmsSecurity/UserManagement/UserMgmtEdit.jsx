import React, { useEffect, useMemo, useState } from "react";
import {
    Box,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";
 import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";
import MDialog from "@/components/Reusable/Dialog/MDialog";

import {
    SecurityAxios,
} from "@/RestAPI/api/axiosApicall";

import {
    UPDATE_USERS,
   
} from "@/RestAPI/url/endpoint";



import question_mark from "@/assets/SVGIcons/question_mark.svg";
import FormField from "@/components/Reusable/Form/FormField";
import { emailValidation, ipPhoneValidation, NameValidator, primaryMobileValidation } from "@/utility/FormValidation/YupSchema";
const UserMgmtEdit = ({
    row,
    onClose,
    onRefresh,
    isGrandchildFullScreen
  }) => {
    const allUsersFromRedux = useSelector(
      (state) => state.getAllUsers.allUsers
    );
  console.log("row",row)
    const [terminalSiteData, setTerminalSiteData] = useState([]);
    const [showConfirm, setShowConfirm] = useState(false);
  
    const initialValues = useMemo(
      () => ({
        rnmsDetailId: String(row?.rnmsDetailId || ""),
        groupName: row?.groupName || "", 
        userName: row?.userName || "",
        firstName: row?.firstName || "",
        lastName: row?.lastName || "",
        mailId: row?.mailId || "",
        mobileNo: row?.mobileNo || "",
        ipPhone: row?.ipPhone || "",
        id:row?.id || "",
       
      }),
      [row]
    );
    console.log("initialValues",initialValues)
  
    const schema = Yup.object({
      rnmsDetailId: Yup.string().required("Site ID is required"),
      groupName: Yup.string().required("Group Name is required"),
      firstName:NameValidator,
      lastName: NameValidator,
      mailId: emailValidation,
      mobileNo:  primaryMobileValidation,
      ipPhone: ipPhoneValidation,

    });
  
    const formik = useFormik({
      initialValues,
      enableReinitialize: true,
      validationSchema: schema,
      validateOnChange: true,
      validateOnBlur: true,
      onSubmit: async (values) => {
        await handleSuccess(values);
      },
    });
  
    const getError = (field) => {
      if (formik.touched[field] || formik.submitCount > 0) {
        return formik.errors[field] || null;
      }
  
      return null;
    };
  
    const handleInputChange = (field) => (event) => {
      formik.setFieldValue(field, event.target.value);
      formik.setFieldTouched(field, true, false);
    };
  
    useEffect(() => {
      if (!Array.isArray(allUsersFromRedux)) {
        setTerminalSiteData([]);
        return;
      }
  
      const relationshipData = allUsersFromRedux
        .map((user) => ({
          terminalTypeId:
            user?.group?.terminalType?.id != null
              ? String(user.group.terminalType.id)
              : "",
  
          rnmsDetailId:
            user?.rnmsDetailId != null
              ? String(user.rnmsDetailId)
              : "",
  
          groupName: user?.group?.groupName || "",
  
          groupId:
            user?.group?.id != null
              ? String(user.group.id)
              : "",
        }))
        .filter(
          (item) =>
            item.rnmsDetailId &&
            item.groupId &&
            item.groupName
        );
  
      setTerminalSiteData(relationshipData);
    }, [allUsersFromRedux]);
  
    const groupOptions = useMemo(() => {
      const currentSiteId = formik.values.rnmsDetailId;
      
      // 1. Get groups belonging to the selected site from Redux
      const siteGroups = terminalSiteData
        .filter((item) => String(item.rnmsDetailId) === String(currentSiteId))
        .map((item) => ({
          label: item.groupName,
          value: item.groupName,
          groupId: String(item.groupId),
        }));
    
      // 2. Remove duplicates (in case the current row's group is already in the siteGroups)
      const uniqueGroups = [
        ...new Map(siteGroups.map((item) => [item.value, item])).values(),
      ];
    
      // 3. FORCE the current row's group into the options 
      // This ensures the dropdown shows the value from the "row" immediately
      const currentRowGroupName = row?.group?.groupName;
      const currentRowGroupId = row?.group?.id ? String(row.group.id) : "";
    
      const isAlreadyInList = uniqueGroups.some(
        (group) => group.value === currentRowGroupName
      );
    
      if (currentRowGroupName && !isAlreadyInList) {
        uniqueGroups.unshift({
          label: currentRowGroupName,
          value: currentRowGroupName,
          groupId: currentRowGroupId,
        });
      }
    
      return uniqueGroups;
    }, [formik.values.rnmsDetailId, terminalSiteData, row]);
    const handleSuccess = async (values) => {
      const selectedGroup = groupOptions.find(
        (group) => String(group.value) === String(values.groupName)
      );
    
      // If the group was found in options, use its ID. 
      // If the group is NOT in options (because of filtering), 
      // you might need to fallback to a hardcoded ID or logic from the row.
      let groupIdValue = selectedGroup?.groupId || row?.groupId; 
    
      const payload = {
        id: values?.id ? Number(values.id) : Number(row?.id),
        userName: values.userName,
        firstName: values.firstName,
        lastName: values.lastName,
        mailId: values.mailId,
        mobileNo: values.mobileNo,
        ipPhone: values.ipPhone,
        rnmsDetailId: values.rnmsDetailId,
        group: {
          id: groupIdValue ? Number(groupIdValue) : null,
        },
        description: row?.description || "",
      };
    
      console.log("SUBMITTING PAYLOAD WITH LOCKED GROUP:", payload);
    
      try {
        const response = await SecurityAxios(UPDATE_USERS, "post", payload);
    
        if (response.status === 200 || response.status === 201) {
          Toast("Success!", "User details updated successfully!", "success");
    
          if (typeof onRefresh === "function") onRefresh();
          if (typeof onClose === "function") onClose();
        } else {
          // Handle non-200/201 responses (like 500)
          const errorMsg = response.data?.message || "Failed to update details.";
          Toast("Error!", errorMsg, "error");
        }
      } catch (error) {
        console.error(" Error updating user:", error);
    
        let errorMessage = "Failed to update details.";
    
        // Detailed Error Handling
        if (error.response) {
          // Server responded with status >= 400 (e.g., 500)
          const serverMsg = error.response.data?.message || "Server error occurred.";
          console.error("Server Response:", error.response.data);
          console.error("Status Code:", error.response.status);
          errorMessage = serverMsg;
        } else if (error.request) {
          // Request made but no response received
          console.error("No response received from server.");
          errorMessage = "Connection failed. Please check your internet.";
        } else {
          // Something else happened (e.g., config error)
          console.error("Error details:", error.message);
          errorMessage = error.message || "Failed to update details.";
        }
    
        Toast("Error!", errorMessage, "error");
      }
    };
    
    
  
    const handleConfirmSubmit = async () => {
      const touchedFields = {
        rnmsDetailId: true,
        groupName: true,
        firstName: true,
        lastName: true,
        mailId: true,
        mobileNo: true,
        ipPhone:true
      };
  
      await formik.setTouched(
        touchedFields,
        true
      );
  
      const errors =
        await formik.validateForm();
  
      if (Object.keys(errors).length === 0) {
        setShowConfirm(false);
        await handleSuccess(formik.values);
      }
    };
  
    const isUpdateDisabled = useMemo(() => {
       const requiredFields = [
        "firstName",
        "lastName",
        "mailId",
        "mobileNo",
        "ipPhone",
      ];
      
      const hasEmptyRequiredField = requiredFields.some(
        (field) =>
          !formik.values[field] ||
          String(formik.values[field]).trim() === ""
      );
    
       const hasErrors = Object.keys(formik.errors).length > 0;
    
        const isNotChanged = !formik.dirty;
    
        return hasEmptyRequiredField || hasErrors || isNotChanged;
    }, [
      formik.values,
      formik.errors,
      formik.dirty, // Add this dependency
    ]);
  
    return (
      <Box
        component="form"
        onSubmit={formik.handleSubmit}
        className="flex flex-col gap-5"
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            ml: 3,
            mr: 5,
          }}
        >
          <Box sx={{ mb: 2 }}>
            <FormField
              label="User Name"
              required
              value={formik.values.userName}
              disabled
            />
          </Box>
  
         <Box
  sx={{
    display: "flex",
    flexDirection: "column",
  
    mb: 2,
  }}
>
  
  
  {/* Changed from MSelect to FormField to match the UserName style */}
  <FormField
    label="Group Name"
    required
    value={formik.values.groupName} // This will be "AdminGroup001" from your row
    disabled={true}                 // This makes it non-editable
  />
</Box>
  
          <Box sx={{ mb: 2 }}>
            <FormField
              label="First Name"
              required
              value={formik.values.firstName}
              onChange={handleInputChange(
                "firstName"
              )}
              onBlur={() =>
                formik.setFieldTouched(
                  "firstName",
                  true
                )
              }
              error={getError("firstName")}
              errorMessage={getError(
                "firstName"
              )}
            />
          </Box>
  
          <Box sx={{ mb: 2 }}>
            <FormField
              label="Last Name"
              required
              value={formik.values.lastName}
              onChange={handleInputChange(
                "lastName"
              )}
              onBlur={() =>
                formik.setFieldTouched(
                  "lastName",
                  true
                )
              }
              error={getError("lastName")}
              errorMessage={getError(
                "lastName"
              )}
            />
          </Box>
  
          <Box sx={{ mb: 2 }}>
            <FormField
              label="Email ID"
              required
              type="email"
              value={formik.values.mailId}
              onChange={handleInputChange(
                "mailId"
              )}
              onBlur={() =>
                formik.setFieldTouched(
                  "mailId",
                  true
                )
              }
              error={getError("mailId")}
              errorMessage={getError(
                "mailId"
              )}
            />
          </Box>
  
          <Box sx={{ mb: 2 }}>
            <FormField
              label="Mobile Number"
              required
              value={formik.values.mobileNo}
              onChange={handleInputChange(
                "mobileNo"
              )}
              onBlur={() =>
                formik.setFieldTouched(
                  "mobileNo",
                  true
                )
              }
              error={getError("mobileNo")}
              errorMessage={getError(
                "mobileNo"
              )}
            />
          </Box>
  
          <Box sx={{ mb: 2 }}>
            <FormField
              label="IP Phone"
              required
              value={formik.values.ipPhone}
              onChange={handleInputChange(
                "ipPhone"
              )}
              onBlur={() =>
                formik.setFieldTouched(
                  "ipPhone",
                  true
                )
              }
              error={getError("ipPhone")}
              errorMessage={getError(
                "ipPhone"
              )}
            />
          </Box>
  
          <Box
            sx={{
              float: "right",
              display: "flex",
              mt: 3,
              justifyContent: "flex-end",
            }}
          >
            <MButtonPrimary
              type="button"
              disabled={isUpdateDisabled}
              onClick={async () => {
                const touchedFields = {
                  groupName: true,
                  firstName: true,
                  lastName: true,
                  mailId: true,
                  mobileNo: true,
                };
  
                await formik.setTouched(
                  touchedFields,
                  true
                );
  
                const errors =
                  await formik.validateForm();
  
                if (
                  Object.keys(errors).length === 0
                ) {
                  setShowConfirm(true);
                }
              }}
            >
              Update
            </MButtonPrimary>
          </Box>
        </Box>
  
        <MDialog
          open={showConfirm}
          variant="warning"
          title="Confirm Action"
          icon={question_mark}
          message="Are you sure you want to update User details?"
          onConfirm={handleConfirmSubmit}
          onClose={() =>
            setShowConfirm(false)
          }
          mode="grandchild"
          isGrandchildFullScreen={isGrandchildFullScreen} 

        />
      </Box>
    );
  };
  
  export default UserMgmtEdit;
