import React, { useEffect, useMemo, useState } from "react";
import { Box, Typography, InputAdornment, IconButton } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall";
import {
  ADD_USERS,
  FETCH_ALL_TERMINAL_TYPE_DETAILS,
  GET_ALL_NON_DEFAULT_GROUPS
} from "@/RestAPI/url/endpoint";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import {
  ipPhoneValidation,
  emailValidation,
  UsernameValidator,
  PasswordValidator,
  NameValidator,
  primaryMobileValidation,
} from "@/utility/FormValidation/YupSchema";
import { useSelector } from "react-redux";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MSelect from "@/components/Reusable/Select/MSelect";
import FormField from "@/components/Reusable/Form/FormField";
import { encryptData } from "@/utility/encryptLogin";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";

const UserMgmtAdd = ({
  row,
  mode,
  onClose,
  onSuccess,
  siteId,
  onRefresh,
  refreshTrigger,
  isGrandchildFullScreen,
}) => {
  const fetchSiteDetails = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails || []
  );
  // 1. Redux Selectors
  const allUsersFromRedux = useSelector((state) => state.getAllUsers.allUsers);
  const { remoteRepDetails } = useSelector((state) => state.remoteRepDetails);
  console.log("remoteRepDetails sitedetails", remoteRepDetails);

  // 2. Local State
  const [terminalTypes, setTerminalTypes] = useState([]);
  // const [terminalSiteData, setTerminalSiteData] = useState([]);
  const [selectedTerminalId, setSelectedTerminalId] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);
  const [visibleFields, setVisibleFields] = useState({});
  const toggleVisibility = (fieldName) => {
    setVisibleFields((prev) => ({
      ...prev, // This is crucial! It keeps the other fields as they were
      [fieldName]: !prev[fieldName],
    }));
  };
  const InitialData = {
    terminalTypeName: "",
    rnmsDetailId: "",
    siteNameId: "",
    groupName: "",
    userName: "",
    firstName: "",
    lastName: "",
    mailId: "",
    mobileNo: "",
    ipPhone: "",
    password: "",
    confirmPassword: "",
  };

  // 3. Validation Schema
  const schema = Yup.object({
    terminalTypeName: Yup.string().required("Terminal is required"),
    rnmsDetailId: Yup.string().required("Site ID is required"),
    siteNameId: Yup.string().notRequired(),
    groupName: Yup.string().required("Group Name is required"),
    userName: UsernameValidator,
    firstName: NameValidator,
    lastName: NameValidator,
    mailId: emailValidation,
    mobileNo: primaryMobileValidation,
    ipPhone: ipPhoneValidation,
    password: PasswordValidator,
    confirmPassword: Yup.string()
      .oneOf([Yup.ref("password")], "Passwords must match")
      .required("Confirm Password is required"),
  });

  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    validateOnMount: false,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: async (values) => {
      await handleSuccess(values);
    },
  });

  // 4. Helpers
  const getError = (field) => {
    return formik.touched[field] ? formik.errors[field] || null : null;
  };

  const handleInputChange = (field) => (event) => {
    formik.setFieldTouched(field, true, false);
    formik.setFieldValue(field, event.target.value);
  };

  // 5. Data Loading
  useEffect(() => {
    const loadTerminalData = async () => {
      try {
        // ONLY call API for Terminal Types. Users are coming from Redux.
        const terminalResponse = await InventoryAxios(
          FETCH_ALL_TERMINAL_TYPE_DETAILS,
          "get"
        );

        const terminals = Array.isArray(terminalResponse?.data)
          ? terminalResponse.data
          : [];

        setTerminalTypes(
          terminals.map((terminal) => ({
            label: terminal?.terminalTypeName || "Unknown",
            value: String(terminal.id),
            raw: terminal,
          }))
        );
      } catch (error) {
        console.error("Error loading terminal data:", error);
        Toast("Error!", "Error loading terminal details", "error");
      }
    };
    loadTerminalData();
  }, []);
  const [selectedTerminalObj, setSelectedTerminalObj] = useState(null);

  // 6. Process Redux Users into Relationship Data
  // This runs whenever allUsersFromRedux changes
  useEffect(() => {
    if (Array.isArray(allUsersFromRedux)) {
      // const relationshipData = allUsersFromRedux
      //   .map((user) => ({
      //     terminalTypeId:
      //       user?.group?.terminalType?.id != null
      //         ? String(user.group.terminalType.id)
      //         : "",
      //     terminalTypeName: user?.group?.terminalType?.terminalTypeName || "",
      //     rnmsDetailId:
      //       user?.rnmsDetailId != null ? String(user.rnmsDetailId) : "",
      //     groupName: user?.group?.groupName || "",
      //     groupId: user?.group?.id || "",
      //   }))
      //   .filter((item) => item.terminalTypeId && item.rnmsDetailId);

      // setTerminalSiteData(relationshipData);
    }
  }, [allUsersFromRedux]);

  const siteOptions = useMemo(() => {
    // If no terminal is selected, return empty (except for your CNMS fallback)
    if (!selectedTerminalId) {
      if (formik.values.rnmsDetailId === "CNMS_001") {
        return [{ value: "CNMS_001", label: "CNMS_001" }];
      }
      return [];
    }

    // Get the terminal info from the selected terminal object
    const targetSubTypeId = selectedTerminalObj?.subTypeId;
    // Note: In your data, terminal subtypes might be handled by ID or Name.
    // Based on your object, we will filter by terminalSubTypeId.

    // Filter the Redux data
    const matchingSites = fetchSiteDetails.filter((siteItem) => {
      // Logic: Match the site's terminalSubTypeId with the selected terminal's subTypeId
      // We use String() to ensure comparison works even if one is number and other is string
      return String(siteItem.terminalSubTypeId) === String(targetSubTypeId);
    });

    // Convert to MSelect format
    const options = matchingSites.map((item) => ({
      value: item.siteId, // From your object: siteId: "MCT-LSV_001"
      label: item.siteId, // From your object: siteName: "Bangalore"
      raw: item,
    }));

    // Deduplicate by siteId (just in case)
    const uniqueOptions = Array.from(
      new Map(options.map((opt) => [opt.value, opt])).values()
    );

    // 3. Keep the CNMS_001 fallback logic
    if (formik.values.rnmsDetailId === "CNMS_001") {
      const exists = uniqueOptions.find((opt) => opt.value === "CNMS_001");
      if (!exists) {
        uniqueOptions.push({
          value: "CNMS_001",
          label: "CNMS_001",
          raw: { siteId: "CNMS_001", siteName: "CNMS_001" },
        });
      }
    }

    return uniqueOptions;
  }, [
    selectedTerminalObj,
    fetchSiteDetails,
    formik.values.rnmsDetailId,
    selectedTerminalId,
  ]);
  const [nonDefaultGroups, setNonDefaultGroups] = useState([]);

  useEffect(() => {
    const fetchNonDefaultGroups = async () => {
      try {
        const res = await SecurityAxios(GET_ALL_NON_DEFAULT_GROUPS, "get");
        if (res?.data && Array.isArray(res.data)) {
          setNonDefaultGroups(res.data);
        }
      } catch (error) {
        console.error("Error fetching non-default groups:", error);
        Toast("Error!", "Failed to load groups", "error");
      }
    };
    fetchNonDefaultGroups();
  }, []);
  const groupOptions = useMemo(() => {
    if (!selectedTerminalId || !formik.values.rnmsDetailId) return [];

    const filteredGroups = nonDefaultGroups.filter((group) => {
      const matchesTerminal =
        String(group?.terminalType?.id) === String(selectedTerminalId);
      return matchesTerminal;
    });

    return filteredGroups.map((g) => ({
      label: g.groupName,
      value: String(g.id),
    }));
  }, [selectedTerminalId, formik.values.rnmsDetailId, nonDefaultGroups]);
  const handleTerminalChange = (newValue) => {
    const selectedId =
      typeof newValue === "object" ? newValue?.value : newValue;

    // 1. Find the full object from terminalTypes
    const foundTerminal = terminalTypes.find(
      (t) => String(t.value) === String(selectedId)
    );

    // 2. Update Local States
    setSelectedTerminalObj(foundTerminal?.raw || null);
    setSelectedTerminalId(selectedId || "");

    // 3. Update Formik
    formik.setFieldValue("terminalTypeName", foundTerminal?.label || "");

    // 4. Handle CNMS Hardcode vs Normal Flow
    if (String(selectedId) === "1") {
      // Set the value internally so validation passes
      formik.setFieldValue("rnmsDetailId", "CNMS_001");
      formik.setFieldValue("siteNameId", "CNMS_001");
      formik.setFieldTouched("rnmsDetailId", true, true);
    } else {
      formik.setFieldValue("rnmsDetailId", "");
      formik.setFieldValue("siteNameId", "");
    }

    formik.setFieldValue("groupName", "");
  };

  const handleSiteChange = (newValue) => {
    // MSelect usually returns the value directly or an object with a value property
    const value = typeof newValue === "object" ? newValue?.value : newValue;
    const siteValue = value ? String(value) : "";

    formik.setFieldValue("rnmsDetailId", siteValue);
    formik.setFieldValue("siteNameId", siteValue); // Syncing both as per your initial logic
    formik.setFieldValue("groupName", ""); // Reset group when site changes

    // Mark as touched to clear validation errors
    formik.setFieldTouched("rnmsDetailId", true, true);
    formik.setFieldTouched("siteNameId", true, true);
  };

  const handleSuccess = async (values) => {
    const payload = {
      userName: encryptData(values.userName),
      firstName: values.firstName,
      lastName: values.lastName,
      mailId: values.mailId,
      mobileNo: values.mobileNo,
      ipPhone: values.ipPhone,
      password: encryptData(values.password),

      // FIX: Ensure CNMS logic is applied here explicitly
      rnmsDetailId: values.rnmsDetailId || "CNMS_001",

      group: {
        id: Number(values.groupName),
      },
      ipaddress: "",
      id: values.id,
    };

    try {
      const response = await SecurityAxios(ADD_USERS, "post", payload);
      console.log("payload to send", response);

      if (response.status === 200 || response.status === 201) {
        Toast("Success!", "User details saved successfully!", "success");
        if (typeof onRefresh === "function") {
          onRefresh();
        }
        formik.resetForm();
        setSelectedTerminalId("");
        setShowConfirm(false);
        if (onClose) onClose();
      } else {
        Toast("Error!", "Failed to save details.", "error");
      }
    } catch (error) {
      console.error("Error saving user:", error);

      const errorMessage =
        error.response?.data?.message ||
        error.message ||
        "An unexpected error occurred";

      Toast("Error!", errorMessage, "error");
    }
  };

  const handleConfirmSubmit = async () => {
    setShowConfirm(false);
    await formik.validateForm();
    const allFields = [
      "terminalTypeName",
      "rnmsDetailId",
      "siteNameId",
      "userName",
      "firstName",
      "lastName",
      "mailId",
      "mobileNo",
      "ipPhone",
      "password",
      "confirmPassword",
      "groupName",
    ];
    const touchedFields = {};
    allFields.forEach((field) => {
      touchedFields[field] = true;
    });
    await formik.setTouched(touchedFields, true);

    const errors = await formik.validateForm();
    if (Object.keys(errors).length === 0) {
      await handleSuccess(formik.values);
    }
  };
  const isAddDisabled = () => {
    const mandatoryFields = [
      "terminalTypeName",
      "rnmsDetailId",
      "groupName",
      "userName",
      "firstName",
      "lastName",
      "mailId",
      "mobileNo",
      "ipPhone",
      "password",
      "confirmPassword",
    ];

    // Check if any mandatory field is empty/null/undefined
    const hasEmptyMandatory = mandatoryFields.some(
      (field) =>
        !formik.values[field] || String(formik.values[field]).trim() === ""
    );

    // Check if there are actual error messages in the errors object
    const hasAnyError = Object.keys(formik.errors).some(
      (key) => formik.errors[key] !== undefined && formik.errors[key] !== ""
    );

    return hasEmptyMandatory || hasAnyError;
  };

  return (
    <Box
      component="form"
      onSubmit={formik.handleSubmit}
      className="flex flex-col gap-5"
    >
      <Box sx={{ display: "flex", flexDirection: "column", ml: 3, mr: 5 }}>
        {/* 1. Terminal Type Selection */}
        <Box sx={{ display: "flex", flexDirection: "column" }}>
          <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>
            Terminal *
          </Typography>
          <MSelect
            options={terminalTypes}
            value={selectedTerminalId}
            onChange={handleTerminalChange}
            placeholder="Select Terminal Type"
            error={getError("terminalTypeName")}
            errorMessage={getError("terminalTypeName")}
            disabled={terminalTypes.length === 0}
          />
        </Box>

        {/* 2. Site ID Selection (Filtered by Terminal) */}
        {/* Only render this box if it's NOT CNMS (ID '1') */}
        {String(selectedTerminalId) !== "1" && (
          <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
            <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>
              Site ID *
            </Typography>
            <MSelect
              options={siteOptions}
              value={formik.values.rnmsDetailId}
              onChange={handleSiteChange}
              placeholder={
                selectedTerminalId
                  ? "Select Site ID"
                  : "Select Terminal Type first"
              }
              getOptionValue={(opt) => opt.value}
              getOptionLabel={(opt) => opt.label}
              disabled={!selectedTerminalId}
              error={getError("rnmsDetailId")}
              errorMessage={getError("rnmsDetailId")}
            />
            {selectedTerminalId && siteOptions.length === 0 && (
              <Typography variant="caption" color="error" sx={{ mt: 1 }}>
                No Site IDs found for this Terminal Type.
              </Typography>
            )}
          </Box>
        )}

        {/* 3. Group Name Selection (Filtered by Site) */}
        <Box sx={{ display: "flex", flexDirection: "column", mt: 2, mb: 2 }}>
          <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>
            Group Name *
          </Typography>
          <MSelect
            options={groupOptions}
            placeholder={
              formik.values.rnmsDetailId
                ? "Select Group"
                : "Select Site ID first"
            }
            value={formik.values.groupName}
            onChange={(newValue) => {
              const value =
                typeof newValue === "object" ? newValue?.value : newValue;
              formik.setFieldValue("groupName", value);
              formik.setFieldTouched("groupName", true, true);
            }}
            error={getError("groupName")}
            errorMessage={getError("groupName")}
            disabled={!formik.values.rnmsDetailId}
          />
        </Box>

        {/* Form Fields */}
        <Box sx={{ mb: 2 }}>
          <FormField
            label="User Name"
            required
            value={formik.values.userName}
            onChange={handleInputChange("userName")}
            onBlur={() => formik.setFieldTouched("userName", true)}
            error={getError("userName")}
            errorMessage={getError("userName")}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="First Name"
            required
            value={formik.values.firstName}
            onChange={handleInputChange("firstName")}
            onBlur={() => formik.setFieldTouched("firstName", true)}
            error={getError("firstName")}
            errorMessage={getError("firstName")}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="Last Name"
            required
            value={formik.values.lastName}
            onChange={handleInputChange("lastName")}
            onBlur={() => formik.setFieldTouched("lastName", true)}
            error={getError("lastName")}
            errorMessage={getError("lastName")}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="Email ID"
            required
            type="email"
            value={formik.values.mailId}
            onChange={handleInputChange("mailId")}
            onBlur={() => formik.setFieldTouched("mailId", true)}
            error={getError("mailId")}
            errorMessage={getError("mailId")}
            placeholder="example@domain.com"
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="Mobile Number"
            required
            value={formik.values.mobileNo}
            onChange={handleInputChange("mobileNo")}
            onBlur={() => formik.setFieldTouched("mobileNo", true)}
            error={getError("mobileNo")}
            errorMessage={getError("mobileNo")}
            placeholder="10 digit number"
            inputProps={{
              maxLength: 10,
              inputMode: "numeric",
            }}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="IP Phone"
            required
            value={formik.values.ipPhone}
            onChange={handleInputChange("ipPhone")}
            onBlur={() => formik.setFieldTouched("ipPhone", true)}
            error={getError("ipPhone")}
            errorMessage={getError("ipPhone")}
            placeholder="8 digit number"
            inputProps={{
              maxLength: 8,
              inputMode: "numeric",
            }}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="Password"
            required
            value={formik.values.password}
            onChange={handleInputChange("password")}
            onBlur={() => formik.setFieldTouched("password", true)}
            error={getError("password")}
            errorMessage={getError("password")}
            type={visibleFields.password ? "text" : "password"}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => toggleVisibility("password")}
                    edge="end"
                    onMouseDown={(e) => e.preventDefault()} // Keeps focus
                  >
                    {visibleFields.password ? (
                      <VisibilityIcon />
                    ) : (
                      <VisibilityOffIcon />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <FormField
            label="Confirm Password"
            required
            value={formik.values.confirmPassword}
            onChange={handleInputChange("confirmPassword")}
            onBlur={() => formik.setFieldTouched("confirmPassword", true)}
            error={getError("confirmPassword")}
            errorMessage={getError("confirmPassword")}
            type={visibleFields.password ? "text" : "password"}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => toggleVisibility("password")}
                    edge="end"
                    onMouseDown={(e) => e.preventDefault()} // Keeps focus
                  >
                    {visibleFields.password ? (
                      <VisibilityIcon />
                    ) : (
                      <VisibilityOffIcon />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Box>

        <Box
          sx={{
            float: "right",
            display: "flex",
            mt: 3,
            justifyContent: "flex-end",
          }}
        >
          <MButtonPrimary
            type="button"
            onClick={() => setShowConfirm(true)}
            disabled={isAddDisabled()}
          >
            Add
          </MButtonPrimary>
        </Box>
      </Box>

      <MDialog
        open={showConfirm}
        variant="warning"
        title="Confirm Action"
        icon={question_mark} // Ensure question_mark is imported
        message="Are you sure you want to add this User details?"
        onConfirm={handleConfirmSubmit}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default UserMgmtAdd;
