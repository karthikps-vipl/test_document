import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useMemo, useState } from "react";
import { InventoryAxios, SecurityAxios } from "@/RestAPI/api/axiosApicall"
import { BLOCK_USER, CHANGE_PASSWORD_OTHER_USER, FETCH_ALL_TERMINAL_TYPE_DETAILS, FORCE_DELETE_USER, GET_ALL_PRIVILEGES, GET_ALL_USERS, RESET_PASSWORD, UNBLOCK_USER } from "@/RestAPI/url/endpoint"
import { Box, CircularProgress, Grid, IconButton, InputAdornment, Typography, useTheme } from "@mui/material";
import MMultiSelect from "@/components/Reusable/Select/MMultiSelect";
import { useDispatch } from "react-redux";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import Toast from "@/components/Reusable/Toast/Toast";
import { setAllUsersData } from "@/store/features/Cnms/GetAllUsers/getAllUsersSlice";
import MInput from "@/components/Reusable/Input/MInput";
 import question_mark from "@/assets/SVGIcons/question_mark.svg"
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import { PasswordValidator } from "@/utility/FormValidation/YupSchema";
import * as Yup from "yup";
import { useFormik } from "formik";
import { encryptData } from "@/utility/encryptLogin";
import PrivilegeTree from "./PrivilegeTree";
import { Eye } from "lucide-react";
import MModal from "@/components/Reusable/Modal/MModal";

const changePasswordSchema = Yup.object().shape({
  newPassword: PasswordValidator,
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('newPassword'), null], 'Passwords must match')
    .required('Confirm password is required'),
});

const SiteIdCell = ({ rnmsDetailId }) => {
  // Logic to show '-' for CNMS
  const displayValue = rnmsDetailId === "CNMS_001" ? "-" : rnmsDetailId;

  return (
    <Box sx={{ 
      display: "flex", 
      justifyContent: "center", 
      alignItems: "center",     
      textAlign: "center"       
    }}>
      {displayValue}
    </Box>
  );
};


const GroupNameCell = ({ row, handleOpenPrivilegesModal, isDark }) => {
  return (
    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", minHeight: "32px" }}>
      <span>{row.groupName || "NO_GROUP_NAME"}</span>
      <IconButton
        size="small"
        onClick={(e) => {
          e.stopPropagation();
          handleOpenPrivilegesModal(row);
        }}
        sx={{ minWidth: '32px', height: '32px' }}
      >
        {typeof Eye !== 'undefined' ? (
          <Eye size={18} style={{ color: isDark ? "invert(1)" : "#14348d" }}/>
        ) : "ICON_ERR"}
      </IconButton>
    </Box>
  );
};

const UserMgmt = ({
  privilegeKey,
  handleEdit,
  handleDelete,
  handleView,
  handleAdd,
  refreshTrigger,
  handleBlock,
  onSuccess,
  onRefresh,isChildFullScreen
}) => {
  const dispatch = useDispatch();
  const [visibleFields, setVisibleFields] = useState({});
  const [selectedPrivilegeIds, setSelectedPrivilegeIds] = useState([]);
  const handleTogglePrivilege = (id) => {
    setSelectedPrivilegeIds((prev) =>
      prev.includes(id) 
        ? prev.filter((item) => item !== id) 
        : [...prev, id]
    );
  };
  const handleSelectAllPrivileges = async () => {
    
 
  };
  const toggleVisibility = (fieldName) => {
    setVisibleFields((prev) => ({
      ...prev,
      [fieldName]: !prev[fieldName],
    }));
  };
  const theme=useTheme()
  
  const isDark = theme.palette.mode === "dark";
  const [ipData, setIPData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [terminalTypes, setTerminalTypes] = useState([]);
  const [selectedTerminalIds, setSelectedTerminalIds] = useState([]);
  const [selectedSiteIds, setSelectedSiteIds] = useState([]);
  // const [uniqueSiteIds, setUniqueSiteIds] = useState([]);
  
  const [privilegeTreeData, setPrivilegeTreeData] = useState([]);
  const [treeModalVisible, setTreeModalVisible] = useState(false);
  const [selectedRowForTree, setSelectedRowForTree] = useState(null);
  
  // Dialog States
  const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });
  const [rowToResetPassword, setRowToResetPassword] = useState({ visible: false, row: null });
  
  // Change Password Modal & Input States
  const [changePasswordModal, setChangePasswordModal] = useState({ visible: false, row: null });
  // const [newPassword, setNewPassword] = useState("");
  // const [confirmPassword, setConfirmPassword] = useState("");
  const [blockModal, setBlockModal] = useState({ visible: false, row: null, actionType: "block" });
  const [remarks, setRemarks] = useState("");
  const [remarksError, setRemarksError] = useState("");

  const handleOpenPrivilegesModal = async (row) => {
    setSelectedRowForTree(row);
    try {
      setLoading(true);
      const res = await SecurityAxios(`${GET_ALL_PRIVILEGES}/${row.terminalTypeId}`, "get");      
      if (res?.data) {
        setPrivilegeTreeData(res.data);
        setTreeModalVisible(true);
      }
    } catch (error) {
      console.error("Error fetching privileges:", error);
      Toast("Error!", "Failed to load privileges", "error");
    } finally {
      setLoading(false);
    }
  };

  // --- Memoized Options for Filters ---
  const allTerminalOptions = useMemo(() => {
    const uniqueTerminalsMap = new Map();
    terminalTypes.forEach((item) => {
      if (item?.id != null) {
        if (!uniqueTerminalsMap.has(String(item.id))) {
          uniqueTerminalsMap.set(String(item.id), item);
        }
      }
    });
    return Array.from(uniqueTerminalsMap.values()).map((item) => ({
      label: item?.terminalTypeName || "Unknown",
      value: String(item.id),
      raw: item,
    }));
  }, [terminalTypes]);

  // const allSiteOptions = useMemo(() => {
  //   return uniqueSiteIds.map((siteId) => ({
  //     label: String(siteId),
  //     value: String(siteId),
  //     raw: { id: siteId },
  //   }));
  // }, [uniqueSiteIds]);

  const filteredTableData = useMemo(() => {
    if (selectedTerminalIds.length === 0 || selectedSiteIds.length === 0) {
      return [];
    }
  
    return ipData.filter((row) => {
      const terminalMatch = selectedTerminalIds.includes(String(row.terminalTypeId));
      const siteMatch = selectedSiteIds.includes(String(row.rnmsDetailId));
      return terminalMatch && siteMatch;
    });
  }, [ipData, selectedTerminalIds, selectedSiteIds]);

  // --- Data Fetching ---
  const formik = useFormik({
    initialValues: {
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema: changePasswordSchema,
    onSubmit: (values) => {
      onSubmit(values, user);
    },
  });

  useEffect(() => {
    if (!changePasswordModal.visible) {
      formik.resetForm({
        initialValues: {
          newPassword: "",
          confirmPassword: "",
        },
      });
    }
  }, [changePasswordModal.visible]);

  const fetchUsersAndGroups = async () => {
    try {
      setLoading(true);
      const usersRes = await SecurityAxios(GET_ALL_USERS, "get", 1);
      const usersData = usersRes?.data || [];

      if (!Array.isArray(usersData)) {
        setIPData([]);
        dispatch(setAllUsersData([]));
        return;
      }

      const processedData = usersData.map((item, index) => {
        const userGroup = item?.group || {};
        const userIsDefault = userGroup.isDefaultGroup === true;
        const isBlocked = item?.isBlocked === true;

        return {
          sno: index + 1,
          id: item.id,
          userId: item.id,
          terminalTypeName: userGroup?.terminalType?.terminalTypeName || "N/A",
          terminalTypeId: userGroup?.terminalType?.id != null ? String(userGroup.terminalType.id) : null,
          rnmsDetailId: item?.rnmsDetailId != null ? String(item.rnmsDetailId) : "",
          groupName: userGroup?.groupName || "",
          userName: item?.userName || "",
          firstName: item?.firstName || "",
          lastName: item?.lastName || "",
          mobileNo: item?.mobileNo || "",
          ipPhone: item?.ipPhone || "",
          mailId: item?.mailId || "",
          originalPassword: item?.originalPassword || null,
          isDefaultGroup: userIsDefault,
          isGroupDisabled: userIsDefault,
          isBlocked: isBlocked,
        };
      });

      setIPData(processedData);
      // const sites = [...new Set(processedData.map((item) => item.rnmsDetailId).filter(Boolean))];
      // setUniqueSiteIds(sites);
      dispatch(setAllUsersData(usersData));
    } catch (error) {
      console.error("Error fetching users:", error);
      setIPData([]);
      dispatch(setAllUsersData([]));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsersAndGroups();
  }, [dispatch, refreshTrigger]);

  useEffect(() => {
    const fetchTerminalTypes = async () => {
      try {
        const res = await InventoryAxios(FETCH_ALL_TERMINAL_TYPE_DETAILS, "get");
        const terminals = Array.isArray(res?.data) ? res.data : [];
        setTerminalTypes(terminals);
      } catch (error) {
        console.error("Error loading terminals:", error);
        Toast("Error!", "Error loading terminals", "error");
        setTerminalTypes([]);
      }
    };
    fetchTerminalTypes();
  }, []);

  // Combined Initialization Effect to select all terminals and sites by default
  useEffect(() => {
    if (!terminalTypes || terminalTypes.length === 0) return;

    // const allTerminalIds = terminalTypes
    //   .filter((t) => t && t.id != null)
    //   .map((t) => String(t.id));

    //sonar
    const allTerminalIds = terminalTypes
    .filter((t) => t?.id != null) // Uses optional chaining and handles both null/undefined
    .map((t) => String(t.id));
    
    const allSiteIds = [
      ...new Set(
        ipData
          .map((row) => String(row.rnmsDetailId))
          .filter((id) => id && id !== "null" && id !== "undefined" && id !== "")
      )
    ];

    setSelectedTerminalIds(allTerminalIds);
    setSelectedSiteIds(allSiteIds);
  }, [terminalTypes, ipData]); 

  const handleTerminalChange = (newValue) => {
    const terminalIds = (newValue || []).map(String);
    setSelectedTerminalIds(terminalIds);
  };

  // const handleSiteChange = (newValue) => {
  //   const siteIds = (newValue || []).map(String);
  //   setSelectedSiteIds(siteIds);
  // };

  const handleDeleteRow = async (row) => {
    const payload = {
      id: row.userId,
      rnmsDetailId: row.rnmsDetailId,
    };

    try {
      await SecurityAxios(FORCE_DELETE_USER, "post", payload);
      Toast("Success!", "User deleted successfully", "success");
      const newData = ipData.filter(item => item.userId !== row.userId);
      setIPData(newData);
      // const remainingSites = [...new Set(newData.map((item) => item.rnmsDetailId).filter(Boolean))];
      // setUniqueSiteIds(remainingSites);
    } catch (error) {
      console.error("Error deleting user:", error);
      Toast("Error!", "Failed to delete user", "error");
    }
  };

  const handleResetPasswordRow = async (row) => {
    const payload = {
      id: row.userId,
      rnmsDetailId: row.rnmsDetailId,
    };

    try {
      await SecurityAxios(RESET_PASSWORD, "post", payload);
      Toast("Success!", "Password reset to default successfully", "success");
    } catch (error) {
      console.error("Error resetting password:", error);
      Toast("Error!", "Failed to reset password", "error");
    }
  };

  const handleChangePasswordSubmit = async (values, row) => {
    const payload = {
      id: row.userId,
      rnmsDetailId: row.rnmsDetailId,
      newPassword: encryptData(values.newPassword),
    };
  
    try {
       const res = await SecurityAxios(CHANGE_PASSWORD_OTHER_USER, "post", payload);
       if (res?.status === 200 && res?.data?.status === 1) {
        Toast("Success!", "Password changed successfully", "success");
        setChangePasswordModal({ visible: false, row: null });
         formik.resetForm(); 
        if (typeof refreshTrigger === "function") {
          refreshTrigger();
        }
      } else if (res?.status === 200 && res?.data?.status === 0) {
         const errorMsg = res?.data?.message || "Failed to change password due to business logic.";
        Toast("Error!", errorMsg, "error");
      } else {
        Toast("Error!", "An unexpected response was received", "error");
      }
    } catch (error) {
       console.error("Error changing password:", error);
      const errorMsg = error?.response?.data?.message || "Failed to connect to server.";
      Toast("Error!", errorMsg, "error");
    }
  };

  const customDeleteHandler = (row) => {
    if (row.isGroupDisabled) {
      Toast("Error!", "Cannot delete this user. The group is a default group.", "error");
      return;
    }
    setRowToDelete({ visible: true, row });
  };

  const handleBlockUnblockSubmit = async () => {
    if (!remarks || remarks.trim().length < 10) {
      setRemarksError("Remarks cannot be empty and must be at least 10 characters.");
      return;
    }

    const { row, actionType } = blockModal;
    const endpoint = actionType === "block" ? BLOCK_USER : UNBLOCK_USER;
    const payload = {
      id: row.userId,
      remarks: remarks.trim(),
      rnmsDetailId: row.rnmsDetailId,
    };

    try {
      const res = await SecurityAxios(endpoint, "post", payload);
      if (res?.data?.status || res?.status === 200) {
        Toast("Success!", res?.data?.message || `User ${actionType}ed successfully`, "success");
        setBlockModal({ visible: false, row: null, actionType: "block" });
        setRemarks("");
        setRemarksError("");
        fetchUsersAndGroups();
        if (typeof onRefresh === "function") {
          onRefresh();
        }
      } else {
        Toast("Error!", res?.data?.message || `Failed to ${actionType} user`, "error");
      }
    } catch (error) {
      console.error(`Error during user ${actionType}:`, error);
      Toast("Error!", error?.response?.data?.message || `Failed to connect to server`, "error");
    }
  };



  const columns = [
    { name: "S. No", uid: "sno", width: "70px" },
    { name: "Terminal", uid: "terminalTypeName" },
    { 
      name: "Site ID", 
      uid: "rnmsDetailId",
      width: "150px", 
      // cell: (row) => {
      //   // 1. Logic to show '-' for CNMS
      //   const displayValue = row.rnmsDetailId === "CNMS_001" ? "-" : row.rnmsDetailId;
        
      //   // 2. Wrap in Box for centering
      //   return (
      //     <Box sx={{ 
      //       display: "flex", 
      //       justifyContent: "center", // Centers content horizontally
      //       alignItems: "center",     // Centers content vertically
      //       textAlign: "center"       // Fallback for text alignment
      //     }}>
      //       {displayValue}
      //     </Box>
      //   );
      // }
      cell: (row) => <SiteIdCell rnmsDetailId={row.rnmsDetailId} />
    },
    
    
    {
      name: "Group Name",
      uid: "groupName",
      width: "200px",
      // cell: (row) => {
      //   return (
      //     <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%", minHeight: "32px" }}>
      //       <span>{row.groupName || "NO_GROUP_NAME"}</span>
      //       <IconButton
      //         size="small"
      //         onClick={(e) => {
      //           e.stopPropagation();
      //           handleOpenPrivilegesModal(row);
      //         }}
      //         sx={{ minWidth: '32px', height: '32px' }}
      //       >
      //         {typeof Eye !== 'undefined' ? <Eye size={18} style={{ color: isDark ? "invert(1)" : "#14348d", } }/> : "ICON_ERR"}
      //       </IconButton>
      //     </Box>
      //   );
      // }
      // Pass necessary dependencies as props
      cell: (row) => (
        <GroupNameCell 
          row={row} 
          handleOpenPrivilegesModal={handleOpenPrivilegesModal} 
          isDark={isDark} 
        />
      )
    },
    { name: "User Name", uid: "userName" },
    { name: "First Name", uid: "firstName" },
    { name: "Last Name", uid: "lastName" },
    { name: "Mobile No", uid: "mobileNo", width: "120px" },
    { name: "Ip Phone", uid: "ipPhone" },
    { name: "Email ID", uid: "mailId", width: "190px" },
    {
      name: "Actions",
      uid: "actions",
      sortable: false,
      cellClassName: "sticky-actions",
      headerClassName: "sticky-actions",
      width: "220px"
    },
  ];

  return (
    <Box>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Box sx={{ marginBottom: 2, display: "flex", flexDirection: "column", gap: 2 }}>
          {/* Filters Section */}
          <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, gap: 2, width: "100%" }}>
            <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
              <Typography sx={{ mb: 0.5, pl: 1 }}>Terminals</Typography>
              <MMultiSelect 
                options={allTerminalOptions} 
                value={selectedTerminalIds} 
                onChange={handleTerminalChange} 
                placeholder="Choose terminal type(s)..." 
              />
            </Box>
            <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
              {/* <Typography sx={{ mb: 0.5, pl: 1 }}>Site ID</Typography>
              <MMultiSelect 
                options={allSiteOptions} 
                value={selectedSiteIds} 
                onChange={handleSiteChange} 
                placeholder="Choose site ID(s)..." 
              /> */}
            </Box>
          </Box>

          {/* Table Section */}
          <MTable
            privilegeKey={privilegeKey}
            columns={columns}
            tableData={filteredTableData}
            showPagination={true}
            showSearch={true}
            hideAdd={false}
            AddText="Add"
            handleAdd={() => handleAdd({ mode: "CREATE", title: "Add User Details" })}
            handleEdit={(row) => handleEdit({ ...row, password: row.originalPassword, mode: "EDIT", title: "Update Login Details" })}
            handleDelete={customDeleteHandler}
            deleteDisable={(row) => row.isGroupDisabled}
            refreshTrigger={refreshTrigger}
            handleResetPasswordClick={(row) => {
              setRowToResetPassword({ visible: true, row: row });
            }}
            handleChangePasswordClick={(row) => {
              setChangePasswordModal({ visible: true, row: row });
              formik.resetForm({
                initialValues: {
                  newPassword: "",
                  confirmPassword: "",
                },
              });
              // setNewPassword("");
              // setConfirmPassword("");
            }}
            blockDisable={(row) => row.isDefaultGroup}
            blockColor={(row) => (row.isBlocked ? "error" : "success")}
            handleBlock={(row) => {
              if (row.isDefaultGroup) return;
              const actionType = row.isBlocked ? "unblock" : "block";
              setBlockModal({ visible: true, row, actionType });
              setRemarks("");
              setRemarksError("");
            }}
          />
        </Box>
      )}

      {/* Delete Confirmation Dialog */}
      {rowToDelete.visible && (
        <MDialog
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          mode="child"
          isChildFullScreen={isChildFullScreen}

           message={`Are you sure you want to delete ${rowToDelete.row.userName} login detail?`}
          icon={Delete_Icon_}
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null });
          }}
          onClose={() => setRowToDelete({ visible: false, row: null })}
        />
      )}

      {/* Reset Password Confirmation Dialog */}
      {rowToResetPassword.visible && (
        <MDialog
          open={rowToResetPassword.visible}
          variant="warning"
          title="Reset Password"
          mode="child"
          isChildFullScreen={isChildFullScreen}

          icon={question_mark}
          message="Are you sure you want to set the password to default ?"
          onConfirm={() => {
            handleResetPasswordRow(rowToResetPassword.row);
            setRowToResetPassword({ visible: false, row: null });
          }}
          onClose={() => setRowToResetPassword({ visible: false, row: null })}
        />
      )}

      {blockModal.visible && (
        <MDialog
          open={blockModal.visible}
          title={`${blockModal.actionType === "block" ? "Block" : "Unblock"} User`}
          mode="child"
          isChildFullScreen={isChildFullScreen}

          icon={question_mark}
          onConfirm={handleBlockUnblockSubmit}
          onClose={() => {
            setBlockModal({ visible: false, row: null, actionType: "block" });
            setRemarks("");
            setRemarksError("");
          }}
        >
          <Typography sx={{ mb: 1 }}>
            Provide remarks to {blockModal.actionType} user <b>{blockModal.row?.userName}</b>
          </Typography>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 1, pl: 1, pr: 1 }}>
            <MInput
              name="remarks"
              value={remarks}
              onChange={(e) => {
                setRemarks(e.target.value);
                if (e.target.value.trim().length >= 10) setRemarksError("");
              }}
              placeholder="Enter remarks (minimum 10 characters)..."
              error={Boolean(remarksError)}
              errorMessage={remarksError}
              fullWidth
              multiline
              rows={3}
            />
          </Box>
        </MDialog>
      )}

{treeModalVisible && (
  <MModal
    open={treeModalVisible}
    title="GENERAL PRIVILEGES"
    mode="child"
    handleClose={() => {
      setTreeModalVisible(false);
      setPrivilegeTreeData([]);
    }}
  >
    <Box sx={{ mt: 1 }}>
      <Typography variant="caption" color="textSecondary" sx={{ mb: 1, display: 'block' }}>
        Privileges for group: <b>{selectedRowForTree?.groupName}</b>
      </Typography>
      
      {/* UPDATED LINE BELOW */}
      <PrivilegeTree 
        flatData={privilegeTreeData} 
        selectedIds={selectedPrivilegeIds} // Pass the state
        onToggle={handleTogglePrivilege}    // Pass the toggle handler
        onSelectAll={handleSelectAllPrivileges} // Pass select all handler
        allSelected={selectedPrivilegeIds.length} // Pass count for indeterminate logic
        isReadOnly={true} 
        />
    </Box>
  </MModal>
)}

      {changePasswordModal.visible && (
        <MDialog
          open={changePasswordModal.visible}
          title="Change Password"
          mode="child"
          isChildFullScreen={isChildFullScreen}
          
          icon={question_mark}
          onConfirm={() => handleChangePasswordSubmit(formik.values, changePasswordModal.row)}
          onClose={() => setChangePasswordModal({ visible: false, row: null })}
        >
          <Typography sx={{ mb: 1 }}>
            Change password for <b>{changePasswordModal.row?.userName}</b>
          </Typography>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 1, pl:3}}>
            <Grid container spacing={1} alignItems="flex-start">
              <Grid item xs={4}>
                <Typography sx={{ mt: 1 }}>New Password</Typography>
              </Grid>
              <Grid item xs={8}>
                <MInput
                  type={visibleFields.password ? "text" : "password"}
                  name="newPassword"
                  value={formik.values.newPassword}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  error={formik.values.newPassword.length > 0 && Boolean(formik.errors.newPassword)}
                  errorMessage={formik.values.newPassword.length > 0 ? formik.errors.newPassword : ""}
                  fullWidth
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => toggleVisibility("password")} edge="end">
                          {visibleFields.password ? <VisibilityIcon /> : <VisibilityOffIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
            </Grid>

            <Grid container spacing={1} alignItems="flex-start">
              <Grid item xs={4}>
                <Typography sx={{ mt: 1 }}>Confirm password</Typography>
              </Grid>
              <Grid item xs={8}>
                <MInput
                  type={visibleFields.password ? "text" : "password"}
                  name="confirmPassword"
                  value={formik.values.confirmPassword}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  error={formik.values.confirmPassword.length > 0 && Boolean(formik.errors.confirmPassword)}
                  errorMessage={formik.values.confirmPassword.length > 0 ? formik.errors.confirmPassword : ""}
                  fullWidth
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => toggleVisibility("password")} edge="end">
                          {visibleFields.password ? <VisibilityIcon /> : <VisibilityOffIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
            </Grid>
          </Box>
        </MDialog>
      )}
    </Box>
  );
};

export default UserMgmt;
 