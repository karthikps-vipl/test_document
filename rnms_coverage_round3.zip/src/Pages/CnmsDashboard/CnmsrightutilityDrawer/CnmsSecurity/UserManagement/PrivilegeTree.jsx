import React, { useState } from 'react';
import { Box, Checkbox, Typography, TextField, InputAdornment, useTheme } from '@mui/material';
import {
  Folder as FolderIcon,
  Description as FileIcon,
  KeyboardArrowDown as ExpandDown,
  Search as SearchIcon,
} from '@mui/icons-material';

const buildTree = (data, parentId = 0) => {
  return data
    .filter((item) => item.parent === parentId)
    .map((item) => ({
      ...item,
      children: buildTree(data, item.id),
    }));
};

const TreeNode = ({ node, level = 0, selectedIds, onToggle, searchTerm, isReadOnly }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasChildren = node.children && node.children.length > 0;
  const isChecked = selectedIds.includes(node.id);
  
  const matchesSearch = node.privilegeName.toLowerCase().includes(searchTerm.toLowerCase());
  const hasMatchingChild = node.children?.some(child =>
    child.privilegeName.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const shouldShow = searchTerm === "" || matchesSearch || hasMatchingChild;
  
  if (searchTerm !== "" && !shouldShow) return null;
  
  return (
    <Box sx={{ ml: level > 0 ? 3 : 0, mt: 0.5 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Box sx={{ width: 24, display: 'flex', justifyContent: 'center' }}>
          {hasChildren && (
            <ExpandDown
              fontSize="small"
              sx={{ cursor: 'pointer', color: 'text.secondary' }}
              onClick={() => setIsExpanded(!isExpanded)}
            />
          )}
          {!hasChildren && <Box sx={{ width: 24 }} />}
        </Box>
  
        {/* HIDE CHECKBOX IF READ ONLY */}
        {!isReadOnly && (
          <Checkbox
            size="small"
            checked={isChecked}
            onChange={() => onToggle(node.id)}
            sx={{ p: 0.5 }}
          />
        )}
  
        {hasChildren ? (
          <FolderIcon sx={{ color: '#ffca28', fontSize: 20 }} />
        ) : (
          <FileIcon sx={{ color: '#90a4ae', fontSize: 20 }} />
        )}
  
        <Typography variant="body2" sx={{ fontWeight: hasChildren ? 600 : 400 }}>
          {node.privilegeName}
        </Typography>
      </Box>
  
      {hasChildren && isExpanded && (
        <Box>
          {node.children.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              level={level + 1}
              selectedIds={selectedIds}
              onToggle={onToggle}
              searchTerm={searchTerm}
              isReadOnly={isReadOnly} // Pass it down
            />
          ))}
        </Box>
      )}
    </Box>
  );
};
  
const PrivilegeTree = ({ 
  flatData, 
  selectedIds = [], // Default to empty array to prevent undefined error
  onToggle, 
  onSelectAll, 
  allSelected, 
  isReadOnly = false // NEW PROP
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const treeData = buildTree(flatData);
  
  if (!treeData || treeData.length === 0) {
    return <Typography sx={{ p: 2 }}>No privileges found.</Typography>;
  }
  const theme=useTheme()
  return (
    <Box sx={{ p: 1,background:theme.palette.custom.rightUtilityDrawer.bg}}>
      <Box sx={{  mb: 2, px: 1, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        <TextField
          size="small"
          fullWidth
          placeholder="Search privileges..."
          variant="outlined"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
  
        {/* HIDE SELECT ALL SECTION IF READ ONLY */}
        {!isReadOnly && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5, borderBottom: '1px solid #f0f0f0' }}>
            <Checkbox
              size="small"
              indeterminate={allSelected > 0 && allSelected < flatData.length}
              checked={allSelected === flatData.length && flatData.length > 0}
              onChange={onSelectAll}
              sx={{ p: 0.5 }}
            />
            <Typography variant="body2" sx={{ fontWeight: 500, userSelect: 'none' }}>
              Select All Privileges
            </Typography>
          </Box>
        )}
      </Box>

      <Box sx={{ maxHeight: '85vh', overflowY: 'auto', border: '2px solid #eee', borderRadius: 1 }}>
        {treeData.map((rootNode) => (
          <TreeNode
            key={rootNode.id}
            node={rootNode}
            level={0}
            selectedIds={selectedIds}
            onToggle={onToggle}
            searchTerm={searchTerm}
            isReadOnly={isReadOnly} // Pass it down
          />
        ))}
      </Box>
    </Box>
  );
};
export default PrivilegeTree;