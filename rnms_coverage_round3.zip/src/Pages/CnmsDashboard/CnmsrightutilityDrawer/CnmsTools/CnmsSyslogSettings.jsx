import MTable from "@/components/Reusable/Table/MTable";
import React, { useCallback, useEffect, useState } from "react";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { Box, CircularProgress } from "@mui/material";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  FETCH_SYS_LOG_SERVER_SETTINGS,
  REMOVE_SYS_LOG_SERVER_SETTINGS,
} from "@/RestAPI/url/cnmsEndPoint";
const CnmsSyslogSettings = ({
  isChildFullScreen,
  privilegeKey,
  handleAdd,
  refreshTrigger,
  handleEdit,
}) => {
  const [syslogData, setSyslogData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });

  const fetchSyslogSettings = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await FaultAxios(FETCH_SYS_LOG_SERVER_SETTINGS, "get");

      const processedData = (data || []).map((item, index) => ({
        sno: index + 1,
        ipaddress: item.ipaddress || item.ip,
        portNumber: item.portNumber,
        id: item.id,
      }));

      setSyslogData(processedData);
    } catch (error) {
      console.error("Error fetching syslog settings:", error);
      Toast("Error!", "Failed to load syslog settings", "error");
      setSyslogData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch data on mount and whenever refreshTrigger changes
  useEffect(() => {
    fetchSyslogSettings();
  }, [fetchSyslogSettings, refreshTrigger]);

  /**
   * Deletes an IP Address entry
   */
  const handleDeleteRow = async (row) => {
    const payload = {
      ipaddress: row.ipaddress,
      id: row.id,
      portNumber: row.portNumber,
    };

    try {
      await FaultAxios(REMOVE_SYS_LOG_SERVER_SETTINGS, "post", payload);
      Toast("Success!", "IP Address deleted successfully", "success");
      setSyslogData((prev) =>
        prev.filter((item) => item.ipaddress !== row.ipaddress)
      );
    } catch (error) {
      console.error("Error deleting IP:", error);
      Toast("Error!", "Failed to delete IP Address", "error");
    }
  };

  const columns = [
    { name: "S. No", uid: "sno", width: "73px" },
    { name: "IP Address", uid: "ipaddress" },
    { name: "Port", uid: "portNumber" },
    { name: "Actions", uid: "actions", width: "100px" },
  ];

  return (
    <Box>
      {loading ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: "100%",
            height: "200px",
          }}
        >
          <CircularProgress />
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          columns={columns}
          tableData={syslogData}
          showPagination={true}
          showSearch={true}
          refreshTrigger={refreshTrigger}
          hideAdd={false}
          AddText="Add"
          handleAdd={() => {
            handleAdd({
              mode: "CREATE",
              title: "Add Syslog Server",
              // Removed selectedTerminalId from payload
            });
          }}
          handleDelete={(row) => {
            setRowToDelete({ visible: true, row: row });
          }}
          handleEdit={(row) =>
            handleEdit({
              ...row,

              mode: "EDIT",
              title: "Edit Syslog Server",
            })
          }
        />
      )}

      {rowToDelete.visible && (
        <MDialog
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          mode="child"
          isChildFullScreen={isChildFullScreen}
          message={`Are you sure you want to delete ${rowToDelete.row.ipaddress}?`}
          icon={Delete_Icon_}
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null });
          }}
          onClose={() => setRowToDelete({ visible: false, row: null })}
        />
      )}
    </Box>
  );
};

export default CnmsSyslogSettings;
