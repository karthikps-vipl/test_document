
import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
} from '@mui/material';
import MButtonPrimary from '@/components/Reusable/Button/MButtonPrimary';
import MInput from '@/components/Reusable/Input/MInput';
import question_mark from "@/assets/SVGIcons/question_mark.svg";
 
import { FaultAxios } from '@/RestAPI/api/axiosApicall';
import MDialog from '@/components/Reusable/Dialog/MDialog';
import Toast from '@/components/Reusable/Toast/Toast';
import {UPDATE_SYS_LOG_SERVER_SETTINGS } from '@/RestAPI/url/cnmsEndPoint';
 

const CnmsSyslogSettingsEdit = ({ onClose, onRefresh, isGrandchildFullScreen, row }) => {
    // Initialize states with values from 'row'
    const [ip, setIp] = useState(row?.ipaddress || "");
    const [ipType, setIpType] = useState("1");
    const [ipError, setIpError] = useState("");
    const [port, setPort] = useState(row?.portNumber?.toString() || "");
    const [portError, setPortError] = useState("");
    const [showConfirm, setShowConfirm] = useState(false);
    const id = row?.id;

    // IMPORTANT: Update local state if the 'row' prop changes
    useEffect(() => {
        if (row) {
            setIp(row.ipaddress || "");
            setPort(row.portNumber?.toString() || "");
            // Reset errors when row changes to ensure a clean slate
            setIpError("");
            setPortError("");
        }
    }, [row]);

    /**
     * CHANGE TRACKING LOGIC
     * The button should be enabled only if:
     * 1. The IP or Port is different from the original row values
     * 2. There are no validation errors
     */
    const isChanged = 
        ip !== (row?.ipaddress || "") || 
        port !== (row?.portNumber?.toString() || "");

    const isInvalid = !!ipError || !!portError || !ip || !port;

    const onChangeIpValues = (value) => {
        let parsedValue = value;
        if (ipType === "1") {
            let cleaned = value.replace(/[^0-9.]/g, "");
            cleaned = cleaned.replace(/\.{2,}/g, ".");
            let parts = cleaned.split(".");
            if (parts.length > 4) return;
            for (let i = 0; i < parts.length; i++) {
                let part = parts[i];
                if (part === "") continue;
                let num = parseInt(part, 10);
                if (isNaN(num) || num > 255) return;
                if (part.length > 1 && part.startsWith("0")) return;
            }
            parsedValue = cleaned;
        } else {
            parsedValue = value.toLowerCase().replace(/[^0-9a-f:%]/g, "");
        }
        setIp(parsedValue);
        validateIp(parsedValue);
    };

    const onChangePortValues = (value) => {
        let numericValue = value.replace(/[^0-9]/g, "");
        if (numericValue.length > 5) return;
        setPort(numericValue);
        if (numericValue === "") {
            setPortError("Port is required");
        } else {
            const portNum = parseInt(numericValue, 10);
            if (portNum < 0 || portNum > 65535) {
                setPortError("Port should be between 0 to 65535");
            } else {
                setPortError("");
            }
        }
    };

    const validateIp = (currentIp) => {
        if (currentIp === "") {
            setIpError("IP Address cannot be empty");
            return;
        }
        if (ipType === "1") {
            const ipV4Regx = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            if (!ipV4Regx.test(currentIp)) {
                setIpError("Invalid IPv4 Address format");
                return;
            }
            const parts = currentIp.split('.');
            let valid = true;
            parts.forEach(part => {
                const num = parseInt(part, 10);
                if (isNaN(num) || num < 0 || num > 255) valid = false;
            });
            if (!valid) {
                setIpError("IP segments must be between 0 and 255");
            } else {
                setIpError("");
            }
        } else {
            setIpError(currentIp.length < 1 ? "IP Address cannot be empty" : "");
        }
    };

    const handleAddSubmit = (e) => {
        if (e) e.preventDefault();
        if (isInvalid) return;
        setShowConfirm(true);
    };

    const confirmAddition = async () => {
        setShowConfirm(false);
        const payload = {
            ipaddress: ip,
            portNumber: port,
            id: id
        };
        try {
            const response = await FaultAxios(UPDATE_SYS_LOG_SERVER_SETTINGS, "post", payload);
            Toast("Success!", response.data?.message || "Details updated successfully!", "success");
            if (onRefresh) onRefresh();
            if (onClose) onClose();
        } catch (error) {
            console.error("Error saving details:", error);
            Toast("Error!", "Failed to save details. Please try again.", "error");
        }
    };

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, width: '100%' }}>
            <Box sx={{ display: 'flex', pl: 2, pr: 3, flexDirection: 'column' }}>
                <Typography sx={{ mb: 0.5 }}>IP Address *</Typography>
                <MInput
                    fullWidth
                    value={ip}
                    onChange={(e) => onChangeIpValues(e.target.value)}
                    error={!!ipError}
                    helperText={ipError}
                    size="small"
                    placeholder={ipType === "1" ? "___.___.___.___" : "e.g. 2001:0db8::1"}
                />
            </Box>

            <Box sx={{ mt: 2, display: 'flex', pl: 2, pr: 3, flexDirection: 'column' }}>
                <Typography sx={{ mb: 0.5 }}>Port *</Typography>
                <MInput
                    fullWidth
                    value={port}
                    onChange={(e) => onChangePortValues(e.target.value)}
                    error={!!portError}
                    helperText={portError}
                    size="small"
                    placeholder="Port Number"
                    inputProps={{ inputMode: "numeric" }}
                />
            </Box>

            <Box sx={{ display: 'flex', justifyContent: 'flex-end', pr: 3, mt: 2 }}>
                <MButtonPrimary
                    variant="contained"
                    color="primary"
                    onClick={handleAddSubmit}
                    /* 
                       LOGIC: Disable if:
                       1. Nothing has changed (isChanged is false)
                       OR
                       2. There is a validation error (isInvalid is true)
                    */
                    disabled={!isChanged || isInvalid}
                >
                    Update
                </MButtonPrimary>
            </Box>

            <MDialog
                open={showConfirm}
                variant="warning"
                title="Confirm Action"
                icon={question_mark}
                message={`Are you sure you want to update to ${ip}:${port}?`}
                onConfirm={confirmAddition}
                onClose={() => setShowConfirm(false)}
                mode="grandchild"
                isGrandchildFullScreen={isGrandchildFullScreen}
            />
        </Box>
    );
};

export default CnmsSyslogSettingsEdit;