import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { ConfigurationAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  COMAPARE_BACKUP_DATA,
  COMPARE_BACKUP_DATA_AT_CNMS,
  FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES,
  FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES_AT_CNMS,
  FETCH_ALL_REMOTE_TERMINAL_TYPE_DETAILS_AT_CNMS,
  FETCH_BACKUP_DATA_BY_RESOURCE_ID,
  FETCH_SITEDETAILS_BY_TERMINALTYPE_ID,
  FTECH_BACKUP_DATA_BY_RESOURCE_ID_SITE_ID_AT_CNMS,
  GET_BACKUP_MODE_ENUM,
  GET_COMPARE_TYPE_ENUM,
} from "@/RestAPI/url/cnmsEndPoint";
import Toast from "@/components/Reusable/Toast/Toast";
import PreviewDialog from "./Preview";
import {
  Box,
  CircularProgress,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";
import { Visibility } from "@mui/icons-material";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MForm from "@/components/Reusable/Form/MForm";

const FILES_FETCH_FAILED = "Fetching Files Failed!";
const COMPARE_TYPE_FETCH_FAILED = "Fetching Compare Type Failed!";
const COMPARE_DATA_FETCH_FAILED = "Couldn't Fetch File Contents!";

export default function ConfigFileCompareDialog() {
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const [compareWith, setCompareWith] = useState("RunningConfiguration");
  // const [deviceTypes, setDeviceTypes] = useState([]);
  const [selectedDeviceType] = useState("Select One");
  const [devices, setDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [filesNames, setFilesNames] = useState([]);
  const [selectedFileName1, setSelectedFileName1] = useState("Select One");
  const [selectedFileName2, setSelectedFileName2] = useState("Select One");
  const [compareTypeEnum, setCompareTypeEnum] = useState(null);
  const [loadingDevices] = useState(false);
  const [loadingConfigFiles, setLoadingConfigFiles] = useState(false);
  const [openPreviewDialog, setOpenPreviewDialog] = useState(false);
  const [compData, setCompData] = useState({});
  const [backupModeEnum, setBackupModeEnum] = useState({});
  const [selectedTerminal, setSelectedTerminal] = useState("");
  const [allTerminalTypes, setAllTerminalTypes] = useState([]);
  const [selectedSiteId, setSelectedSiteId] = useState("");
  const [allSites, setAllSites] = useState([]);
  const [loader, setLoader] = useState(false);

  const findAllDeviceNames = async () => {
    try {
      const response = await InventoryAxios(
        FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES,
        "get"
      );
      if (response?.data) {
        setDevices(response?.data || []);
      } else {
        setDevices([]);
      }
    } catch (error) {
      console.error("error", error);
    }
  };

  const validate = () => {
    let isValid =
      selectedDevice !== "Select One" && selectedFileName1 !== "Select One";
    if (compareWith === "ConfigFile") {
      isValid = isValid && selectedFileName2 !== "Select One";
    }
    return isValid;
  };

  const fetchAllFileNamesAtCnms = async (resourceId, siteId) => {
    setLoadingConfigFiles(true);
    try {
      const url = `${FTECH_BACKUP_DATA_BY_RESOURCE_ID_SITE_ID_AT_CNMS}/${resourceId}/${siteId}`;
      const response = await ConfigurationAxios(url, "get");
      // setResourceData(response.data);
      const files = response?.data?.map((el) => {
        return {
          ...el,
          fileName: el.fileName,
          id: el.id,
          filesDescription: el.description,
          mode: el.backupMode === 2 ? "SCHEDULED" : "MANUAL",
        };
      });
      setFilesNames(files);
    } catch (e) {
      console.error(e);
      Toast("", FILES_FETCH_FAILED, "error");
    }
    setLoadingConfigFiles(false);
  };

  const fetchAllFileNames = async (resourceId) => {
    setLoadingConfigFiles(true);
    try {
      const response = await ConfigurationAxios(
        `${FETCH_BACKUP_DATA_BY_RESOURCE_ID}/${resourceId}`
      );
      const files = response.data.map((el) => {
        return { fileName: el.fileName, id: el.id };
      });
      setFilesNames(files);
    } catch (error) {
      Toast("", FILES_FETCH_FAILED, "error");
      console.error(error);
    }
    setLoadingConfigFiles(false);
  };
  const fetchCompareTypeEnum = React.useCallback(async () => {
    try {
      const response = await ConfigurationAxios(GET_COMPARE_TYPE_ENUM, "get");
      setCompareTypeEnum(response.data);
    } catch (error) {
      Toast("", COMPARE_TYPE_FETCH_FAILED, "error");
      console.error(error);
    }
  }, []);

  const fetchFileCompData = async () => {
    setLoader(true);
    try {
      let compareType;
      Object.keys(compareTypeEnum).forEach((k) => {
        if (compareTypeEnum[k] === compareWith) {
          compareType = k;
        }
      });

      const data = {
        file1: {
          id: selectedFileName1.id,
        },
        file2:
          compareWith === "ConfigFile"
            ? { id: selectedFileName2.id }
            : undefined,
        compareType,
        resourceInfo: {
          resourceId:
            compareWith !== "ConfigFile"
              ? selectedDevice.resourceId
              : undefined,
        },
        siteId: selectedSiteId ?? undefined,
      };
      const response = isCnms
        ? await ConfigurationAxios(COMPARE_BACKUP_DATA_AT_CNMS, "post", data)
        : await ConfigurationAxios(COMAPARE_BACKUP_DATA, "post", data);
      if (response?.data?.data) {
        setCompData(response.data);
        setOpenPreviewDialog(true);
        setLoader(false);
      } else {
        setLoader(false);
        setOpenPreviewDialog(false);
        Toast("", COMPARE_DATA_FETCH_FAILED, "error");
      }
    } catch (error) {
      setLoader(false);
      Toast("", COMPARE_DATA_FETCH_FAILED, "error");
      console.error(error);
    }
  };

  useEffect(() => {
    ConfigurationAxios(GET_BACKUP_MODE_ENUM, "get")
      .then(({ data }) => {
        setBackupModeEnum(data);
      })
      .catch((err) => {
        Toast("", "Failed to fetch Backup Enums.", "error");
      });
  }, []);

  useEffect(() => {
    findAllDeviceNames();
    if (selectedDeviceType === "Select One") {
      fetchCompareTypeEnum();
    }
  }, [selectedDeviceType]);

  const handleChange = (event) => {
    setCompareWith(event.target.value);
  };

  const renderConfigTwo = () => {
    if (compareWith === "ConfigFile") {
      return (
        <Box sx={{ display: "flex", flex: 1 }}>
          <MSelect
            label={"Config File 2*"}
            value={selectedFileName2}
            getOptionLabel={(option) => option?.fileName}
            getOptionValue={(option) => option?.id}
            onChange={(option) => {
              setSelectedFileName2(option);
            }}
            options={filesNames
              .filter((el) => el.id !== selectedFileName1.id)
              .map((file) => ({
                ...file, // spread existing file properties
              }))}
          />
        </Box>
      );
    } else {
      return null;
    }
  };

  useEffect(() => {
    if (isCnms) {
      (async () => {
        try {
          // setLoader(true);
          const res = await InventoryAxios(
            FETCH_ALL_REMOTE_TERMINAL_TYPE_DETAILS_AT_CNMS,
            "get"
          );
          if (res?.data) {
            const options = res?.data?.map((item) => ({
              ...item,
              label: item?.terminalTypeName,
              value: item.id,
            }));
            setAllTerminalTypes(options);
          } else {
            setAllTerminalTypes([]);
          }
          setLoader(false);
        } catch (error) {
          console.error(error);

          setLoader(false);
        }
      })();
    }
  }, []);

  const findAllDeviceNamesAtCnms = async (siteId) => {
    try {
      const url = `${FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES_AT_CNMS}/${selectedTerminal}/${siteId}`;
      const response = await InventoryAxios(url, "get");
      if (response?.data) {
        setDevices(response?.data || []);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      {openPreviewDialog && (
        <PreviewDialog
          data={compData}
          onClose={() => setOpenPreviewDialog(false)}
          backupModeEnum={backupModeEnum}
        />
      )}

      <MForm title={"File comparison"} paddingX={1}>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <Box>
            {isCnms && (
              <Box sx={{ display: "flex", gap: 1 }}>
                <Box
                  sx={{
                    display: "flex",
                    width: "50%",
                    flexDirection: "column",
                  }}
                >
                  <MSelect
                    label={"Terminal*"}
                    value={selectedTerminal}
                    onChange={async (selectedoption) => {
                      setSelectedTerminal(selectedoption.value);
                      try {
                        const res = await InventoryAxios(
                          `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${selectedoption.value}`
                        );
                        if (res?.data) {
                          setSelectedSiteId("none");
                          const options = res?.data?.map((item) => ({
                            ...item,
                            label: item.siteId,
                            value: item.siteId,
                          }));
                          setAllSites(options);
                        } else {
                          setAllSites([]);
                        }
                      } catch (err) {
                        console.error(err);
                        setAllSites([]);
                      }
                    }}
                    options={allTerminalTypes}
                  />
                </Box>

                <Box
                  sx={{
                    display: "flex",
                    width: "50%",
                    flexDirection: "column",
                  }}
                >
                  <MSelect
                    label={"Site ID*"}
                    value={selectedSiteId}
                    onChange={(selectedoption) => {
                      setSelectedSiteId(selectedoption.value);
                      findAllDeviceNamesAtCnms(selectedoption.value);
                    }}
                    options={allSites}
                  />
                </Box>
              </Box>
            )}
          </Box>
        </Box>

        <Box sx={{ display: "flex", gap: 1, mt: 2 }}>
          <Box sx={{ display: "flex", width: "50%", flexDirection: "column" }}>
            {loadingDevices ? (
              <Typography align="center">
                <CircularProgress size="24px" />
              </Typography>
            ) : (
              <MSelect
                label={"Device Name*"}
                value={selectedDevice}
                // renderValue={() => selectedDevice.resourceName || "Select One"}
                getOptionLabel={(option) => option?.resourceName}
                getOptionValue={(option) => option?.resourceId}
                onChange={(option) => {
                  setSelectedDevice(option);
                  setSelectedFileName1("Select One");
                  setSelectedFileName2("Select One");
                  if (isCnms) {
                    let resourceId = option.resourceId;
                    fetchAllFileNamesAtCnms(resourceId, selectedSiteId);
                  } else {
                    fetchAllFileNames(option.resourceId);
                  }
                }}
                options={devices}
              />
            )}
          </Box>
          <Box sx={{ display: "flex", width: "50%", flexDirection: "column" }}>
            {loadingConfigFiles ? (
              <Typography align="center">
                <CircularProgress size="24px" />
              </Typography>
            ) : (
              <MSelect
                label={"Config File 1*"}
                placeholder={"Select One"}
                value={selectedFileName1}
                getOptionLabel={(option) => option?.fileName}
                getOptionValue={(option) => option?.id}
                onChange={(option) => {
                  setSelectedFileName1(option);
                }}
                options={filesNames
                  .filter((el) => el.id !== selectedFileName2.id)
                  .map((file) => ({
                    ...file, // spread existing file properties
                  }))}
              />
            )}
          </Box>
        </Box>

        <Box sx={{ display: "flex", mt: 2 }}>
          <Box
            sx={{ display: "flex", width: "50%", alignItems: "center", gap: 1 }}
          >
            <Box>Compare With*</Box>
            <Box>
              <RadioGroup
                aria-label="compareWith"
                name="compareWith"
                value={compareWith}
                onChange={handleChange}
              >
                <FormControlLabel
                  value={compareTypeEnum ? compareTypeEnum["1"] : null}
                  control={<Radio />}
                  label={compareTypeEnum ? compareTypeEnum["1"] : null}
                />
                <FormControlLabel
                  value={compareTypeEnum ? compareTypeEnum["2"] : null}
                  control={<Radio />}
                  label={compareTypeEnum ? compareTypeEnum["2"] : null}
                />
              </RadioGroup>
            </Box>
          </Box>
          <Box sx={{ display: "flex", width: "50%" }}>{renderConfigTwo()}</Box>
        </Box>

        <Box
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "20px",
          }}
        >
          <MButtonPrimary
            onClick={() => fetchFileCompData()}
            color="primary"
            disabled={!validate() || loader}
            variant="contained"
            startIcon={
              loader ? (
                <CircularProgress size="24px" color="inherit" />
              ) : (
                <Visibility />
              )
            }
          >
            Preview
          </MButtonPrimary>
        </Box>
      </MForm>
    </div>
  );
}
