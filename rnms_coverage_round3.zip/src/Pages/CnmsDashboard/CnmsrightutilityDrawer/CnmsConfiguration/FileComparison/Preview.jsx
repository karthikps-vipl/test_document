import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { Box, Grid, Tooltip, Typography } from "@mui/material";
import { formatDateTime } from "@/lib/utils";
import { ArrowDownward, ArrowUpward } from "@mui/icons-material";
import MInput from "@/components/Reusable/Input/MInput";
import MForm from "@/components/Reusable/Form/MForm";
import MModal from "@/components/Reusable/Modal/MModal";
import { diffLines } from "diff";

const styles = {
  rightAlign: {
    textAlign: "right",
  },
  centerAlign: {
    textAlign: "center",
  },
  selectField: {
    height: "40px",
    width: "120px",
  },
  divider: {
    marginBottom: "20px",
  },
  MODIFIED: {
    background: "#f4dada",
    height: "30.8px",
  },
  NEW: {
    background: "#deecbe",
    height: "30.8px",
  },
  DELETED: {
    background: "#f4dada",
    height: "30.8px",
  },
  UNKNOWN_STATE: {
    backgroundImage:
      "linear-gradient(315deg, #fff 25%, #e0e0e0 25%, #e0e0e0 50%, #fff 50%, #fff 75%, #e0e0e0 75%, #e0e0e0 100%)",
    backgroundSize: "7.7px 7.7px",
    height: "30.8px",
  },
  NOT_MODIFIED: {},
  modifiedText: {
    backgroundColor: "#ffc1c1",
  },
};

var target = null;
export default function PreviewDialog(props) {
  const { onClose, data, backupModeEnum } = props;

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const presentArr = useRef([]);

  const file1ScrollRef = useRef(null);
  const file2ScrollRef = useRef(null);
  const isSyncingScroll = useRef(false);

  const syncScroll = (source, target) => {
    if (isSyncingScroll.current) return;

    isSyncingScroll.current = true;
    target.scrollTop = source.scrollTop;

    requestAnimationFrame(() => {
      isSyncingScroll.current = false;
    });
  };

  const [diff, setDiff] = useState([]);
  const [count, setCount] = useState(0);
  const [currentTarget, setCurrentTarget] = useState(null);
  const [fullScreen] = useState(false);

  const buildDiff = (file1 = "", file2 = "") => {
    const changes = diffLines(file1, file2);
    const rows = [];

    const getLines = (value) => {
      const lines = value.split("\n");

      // Remove the extra empty element from a trailing newline.
      if (lines[lines.length - 1] === "") {
        lines.pop();
      }

      return lines;
    };

    const appendPairedChanges = (deleted, added) => {
      const maxLength = Math.max(deleted.length, added.length);

      for (let i = 0; i < maxLength; i++) {
        const hasOldLine = i < deleted.length;
        const hasNewLine = i < added.length;

        if (hasOldLine && hasNewLine) {
          rows.push({
            v1Status: "MODIFIED",
            v2Status: "MODIFIED",
            value1: deleted[i],
            value2: added[i],
          });
        } else if (hasOldLine) {
          rows.push({
            v1Status: "DELETED",
            v2Status: "UNKNOWN_STATE",
            value1: deleted[i],
            value2: "",
          });
        } else {
          rows.push({
            v1Status: "UNKNOWN_STATE",
            v2Status: "NEW",
            value1: "",
            value2: added[i],
          });
        }
      }
    };

    for (let i = 0; i < changes.length; i++) {
      const part = changes[i];

      if (part.removed) {
        // Collect consecutive removed and added blocks.
        const deleted = [];
        const added = [];

        while (i < changes.length) {
          const current = changes[i];

          if (current.removed) {
            deleted.push(...getLines(current.value));
            i++;
          } else if (current.added) {
            added.push(...getLines(current.value));
            i++;
          } else {
            break;
          }
        }

        // Pair corresponding lines as modifications.
        appendPairedChanges(deleted, added);

        // The loop above may have reached an unchanged block.
        i--;

        continue;
      }

      if (part.added) {
        // Added block without a preceding deletion.
        getLines(part.value).forEach((line) => {
          rows.push({
            v1Status: "UNKNOWN_STATE",
            v2Status: "NEW",
            value1: "",
            value2: line,
          });
        });

        continue;
      }

      // Unchanged lines.
      getLines(part.value).forEach((line) => {
        rows.push({
          v1Status: "NOT_MODIFIED",
          v2Status: "NOT_MODIFIED",
          value1: line,
          value2: line,
        });
      });
    }

    return rows;
  };

  const handleNav = (key) => {
    if (currentTarget === null) {
      setCurrentTarget(target);
    } else {
      if (key === "P") {
        if (count === 0) {
          setCount(presentArr.current.length - 1);
          setCurrentTarget(presentArr.current[presentArr.current.length - 1]);
          document
            .getElementById(
              `file${presentArr.current[presentArr.current.length - 1]}`
            )
            .scrollIntoView();
        } else {
          setCurrentTarget(presentArr.current[count - 1]);
          document
            .getElementById(`file${presentArr.current[count - 1]}`)
            .scrollIntoView();

          setCount(count - 1);
        }
      } else {
        if (count === presentArr.current.length - 1) {
          setCount(0);
          document
            .getElementById(`file${presentArr.current[0]}`)
            .scrollIntoView();

          setCurrentTarget(presentArr.current[0]);
        } else {
          setCount(count + 1);
          document
            .getElementById(`file${presentArr.current[count + 1]}`)
            .scrollIntoView();
          setCurrentTarget(presentArr.current[count + 1]);
        }
      }
    }
  };

  useEffect(() => {
    const file1 = data?.data?.file1?.configData ?? "";
    const file2 = data?.data?.file2?.configData ?? "";

    const rows = buildDiff(file1, file2);

    // Reset navigation when a new comparison is loaded.
    target = null;
    presentArr.current = [];

    rows.forEach((row, index) => {
      if (row.v1Status !== "NOT_MODIFIED" || row.v2Status !== "NOT_MODIFIED") {
        if (target === null) {
          target = index;
        }

        presentArr.current.push(index);
      }
    });

    setDiff(rows);
    setCount(0);
    setCurrentTarget(null);
  }, [data?.data?.file1?.configData, data?.data?.file2?.configData]);

  const renderDiff2 = (status) => {
    let template = <></>;
    if (status.v2Status !== "UNKNOWN_STATE") {
      if (status.v2Status === "MODIFIED") {
        template = (
          <span>
            {/* {status.key && status.key + ":"} */}
            <span style={{ ...(styles.modifiedText || {}) }}>
              {status.value2}
            </span>
          </span>
        );
      } else {
        template = (
          <span>
            {/* {status.v2Status === "DELETED" && (
              <span style={{ fontWeight: "bold" }}>--</span>
            )}
            {status.v2Status === "NEW" && (
              <span style={{ fontWeight: "bold" }}>++</span>
            )} */}
            {/* {status.key ? `${status.key}:${status.value2}` : `${status.value2}`} */}
            {status.value2}
          </span>
        );
      }
    } else {
      template = <span></span>;
    }
    return template;
  };

  const renderDiff1 = (status) => {
    let template = <></>;
    if (status.v1Status !== "UNKNOWN_STATE") {
      if (status.v1Status === "MODIFIED") {
        template = (
          <span>
            {/* {status.key && status.key + ":"} */}
            <span style={{ ...(styles.modifiedText || {}) }}>
              {status.value1}
            </span>
          </span>
        );
      } else {
        template = (
          <span>
            {/* {status.v1Status === "DELETED" && (
              <span style={{ fontWeight: "bold" }}>--</span>
            )}
            {status.v1Status === "NEW" && (
              <span style={{ fontWeight: "bold" }}>++</span>
            )} */}
            {/* {status.key ? `${status.key}:${status.value1}` : `${status.value1}`} */}
            {status.value1}
          </span>
        );
      }
    } else {
      template = <span></span>;
    }
    return template;
  };

  const getLineHeight = (value, charsPerLine = 45) => {
    const text = value ?? "";

    const visualLines = text.split("\n").reduce((total, line) => {
      return total + Math.max(1, Math.ceil(line.length / charsPerLine));
    }, 0);

    return Math.max(30.8, visualLines * 18.8 + 12);
  };

  return (
    <div>
      <MModal
        open={true}
        maxWidth="md"
        fullWidth
        fullScreen={fullScreen}
        // title="Comparison Result"
        handleClose={onClose}
      >
        <Box>
          <MForm title={"Comparison Result"} paddingX={1}>
            <Box
              sx={{
                display: "flex",
                flex: 1,
                gap: 1,
                justifyContent: "space-between",
              }}
            >
              <Box
                sx={{ display: "flex", width: "50%", flexDirection: "column" }}
              >
                <Typography>Device Type</Typography>
                <MInput
                  label=" Device Type"
                  size="small"
                  variant="outlined"
                  InputProps={{ readOnly: true }}
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={
                    !isCnms
                      ? data?.data?.file1?.resourceInfo?.imResourceType
                          ?.resourceTypeName
                      : data?.data?.file1?.imSiteResourceInfo?.imResourceType
                          ?.resourceTypeName
                  }
                />
              </Box>

              <Box
                sx={{ display: "flex", width: "50%", flexDirection: "column" }}
              >
                <Typography>Device Name</Typography>
                <MInput
                  label="Device Name"
                  size="small"
                  variant="outlined"
                  InputProps={{ readOnly: true }}
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={
                    !isCnms
                      ? data?.data?.file1?.resourceInfo?.resourceName
                      : data?.data?.file1?.imSiteResourceInfo?.resourceName
                  }
                />
              </Box>
            </Box>
          </MForm>
          <Box sx={{ display: "flex", gap: 1, mt: 1 }}>
            <Box sx={{ width: "50%" }}>
              <MForm
                title={`File Name: ${data?.data?.file1?.fileName}`}
                paddingX={1}
              >
                <Box sx={{ gap: 2, display: "flex", flexDirection: "column" }}>
                  <Box className="fullwidth-minpu-cont">
                    <Typography>Backup Mode</Typography>
                    <MInput
                      label="Backup Mode"
                      size="small"
                      variant="outlined"
                      fullWidth
                      InputProps={{ readOnly: true }}
                      InputLabelProps={{ shrink: true }}
                      value={backupModeEnum[data?.data?.file1?.backupMode]}
                    />
                  </Box>
                  <Box className="fullwidth-minpu-cont">
                    <Typography>File Description</Typography>
                    <MInput
                      size="small"
                      fullWidth
                      variant="outlined"
                      InputProps={{ readOnly: true }}
                      InputLabelProps={{ shrink: true }}
                      value={data?.data?.file1?.description}
                    />
                  </Box>
                  <Box className="fullwidth-minpu-cont">
                    <Typography>Date/Time</Typography>
                    <MInput
                      size="small"
                      fullWidth
                      InputProps={{ readOnly: true }}
                      InputLabelProps={{ shrink: true }}
                      variant="outlined"
                      value={formatDateTime(data?.data?.file1?.dateTime)}
                    />
                  </Box>
                </Box>
              </MForm>
            </Box>
            <Box sx={{ width: "50%" }}>
              <MForm
                title={`File Name: ${data?.data?.file2?.fileName}`}
                paddingX={1}
              >
                <Box sx={{ gap: 2, display: "flex", flexDirection: "column" }}>
                  <Box className="fullwidth-minpu-cont">
                    <Typography>Backup Mode</Typography>
                    <MInput
                      size="small"
                      variant="outlined"
                      InputProps={{ readOnly: true }}
                      InputLabelProps={{ shrink: true }}
                      fullWidth
                      value={backupModeEnum[data?.data?.file2?.backupMode]}
                    />
                  </Box>
                  <Box className="fullwidth-minpu-cont">
                    <Typography>File Description</Typography>
                    <MInput
                      size="small"
                      variant="outlined"
                      InputProps={{ readOnly: true }}
                      InputLabelProps={{ shrink: true }}
                      fullWidth
                      value={data?.data?.file2?.description}
                    />
                  </Box>
                  <Box className="fullwidth-minpu-cont">
                    <Typography>Date/Time</Typography>
                    <MInput
                      label="Date/Time"
                      size="small"
                      variant="outlined"
                      InputProps={{ readOnly: true }}
                      InputLabelProps={{ shrink: true }}
                      fullWidth
                      value={formatDateTime(data?.data?.file2?.dateTime)}
                    />
                  </Box>
                </Box>
              </MForm>
            </Box>
          </Box>

          <Grid>
            <MForm title="Config Data Comparison" paddingX={1}>
              <Box
                sx={{
                  display: "flex",
                  width: "100%",
                  minWidth: 0,
                  border: "1px solid #d0d0d0",
                  borderRadius: 1,
                  overflow: "hidden",
                }}
              >
                {/* File 1: 50% width */}
                <Box
                  ref={file1ScrollRef}
                  onScroll={() =>
                    syncScroll(file1ScrollRef.current, file2ScrollRef.current)
                  }
                  sx={{
                    width: "50%",
                    minWidth: 0,
                    height: fullScreen ? "60vh" : "25vh",
                    overflow: "auto",
                    borderRight: "2px solid #808080",
                    boxSizing: "border-box",
                  }}
                >
                  {/* <Box
                    sx={{
                      position: "sticky",
                      top: 0,
                      zIndex: 1,
                      backgroundColor: "#eeeeee",
                      color: "#222222",
                      borderBottom: "1px solid #bdbdbd",
                      padding: 1,
                      fontWeight: 600,
                    }}
                  >
                    File 1: {data?.data?.file1?.fileName}
                  </Box> */}

                  {diff.map((status, i) => {
                    const rowHeight = Math.max(
                      getLineHeight(status.value1),
                      getLineHeight(status.value2)
                    );

                    return (
                      <Box
                        key={`file1-${i}`}
                        id={`file${i}`}
                        sx={{
                          display: "flex",
                          alignItems: "stretch",
                          height: rowHeight,
                          minHeight: rowHeight,
                          boxSizing: "border-box",
                          ...styles[status.v1Status],
                          ...(currentTarget === i
                            ? { background: "#8bce90" }
                            : {}),
                        }}
                      >
                        {/* Keep line numbers */}
                        <Box
                          sx={{
                            flex: "0 0 48px",
                            textAlign: "right",
                            paddingRight: 1,
                            paddingTop: "6px",
                            color: "#666666",
                            borderRight: "1px solid #dddddd",
                            boxSizing: "border-box",
                            userSelect: "none",
                          }}
                        >
                          {i + 1}
                        </Box>

                        <Box
                          component="p"
                          sx={{
                            flex: 1,
                            minWidth: 0,
                            m: 0,
                            padding: "6px 8px",
                            color: "#222222",
                            fontFamily: "monospace",
                            fontSize: "13px",
                            lineHeight: "18.8px",
                            whiteSpace: "pre-wrap",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {renderDiff1(status)}
                        </Box>
                      </Box>
                    );
                  })}
                </Box>

                {/* File 2: 50% width */}
                <Box
                  ref={file2ScrollRef}
                  onScroll={() =>
                    syncScroll(file2ScrollRef.current, file1ScrollRef.current)
                  }
                  sx={{
                    width: "50%",
                    minWidth: 0,
                    height: fullScreen ? "60vh" : "25vh",
                    overflow: "auto",
                    boxSizing: "border-box",
                  }}
                >
                  {/* <Box
                    sx={{
                      position: "sticky",
                      top: 0,
                      zIndex: 1,
                      backgroundColor: "#eeeeee",
                      color: "#222222",
                      borderBottom: "1px solid #bdbdbd",
                      padding: 1,
                      fontWeight: 600,
                    }}
                  >
                    File 2: {data?.data?.file2?.fileName}
                  </Box> */}

                  {diff.map((status, i) => {
                    const rowHeight = Math.max(
                      getLineHeight(status.value1),
                      getLineHeight(status.value2)
                    );
                    return (
                      <Box
                        key={`file2-${i}`}
                        sx={{
                          display: "flex",
                          alignItems: "stretch",
                          height: rowHeight,
                          minHeight: rowHeight,
                          boxSizing: "border-box",
                          ...styles[status.v2Status],
                          ...(currentTarget === i
                            ? { background: "#8bce90" }
                            : {}),
                        }}
                      >
                        {/* Keep line numbers */}
                        <Box
                          sx={{
                            flex: "0 0 48px",
                            textAlign: "right",
                            paddingRight: 1,
                            paddingTop: "6px",
                            color: "#666666",
                            borderRight: "1px solid #dddddd",
                            boxSizing: "border-box",
                            userSelect: "none",
                          }}
                        >
                          {i + 1}
                        </Box>

                        <Box
                          component="p"
                          sx={{
                            flex: 1,
                            minWidth: 0,
                            margin: 0,
                            padding: "6px 8px",
                            color: "#222222",
                            fontFamily: "monospace",
                            fontSize: "13px",
                            lineHeight: "18.8px",
                            whiteSpace: "pre-wrap",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {renderDiff2(status)}
                        </Box>
                      </Box>
                    );
                  })}
                </Box>
              </Box>
            </MForm>

            <Box>
              {presentArr.current.length ? (
                <Box
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 1,
                  }}
                >
                  <Box sx={{ display: "flex", gap: 1 }}>
                    <Box
                      style={{
                        padding: "5px 10px",
                        borderRadius: "10px",
                        backgroundColor: "#8bce90",
                      }}
                    >
                      Current Selection
                    </Box>
                    <Box
                      style={{
                        padding: "5px 10px",
                        borderRadius: "10px",
                        backgroundColor: "#f4dada",
                      }}
                    >
                      Modified Line
                    </Box>
                    <Box
                      style={{
                        padding: "5px 10px",
                        borderRadius: "10px",
                        backgroundColor: "#ffc1c1",
                      }}
                    >
                      Modified Content
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", gap: 1 }}>
                    <Tooltip title="Prev. Change">
                      <Box
                        onClick={() => {
                          handleNav("P");
                        }}
                        sx={{
                          backgroundColor: "#e9efff",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          borderRadius: "50%",
                          padding: "6px 6px",
                        }}
                      >
                        <ArrowUpward />
                      </Box>
                    </Tooltip>
                    <Tooltip title="Next Change">
                      <Box
                        onClick={() => {
                          handleNav("N");
                        }}
                        sx={{
                          backgroundColor: "#e9efff",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          borderRadius: "50%",
                          padding: "6px 6px",
                        }}
                      >
                        <ArrowDownward />
                      </Box>
                    </Tooltip>
                  </Box>
                </Box>
              ) : null}
            </Box>
          </Grid>
        </Box>
      </MModal>
    </div>
  );
}
