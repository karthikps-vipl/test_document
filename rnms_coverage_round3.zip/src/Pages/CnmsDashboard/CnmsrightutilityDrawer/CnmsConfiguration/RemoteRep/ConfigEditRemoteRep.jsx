 
import React, { useState } from "react";
import { Box, Select, Typography, FormControl, MenuItem } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {  EDIT_SITE_REP_DETAILS, } from "@/RestAPI/url/endpoint";
import { validateInput, personnelRegex } from "@/utility/FormValidation/Regex";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import {
    personnelNameValidation,
    rankValidation,
    unitValidation,
    primaryMobileValidation,
    afcelPhoneValidation,
    ipPhoneValidation,
    alternateMobileValidation,
    emailValidation,
   
} from "@/utility/FormValidation/YupSchema";
 import MDialog from "@/components/Reusable/Dialog/MDialog";
 
 const ConfigEditRemoteRep = ({ data, onClose, onSuccess,isGrandchildFullScreen }) => {
    const [showConfirm, setShowConfirm] = useState(false);
    const [loading, setLoading] = useState(false);
    
    // Ensure we have a reference to the terminal type
    const selectedTerminal = data?.siteDetails?.imTerminalType?.terminalTypeName || "";

    // CRITICAL FIX: Handle initialization based on whether this is an Edit or Add
    const isEditMode = !!data?.repId;

    const formik = useFormik({
        initialValues: {
            repId: isEditMode ? data.repId : null, // Add repId to form state
            siteId: data?.siteId || "",
            personalName: data?.personnelName || "",
            rank: data?.personnel || "",
            unit: data?.unit || "",
            primaryCivilMobile: data?.primaryCivilMobile || "",
            afcelPhone: data?.afcel || "",
            ipPhone: data?.ipPhone || "",
            alternateCivilMobile: data?.alternateCivilMobile || "",
            email: data?.email || "",
        },
        validationSchema: Yup.object({
            siteId: Yup.string().required("Site ID is required"),
            personalName: personnelNameValidation,
            rank: rankValidation,
            unit: unitValidation,
            primaryCivilMobile: primaryMobileValidation,
            afcelPhone: afcelPhoneValidation,
            ipPhone: ipPhoneValidation,
            alternateCivilMobile: alternateMobileValidation,
            email: emailValidation,
        }),
        enableReinitialize: true,
        validateOnMount: isEditMode, // Only validate on mount if editing
        onSubmit: async (values) => {
            setLoading(true);
            try {
                // Ensure we use the trimmed/normalized value for the API
                const payload = {
                    repId: values.repId, // Pass repId to API
                    siteId: values.siteId.trim(),
                    personnelName: values.personalName.trim(),
                    personnel: values.rank,
                    unit: values.unit.trim(),
                    primaryCivilMobile: values.primaryCivilMobile || null,
                    afcel: values.afcelPhone || null,
                    ipPhone: values.ipPhone || null,
                    alternateCivilMobile: values.altCivilMobile || null,
                    email: values.email || "",
                };
                
                console.log("payload", payload);

                // Determine API endpoint based on mode
                // If repId exists, use EDIT endpoint, otherwise CREATE (if your logic requires it)
                const endpoint = values.repId ? EDIT_SITE_REP_DETAILS : CREATE_SITE_REP_DETAILS;

                const response = await InventoryAxios(endpoint, "post", payload);

                if (response.status === 200) {
                    Toast("Success!", "Representative details updated", "success");
                    onSuccess();
                    onClose();
                } else {
                    Toast("Error!", "Failed to update representative details.", "error");
                }
            } catch (error) {
                console.error("Error updating Rep Details:", error);
                Toast("Error!", "Failed to update representative details.", "error");
            } finally {
                setLoading(false);
            }
        },
    });

    const handleInputChange = (fieldName, value) => {
        formik.setFieldValue(fieldName, value);
        formik.setFieldTouched(fieldName, true, false);
    };

    const handleConfirmSubmit = () => {
        setShowConfirm(false);
        formik.handleSubmit();
    };

    // Validation Status Logic
    const isMandatoryValid =
        formik.values.siteId &&
        formik.values.personalName &&
        formik.values.rank &&
        formik.values.unit &&
        formik.values.primaryCivilMobile &&
        !formik.errors.siteId &&
        !formik.errors.personalName &&
        !formik.errors.rank &&
        !formik.errors.unit &&
        !formik.errors.primaryCivilMobile;

    const hasNonMandatoryErrors =
        !!formik.errors.afcelPhone ||
        !!formik.errors.ipPhone ||
        !!formik.errors.altCivilMobile ||
        !!formik.errors.email;

    const isAddDisabled = !isMandatoryValid || hasNonMandatoryErrors;

    return (
        <Box
            component="form"
            onSubmit={formik.handleSubmit}
            className="flex flex-col gap-5"
        >
            <Box sx={{ display: "flex", flexDirection: "column", ml: 3, mr: 5 }}>

                {/* Terminal Type Selector */}
                <Box sx={{ display: "flex", flexDirection: "column" }}>
                    <Typography sx={{ mb: 0.5 }}>Terminal Type *</Typography>
                    <FormControl fullWidth>
                        <MInput
                            value={selectedTerminal}
                            disabled={true}
                        />
                    </FormControl>
                </Box>

                {/* Site ID Selector (Dynamic) */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ mb: 0.5 }}>Site ID *</Typography>
                    <MInput
                        value={formik.values.siteId}
                        disabled={true}
                    />
                    {formik.touched.siteId && formik.errors.siteId && (
                        <Typography sx={{ color: "#d32f2f", fontSize: "12px", mt: 0.5 }}>
                            {formik.errors.siteId}
                        </Typography>
                    )}
                </Box>

                {/* Personal Name */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        Personnel Name *
                    </Typography>
                    <MInput
                        label="Personnel Name"
                        value={formik.values.personalName}
                        placeholder="Enter personnel name"
                        onChange={(e) => {
                            if (validateInput(e.target.value, personnelRegex.name) !== undefined) {
                                handleInputChange("personalName", e.target.value);
                            }
                        }}
                        errorMessage={formik.touched.personalName && formik.errors.personalName}
                    />
                </Box>

                {/* Rank */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ mb: 0.5 }}>Rank *</Typography>
                    <FormControl fullWidth>
                        <Select
                            id="rank-select"
                            size="small"
                            value={formik.values.rank}
                            onChange={(e) => handleInputChange("rank", e.target.value)}
                            sx={{ borderRadius: "10px" }}
                        >
                            <MenuItem value="AIR CMDE">AIR CMDE</MenuItem>
                            <MenuItem value="GP CAPT">GP CAPT</MenuItem>
                            <MenuItem value="WG CDR">WG CDR</MenuItem>
                            <MenuItem value="SQN LDR">SQN LDR</MenuItem>
                            <MenuItem value="FLT LT">FLT LT</MenuItem>
                            <MenuItem value="FG OFFR">FG OFFR</MenuItem>
                            <MenuItem value="MWO">MWO</MenuItem>
                            <MenuItem value="WO">WO</MenuItem>
                            <MenuItem value="JWO">JWO</MenuItem>
                            <MenuItem value="SGT">SGT</MenuItem>
                            <MenuItem value="CPL">CPL</MenuItem>
                            <MenuItem value="LAC">LAC</MenuItem>
                            <MenuItem value="AC">AC</MenuItem>
                            <MenuItem value="AGV">AGV</MenuItem>
                        </Select>
                        {formik.touched.rank && formik.errors.rank && (
                            <Typography sx={{ color: "#d32f2f", fontSize: "12px", mt: 0.5 }}>
                                {formik.errors.rank}
                            </Typography>
                        )}
                    </FormControl>
                </Box>

                {/* Unit */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        Unit *
                    </Typography>
                    <MInput
                        label="Unit"
                        value={formik.values.unit}
                        placeholder="Enter unit"
                        onChange={(e) => handleInputChange("unit", e.target.value)}
                        errorMessage={formik.touched.unit && formik.errors.unit}
                    />
                </Box>

                {/* Primary Civil Mobile */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        Primary Civil Mobile *
                    </Typography>
                    <MInput
                        label="Primary Civil Mobile"
                        value={formik.values.primaryCivilMobile}
                        placeholder="6-9xxxxxxxxx"
                        onChange={(e) => {
                            if (validateInput(e.target.value, personnelRegex.primaryMobile) !== undefined) {
                                handleInputChange("primaryCivilMobile", e.target.value);
                            }
                        }}
                        errorMessage={formik.touched.primaryCivilMobile && formik.errors.primaryCivilMobile}
                    />
                </Box>

                {/* AFCEL Phone */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        AFCEL Phone
                    </Typography>
                    <MInput
                        label="AFCEL Phone"
                        value={formik.values.afcelPhone}
                        placeholder="1-9xxxxxxx"
                        onChange={(e) => {
                            if (validateInput(e.target.value, personnelRegex.landline) !== undefined) {
                                handleInputChange("afcelPhone", e.target.value);
                            }
                        }}
                        errorMessage={formik.touched.afcelPhone && formik.errors.afcelPhone}
                    />
                </Box>

                {/* IP Phone */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        IP Phone
                    </Typography>
                    <MInput
                        label="IP Phone"
                        value={formik.values.ipPhone}
                        placeholder="1-9xxxxxxx"
                        onChange={(e) => {
                            if (validateInput(e.target.value, personnelRegex.landline) !== undefined) {
                                handleInputChange("ipPhone", e.target.value);
                            }
                        }}
                        errorMessage={formik.touched.ipPhone && formik.errors.ipPhone}
                    />
                </Box>

                {/* Alternate Civil Mobile */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        Alternative Civil Mobile No.
                    </Typography>
                    <MInput
                        label="Alternate Civil Mobile No."
                        value={formik.values.alternateCivilMobile}
                        placeholder="5-9xxxxxxxxx"
                        onChange={(e) => {
                            if (validateInput(e.target.value, personnelRegex.altMobile) !== undefined) {
                                handleInputChange("altCivilMobile", e.target.value);
                            }
                        }}
                        errorMessage={formik.touched.altCivilMobile && formik.errors.altCivilMobile}
                    />
                </Box>

                {/* Email */}
                <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                    <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                        Email
                    </Typography>
                    <MInput
                        label="Email"
                        value={formik.values.email}
                        placeholder="example@domain.com"
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        errorMessage={formik.touched.email && formik.errors.email}
                    />
                </Box>

                {/* Action Button */}
                <Box
                    sx={{
                        float: "right",
                        display: "flex",
                        mt: 3,
                        justifyContent: "flex-end",
                    }}
                >
                    <MButtonPrimary
                        type="button"
                        onClick={() => setShowConfirm(true)}
                        disabled={isAddDisabled || loading}
                    >
                        {loading ? "Updating..." : "Update"}
                    </MButtonPrimary>
                </Box>
            </Box>

            {/* Confirmation Dialog */}
            <MDialog
                open={showConfirm}
                variant="warning"
                title="Confirm Action"
                icon={question_mark}
                message="Are you sure you want to update this representative?"
                onConfirm={handleConfirmSubmit}
                onClose={() => setShowConfirm(false)}
                mode="grandchild"
                isGrandchildFullScreen={isGrandchildFullScreen}
            />
        </Box>
    );
};

export default ConfigEditRemoteRep;
