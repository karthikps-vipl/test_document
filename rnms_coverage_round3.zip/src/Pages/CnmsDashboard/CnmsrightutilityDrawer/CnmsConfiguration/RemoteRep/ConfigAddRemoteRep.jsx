import React, { useEffect, useMemo, useState } from "react";
import { Box, Select, Typography, FormControl, MenuItem } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { ADD_SITE_REP_DETAILS, FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,} from "@/RestAPI/url/endpoint";
import { validateInput, personnelRegex } from "@/utility/FormValidation/Regex";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg"
import {

    personnelNameValidation,
    rankValidation,
    primaryMobileValidation,
    afcelPhoneValidation,
    ipPhoneValidation,
    alternateMobileValidation,
    emailValidation,
    UnitNameValidator,
} from "@/utility/FormValidation/YupSchema";
import { useDispatch, useSelector } from "react-redux";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MSelect from "@/components/Reusable/Select/MSelect";
import { setRnmsterminaltypesData } from "@/store/features/Cnms/remoteRepDetails/rnmsTerminalTypes";

const ConfigAddRemoteRep = ({
    row,
    data,
    mode,
    onClose,
    onSuccess,
    siteId,isGrandchildFullScreen
}) => {
    const dispatch = useDispatch();

    // const { repDetails, isCnms } = useSelector(
    //     (state) => state.nodeDetails
    // );

    const { remoteRepDetails } = useSelector(
        (state) => state.remoteRepDetails
    );

    const [terminalTypes, setTerminalTypes] = useState([]);
    const [selectedTerminalId, setSelectedTerminalId] =
        useState("");
    const [selectedTerminalObj, setSelectedTerminalObj] =
        useState(null);
    const [showConfirm, setShowConfirm] = useState(false);

    const InitialData = {
        siteId: "",
        personalName: "",
        rank: "",
        unit: "",
        primaryCivilMobile: "",
        afcelPhone: "",
        ipPhone: "",
        altCivilMobile: "",
        email: "",
    };

   

    const schema = Yup.object({
        siteId: Yup.string(),
        personalName: personnelNameValidation,
        rank: rankValidation,
        unit: UnitNameValidator,
        primaryCivilMobile: primaryMobileValidation,
        afcelPhone: afcelPhoneValidation,
        ipPhone: ipPhoneValidation,
        altCivilMobile: alternateMobileValidation,
        email: emailValidation,
    });

    const formik = useFormik({
        initialValues: InitialData,
        validationSchema: schema,
        onSubmit: async (values) => {
            await handleSucess(values);
        },
    });

    useEffect(() => {
        const load = async () => {
            try {
                const res = await InventoryAxios(
                    FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
                    "get"
                );

                dispatch(
                    setRnmsterminaltypesData(res.data)
                );

                setTerminalTypes(
                    (res?.data || []).map((t) => ({
                        label: t.terminalTypeName,
                        value: t.id,
                        raw: t,
                    }))
                );
            } catch (err) {
                console.error(
                    "Terminal type API error:",
                    err
                );

                Toast(
                    "Error!",
                    "Error loading terminals",
                    "error"
                );
            }
        };

        load();
    }, [dispatch]);

    const handleTerminalChange = (newValue) => {
        const idToSelect =
            typeof newValue === "object"
                ? newValue?.value
                : newValue;

        setSelectedTerminalId(idToSelect || "");

        const found = terminalTypes.find(
            (t) =>
                String(t.value) ===
                String(idToSelect)
        );

        setSelectedTerminalObj(found?.raw || null);

        formik.setFieldValue("siteId", "");
        formik.setFieldTouched("siteId", false);
    };

    const options = useMemo(() => {
        if (
            !selectedTerminalObj ||
            !remoteRepDetails?.length
        ) {
            return [];
        }

        const targetSubTypeId =
            selectedTerminalObj.subTypeId;

        const targetTypeName =
            selectedTerminalObj.terminalTypeName;

        const matchingSites =
            remoteRepDetails.filter((siteItem) => {
                if (!siteItem?.siteDetails) {
                    return false;
                }

                const siteSubTypeId =
                    siteItem.siteDetails
                        ?.terminalSubTypeId;

                const siteTypeName =
                    siteItem.siteDetails
                        ?.terminalTypeName;

                return (
                    siteSubTypeId ===
                        targetSubTypeId ||
                    String(siteTypeName)
                        .toLowerCase()
                        .trim() ===
                        String(targetTypeName)
                            .toLowerCase()
                            .trim()
                );
            });

        const uniqueSiteMap = new Map();

        matchingSites.forEach((item) => {
            const currentSiteId =
                item?.siteId ||
                item?.siteDetails?.siteId ||
                "";

            if (
                currentSiteId &&
                !uniqueSiteMap.has(currentSiteId)
            ) {
                uniqueSiteMap.set(
                    currentSiteId,
                    item
                );
            }
        });

        return Array.from(
            uniqueSiteMap.values()
        ).map((item) => {
            const currentSiteId =
                item?.siteId ||
                item?.siteDetails?.siteId ||
                "";

            return {
                value: currentSiteId,
                label: currentSiteId,
                raw: item,
            };
        });
    }, [
        selectedTerminalObj,
        remoteRepDetails,
    ]);

    const handleInputChange = (
        event,
        fieldName
    ) => {
        const value = event.target.value;

        formik.setFieldValue(
            fieldName,
            value
        );

        setTimeout(() => {
            formik.handleBlur({
                target: {
                    name: fieldName,
                },
            });
        }, 0);
    };

    const isMandatoryValid =
        formik.values.siteId &&
        formik.values.personalName &&
        formik.values.rank &&
        formik.values.unit &&
        formik.values.primaryCivilMobile &&
        !formik.errors.siteId &&
        !formik.errors.personalName &&
        !formik.errors.rank &&
        !formik.errors.unit &&
        !formik.errors.primaryCivilMobile;

    const hasNonMandatoryErrors =
        !!formik.errors.afcelPhone ||
        !!formik.errors.ipPhone ||
        !!formik.errors.altCivilMobile ||
        !!formik.errors.email;

    const isAddDisabled =
        !isMandatoryValid ||
        hasNonMandatoryErrors;

    const handleSucess = async (values) => {
        const payload = {
            siteId: values.siteId,
            personnelName: values.personalName,
            personnel: values.rank,
            unit: values.unit,
            primaryCivilMobile:
                values.primaryCivilMobile || null,
            afcel: values.afcelPhone || null,
            ipPhone: values.ipPhone || null,
            alternateCivilMobile:
                values.altCivilMobile || null,
            email: values.email || "",
        };

        console.log(
            "FINAL SAVE PAYLOAD:",
            payload
        );

        try {
            const resp = await InventoryAxios(
                ADD_SITE_REP_DETAILS,
                "post",
                payload
            );

            console.log(
                "SAVE API RESPONSE:",
                resp
            );

            if (
                resp.status === 200 &&
                resp.data
            ) {
                Toast(
                    "Success!",
                    "Successfully saved rep details",
                    "success"
                );

                if (onSuccess) {
                    onSuccess();
                }

                formik.resetForm();

                setSelectedTerminalId("");

                setSelectedTerminalObj(null);

                setShowConfirm(false);

                if (onClose) {
                    onClose();
                }
            } else {
                Toast(
                    "Notice",
                    "Unexpected response format",
                    "info"
                );
            }
        } catch (error) {
            console.error(
                "API Error:",
                error
            );

            console.error(
                "API Response:",
                error?.response
            );

            Toast(
                "Error",
                error?.response?.data?.message ||
                    "An unexpected error occurred",
                "error"
            );
        }
    };

    const handleConfirmSubmit = () => {
        setShowConfirm(false);
        formik.handleSubmit();
    };

    return (
        <Box
            component="form"
            onSubmit={formik.handleSubmit}
            className="flex flex-col gap-5"
        >
            <Box
                sx={{
                    display: "flex",
                    flexDirection: "column",
                    ml: 3,
                    mr: 5,
                }}
            >
                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                    }}
                >
                    <Typography sx={{ mb: 0.5 }}>
                        Terminal Type *
                    </Typography>

                    <FormControl fullWidth>
                        <MSelect
                            options={terminalTypes}
                            value={selectedTerminalId}
                            onChange={
                                handleTerminalChange
                            }
                            multiple={false}
                            placeholder="Select Terminal Type (e.g., MCT-MK-III)"
                        />
                    </FormControl>
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography sx={{ mb: 0.5 }}>
                        Site ID *
                    </Typography>

                    <MSelect
                        options={options}
                        value={formik.values.siteId}
                        onChange={(newValue) => {
                            const value =
                                typeof newValue ===
                                "object"
                                    ? newValue?.value
                                    : newValue;

                            formik.setFieldValue(
                                "siteId",
                                value || ""
                            );

                            formik.setFieldTouched(
                                "siteId",
                                true
                            );
                        }}
                        placeholder={
                            selectedTerminalId
                                ? "Select a matching Site"
                                : "Select Terminal Type first"
                        }
                        getOptionValue={(opt) =>
                            opt.value
                        }
                        getOptionLabel={(opt) =>
                            opt.label
                        }
                        disabled={
                            !selectedTerminalId
                        }
                    />

                    {selectedTerminalId &&
                        options.length === 0 && (
                            <Typography
                                variant="caption"
                                color="error"
                                sx={{ mt: 1 }}
                            >
                                No sites found for
                                this Terminal Type.
                            </Typography>
                        )}

                    {formik.touched.siteId &&
                        formik.errors.siteId && (
                            <Typography
                                sx={{
                                    color: "#d32f2f",
                                    fontSize: "12px",
                                    mt: 0.5,
                                }}
                            >
                                {
                                    formik.errors
                                        .siteId
                                }
                            </Typography>
                        )}
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        Personal Name *
                    </Typography>

                    <MInput
                        label="Personnel Name"
                        value={
                            formik.values
                                .personalName
                        }
                        placeholder="Enter personnel name"
                        onChange={(e) => {
                            const value = e.target.value;
                            if (value.length <= 50 && validateInput(value, personnelRegex.name) !== undefined) {
                              handleInputChange(e, "personalName");
                            }
                          }}
                          
                        errorMessage={
                            formik.touched
                                .personalName &&
                            formik.errors
                                .personalName
                        }
                    />
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography sx={{ mb: 0.5 }}>
                        Rank *
                    </Typography>

                    <FormControl fullWidth>
                        <Select
                            id="rank-select"
                            size="small"
                            value={
                                formik.values.rank
                            }
                            onChange={(e) =>
                                handleInputChange(
                                    e,
                                    "rank"
                                )
                            }
                            sx={{
                                borderRadius: "10px",
                                "& .MuiSelect-select": {
                                    fontFamily:
                                        "Montserrat",
                                },
                            }}
                        >
                            <MenuItem value="AIR CMDE">
                                AIR CMDE
                            </MenuItem>
                            <MenuItem value="GP CAPT">
                                GP CAPT
                            </MenuItem>
                            <MenuItem value="WG CDR">
                                WG CDR
                            </MenuItem>
                            <MenuItem value="SQN LDR">
                                SQN LDR
                            </MenuItem>
                            <MenuItem value="FLT LT">
                                FLT LT
                            </MenuItem>
                            <MenuItem value="FG OFFR">
                                FG OFFR
                            </MenuItem>
                            <MenuItem value="MWO">
                                MWO
                            </MenuItem>
                            <MenuItem value="WO">
                                WO
                            </MenuItem>
                            <MenuItem value="JWO">
                                JWO
                            </MenuItem>
                            <MenuItem value="SGT">
                                SGT
                            </MenuItem>
                            <MenuItem value="CPL">
                                CPL
                            </MenuItem>
                            <MenuItem value="LAC">
                                LAC
                            </MenuItem>
                            <MenuItem value="AC">
                                AC
                            </MenuItem>
                            <MenuItem value="AGV">
                                AGV
                            </MenuItem>
                        </Select>
                    </FormControl>

                    {formik.touched.rank &&
                        formik.errors.rank && (
                            <Typography
                                sx={{
                                    color: "#d32f2f",
                                    fontSize: "12px",
                                    mt: 0.5,
                                }}
                            >
                                {
                                    formik.errors
                                        .rank
                                }
                            </Typography>
                        )}
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        Unit *
                    </Typography>

                    <MInput
                        label="Unit"
                        value={
                            formik.values.unit
                        }
                        placeholder="Enter unit"
                        onChange={(e) => {
                            const value = e.target.value;
                            if (value.length <= 20) {
                              handleInputChange(e, "unit");
                            }
                          }}
                        errorMessage={
                            formik.touched.unit &&
                            formik.errors.unit
                        }
                    />
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        Primary Civil Mobile *
                    </Typography>

                    <MInput
                        label="Primary Civil Mobile"
                        value={
                            formik.values
                                .primaryCivilMobile
                        }
                        placeholder="6-9xxxxxxxxx"
                        onChange={(e) => {
                            if (
                                validateInput(
                                    e.target.value,
                                    personnelRegex
                                        .primaryMobile
                                ) !== undefined
                            ) {
                                handleInputChange(
                                    e,
                                    "primaryCivilMobile"
                                );
                            }
                        }}
                        errorMessage={
                            formik.touched
                                .primaryCivilMobile &&
                            formik.errors
                                .primaryCivilMobile
                        }
                    />
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        AFCEL Phone
                    </Typography>

                    <MInput
                        label="AFCEL Phone"
                        value={
                            formik.values
                                .afcelPhone
                        }
                        placeholder="1-9xxxxxxx"
                        onChange={(e) => {
                            if (
                                validateInput(
                                    e.target.value,
                                    personnelRegex
                                        .landline
                                ) !== undefined
                            ) {
                                handleInputChange(
                                    e,
                                    "afcelPhone"
                                );
                            }
                        }}
                        errorMessage={
                            formik.touched
                                .afcelPhone &&
                            formik.errors
                                .afcelPhone
                        }
                    />
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        IP Phone
                    </Typography>

                    <MInput
                        label="IP Phone"
                        value={
                            formik.values
                                .ipPhone
                        }
                        placeholder="1-9xxxxxxx"
                        onChange={(e) => {
                            if (
                                validateInput(
                                    e.target.value,
                                    personnelRegex
                                        .landline
                                ) !== undefined
                            ) {
                                handleInputChange(
                                    e,
                                    "ipPhone"
                                );
                            }
                        }}
                        errorMessage={
                            formik.touched
                                .ipPhone &&
                            formik.errors
                                .ipPhone
                        }
                    />
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        Alternative Civil Phone No.
                    </Typography>

                    <MInput
                        label="Alternate Civil Mobile No."
                        value={
                            formik.values
                                .altCivilMobile
                        }
                        placeholder="5-9xxxxxxxxx"
                        onChange={(e) => {
                            if (
                                validateInput(
                                    e.target.value,
                                    personnelRegex
                                        .altMobile
                                ) !== undefined
                            ) {
                                handleInputChange(
                                    e,
                                    "altCivilMobile"
                                );
                            }
                        }}
                        errorMessage={
                            formik.touched
                                .altCivilMobile &&
                            formik.errors
                                .altCivilMobile
                        }
                    />
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                    }}
                >
                    <Typography
                        sx={{
                            textAlign: "left",
                            fontFamily: "Montserrat",
                            mb: 0.5,
                        }}
                    >
                        Email
                    </Typography>

                    <MInput
                        label="Email"
                        value={
                            formik.values.email
                        }
                        placeholder="example@domain.com"
                        onChange={(e) =>
                            handleInputChange(
                                e,
                                "email"
                            )
                        }
                        errorMessage={
                            formik.touched.email &&
                            formik.errors.email
                        }
                    />
                </Box>

                <Box
                    sx={{
                        float: "right",
                        display: "flex",
                        mt: 3,
                        justifyContent: "flex-end",
                    }}
                >
                    <MButtonPrimary
                        type="button"
                        onClick={() =>
                            setShowConfirm(true)
                        }
                        disabled={
                            isAddDisabled
                        }
                    >
                        Add
                    </MButtonPrimary>
                </Box>
            </Box>

            <MDialog
                open={showConfirm}
                variant="warning"
                title="Confirm Action"
                icon={question_mark}
                message="Are you sure you want to add this representative?"
                onConfirm={
                    handleConfirmSubmit
                }
                onClose={() =>
                    setShowConfirm(false)
                }
                mode="grandchild"
                isGrandchildFullScreen={isGrandchildFullScreen}
            />
        </Box>
    );
};

export default ConfigAddRemoteRep;