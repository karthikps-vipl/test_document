import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useState } from "react";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  DELETE_SITE_REP_DETAILS,
  FETCH_SITE_REP_DETAILS,
 } from "@/RestAPI/url/endpoint";
import { Box, CircularProgress, Typography } from "@mui/material";
import Toast from "@/components/Reusable/Toast/Toast";
 import MDialog from "@/components/Reusable/Dialog/MDialog";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useDispatch } from "react-redux";
import { setRemoteRepDetails } from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";

const ConfigRemoteRep = ({
  privilegeKey,
  handleEdit,
  handleDelete,
  handleView,
  handleAdd,
  refreshTrigger,
  isChildFullScreen
}) => {
  const [ipData, setIPData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });

  const dispatch = useDispatch();

  const columns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Name", uid: "personnelName", width: "100px" },
    { name: "Rank", uid: "personnel", width: "100px" },
    { name: "Unit", uid: "unit", width: "100px" },
    { name: "IP Phone", uid: "ipPhone", width: "110px" },
    { name: "AFCEL", uid: "afcel", width: "110px" },
    { name: "Primary Mobile", uid: "primaryCivilMobile", width: "140px" },
    { name: "Email", uid: "email" },
    {
      name: "Actions",
      uid: "actions",
      sortable: false,
      cellClassName: "sticky-actions",
      headerClassName: "sticky-actions",
    },
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await InventoryAxios(FETCH_SITE_REP_DETAILS, "get", 1);
        console.log("FETCH_SITE_REP_DETAILS", data);
        dispatch(setRemoteRepDetails(data));
        // Map data directly into the state
        const processedData = data.map((item, index) => ({
          ...item,
          sno: index + 1,
        }));

        setIPData(processedData);
      } catch (error) {
        console.error("Error fetching IP data:", error);
        setIPData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [refreshTrigger]);

  const handleDeleteRow = async (row) => {
    console.log("Deleting row:", row);

    try {
      // 1. Optimistic UI Update
      setIPData((prevData) =>
        prevData.filter((item) => item.repId !== row.repId)
      );

      // 2. Construct payload
      const payload = {
        repId: row.repId,
        personnelName: row.personnelName || "",
        personnel: row.personnel || "",
        unit: row.unit || "",
        ipPhone: row.ipPhone || "",
        afcel: row.afcel || "",
        primaryCivilMobile: row.primaryCivilMobile || "",
        alternateCivilMobile: row.alternateCivilMobile || "",
        email: row.email || "",
        siteId: row.siteId,
      };

      // 3. Call API
      await InventoryAxios(DELETE_SITE_REP_DETAILS, "post", payload);
      console.log("Delete successful");
    } catch (error) {
      console.error("Delete failed, reverting UI:", error);
      setIPData((prevData) => [...prevData, row]);
      Toast("Error", "Failed to delete record. Data restored.", "error");
    }
  };

  return (
    <Box>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          columns={columns}
          tableData={ipData}
          showPagination={true}
          showSearch={true}
          hideAdd={false}
          AddText="Add "
          // Handle Add
          handleAdd={() =>
            handleAdd({ mode: "CREATE", title: "Add Representative" })
          }
          // Handle Edit - CRITICAL FIX: Ensure repId is passed correctly
          handleEdit={(row) =>
            handleEdit({
              ...row, // Spread original row data
              repId: row.repId, // Explicitly ensure repId exists
              mode: "EDIT",
              title: `Edit Representative: ${row.personnelName || "RECORD"}`,
            })
          }
          handleDelete={(row) => {
            setRowToDelete({ visible: true, row: row });
          }}
        />
      )}

      <Typography
        sx={{
          p: 1,
          color: "#e75656",
          fontSize: "12px",
          mt: 2,
          display: "block",
          width: "100%",
        }}
      >
        Note : Maximum 5 Rep's can be added in each site.
      </Typography>

      {rowToDelete.visible && (
        <MDialog
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          icon={Delete_Icon_}
          mode="child"
          isChildFullScreen={isChildFullScreen}
          message={`Are you sure you want to delete ${
            rowToDelete.row?.personnelName || "this record"
          }?`}
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null });
            Toast("Success!", "Successfully deleted row", "success");
          }}
          onClose={() => setRowToDelete({ visible: false, row: null })}
        />
      )}
    </Box>
  );
};

export default ConfigRemoteRep;
