import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useState } from "react";
import { InventoryAxios, } from "@/RestAPI/api/axiosApicall"
import { FETCH_SITE_REP_DETAILS, } from "@/RestAPI/url/endpoint"
import { Box, CircularProgress } from "@mui/material";


const ConfigRemoteRep = ({ privilegeKey, handleEdit, }) => {
    const [ipData, setIPData] = useState([]);
    const [loading, setLoading] = useState(true);
    // const [terminalTypes, setTerminalTypes] = useState([]);
    // const [selectedTerminalId, setSelectedTerminalId] = useState("");
    const columns = [
        { name: "S. No ", uid: "sno",width:'40px' },
        { name: "Name", uid: "personnelName",width:'100px' },
        { name: "Rank", uid: "personnel",width:'100px' },
        { name: "Unit", uid: "unit",width:'100px' },
        { name: "IP Phone", uid: "ipPhone",width:'110px' },
        { name: "AFCEL", uid: "afcel",width:'110px' },
        { name: "Primary Mobile", uid: "primaryCivilMobile" ,width:'140px'},
        { name: "Email", uid: "email",width:"70px" },

        { name: "Actions", uid: "actions", sortable: false, cellClassName: 'sticky-actions', headerClassName: 'sticky-actions' },
    ];
    // useEffect(() => {
    //     const load = async () => {
    //         try {
    //             const res = await InventoryAxios(FETCH_ALL_TERMINAL_TYPE_DETAILS, "get");
    //             console.log("Terminal Types Response:", res);

    //             setTerminalTypes(
    //                 (res?.data || []).map((t) => ({
    //                     label: t.terminalTypeName,
    //                     value: t.id,
    //                     raw: t,
    //                 }))
    //             );
    //         } catch (err) {
    //             Toast("Error!", `Error loading terminals`, "error");
    //         }
    //     };
    //     load();
    // }, []);

    // const handleTerminalChange = (newValue) => {
    //     setSelectedTerminalId(newValue);
    //     // You can add logic here if you need to fetch specific IPs based on terminal type
    // };
    useEffect(() => {
        const fetchData = async () => {
            try {
                const { data } = await InventoryAxios(FETCH_SITE_REP_DETAILS, "get", 1);
                console.log("aaaaaaa", data)
                // Map data directly into the state
                const processedData = data.map((item, index) => ({
                    ...item,
                    sno: index + 1,
                }));

                setIPData(processedData);
            } catch (error) {
                console.error("Error fetching IP data:", error);
                setIPData([]); // Fallback to empty array on error
            } finally {
                setLoading(false); // Runs whether try succeeded or catch ran
            }
        };

        fetchData();
    }, []);


    return (
        <Box   >
            {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', }}>
                    <CircularProgress />

                </Box>
            ) : (
            //     <Box sx={{ marginBottom: 2,display:"flex"  ,flexDirection:"column"}}>
            //         <Box sx={{width:"50%",mb:3}} >  <MSelect
            //     label="Select Terminal *"
            //     options={terminalTypes}
            //     value={selectedTerminalId}
            //     onChange={handleTerminalChange}
            //     multiple={false}
            // /></Box>
                  

                    <MTable
                        privilegeKey={privilegeKey}
                        columns={columns}
                        tableData={ipData}
                        //tableTitle="IP Whitelisting"
                        showPagination={true}
                        showSearch={true}
                        hideAdd={false}
                        AddText="Add  "
                        // Handle Add
                        handleAdd={() =>
                            handleAdd({ mode: "CREATE", title: "Add  Login Details" })
                        }
                        // Handle Edit - Pass originalPassword instead of the asterisks
                        handleEdit={(row) =>
                            handleEdit({
                                ...row,
                                password: row.originalPassword,
                                mode: "EDIT",
                                title: "Update Login Details",
                            })
                        }
                        handleDelete={(row) => {
                            setRowToDelete({ visible: true, row: row });
                        }}
                         
                    />
                // </Box>
            )}
        </Box>


    )
        ;
};

export default ConfigRemoteRep;
