import MInput from "@/components/Reusable/Input/MInput";
import MModal from "@/components/Reusable/Modal/MModal";
import formatDate from "@/lib/utils";
import { Box, Typography } from "@mui/material";
import { useEffect, useState } from "react";

const classes = {
  inputContainer: {
    display: "flex",
    flexDirection: "column",
  },
};

export default function IndividualDevicePreview(props) {
  const { onClose, data } = props;
  const [configData, setConfigData] = useState("null");

  useEffect(() => {
    if (data?.configData) {
      try {
        let tempStr = JSON.stringify(JSON.parse(data?.configData)?.[0])
          .replaceAll(",", "\n")
          .replaceAll("{", "")
          .replaceAll('"}', "")
          .replaceAll('"', " ");
        setConfigData(tempStr);
      } catch {
        setConfigData(data.configData);
      }
    } else {
      setConfigData("null");
    }
  }, [data]);

  return (
    <MModal
      open={true}
      fullWidth
      title={"Individual Device Configuration Backup"}
      handleClose={onClose}
      customWidth={"1024px"}
    >
      <Box
        sx={{
          display: "flex",
          gap: "10px",
          width: "100%",
          justifyContent: "space-between",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 1.5,
            width: "50%",
          }}
        >
          <Box sx={{ ...classes.inputContainer }}>
            <Typography>File Name</Typography>
            <MInput
              variant="outlined"
              size="small"
              fullWidth
              value={data.fileName || "null"}
            />
          </Box>
          <Box sx={{ ...classes.inputContainer }}>
            <Typography>File Description</Typography>
            <MInput
              fullWidth
              multiline
              minRows={3}
              value={data.description || "null"}
            />
          </Box>
          <Box sx={{ ...classes.inputContainer }}>
            <Typography>Device Name</Typography>
            <MInput
              fullWidth
              value={
                data?.imSiteResourceInfo?.resourceName ||
                data?.resourceInfo?.resourceName ||
                "null"
              }
            />
          </Box>
          <Box sx={{ ...classes.inputContainer }}>
            <Typography>Device Type</Typography>
            <MInput
              fullWidth
              value={
                data?.imSiteResourceInfo?.imResourceType?.resourceTypeName ||
                data?.resourceInfo?.imResourceType?.resourceTypeName ||
                "null"
              }
            />
          </Box>
          <Box sx={{ ...classes.inputContainer }}>
            <Typography>Backup Mode</Typography>
            <MInput
              label=" Backup Mode"
              variant="outlined"
              size="small"
              fullWidth
              value={
                data.formattedBackupMode || data.backupMode === 1
                  ? "MANUAL"
                  : "SCHEDULED" || "null"
              }
            />
          </Box>
          <Box sx={{ ...classes.inputContainer }}>
            <Typography>Date/Time</Typography>
            <MInput
              fullWidth
              value={
                formatDate(data.formattedDateTime) ||
                formatDate(data.dateTime) ||
                "null"
              }
            />
          </Box>
        </Box>

        <Box sx={{ display: "flex", width: "50%", flexDirection: "column" }}>
          <Typography>Config Data</Typography>
          <MInput
            multiline
            maxRows={20}
            minRows={20}
            fullWidth
            value={configData || "null"}
          />
        </Box>
      </Box>
    </MModal>
  );
}
