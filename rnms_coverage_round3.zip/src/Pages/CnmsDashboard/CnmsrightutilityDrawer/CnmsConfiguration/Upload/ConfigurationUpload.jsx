import React, { useState, useEffect } from "react";

import {
  Box,
  CircularProgress,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from "@mui/material";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";

// import IndividualDevicePreview from "../ConfigurationBackupData/IndividualDevicePreview";
import { useSelector } from "react-redux";

import { ConfigurationAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES,
  FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES_AT_CNMS,
  FETCH_ALL_REMOTE_TERMINAL_TYPE_DETAILS_AT_CNMS,
  FETCH_BACKUP_DATA_BY_RESOURCE_ID,
  FETCH_SITEDETAILS_BY_TERMINALTYPE_ID,
  FTECH_ALL_DEVICE_BACKUP,
  FTECH_BACKUP_DATA_BY_RESOURCE_ID_SITE_ID_AT_CNMS,
  UPLOAD_ALL_DEVICE_BACKUP,
  UPLOAD_SINGLE_DEVICE_BACKUP,
  UPLOAD_SINGLE_DEVICE_BACKUP_FROM_CNMS,
} from "@/RestAPI/url/cnmsEndPoint";
import Toast from "@/components/Reusable/Toast/Toast";
import { Update, Visibility } from "@mui/icons-material";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MForm from "@/components/Reusable/Form/MForm";
import IndividualDevicePreview from "./components/IndividualDevicePreview";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";

const DEVICE_TYPE_FETCH_FAILED = "Fetching Device Type Failed!";
const FAILED_TO_UPLOAD = "Failed to upload!";
const DEVICE_FETCH_FAILED = "Fetching Devices Failed!";
const FILES_FETCH_FAILED = "Files Fetch Failed!";
const ENUM_FETCH_FAILED = "Fetching Enum Value Failed";
const SUCCESSFULLY_TO_UPLOAD = "Successfully Uploaded";

//Helper Component
const FileUpload = ({ disableValue }) => {
  const schema = yup.object().shape({
    fileName: yup
      .string()
      .typeError("Must be a String")
      .min(3, "Min 3 Characters required")
      .max(20, "Max 20 characters reached")
      .required(),
    fileDescription: yup
      .string()
      .typeError("Must be a String")
      .min(3, "Min 3 Characters required")
      .max(256, "Max 256 characters reached")
      .nullable()
      .required(),
  });
  //Form Handler
  const {
    register,
    formState: { errors },
  } = useForm({
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const [data, setData] = useState({});
  const [backupType] = useState("INDIVIDUAL_DEVICE");
  const [backupMode, setBackupMode] = useState("SCHEDULED");
  const [selectedDeviceTypes] = useState("Select One");
  const [devices, setDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState("Select One");
  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState("Select One");
  const [selectedFileId, setSelectedFileId] = useState(null);
  const [resourceData, setResourceData] = useState([]);

  const [selectedFileDescription, setSelectedFileDescription] = useState("");
  const [isIndividualPreviewDialogOpen, setIsIndividualPreviewDialogOpen] =
    useState(false);
  const [isAllDevicePreviewDialogOpen, setIsAllDevicePreviewDialogOpen] =
    useState(false);

  const [loading, setLoading] = useState(false);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [allTerminalTypes, setAllTerminalTypes] = useState([]);
  const [selectedTerminal, setSelectedTerminal] = useState("");
  const [allSites, setAllSites] = useState([]);
  const [selectedSiteId, setSelectedSiteId] = useState("");

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const fetchAllFileNamesAtCnms = async (resourceId, siteId) => {
    setLoadingFiles(true);
    try {
      const url = `${FTECH_BACKUP_DATA_BY_RESOURCE_ID_SITE_ID_AT_CNMS}/${resourceId}/${siteId}`;
      const response = await ConfigurationAxios(url, "get");
      setResourceData(response.data);
      const files = response.data.map((el) => {
        return {
          ...el,
          fileName: el.fileName,
          id: el.id,
          filesDescription: el.description,
          mode: el.backupMode === 2 ? "SCHEDULED" : "MANUAL",
        };
      });
      setFiles(files);
    } catch (e) {
      Toast("", "error", "error");
      console.error(e);
    }
    setLoadingFiles(false);
  };
  const fetchAllFileNames = async (Id) => {
    if (backupType === "ALL_DEVICE") {
      setLoadingFiles(true);
      try {
        const response = await ConfigurationAxios(
          FTECH_ALL_DEVICE_BACKUP,
          "get"
        );
        setResourceData(response.data);
        const files = response.data.map((el) => {
          return {
            ...el,
            fileName: el.fileName,
            id: el.id,
            filesDescription: el.description,
            mode: el.backupMode === 2 ? "SCHEDULED" : "MANUAL",
          };
        });
        setFiles(files);
      } catch (e) {
        console.error("Error", e);
      }
      setLoadingFiles(false);
    }
    if (backupType === "INDIVIDUAL_DEVICE") {
      setLoadingFiles(true);
      try {
        const response = await ConfigurationAxios(
          `${FETCH_BACKUP_DATA_BY_RESOURCE_ID}/${Id}`,
          "get"
        );
        setResourceData(response.data);
        const files = response.data.map((el) => {
          return {
            fileName: el.fileName,
            id: el.id,
            filesDescription: el.description,
            mode: el.backupMode === 2 ? "SCHEDULED" : "MANUAL",
          };
        });
        setFiles(files);
      } catch (e) {
        console.error(e);
      }
      setLoadingFiles(false);
    }
  };

  const findAllDeviceNames = async () => {
    setLoading(true);
    try {
      const response = await InventoryAxios(
        FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES,
        "get"
      );
      if (response?.data) {
        setDevices(response?.data);
      }
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  };

  const findAllDeviceNamesAtCnms = async (siteId) => {
    try {
      const url = `${FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES_AT_CNMS}/${selectedTerminal}/${siteId}`;
      const response = await InventoryAxios(url, "get");
      if (response?.data) {
        const options = response?.data?.map((item) => ({
          ...item,
          label: item.resourceName,
          value: item.resourceId,
        }));
        setDevices(options);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (isCnms) {
      (async () => {
        try {
          setLoading(true);
          const res = await InventoryAxios(
            FETCH_ALL_REMOTE_TERMINAL_TYPE_DETAILS_AT_CNMS,
            "get"
          );
          if (res?.data) {
            const data = res.data?.map((item) => ({
              ...item,
              label: item.terminalTypeName,
              value: item.id,
            }));
            setAllTerminalTypes(data);
          } else {
            setAllTerminalTypes([]);
          }
          setLoading(false);
        } catch (error) {
          setLoading(false);
          console.error("failed to fetch data", error);
        }
      })();
    }
  }, []);

  useEffect(() => {
    // getEnumValue();
    if (backupType === "ALL_DEVICE") {
      fetchAllFileNames();
    }

    if (
      backupType !== "ALL_DEVICE" &&
      selectedDeviceTypes === "Select One" &&
      !isCnms
    ) {
      // fetchDeviceTypes();
      findAllDeviceNames();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [backupType]);

  const handleViewConfigFile = () => {
    if (backupType === "INDIVIDUAL_DEVICE") {
      setIsIndividualPreviewDialogOpen(true);
      let selectedObj = resourceData.find((el) => el.id === selectedFileId);
      setData(selectedObj);
    }
    if (backupType === "ALL_DEVICE") {
      setIsAllDevicePreviewDialogOpen(true);
      let selectedObj = resourceData.find((el) => el.id === selectedFileId);
      setData(selectedObj);
    }
  };

  //renders based on selection of backup type
  const renderFieldForIndividual = () => {
    if (backupType === "INDIVIDUAL_DEVICE") {
      return (
        <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <Box>
            {isCnms && (
              <Box sx={{ display: "flex", gap: 1 }}>
                <Box
                  sx={{
                    display: "flex",
                    width: "50%",
                    flexDirection: "column",
                  }}
                >
                  <MSelect
                    label={"Terminal*"}
                    placeholder={"Select terminal"}
                    value={selectedTerminal}
                    options={allTerminalTypes}
                    onChange={async (selected) => {
                      setSelectedTerminal(selected.value);
                      try {
                        const res = await InventoryAxios(
                          `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${selected.value}`,
                          "get"
                        );
                        if (res?.data) {
                          setSelectedSiteId("none");
                          const options = res.data?.map((item) => ({
                            ...item,
                            label: item.siteId,
                            value: item.siteId,
                          }));
                          setAllSites(options);
                        } else {
                          setAllSites([]);
                        }
                        // setFormData({ ...formData, ['sites']: res.data })
                      } catch (err) {
                        console.error(err);
                        setAllSites([]);
                      }
                    }}
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    width: "50%",
                    flexDirection: "column",
                  }}
                >
                  <MSelect
                    label={"Site ID*"}
                    value={selectedSiteId}
                    placeholder={"Select site"}
                    onChange={(option) => {
                      setSelectedSiteId(option.value);
                      findAllDeviceNamesAtCnms(option.value);
                    }}
                    options={allSites}
                  />
                </Box>
              </Box>
            )}
          </Box>

          <Box sx={{ display: "flex", gap: 1 }}>
            <Box
              sx={{ display: "flex", width: "50%", flexDirection: "column" }}
            >
              {loading ? (
                <Typography align="center">
                  <CircularProgress size="35px" />
                </Typography>
              ) : (
                <MSelect
                  label={"Device Name*"}
                  value={selectedDevice}
                  onChange={(option) => {
                    setSelectedDevice(option.value);
                    setSelectedFile("Select One");
                    setSelectedFileDescription("");
                    if (isCnms) {
                      let resourceId = option.value;
                      fetchAllFileNamesAtCnms(resourceId, selectedSiteId);
                    } else {
                      fetchAllFileNames(option.value);
                    }
                  }}
                  options={devices}
                />
              )}
            </Box>

            <Box
              sx={{ display: "flex", width: "50%", flexDirection: "column" }}
            >
              {loadingFiles ? (
                <Typography align="center">
                  <CircularProgress size="35px" />
                </Typography>
              ) : (
                <MSelect
                  label={"File Name*"}
                  placeholder={"Select One"}
                  value={selectedFile}
                  getOptionLabel={(option) => option?.fileName}
                  getOptionValue={(option) => option?.id}
                  onChange={(selectedOption) => {
                    setSelectedFile(selectedOption);
                    setSelectedFileDescription(selectedOption.filesDescription);
                    setBackupMode(selectedOption.mode);
                    setSelectedFileId(selectedOption.id);
                    disableValue(true, selectedOption.id, backupType, files);
                  }}
                  options={files}
                />
              )}
            </Box>
          </Box>
        </Box>
      );
    } else {
      return null;
    }
  };
  //
  return (
    <div>
      {isAllDevicePreviewDialogOpen && (
        // <AllDevicePreview
        //   data={data || []}
        //   fileId={selectedFileId}
        //   onClose={() => {
        //     setIsAllDevicePreviewDialogOpen(false);
        //   }}
        //       />
        <></>
      )}

      {isIndividualPreviewDialogOpen && (
        <IndividualDevicePreview
          data={data || []}
          fileId={selectedFileId}
          onClose={() => {
            setIsIndividualPreviewDialogOpen(false);
          }}
        />
      )}

      <Box>
        {renderFieldForIndividual()}

        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
          <MButtonPrimary
            onClick={() => handleViewConfigFile()}
            color="primary"
            variant="contained"
            size="small"
            startIcon={<Visibility />}
            disabled={selectedFile === "Select One"}
          >
            View Config File
          </MButtonPrimary>
        </Box>
        <Box sx={{ mt: 2 }}>
          <TextField
            label={"File Description*"}
            {...register("fileDescription")}
            id="filled-multiline-static"
            multiline
            InputProps={{ readOnly: true }}
            rows={4}
            value={selectedFileDescription}
            variant="outlined"
            inputProps={{ maxLength: 255 }}
            fullWidth
            error={Boolean(errors?.fileDescription)}
            helperText={errors?.fileDescription?.message}
          />
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2, mt: 2 }}>
          <Box>{"Backup Mode :"}</Box>

          <FormControl disabled>
            <RadioGroup
              aria-label="mode"
              name="backupMode"
              value={backupMode}
              row={true}
            >
              <FormControlLabel
                value="MANUAL"
                control={<Radio />}
                label="MANUAL"
              />
              <FormControlLabel
                value={"SCHEDULED"}
                control={<Radio />}
                label="SCHEDULED"
              />
            </RadioGroup>
          </FormControl>
        </Box>

        {/* show upload when user has a privilege to upload */}
        {/* {privilegesKeysSet?.has("configuration_Management_upload") && (
            <Box sx={{ mt: 2 }}>
              <MButtonPrimary startIcon={<Update />}>UPLOAD</MButtonPrimary>
            </Box>
          )} */}
      </Box>
    </div>
  );
};

// main entry
export default function ConfigurationUpload({ isChildFullScreen }) {
  const [uploadBtnStatus, setUploadBtnStatus] = useState(false);
  const [selectedFileId, setSelectedFileId] = useState(null);
  const [selectedBackupType, setSelectedBackupType] = useState("ALL_DEVICE");
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [files, setFiles] = useState([]);
  const privilegesSet = useSelector(selectPrivilegesSet);
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const uploadForSingleDevice = async (Id) => {
    try {
      await ConfigurationAxios(`${UPLOAD_SINGLE_DEVICE_BACKUP}/${Id}`, "post");
      Toast("", SUCCESSFULLY_TO_UPLOAD, "success");
    } catch {
      Toast("", FAILED_TO_UPLOAD, "error");
    }
  };
  const uploadForAllDevice = async (Id) => {
    try {
      await ConfigurationAxios(`${UPLOAD_ALL_DEVICE_BACKUP}/${Id}`, "post");
      Toast("", SUCCESSFULLY_TO_UPLOAD, "success");
    } catch {
      Toast("", FAILED_TO_UPLOAD, "error");
    }
  };

  const handleUploadBtnClick = () => {
    if (selectedBackupType === "ALL_DEVICE") {
      uploadForAllDevice(selectedFileId);
    } else {
      uploadForSingleDevice(selectedFileId);
    }
  };

  const handleUploadAtCnms = async () => {
    let obj = {};
    obj = files?.find((e) => e.id === selectedFileId);
    try {
      await ConfigurationAxios(
        UPLOAD_SINGLE_DEVICE_BACKUP_FROM_CNMS,
        "post",
        obj
      );
      Toast("", SUCCESSFULLY_TO_UPLOAD, "success");
    } catch {
      Toast("", FAILED_TO_UPLOAD, "error");
    }
  };

  const disabledValueForUploadBtn = (val, Id, type, files) => {
    setUploadBtnStatus(val);
    setSelectedFileId(Id);
    setFiles(files);
    setSelectedBackupType(type);
  };
  return (
    <>
      <MForm title={"Upload"}>
        <Box>
          <FileUpload disableValue={disabledValueForUploadBtn} />

          <Box>
            {privilegesSet?.has("configuration_Management_upload") && (
              <MButtonPrimary
                color="primary"
                variant="contained"
                startIcon={<Update />}
                disabled={!uploadBtnStatus || !selectedFileId}
                onClick={() => {
                  setOpenConfirmation(true);
                }}
              >
                Upload
              </MButtonPrimary>
            )}
          </Box>
        </Box>
      </MForm>

      {/*  Confirmation Dialog */}

      <MDialog
        open={openConfirmation}
        onClose={() => setOpenConfirmation(false)}
        title={"Confirm"}
        message={"Do you really want to perform this operation(UPLOAD)?"}
        onConfirm={() => {
          if (!isCnms) {
            handleUploadBtnClick();
            setOpenConfirmation(false);
          } else {
            handleUploadAtCnms();
            setOpenConfirmation(false);
          }
        }}
        cancelText="No"
        icon={confirmIcon}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </>
  );
}
