import MCheckbox from "@/components/Reusable/Checkbox/MCheckbox";
import MForm from "@/components/Reusable/Form/MForm";
import MInput from "@/components/Reusable/Input/MInput";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { GET_LDAP_CONFIG, SAVE_LDAP_CONFIG } from "@/RestAPI/url/cnmsEndPoint";
import { Box, Typography, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import Toast from "@/components/Reusable/Toast/Toast";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { Update } from "@mui/icons-material";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";

const LdapConfiguration = ({ isChildFullScreen }) => {
  const [uploadOptions, setUploadOptions] = useState({
    url: "",
    port: "",
    domain_name: "",
    caFilePath: "",
    bindUsername: "",
    bindPassword: "",
  });

  const [isCustomCredsEnabled, setIsCustomCredsEnabled] = useState(false);
  const [isModifyMode, setIsModifyMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [proceed, setProceed] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // Error States
  const [userNameError, setUserNameError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);

  useEffect(() => {
    ConfigurationAxios(GET_LDAP_CONFIG, "get")
      .then((resp) => {
        console.log("Ldap Data", resp.data);
        if (resp.data) {
          // Logic migrated from old useEffect
          const data = resp.data;

          // Extract Port
          // const portMatch = data.connection_url?.match(/([\d]*)\/?$/);
          //sonar
          const portMatch = data.connection_url?.match(/(\d+)(?!\D)/);
          const port = portMatch ? portMatch[1] : "INVALID PORT";

          // Extract URL
          // const urlMatch = data.connection_url?.match(/^(.*):[\d]*\/?$/);

          // sonar
          const urlMatch = data.connection_url?.match(/^(.*):\d*\/?$/);
          const url = urlMatch ? urlMatch[1] : "INVALID URL";

          // Extract Domain
          const domainMatch = data.user_domain?.match(/^,(.*)/);
          const domain = domainMatch ? domainMatch[1] : "INVALID DOMAIN NAME";

          setUploadOptions({
            url: url,
            port: port,
            domain_name: domain,
            caFilePath: data.ca_file_path || "",
            bindUsername: data.bindUserName || "",
            bindPassword: data.bindPassword || "",
          });
          setIsCustomCredsEnabled(data.bind_credentials_enabled || false);
        }
      })
      .catch((error) => {
        console.error("GET_LDAP_CONFIG", error);

        Toast("", "Error in getting LDAP config", "error");
      });
  }, []);

  const handleChange = (e, key) => {
    const value = e.target.value;
    const keyName = key; // 'bindUsername' or 'bindPassword'

    // Validation: Username Regex
    const usernameRegex = /^[a-zA-Z0-9_-]{4,24}$/;
    if (keyName === "bindUsername") {
      if (value && !value.match(usernameRegex)) {
        setUserNameError(true);
      } else {
        setUserNameError(false);
      }
    }

    // Validation: Password Regex (Simplified based on old code intent)
    const passwordReg =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)([a-zA-Z\d^@#$&_-]{8,16}$)/;
    if (keyName === "bindPassword") {
      if (value && !value.match(passwordReg)) {
        setPasswordError(true);
      } else {
        setPasswordError(false);
      }
    }

    setProceed(true);

    setUploadOptions((prev) => ({ ...prev, [keyName]: value }));
  };

  const handleSave = (e) => {
    e.preventDefault();
    setLoading(true);
    setProceed(false);
    setIsModifyMode(false);

    // 2. Validate Username
    let isValidUsername = true;
    if (uploadOptions.bindUsername) {
      const usernameRegex = /^[a-zA-Z0-9_-]{4,24}$/;
      if (!usernameRegex.test(uploadOptions.bindUsername)) {
        setUserNameError(true);
        Toast("", "Invalid user name", "error");
        isValidUsername = false;
      } else {
        setUserNameError(false);
      }
    } else {
      setUserNameError(false);
    }

    // 3. Validate Password
    let isValidPassword = true;
    if (uploadOptions.bindPassword) {
      // Regex from old code: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)([a-zA-Z\d^@#$&_-]{8,16}$)/
      const passwordRegex =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)([a-zA-Z\d^@#$&_-]{8,16})$/;

      if (!passwordRegex.test(uploadOptions.bindPassword)) {
        setPasswordError(true);
        Toast("", "Invalid password", "error");
        isValidPassword = false;
      } else {
        setPasswordError(false);
      }
    } else {
      setPasswordError(false);
    }

    if (!isValidUsername || !isValidPassword) {
      setLoading(false);
      return;
    }

    const payload = {
      id: "1",
      connection_url: uploadOptions.url + ":" + uploadOptions.port,
      ca_file_path: uploadOptions.caFilePath,
      user_domain: "," + uploadOptions.domain_name,
      bindUserName: uploadOptions.bindUsername,
      bindPassword: uploadOptions.bindPassword,
      useServiceAccount: isCustomCredsEnabled,
    };

    ConfigurationAxios(SAVE_LDAP_CONFIG, "post", payload).then(({ data }) => {
      setLoading(false);
      if (data.status) {
        Toast("", "Ldap configuration saved successfully", "success");

        // setUploadOptions({
        //   url: "",
        //   port: "",
        //   domain_name: "",
        //   caFilePath: "",
        //   bindUsername: "",
        //   bindPassword: "",
        // });
      } else {
        Toast("", "Error in uploading", "error");
      }
    });
    setShowConfirm(false);
  };

  // Helper to determine if fields are readonly
  const isReadonly = !isModifyMode;

  return (
    <Box>
      <MForm title={"LDAP Configuration"}>
        {/* Toggle Switch for Modify Mode */}

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 2,

            borderRadius: 1,
          }}
        >
          <Typography fontWeight="bold" variant="body2">
            View
          </Typography>

          <CustomSwitch
            checked={isModifyMode}
            onChange={(e) => setIsModifyMode(e.target.checked)}
            label="Modify"
          />
          <Typography fontWeight="bold" variant="body2">
            Modify
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 1,
            width: "100%",
          }}
        >
          {/* URL and Port Row */}
          <Box sx={{ display: "flex", gap: 1 }}>
            <Box
              sx={{ display: "flex", width: "50%", flexDirection: "column" }}
            >
              <Typography variant="subtitle2" color="text.primary">
                URL *
              </Typography>
              <MInput
                value={uploadOptions["url"]}
                onChange={(e) => handleChange(e, "url")}
                error={false}
                disabled={isReadonly}
                placeholder="ldaps://iaf.ldap"
              />
            </Box>
            <Box
              sx={{
                display: "flex",
                width: "50%",
                flexDirection: "column",
                maxWidth: "100px",
              }}
            >
              <Typography variant="subtitle2" color="text.primary">
                Port *
              </Typography>
              <MInput
                type="number"
                value={uploadOptions["port"]}
                onChange={(e) => handleChange(e, "port")}
                onInput={(e) =>
                  (e.target.value = (
                    Math.max(0, parseInt(e.target.value)) || ""
                  )
                    .toString()
                    .slice(0, 5))
                }
                disabled={isReadonly}
                placeholder="636"
              />
            </Box>
          </Box>

          {/* Domain and CA File Row */}
          <Box sx={{ display: "flex", gap: 1 }}>
            <Box
              sx={{ display: "flex", width: "50%", flexDirection: "column" }}
            >
              <Typography variant="subtitle2" color="text.primary">
                Domain Name *
              </Typography>
              <MInput
                value={uploadOptions["domain_name"]}
                onChange={(e) => handleChange(e, "domain_name")}
                disabled={isReadonly}
                placeholder="ou=users,dc=bel,dc=com"
              />
            </Box>
            <Box
              sx={{ display: "flex", width: "50%", flexDirection: "column" }}
            >
              <Typography variant="subtitle2" color="text.primary">
                CA File Path *
              </Typography>
              <MInput
                value={uploadOptions["caFilePath"]}
                onChange={(e) => handleChange(e, "caFilePath")}
                disabled={isReadonly}
                placeholder="/etc/cafiles/cafile.pem"
              />
            </Box>
          </Box>

          {/* Custom Credentials Toggle */}
          <Box>
            <MCheckbox
              label="Custom Credentials for LDAP Bind"
              checked={isCustomCredsEnabled}
              onChange={(e) => setIsCustomCredsEnabled(e.target.checked)}
            />
          </Box>

          {/* Conditional Bind Username and Password */}
          {isCustomCredsEnabled && (
            <Box
              sx={{ display: "flex", gap: 2, justifyContent: "space-between" }}
            >
              <Box
                sx={{ display: "flex", width: "50%", flexDirection: "column" }}
              >
                <Typography variant="subtitle2" color="text.primary">
                  Bind Username
                </Typography>
                <MInput
                  value={uploadOptions["bindUsername"]}
                  onChange={(e) => handleChange(e, "bindUsername")}
                  error={userNameError}
                  helperText={
                    userNameError &&
                    "UserName should be 4-24 alphanumeric characters with no space or special characters, except - and _"
                  }
                  disabled={isReadonly}
                />
              </Box>
              <Box
                sx={{ display: "flex", width: "50%", flexDirection: "column" }}
              >
                <Typography variant="subtitle2" color="text.primary">
                  Bind Password
                </Typography>
                <MInput
                  type="password"
                  value={uploadOptions["bindPassword"]}
                  onChange={(e) => handleChange(e, "bindPassword")}
                  error={passwordError}
                  helperText={
                    passwordError &&
                    "Password should be 8-16 characters with at least one Special Character, Number, Uppercase and Lowercase"
                  }
                  disabled={isReadonly}
                />
              </Box>
            </Box>
          )}
        </Box>

        {/* Submit Button Area */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            mt: 4,
            pt: 2,
          }}
        >
          {isModifyMode && (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 1,
              }}
            >
              <MButtonPrimary
                type="submit"
                disabled={
                  !proceed ||
                  !uploadOptions.domain_name ||
                  !uploadOptions.url ||
                  !uploadOptions.port ||
                  !uploadOptions.caFilePath ||
                  loading ||
                  passwordError ||
                  userNameError
                }
                onClick={() => {
                  // 1. Check if Custom Credentials are enabled
                  if (isCustomCredsEnabled) {
                    if (
                      !uploadOptions.bindUsername ||
                      !uploadOptions.bindPassword
                    ) {
                      setUserNameError(true);
                      setPasswordError(true);
                      Toast(
                        "",
                        "Username and Password are required when custom credentials are enabled.",
                        "error"
                      );
                      setLoading(false);
                      return;
                    }
                  }

                  setShowConfirm(true);
                }}
                startIcon={
                  loading ? (
                    <CircularProgress size={20} sx={{ color: "white" }} />
                  ) : (
                    <Update />
                  )
                }
              >
                {loading ? "Saving..." : "Save"}
              </MButtonPrimary>
            </Box>
          )}
        </Box>
        <MDialog
          open={showConfirm}
          onClose={() => setShowConfirm(false)}
          title={"Confirmation"}
          message={"Are you sure want to save configuration"}
          onConfirm={handleSave}
          icon={confirmIcon}
          mode="child"
          isChildFullScreen={isChildFullScreen}
        />
      </MForm>
    </Box>
  );
};

export default LdapConfiguration;
