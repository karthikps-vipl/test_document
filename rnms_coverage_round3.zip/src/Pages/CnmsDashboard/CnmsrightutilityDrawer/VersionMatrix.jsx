// import React, { useMemo, useEffect } from "react";
// import { useSelector } from "react-redux";
// import { useFormik } from "formik";
// import * as Yup from "yup";
// import dayjs from "dayjs";
// import {
//   Box,
//   Button,
//   Typography,
//   Stack,
//   Divider,
//   IconButton,
// } from "@mui/material";
// import { Close, Search } from "@mui/icons-material";
// import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
// import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
// import MAlarmSelect from "@/components/Dialogs/AlarmSuppression/MAlarmSelect";
// import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";

// const VersionMatrix = ({ onClose }) => {
//   // Redux Selectors
//   const allTerminalTypes = useSelector(
//     (state) => state.nodeDetails.allTerminalTypeDetails || []
//   );
//   const allSites = useSelector(
//     (state) => state.remoteRepDetails.fetchSiteDetails || []
//   );
//   // 3. Validation Schema (Senior Developer Approach)
//   const validationSchema = Yup.object().shape({
//     terminals: Yup.array()
//       .min(1, "At least one terminal must be selected")
//       .required("Required"),
//     sites: Yup.array().when("terminals", {
//       is: (val) => val && val.length > 0,
//       then: (schema) =>
//         schema
//           .min(1, "At least one site must be selected")
//           .required("Required"),
//       otherwise: (schema) => schema.notRequired(),
//     }),
//     fromDate: Yup.date()
//       .required("From date is required")
//       .min(new Date(), "From date cannot be in the past"),
//     toDate: Yup.date()
//       .required("To date is required")
//       .min(Yup.ref("fromDate"), "To date cannot be before From date"),
//   });

//   const formik = useFormik({
//     initialValues: {
//       terminals: [],
//       sites: [],
//       fromDate: dayjs().subtract(1, "day"),
//       toDate: dayjs(),
//     },
//     validationSchema,
//     onSubmit: (values) => {
//       console.log("Fetching data with:", values);
//       // Perform API call here
//     },
//   });

//   const terminalOptions = useMemo(() => {
//     return allTerminalTypes.map((type) => ({
//       label: type.terminalTypeName,
//       value: type.terminalTypeName,
//     }));
//   }, [allTerminalTypes]);

//   const siteOptions = useMemo(() => {
//     const selectedTerminals = formik.values.terminals;
//     if (selectedTerminals.length === 0) return [];

//     const filteredSites = allSites.filter((site) => {
//       const siteTerminalName = site.imTerminalType?.terminalTypeName;
//       return selectedTerminals.includes(siteTerminalName);
//     });

//     return filteredSites.map((site) => ({
//       label: site.siteId,
//       value: site.siteId,
//     }));
//   }, [allSites, formik.values.terminals]);

//   // Reset sites when terminals change to prevent invalid state
//   useEffect(() => {
//     formik.setFieldValue("sites", []);
//   }, [formik.values.terminals]);

//   return (
//     <Box
//       sx={{
//         width: "100%",
//         height: "100%",
//         bgcolor: "white",
//         display: "flex",
//         flexDirection: "column",
//       }}
//     >
//       {/* Adjusted padding to match the clean look */}
//       <Box sx={{ p: 1, flexGrow: 1 }}>
//         <LocalizationProvider dateAdapter={AdapterDayjs}>
//           <form onSubmit={formik.handleSubmit}>
//             <Box
//               sx={{
//                 border: "1px solid #e0e0e0",
//                 borderRadius: "8px",
//                 p: 2, // Increased padding inside the card
//               }}
//             >
//               <Stack spacing={3}>
//                 <Stack direction={{ xs: "column", md: "row", }} spacing={4}>
//                   <Box sx={{ flex: 1, width:'90px'}}>
//                     <MAlarmSelect
//                       label="Terminal"
//                       options={terminalOptions}
//                       value={formik.values.terminals}
//                       onChange={(val) => formik.setFieldValue("terminals", val)}
//                     />
//                     {formik.touched.terminals && formik.errors.terminals && (
//                       <Typography variant="caption" color="error">
//                         {formik.errors.terminals}
//                       </Typography>
//                     )}
//                   </Box>
//                   <Box sx={{ flex: 1,width:'90px' }}>
//                     <MAlarmSelect
//                       label="Remote"
//                       options={siteOptions}
//                       value={formik.values.sites}
//                       onChange={(val) => formik.setFieldValue("sites", val)}
//                     />
//                     {formik.touched.sites && formik.errors.sites && (
//                       <Typography variant="caption" color="error">
//                         {formik.errors.sites}
//                       </Typography>
//                     )}
//                   </Box>
//                 </Stack>

//                 {/* ROW 2: Dates */}
//                 <Stack direction={{ xs: "column", md: "row" }} spacing={4}>
//                   <Box sx={{ flex: 1,width:'90px' }}>
//                     <Typography
//                       sx={{
//                         mb: 1,
//                         fontSize: "14px",
//                         fontWeight: 500,
//                         color: "#333",
//                       }}
//                     >
//                       From Date Time
//                     </Typography>
//                     <DateTimePicker
//                       value={
//                         formik.values.fromDate
//                           ? dayjs(formik.values.fromDate)
//                           : null
//                       }
//                       onChange={(newValue) => {
//                         formik.setFieldValue(
//                           "fromDate",
//                           newValue ? newValue.toISOString() : ""
//                         );
//                       }}
//                       format="DD-MMMM-YYYY HH:mm:ss" // Updated format to match "17-March-2026..."
//                       slotProps={{
//                         textField: {
//                           size: "small",
//                           onBlur: () =>
//                             formik.setFieldTouched("fromDate", true),
//                           error:
//                             formik.touched.fromDate &&
//                             Boolean(formik.errors.fromDate),
//                           fullWidth: true,
//                           sx: {
//                             "& .MuiOutlinedInput-root": { borderRadius: "10px" }, // Sharper corners like the image
//                           },
//                         },
//                       }}
//                       viewRenderers={{
//                         hours: renderTimeViewClock,
//                         minutes: renderTimeViewClock,
//                         seconds: renderTimeViewClock,
//                       }}
//                     />
//                   </Box>
//                   <Box sx={{ flex: 1,width:'90px' }}>
//                     <Typography
//                       sx={{
//                         mb: 1,
//                         fontSize: "14px",
//                         fontWeight: 500,
//                         color: "#333",
//                       }}
//                     >
//                       To Date Time
//                     </Typography>
//                     <DateTimePicker
//                       value={
//                         formik.values.toDate
//                           ? dayjs(formik.values.toDate)
//                           : null
//                       }
//                       onChange={(newValue) => {
//                         formik.setFieldValue(
//                           "toDate",
//                           newValue ? newValue.toISOString() : ""
//                         );
//                       }}
//                       format="DD-MMMM-YYYY HH:mm:ss" // Updated format
//                       slotProps={{
//                         textField: {
//                           size: "small",
//                           onBlur: () => formik.setFieldTouched("toDate", true),
//                           error:
//                             formik.touched.toDate &&
//                             Boolean(formik.errors.toDate),
//                           fullWidth: true,
//                           sx: {
//                             "& .MuiOutlinedInput-root": { borderRadius: "10px" },
//                           },
//                         },
//                       }}
//                       viewRenderers={{
//                         hours: renderTimeViewClock,
//                         minutes: renderTimeViewClock,
//                         seconds: renderTimeViewClock,
//                       }}
//                     />
//                   </Box>
//                 </Stack>

//                 {/* BUTTON ROW: Aligned to the right as per the image */}
//                 <Box
//                   sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}
//                 >
//                   <Button
//                     type="submit"
//                     variant="contained"
//                     disabled={!formik.isValid || formik.isSubmitting}
//                     sx={{
//                       bgcolor: "#003399", // Changed to a deep blue to match the "Fetch" button in image
//                       color: "white",
//                       px: 6,
//                       py: 1,
//                       borderRadius: "20px", // Rounded pill shape from image
//                       textTransform: "none", // Prevents all-caps if preferred
//                       fontSize: "14px",
//                       "&:hover": { bgcolor: "#002673" },
//                     }}
//                   >
//                     Fetch
//                   </Button>
//                 </Box>
//               </Stack>
//             </Box>
//           </form>
//         </LocalizationProvider>
//       </Box>
//     </Box>
//   );
// };

// export default VersionMatrix;

import React, { useMemo, useEffect, useState } from "react"; // 1. Added useState
import { useSelector } from "react-redux";
import { useFormik } from "formik";
import * as Yup from "yup";
import dayjs from "dayjs";
import {
  Box,
  Button,
  Typography,
  Stack,
  CircularProgress, // Added for loading state
} from "@mui/material";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
import MAlarmSelect from "@/components/Dialogs/AlarmSuppression/MAlarmSelect";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { GET_VERSION_DETAILS_BY_DATES } from "@/RestAPI/url/cnmsEndPoint";
import MTable from "@/components/Reusable/Table/MTable";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";

const VersionMatrix = ({ refreshTrigger }) => {
  // State to store API results
  const [versionData, setVersionData] = useState([]);
  const [loading, setLoading] = useState(false);
  // Redux Selectors
  const allTerminalTypes = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails || []
  );
  const allSites = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails || []
  );

  console.log("versionmatrixallSites", allSites);

  const validationSchema = Yup.object().shape({
    terminals: Yup.array()
      .min(1, "At least one terminal must be selected")
      .required("Required"),
    sites: Yup.array().when("terminals", {
      is: (val) => val && val.length > 0,
      then: (schema) =>
        schema
          .min(1, "At least one site must be selected")
          .required("Required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    fromDate: Yup.date().required("From date is required"),
    toDate: Yup.date()
      .required("To date is required")
      .min(Yup.ref("fromDate"), "To date cannot be before From date"),
  });

  const formik = useFormik({
    initialValues: {
      terminals: [],
      sites: [],
      fromDate: dayjs().subtract(1, "day"),
      toDate: dayjs(),
    },
    validationSchema,
    onSubmit: async (values) => {
      setLoading(true);
      // Reset data so the table disappears while loading new data
      setVersionData([]);

      try {
        const payload = {
          siteId: values.sites,
          fromDate: [dayjs(values.fromDate).format("YYYY-MM-DD HH:mm:ss")],
          toDate: [dayjs(values.toDate).format("YYYY-MM-DD HH:mm:ss")],
        };

        const response = await ConfigurationAxios(
          GET_VERSION_DETAILS_BY_DATES,
          "post",
          payload
        );

        // Check if response exists and if the API status is successful (status: 1)
        if (response?.data?.status === 1) {
          // IMPORTANT: Set the array part of the response, not the whole object
          setVersionData(response.data.data || []);
          console.log("API Success:", response.data.data);
        } else {
          console.warn("API returned success: 0 or empty data");
          setVersionData([]);
        }
      } catch (error) {
        console.error("API Error:", error);
        setVersionData([]); // Clear data on error
      } finally {
        setLoading(false);
      }
    },
  });

  // ... (Keep your existing useMemo and useEffect logic)
  const terminalOptions = useMemo(() => {
    return allTerminalTypes.map((type) => ({
      label: type.terminalTypeName,
      value: type.terminalTypeName,
    }));
  }, [allTerminalTypes]);

  const siteOptions = useMemo(() => {
    const selectedTerminals = formik.values.terminals;
    if (selectedTerminals.length === 0) return [];
    const filteredSites = allSites.filter((site) => {
      const siteTerminalName = site.imTerminalType?.terminalTypeName;
      return selectedTerminals.includes(siteTerminalName);
    });
    return filteredSites.map((site) => ({
      label: site.siteId,
      value: site.siteId,
    }));
  }, [allSites, formik.values.terminals]);

  useEffect(() => {
    formik.setFieldValue("sites", []);
  }, [formik.values.terminals]);

  const columns = useMemo(
    () => [
      {
        name: "S.No.",
        uid: "sno",
        width: "80px",
      },
      {
        name: "Site ID",
        uid: "siteId",
        width: "150px",
      },
      {
        name: "Site Name",
        uid: "siteName",
        width: "150px",
      },
      {
        name: "Current Version",
        uid: "currentVersion",
        width: "150px",
      },
      {
        name: "Latest Version",
        uid: "latestVersion",
        width: "150px",
      },
      {
        name: "Date Time",
        uid: "messageTime",
        width: "200px",
      },
      {
        name: "Status",
        uid: "status",
        width: "200px",
      },
    ],
    []
  );

  console.log("versionDataversionData", versionData);

  const tableData = useMemo(() => {
    return versionData?.map((item, index) => {
      let resolvedSiteName = item.siteName;

      if (
        !resolvedSiteName ||
        resolvedSiteName === "null" ||
        resolvedSiteName === ""
      ) {
        const matchedSite = allSites.find(
          (site) => site.siteId === item.siteId
        );
        resolvedSiteName = matchedSite ? matchedSite.siteName : "N/A";
      }
      return {
        ...item,
        sno: index + 1,
        messageTime: item.messageTime
          ? dayjs(item.messageTime).format("DD-MMM-YYYY HH:mm:ss")
          : "",
        currentVersion: item.currentVersion || "--",
        siteName: resolvedSiteName,
      };
    });
  }, [versionData, allSites]);

  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box sx={{ p: 1, flexGrow: 1 }}>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <form onSubmit={formik.handleSubmit}>
            <Box
              sx={{ border: "1px solid #e0e0e0", borderRadius: "8px", p: 2 }}
            >
              <Stack spacing={3}>
                <Stack direction={{ xs: "column", md: "row" }} spacing={4}>
                  <Box sx={{ flex: 1, width: "150px" }}>
                    {" "}
                    {/* Increased width slightly for visibility */}
                    <MAlarmSelect
                      label="Terminal"
                      options={terminalOptions}
                      value={formik.values.terminals}
                      onChange={(val) => formik.setFieldValue("terminals", val)}
                    />
                    {formik.touched.terminals && formik.errors.terminals && (
                      <Typography variant="caption" color="error">
                        {formik.errors.terminals}
                      </Typography>
                    )}
                  </Box>
                  <Box sx={{ flex: 1, width: "150px" }}>
                    <MAlarmSelect
                      label="Remote"
                      options={siteOptions}
                      value={formik.values.sites}
                      onChange={(val) => formik.setFieldValue("sites", val)}
                    />
                    {formik.touched.sites && formik.errors.sites && (
                      <Typography variant="caption" color="error">
                        {formik.errors.sites}
                      </Typography>
                    )}
                  </Box>
                </Stack>

                <Stack direction={{ xs: "column", md: "row" }} spacing={4}>
                  <Box sx={{ flex: 1, width: "200px" }}>
                    <Typography
                      sx={{
                        mb: 1,
                        fontSize: "14px",
                        fontWeight: 500,
                        // color: "#333",
                      }}
                    >
                      From Date Time
                    </Typography>
                    <DateTimePicker
                      value={formik.values.fromDate || null}
                      onChange={(newValue) =>
                        formik.setFieldValue("fromDate", newValue)
                      }
                      format="DD-MMMM-YYYY HH:mm:ss"
                      slotProps={{
                        textField: {
                          size: "small",
                          error:
                            formik.touched.fromDate &&
                            Boolean(formik.errors.fromDate),
                          fullWidth: true,
                          sx: {
                            "& .MuiOutlinedInput-root": {
                              borderRadius: "10px",
                            },
                          },
                        },
                      }}
                      viewRenderers={{
                        hours: renderTimeViewClock,
                        minutes: renderTimeViewClock,
                        seconds: renderTimeViewClock,
                      }}
                    />
                  </Box>
                  <Box sx={{ flex: 1, width: "200px" }}>
                    <Typography
                      sx={{
                        mb: 1,
                        fontSize: "14px",
                        fontWeight: 500,
                      }}
                    >
                      To Date Time
                    </Typography>
                    <DateTimePicker
                      value={formik.values.toDate || null}
                      onChange={(newValue) =>
                        formik.setFieldValue("toDate", newValue)
                      }
                      format="DD-MMMM-YYYY HH:mm:ss"
                      slotProps={{
                        textField: {
                          size: "small",
                          error:
                            formik.touched.toDate &&
                            Boolean(formik.errors.toDate),
                          fullWidth: true,
                          sx: {
                            "& .MuiOutlinedInput-root": {
                              borderRadius: "10px",
                            },
                          },
                        },
                      }}
                      viewRenderers={{
                        hours: renderTimeViewClock,
                        minutes: renderTimeViewClock,
                        seconds: renderTimeViewClock,
                      }}
                    />
                  </Box>
                </Stack>

                <Box
                  sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}
                >
                  <Button
                    type="submit"
                    variant="contained"
                    disabled={!formik.isValid || loading}
                    sx={{
                      bgcolor: "#003399",
                      color: "white",
                      px: 6,
                      py: 1,
                      borderRadius: "20px",
                      textTransform: "none",
                      minWidth: "120px",
                      "&:hover": { bgcolor: "#002673" },
                    }}
                  >
                    {loading ? (
                      <CircularProgress size={24} color="inherit" />
                    ) : (
                      "Fetch"
                    )}
                  </Button>
                </Box>
              </Stack>
            </Box>
          </form>
        </LocalizationProvider>
      </Box>

      {versionData && versionData.length > 0 ? (
        <Box sx={{ width: "100%", p: 2, flexGrow: 1, overflow: "auto" }}>
          <MTable
            tableTitle="Version Matrix"
            columns={columns}
            tableData={tableData}
            showPagination={true}
            showSearch={true}
            refreshTrigger={refreshTrigger}
            handleDownloadPDF={() => {
              // We use the tableData (which contains the transformed names and formatted dates)
              // so the PDF looks exactly like the screen.
              const sanitizedName = "Version_Matrix".replace(/\s+/g, "_");
              const normalName = "Version Matrix";

              exportToPDF(
                `${normalName} Report`, // PDF Title
                columns, // The column definitions
                tableData, // The actual processed data
                `${sanitizedName}_Report`, // Filename
                "NMS User" // User/Author name
              );
            }}
          />
        </Box>
      ) : (
        /* If not loading and no data, show a placeholder or nothing */
        !loading && (
          <Box sx={{ p: 5, textAlign: "center", color: "gray" }}>
            <Typography>
              No data available. Please select filters and click Fetch.
            </Typography>
          </Box>
        )
      )}

      {/* Show a global loading overlay if needed, or just rely on the button spinner */}
      {loading && (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "200px",
          }}
        >
          <CircularProgress />
        </Box>
      )}
    </Box>
  );
};

export default VersionMatrix;
