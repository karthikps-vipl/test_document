
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MInput from "@/components/Reusable/Input/MInput";
import { Box, Typography } from "@mui/material";
import React, { useState, useEffect } from "react";

import { DbAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg"
import MForm from "@/components/Reusable/Form/MForm";
import MSelect from "@/components/Reusable/Select/MSelect";
import { DB_DATA_RESTORE, GET_RESTORE_BACKUP_FILE_LIST } from "@/RestAPI/url/cnmsEndPoint";
 
const CONFIRM_STRING = "CONFIRM";

const CnmsDbStore = ({isChildFullScreen }) => {
    const [resourceId, setResourceId] = useState(null);
    // const [loading, setLoading] = useState(true);
    const [isUpdating, setIsUpdating] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [dbStore, setDbStore] = useState([]);

     const [confirmText, setConfirmText] = useState("");
     const [isRestored, setIsRestored] = useState(false); // To disable the main button

     useEffect(() => {
        let isMounted = true;
        const loadTerminalData = async () => {
            try {
                const terminalResponse = await DbAxios(GET_RESTORE_BACKUP_FILE_LIST, "get");
                if (isMounted && terminalResponse?.data) {
                    const rawData = Array.isArray(terminalResponse.data) ? terminalResponse.data : [];
                    setDbStore(
                        rawData.map((item, index) => {
                            const fileName = typeof item === 'string' ? item : (item.fileName || "Unknown");
                            const id = typeof item === 'string' ? index : item.id;
                            return {
                                label: fileName,
                                value: String(id),
                                raw: item,
                            };
                        })
                    );
                    // setLoading(false);
                }
            } catch (error) {
                if (isMounted) {
                    Toast("Error!", "Error loading terminal details", "error");
                }
            }
        };
        loadTerminalData();
        return () => { isMounted = false; };
    }, []);

    const handleConfirmUpdate = async () => {
        try {
            setIsUpdating(true);
            const selectedFileObj = dbStore.find(item => item.value === String(resourceId));
            const fileNameToUse = selectedFileObj?.raw || selectedFileObj?.label;

            const payload = { fileName: fileNameToUse };
            const response = await DbAxios(DB_DATA_RESTORE, 'post', payload);

            if (response.status === 200 || response.data?.status === 1) {
                setShowConfirm(false);
                setConfirmText(""); // Reset text
                setIsRestored(true);
                Toast("Success!", "Database restored successfully", "success");
            } else {
                Toast("Error!", "Restore failed", "error");
            }
        } catch (error) {
            console.error('Error:', error);
            Toast("Error!", "An error occurred during restoration", "error");
        } finally {
            setIsUpdating(false);
        }
    };
    return (
        <MForm title="About Database Restore">
            <Box sx={{ display: "flex", flexDirection: 'column', gap: 2 }}>
                <Typography variant="h6">NOTE:</Typography>
                <Typography variant="body2">1. Before performing Restore, Switch Off the StandBy Nodewhere Application Server is not Running.</Typography>
                <Typography variant="body2">2. Current database will be dropped and data will be erased.</Typography>
                <Typography variant="body2">3. Database restoration will be done with Selected SQL file.</Typography>
                <Typography variant="body2">4. After Successful restoration, Switch On the stand By Node.</Typography>
                <Typography variant="body2">5. Restart the Active Node for the changes to take into effect.</Typography>
                <Typography variant="body2">6. On completion of Active Node restart, login into the NMS.Application and verify the data.</Typography>
            </Box>

            <Box sx={{ mt: 2, width: "50%" }}>
                <MSelect
                    label="Select Backup File"
                    placeholder="Select SQL File *"
                    options={dbStore}
                    value={resourceId}
                    
                    onChange={(selectedOption) => {
                        setResourceId(selectedOption?.value || null);
                        setIsRestored(false);  
                    }}
                />
            </Box>

            <Box sx={{ mt: 2, display: "flex", justifyContent: "flex-end" }}>
                <MButtonPrimary
                    // 2. Disable button if already restored OR if nothing is selected
                    disabled={!resourceId || isRestored || isUpdating}
                    onClick={() => setShowConfirm(true)}
                >
                    {isRestored ? "Restored" : "Restore"}
                </MButtonPrimary>
            </Box>

            <MDialog
                open={showConfirm}
                 icon={confirmation_icon} 
                title="Confirm Database Restore"
                message="Before performing Database Restore follow the instructions mentioned in the Database Restore Now."
                onConfirm={handleConfirmUpdate}
                onClose={() => {
                    setShowConfirm(false);
                    setConfirmText(""); // Clear text when closing
                }}
                 confirmDisabled={confirmText !== CONFIRM_STRING || isUpdating}
                isSubmitting={isUpdating}
                confirmText="Confirm"
                
                mode="child"
                isChildFullScreen={isChildFullScreen}
            >
                 <Box sx={{ mt: 2,display:"flex" ,gap:2,flexDirection:"column"}}>
                    <Typography sx={{fontSize:"16px",gap:2,fontWeight:"bold",color:"#14348d"}}>
                    Do you want to perform database restore?
                    </Typography>
                    <Typography variant="body2" >
                        Please Type <strong>'{CONFIRM_STRING}'</strong> to proceed
                    </Typography>
                   <Box >
                   <MInput
                        fullWidth
                        size="small"
                        variant="outlined"
                        placeholder="Type CONFIRM here..."
                        value={confirmText}
                        onChange={(e) => setConfirmText(e.target.value)}
                        error={confirmText.length > 0 && confirmText !== CONFIRM_STRING}
                        helperText={confirmText.length > 0 && confirmText !== CONFIRM_STRING ? "Must type CONFIRM" : ""}
                        inputProps={{ maxLength: CONFIRM_STRING.length }}
                        sx={{textAlign:"center"}}
                    />
                   </Box>
                </Box>
            </MDialog>
        </MForm>
    );
};

export default CnmsDbStore;