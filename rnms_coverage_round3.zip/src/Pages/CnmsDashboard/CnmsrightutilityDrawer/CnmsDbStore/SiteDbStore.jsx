import React, { useEffect, useState } from "react";
import { Box, CircularProgress } from "@mui/material";
import { useSelector } from "react-redux";

import MSelect from "@/components/Reusable/Select/MSelect";
import { DbAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_SITE_DB_BACKUP_SQL_FILELIST,
  RESTORE_SITE_DB_BACKUP,
} from "@/RestAPI/url/cnmsEndPoint";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";
import MTable from "@/components/Reusable/Table/MTable";
const SiteDbStore = ({
  isChildFullScreen,
  refreshTrigger,
  privilegeKey,
  onRefresh,
}) => {
  // Redux State
  const allTerminalTypes = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails
  );
  const allSites = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails
  );

  // Local State
  const [siteReStore, setSiteReStore] = useState([]);
  const [terminalType, setTerminalType] = useState(null);
  const [siteId, setSiteId] = useState(null); // This is the Site Object from the dropdown
  const [sites, setSites] = useState([]);

  const [selectedRowId, setSelectedRowId] = useState(null); // Tracks the ID from the table row
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [isRestored, setIsRestored] = useState(false);
  const columns = [
    { name: "S.No", uid: "sno", width: "73px" },
    { name: "File Name", uid: "fileName" },
    { name: "Date and Time", uid: "dateKey" },
  ];

  // 1. Filter sites based on selected terminal
  useEffect(() => {
    if (!terminalType || !Array.isArray(allSites)) {
      setSites([]);
      return;
    }
    const terminalName = terminalType.terminalTypeName;
    const filteredSites = allSites.filter(
      (site) => site.imTerminalType?.terminalTypeName === terminalName
    );
    setSites(filteredSites);
  }, [terminalType, allSites]);

  // 2. Fetch backup files when terminal or site changes
  useEffect(() => {
    const fetchSiteDbBackupFilelist = async () => {
      const tId = terminalType?.terminalId || terminalType?.id;
      const sId = siteId?.siteId;
      if (!tId || !sId) {
        setSiteReStore([]);
        return;
      }
      setLoading(true);
      try {
        const dynamicUrl = `${GET_SITE_DB_BACKUP_SQL_FILELIST}/${tId}/${sId}`;
        const response = await DbAxios(dynamicUrl, "get");
        const rawData = response?.data || [];

        const processedData = rawData.map((fileNameString, index) => {
          const dateMatch = fileNameString.match(/\d{2}-\d{2}-\d{4}/);
          const extractedDate = dateMatch ? dateMatch[0] : "Unknown Date";

          const timeMatch = fileNameString.match(/\d{2}-\d{2}-\d{2}(?=\~)/);
          const extractedTime = timeMatch
            ? timeMatch[0].replace(/-/g, ":")
            : "00:00:00";

          const cleanedFileName = fileNameString.split(".")[0];

          // \u00A0 is a Non-Breaking Space.
          // Adding 5 of them creates a significant, guaranteed gap.
          const gap = "\u00A0\u00A0\u00A0\u00A0\u00A0";

          return {
            id: index + 1,
            sno: index + 1,
            fileName: cleanedFileName,
            dateKey: `${extractedDate}${gap}${extractedTime}`,
          };
        });
        setSiteReStore(processedData);
      } catch (error) {
        console.error("Fetch Error:", error);
        setSiteReStore([]);
      } finally {
        setLoading(false);
      }
    };
    fetchSiteDbBackupFilelist();
  }, [refreshTrigger, terminalType, siteId]);

  const handleTerminalChange = (selectedTerminal) => {
    setTerminalType(selectedTerminal);
    setSiteId(null);
    setSelectedRowId(null); // Reset table selection
  };

  const handleSiteChange = (selectedSite) => {
    if (!selectedSite?.siteId) {
      setSiteId(null);
      setSelectedRowId(null);
      return;
    }
    setSiteId(selectedSite);
    setSelectedRowId(null); // Reset table selection when site changes
  };

  // 3. Table Selection Logic (Single Select)
  const handleRowSelect = (id, isSelected) => {
    if (isSelected) {
      setSelectedRowId(id); // Only allow one
      setIsRestored(false);
    } else if (String(id) === String(selectedRowId)) {
      setSelectedRowId(null);
      setIsRestored(false);
    }
  };

  const handleSelectAll = (isSelected) => {
    if (isSelected && siteReStore.length > 0) {
      setSelectedRowId(siteReStore[0].id);
    } else {
      setSelectedRowId(null);
    }
  };

  // 4. Submit the Restore API
  const handleSubmit = async (event) => {
    if (event) event.preventDefault();

    // 1. Find the specific row object that was selected in the table
    const selectedRowData = siteReStore.find((row) => row.id === selectedRowId);

    // Validation
    if (!selectedRowData) {
      Toast("", "Please select a file from the table first", "error");
      return;
    }
    if (!siteId || !terminalType) {
      Toast("", "Terminal or Site not selected", "error");
      return;
    }

    try {
      setIsSubmitting(true);

      const tId = terminalType.terminalId || terminalType.id;
      const sId = siteId.siteId;

      const fullFileNameWithExtension = `${selectedRowData.fileName}.dump`;

      const dynamicRestoreUrl = `${RESTORE_SITE_DB_BACKUP}/${tId}/${sId}/${fullFileNameWithExtension}`;

      console.log("Requesting Restore at:", dynamicRestoreUrl);

      const res = await DbAxios(dynamicRestoreUrl, "get");

      if (res && (res.status === 200 || res.status === 201)) {
        Toast("", "Database restored successfully", "success");
        setIsRestored(true);
        setOpenDialog(false);
        if (onRefresh) onRefresh();
      } else {
        Toast("", "Failed to restore database", "error");
      }
    } catch (error) {
      console.error("Restore Error:", error);
      Toast(
        "",
        error?.message || "Something went wrong during restore",
        "error"
      );
    } finally {
      setIsSubmitting(false);
    }
  };
  const terminalOptions = (allTerminalTypes || [])
    .filter((t) => t.terminalTypeName !== "CNMS")
    .map((t) => ({
      ...t,
      value: t.terminalTypeName,
      label: t.terminalTypeName,
    }));

  const siteOptions = (sites || []).map((s) => ({
    ...s,
    value: s.siteId,
    label: s.siteId,
  }));

  return (
    <Box
      sx={{
        width: "100%",
        padding: "20px",
        border: "2px solid #eee",
        borderRadius: "10px",
      }}
    >
      {/* Dropdowns */}
      <Box sx={{ display: "flex", gap: "10px", mb: 3 }}>
        <MSelect
          label="Terminal"
          options={terminalOptions}
          value={terminalType}
          getOptionLabel={(opt) => opt.terminalTypeName}
          onChange={handleTerminalChange}
          sx={{ flex: 1 }}
          placeholder={"Select Terminal"}
        />
        <MSelect
          label="Site ID"
          options={siteOptions}
          value={siteId}
          disabled={!terminalType}
          getOptionLabel={(opt) => opt.siteId}
          onChange={handleSiteChange}
          sx={{ flex: 1 }}
          placeholder={"Select Site ID"}
        />
      </Box>

      {/* Table Section */}
      {loading ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          columns={columns}
          tableData={siteReStore}
          showPagination={true}
          enableRowSelection={true}
          // Pass the selected ID as a Set for the MTable component
          selectedRowsNew={
            selectedRowId ? new Set([String(selectedRowId)]) : new Set()
          }
          onRowSelect={handleRowSelect}
          onSelectAll={handleSelectAll}
          rowIdKey="id"
          refreshTrigger={refreshTrigger}
          showSearch={true}
        />
      )}

      {/* Restore Button Section */}
      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 3 }}>
        <MButtonPrimary
          onClick={() => {
            if (!selectedRowId) {
              Toast("", "Please select a file from the table", "error");
            } else {
              setOpenDialog(true);
            }
          }}
          variant="contained"
          disabled={!selectedRowId || isSubmitting || isRestored}
          startIcon={
            isSubmitting ? <CircularProgress size={20} color="inherit" /> : null
          }
        >
          Restore
        </MButtonPrimary>
      </Box>

      {/* Confirmation Dialog */}
      <MDialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        title="Confirm Restore"
        message={`Are you sure you want to restore the database for Site ${
          siteId?.siteId
        } using file: ${
          siteReStore.find((r) => r.id === selectedRowId)?.fileName
        }?`}
        onConfirm={handleSubmit}
        mode="child"
        isChildFullScreen={isChildFullScreen}
        icon={confirmIcon}
        isSubmitting={isSubmitting}
      />
    </Box>
  );
};

export default SiteDbStore;
