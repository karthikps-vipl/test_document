
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { Box, CircularProgress } from "@mui/material";
import React, { useState, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { CHECK_FOR_BACKUP_FILES, CONFIG_NO_OF_BACKUP_FILES, FETCH_DB_CONFIG_DATA } from "@/RestAPI/url/endpoint";
import { DbAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg"
import FormField from "@/components/Reusable/Form/FormField";
import MForm from "@/components/Reusable/Form/MForm";
 
const ConfigBackupFiles = () => {
    const [loading, setLoading] = useState(true);
    const [isUpdating, setIsUpdating] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);

    const [apiData, setApiData] = useState({
        backupcount: '',
    });

    const formik = useFormik({
        enableReinitialize: true,
        validateOnMount: true,

        initialValues: apiData,

        validationSchema: Yup.object({
            backupcount: Yup.number()
                .required("Number of backup files is required")
                .min(30, "Must be at least 30")
                .max(100, "Must be at most 100"),
        }),

        onSubmit: () => {
            setShowConfirm(true);
        },
    });

    useEffect(() => {
        fetchInitialData();
    }, []);

    const fetchInitialData = async () => {
        try {
            setLoading(true);

            const response = await DbAxios(
                FETCH_DB_CONFIG_DATA,
                'get'
            );

            if (response.data) {
                const noOfBackupfilesCount =
                    response.data.noOfBackupfiles;

                setApiData({
                    backupcount:
                        noOfBackupfilesCount !== null &&
                            noOfBackupfilesCount !== undefined
                            ? noOfBackupfilesCount.toString()
                            : '',
                });
            }
        } catch (error) {
            console.error(
                "Error fetching config data:",
                error
            );
        } finally {
            setLoading(false);
        }
    };

    const handleBackupCountChange = (e) => {
        const value = e.target.value;

        // Allow only numbers
        if (value === '' || /^[0-9]+$/.test(value)) {
            formik.handleChange(e);
        }
    };
    // const handleConfirmUpdate = async () => {
    //     try {
    //         setIsUpdating(true);

    //         // Force Axios to send application/json even for primitive payloads (like numbers)
    //         axios.defaults.headers.post['Content-Type'] = 'application/json';

    //         const backupCountValue = Number(formik.values.backupcount);

    //         // 1. Prepare the payloads as raw numbers to match your backend `@RequestBody Integer`
    //         const payload1 = backupCountValue;
    //         const payload = {
    //                         noOfBackupfiles: Number(
    //                             formik.values.backupcount)
    //                     }
    //         const validationResponse = await DbAxios(
    //             CHECK_FOR_BACKUP_FILES,
    //             'post',
    //             payload1
    //         );

    //         // Since your backend returns a boolean (true/false) directly:
    //         if (!validationResponse.data) {
    //             Toast("Error!", "Invalid backup count range (Must be 30-100)", "error");
    //             setIsUpdating(false);
    //             return; // Stop execution here
    //         }

    //         // 3. Proceed to update settings if validation passed
    //         const response = await DbAxios(
    //             CONFIG_NO_OF_BACKUP_FILES,
    //             'post',
    //             payload
    //         );

    //         if (
    //             response.data?.status === 1 ||
    //             response.status === 200 ||
    //             response.data === true
    //         ) {
    //             setShowConfirm(false);

    //             Toast(
    //                 "Success!",
    //                 "Backup Settings updated successfully",
    //                 "success"
    //             );

    //             // Update local state with the new value
    //             setApiData({
    //                 backupcount: formik.values.backupcount,
    //             });
    //         } else {
    //             Toast(
    //                 "Error!",
    //                 response.data?.message || "Failed to update settings",
    //                 "error"
    //             );
    //         }
    //     } catch (error) {
    //         console.error("Error updating settings:", error);
    //         Toast("Error!", "Failed to update Backup Settings", "error");
    //     } finally {
    //         setIsUpdating(false);
    //     }
    // };

    const handleConfirmUpdate = async () => {
        try {
            setIsUpdating(true);
    
            // Get the value from formik
            const backupCountValue = formik.values.backupcount;
    
            // 1. Call the validation API using GET with the value in the URL
            // This will result in: CHECK_FOR_BACKUP_FILES/30 (if user entered 30)
            const validationUrl = `${CHECK_FOR_BACKUP_FILES}/${backupCountValue}`;
    
            const validationResponse = await DbAxios(
                validationUrl,
                'get' // Changed to 'get'
            );
    
            // Based on your code: if validationResponse.data is false, stop execution
            if (!validationResponse.data) {
                Toast("Error!", "Invalid backup count range or criteria not met", "error");
                setIsUpdating(false);
                return; 
            }
    
            // 2. Proceed to update settings if validation passed
            // Note: Keep this as 'post' if your update API still expects a JSON body
            const payload = {
                noOfBackupfiles: Number(backupCountValue)
            };
    
            const response = await DbAxios(
                CONFIG_NO_OF_BACKUP_FILES,
                'post',
                payload
            );
    
            if (
                response.data?.status === 1 ||
                response.status === 200 ||
                response.data === true
            ) {
                setShowConfirm(false);
    
                Toast(
                    "Success!",
                    "Config Backup Settings updated successfully",
                    "success"
                );
    
                // Update local state with the new value
                setApiData({
                    backupcount: backupCountValue.toString(),
                });
            } else {
                Toast(
                    "Error!",
                    response.data?.message || "Failed to update settings",
                    "error"
                );
            }
        } catch (error) {
            console.error("Error updating settings:", error);
            Toast("Error!", "Failed to update Backup Settings", "error");
        } finally {
            setIsUpdating(false);
        }
    };

    if (loading) {
        return (
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    py: 4,
                }}
            >
                <CircularProgress
                    size={30}
                    style={{ color: "#14348D" }}
                />
            </Box>
        );
    }

    return (
        <MForm title="Config. Of Backup Files">

            <Box className="grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-4 items-end">

                <Box>
                    <FormField
                        label="Number of Backup Files to be Retained *"
                        name="backupcount"
                        size="small"
                        fullWidth
                        placeholder="Must be between 30 - 100"

                        value={
                            formik.values.backupcount
                        }

                        /*
                         * IMPORTANT:
                         *
                         * We use dirty here instead of touched.
                         *
                         * API value = 45
                         * dirty = false
                         * => no error shown
                         *
                         * User changes 45 -> 20
                         * dirty = true
                         * validation error exists
                         * => error shown immediately
                         */
                        error={
                            formik.dirty &&
                            Boolean(
                                formik.errors.backupcount
                            )
                        }

                        errorMessage={
                            formik.dirty &&
                                formik.errors.backupcount
                                ? formik.errors.backupcount
                                : ""
                        }

                        onChange={
                            handleBackupCountChange
                        }

                        onBlur={
                            formik.handleBlur
                        }
                    />
                </Box>

            </Box>

            <Box sx={{ mt: 3 }}>
                <MButtonPrimary
                    disabled={
                        !formik.isValid ||
                        !formik.dirty ||
                        isUpdating
                    }
                    onClick={
                        formik.handleSubmit
                    }
                    sx={{
                        width: {
                            xs: '100%',
                            md: 'auto',
                        },
                    }}
                >
                    {
                        isUpdating
                            ? "Updating..."
                            : "Update"
                    }
                </MButtonPrimary>
            </Box>

            <MDialog
                open={showConfirm}
                variant="info"
                icon={confirmation_icon}
                title="Confirm Action"
                message="Are you sure you want to update the Backup Settings?"
                onConfirm={
                    handleConfirmUpdate
                }
                onClose={() =>
                    setShowConfirm(false)
                }
                mode="child"
            />

        </MForm>
    );
};

export default ConfigBackupFiles;


