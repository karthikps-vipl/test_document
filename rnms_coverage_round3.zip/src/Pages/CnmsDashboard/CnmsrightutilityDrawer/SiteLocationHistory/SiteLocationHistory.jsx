import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MForm from "@/components/Reusable/Form/MForm";
import MSelect from "@/components/Reusable/Select/MSelect";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { SITE_LOCATION_UPDATE_LOG } from "@/RestAPI/url/cnmsEndPoint";
import { Box } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import LocationHistoryMap from "./LocationHistoryMap";
import MTable from "@/components/Reusable/Table/MTable";
import { convertSeconds, formatDateTime } from "@/lib/utils";
import Toast from "@/components/Reusable/Toast/Toast";

const logOptions = [
  { label: "5 Logs", value: 5 },
  { label: "10 Logs", value: 10 },
  { label: "15 Logs", value: 15 },
  { label: "20 Logs", value: 20 },
];

const colums = [
  {
    name: "S.No",
    uid: "serial",
    width: "50px",
  },
  {
    name: "Site Name",
    uid: "siteName",
  },
  {
    name: "Latitude",
    uid: "lattitude",
  },
  {
    name: "Longitude",
    uid: "longitude",
  },
  {
    name: "Start Date",
    uid: "startDateTime",
  },
  {
    name: "End Date",
    uid: "endDateTime",
  },
  {
    name: "Duration (day:hr:min:sec)",
    uid: "durationInHours",
  },
];

const SiteLocationHistory = () => {
  const [sites, setSites] = useState([]);
  const [terminalType, setTerminalType] = useState(null);
  const [siteId, setSiteId] = useState(null);
  const [logsCount, setLogsCount] = useState(0);
  const [finalTransformedData, setFinalTransformedData] = useState([]);

  const allTerminalTypes = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails
  );

  const allSites = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails
  );

  useEffect(() => {
    if (!terminalType || !Array.isArray(allSites)) {
      setSites([]);
      return;
    }

    const terminalName = terminalType.terminalTypeName;

    const filteredSites = allSites.filter(
      (site) => site.imTerminalType?.terminalTypeName === terminalName
    );

    setSites(filteredSites);
  }, [terminalType, allSites]);

  const terminalOptions = (allTerminalTypes || [])
    .filter(
      (terminal) =>
        terminal.terminalTypeName !== "CNMS" &&
        terminal.terminalTypeName !== "HUB-NMS"
    )
    .map((terminal) => ({
      ...terminal,

      value: terminal.terminalTypeName,
      label: terminal.terminalTypeName,
    }));

  const siteOptions = (sites || []).map((site) => ({
    ...site,
    value: site.siteId,
    label: site.siteId,
  }));

  const handleTerminalChange = (selectedTerminal) => {
    setTerminalType(selectedTerminal);

    setSiteId(null);
  };

  const handleSiteChange = async (selectedSite) => {
    setSiteId(selectedSite?.siteId);
  };

  const handleLogsCountChange = (count) => {
    setLogsCount(count.value);
  };

  const handleView = async () => {
    const payload = {
      count: logsCount,
      siteId: siteId,
    };
    try {
      const response = await InventoryAxios(
        SITE_LOCATION_UPDATE_LOG,
        "post",
        payload
      );

      const rawData = response.data;

      if (rawData.length <= 0) {
        Toast("", `No logs found for ${siteId}`, "error");
        return;
      }

      const transformedData = rawData.map((e, i) => {
        return { ...e, serial: i + 1 };
      });

      // SORT THE DATA BY START TIME
      const sortedData = transformedData.sort((a, b) => {
        return new Date(a.startDateTime) - new Date(b.startDateTime);
      });

      // Re-assign serial numbers after sorting (Optional, but good for table display)
      const finalData = sortedData.map((item, index) => ({
        ...item,
        serial: index + 1,
        lattitude: item.lattitude,
        longitude: item.longitude,
        siteName: item.siteName || "Unknown",
        startDateTime: formatDateTime(item.startDateTime),
        endDateTime: formatDateTime(item.endDateTime),
        durationInHours: item.durationInHours
          ? convertSeconds(item.durationInHours * 3600)
          : "NA",
      }));

      setFinalTransformedData(finalData);
    } catch (error) {
      console.log("SITE_LOCATION_UPDATE_LOG error", error);
      Toast("", "Error getting logs", "error");
    }
  };

  return (
    <Box>
      <MForm title={"Site Location History"} paddingX={1}>
        <Box
          sx={{
            display: "flex",
            gap: "10px",
            width: "100%",
            justifyContent: "space-between",
            alignItems: "end",
          }}
        >
          <MSelect
            label="Terminal"
            placeholder="Select Terminal"
            options={terminalOptions}
            value={terminalType}
            getOptionLabel={(option) => option.terminalTypeName}
            getOptionValue={(option) => option.terminalTypeName}
            onChange={handleTerminalChange}
          />

          <MSelect
            label="Site ID"
            placeholder={
              terminalType ? "Select Site ID" : "Select Terminal first"
            }
            options={siteOptions}
            value={siteId}
            disabled={!terminalType}
            getOptionLabel={(option) =>
              option.siteId + " (" + option.siteName + ")"
            }
            getOptionValue={(option) => option.siteId}
            onChange={handleSiteChange}
          />

          <MSelect
            label="Recent logs"
            options={logOptions}
            onChange={handleLogsCountChange}
            value={logsCount}
            placeholder="Recent logs"
          />

          <Box>
            <MButtonPrimary
              onClick={() => handleView()}
              disabled={
                siteId === null || logsCount === 0 || terminalType === null
              }
            >
              VIEW
            </MButtonPrimary>
          </Box>
        </Box>
      </MForm>

      {finalTransformedData.length > 0 && (
        <MForm
          title={`Location History of Vehicle - ${finalTransformedData[0]?.siteId} (${finalTransformedData[0]?.siteName})`}
          paddingX={1}
        >
          <Box
            sx={{
              display: "flex",
              gap: "10px",
            }}
          >
            <Box sx={{ width: "45%", height: "58vh" }}>
              <LocationHistoryMap finalTransformedData={finalTransformedData} />
            </Box>

            <Box sx={{ display: "flex", width: "55%" ,height:'100%'}}>
              <MTable
                columns={colums}
                tableData={finalTransformedData}
                showPagination={true}
              />
            </Box>
          </Box>
        </MForm>
      )}
    </Box>
  );
};

export default SiteLocationHistory;
