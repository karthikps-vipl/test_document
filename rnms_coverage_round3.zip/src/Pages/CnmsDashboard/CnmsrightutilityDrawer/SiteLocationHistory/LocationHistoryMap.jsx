import { GEO_SERVER_MAP_VIEW_URL } from "@/RestAPI/url/baseUrl";
import React, { useEffect, useState } from "react";
import {
  MapContainer,
  Marker,
  Polyline,
  TileLayer,
  WMSTileLayer,
} from "react-leaflet";
import { LiveCordinates } from "../../CnmsMap/components/LiveCoordinates";
import L from "leaflet";

const LocationHistoryMap = ({ finalTransformedData }) => {
  const [positionsArr, setPositionsArr] = useState([]);

  useEffect(() => {
    const arr = [];
    finalTransformedData?.forEach((e) => {
      arr.push([e.lattitude, e.longitude]);
    });
    setPositionsArr(arr);
  }, [finalTransformedData]);

  const customIcon = (slno) => {
    const numberToDisplay = slno < 10 ? `0${slno}` : slno;
    return L.divIcon({
      html: `<span class="site-hist-marker" >${numberToDisplay}</span>`,
    });
  };

  return (
    // <Box>
    <MapContainer
      preferCanvas={true}
      // center={[20.5937, 78.9029]}
      center={[
        finalTransformedData[0]?.lattitude,
        finalTransformedData[0]?.longitude,
      ]}
      zoom={7} //default zoom level
      maxZoom={15}
      minZoom={4}
      style={{ width: "100%", height: "100%", border: "1px solid" }}
      attributionControl={false}
    >
      <TileLayer url={GEO_SERVER_MAP_VIEW_URL} ed={10} />
      <WMSTileLayer // WMS layer to get India map from geoserver; all parameters are attached in url
        url={GEO_SERVER_MAP_VIEW_URL}
        version={"1.1.1"} // WMS Version
        format="image/png"
        transparent={true}
        layers={"MCT_LSV_GIS:MCT_LSV_Map"} //layer name from geoserver
        tiled={true}
        srs={window.L.CRS.EPSG4326.code}
        uppercase={true}
      />

      <LiveCordinates />

      {/* 1. Render CNMS Markers */}
      {finalTransformedData?.map((item) => (
        <Marker
          key={item.serial}
          position={[item.lattitude, item.longitude]}
          icon={customIcon(item.serial)}
        />
      ))}

      <Polyline pathOptions={{ color: "green" }} positions={positionsArr} />
    </MapContainer>
    // </Box>
  );
};

export default LocationHistoryMap;
