import React, { useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { Box, Grid, CircularProgress } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { UPDATE_SITE_ACTIVE_MODE_COMMUNICATION } from "@/RestAPI/url/cnmsEndPoint";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { Update } from "@mui/icons-material";
import Toast from "@/components/Reusable/Toast/Toast";
import { useSiteDetails } from "./utils";

const UpdateSiteActiveMode = () => {
  const allTerminalTypes = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails || []
  );

  // Filter out any terminals where terminalTypeName is "CNMS"
  const filteredTerminalTypes = useMemo(() => {
    return allTerminalTypes.filter(
      (terminal) => terminal.terminalTypeName !== "CNMS"
    );
  }, [allTerminalTypes]);

  const allSitesData = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails || []
  );
  const [loading, setLoading] = useState(false);

  const validationSchema = Yup.object().shape({
    terminalId: Yup.number().required("Please select a Terminal"),
    siteId: Yup.string().required("Please select a Site ID"),
    commMode: Yup.string().required("Please select Communication Mode"),
  });

  const { refreshSiteDetails } = useSiteDetails();

  const formik = useFormik({
    initialValues: {
      terminalId: null,
      siteId: null,
      commMode: "",
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      try {
        setLoading(true);
        const payload = {
          siteId: values.siteId,
          activeModeOfCommunication: parseInt(values.commMode, 10),
        };
        const response = await InventoryAxios(
          UPDATE_SITE_ACTIVE_MODE_COMMUNICATION,
          "post",
          payload
        );
        console.log("hdvbhfactive", response);
        if (response?.data === true) {
          await refreshSiteDetails();
        }

        Toast("Success!", "Updtaed successfully", "success");
        formik.resetForm();
      } catch (error) {
        console.error("Update Error:", error);
        Toast("Error!", error || "Operation failed", "error");
      } finally {
        setLoading(false);
      }
    },
  });

  const siteOptions = useMemo(() => {
    if (!formik.values.terminalId) return [];
    const selectedTerminalObj = filteredTerminalTypes.find(
      (t) => t.id === formik.values.terminalId
    );
    if (!selectedTerminalObj) return [];
    const targetTypeName = selectedTerminalObj.terminalTypeName;

    const filteredSites = allSitesData.reduce((acc, site) => {
      if (site.imTerminalType?.terminalTypeName === targetTypeName) {
        acc.push({ label: site.siteId, value: site.siteId });
        site.groupList?.forEach((group) => {
          group.sites?.forEach((nestedSite) => {
            if (nestedSite.siteId) {
              acc.push({ label: nestedSite.siteId, value: nestedSite.siteId });
            }
          });
        });
      }
      return acc;
    }, []);
    return Array.from(
      new Map(filteredSites.map((item) => [item.value, item])).values()
    );
  }, [formik.values.terminalId, allSitesData, filteredTerminalTypes]);

  const communicationModes = [
    { label: "VSAT", value: "1" },
    { label: "LOS", value: "2" },
    { label: "E1-OFC", value: "3" },
  ];

  useEffect(() => {
    formik.setFieldValue("siteId", null);
    formik.setFieldValue("commMode", "");
  }, [formik.values.terminalId]);

  // --- LOGIC TO ENABLE/DISABLE BUTTON ---
  // Button is disabled if loading OR if any required field is missing
  const isButtonDisabled =
    loading ||
    !formik.values.terminalId ||
    !formik.values.siteId ||
    !formik.values.commMode;

  return (
    <Box
      sx={{
        border: "1px solid #e0e0e0",
        borderRadius: "8px",
        p: 3,
      }}
    >
      {/* We keep the form tag, but since MButtonPrimary doesn't support type="submit", 
          we handle the click manually via formik.handleSubmit */}
      <form onSubmit={(e) => e.preventDefault()}>
        <Grid>
          <Grid item xs={12} sx={{ mb: 2 }}>
            <MSelect
              label="Terminal *"
              name="terminalId"
              options={filteredTerminalTypes}
              value={formik.values.terminalId}
              onChange={(val) => formik.setFieldValue("terminalId", val?.id)}
              placeholder="Select a Terminal"
              getOptionLabel={(opt) => opt.terminalTypeName || ""}
              getOptionValue={(opt) => opt.id}
              error={
                formik.touched.terminalId && Boolean(formik.errors.terminalId)
              }
              helperText={formik.touched.terminalId && formik.errors.terminalId}
            />
          </Grid>

          <Grid item xs={12} sx={{ mb: 2 }}>
            <MSelect
              label="Site ID *"
              name="siteId"
              options={siteOptions}
              value={formik.values.siteId}
              onChange={(val) => formik.setFieldValue("siteId", val?.value)}
              placeholder="Select a Site"
              getOptionLabel={(opt) => opt.label || ""}
              getOptionValue={(opt) => opt.value || ""}
              disabled={!formik.values.terminalId}
              error={formik.touched.siteId && Boolean(formik.errors.siteId)}
              helperText={formik.touched.siteId && formik.errors.siteId}
            />
          </Grid>

          <Grid item xs={12} sx={{ mb: 2 }}>
            <MSelect
              label="Active Mode of Communication *"
              name="commMode"
              options={communicationModes}
              value={formik.values.commMode}
              onChange={(val) => formik.setFieldValue("commMode", val?.value)}
              placeholder="Select Mode"
              getOptionLabel={(opt) => opt.label}
              getOptionValue={(opt) => opt.value}
              error={formik.touched.commMode && Boolean(formik.errors.commMode)}
              helperText={formik.touched.commMode && formik.errors.commMode}
            />
          </Grid>

          <Grid
            item
            xs={12}
            sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}
          >
            <MButtonPrimary
              // 1. Manual trigger for Formik since MButtonPrimary doesn't support type="submit"
              onClick={formik.handleSubmit}
              variant="contained"
              // 2. Disable logic: Only enabled when all fields are selected and not loading
              disabled={isButtonDisabled}
              startIcon={
                loading ? (
                  <CircularProgress size={20} color="inherit" />
                ) : (
                  <Update />
                )
              }
              sx={{
                bgcolor: "#1a237e",
                "&:hover": { bgcolor: "#000" },
                flex: 1,
              }}
            >
              {loading ? "Updating..." : "Update"}
            </MButtonPrimary>
          </Grid>
        </Grid>
      </form>
    </Box>
  );
};

export default UpdateSiteActiveMode;
