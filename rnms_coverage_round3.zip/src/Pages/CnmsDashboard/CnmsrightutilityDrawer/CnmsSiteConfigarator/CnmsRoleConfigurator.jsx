import React, { useEffect, useState } from "react";
import { Box, CircularProgress } from "@mui/material";
import MTable from "@/components/Reusable/Table/MTable";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import moment from "moment";
import {
  DELETE_ROLE_CONFIGURATION,
  ROLE_ASSIGNMENT_SITE,
} from "@/RestAPI/url/cnmsEndPoint";
import MDialog from "@/components/Reusable/Dialog/MDialog"; 
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useSiteDetails } from "./utils";

const CnmsRoleConfigurator = ({ privilegeKey, handleAdd, refreshTrigger,isGrandchildFullScreen }) => {
  const [roleData, setRoleData] = useState([]);
  const [loading, setLoading] = useState(true);

  const { refreshSiteDetails } = useSiteDetails();

  // Delete States
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deleteRow, setDeleteRow] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Fetch Data
  const fetchData = async () => {
    setLoading(true);
    try {
      const { data } = await InventoryAxios(ROLE_ASSIGNMENT_SITE, "get", 1);
      const processedData = data.map((item, index) => ({
        ...item,
        sno: index + 1,
        activeDuration: getActiveSinceDuration(item.activesince),
      }));
      setRoleData(processedData);
    } catch (error) {
      console.error("Error fetching role assignments:", error);
      Toast("Error", "Failed to fetch role assignments", "error");
      setRoleData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [refreshTrigger]);

  // Delete Logic
  const handleDeleteClick = (row) => {
    setDeleteRow(row);
    setIsDeleteOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deleteRow) return;
    console.log("deleteRowrole", deleteRow);

    setIsDeleting(true);
    try {
      const response = await InventoryAxios(
        `${DELETE_ROLE_CONFIGURATION}/${deleteRow.localSite}`,
        "post"
      );

      if (response?.data === true) {
        await refreshSiteDetails();
      }

      Toast("Success", "Role Configuration deleted successfully", "success");
      setIsDeleteOpen(false);
      setDeleteRow(null);
      fetchData(); // Refresh table
    } catch (error) {
      console.error("Delete error:", error);
      Toast("Error", "Failed to delete configuration", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  // Helper: Duration Calculation
  const getActiveSinceDuration = (timestamp) => {
    if (!timestamp) return "NA";
    try {
      const now = moment();
      const end = moment(timestamp, "DD-MM-YYYY HH:mm:ss");
      if (!end.isValid()) return "Invalid Date";
      const duration = moment.duration(now.diff(end));
      const months = Math.floor(duration.asMonths());
      const parts = [];
      if (months > 0) parts.push(`${months} months`);
      if (duration.days() > 0) parts.push(`${duration.days()} days`);
      if (duration.hours() > 0) parts.push(`${duration.hours()} hours`);
      if (parts.length === 0) parts.push(`${duration.seconds()} seconds`);
      return parts.join(" ");
    } catch (error) {
      return "NA";
    }
  };

  const columns = [
    { name: "S.No.", uid: "sno", width: "60px" },
    { name: "Local Site", uid: "localSite", width: "150px" },
    { name: "Repeater 1 Site", uid: "repeator1Site", width: "150px" },
    { name: "Repeater 2 Site", uid: "repeator2Site", width: "150px" },
    { name: "Remote Site", uid: "remoteSite", width: "150px" },
    { name: "Time Stamp", uid: "activesince", width: "180px" },
    { name: "Active Since", uid: "activeDuration", width: "260px" },
    {
      name: "Actions",
      uid: "actions",
      sortable: false,
      cellClassName: "sticky-actions",
      headerClassName: "sticky-actions",
      width: "100px",
    },
  ];

  return (
    <Box sx={{ width: "100%", p: 2 }}>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", mt: 10 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <MTable
            privilegeKey={privilegeKey}
            columns={columns}
            tableData={roleData}
            showPagination={true}
            showSearch={true}
            hideAdd={false}
            AddText="ADD ROLE"
            handleAdd={() =>
              handleAdd?.({ mode: "CREATE", title: "Assign Role" })
            }
            handleDelete={handleDeleteClick}
            refreshTrigger={refreshTrigger}
          />

          {/* Confirmation Dialog */}
          {isDeleteOpen && (
            <MDialog
              open={isDeleteOpen}
              onClose={() => {
                setIsDeleteOpen(false);
                setDeleteRow(null);
              }}
              onConfirm={handleConfirmDelete}
              title="Delete Configuration"
              message={
                <>
                  Are you sure you want to delete the role configuration for{" "}
                  <strong>{deleteRow?.localSite}</strong>?
                  <br />
                  This action cannot be undone.
                </>
              }
              confirmText={isDeleting ? "Deleting..." : "Delete"}
              cancelText="Cancel"
              variant="error"
              icon={Delete_Icon_}
              mode="child"
              isGrandchildFullScreen={isGrandchildFullScreen}
            />
          )}
        </>
      )}
    </Box>
  );
};

export default CnmsRoleConfigurator;
