import React from "react";
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Typography,
  CircularProgress,
} from "@mui/material";

import MDialog from "@/components/Reusable/Dialog/MDialog";

const CnmsDiscoveryProgressOverlay = ({
  isOpen,
  activeStep,
  loading,
  message,
}) => {
  const steps = ["Start", "Fetching Active IPs", "Site Discovery", "Complete"];

  const brandBlue = "#14348D";

  return (
    <MDialog
      open={isOpen}
      showButtons={false}
      title=""
      message=""
      mode="child"
      glass={true}
      PaperProps={{
        style: {
          backgroundColor: "transparent",
          backdropFilter: "blur(20px)",
          boxShadow: "0 8px 32px 0 rgba(20, 52, 141, 0.15)",
          borderRadius: "16px",
          padding: "32px",
          maxWidth: "850px",
          width: "100%",
        },
      }}
      sx={{
        "& .MuiBackdrop-root": {
          backgroundColor: "rgba(0, 0, 0, 0.25)",
          backdropFilter: "blur(0.5px)",
        },
      }}
    >
      <Box>
        <Stepper
          activeStep={activeStep}
          alternativeLabel
          sx={{
            "& .MuiStepIcon-root.Mui-active": {
              color: brandBlue,
            },

            "& .MuiStepIcon-root.Mui-completed": {
              color: brandBlue,
            },

            "& .MuiStepConnector-root .MuiStepConnector-line": {
              borderTopColor: brandBlue,
              borderTopWidth: "2px",
            },

            "& .MuiStepLabel-label.Mui-active": {
              color: brandBlue,
              fontWeight: "bold",
            },

            "& .MuiStepLabel-label.Mui-completed": {
              color: brandBlue,
            },
          }}
        >
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel
                optional={
                  loading && activeStep === index ? (
                    <Typography
                      variant="caption"
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: 0.5,
                        mt: 0.5,
                        color: brandBlue,
                      }}
                    >
                      Processing
                      <CircularProgress size={8} sx={{ color: brandBlue }} />
                    </Typography>
                  ) : null
                }
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>

        {message && (
          <Typography
            sx={{
              mt: 3,
              textAlign: "center",
              color: brandBlue,
              fontWeight: 500,
            }}
          >
            {message}
          </Typography>
        )}
      </Box>
    </MDialog>
  );
};

export default CnmsDiscoveryProgressOverlay;
