import React, { useEffect, useState, useMemo } from "react";
import {
    Box,
    Typography,
    CircularProgress,
    FormControlLabel,
    Checkbox,
} from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { Update } from "@mui/icons-material";
import { useFormik } from "formik";
import Toast from "@/components/Reusable/Toast/Toast";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import confirmation_icon from "@/assets/SVGIcons/Alert.svg";
import {
    GET_SITE_DEFAULT_POLLING_INTERVAL,
    UPDATE_SITE_DEFAULT_POLLING_INTERVAL,
} from "@/RestAPI/url/endpoint";
import MForm from "@/components/Reusable/Form/MForm";
import * as Yup from "yup";
 

const MIN_POLLING_INTERVAL = 5;
const MAX_POLLING_INTERVAL = 60;

const RnmsPollingInterval = ({isChildFullScreen}) => {
  // const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [apiConstraints, setApiConstraints] = useState({
    min: MIN_POLLING_INTERVAL,
    max: MAX_POLLING_INTERVAL,
    defaultVal: 10,
  });

  const [initialData, setInitialData] = useState({
    pollingInterval: "",
    isDefault: false,
  });

  const validationSchema = useMemo(
    () =>
      Yup.object({
        pollingInterval: Yup.number()
          .transform((value, originalValue) => {
            if (
              originalValue === "" ||
              originalValue === null ||
              originalValue === undefined
            ) {
              return undefined;
            }

            return value;
          })
          .typeError("Please enter a valid whole number")
          .integer("Please enter a valid whole number")
          .min(
            apiConstraints.min,
            `Value must be at least ${apiConstraints.min} minutes`
          )
          .max(
            apiConstraints.max,
            `Value must not exceed ${apiConstraints.max} minutes`
          )
          .required("Interval is required"),
      }),
    [apiConstraints]
  );

  const getData = async () => {
    try {
      // setLoading(true);

      const res = await FaultAxios(GET_SITE_DEFAULT_POLLING_INTERVAL, "get");

      if (res?.data) {
        const {
          pollingInterval,
          defaultInterval,
          minPollingInterval,
          maxPollingInterval,
        } = res.data;

        const safeMin =
          minPollingInterval !== undefined &&
          minPollingInterval !== null
            ? Number(minPollingInterval)
            : MIN_POLLING_INTERVAL;

        const safeMax =
          maxPollingInterval !== undefined &&
          maxPollingInterval !== null
            ? Number(maxPollingInterval)
            : MAX_POLLING_INTERVAL;

        const safeDefault =
          defaultInterval !== undefined &&
          defaultInterval !== null
            ? Number(defaultInterval)
            : 10;

        const currentValue =
          pollingInterval !== undefined &&
          pollingInterval !== null
            ? String(pollingInterval)
            : "";

        setApiConstraints({
          min: safeMin,
          max: safeMax,
          defaultVal: safeDefault,
        });

        setInitialData({
          pollingInterval: currentValue,
          isDefault: currentValue === String(safeDefault),
        });
      }
    } catch (err) {
      console.error("Failed to fetch polling config", err);
      Toast("Error", "Failed to fetch configuration", "error");
    } finally {
      // setLoading(false);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const formik = useFormik({
    initialValues: initialData,
    enableReinitialize: true,
    validationSchema,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: async (values, { setSubmitting }) => {
      try {
        if (values.isDefault) {
          setShowConfirm(true);
          return;
        }

        await handleConfirmUpdate(values);
      } finally {
        setSubmitting(false);
      }
    },
  });

  const handlePollingIntervalChange = (event) => {
    const value = event.target.value;

    if (!/^\d{0,2}$/.test(value)) {
      return;
    }

    formik.setFieldValue("pollingInterval", value);
    formik.setFieldTouched("pollingInterval", true, false);
  };

  const handleCheckboxChange = (event) => {
    const checked = event.target.checked;

    formik.setFieldValue("isDefault", checked);

    if (checked) {
      formik.setFieldValue(
        "pollingInterval",
        String(apiConstraints.defaultVal)
      );
    }
  };

  const handleConfirmUpdate = async (values) => {
    try {
      setIsSaving(true);

      const payload = {
        pollingInterval: Number(values.pollingInterval),
      };

      const res = await FaultAxios(
        UPDATE_SITE_DEFAULT_POLLING_INTERVAL,
        "post",
        payload
      );

      if (res?.data) {
        Toast(
          "Success",
          "Polling interval updated successfully!",
          "success"
        );

        setShowConfirm(false);
        await getData();
      }
    } catch (err) {
      console.error("Failed to update polling configuration", err);
      Toast("Error", "Failed to update configuration", "error");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Box>
      <MForm title="RNMS Polling Interval">
        <Box sx={{ width: "100%", }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
              width: "50%",
            }}
          >
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{mb:0.5}}>
                Interval (Minutes) *
              </Typography>

              <MInput
                fullWidth
                type="text"
                name="pollingInterval"
                value={formik.values.pollingInterval}
                disabled={formik.values.isDefault === true}
                onChange={handlePollingIntervalChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.pollingInterval &&
                  Boolean(formik.errors.pollingInterval)
                }
                errorMessage={
                  formik.touched.pollingInterval
                    ? formik.errors.pollingInterval
                    : ""
                }
                placeholder="e.g. 10"
                inputProps={{
                  inputMode: "numeric",
                  pattern: "[0-9]*",
                  maxLength: 2,
                }}
              />
            </Box>

            <FormControlLabel
              control={
                <Checkbox
                  name="isDefault"
                  checked={formik.values.isDefault === true}
                  onChange={handleCheckboxChange}
                  color="primary"
                />
              }
              label={
                <Typography variant="body2" fontWeight={500}>
                  Reset to Default Interval
                </Typography>
              }
            />

            <Box sx={{ display: "flex", justifyContent: "flex-start" }}>
              <MButtonPrimary
                variant="contained"
                color="primary"
                startIcon={
                  isSaving ? (
                    <CircularProgress size={20} color="inherit" />
                  ) : (
                    <Update />
                  )
                }
                disabled={
                  isSaving ||
                  !formik.isValid ||
                  !formik.dirty
                }
                onClick={formik.handleSubmit}
                sx={{ px: 5 }}
              >
                {isSaving ? "Updating..." : "Update"}
              </MButtonPrimary>
            </Box>
          </Box>
        </Box>
      </MForm>

      <MDialog
        open={showConfirm}
        variant="info"
      icon={confirmation_icon}
        title="Confirm Action"
        message="This action will reset polling interval for All Sites. Do you really want to continue?"
        onConfirm={async () => {
          await handleConfirmUpdate(formik.values);
        }}
        onClose={() => {
          setShowConfirm(false);
        }}
        confirmText="Yes"
        cancelText="No"
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </Box>
  );
};

export default RnmsPollingInterval;
