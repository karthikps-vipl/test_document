import React, { useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import {
  Box,
  Grid,
  CircularProgress,
  TextField,
  IconButton,
  InputAdornment,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import JSEncrypt from "jsencrypt";

import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";

import { Update, Visibility, VisibilityOff } from "@mui/icons-material";
import {
  FETCH_MODEM_ENCRYPTOR_PASSWORD,
  FETCH_SITEDETAILS_BY_TERMINALTYPE_ID,
  UPDATE_MODEM_ENCRYPTOR_PASSWORD,
} from "@/RestAPI/url/cnmsEndPoint";

// --------------------------------------------------
// ENCRYPTION UTILITY
// --------------------------------------------------

export const encryptData = (params) => {
  const pub_key =
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDdCEJNwWItuLHrG+UYhJMEUp9zCfGgbZnWx1CvZa9MoHEjcOCqVX36rlSyHibSQZY1jpsKYyZ0c51V9XeBRWhpT6dcVFTLoQZEqsWgiHK3HZe63gz2wa2ujwQTpVrsgVkAeBikPbR5k/Gr9xDBZJ99poGxmg0649S2vIa95BmhLQIDAQAB";

  const encrypt = new JSEncrypt();
  encrypt.setPublicKey(pub_key);

  return encrypt.encrypt(params);
};

// --------------------------------------------------
// MAIN COMPONENT
// --------------------------------------------------

const UpdateModeAndEncryptorPassword = () => {
  const allTerminalTypes = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails || []
  );

  // Filter terminal types (same as UpdateSiteActiveMode)
  const filteredTerminalTypes = useMemo(() => {
    return allTerminalTypes.filter(
      (terminal) => terminal.terminalTypeName !== "CNMS"
    );
  }, [allTerminalTypes]);

  const [discoveredSites, setDiscoveredSites] = useState([]);
  const [fetching, setFetching] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // --------------------------------------------------
  // FORMIK VALIDATION
  // --------------------------------------------------

  // const validationSchema = Yup.object().shape({
  //   terminalId: Yup.number().required("Please select a Terminal"),

  //   password: Yup.string().trim().required("Please enter a Password"),
  // });

  const validationSchema = Yup.object().shape({
    terminalId: Yup.number().required("Please select a Terminal"),
    password: Yup.string()
      .trim()
      .min(4, "Password must be at least 4 characters long") // Minimum length
      .required("Please enter a Password")
      .matches(/[a-zA-Z]/, "Password must contain letters") // Must contain letters
      .matches(/[0-9]/, "Password must contain at least one number"), // Must contain a number
  });

  const formik = useFormik({
    initialValues: {
      terminalId: null,
      password: "",
    },

    validationSchema,

    onSubmit: async (values) => {
      try {
        setLoading(true);

        // Encrypt the password entered in the input field
        const encryptedPassword = encryptData(values.password);

        if (!encryptedPassword) {
          Toast("Error!", "Password encryption failed", "error");
          return;
        }

        // Final API URL
        const updateUrl =
          `${UPDATE_MODEM_ENCRYPTOR_PASSWORD}/` + `${values.terminalId}`;
        // `${encodeURIComponent(encryptedPassword)}`;
        const payload = {
          message: encryptedPassword,
        };

        // Update API call
        const response = await InventoryAxios(updateUrl, "post", payload);

        console.log("Update Password Response:", response);

        Toast("Success!", "Password updated successfully", "success");
      } catch (error) {
        console.error("Update Password Error:", error);

        Toast(
          "Error!",
          error?.response?.data?.message ||
            error?.message ||
            "Operation failed",
          "error"
        );
      } finally {
        setLoading(false);
      }
    },
  });

  // --------------------------------------------------
  // FETCH PASSWORD AND DISCOVERED SITES
  // WHEN TERMINAL ID CHANGES
  // --------------------------------------------------

  useEffect(() => {
    const terminalId = formik.values.terminalId;

    let cancelled = false;

    // Reset previous terminal data
    setDiscoveredSites([]);
    formik.setFieldValue("password", "");
    setShowPassword(false);

    if (!terminalId) {
      setFetching(false);
      return;
    }

    const fetchTerminalDetails = async () => {
      try {
        setFetching(true);

        // Both API calls execute simultaneously
        const [sitesResult, passwordResult] = await Promise.allSettled([
          // API 1: Fetch discovered sites
          InventoryAxios(
            `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${terminalId}`,
            "get"
          ),

          // API 2: Fetch existing password
          InventoryAxios(
            `${FETCH_MODEM_ENCRYPTOR_PASSWORD}/${terminalId}`,
            "post"
          ),
        ]);

        if (cancelled) return;

        // ----------------------------------------------
        // HANDLE DISCOVERED SITES RESPONSE
        // ----------------------------------------------

        if (sitesResult.status === "fulfilled") {
          const sitesResponse = sitesResult.value;

          const sitesData =
            sitesResponse?.data?.data ??
            sitesResponse?.data ??
            sitesResponse ??
            [];

          if (Array.isArray(sitesData)) {
            // Display only siteName
            const siteNames = sitesData
              .map((site) => site?.siteName)
              .filter(
                (siteName) =>
                  typeof siteName === "string" && siteName.trim() !== ""
              );

            setDiscoveredSites(siteNames);
          } else {
            setDiscoveredSites([]);
          }
        } else {
          console.error("Fetch Discovered Sites Error:", sitesResult.reason);

          setDiscoveredSites([]);

          Toast("Error!", "Failed to fetch discovered sites", "error");
        }

        // ----------------------------------------------
        // HANDLE PASSWORD RESPONSE
        // ----------------------------------------------

        if (passwordResult.status === "fulfilled") {
          const passwordResponse = passwordResult.value;

          const passwordData =
            passwordResponse?.data?.data ??
            passwordResponse?.data ??
            passwordResponse ??
            "";

          // Backend directly returns plain-text password.
          const password =
            typeof passwordData === "string"
              ? passwordData
              : passwordData?.password ?? "";

          formik.setFieldValue("password", password);
        } else {
          console.error("Fetch Password Error:", passwordResult.reason);

          formik.setFieldValue("password", "");

          Toast("Error!", "Failed to fetch password", "error");
        }
      } catch (error) {
        if (!cancelled) {
          console.error("Fetch Terminal Details Error:", error);

          Toast("Error!", "Failed to fetch terminal details", "error");
        }
      } finally {
        if (!cancelled) {
          setFetching(false);
        }
      }
    };

    fetchTerminalDetails();

    // Prevent previous terminal responses from updating
    // the UI after switching terminals.
    return () => {
      cancelled = true;
    };
  }, [formik.values.terminalId]);

  // --------------------------------------------------
  // UPDATE BUTTON VALIDATION
  // --------------------------------------------------

  const isButtonDisabled =
    loading ||
    fetching ||
    !formik.values.terminalId ||
    !formik.values.password?.trim() ||
    discoveredSites.length === 0;

  // --------------------------------------------------
  // UI
  // --------------------------------------------------

  return (
    <Box
      sx={{
        border: "1px solid #e0e0e0",
        borderRadius: "8px",
        p: 3,
      }}
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          formik.handleSubmit();
        }}
      >
        <Grid container direction="column" spacing={2}>
          {/* ----------------------------------------- */}
          {/* 1. TERMINAL ID */}
          {/* ----------------------------------------- */}

          <Grid item xs={12} sx={{ width: "100%" }}>
            <MSelect
              label="Terminal *"
              name="terminalId"
              options={filteredTerminalTypes}
              value={formik.values.terminalId}
              onChange={(val) =>
                formik.setFieldValue("terminalId", val?.id ?? null)
              }
              placeholder="Select a Terminal"
              getOptionLabel={(opt) => opt.terminalTypeName || ""}
              getOptionValue={(opt) => opt.id}
              error={
                formik.touched.terminalId && Boolean(formik.errors.terminalId)
              }
              helperText={formik.touched.terminalId && formik.errors.terminalId}
            />
          </Grid>

          {/* ----------------------------------------- */}
          {/* 2. PASSWORD INPUT */}
          {/* ----------------------------------------- */}

          <Grid item xs={12} sx={{ width: "100%" }}>
            <Typography
              sx={{
                mb: 0.5,
                fontSize: "14px",
                fontWeight: 500,
              }}
            >
              Password *
            </Typography>
            <TextField
              fullWidth
              // label="Password *"
              name="password"
              type={showPassword ? "text" : "password"}
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled={!formik.values.terminalId || fetching}
              placeholder="Enter Password"
              sx={{ borderRadius: "10px" }}
              error={formik.touched.password && Boolean(formik.errors.password)}
              helperText={formik.touched.password && formik.errors.password}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword((prev) => !prev)}
                      edge="end"
                      disabled={!formik.values.password}
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Grid>

          {/* ----------------------------------------- */}
          {/* 3. DISCOVERED SITES */}
          {/* ----------------------------------------- */}

          <Grid item xs={12} sx={{ width: "100%" }}>
            <Box>
              <Typography
                sx={{
                  mb: 0.5,
                  fontSize: "14px",
                  fontWeight: 500,
                }}
              >
                Discovered Sites *
              </Typography>

              <Box
                sx={{
                  minHeight: "120px",
                  maxHeight: "120px",
                  minWidth: "270px",
                  overflowY: "auto",
                  border: "1px solid #d1d5db",
                  borderRadius: "8px",
                  p: 1.5,
                  backgroundColor: "#fff",
                }}
              >
                {/* {fetching ? (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      height: "90px",
                    }}
                  >
                    <CircularProgress size={22} />
                  </Box>
                ) : discoveredSites.length > 0 ? (
                  discoveredSites.map((siteName, index) => (
                    <Typography
                      key={`${siteName}-${index}`}
                      sx={{
                        fontSize: "14px",
                        mb: 0.5,
                      }}
                    >
                      {siteName}
                      {index !== discoveredSites.length - 1 ? "," : ""}
                    </Typography>
                  ))
                ) : (
                  <Typography
                    sx={{
                      color: "#999",
                      fontSize: "13px",
                    }}
                  >
                    {formik.values.terminalId
                      ? "No discovered sites"
                      : "Select a Terminal first"}
                  </Typography>
                )} */}
                {discoveredSites.length > 0 ? (
                  discoveredSites.map((siteName, index) => (
                    <Typography
                      key={`${siteName}-${index}`}
                      sx={{
                        fontSize: "14px",
                        mb: 0.5,
                      }}
                    >
                      {index + 1}. {siteName}
                      {index !== discoveredSites.length - 1 ? "," : ""}
                    </Typography>
                  ))
                ) : (
                  <Typography
                    sx={{
                      color: "#999",
                      fontSize: "13px",
                    }}
                  >
                    {formik.values.terminalId
                      ? "No discovered sites"
                      : "Select a Terminal first"}
                  </Typography>
                )}
              </Box>
            </Box>
          </Grid>

          {/* ----------------------------------------- */}
          {/* UPDATE BUTTON */}
          {/* ----------------------------------------- */}

          <Grid
            item
            xs={12}
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              width: "100%",
              mt: 1,
            }}
          >
            <MButtonPrimary
              onClick={formik.handleSubmit}
              variant="contained"
              disabled={isButtonDisabled}
              startIcon={
                loading ? (
                  <CircularProgress size={20} color="inherit" />
                ) : (
                  <Update />
                )
              }
              sx={{
                bgcolor: "#1a237e",
                "&:hover": {
                  bgcolor: "#000",
                },
                minWidth: "130px",
              }}
            >
              {loading ? "Updating..." : "Update"}
            </MButtonPrimary>
          </Grid>
        </Grid>
      </form>
    </Box>
  );
};

export default UpdateModeAndEncryptorPassword;
