import React, { useEffect, useState, useMemo } from "react";
import { Box, CircularProgress } from "@mui/material";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_SITE_DETAILS_BASED_ON_LOCAL_MODE,
  SAVE_ROLE_ASSIGNMENT_CONFIGURATION,
} from "@/RestAPI/url/cnmsEndPoint";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { Update } from "@mui/icons-material";
import Toast from "@/components/Reusable/Toast/Toast";

import { useSiteDetails } from "./utils";

// Ensure this is correct based on your project structure
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MSelect from "@/components/Reusable/Select/MSelect";

const RoleAssignmentForm = ({ onClose, isGrandchildFullScreen,onRefresh }) => {
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sites, setSites] = useState([]);

  // Form State
  const [numRepeaters, setNumRepeaters] = useState(0);
  const [localSite, setLocalSite] = useState(null);
  const [remoteSite, setRemoteSite] = useState(null);
  const [repeaters, setRepeaters] = useState([]);

  const { refreshSiteDetails } = useSiteDetails();

  // --- NEW: Confirmation Dialog State ---
  const [confirmationDialog, setConfirmationDialog] = useState({
    open: false,
    message: "Are you sure you want to Add Role?",
  });


  useEffect(() => {
    fetchSites();
  }, []);

  const fetchSites = async () => {
    setLoading(true);
    try {
      const { data } = await InventoryAxios(
        FETCH_SITE_DETAILS_BASED_ON_LOCAL_MODE,
        "get",
        1
      );
      const siteOptions = data.map((site) => ({
        id: site.siteId,
        label: site.siteId,
        originalData: site,
      }));
      setSites(siteOptions);
    } catch (error) {
      console.error("Error fetching sites:", error);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredOptions = (excludeId) => {
    const selectedIds = new Set();

    if (localSite && localSite.id !== excludeId) selectedIds.add(localSite.id);
    if (remoteSite && remoteSite.id !== excludeId)
      selectedIds.add(remoteSite.id);

    repeaters.forEach((rep) => {
      if (rep && rep.id !== excludeId) {
        selectedIds.add(rep.id);
      }
    });
    return sites.filter((site) => !selectedIds.has(site.id));
  };

  const isFormValid = useMemo(() => {
    if (!localSite || !remoteSite) return false;
    if (numRepeaters > 0) {
      return (
        repeaters.length === numRepeaters && repeaters.every((r) => r !== null)
      );
    }
    return true;
  }, [localSite, remoteSite, numRepeaters, repeaters]);

  const handleNumRepeatersChange = (opt) => {
    const count = parseInt(opt?.value) || 0;
    setNumRepeaters(count);
    setRepeaters(Array.from({ length: count }, () => null));
  };

  const handleRepeaterChange = (index, val) => {
    const updated = [...repeaters];
    updated[index] = val;
    setRepeaters(updated);
  };

  // --- 1. Function to Open Dialog ---
  const handleOpenConfirmation = () => {
    setConfirmationDialog({
      open: true,
      message: "Are you sure you want to Add Role?",
    });
  };

  // --- 2. Function to Handle "Yes" (Actual Submit) ---
  const handleConfirmationYes = async () => {
    // Close the dialog immediately
    setConfirmationDialog({ open: false });

    // Proceed with the actual submission logic
    await handleSubmit();
  };

  // --- 3. Function to Handle "No" / Cancel ---
  const closeConfirmationDialog = () => {
    setConfirmationDialog({ open: false });
  };

  const handleSubmit = async () => {
    if (!isFormValid) {
      Toast("Validation Error", "Please fill in all required fields.", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        localSite: localSite.id,
        remoteSite: remoteSite.id,
      };

      repeaters.forEach((rep, index) => {
        payload[`repeator${index + 1}Site`] = rep.id;
      });

      const response = await InventoryAxios(
        SAVE_ROLE_ASSIGNMENT_CONFIGURATION,
        "post",
        payload
      );

      if (response?.data) {
        await refreshSiteDetails();

        Toast("Success", "Role Configuration added successfully", "success");
        onRefresh?.();
        onClose();
      }
    } catch (error) {
      console.error("Error submitting role assignment:", error);
      Toast("Error", "Failed to add role configuration", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 3, p: 2 }}>
      {/* 1. No of Repeaters */}
      <MSelect
        label="No of Repeaters to Add :*"
        placeholder="Select"
        // We define the options in a constant so we can reference them in the 'value' logic
        options={[
          { label: "0", value: 0 },
          { label: "1", value: 1 },
          { label: "2", value: 2 },
        ]}
        // This line ensures the UI displays the currently selected number
        value={
          [
            { label: "0", value: 0 },
            { label: "1", value: 1 },
            { label: "2", value: 2 },
          ].find((opt) => opt.value === numRepeaters) || null
        }
        onChange={(opt) => handleNumRepeatersChange(opt)}
      />
      {/* 2. Local Site */}
      <MSelect
        label="Local *"
        placeholder="Select Local Site"
        value={localSite}
        options={getFilteredOptions(localSite?.id)}
        onChange={(val) => setLocalSite(val)}
        getOptionValue={(opt) => opt.id}
        getOptionLabel={(opt) => opt.label}
      />

      {/* 3. Dynamic Repeaters */}
      {repeaters.map((rep, index) => {
        console.log("hynvecgs",rep?.id)
        return(
        <MSelect
          key={rep?.id}
          label={`Repeater ${index + 1} *`}
          placeholder={`Select Repeater ${index + 1}`}
          value={rep}
          options={getFilteredOptions(rep?.id)}
          onChange={(val) => handleRepeaterChange(index, val)}
          getOptionValue={(opt) => opt.id}
          getOptionLabel={(opt) => opt.label}
        />
      )}
      )}

      {/* 4. Remote Site */}
      <MSelect
        label="Remote *"
        placeholder="Select Remote Site"
        value={remoteSite}
        options={getFilteredOptions(remoteSite?.id)}
        onChange={(val) => setRemoteSite(val)}
        getOptionValue={(opt) => opt.id}
        getOptionLabel={(opt) => opt.label}
      />

      <Box sx={{ display: "flex", gap: 2, mt: 2 }}>
        <MButtonPrimary
          variant="contained"
          onClick={handleOpenConfirmation} // Opens dialog on click
          disabled={!isFormValid || loading || isSubmitting}
          startIcon={
            isSubmitting ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              <Update />
            )
          }
          sx={{ bgcolor: "#1a237e", "&:hover": { bgcolor: "#000" }, flex: 1 }}
        >
          {isSubmitting ? "Submitting..." : "SUBMIT"}
        </MButtonPrimary>

        <MButtonSecondary onClick={onClose} disabled={isSubmitting}>
          CANCEL
        </MButtonSecondary>
      </Box>

      {/* --- MDialog Component --- */}
      <MDialog
        open={confirmationDialog.open}
        title="Confirm Action"
        message={confirmationDialog.message}
        onConfirm={handleConfirmationYes}
        onClose={closeConfirmationDialog}
        variant="warning"
        icon={Confirmation_icon}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default RoleAssignmentForm;
