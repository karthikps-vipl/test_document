import React, { useMemo, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import {
  Box,
  Grid,
  Typography,
  Button,
  FormHelperText,
  CircularProgress,
  useTheme,
} from "@mui/material";
import * as Yup from "yup";
import { useFormik } from "formik";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { ADD_SITE_GROUP } from "@/RestAPI/url/cnmsEndPoint";
import MAlarmSelect from "@/components/Dialogs/AlarmSuppression/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { Update } from "@mui/icons-material";
import { useSiteDetails } from "../utils";

// Validation schema
const validationSchema = Yup.object({
  groupName: Yup.string()
    .required("Group Name is required")
    .matches(
      /^[a-zA-Z0-9]+$/,
      "Group Name should contain only alphanumeric characters"
    )
    .min(3, "Group Name should be between 3 to 24 alphanumeric characters")
    .max(24, "Group Name should be between 3 to 24 alphanumeric characters"),
  groupDescription: Yup.string()
    .required("Group Description is required")
    .matches(
      /^[a-zA-Z0-9 ]+$/,
      "Group Description should contain only alphanumeric characters"
    )
    .min(
      10,
      "Group Description should be between 10 to 256 alphanumeric characters"
    )
    .max(
      256,
      "Group Description should be between 10 to 256 alphanumeric characters"
    ),
  selectedSites: Yup.array()
    .min(1, "Sites are mandatory")
    .required("Sites are mandatory"),
});

const AddRemoteGroup = ({ onClose, onRefresh, data }) => {
  const { fetchSiteDetails = [] } = useSelector(
    (state) => state?.remoteRepDetails || {}
  );
  const [loading, setLoading] = useState(false);

  const { refreshSiteDetails,refreshSiteGroups } = useSiteDetails();

    const theme = useTheme();

  // Determine if we are in Edit mode
  const isEditMode = data?.type === "edit" || data?.mode === "EDIT";

  const siteOptions = useMemo(() => {
    const sites = Array.isArray(fetchSiteDetails) ? fetchSiteDetails : [];
    return [...new Set(sites.map((site) => site?.siteId).filter(Boolean))].map(
      (siteId) => ({
        label: siteId,
        value: siteId,
      })
    );
  }, [fetchSiteDetails]);

  const formik = useFormik({
    // 1. PRE-FILL DATA: If isEditMode, map existing data to initial values
    initialValues: {
      groupName: data?.groupName || data?.groupname || "",
      groupDescription: data?.groupDescription || data?.description || "",
      // Map existing sites array to just the ID strings for the dropdown
      selectedSites:
        isEditMode && data?.sites ? data.sites.map((s) => s.siteId) : [],
    },
    validationSchema,
    onSubmit: async (values) => {
      // 2. DYNAMIC PAYLOAD: Use "edit" or "add" based on mode
      const payload = {
        groupName: values.groupName,
        groupDescription: values.groupDescription,
        sites: values.selectedSites.map((siteId) => ({
          siteId,
        })),
        type: isEditMode ? "edit" : "add",
      };

      try {
        setLoading(true);
        const response = await InventoryAxios(ADD_SITE_GROUP, "post", payload);

        if (response?.data?.status === 0 || response?.data?.status === false) {
          Toast(
            "Error!",
            response?.data?.message || "Operation failed",
            "error"
          );
          return;
        }
        await refreshSiteDetails();
        await refreshSiteGroups();
        Toast(
          "Success!",
          `${isEditMode ? "Updated" : "Added"} group successfully`,
          "success"
        );
        onRefresh?.();
        onClose?.();
      } catch (error) {
        console.error("Error:", error);
        Toast(
          "Error!",
          error?.response?.data?.message || "Operation failed",
          "error"
        );
      } finally {
        setLoading(false);
      }
    },
  });

  // 3. SYNC DATA: If the 'data' prop changes (e.g., user clicks a different row), update form
  useEffect(() => {
    if (data) {
      formik.setValues({
        groupName: data?.groupName || data?.groupname || "",
        groupDescription: data?.groupDescription || data?.description || "",
        selectedSites:
          isEditMode && data?.sites ? data.sites.map((s) => s.siteId) : [],
      });
    }
  }, [data, isEditMode]);

  const selectedRemoteIds = formik.values.selectedSites
    .map((siteId) => siteOptions.find((site) => site.value === siteId))
    .filter(Boolean);

  return (
    <Box sx={{ width: "100%", p: 2 }}>
      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={4}>
          {/* LEFT SECTION */}
          <Grid item xs={12} md={6} sx={{ width: "100%" }}>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 3,}}>
              {/* Group Name */}
              <Box>
                <Typography sx={{ mb: 0.5, fontSize: "14px", fontWeight: 500 }}>
                  Group Name
                </Typography>
                <MInput
                  fullWidth
                  name="groupName"
                  value={formik.values.groupName}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  placeholder="Enter Group Name"
                  sx={{ width: "100%" }}
                  // ADD THIS LINE: Disable if isEditMode is true
                  disabled={isEditMode}
                />
                {formik.touched.groupName && formik.errors.groupName && (
                  <FormHelperText error>
                    {formik.errors.groupName}
                  </FormHelperText>
                )}
              </Box>
              <Box>
                <Typography sx={{ mb: 0.5, fontSize: "14px", fontWeight: 500 }}>
                  Group Description
                </Typography>
                <MInput
                  fullWidth
                  name="groupDescription"
                  value={formik.values.groupDescription}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  placeholder="Enter Group Description"
                  sx={{ width: "100%" }}
                />
                {formik.touched.groupDescription &&
                  formik.errors.groupDescription && (
                    <FormHelperText error>
                      {formik.errors.groupDescription}
                    </FormHelperText>
                  )}
              </Box>
            </Box>
          </Grid>

          {/* RIGHT SECTION */}
          <Grid item xs={12} md={6} sx={{ width: "100%" }}>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
              <Box>
                <MAlarmSelect
                  label="Remote ID's"
                  options={siteOptions}
                  value={formik.values.selectedSites}
                  onChange={(values) => {
                    formik.setFieldValue("selectedSites", values);
                    formik.setFieldTouched("selectedSites", true, false);
                  }}
                />
              </Box>
              <Box>
                <Typography sx={{ mb: 0.5, fontSize: "14px", fontWeight: 500 }}>
                  Selected Remote's
                </Typography>
                <Box
                  sx={{
                    minHeight: "120px",
                    maxHeight: "120px",
                    width: "100%",
                    overflowY: "auto",
                    border: "1px solid #d1d5db",
                    borderRadius: "8px",
                    p: 1.5,
                  }}
                >
                  {selectedRemoteIds.length > 0 ? (
                    selectedRemoteIds.map((site, index) => (
                      <Typography
                        key={site.value}
                        sx={{ fontSize: "14px", mb: 0.5 }}
                      >
                        {site.label}
                        {index !== selectedRemoteIds.length - 1 ? "," : ""}
                      </Typography>
                    ))
                  ) : (
                    <Typography sx={{ color: "#999", fontSize: "13px" }}>
                      No remotes selected
                    </Typography>
                  )}
                </Box>
              </Box>
            </Box>
          </Grid>
        </Grid>

        {/* BOTTOM-RIGHT BUTTONS */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 2,
            mt: 4,
          }}
        >
          {/* 1. Conditionally render Clear button: Only show if NOT in edit mode */}
          {!isEditMode && (
            <Button
              variant="outlined"
              onClick={() => formik.resetForm()}
              disabled={loading}
              sx={{
                // border: "1px solid #14348D",
                border: theme.palette.mode === "dark" ? "1px solid #ffffff" : "1px solid #14348D",
                borderRadius: "10px",
                // color: "#14348D",
                color:theme.palette.mode === "dark" ? "#ffffff" : "#14348D",
                textTransform: "none",
              }}
            >
              Clear
            </Button>
          )}

          <MButtonPrimary
            variant="contained"
            onClick={formik.handleSubmit}
            // If it's Edit mode, we don't want to disable just because it's not "dirty"
            // (since initial values match the data)
            disabled={loading || !formik.isValid}
            startIcon={
              loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
            sx={{
              bgcolor: "#1a237e",
              "&:hover": { bgcolor: "#000" },
              // 2. Adjust flex: If Clear is hidden, make Update button full width
              flex: !isEditMode ? 1 : "none",
              minWidth: isEditMode ? "150px" : "auto",
            }}
          >
            {loading ? "Processing..." : isEditMode ? "UPDATE" : "ADD"}
          </MButtonPrimary>
        </Box>
      </form>
    </Box>
  );
};

export default AddRemoteGroup;
