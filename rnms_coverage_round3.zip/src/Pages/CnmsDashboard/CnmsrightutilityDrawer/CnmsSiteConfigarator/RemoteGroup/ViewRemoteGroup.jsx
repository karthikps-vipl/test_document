import React from 'react';
import { Box, Typography } from '@mui/material';

const ViewRemoteGroup = ({ data }) => {
  // Extract the sites array from the data object
  // We use optional chaining (?.) and default to an empty array to prevent errors if data is null
  const sites = data?.sites || [];

  console.log("ViewRemoteGroup", data);

  return (
    <div style={{ width: "100%", padding: "10px" }}>
      <Box
        sx={{
          minHeight: "120px",
          maxHeight: "500px",
          width: "100%",
          overflowY: "auto",
          border: "1px solid #d1d5db",
          borderRadius: "8px",
          p: 1.5,
        }}
      >
        {sites.length > 0 ? (
          sites.map((site, index) => (
            <Typography
              key={site.siteId || index} // Using siteId as key
              sx={{ fontSize: "14px", mb: 0.5 }}
            >
              {site.siteId}
              {/* Adds a comma after every item except the last one */}
              {index !== sites.length - 1 ? "," : ""}
            </Typography>
          ))
        ) : (
          <Typography sx={{ color: "#999", fontSize: "13px" }}>
            No remotes selected
          </Typography>
        )}
      </Box>
    </div>
  );
};

export default ViewRemoteGroup;