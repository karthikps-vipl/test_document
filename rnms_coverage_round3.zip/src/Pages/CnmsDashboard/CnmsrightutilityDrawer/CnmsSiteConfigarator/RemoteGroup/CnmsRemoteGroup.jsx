import React, { useEffect, useState } from "react";
import { Box, CircularProgress } from "@mui/material";
import MTable from "@/components/Reusable/Table/MTable";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  FETCH_ALL_SITE_GROUPS,
  ADD_SITE_GROUP,
} from "@/RestAPI/url/cnmsEndPoint";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useSiteDetails } from "../utils";

const CnmsRemoteGroup = ({
  privilegeKey,
  handleAdd,
  refreshTrigger,
  handleEdit,
  handleView,isChildFullScreen
}) => {
  const [groupData, setGroupData] = useState([]);
  const [loading, setLoading] = useState(true);

  // --- DELETE STATES ---
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deleteRow, setDeleteRow] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const { refreshSiteDetails,refreshSiteGroups } = useSiteDetails();

  // Fetch all site groups
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await InventoryAxios(FETCH_ALL_SITE_GROUPS, "get");
      const groups = response?.data?.data ?? [];
      const processedData = groups.map((item, index) => ({
        ...item,
        sno: index + 1,
        groupname: item.groupName ?? "NA",
        description: item.groupDescription ?? "NA",
      }));
      setGroupData(processedData);
    } catch (error) {
      console.error("Error fetching site groups:", error);
      Toast("Error", "Failed to fetch site groups", "error");
      setGroupData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [refreshTrigger]);

  // --- DELETE LOGIC ---
  const handleDeleteClick = (row) => {
    setDeleteRow(row);
    setIsDeleteOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deleteRow) return;

    const payload = {
      groupName: deleteRow.groupName,
      groupDescription: deleteRow.groupDescription,
      sites: [],
      type: "delete",
    };

    setIsDeleting(true);
    try {
      const response = await InventoryAxios(ADD_SITE_GROUP, "post", payload);

      // Check for success based on your API pattern (usually response.data.status)
      if (response?.data?.status === 0 || response?.data?.status === false) {
        throw new Error(response?.data?.message || "Failed to delete group");
      }
      await refreshSiteDetails();
      await refreshSiteGroups();
      Toast("Success", "Remote group deleted successfully", "success");
      setIsDeleteOpen(false);
      setDeleteRow(null);
      fetchData(); // Refresh the table
    } catch (error) {
      console.error("Delete error:", error);
      Toast(
        "Error",
        error?.response?.data?.message || "Failed to delete group",
        "error"
      );
    } finally {
      setIsDeleting(false);
    }
  };

  // Table columns
  const columns = [
    {
      name: "S.No",
      uid: "sno",
      width: "80px",
    },
    {
      name: "Group Name",
      uid: "groupname",
      width: "200px",
    },
    {
      name: "Description",
      uid: "description",
      width: "300px",
    },
    {
      name: "Actions",
      uid: "actions",
      sortable: false,
      cellClassName: "sticky-actions",
      headerClassName: "sticky-actions",
      width: "150px",
    },
  ];

  return (
    <Box sx={{ width: "100%", p: 2 }}>
      {loading ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            mt: 10,
          }}
        >
          <CircularProgress />
        </Box>
      ) : (
        <>
          <MTable
            privilegeKey={privilegeKey}
            columns={columns}
            tableData={groupData}
            showPagination={true}
            showSearch={true}
            hideAdd={false}
            AddText="ADD GROUP"
            handleAdd={() =>
              handleAdd?.({
                mode: "CREATE",
                title: "Add Group",
              })
            }
            refreshTrigger={refreshTrigger}
            handleDelete={handleDeleteClick}
            handleEdit={(row) =>
              handleEdit({ ...row, mode: "EDIT", title: "Update Remote Group" })
            }
            handleView={(row) =>
              handleView({
                ...row,
                mode: "VIEW",
                title: `View Remote's: ${row.groupName}`,
              })
            }
          />

          {/* Confirmation Dialog */}
          {isDeleteOpen && (
            <MDialog
              open={isDeleteOpen}
              onClose={() => {
                setIsDeleteOpen(false);
                setDeleteRow(null);
              }}
              onConfirm={handleConfirmDelete}
              title="Delete Group"
              message={
                <>
                  Are you sure you want to delete the group{" "}
                  <strong>{deleteRow?.groupName}</strong>?
                </>
              }
              confirmText={isDeleting ? "Deleting..." : "Delete"}
              cancelText="Cancel"
              variant="error"
              icon={Delete_Icon_}
              mode="child"
              isChildFullScreen={isChildFullScreen}
            />
          )}
        </>
      )}
    </Box>
  );
};

export default CnmsRemoteGroup;
