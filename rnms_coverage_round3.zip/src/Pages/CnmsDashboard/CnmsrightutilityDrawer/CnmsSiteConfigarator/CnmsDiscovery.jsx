import React, { useMemo, useRef, useState } from "react";
import {
  Box,
  Typography,
  Radio,
  RadioGroup,
  FormControlLabel,
  Divider,
  IconButton,
  Tooltip,
} from "@mui/material";

import DownloadIcon from "@mui/icons-material/Download";
import PlayArrow from "@mui/icons-material/PlayArrow";

import * as XLSX from "xlsx";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";

import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";

import {
  PERFORM_SITE_DISCOVERY,
  FETCH_ALL_SITE_DETAILS,
  FETCH_ALL_TERMINAL_TYPE_ALONG_WITH_SITE,
} from "@/RestAPI/url/cnmsEndPoint";

import { isValidIpV4 } from "@/utility/FormValidation/YupSchema";

import { useDispatch, useSelector } from "react-redux";

import {
  setDiscoveryResults,
  setDiscoveryProgress,
  resetDiscoveryProgress,
} from "@/store/features/Cnms/CnmsDiscovery/siteDiscoverySlice";

import CnmsDiscoveryProgressOverlay from "./CnmsDiscoveryProgressOverlay";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import CnmsDiscoveryReportModal from "./CnmsDiscoveryReportModal";
import {
  setFetchAllTerminalTypeAlongWithSite,
  setFetchSiteDetails,
} from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import { getIpMaskedValueAndPosition } from "@/lib/utils";
import { triggerFilterReset } from "@/store/features/Cnms/mapViewSlice";
import { IosShare } from "@mui/icons-material";
import IPv4Input from "@/components/Reusable/Input/IPv4Input";

const CnmsDiscovery = ({ isChildFullScreen }) => {
  const dispatch = useDispatch();

  const fileInputRef = useRef(null);

  const discoveryProgress = useSelector(
    (state) => state.siteDiscovery.discoveryProgress
  );

  const [discoveryType, setDiscoveryType] = useState("2");

  const [listIpAddress, setListIpAddress] = useState("");

  const [individualIp, setIndividualIp] = useState("");

  const [selectedFile, setSelectedFile] = useState(null);

  const [fileIpAddresses, setFileIpAddresses] = useState([]);

  const [loading, setLoading] = useState(false);

  const [dialogConfig, setDialogConfig] = useState({
    visible: false,
    message: "",
  });
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportData, setReportData] = useState([]);
  // const IPV4_REGEX =
  //   /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
  // const validateIp = (ip) => {
  //   const cleaned = String(ip ?? "").trim();

  //   if (!cleaned || !/^[0-9.]+$/.test(cleaned)) {
  //     return false;
  //   }

  //   return IPV4_REGEX.test(cleaned) && isValidIpV4(cleaned);
  // };
  const cleanIp = (value) => {
    if (!value) return "";

    return value.replace(/[^0-9.]/g, "").replace(/\.$/, "");
  };

  const validateIp = (ip) => {
    const cleaned = cleanIp(ip);

    if (!cleaned) {
      return false;
    }

    return isValidIpV4(cleaned);
  };

  // const handleIpInputChange = (event) => {
  //   const { value } = event.target;
  //   const selectionStart = event.target.selectionStart;

  //   const previousValue = individualIp || "";

  //   const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
  //     value,
  //     selectionStart,
  //     previousValue
  //   );

  //   setIndividualIp(maskedValue);

  //   requestAnimationFrame(() => {
  //     const safePosition = Math.min(newCursorPosition, maskedValue.length);

  //     event.target.setSelectionRange(safePosition, safePosition);
  //   });
  // };

  const handleListIpChange = (event) => {
    const { value } = event.target;
    const selectionStart = event.target.selectionStart;

    const beforeCursor = value.slice(0, selectionStart);
    const lastCommaIndex = beforeCursor.lastIndexOf(",");

    const segmentStart = lastCommaIndex + 1;

    const currentIpPart = value.slice(segmentStart, selectionStart);

    const previousListValue = listIpAddress || "";

    const previousBeforeCursor = previousListValue.slice(
      0,
      Math.min(selectionStart, previousListValue.length)
    );

    const previousLastCommaIndex = previousBeforeCursor.lastIndexOf(",");

    const previousSegmentStart = previousLastCommaIndex + 1;

    const previousIpPart = previousListValue.slice(
      previousSegmentStart,
      Math.min(selectionStart, previousListValue.length)
    );

    // Allow the user to type/delete a comma.
    if (value.includes(",")) {
      const commaCountBeforeCursor = (beforeCursor.match(/,/g) || []).length;

      const previousCommaCountBeforeCursor = (
        previousBeforeCursor.match(/,/g) || []
      ).length;

      // If the change is primarily a comma operation,
      // preserve the list as-is and clean the IP portions below.
      if (commaCountBeforeCursor !== previousCommaCountBeforeCursor) {
        const cleanedList = value
          .split(",")
          .map((ip) => cleanIp(ip))
          .join(",");

        setListIpAddress(cleanedList);

        requestAnimationFrame(() => {
          const safePosition = Math.min(selectionStart, cleanedList.length);

          event.target.setSelectionRange(safePosition, safePosition);
        });

        return;
      }
    }

    const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
      currentIpPart,
      currentIpPart.length,
      previousIpPart
    );

    const afterCursor = value.slice(selectionStart);

    const cleanedAfterCursor = afterCursor.replace(/[^0-9.,]/g, "");

    const newValue =
      value.slice(0, segmentStart) + maskedValue + cleanedAfterCursor;

    const newPosition = segmentStart + newCursorPosition;

    setListIpAddress(newValue);

    requestAnimationFrame(() => {
      const safePosition = Math.min(newPosition, newValue.length);

      event.target.setSelectionRange(safePosition, safePosition);
    });
  };

  const parsedListIps = useMemo(() => {
    if (!listIpAddress.trim()) {
      return [];
    }

    return listIpAddress
      .split(",")
      .map((ip) => ip.trim())
      .filter(Boolean);
  }, [listIpAddress]);

  const invalidListIps = useMemo(() => {
    return parsedListIps.filter((ip) => !validateIp(ip));
  }, [parsedListIps]);

  const duplicateListIps = useMemo(() => {
    const normalized = parsedListIps.map((ip) => ip.toLowerCase());

    return normalized.filter((ip, index) => normalized.indexOf(ip) !== index);
  }, [parsedListIps]);

  const isListValid =
    parsedListIps.length > 0 &&
    invalidListIps.length === 0 &&
    duplicateListIps.length === 0;

  const isIndividualIpValid = individualIp === "" || validateIp(individualIp);

  const handleDownloadTemplate = () => {
    try {
      const workbook = XLSX.utils.book_new();

      const worksheetData = [["List the ip addresses below"]];

      const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

      worksheet["!cols"] = [
        {
          wch: 30,
        },
      ];

      XLSX.utils.book_append_sheet(workbook, worksheet, "IP Addresses");

      XLSX.writeFile(workbook, "File based discovery.xlsx");

      Toast("Success", "Excel template downloaded successfully.", "success");
    } catch (error) {
      console.error("Excel template download failed:", error);

      Toast("Error", "Failed to download Excel template.", "error");
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];

    if (!file) {
      return;
    }

    const allowedExtensions = [".xlsx", ".xls"];
    const fileName = file.name.toLowerCase();

    const isValidExtension = allowedExtensions.some((extension) =>
      fileName.endsWith(extension)
    );

    if (!isValidExtension) {
      Toast(
        "Error",
        "Please upload a valid Excel file (.xlsx or .xls).",
        "error"
      );

      event.target.value = "";
      return;
    }

    try {
      const buffer = await file.arrayBuffer();

      const workbook = XLSX.read(buffer, {
        type: "array",
      });

      if (!workbook.SheetNames?.length) {
        throw new Error("Excel file does not contain any sheet.");
      }

      const worksheet = workbook.Sheets[workbook.SheetNames[0]];

      const rows = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
        raw: false,
      });

      /*
       * Skip the first row because your template contains:
       *
       * List the ip addresses below
       *
       * Then collect all remaining cell values.
       */
      const rawValues = rows
        .slice(1)
        .flat()
        .map((value) => String(value ?? "").trim())
        .filter(Boolean);

      /*
       * Allow comma-separated IPs inside a cell as well.
       */
      const extractedIps = rawValues
        .flatMap((value) => value.split(","))
        .map((ip) => ip.trim())
        .filter(Boolean);

      if (extractedIps.length === 0) {
        throw new Error("No IP addresses were found in the Excel file.");
      }

      /*
       * Strict IPv4 validation.
       */
      const invalidIps = extractedIps.filter((ip) => !validateIp(ip));

      if (invalidIps.length > 0) {
        Toast(
          "Error",
          `Invalid IPv4 address(es): ${invalidIps.join(", ")}`,
          "error"
        );

        setSelectedFile(null);
        setFileIpAddresses([]);

        event.target.value = "";
        return;
      }

      /*
       * Duplicate validation.
       */
      const normalizedIps = extractedIps.map((ip) => ip.toLowerCase());

      const duplicateIps = normalizedIps.filter(
        (ip, index) => normalizedIps.indexOf(ip) !== index
      );

      if (duplicateIps.length > 0) {
        const duplicates = [...new Set(duplicateIps)];

        Toast(
          "Error",
          `Duplicate IP address(es) are not allowed: ${duplicates.join(", ")}`,
          "error"
        );

        setSelectedFile(null);
        setFileIpAddresses([]);

        event.target.value = "";
        return;
      }

      /*
       * Everything is valid.
       */
      setSelectedFile(file);
      setFileIpAddresses(extractedIps);

      Toast(
        "Success",
        `${extractedIps.length} valid IP address(es) loaded from Excel.`,
        "success"
      );
    } catch (error) {
      console.error("Excel processing error:", error);

      setSelectedFile(null);
      setFileIpAddresses([]);

      Toast(
        "Error",
        error.message || "Failed to read the Excel file.",
        "error"
      );

      event.target.value = "";
    }
  };

  const handleRadioChange = (event) => {
    const value = event.target.value;

    setDiscoveryType(value);

    setListIpAddress("");
    setIndividualIp("");

    setSelectedFile(null);
    setFileIpAddresses([]);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    dispatch(resetDiscoveryProgress());
  };

  const validateForm = () => {
    if (discoveryType === "3") {
      return isListValid;
    }
    if (discoveryType === "1") {
      return (
        selectedFile !== null &&
        fileIpAddresses.length > 0 &&
        fileIpAddresses.every(validateIp)
      );
    }
    if (discoveryType === "2") {
      return individualIp.trim() !== "" && validateIp(individualIp);
    }

    return false;
  };

  const handleDiscoverClick = () => {
    if (!validateForm()) {
      Toast("Warning", "Please provide valid discovery input.", "warning");

      return;
    }

    setDialogConfig({
      visible: true,
      message: "Are you sure you want to perform Site Discovery?",
    });
  };

  const buildPayload = () => {
    if (discoveryType === "2") {
      return {
        siteDiscoveryType: 2,
        ipAddress: individualIp.trim(),
      };
    }

    if (discoveryType === "3") {
      return {
        siteDiscoveryType: 3,
        listIPAddress: parsedListIps,
      };
    }

    if (discoveryType === "1") {
      return {
        siteDiscoveryType: 1,
        listIPAddress: fileIpAddresses,
      };
    }

    return null;
  };

  const executeDiscovery = async () => {
    const payload = buildPayload();

    if (!payload) {
      return;
    }

    setLoading(true);

    // Open the progress dialog.
    // WebSocket will control the actual stage.
    dispatch(
      setDiscoveryProgress({
        activeStep: 0,
        message: "Starting Site Discovery...",
        percentage: 0,
        isRunning: true,
        socketStage: 0,
      })
    );

    try {
      const discoveryResponse = await InventoryAxios(
        PERFORM_SITE_DISCOVERY,
        "post",
        payload
      );

      console.log("PERFORM_SITE_DISCOVERY response:", discoveryResponse?.data);

      const discoveryData = Array.isArray(discoveryResponse?.data)
        ? discoveryResponse.data
        : [];

      dispatch(setDiscoveryResults(discoveryData));
      setReportData(discoveryData);

      const [siteDetailsResponse, terminalTypesResponse] = await Promise.all([
        InventoryAxios(FETCH_ALL_SITE_DETAILS, "get"),

        InventoryAxios(FETCH_ALL_TERMINAL_TYPE_ALONG_WITH_SITE, "get"),
      ]);

      const siteDetails = Array.isArray(siteDetailsResponse?.data)
        ? siteDetailsResponse.data
        : [];

      const terminalTypes = Array.isArray(terminalTypesResponse?.data)
        ? terminalTypesResponse.data
        : [];

      // dispatch(setSiteDetails(siteDetails));
      dispatch(setFetchSiteDetails(siteDetails));
      dispatch(triggerFilterReset(true));
      console.log("setFetchAllTerminalTypeAlongWithSite", terminalTypes);
      dispatch(setFetchAllTerminalTypeAlongWithSite(terminalTypes));

      /*
       * Do NOT manually change the WebSocket stage here.
       *
       * The WebSocket stage: 3 event should close the
       * progress overlay.
       */

      Toast("Success", "Site Discovery completed successfully.", "success");

      setShowReportModal(true);
    } catch (error) {
      console.error("Site Discovery failed:", error);

      dispatch(resetDiscoveryProgress());

      Toast("Error", "Failed to perform Site Discovery.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmDiscovery = () => {
    setDialogConfig({
      visible: false,
      message: "",
    });

    executeDiscovery();
  };

  return (
    <MForm title={null}>
      <RadioGroup value={discoveryType} onChange={handleRadioChange}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 1.75,
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              gap: 2,
              alignItems: "flex-start",
            }}
          >
            <Box
              sx={{
                minWidth: {
                  md: "200px",
                },
                display: "flex",
                alignItems: "center",
              }}
            >
              <FormControlLabel
                value="3"
                control={<Radio color="primary" size="small" />}
                label={
                  <Typography
                    sx={{
                      fontWeight: 500,
                    }}
                  >
                    List of IPs
                  </Typography>
                }
              />
            </Box>

            <Box
              sx={{
                flex: 1,
                width: "100%",
              }}
            >
              <FormField
                // label="IP Addresses"
                disabled={discoveryType !== "3"}
                value={listIpAddress}
                placeholder="___.___.___.___, ___.___.___.___"
                // onChange={(event) => setListIpAddress(event.target.value)}
                onChange={handleListIpChange}
                multiline
                minRows={2}
                maxRows={5}
                error={
                  discoveryType === "3" && listIpAddress !== "" && !isListValid
                }
                errorMessage={
                  discoveryType === "3" && invalidListIps.length > 0
                    ? `Invalid IP(s): ${invalidListIps.join(", ")}`
                    : discoveryType === "3" && duplicateListIps.length > 0
                    ? "Duplicate IP addresses are not allowed."
                    : ""
                }
              />
              {/* <IPv4Input
  disabled={discoveryType !== "3"}
  value={listIpAddress}
  placeholder="___.___.___.___"
  onChange={(value) => setListIpAddress(value)}
  error={
    discoveryType === "3" &&
    listIpAddress !== "" &&
    !isListValid
  }
  helperText={
    discoveryType === "3" && invalidListIps.length > 0
      ? `Invalid IP(s): ${invalidListIps.join(", ")}`
      : discoveryType === "3" && duplicateListIps.length > 0
      ? "Duplicate IP addresses are not allowed."
      : ""
  }
/> */}
            </Box>
          </Box>

          <Box
            sx={{
              mx: -4,
              width: "calc(100% + 68px)",
            }}
          >
            <Divider
              sx={{
                borderBottomWidth: "2px",
                borderColor: "#eee",
              }}
            />
          </Box>

          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              gap: 2,
              alignItems: "flex-start",
            }}
          >
            {/* FILE RADIO LABEL */}
            <Box
              sx={{
                minWidth: {
                  md: "200px",
                },
                display: "flex",
                alignItems: "center",
              }}
            >
              <FormControlLabel
                value="1"
                control={<Radio color="primary" size="small" />}
                label={
                  <Typography
                    sx={{
                      fontWeight: 500,
                    }}
                  >
                    File
                  </Typography>
                }
              />
            </Box>

            {/* FILE UPLOAD AREA */}
            <Box
              sx={{
                flex: 1,
                width: "100%",
                display: "flex",
                alignItems: "center",
                gap: 1.5,
              }}
            >
              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                hidden
                onChange={handleFileUpload}
              />

              {/* DOTTED FILE SELECTOR */}
              <Box
                onClick={() => {
                  if (discoveryType === "1") {
                    fileInputRef.current?.click();
                  }
                }}
                sx={{
                  flex: 1,
                  minHeight: "72px",
                  border: "2px dashed",
                  borderColor: discoveryType === "1" ? "#14348D" : "#d5d5d5",
                  borderRadius: "8px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 1.5,
                  px: 2,
                  cursor: discoveryType === "1" ? "pointer" : "not-allowed",
                  backgroundColor:
                    discoveryType === "1" ? "#fafbff" : "#f5f5f5",
                  transition: "all 0.2s ease",

                  "&:hover": {
                    backgroundColor:
                      discoveryType === "1" ? "#f1f4ff" : "#f5f5f5",
                    borderColor: discoveryType === "1" ? "#14348D" : "#d5d5d5",
                  },
                }}
              >
                <IosShare
                  sx={{
                    color: discoveryType === "1" ? "#14348D" : "#9e9e9e",
                    fontSize: 30,
                  }}
                />

                <Box>
                  <Typography
                    sx={{
                      fontSize: "14px",
                      fontWeight: 600,
                      color: discoveryType === "1" ? "#14348D" : "#757575",
                    }}
                  >
                    {selectedFile ? selectedFile.name : "Choose an Excel file"}
                  </Typography>

                  <Typography
                    variant="caption"
                    sx={{
                      color: "#757575",
                    }}
                  >
                    {selectedFile
                      ? `${fileIpAddresses.length} valid IP address(es) loaded`
                      : "Supported formats: .xlsx, .xls"}
                  </Typography>
                </Box>
              </Box>

              {/* UPLOAD ICON */}
              {/* <Tooltip title="Upload Excel">
                <span>
                  <IconButton
                    disabled={discoveryType !== "1"}
                    onClick={() => fileInputRef.current?.click()}
                    sx={{
                      color: "#14348D",
                      border: "1px solid #d6dcef",
                      borderRadius: "8px",
                      width: 48,
                      height: 48,
                      "&:hover": {
                        backgroundColor: "#f1f4ff",
                      },
                    }}
                  >
                    <UploadFileIcon />
                  </IconButton>
                </span>
              </Tooltip> */}

              {/* DOWNLOAD TEMPLATE ICON */}
              <Tooltip title="Download Excel Template">
                <span>
                  <IconButton
                    disabled={discoveryType !== "1"}
                    onClick={handleDownloadTemplate}
                    sx={{
                      color: "#14348D",
                      border: "1px solid #d6dcef",
                      borderRadius: "8px",
                      width: 40,
                      height: 40,
                      "&:hover": {
                        backgroundColor: "#f1f4ff",
                      },
                    }}
                  >
                    <DownloadIcon />
                  </IconButton>
                </span>
              </Tooltip>
            </Box>
          </Box>
          {discoveryType === "1" && fileIpAddresses.length > 0 && (
            <Typography
              variant="caption"
              sx={{
                ml: {
                  md: "200px",
                },
                color: "#2e7d32",
              }}
            >
              {fileIpAddresses.length} valid IP address(es) loaded from Excel.
            </Typography>
          )}
          <Box
            sx={{
              mx: -4,
              width: "calc(100% + 68px)",
            }}
          >
            <Divider
              sx={{
                borderBottomWidth: "2px",
                borderColor: "#eee",
              }}
            />
          </Box>

          <Box
            sx={{
              display: "flex",
              flexDirection: {
                xs: "column",
                md: "row",
              },
              gap: 2,
              alignItems: "flex-start",
            }}
          >
            <Box
              sx={{
                minWidth: {
                  md: "200px",
                },
                display: "flex",
                alignItems: "center",
              }}
            >
              <FormControlLabel
                value="2"
                control={<Radio color="primary" size="small" />}
                label={
                  <Typography
                    sx={{
                      fontWeight: 500,
                    }}
                  >
                    Individual IP
                  </Typography>
                }
              />
            </Box>

            <Box
              sx={{
                flex: 1,
                width: "100%",
              }}
            >
              {/* <FormField
                // label="IP Address"
                disabled={discoveryType !== "2"}
                value={individualIp}
                placeholder="___.___.___.___"
                // onChange={(event) => setIndividualIp(event.target.value)}
                // error={discoveryType === "2" && !isIndividualIpValid}
                onChange={handleIpInputChange}
                error={
                  discoveryType === "2" &&
                  individualIp !== "" &&
                  !isIndividualIpValid
                }
                errorMessage={
                  !isIndividualIpValid ? "Invalid IPv4 Address" : ""
                }
              /> */}
              <IPv4Input
                disabled={discoveryType !== "2"}
                value={individualIp}
                placeholder="___.___.___.___"
                onChange={(value) => setIndividualIp(value)}
                error={
                  discoveryType === "2" &&
                  individualIp !== "" &&
                  !isIndividualIpValid
                }
                helperText={
                  discoveryType === "2" &&
                  individualIp !== "" &&
                  !isIndividualIpValid
                    ? "Invalid IPv4 Address"
                    : ""
                }
              />
            </Box>
          </Box>
        </Box>
      </RadioGroup>
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-start",
          mt: 2,
        }}
      >
        <MButtonPrimary
          variant="contained"
          color="primary"
          startIcon={<PlayArrow />}
          disabled={!validateForm() || loading}
          onClick={handleDiscoverClick}
          sx={{
            px: 5,
          }}
        >
          Discover
        </MButtonPrimary>
      </Box>

      <MDialog
        open={dialogConfig.visible}
        icon={confirmation_icon}
        onClose={() =>
          setDialogConfig({
            visible: false,
            message: "",
          })
        }
        title="Confirmation"
        message={dialogConfig.message}
        confirmText="Yes"
        onConfirm={handleConfirmDiscovery}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />

      <CnmsDiscoveryProgressOverlay
        isOpen={discoveryProgress.isRunning}
        activeStep={discoveryProgress.activeStep}
        loading={loading}
        message={discoveryProgress.message}
      />
      <CnmsDiscoveryReportModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportData={reportData}
      />
    </MForm>
  );
};

export default CnmsDiscovery;
