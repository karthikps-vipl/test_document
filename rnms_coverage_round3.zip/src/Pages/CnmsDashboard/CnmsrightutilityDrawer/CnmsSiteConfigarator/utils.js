import { InventoryAxios } from '@/RestAPI/api/axiosApicall';
import { FETCH_ALL_SITE_DETAILS, FETCH_ALL_SITE_GROUPS } from '@/RestAPI/url/cnmsEndPoint';
import { setAllSiteGroups } from '@/store/features/Cnms/mapViewSlice';
import { setFetchSiteDetails } from '@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice';
import { useDispatch } from 'react-redux';


export const useSiteDetails = () => {
  const dispatch = useDispatch();

  const refreshSiteDetails = async () => {
    try {
      const res = await InventoryAxios(FETCH_ALL_SITE_DETAILS, "get");
      console.log("FETCH_ALL_SITE_DETAILS success:", res?.data);
      
      if (res?.data) {
        dispatch(setFetchSiteDetails(res.data));
      }
      return res.data;
    } catch (error) {
      console.error("Error refreshing site details:", error);
      throw error; // Re-throw so the calling component knows it failed
    }
  };


  const refreshSiteGroups = async () => {
    try {
      const res = await InventoryAxios(FETCH_ALL_SITE_GROUPS, "get");
      const groupData = res?.data?.data || [];
      
      dispatch(setAllSiteGroups(groupData));
      return groupData;
    } catch (error) {
      console.error("FETCH_ALL_SITE_GROUPS Error:", error);
      throw error;
    }
  };

  return { refreshSiteDetails,refreshSiteGroups };
};