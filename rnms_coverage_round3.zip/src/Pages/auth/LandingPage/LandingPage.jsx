/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : LandingPage
   File Name                : LandingPage.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\auth\LandingPage\LandingPage.jsx
   Purpose                  : The purpose is to show the landing page of IAF-NMS. 
   Created Date             : 05-01-2026
 *******************************************************************************************/
 
import React, { useEffect, useState } from "react";
import Typography from "@mui/material/Typography";
import { Box, Button, Grid } from "@mui/material";
//import vehicleImage from "../../../assets/svg/vechile.svg";
import vehicleImage from "../../../assets/svg/MCT-MK-III-Vehicle-Image.png";
import { useNavigate } from "react-router-dom";
import Wifi from "../LandingPage/WifiDesign";
import { useDispatch, useSelector } from "react-redux";
import {
  setDeployedSiteDetails,
  setIsCnms,
  setRepDetails,
} from "../../../store/features/nodeDetailsSlice";
import { AuthAxios, InventAxios } from "../../../RestAPI/api/axiosApicall";
import {
  DEPLOYED_TERMINAL_TYPE,
  FETCH_CNMS_DETAILS,
  NODE_DETAILS,
  VALIDATE_IP,
} from "../../../RestAPI/url/endpoint";
import {
  setInitialEdges,
} from "../../../store/features/Topology/topologyNodesslice";
// page 1 - Login Page
// page 2 - Configure page
import cnmslanding from "@/assets/SVGIcons/cnms/cnmslanding.png";
import Loader from "@/components/Reusable/Loader/Loader";

const LandingPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const LOGIN_WITH_ATP = window.isRNMS_LOGIN_ATP;
  
  const [isLoginEnable, setIsLoginEnable] = useState(false);
  const [validateIpMsg, setValidateIpMsg] = useState("");
  const [page, setPage] = useState(0);
  // This is the value we use for the condition
  const { isCnms } = useSelector((state) => state.nodeDetails);
  
  const fetchNodeDetails = async (isCnmsFlag) => {
    InventAxios(!isCnmsFlag ? NODE_DETAILS : FETCH_CNMS_DETAILS, "get")
      .then((res) => {
        if (res?.data) {
          setPage(1);
          dispatch(setRepDetails(res.data));
        } else {
          setPage(2);
        }
      })
      .catch((error) => {
        console.error(error, "rrrrr");
        setPage(2);
      });
  
    AuthAxios(VALIDATE_IP, "post")
      .then((res) => {
        setValidateIpMsg(res?.data?.message);
        if (res.data.status == 1) {
          setIsLoginEnable(false);
        } else {
          setIsLoginEnable(true);
        }
      })
      .catch((err) => {
        console.error("Error:", err);
        setIsLoginEnable(true);
      });
  };
  useEffect(() => {
    let retryTimer = null; // Variable to store the timeout ID
  
    const fetchDeployedTerminalType = async () => {
      try {
        const response = await InventAxios(DEPLOYED_TERMINAL_TYPE, "get");
  
        if (response?.data) {
          let isCnmsFlag = false;
          
          // 1. Update State with Site Details
          dispatch(setDeployedSiteDetails(response?.data));
          
          // 2. Check for CNMS Flag
          if (response?.data?.id === 1) {
            dispatch(setIsCnms(true));
            isCnmsFlag = true;
          }
  
          // 3. Handle Topology Data
          if (response?.data?.topologyData) {
            const data = JSON.parse(response?.data?.topologyData || "{}");
            // Optional: Uncomment normalize/filter logic if needed
            // const normalizedNodes = data.nodes.map(normalizeTopologyNode);
            // const filteredNodes = normalizedNodes.filter((item) => item.type === "commonNode");
            dispatch(setInitialEdges(data.edges));
          }
  
          // 4. Handle Rack View Data
          if (response?.data?.rackViewData) {
            // const data1 = JSON.parse(response?.data?.rackViewData);
          }
  
          // 5. Fetch Node Details based on flag
          fetchNodeDetails(isCnmsFlag);
        }
      } catch (error) {
        console.log("Error fetching terminal type:", error);
  
        // --- RETRY LOGIC STARTS HERE ---
        
        // Check if we want to retry (you can add a maxRetryCount if needed)
        // For now, we assume infinite retry as per your previous snippet
        
        // Set timeout for 5 seconds (5000ms)
        retryTimer = setTimeout(() => {
          console.log("Retrying in 5 seconds...");
          fetchDeployedTerminalType(); // Call the function again
        }, 5000);
        
        // --- RETRY LOGIC ENDS HERE ---
      }
    };
  
    // Initial call
    fetchDeployedTerminalType();
  
    // Cleanup function (Important for useEffect)
    // Clears the timer if the component unmounts or dependencies change
    return () => {
      if (retryTimer) {
        clearTimeout(retryTimer);
      }
    };
  }, []);
  return (
    <Grid
      container
      sx={{
        height: "100vh",
        background: isCnms
          ? `url(${cnmslanding}) no-repeat center center / cover`
          : (theme) => theme.palette.customGradients.landing,
        overflow: "hidden",
        position: "relative",pb:6,
        
      }}
    >
      {/* LEFT SIDE GRID (Vehicle & Wifi - Hidden if CNMS) */}
      <Grid
        item
        xs={12}
        sm={6}
        md={6}
        lg={7}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
          height: "70vh",
        }}
      >
        {!isCnms && (
          <Box
            sx={{
              mr: 2,
              padding: "10px",
              position: "relative",
              maxWidth: "90vw",
              mt: 5,
            }}
          >
            <img src={vehicleImage} alt="Vehicle" style={{ width: "90%" }} />
            <Wifi position="top" />
            <Wifi position="right" />
            <Wifi position="left" />
          </Box>
        )}
      </Grid>
    
      {/* RIGHT SIDE GRID (Buttons + New Text) */}
      <Grid
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          width: "100%",
          gap: 2,
          position: "relative",
          // Optional: Add padding to ensure text doesn't touch edges
          px: 2,
           
        }}
      >
        {/* 
          NEW SECTION: 
          Only renders when isCnms is true.
          Placed above the button.
        */}
        {isCnms && (
          <>
            <Typography
              variant="h3"
              sx={{
                color: "#FFFFFF",
                fontWeight: "bold",
                mt:- 5,
        
                textTransform: "none",
                letterSpacing: "0.5px",
              }}
            >
              Central Network Management System
            </Typography>
            
            {/* <Typography
              variant="h11"
              sx={{
                color: "#FFFFFF",
                 fontWeight: 400,
                textTransform: "none",
                opacity: 0.9,
              }}
            >
              A Secure Platform for network Monitoring,Management and Operational control.
            </Typography> */}
          </>
        )}
  
        {/* BUTTONS */}
        {page === 1 ? (
          <Button
            variant="contained"
            disabled={isLoginEnable}
            sx={{
              borderRadius: "11px",
              width: "12%",
              textTransform: "none",
              backgroundColor: "#14348D",
              color: "white",
              fontFamily: "Montserrat",
              fontWeight: "Medium",
             
              ...(isLoginEnable
                ? {
                    backgroundColor: "gray !important",
                    color: "white !important",
                    opacity: 0.5,
                  }
                : {}),
            }}
            onClick={() => {
              if (isCnms) {
                // Check if it's CNMS to decide which path to navigate to
                navigate("/login"); 
              }
                else if (LOGIN_WITH_ATP) {
                  navigate("/loginATP"); // The new path for CNMS
                } 
               else {
                navigate("/login");
              }
            }}
          >
            Login
          </Button>
        ) : page === 2 ? (
          <Button
            variant="contained"
            disabled={isLoginEnable}
            sx={{
              borderRadius: "11px",
              width: "12%",
              textTransform: "none",
              backgroundColor: "#14348D",
              color: "white",
              fontFamily: "Montserrat",
              fontWeight: "Medium",
              ...(isLoginEnable
                ? {
                    backgroundColor: "gray !important",
                    color: "white !important",
                    opacity: 0.5,
                  }
                : {}),
            }}
            onClick={() =>
              isCnms ? navigate("/cnmsconfigurator") : navigate("/configurator")
            }
          >
            Configure
          </Button>
        ) : (
       
          <Loader/>
   
        )}
        
        {/* Error Message Box */}
        {validateIpMsg && (
          <Box
            sx={{ backgroundColor: "#D75961", borderRadius: "10px", mb: -2 }}
          >
            <Typography color="white" sx={{ p: 0.5 }}>
              {validateIpMsg}
            </Typography>
          </Box>
        )}
      </Grid>
   
      {/* FOOTER GRID */}
      <Grid
        item
        xs={12}
        sx={{
          mb: "2%",
          width: "100%",
          textAlign: "center",
          mt:4
        }}
      >
        <Typography
          variant="h11"
          sx={{
            color: "#FFFFFF",
            fontFamily: "Montserrat",
          }}
        >
          Best Viewed in Google Chrome (v 136.0+) and Mozilla Firefox(v 130+)
        </Typography>
      </Grid>
    </Grid>
  );
  
  
  
}

export default LandingPage;
