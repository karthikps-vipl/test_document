/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : LandingPage
   File Name                : WifiDesign.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\auth\LandingPage\WifiDesign.jsx
   Purpose                  : The purpose is to show the working functionality for the landing page of IAF-NMS. 
   Created Date             : 05-01-2026
 *******************************************************************************************/
import React from "react";
import { Box, useTheme } from "@mui/material";
import Lottie from "lottie-react";
import wifiAnimation from "../../../assets/Json/wifiSignal.json";

export default function WifiDesign({ position = "top", size = 180 }) {
  const config = {
    left: {
      sx: {
        position: "absolute",
        left: "-20%",
        top: "50%",
        transform: "rotate(0deg)",
      },
      rotate: -90,
    },
    right: {
      sx: {
        position: "absolute",
        right: "-10%",
        top: "50%",
        transform: "rotate(0deg)",
      },
      rotate: 90,
    },
    top: {
      sx: {
        position: "absolute",
        top: "3%",
        left: "30%",
        transform: "rotate(30deg)",
      },
      rotate: 0,
    },
  };
  const theme = useTheme();
  const isdarkmode = theme.palette.mode === "dark";

  const selectedConfig = position in config ? config[position] : config.top; // Use config.top as a default

  return (
    <Box
      sx={{
        position: "absolute",
        ...selectedConfig.sx,
        transform: selectedConfig.rotate
          ? "rotate(" + selectedConfig.rotate + "deg)"
          : "rotate(0deg)",
        filter: isdarkmode ? "brightness(0) invert(1)" : "none",
        // Optional: if you want it slightly transparent in dark mode
        opacity: isdarkmode ? 0.8 : 1,
      }}
    >
      <Lottie animationData={wifiAnimation} style={{ width: size }} />
    </Box>
  );
}
