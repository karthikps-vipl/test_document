import MModal from "@/components/Reusable/Modal/MModal";
import { resetAuthStatus } from "@/store/features/Logout/authSlice";
import useLogout from "@/utility/customHooks/useLogout";
import { LogoutTwoTone } from "@mui/icons-material";
import { Box, Typography } from "@mui/material";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const SessionLogoutModal = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const { logoutHandler } = useLogout();

    const [isProcessing, setIsProcessing] = useState(false);
    const userDetails = useSelector((state) => state.userSlice.userDetails?.data);
    const userName = userDetails?.userName || "";
    const rnmsDetailId = userDetails?.rnmsDetailId || "";

    // 2. Get the logout notification status from Redux
    const { isLogoutPending, logoutMessage, targetUser } = useSelector(
        (state) => state.auth
    );
    const expectedMessageString = `${userName}${rnmsDetailId}`;
 
    const shouldShowModal = isLogoutPending && 
                            targetUser === expectedMessageString;
    const handleModalClose = async () => {
        if (isProcessing) return;

        setIsProcessing(true);

        try {
            await logoutHandler();
        } catch (error) {
            console.error("Logout error:", error);
        } finally {
            // Always clear local authentication state
            dispatch(resetAuthStatus());

            // Redirect to login
            navigate("/login", { replace: true });

            setIsProcessing(false);

            // IMPORTANT: Close the modal after the redirect logic starts
            // This ensures the user doesn't see the modal while navigating
            handleClose();
        }
    };

    // Define the onClose handler for the Modal component
    const handleClose = () => {

    };


    return (
        <MModal
            open={shouldShowModal}
            title="Session Terminated"
            customWidth={"400px"}
            fullWidth
            showCloseButton={false}
            // Pass the close handler here. 
            // Note: You may need to adjust this based on how your MModal component is defined.
            onClose={handleModalClose}
        >
            <Box
                sx={{
                    display: "flex",
                    flexDirection: "column",

                    gap: 1,

                }}
            >
                <Box
                    sx={{
                        display: 'flex',

                        gap: 1,
                        color: 'error.main', // Red color for logout/warning
                        fontSize: 30, // Large icon size
                    }}
                >
                    <LogoutTwoTone fontSize="inherit" />
                    <Typography  fontWeight="bold" color="error.main">
                        Logging Out ...
                    </Typography>
                </Box>
                <Typography
                    sx={{
                        fontSize: '16px',
                        color: 'text.primary',
                        // Optional: Make the whole line bold if you prefer that style

                    }}
                >
                    {logoutMessage
                        ? `${logoutMessage} `
                        : `As new login request has come up for the user `}

                    {/* Pass the name as a separate child element */}
                    <strong>{userName}!</strong>
                </Typography>

                {/* Button Removed */}

                {/* Optional: Add a spinner or loading indicator if you want visual feedback while processing */}
                {isProcessing && (
                    <CircularProgress size={24} color="inherit" sx={{ mt: 2 }} />
                )}
            </Box>
        </MModal>
    );
};

export default SessionLogoutModal;