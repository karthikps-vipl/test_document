/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : configurator
   File Name                : SucessConfigarator.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\auth\configurator\SucessConfigarator.jsx
   Purpose                  : The purpose is to show the Success Message after creating the configurator page. 
   Created Date             : 02-01-2026
 *******************************************************************************************/
// import { Box, Typography, Button, useTheme, CircularProgress } from "@mui/material";
// import { useNavigate } from "react-router-dom";
// import { CheckCircleOutline } from "@mui/icons-material";
// import { useSelector } from "react-redux";
// import { useState } from "react";

// const SuccessConfigurator = () => {
//   const { savedRnmsDetails } = useSelector((state) => state.nodeDetails);
//   const [isLoading, setIsLoading] = useState(false);
//   const navigate = useNavigate();
//   // const handleLogin = () => {
//   //   navigate("/signin");
//   // };
//   const handleLogin = async () => {
//     setIsLoading(true); // Start loading

//     try {
//       // Simulate an API call/Backend response delay
//       // In your real code, replace this with your actual API call logic
//       await new Promise((resolve) => setTimeout(resolve, 2000)); 

//       navigate("/signin");
//     } catch (error) {
//       console.error("Navigation failed", error);
//     } finally {
//       setIsLoading(false); // Stop loading regardless of success/fail
//     }
//   };

// const theme=useTheme()
//   return (
//     <Box
//       sx={{
//         height: "85vh",
//         width: "90vw",
//         backgroundColor: theme.palette.custom.configuration.configmodal,
//         border: "1px solid #e2e2e2",
//         borderRadius: "50px",
//         display: "flex",
//         flexDirection: "column",
//         alignItems: "center",
//         justifyContent: "center",
//         margin: "2% 5% 0% 5%",
//         position: "relative",
//         "@media (maxWidth: 600px)": {
//           height: "90vh",
//           width: "95vw",
//           marginTop: "10%",
//           marginLeft: "2.5%",
//           marginRight: "2.5%",
//         },
//       }}
//     >
//       {/* <Header /> */}
//       <Box
//         sx={{
//           position: "relative",
//           width: "40%",
//           backgroundColor:  theme.palette.custom.configuration.configbg,
//           borderRadius: "20px",
//           height: "50%",
//           top: 1,
//         }}
//       >
//         <Box
//           sx={{
//             backgroundColor: theme.palette.custom.configuration.configsucess,
//             height: "25%",
//             width: "100%",
//             marginBottom: "10px",
//             fontFamily: "Montserrat",
//             borderRadius: "20px 10px 0 0",
//             position: "relative",
//           }}
//         />
//         <CheckCircleOutline
//           sx={{
//             position: "absolute",
//             top: "15%",
//             left: "45%",
//             transform: "translateY(-50%)",
//             color: "green",
//             fontSize: "60px",
//           }}
//         />
//         <Box
//           sx={{
//             width: "100%",
//             textAlign: "left",
//             height: "50%",
//             justifyContent: "center",
//           }}
//         >
//           <Typography
//             sx={{
//               fontFamily: "Montserrat",
//               fontWeight: "Medium",
//               textAlign: "center",
//               alignContent: "center",
//               mt: 2,
//             }}
//           >
//             The RNMS for {savedRnmsDetails?.imTerminalType?.terminalTypeName} #
//             {savedRnmsDetails?.remoteNumber} Site Data created successfully
//           </Typography>

//           <Box
//             sx={{
//               display: "flex",
//               justifyContent: "center",
//               gap: "30px",
//               mt: 2,
//             }}
//           >
//             <Box
//               sx={{
//                 // color: "grey",
//                 display: "flex",
//                 flexDirection: "column",
//                 gap: "7px",
//               }}
//             >
//               <Box>Remote #</Box>
//               <Box>Remote Site Name</Box>
//               <Box>Remote Type</Box>
//             </Box>
//             <Box sx={{ display: "flex", flexDirection: "column", gap: "7px" }}>
//               <Box>{savedRnmsDetails?.remoteNumber}</Box>
//               <Box>{savedRnmsDetails?.siteName}</Box>
//               <Box>{savedRnmsDetails?.imTerminalType?.terminalTypeName}</Box>
//             </Box>
//           </Box>
//         </Box>
//         <Box sx={{ borderTop: "2px solid #ccc", mt: -4 }} />
//         <Box sx={{ display: "flex", justifyContent: "center", gap: 4, mt: 2 }}>
//           <Button
//             variant="contained"
//             disabled={isLoading}
//             sx={{
//               width: "15%",
//               display: "flex",

//               backgroundColor: "#14348D",
//               fontFamily: "Montserrat",
//               fontWeight: "Medium",

//               textTransform: "none",
//               minWidth: "100px",
//             //border:theme.palette.custom.border,
//             //color:"text.TitleTextcolor",
//             borderRadius:'10px'
//             }}
//             onClick={handleLogin}
//           >
//             {isLoading ? <CircularProgress size={24} color="inherit" /> : "Login"}
//           </Button>
//           <Button
//             variant="outlined"
//             disabled={isLoading}
//             sx={{
//               fontFamily: "Montserrat",
//               fontWeight: "Medium",
//               width: "15%",
//               borderRadius: "10px",
//               border:theme.palette.custom.border,
//               color:"text.TitleTextcolor",
//             }}
//             onClick={() => navigate("/Configarator")}
//           >
//             Close
//           </Button>
//         </Box>
//       </Box>
//     </Box>
//   );
// };

// export default SuccessConfigurator;

import {
  Box,
  Typography,
  Button,
  useTheme,
  CircularProgress,
} from "@mui/material";

import { useNavigate } from "react-router-dom";
import { CheckCircleOutline } from "@mui/icons-material";
import { useSelector } from "react-redux";
import { useState } from "react";

const SuccessConfigurator = () => {
  const { savedRnmsDetails, isCnms } = useSelector(
    (state) => state.nodeDetails
  );
  console.log("savedRnmsDetails", savedRnmsDetails)
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const theme = useTheme();
  const LOGIN_WITH_ATP = window.isRNMS_LOGIN_ATP;
 

  const handleLogin = async () => {
    setIsLoading(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      if (LOGIN_WITH_ATP) {
        navigate("/loginATP"); // The new path for CNMS
      } 
     else {
      navigate("/login");
    }
    } catch (error) {
      console.error("Navigation failed", error);
    } finally {
      setIsLoading(false);
    }
  };


  const cnmsData = Array.isArray(savedRnmsDetails)
    ? savedRnmsDetails
    : [];

  const rnmsData = Array.isArray(savedRnmsDetails)
    ? savedRnmsDetails[0]
    : savedRnmsDetails;

  return (
    <Box
      sx={{
        height: "85vh",
        width: "90vw",
        backgroundColor:
          theme.palette.custom.configuration.configmodal,
        border: "1px solid #e2e2e2",
        borderRadius: "50px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        margin: "2% 5% 0% 5%",
        position: "relative",

        "@media (maxWidth: 600px)": {
          height: "90vh",
          width: "95vw",
          marginTop: "10%",
          marginLeft: "2.5%",
          marginRight: "2.5%",
        },
      }}
    >

      {!isCnms && (
        <Box
          sx={{
            position: "relative",
            width: "40%",
            backgroundColor:
              theme.palette.custom.configuration.configbg,
            borderRadius: "20px",
            minHeight: "50%",
            top: 1,

            "@media (maxWidth: 900px)": {
              width: "60%",
            },

            "@media (maxWidth: 600px)": {
              width: "90%",
            },
          }}
        >
          {/* SUCCESS HEADER */}
          <Box
            sx={{
              backgroundColor:
                theme.palette.custom.configuration.configsucess,
              height: "25%",
              width: "100%",
              marginBottom: "10px",
              fontFamily: "Montserrat",
              borderRadius: "20px 10px 0 0",
              position: "relative",
            }}
          />

          <CheckCircleOutline
            sx={{
              position: "absolute",
              top: "15%",
              left: "45%",
              transform: "translateY(-50%)",
              color: "green",
              fontSize: "60px",
            }}
          />

          {/* CONTENT */}
          <Box
            sx={{
              width: "100%",
              textAlign: "left",
              minHeight: "50%",
              justifyContent: "center",
            }}
          >
            <Typography
              sx={{
                fontFamily: "Montserrat",
                fontWeight: "Medium",
                textAlign: "center",
                alignContent: "center",
                mt: 2,
                px: 2,
              }}
            >
              The RNMS for{" "}
              {rnmsData?.imTerminalType?.terminalTypeName} #
              {rnmsData?.remoteNumber} Site Data created successfully
            </Typography>

            {/* RNMS DETAILS */}
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "flex-start",
                gap: "30px",
                mt: 2,
                px: 2,
              }}
            >
              {/* LABELS */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "7px",
                }}
              >
                <Box>Remote #</Box>
                <Box>Remote Site Name</Box>
                <Box>Remote Type</Box>
              </Box>

              {/* VALUES */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "7px",
                }}
              >
                <Box>{rnmsData?.remoteNumber}</Box>
                <Box>{rnmsData?.siteName}</Box>
                <Box>
                  {rnmsData?.imTerminalType?.terminalTypeName}
                </Box>
              </Box>
            </Box>
          </Box>

          {/* DIVIDER */}
          <Box
            sx={{
              borderTop: "2px solid #ccc",
              mt: 2,
            }}
          />

          {/* BUTTONS */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              gap: 4,
              mt: 2,
              mb: 3,
            }}
          >
            <Button
              variant="contained"
              disabled={isLoading}
              sx={{
                width: "15%",
                display: "flex",
                backgroundColor: "#14348D",
                fontFamily: "Montserrat",
                fontWeight: "Medium",
                textTransform: "none",
                minWidth: "100px",
                borderRadius: "10px",
              }}
              onClick={handleLogin}
            >
              {isLoading ? (
                <CircularProgress size={24} color="inherit" />
              ) : (
                "Login"
              )}
            </Button>

            <Button
              variant="outlined"
              disabled={isLoading}
              sx={{
                fontFamily: "Montserrat",
                fontWeight: "Medium",
                width: "15%",
                minWidth: "100px",
                borderRadius: "10px",
                border: theme.palette.custom.border,
                color: "text.TitleTextcolor",
              }}
              onClick={() => navigate("/Configarator")}
            >
              Close
            </Button>
          </Box>
        </Box>
      )}

{isCnms&&(<Box sx={{fontSize:"25px",
 
}}>
CNMS Configurator
</Box>)}
  

      {isCnms && (
        <Box
          sx={{
            position: "relative",
            width: "55%",
            backgroundColor:
              theme.palette.custom.configuration.configbg,
            borderRadius: "20px",
            minHeight: "55%",
            maxHeight: "80vh",
            overflowY: "auto",
mt:2,
            "@media (maxWidth: 1100px)": {
              width: "70%",
            },

            "@media (maxWidth: 700px)": {
              width: "90%",
            },
          }}
        >
          {/* SUCCESS HEADER */}
          <Box
            sx={{
              backgroundColor:
                theme.palette.custom.configuration.configsucess,
              height: "110px",
              width: "100%",
              fontFamily: "Montserrat",
              borderRadius: "20px 10px 0 0",
              position: "relative",
            }}
          />

          {/* SUCCESS ICON */}
          <CheckCircleOutline
            sx={{
              position: "absolute",
              top: "75px",
              left: "50%",
              transform: "translate(-50%, -50%)",
              color: "green",
              fontSize: "60px",

              borderRadius: "50%",
            }}
          />

          {/* CNMS TITLE */}
          <Box
            sx={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
              mt: 3,
              px: 2,
            }}
          >
            <Typography
              sx={{
                fontFamily: "Montserrat",
                fontWeight: 500,
                textAlign: "center",
              }}
            >
              The CNMS Site Data was created successfully
            </Typography>
          </Box>


          <Box
            sx={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              mt: 3,
              px: 3,
              gap: 2,
            }}
          >
            {cnmsData.map((site, index) => (
              <Box
                key={site?.id || site?.remoteNumber || index}
                sx={{
                  width: "85%",
                  border: "1px solid #ddd",
                  borderRadius: "12px",
                  padding: "18px 25px",
                  backgroundColor: "#fff",
                }}
              >
                {/* SITE NAME */}
                <Typography
                  sx={{
                    fontFamily: "Montserrat",
                    fontWeight: 700,
                    textAlign: "center",
                    mb: 2,
                    fontSize: "20px",
                    color:"#14348d"


                  }}
                >
                  {site?.siteName}
                </Typography>

                {/* DETAILS */}
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    width: "100%",
                    gap: "8px",
                  }}
                >
                  {/* Remote # */}
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "150px 20px 180px",
                      alignItems: "center",
                      width: "350px",
                      maxWidth: "100%",
                    }}
                  >
                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "right",
                        fontWeight: 500,
                      }}
                    >
                      Site
                    </Typography>

                    <Typography
                      sx={{
                        textAlign: "center",
                        fontWeight: 500,
                      }}
                    >
                      :
                    </Typography>

                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "left",
                        fontWeight: 600,
                      }}
                    >
                      DC
                      {/* {site?.remoteNumber} */}
                    </Typography>
                  </Box>

                  {/* Remote Site Name */}
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "150px 20px 180px",
                      alignItems: "center",
                      width: "350px",
                      maxWidth: "100%",
                    }}
                  >
                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "right",
                        fontWeight: 500,
                      }}
                    >
                      Site Name
                    </Typography>

                    <Typography
                      sx={{
                        textAlign: "center",
                        fontWeight: 600,
                      }}
                    >
                      :
                    </Typography>

                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "left",
                        wordBreak: "break-word",
                        fontWeight: 600,
                      }}
                    >
                      {site?.siteName}
                    </Typography>
                  </Box>

                  {/* Remote Type */}
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "150px 20px 180px",
                      alignItems: "center",
                      width: "350px",
                      maxWidth: "100%",
                    }}
                  >
                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "right",
                        fontWeight: 500,
                      }}
                    >
                      Latitude
                    </Typography>

                    <Typography
                      sx={{
                        textAlign: "center",
                        fontWeight: 600,
                      }}
                    >
                      :
                    </Typography>

                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "left",
                        fontWeight: 600,
                      }}
                    >
                      {site?.latitude}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "150px 20px 180px",
                      alignItems: "center",
                      width: "350px",
                      maxWidth: "100%",
                    }}
                  >
                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "right",
                        fontWeight: 500,
                      }}
                    >
                      Longitude
                    </Typography>

                    <Typography
                      sx={{
                        textAlign: "center",
                        fontWeight: 500,
                      }}
                    >
                      :
                    </Typography>

                    <Typography
                      sx={{
                        fontFamily: "Montserrat",
                        textAlign: "left",
                        fontWeight: 600,
                      }}
                    >
                      {site?.longitude}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            ))}
          </Box>

          {/* DIVIDER */}
          <Box
            sx={{

              mt: 3,
              mx: 3,
            }}
          />

          {/* BUTTONS */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              gap: 4,
              mt: 2,
              mb: 3,
            }}
          >
        

            <Button
              variant="outlined"
              disabled={isLoading}
              sx={{
                fontFamily: "Montserrat",
                fontWeight: "Medium",
                width: "15%",
                minWidth: "100px",
                borderRadius: "10px",
                border: theme.palette.custom.border,
                color: "text.TitleTextcolor",
              }}
              onClick={() => navigate("/Configarator")}
            >
              Close
            </Button>
            <Button
              variant="contained"
              disabled={isLoading}
              sx={{
                width: "15%",
                display: "flex",
                backgroundColor: "#14348D",
                fontFamily: "Montserrat",
                fontWeight: "Medium",
                textTransform: "none",
                minWidth: "100px",
                borderRadius: "10px",
              }}
              onClick={handleLogin}
            >
              {isLoading ? (
                <CircularProgress size={24} color="inherit" />
              ) : (
                "Login"
              )}
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default SuccessConfigurator;
