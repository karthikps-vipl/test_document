/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : configurator
   File Name                : Configuration.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\auth\configurator\Configuration.jsx
   Purpose                  : The purpose is to show the configurator page. 
   Created Date             : 03-01-2026
 *******************************************************************************************/
import React, { useState, useMemo } from "react"; // Added useMemo
import { Box, Typography, Button, useTheme, CircularProgress } from "@mui/material";
import {
  AddCircleOutlineOutlined,
  VisibilityOutlined,
  InfoOutlineRounded,
  EditOutlined,
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import MInput from "../../../components/Reusable/Input/MInput";
import MTable from "../../../components/Reusable/Table/MTable";
import MModal from "../../../components/Reusable/Modal/MModal";
import { FormControl, Select, MenuItem } from "@mui/material";
import { useFormik } from "formik";
import {
  SiteNumberValidator,
  SitenameValidator ,
  personnelNameValidation,
  rankValidation,
  unitValidation,
  primaryMobileValidation,
  afcelPhoneValidation,
  ipPhoneValidation,
  alternateMobileValidation,
  emailValidation,
  SiteNicknameValidator,
} from "../../../utility/FormValidation/YupSchema";
import { SitenameRegex ,SiteNicknameRegex} from "../../../utility/FormValidation/Regex";
import {
  personnelRegex,
  validateInput,
} from "../../../utility/FormValidation/Regex";

import { siteNumRegex } from "../../../utility/FormValidation/Regex";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import EditRepDetails from "./EditRepDetails";
import MButtonPrimary from "../../../components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "../../../components/Reusable/Button/MButtonSecondary";
import MDialog from "../../../components/Reusable/Dialog/MDialog";
import { InventAxios } from "../../../RestAPI/api/axiosApicall";
import { SAVE_RNMS_DETAILS } from "../../../RestAPI/url/endpoint";
import Toast from "../../../components/Reusable/Toast/Toast";
import clear from "@/assets/SVGIcons/clear.svg";
import {
  setRepDetails,
  setSavedRnmsDetails,
} from "../../../store/features/nodeDetailsSlice";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
 
const Configuration = () => {
  const theme=useTheme()
  const { repDetails, siteDetails } = useSelector((state) => state.nodeDetails);
  const dispatch = useDispatch();
const terminalName =siteDetails?.terminalTypeName 
const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [repTableData, setRepTableData] = useState(
    repDetails?.resRepDetails || []
  );

  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isAddMode, setIsAddMode] = useState(true);



  const [editModalOpen, setEditModalOpen] = useState({
    visible: false,
    rowData: null,
  });

  const [deleteAllRowsConfirm, setDeleteAllRowsConfirm] = useState(false);
  const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });

  const navigate = useNavigate();
  const maxRepresentatives = 5;

  const handleAddButtonClick = () => {
    if (repTableData.length < maxRepresentatives) {
      handleAddRepFieldsClear();
      setIsModalOpen(true);
    } else {
      Toast(
        "Limit Reached!",
        "You have reached the maximum of 5 representatives.",
        "warning"
      );
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    handleAddRepFieldsClear();
  };

  const handleAddRepFieldsClear = () => {
    formik.setFieldValue("personalName", "", false);
    formik.setFieldValue("rank", "", false);
    formik.setFieldValue("unit", "", false);
    formik.setFieldValue("primaryCivilMobile", "", false);
    formik.setFieldValue("afcelPhone", "", false);
    formik.setFieldValue("ipPhone", "", false);
    formik.setFieldValue("altCivilMobile", "", false);
    formik.setFieldValue("email", "", false);
    formik.setFieldTouched("personalName", "", false);
    formik.setFieldTouched("rank", "", false);
    formik.setFieldTouched("unit", "", false);
    formik.setFieldTouched("primaryCivilMobile", "", false);
    formik.setFieldTouched("afcelPhone", "", false);
    formik.setFieldTouched("ipPhone", "", false);
    formik.setFieldTouched("altCivilMobile", "", false);
    formik.setFieldTouched("email", "", false);
  };

  const handlePreview = () => {
    setIsReviewMode(true);
    setIsPreviewMode(true);
    setIsAddMode(false);

    setTableColumns((prevCols) =>
      prevCols.filter((item) => item.uid !== "actions")
    );
  };

  // const handleSucess = async () => {
  //   setIsLoading(true);
  //   const repDetailsForPayload = repTableData.map((item) => ({
  //     personnelName: item.personnelName,
  //     personnel: item.personnel,
  //     unit: item.unit,
  //     ipPhone: item.ipPhone,
  //     afcel: item.afcel,
  //     primaryCivilMobile: item.primaryCivilMobile,
  //     alternateCivilMobile: item.alternateCivilMobile,
  //     email: item.email,
  //     serial: 1,
  //   }));

  //   const payload = {
  //     remoteNumber: parseInt(formik.values.siteNumber),
  //     siteName: formik.values.siteName,
  //     siteNickName: formik.values.siteNickName,
  //     isConfigured: true,
  //     imTerminalType: { id: siteDetails?.id },
  //     imTerminalMode: { id: 2 },
  //     resRepDetails: repDetailsForPayload,
  //   };

  //   const resp = await InventAxios(SAVE_RNMS_DETAILS, "post", payload);

  //   if (resp.status == 200 && resp.data) {
  //     dispatch(setSavedRnmsDetails(resp.data));
  //     dispatch(setRepDetails(resp.data));
  //     navigate("/SucessConfigarator");
  //     Toast("Success!", "Successfully added rnms", "success");
  //   } else {
  //     Toast("Failed!", "Failed to add rnms details", "error");
  //   }
  //   setIsLoading(false);
  // };
  const handleSucess = async () => {
    if (isLoading) return;
  
    setIsLoading(true);
  
    try {
      const repDetailsForPayload = repTableData.map((item) => ({
        personnelName: item.personnelName,
        personnel: item.personnel,
        unit: item.unit,
        ipPhone: item.ipPhone,
        afcel: item.afcel,
        primaryCivilMobile: item.primaryCivilMobile,
        alternateCivilMobile: item.alternateCivilMobile,
        email: item.email,
        serial: 1,
      }));
  
      const payload = {
        remoteNumber: parseInt(formik.values.siteNumber, 10),
        siteName: formik.values.siteName,
        siteNickName: formik.values.siteNickName,
        isConfigured: true,
        imTerminalType: { id: siteDetails?.id },
        imTerminalMode: { id: 2 },
        resRepDetails: repDetailsForPayload,
      };
  
      console.log("BEFORE API");
  
      const resp = await InventAxios(
        SAVE_RNMS_DETAILS,
        "post",
        payload
      );
  
      console.log("AFTER API", resp);
  
      if (resp?.status === 200 && resp?.data) {
        console.log("DISPATCHING DATA");
  
        dispatch(setSavedRnmsDetails(resp.data));
        dispatch(setRepDetails(resp.data));
  
        Toast(
          "Success!",
          "Successfully added rnms",
          "success"
        );
  
        console.log("NAVIGATING");
  
        navigate("/SucessConfigarator");
      } else {
        Toast(
          "Failed!",
          "Failed to add rnms details",
          "error"
        );
      }
    } catch (error) {
      console.error("API ERROR:", error);
  
      Toast(
        "Error!",
        "A network error occurred",
        "error"
      );
    } finally {
      console.log("STOPPING LOADER");
      setIsLoading(false);
    }
  };
  
  
  
  const handleEdit = (row) => {
    setEditModalOpen({ visible: true, rowData: row });
  };

  const InitialData = {
    siteNumber: "",
    siteName: "",
    siteNickName: "",
    personalName: "",
    rank: "",
    unit: "",
    primaryCivilMobile: "",
    afcelPhone: "",
    ipPhone: "",
    altCivilMobile: "",
    email: "",
  };

  const schema = Yup.object({
    siteNumber: SiteNumberValidator,
    siteName: SitenameValidator,
    siteNickName: SiteNicknameValidator,
    personalName: personnelNameValidation,
    rank: rankValidation,
    unit: unitValidation,
    primaryCivilMobile: primaryMobileValidation,
    afcelPhone: afcelPhoneValidation,
    ipPhone: ipPhoneValidation,
    altCivilMobile: alternateMobileValidation,
    email: emailValidation,
  });

  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    onSubmit: async (values) => {
      alert("Submit");
    },
  });

  const handleInputChange = (event, fieldName) => {
    let value = event.target.value;
    formik.setFieldValue(fieldName, value);
    setTimeout(() => {
      formik.handleBlur({ target: { name: fieldName } });
    }, 0);
  };

  const columns = [
    { name: "S. No ", uid: "sno" },
    { name: "Name", uid: "personnelName" },
    { name: "Rank", uid: "personnel" },
    { name: "Unit", uid: "unit" },
    { name: "IP Phone", uid: "ipPhone" },
    { name: "AFCEL", uid: "afcel" },
    { name: "Primary. No", uid: "primaryCivilMobile" },
    { name: "Alternative. No", uid: "alternateCivilMobile" },
    { name: "Email", uid: "email" },
    { name: "Actions", uid: "actions" },
  ];

  const [tableColumns, setTableColumns] = useState(columns);

  const updateRowById = (id, updatedFields) => {
    setRepTableData((prevData) =>
      prevData.map((item) =>
        item.repId === id ? { ...item, ...updatedFields } : item
      )
    );
    setEditModalOpen({ visible: false });
  };

  const handleFormOnClick = () => {
    const newRow = [
      {
        repId: Date.now(), // Better unique ID than length+1
        personnelName: formik.values.personalName,
        personnel: formik.values.rank,
        unit: formik.values.unit,
        primaryCivilMobile: formik.values.primaryCivilMobile,
        afcel: formik.values.afcelPhone,
        ipPhone: formik.values.ipPhone,
        alternateCivilMobile: formik.values.altCivilMobile,
        email: formik.values.email,
      },
    ];

    setRepTableData((prevResult) => [...prevResult, ...newRow]);
    Toast("Success!", "Successfully added representative", "success");
    setIsModalOpen(false);
  };

  const handleDeleteRow = (row) => {
    setRepTableData((prevData) =>
      prevData.filter((item) => item.repId !== row.repId)
    );
  };

  const onEdit = () => {
    setIsReviewMode(false);
    setTableColumns(columns);
    setIsAddMode(true);
    setIsPreviewMode(false);
  };

  // const isAddDisabled =
  //   !formik.values.personalName ||
  //   !formik.values.rank ||
  //   !formik.values.unit ||
  //   !formik.values.primaryCivilMobile ||
  //   !!(
  //     formik.errors.personalName ||
  //     formik.errors.rank ||
  //     formik.errors.unit ||
  //     formik.errors.primaryCivilMobile
  //   );

  const isMandatoryValid =
    formik.values.personalName &&
    formik.values.rank &&
    formik.values.unit &&
    formik.values.primaryCivilMobile &&
    !formik.errors.personalName &&
    !formik.errors.rank &&
    !formik.errors.unit &&
    !formik.errors.primaryCivilMobile;

  const hasNonMandatoryErrors =
    !!formik.errors.afcelPhone ||
    !!formik.errors.ipPhone ||
    !!formik.errors.altCivilMobile ||
    !!formik.errors.email;

  const isAddDisabled = !isMandatoryValid || hasNonMandatoryErrors;

  const isHeaderValid = useMemo(() => {
    const { siteNumber, siteName, siteNickName } = formik.values;
    const {
      siteNumber: errNum,
      siteName: errName,
      siteNickName: errUnit,
    } = formik.errors;
    const maxReps = 5;
    return (
      !!(
        siteNumber &&
        siteName &&
        siteNickName &&
        !errNum &&
        !errName &&
        !errUnit
      ) && repTableData.length < maxReps
    );
  }, [formik.values, formik.errors, repTableData.length]);
  
  const buttonActions = isReviewMode ? (
    <Box sx={{ display: "flex", justifyContent: "center", gap: 3, padding: 3 }}>
      <Button
        variant="contained"
        sx={{
          padding: "8px 20px",
          display: "flex",
          borderRadius: "10px",
          backgroundColor: "#14348D",
          fontFamily: "Montserrat",
          fontWeight: "Medium",
          color: "white",
          textTransform: "none",
        }}
        onClick={() => onEdit()}
      >
        <EditOutlined sx={{ mr: 1, fontSize: "20px" }} />
        Edit
      </Button>
      <Button
  variant="outlined"
  onClick={handleSucess}
  disabled={isLoading}
  sx={{
    color: "text.TitleTextcolor",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 1,
    borderRadius: "10px",
    fontFamily: "Montserrat",
    textTransform: "none",
    fontWeight: "Medium",
    padding: "8px 20px",
    border: theme.palette.custom.border,
    minWidth: "120px",
  }}
>
  {isLoading ? (
    <>
      <CircularProgress size={20} color="inherit" />
      Processing...
    </>
  ) : (
    "Confirm"
  )}
</Button>

    </Box>
  ) : (
    // ... inside buttonActions constant
    <Box sx={{ display: "flex", justifyContent: "center", gap: 2, mb: 1 }}>
      <MButtonSecondary
        variant="outlined"
        onClick={() => setDeleteAllRowsConfirm(true)}
        disabled={repTableData.length === 0}
      >
        <img src={clear}  style={{filter:theme.palette.custom.icon.iconFilter}}  alt="clear" />
        {""}Clear
      </MButtonSecondary>

      <Button
        variant="contained"
        // Disable the button if no rows exist in the table
        disabled={repTableData.length === 0}
        sx={{
          padding: "2px 10px",
          display: "flex",
          borderRadius: "10px",
          backgroundColor: "#14348D",
          fontFamily: "Montserrat",
          fontWeight: "Medium",
          color: "white",
          textTransform: "none",
          // Optional: add visual feedback for disabled state if not handled by MUI automatically
          "&.Mui-disabled": {
            backgroundColor: "#cccccc",
            color: "#666666",
          },
        }}
        onClick={handlePreview}
      >
        <VisibilityOutlined sx={{ mr: 1, fontSize: "20px" }} />
        Preview
      </Button>
    </Box>
  );
 
  return (
    <Box
      sx={{
        minHeight: "88vh", // Changed to minHeight so it can grow if content expands
        width: "95%", // Use percentage for responsiveness
        maxWidth: "1400px", // Prevents it from looking stretched on large screens
        backgroundColor: theme.palette.custom.configuration.configmodal,
        border: "1px solid #e2e2e2",
        borderRadius: { xs: "20px", md: "40px" }, // Smaller radius on mobile
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        margin: "1% auto", // Centered horizontally
        position: "relative",
        overflow: "hidden", // Prevents content from leaking out of border radius
        "@media (maxWidth: 600px)": {
          width: "100%",
          margin: "0",
          borderRadius: "0px", // Full width on mobile feels more native
          border: "none",
        },
      }}
    >
      <Box sx={{ height: "100%", width: "100%" }}>
        <Typography
          variant="h5"
          sx={{
            ml: "5%",
            mb: 1,
            mt: 1,
            p: 0.5,
            fontFamily: "Montserrat",
            fontWeight: "600",
          }}
        >
          {terminalName} RNMS Configurator
        </Typography>
        <Box sx={{ borderTop: "1px solid #ccc" }} />
        <Box
          sx={{
            ml: "5%",
            width: "90%",
            bgcolor:theme.palette.custom.configuration.configinfo,
            borderRadius: "10px",
            mb: 2,
            mt: 2,
          }}
        >
          <Typography
            sx={{
              ml: 4,
              fontFamily: "Montserrat",
              fontWeight: "600",
              color:theme.palette.custom.configuration.configmodaltext,
              display: "flex",
              alignItems: "center",
            }}
          >
            <InfoOutlineRounded sx={{ fontSize: 40, color: "", p: 1 }} />
            <span>
              This configuration is to be done only once and the details have to
              be filled carefully
            </span>
          </Typography>
        </Box>
        <Box
          sx={{
            backgroundColor: theme.palette.custom.configuration.configcard,

            borderRadius: "20px",

            // width: { xs: "95%", sm: "90%", md: "85%", lg: "80%" },

            width: "90%",
            ml: "5%",

            //p: { xs: 2, md: 4 },

            position: "relative",

            border: "2px solid #eee",

            boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.05)",
          }}
        >
          <Typography
            sx={{
              ml: "2%",
              fontFamily: "Montserrat",

              fontSize: 18,
              p: 1,
              color:theme.palette.custom.configuration.configmodaltext,
            }}
          >
            Terminal and site details
          </Typography>
          <Box sx={{ borderTop: "1px solid #ccc" }} />

          <Box sx={{ width: "100%", padding: "0% 1% 0% 1%", ml: 3 }}>
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(2, 1fr)",
                gap: "15px",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mr: 8,
                  width: "90%",
                  mt: 1,
                }}
              >
                <Typography> Terminal</Typography>
                <MInput
                  disabled={true}
                  readOnly={true}
                  placeholder={terminalName}
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  width: "90%",
                  mt: 1,
                }}
              >
                <Typography>Site Number *</Typography>
                <MInput
                  label={"Site Number *"}
                  value={formik.values.siteNumber}
                  placeholder={"Enter Site Number"}
                  inputProps={{ maxLength: 3,minLength:1 }}
                  onKeyDown={(e) => {
                    if (!/[0-9]/.test(e.key) && e.key !== "Backspace" && e.key !== "Delete") {
                      e.preventDefault();
                    }
                  }}
                
                  onChange={(e) => {
                    const data = siteNumRegex(e.target.value);
                    if (data !== undefined) {
                      handleInputChange(e, "siteNumber");
                    }
                  }}
                  errorMessage={
                    formik.touched.siteNumber && formik.errors.siteNumber
                  }
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mb: 2,
                  width: "90%",
                }}
              >
                <Typography>Site Name *</Typography>
                <MInput
                  label={"Site Name *"}
                  value={formik.values.siteName}
                  placeholder={"Enter Site Name"}
                  onChange={(e) => {
                    const data = SitenameRegex(e.target.value);
                    if (data !== undefined) {
                      handleInputChange(e, "siteName");
                    }
                  }}
                  inputProps={{ maxLength: 25,minLength:3 }}
                  errorMessage={
                    formik.touched.siteName && formik.errors.siteName
                  }
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mr: 2,

                  width: "90%",
                }}
              >
                <Typography>Unit Name *</Typography>
                <MInput
                  label={"Unit Name *"}
                  value={formik.values.siteNickName}
                  placeholder={"Enter Unit Name"}
                  inputProps={{ maxLength: 25,minLength:3 }}
                  onChange={(e) => {
                    const data = SiteNicknameRegex(e.target.value);
                    if (data !== undefined) {
                      handleInputChange(e, "siteNickName");
                    }
                  }}
                  errorMessage={
                    formik.touched.siteNickName && formik.errors.siteNickName
                  }
                />
              </Box>
            </Box>
          </Box>

          <Box sx={{ borderTop: "1px solid #ccc", mt: 1 }} />

          <Box sx={{ width: "100%" }}>
            <MTable
            typeHeight="configuration"
              columns={tableColumns}
              tableData={repTableData}
              handleAdd={handleAddButtonClick}
              hideAdd={isPreviewMode}
              handleEdit={(row) => handleEdit(row)}
              handleDelete={(row) => {
                setRowToDelete({ visible: true, row: row });
              }}
              AddText="Add Rep."
              tableTitle="Representative Details"
              addDisable={!isHeaderValid}
              addIcon={<AddCircleOutlineOutlined />}
            />
          </Box>
          <Typography sx={{ p: 1, color: "#e75656" }}>
            Note:Maximum 5 Rep's can be added.
          </Typography>

          {buttonActions}
        </Box>
      </Box>

      {/* REPRESENTATIVE MODAL */}
      <MModal
        open={isModalOpen}
        handleClose={handleModalClose}
        title={"Add Representative"}
      >
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "15px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "100%",
              mt: 2,
            }}
          >
            <Typography>Personnel Name * </Typography>
            <MInput
              label={"Personnel Name"}
              value={formik.values.personalName}
              placeholder={"Enter personnel name"}
              onChange={(e) => {
                if (
                  validateInput(e.target.value, personnelRegex.name) !==
                  undefined
                ) {
                  handleInputChange(e, "personalName");
                }
              }}
              errorMessage={
                formik.touched.personalName && formik.errors.personalName
              }
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 2,
              width: "100%",
              mt: 2,
            }}
          >
            <Typography>Rank *</Typography>
            <FormControl fullWidth>
              <Select
                id="rank-select"
                size="small"
                value={formik.values.rank}
                onChange={(e) => handleInputChange(e, "rank")}
                sx={{
                  "& .MuiSelect-select": {
                    fontFamily: "Montserrat",
                  },
                }}
              >
                <MenuItem value={"AIR CMDE"}>AIR CMDE</MenuItem>
                <MenuItem value={"GP CAPT"}>GP CAPT</MenuItem>
                <MenuItem value={"WG CDR"}>WG CDR</MenuItem>
                <MenuItem value={"SQN LDR"}>SQN LDR</MenuItem>
                <MenuItem value={"FLT LT"}>FLT LT</MenuItem>
                <MenuItem value={"FG OFFR"}>FG OFFR</MenuItem>
                <MenuItem value={"MWO"}>MWO</MenuItem>
                <MenuItem value={"WO"}>WO</MenuItem>
                <MenuItem value={"JWO"}>JWO</MenuItem>
                <MenuItem value={"SGT"}>SGT</MenuItem>
                <MenuItem value={"CPL"}>CPL</MenuItem>
                <MenuItem value={"LAC"}>LAC</MenuItem>
                <MenuItem value={"AC"}>AC</MenuItem>
                <MenuItem value={"AGV"}>AGV</MenuItem>
              </Select>
            </FormControl>
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "100%",
            }}
          >
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>
              Unit *
            </Typography>
            <MInput
              label={"Unit"}
              value={formik.values.unit}
              placeholder={"Enter unit"}
              inputProps={{maxLength:20,minLength:3}}
              onChange={(e) => handleInputChange(e, "unit")}
              errorMessage={formik.touched.unit && formik.errors.unit}
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 2,
              width: "100%",
            }}
          >
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>
              Primary Civil Mobile *
            </Typography>
            <MInput
              label={"Primary Civil Mobile"}
              value={formik.values.primaryCivilMobile}
              placeholder={"6-9xxxxxxxxx"}
              onChange={(e) => {
                if (
                  validateInput(
                    e.target.value,
                    personnelRegex.primaryMobile
                  ) !== undefined
                ) {
                  handleInputChange(e, "primaryCivilMobile");
                }
              }}
              errorMessage={
                formik.touched.primaryCivilMobile &&
                formik.errors.primaryCivilMobile
              }
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "100%",
              mt: 2,
            }}
          >
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>
              AFCEL Phone
            </Typography>
            <MInput
              label={"AFCEL Phone"}
              value={formik.values.afcelPhone}
              placeholder={"1-9xxxxxxx"}
              onChange={(e) => {
                if (
                  validateInput(e.target.value, personnelRegex.landline) !==
                  undefined
                ) {
                  handleInputChange(e, "afcelPhone");
                }
              }}
              errorMessage={
                formik.touched.afcelPhone && formik.errors.afcelPhone
              }
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "100%",
              mt: 2,
            }}
          >
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>
              IP Phone
            </Typography>
            <MInput
              label={"IP Phone"}
              value={formik.values.ipPhone}
              placeholder={"1-9xxxxxxx"}
              onChange={(e) => {
                if (
                  validateInput(e.target.value, personnelRegex.landline) !==
                  undefined
                ) {
                  handleInputChange(e, "ipPhone");
                }
              }}
              errorMessage={formik.touched.ipPhone && formik.errors.ipPhone}
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "100%",
              mt: 2,
            }}
          >
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>
              Alternative Civil Phone No.
            </Typography>
            <MInput
              label={"Alternate Civil Mobile No."}
              value={formik.values.altCivilMobile}
              placeholder={"5-9xxxxxxxxx"}
              onChange={(e) => {
                if (
                  validateInput(e.target.value, personnelRegex.altMobile) !==
                  undefined
                ) {
                  handleInputChange(e, "altCivilMobile");
                }
              }}
              errorMessage={
                formik.touched.altCivilMobile && formik.errors.altCivilMobile
              }
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "100%",
              mt: 2,
            }}
          >
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>
              Email
            </Typography>
            <MInput
              label={"Email"}
              value={formik.values.email}
              placeholder={"example@domain.com"}
              onChange={(e) => handleInputChange(e, "email")}
              errorMessage={formik.touched.email && formik.errors.email}
            />
          </Box>
        </Box>

        <Box sx={{ float: "right", display: "flex", mt: 3, gap: "7%" }}>
          {isAddMode && (
            <MButtonPrimary
              onClick={handleFormOnClick}
              disabled={isAddDisabled}
            >
              <AddCircleOutlineOutlined sx={{ mr: 1, fontSize: "25px" }} />
              Add
            </MButtonPrimary>
          )}
          <MButtonSecondary
            variant={"outlined"}
            onClick={handleAddRepFieldsClear}
          >
            <img src={clear} alt="clear" style={{filter:theme.palette.custom.icon.iconFilter}} />
            {""}Clear
          </MButtonSecondary>
        </Box>
      </MModal>

      {editModalOpen.visible && (
        <EditRepDetails
          rowData={editModalOpen.rowData}
          setEditModalOpen={setEditModalOpen}
          setRepTableData={setRepTableData}
          repTableData={repTableData}
          onUpdate={updateRowById}
        />
      )}

      {deleteAllRowsConfirm && (
        <MDialog
          variant="error"
          title="Confirm Action"
          message="Are you sure you want to clear all the fields?"
          icon={Delete_Icon_}
          open={deleteAllRowsConfirm}
          onConfirm={() => {
            setRepTableData([]);

            formik.resetForm();

            setDeleteAllRowsConfirm(false);
          }}
          onClose={() => setDeleteAllRowsConfirm(false)}
        />
      )}
      {rowToDelete.visible && (
        <MDialog
          icon={Delete_Icon_}
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          message="Are you sure you want to delete?"
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null });
            Toast("Success!", "Successfully deleted row", "success");
          }}
          onClose={() => setRowToDelete({ visible: false, row: null })}
        />
      )}
    </Box>
  );
};

export default Configuration;
