/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : configurator
   File Name                : CommonSiteDetailsFields.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\auth\configurator\CommonSiteDetailsFields.jsx
   Purpose                  : The purpose is to show the Fields of configurator page. 
   Created Date             : 02-01-2026
 *******************************************************************************************/
import React from "react";
import { Box, Typography } from "@mui/material";
import MInput from "../../../components/Reusable/Input/MInput";
import {
  siteNumRegex,
  SitenameRegex,
} from "../../../utility/FormValidation/Regex";

const SiteDetailsHeader = ({ formik, terminalName }) => {
  const handleInputChange = (event, fieldName) => {
    let value = event.target.value;
    formik.setFieldValue(fieldName, value);
    setTimeout(() => {
      formik.handleBlur({ target: { name: fieldName } });
    }, 0);
  };

  return (
    <Box
      sx={{
        backgroundColor: "white",
        borderRadius: "20px",
        ml: "5%",
        mr: "5%",
        p: 0,
      }}
    >
      <Typography
        sx={{
          ml: "2%",
          fontFamily: "Montserrat",
          fontWeight: "600",
          fontSize: 18,
          p: 1.5,
          color: "#14348D",
        }}
      >
        Terminal and site details
      </Typography>
      <Box sx={{ borderTop: "1px solid #ccc", mt: 1 }} />
      <Box sx={{ width: "100%", padding: "0% 1% 0% 1%", ml: 3 }}>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "15px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 8,
              width: "90%",
              mt: 2,
            }}
          >
            <Typography>Terminal</Typography>
            <MInput
              disabled={true}
              readOnly={true}
              placeholder={terminalName}
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              width: "90%",
              mt: 2,
            }}
          >
            <Typography>Site Number *</Typography>
            <MInput
              value={formik.values.siteNumber}
              placeholder={"Enter Site Number"}
              onChange={(e) => {
                if (siteNumRegex(e.target.value) !== undefined)
                  handleInputChange(e, "siteNumber");
              }}
              errorMessage={
                formik.touched.siteNumber && formik.errors.siteNumber
              }
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mb: 2,
              width: "90%",
              mt: 2,
            }}
          >
            <Typography>Site Name *</Typography>
            <MInput
              value={formik.values.siteName}
              placeholder={"Enter Site Name"}
              onChange={(e) => {
                if (SitenameRegex(e.target.value) !== undefined)
                  handleInputChange(e, "siteName");
              }}
              errorMessage={formik.touched.siteName && formik.errors.siteName}
            />
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mr: 2,
              mb: 2,
              width: "90%",
              mt: 2,
            }}
          >
            <Typography>Unit Name</Typography>
            <MInput
              value={formik.values.unitName}
              placeholder={"Enter Unit Name"}
              onChange={(e) => {
                if (SitenameRegex(e.target.value) !== undefined)
                  handleInputChange(e, "unitName");
              }}
              errorMessage={formik.touched.unitName && formik.errors.unitName}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default SiteDetailsHeader;
