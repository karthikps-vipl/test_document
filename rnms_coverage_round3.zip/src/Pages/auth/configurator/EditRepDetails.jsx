/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : configurator
   File Name                : EditRepDetails.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\auth\configurator\EditRepDetails.jsx
   Purpose                  : The purpose is to show the Edit functionality of configurator page. 
   Created Date             : 02-01-2026
 *******************************************************************************************/
/* eslint-disable no-unused-vars */
import React from "react";
import {
  Box,
  Typography,
  FormControl,
  Select,
  MenuItem,
  FormHelperText,
} from "@mui/material";
import MModal from "../../../components/Reusable/Modal/MModal";
import MInput from "../../../components/Reusable/Input/MInput";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  personnelNameValidation,
  rankValidation,
  unitValidation,
  primaryMobileValidation,
  afcelPhoneValidation,
  ipPhoneValidation,
  alternateMobileValidation,
  emailValidation,
} from "../../../utility/FormValidation/YupSchema";
import {
  personnelRegex,
  remainingText,
  validateInput,
} from "../../../utility/FormValidation/Regex";
import MButtonPrimary from "../../../components/Reusable/Button/MButtonPrimary";
import Toast from "../../../components/Reusable/Toast/Toast";
const EditRepDetails = ({ rowData, setEditModalOpen, onUpdate }) => {
  const formik = useFormik({
    initialValues: {
      personalName: rowData?.personnelName || "",
      rank: rowData?.personnel || "",
      unit: rowData?.unit || "",
      primaryCivilMobile: rowData?.primaryCivilMobile || "",
      afcelPhone: rowData?.afcel || "",
      ipPhone: rowData?.ipPhone || "",
      altCivilMobile: rowData?.alternateCivilMobile || "",
      email: rowData?.email || "",
    },
    validationSchema: Yup.object({
      personalName: personnelNameValidation,
      rank: rankValidation,
      unit: unitValidation,
      primaryCivilMobile: primaryMobileValidation,
      afcelPhone: afcelPhoneValidation,
      ipPhone: ipPhoneValidation,
      altCivilMobile: alternateMobileValidation,
      email: emailValidation,
    }),
    enableReinitialize: true,
    validateOnMount: true,
    onSubmit: (values) => {
      onUpdate(rowData.repId, {
        personnelName: values.personalName,
        personnel: values.rank,
        unit: values.unit,
        primaryCivilMobile: values.primaryCivilMobile,
        afcel: values.afcelPhone,
        ipPhone: values.ipPhone,
        alternateCivilMobile: values.altCivilMobile,
        email: values.email,
      });
      Toast("Success!", "Representative details updated", "success");
      setEditModalOpen({ visible: false });
    },
  });

  const isMandatoryValid =
    formik.values.personalName &&
    formik.values.rank &&
    formik.values.unit &&
    formik.values.primaryCivilMobile &&
    !formik.errors.personalName &&
    !formik.errors.rank &&
    !formik.errors.unit &&
    !formik.errors.primaryCivilMobile;

  const hasNonMandatoryErrors =
    !!formik.errors.afcelPhone ||
    !!formik.errors.ipPhone ||
    !!formik.errors.altCivilMobile ||
    !!formik.errors.email;

  const isAddDisabled = !isMandatoryValid || hasNonMandatoryErrors;
  
  // 1. The button is disabled if the form hasn't been touched/changed (dirty) 
  // OR if there are validation errors.
  const isUpdateDisabled = !formik.dirty || isAddDisabled;

  const handleInputChange = (event, fieldName) => {
    const value = event.target.value;
    formik.setFieldValue(fieldName, value);
    setTimeout(() => {
      formik.setFieldTouched(fieldName, true);
      formik.validateForm();
    }, 0);
  };

  return (
    <MModal
      open={true}
      handleClose={() => setEditModalOpen({ visible: false })}
      title={"Edit Representative Details"}
    >
      <Box sx={{ display: "flex", alignItems: "center" }}></Box>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          gap: "15px",
          mt: 1,
        }}
      >
        {/* Personnel Name - Restricted: 3 to 25 chars */}
        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            Personnel Name *
          </Typography>
          <MInput
            value={formik.values.personalName}
            placeholder={"Enter Name"}
            helperText={remainingText(formik.values.personalName.length, 25)}
            onChange={(e) => {
              const val = e.target.value;
              // Logic: Must match regex AND length must be between 3 and 25
              if (
                validateInput(val, personnelRegex.name) !== undefined &&
                val.length >= 0 && // Allow typing from 0 so user can clear/type
                val.length <= 25
              ) {
                handleInputChange(e, "personalName");
              }
            }}
            errorMessage={
              formik.touched.personalName && formik.errors.personalName
            }
          />
        </Box>

        {/* Rank */}
        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            Rank *
          </Typography>
          <FormControl
            fullWidth
            error={formik.touched.rank && Boolean(formik.errors.rank)}
          >
            <Select
              size="small"
              value={formik.values.rank}
              onChange={(e) => handleInputChange(e, "rank")}
              displayEmpty
            >
              {[
                "AIR CMDE", "GP CAPT", "WG CDR", "SQN LDR", "FLT LT", 
                "FG OFFR", "MWO", "WO", "JWO", "SGT", "CPL", "LAC", "AC", "AGV",
              ].map((rank) => (
                <MenuItem key={rank} value={rank}>
                  {rank}
                </MenuItem>
              ))}
            </Select>
            {formik.touched.rank && (
              <FormHelperText>{formik.errors.rank}</FormHelperText>
            )}
          </FormControl>
        </Box>

        {/* Unit - Restricted: 3 to 25 chars */}
        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            Unit *
          </Typography>
          <MInput
            value={formik.values.unit}
            placeholder={"Enter Unit"}
            onChange={(e) => {
              const val = e.target.value;
              // Logic: Restrict length between 3 and 25
              if (val.length <= 20) {
                handleInputChange(e, "unit");
              }
            }}
            errorMessage={formik.touched.unit && formik.errors.unit}
          />
        </Box>

        {/* ... Other fields remain the same ... */}
        <Box sx={{ mt: 1 }}>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            Primary Civil Mobile *
          </Typography>
          <MInput
            value={formik.values.primaryCivilMobile}
            placeholder={"6-9xxxxxxxxx"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, /^[0-9]*$/) !== undefined &&
                e.target.value.length <= 10
              ) {
                handleInputChange(e, "primaryCivilMobile");
              }
            }}
            errorMessage={
              formik.touched.primaryCivilMobile && 
              formik.errors.primaryCivilMobile
            }
          />
        </Box>

        {/* AFCEL */}
        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            AFCEL Phone
          </Typography>
          <MInput
            value={formik.values.afcelPhone}
            placeholder={"8 digits"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, /^[0-9]*$/) !== undefined &&
                e.target.value.length <= 8
              ) {
                handleInputChange(e, "afcelPhone");
              }
            }}
            errorMessage={formik.touched.afcelPhone && formik.errors.afcelPhone}
          />
        </Box>

        {/* IP Phone */}
        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            IP Phone
          </Typography>
          <MInput
            value={formik.values.ipPhone}
            placeholder={"8 digits"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, /^[0-9]*$/) !== undefined &&
                e.target.value.length <= 8
              ) {
                handleInputChange(e, "ipPhone");
              }
            }}
            errorMessage={formik.touched.ipPhone && formik.errors.ipPhone}
          />
        </Box>

        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            Alternative Civil Phone No.{" "}
          </Typography>
          <MInput
            value={formik.values.altCivilMobile}
            placeholder={"10 digits"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, /^[0-9]*$/) !== undefined &&
                e.target.value.length <= 10
              ) {
                handleInputChange(e, "altCivilMobile");
              }
            }}
            errorMessage={
              formik.touched.altCivilMobile && formik.errors.altCivilMobile
            }
          />
        </Box>

        <Box>
          <Typography sx={{ mb: 1, fontFamily: "Montserrat" }}>
            Email
          </Typography>
          <MInput
            value={formik.values.email}
            placeholder={"example@domain.com"}
            onChange={(e) => handleInputChange(e, "email")}
            errorMessage={formik.touched.email && formik.errors.email}
          />
        </Box>
      </Box>

      {/* Action Button */}
      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 4, gap: 2 }}>
        <MButtonPrimary
          onClick={formik.handleSubmit}
          disabled={isUpdateDisabled} // Using the new logic here
        >
          Update
        </MButtonPrimary>
      </Box>
    </MModal>
  );
};

export default EditRepDetails;
