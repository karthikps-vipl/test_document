/* eslint-disable react-hooks/set-state-in-effect */
/* eslint-disable no-unused-vars */
import {
  Box,
  Typography,
  Button,
  Paper,
  InputAdornment,
  IconButton,
  useTheme,
  Link,
  CircularProgress,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MInput from "../../components/Reusable/Input/MInput";
import { useFormik } from "formik";
import * as Yup from "yup";
import { Username, Password } from "../../utility/FormValidation/YupSchema";
import {
  usernameRegex,
  passwordRegex,
} from "../../utility/FormValidation/Regex";

import {
  AuthAxios,
  AuthAxios2,
  FaultAxios,
  InventoryAxios,
  LogoutAxios,
  SecurityAxios,
} from "../../RestAPI/api/axiosApicall";
import {
  CNMS_STATUS_URL,
  FETCH_ALL_MASTER_TERMINAL_TYPE_DETAILS,
  FETCH_ALL_RESOURCE_INFO,
  FETCH_ALL_TERMINAL_TYPE_DETAILS,
  FETCH_SECURITY_SETTINGS,
  GET_ALL_RESOURCES_BY_TERMINAL,
  GET_CAPTCHA,
  GET_DEVICE_TOOLTIP_OPTIONS,
  LOGIN,
  LOGOUT,
  PORT_RESOURCE_DETAILS,
} from "../../RestAPI/url/endpoint";
import { encryptData } from "../../utility/encryptLogin";
import MDialog from "../../components/Reusable/Dialog/MDialog";
import question_mark from "@/assets/SVGIcons/question_mark.svg"

import {
  setIsUserLoggedIn,
  setLoggedInUserDetails,
  setPrivilegesKeysSet,
  setRequiresEmailUpdate,
} from "../../store/features/LoggedInUser/userSlice";
import { useDispatch, useSelector } from "react-redux";
import Toast from "../../components/Reusable/Toast/Toast";
import Loader from "../../components/Reusable/Loader/Loader";
import { RefreshCw } from "lucide-react";
import {
  setAllResourceInfo,
  setImageNodePortStatus,
  setIsCnmsMode,
  setNodes,
  setTerminalTypes,
} from "@/store/features/Topology/topologyNodesslice";
import { setToolTipOptions } from "@/store/features/Tooltip/toolTipSlice";
import Confirmation_icon from "../../assets/SVGIcons/question_mark.svg";
import { setAvailableResources } from "@/store/features/PortStatus/portStatusSlice";
import { transformResourceToNode } from "../Rnmsdashboard/Topology/utils";
import { setResources } from "@/store/features/Inventory/inventorySlice";
import { terminalType, UpdateURlFun } from "@/components/shared/utilis/utils";

import {
  setCnmsOpenAlarm,
  setFetchAllTerminalTypeAlongWithSite,
  setFetchSiteDetails,
} from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import {
  FETCH_ALL_OPEN_ALARM_CNMS,
  FETCH_ALL_SITE_DETAILS,
  FETCH_ALL_SITE_GROUPS,
  FETCH_ALL_TERMINAL_TYPE_ALONG_WITH_SITE,
  LDAP_LOGIN,
  RESET_PASSWORD,
} from "@/RestAPI/url/cnmsEndPoint";
import { setAllSiteGroups } from "@/store/features/Cnms/mapViewSlice";
import { setAllTerminalTypeDetails } from "@/store/features/nodeDetailsSlice";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import { fetchAlarmNotificationSettings } from "../CnmsDashboard/CnmsAlarmSummary/fetchAlarmNotificationSettings";
import MModal from "@/components/Reusable/Modal/MModal";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { ChatSocketMgmt } from "@/RestAPI/Socket/SocketCall";
import { setChatBackendUrl } from "@/store/features/Chats/chatSlice";

const LoginAtp = ({isGrandchildFullScreen}) => {

  const dispatch = useDispatch();
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const [captchaData, setCaptchaData] = useState();
  const [isCaptchaLoading, setIsCaptchaLoading] = useState(false);
  const { siteDetails } = useSelector((state) => state.nodeDetails);
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const [showEndSession, setShowEndSession] = useState({
    visible: false,
    token: "",
    message: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isLdapLogin, setIsLdapLogin] = useState(false);
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [isResetLoading, setIsResetLoading] = useState(false);
  const [apiSuccess, setApiSuccess] = useState(false);
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [isTouched, setIsTouched] = useState(false); // Tracks if user interacted

  const validateEmail = (emailValue) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!emailValue || emailValue.trim() === "") {
      return "Email is required";
    }

    // Defense-in-depth: Limit input length to prevent CPU exhaustion
    if (emailValue.length > 48) {
      return "Email cannot exceed 48 characters";
    }

    if (!emailRegex.test(emailValue)) {
      return "Please enter a valid email address";
    }

    return "";
  };

  useEffect(() => {
    dispatch(setIsCnmsMode(isCnms));
  }, [isCnms, dispatch]);

  const handleEmailChange = (e) => {
    const value = e.target.value;

    // 1. Hard limit: Stop typing at 48 chars
    if (value.length <= 48) {
      setEmail(value);
    }

    // 2. The "Magic" part:
    // If the user has interacted (isTouched), validate EVERY keystroke.
    // This ensures the error shows IMMEDIATELY as they type.
    if (isTouched) {
      const error = validateEmail(value);
      setEmailError(error);
    }
  };
  const handleEmailBlur = () => {
    setIsTouched(true);
    const error = validateEmail(email);
    setEmailError(error);
  };
  const handleResetPassword = async () => {
    // Final validation check before API call
    setShowConfirm(false);
    const error = validateEmail(email);
    if (error) {
      setEmailError(error);
      setIsTouched(true);
      return;
    }

    setEmailError("");
    setIsResetLoading(true);
    setApiSuccess(false);

    try {
      const url = `${RESET_PASSWORD}/${email}`;
      console.log("url", url);

      const resp = await AuthAxios2(url, "post");

      if (resp?.data?.status === 1) {
        setApiSuccess(true);
        const sucessMessage = resp?.data?.message || "Invalid Request";

        Toast("Success!", sucessMessage, "success");
      } else if (resp?.data?.status === 0) {
        const errorMessage = resp?.data?.message || "Invalid Request";
        Toast("Failed!", errorMessage, "error");
      } else {
        Toast("Error", "An unexpected response was received", "error");
      }
    } catch (err) {
      console.error("Error resetting password:", err);
      Toast("Error", "Network error or server is unreachable", "error");
    } finally {
      setIsResetLoading(false);
    }
  };
  const handleOpenModal = () => setIsModalOpen(true);
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setApiSuccess(false);
    setEmail("");
    setEmailError("");
  };
  const fetchCaptcha = async () => {
    try {
      const resp = await AuthAxios(GET_CAPTCHA, "get");
      setCaptchaData(resp?.data);
      setIsCaptchaLoading(false);

      formik.values.captcha = "";
    } catch (err) {
      setIsCaptchaLoading(true);
      console.error("Error fetching captcha", err);
    }
  };

  useEffect(() => {
    fetchCaptcha();
  }, []);

  const handleClear = () => {
    formik.setFieldValue("userName", "", false);
    formik.setFieldValue("password", "", false);
    formik.setFieldValue("captcha", "", false);
    formik.setFieldTouched("userName", "", false);
    formik.setFieldTouched("password", "", false);
    formik.setFieldTouched("captcha", "", false);
  };

  const setTokenToSession = (token, userName) => {
    sessionStorage.setItem("authToken", token);
    sessionStorage.setItem("userName", userName);
  };

  const InitialData = {
    userName: "",
    password: "",
    captcha: "",
  };

  const schema = Yup.object({
    userName: Username,
    password: Password,
    captcha: Yup.string()
      .required("Captcha is required")
      .matches(captchaData?.key, "Invalid Captcha")
      .length(5, "Captcha must be exactly 5 characters")
      .min(5, "Minimum five charcter is allowed")
      .max(5, "Maximum five charcter is allowed"),
  });

  // rnms and cnms login payload creation
  const createPayload = () => {
    return {
      userName: encryptData(formik.values.userName),
      password: encryptData(formik.values.password),
      // rnmsDetails: null, for other tan cnms
      ...(siteDetails.id !== terminalType.CNMS && {
        rnmsDetails: null,
      }),
      ...(siteDetails.id === terminalType.CNMS && { rnmsDetailId: "CNMS_001" }),
      captchaKey: encryptData(captchaData?.key),
      captchaId: captchaData?.id,
    };
  };

  const createPayloadForLdap = () => {
    return {
      username: encryptData(formik.values.userName), //username "n" is smallcase for ldap
      password: encryptData(formik.values.password),
      captchaKey: encryptData(captchaData?.key),
      captchaId: captchaData?.id,
    };
  };

  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    onSubmit: async (values) => {
      setLoading(true);

      const payload = createPayload(); // Reuse the payload here

      try {
        await handleLogin(payload); // Use the new handleLogin function
      } catch (error) {
        Toast("Failed!", "Login Failed", "error");
        console.error("Error during logout/login:", error);
      } finally {
        setLoading(false);
        //setShowEndSession({ visible: false }); // Ensure it's hidden on error too
      }
    },
  });
  function findJsonError(jsonString) {
    try {
      // Try to parse the whole thing first
      JSON.parse(jsonString);
      return " JSON is valid!";
    } catch (e) {
      // If it fails, we need to find where
      if (jsonString.length <= 10) {
        return `Found the broken piece: "${jsonString}" | Error: ${e.message}`;
      }

      // Split the string in half to search (Binary Search approach)
      const mid = Math.floor(jsonString.length / 2);
      const left = jsonString.substring(0, mid);
      const right = jsonString.substring(mid);

      console.log(`Checking segment... length: ${jsonString.length}`);

      // This is a simplified way to find the error by trying to parse parts
      // Note: In a real scenario, we look for the nearest complete object/bracket
      try {
        // Try the first half
        return findJsonError(left);
      } catch (err) {
        return findJsonError(right);
      }
    }
  }

  const updateChatUrl = async () => {
    const cnmsConfigRes = await InventoryAxios(CNMS_STATUS_URL, "get");

    if (cnmsConfigRes.status == 200 && cnmsConfigRes.data) {
      let address = "";
      if (cnmsConfigRes.data.address) {
        address = cnmsConfigRes.data.address;
      } else if (
        cnmsConfigRes.data.data &&
        typeof cnmsConfigRes.data.data == "string"
      ) {
        const data = JSON.parse(cnmsConfigRes.data.data);

        address = data.address;
      }

      console.log(address, "addreererd");

      const newURL = UpdateURlFun(ChatSocketMgmt, address);

      console.log(newURL, "newURLnewURL");

      dispatch(setChatBackendUrl(newURL));
    }
    //
  };

  async function handleLogin(payload) {
    let ldapPayload = createPayloadForLdap();

    try {
      const res = await AuthAxios2(
        isLdapLogin ? LDAP_LOGIN : LOGIN,
        "post",
        isLdapLogin ? ldapPayload : payload
      );

      if (res.status === 200 && res.data) {
        const status = res.data.status;

        switch (status) {
          case 0:
            fetchCaptcha();
            Toast("Failed!", res.data.message, "error");
            break;
          case 1:
          case 3: {
            setTokenToSession(res?.data?.data?.auth, res?.data?.data?.userName);

            dispatch(setIsUserLoggedIn(true));
            dispatch({
              type: "socket/connect",
            });

            // let DevicePrvilage
            // if (siteDetails.id === terminalType.CNMS) {
            //   let privileges = res.data.data.group.privileges.map(
            //     (item) => item.key
            //   );
            //   DevicePrvilage = privileges;
            // } else {
            // const DevicePrvilage = JSON.parse(
            //   res.data.data.group.devicePrivileges || {}
            // );
            // }

            let DevicePrvilage = {};

            if (
              res.data.data &&
              res.data.data.group &&
              res.data.data.group.devicePrivileges
            ) {
              DevicePrvilage = JSON.parse(
                res.data.data.group.devicePrivileges || {}
              );
            }
            console.log(DevicePrvilage, "DevicePrvilagesasasa");

            const ContextmenuPrvilage = {};
            // enbaling menu values by resouce id
            Object.entries(DevicePrvilage).forEach(([key, val]) => {
              const keyData = key.split("_");
              const lable = keyData.slice(1).join("_");

              if (ContextmenuPrvilage[keyData[0]]) {
                ContextmenuPrvilage[keyData[0]][lable] = val;
              } else {
                ContextmenuPrvilage[keyData[0]] = { [lable]: val };
              }
            });

            dispatch(
              setLoggedInUserDetails({
                res: res?.data,
                devicePrivileges: ContextmenuPrvilage,
              })
            );

            let privilegesSet = [];

            privilegesSet = res?.data?.data?.group?.privileges?.map(
              (item) => item.key
            );

            // privilegesSet = new Set(privilegesSet);

            dispatch(setPrivilegesKeysSet(privilegesSet));

            await InventoryAxios(PORT_RESOURCE_DETAILS, "get")
              .then((res) => {
                console.log("klklkllkl", res?.data);
                dispatch(setAvailableResources(res.data));
              })
              .catch((error) => {
                console.error("Error:", error);
              });

            await InventoryAxios(FETCH_ALL_RESOURCE_INFO, "get")
              .then((res) => {
                console.log("abcdef", res?.data);
                dispatch(setAllResourceInfo(res?.data));

                const addDataField = res.data.map((item) => ({
                  id: item.resourceId,
                  data: item,
                }));
                dispatch(setNodes(addDataField));
                console.log(addDataField, "addDataField");
                dispatch(setResources({ resources: res?.data }));
              })
              .catch((error) => {
                Toast("Error", "Failed to fetch resource info", "error");
                console.error(error);
              });

            // await InventoryAxios(FETCH_ALL_RESOURCE_INFO, "get")
            //   .then((res) => {
            //     console.log("Actual API response:", res?.data);

            //     const actualResources = res?.data || [];

            //     const updatedResources = actualResources.map((resource) => {
            //       if (resource.resourceId === "MCT_EP_SWITCH-24PORT") {
            //         return mockSwitchResponse;
            //       }

            //       return resource;
            //     });

            //     console.log(
            //       "Final resources after mock replacement:",
            //       updatedResources
            //     );

            //     dispatch(setAllResourceInfo(updatedResources));

            //     const addDataField = updatedResources.map((item) => ({
            //       id: item.resourceId,
            //       data: item,
            //     }));

            //     dispatch(setNodes(addDataField));

            //     console.log(addDataField, "addDataField");

            //     dispatch(
            //       setResources({
            //         resources: updatedResources,
            //       })
            //     );
            //   })
            //   .catch((error) => {
            //     Toast("Error", "Failed to fetch resource info", "error");
            //     console.error(error);
            //   });

            await InventoryAxios(FETCH_ALL_MASTER_TERMINAL_TYPE_DETAILS, "get")
              .then((res) => {
                console.log("master", res?.data);
                dispatch(setTerminalTypes(res?.data));
              })
              .catch((error) => {
                Toast("Error", "Failed to fetch master type details", "error");
                console.error(error);
              });
            try {
              await fetchAlarmNotificationSettings(dispatch);
            } catch (error) {
              console.error(
                "Failed to initialize alarm notification settings:",
                error
              );
              Toast(
                "Error",
                "Failed to load alarm notification settings",
                "error"
              );
            }
            await InventoryAxios(GET_DEVICE_TOOLTIP_OPTIONS, "get")
              .then((res) => {
                console.log("rnmstooltip1", res.data);
                dispatch(setToolTipOptions(res.data));
              })
              .catch((error) => {
                console.error(error);
              });

            //cnms
            await InventoryAxios(FETCH_ALL_SITE_DETAILS, "get")
              .then((res) => {
                console.log("FETCH_ALL_SITE_DETAILS", res?.data);

                // await FaultAxios(FETCH_ALL_OPEN_ALARM_CNMS, "get")
                dispatch(setFetchSiteDetails(res.data));
              })
              .catch((error) => {
                console.error(error);
              });

            await InventoryAxios(FETCH_ALL_TERMINAL_TYPE_DETAILS, "get")
              .then((res) => {
                dispatch(setAllTerminalTypeDetails(res.data));
              })
              .catch((error) => {
                console.error(
                  "Failed at FETCH_ALL_TERMINAL_TYPE_DETAILS",
                  error
                );
              });
            await InventoryAxios(FETCH_ALL_TERMINAL_TYPE_ALONG_WITH_SITE, "get")
              .then((res) => {
                console.log(
                  "FETCH_ALL_TERMINAL_TYPE_ALONG_WITH_SITE",
                  res?.data
                );

                // await FaultAxios(FETCH_ALL_OPEN_ALARM_CNMS, "get")
                dispatch(setFetchAllTerminalTypeAlongWithSite(res.data));
              })
              .catch((error) => {
                console.error(error);
              });

            if (isCnms) {
              await InventoryAxios(FETCH_ALL_SITE_GROUPS, "get")
                .then((res) => {
                  dispatch(setAllSiteGroups(res?.data?.data || []));
                })
                .catch((error) => {
                  console.error("FETCH_ALL_SITE_GROUPS", error);
                });
            }
            await FaultAxios(FETCH_ALL_OPEN_ALARM_CNMS, "get")
              .then((res) => {
                console.log("FETCH_ALL_OPEN_ALARM_CNMS", res?.data);
                dispatch(setCnmsOpenAlarm(res?.data));
              })
              .catch((error) => {
                console.error(error);
              });

            // if (siteDetails?.id) {
            //   InventoryAxios(GET_ALL_RESOURCES_BY_TERMINAL + `/${siteDetails?.id}`, "get")
            //     .then((res) => {
            //       const processedNodes = res.data.map(transformResourceToNode);
            //       dispatch(setImageNodePortStatus(processedNodes)); // Now all nodes have required fields
            //     })
            //     .catch((err) => console.error("API Error:", err));
            // }

            if (siteDetails?.id) {
              InventoryAxios(
                GET_ALL_RESOURCES_BY_TERMINAL + `/${siteDetails?.id}`,
                "get"
              )
                .then((res) => {
                  const processedNodes = res.data.map((resource) =>
                    transformResourceToNode(resource)
                  );

                  console.log("logindataimage", processedNodes);

                  dispatch(setImageNodePortStatus(processedNodes));
                })
                .catch((err) => console.error("API Error:", err));
            }
            await SecurityAxios(FETCH_SECURITY_SETTINGS, "get")
              .then((res) => {
                console.log("FETCH_ALL_securitysettings", res?.data);

                // 1. Extract the email from the security settings response
                // Based on your log: res.data.passwordRecoveryEmail
                const recoveryEmail = res?.data?.passwordRecoveryEmail;
                console.log("recoveryEmail", recoveryEmail);

                if (
                  !recoveryEmail ||
                  recoveryEmail === null ||
                  recoveryEmail === ""
                ) {
                  dispatch(setRequiresEmailUpdate(true));
                } else {
                  // Ensure it is false if email exists
                  dispatch(setRequiresEmailUpdate(false));
                }
              })
              .catch((error) => {
                console.error("Error fetching security settings:", error);
              });

            await updateChatUrl();

            // await fetchResourceInfo(res?.data);
            navigate("/dashboard");
            break;
          }

          case 5:
            setShowEndSession({
              visible: true,
              token: res.data?.data,
              message: res?.data?.message,
            });
            break;
          default:
            console.warn("Unexpected status code:", status); // Handle unknown status
        }
      }
    } catch (error) {
      Toast("Failed!", "Login Failed", "error");
      console.error(error);
    }
  }

  const handleInputChange = (event, fieldName) => {
    let value = event.target.value;
    formik.setFieldValue(fieldName, value);
    setTimeout(() => {
      formik.handleBlur({ target: { name: fieldName } });
    }, 0);
  };

  const handleLogoutOfExistingUser = async () => {
    setLoading(true);
    setShowEndSession({ visible: false });

    try {
      // Logout request
      await LogoutAxios(LOGOUT, "post", {
        userName: formik.values.userName,
        ...(siteDetails.id === terminalType.CNMS && {
          siteId: "CNMS_001",
        }),
      });
      const payload = createPayload(); // Reuse the payload here
      await handleLogin(payload); // Use the new handleLogin function
    } catch (error) {
      Toast("Failed!", "Login Failed", "error");
      console.error("Error during logout/login:", error);
    } finally {
      setLoading(false);
      setShowEndSession({ visible: false }); // Ensure it's hidden on error too
    }
  };

  return (
    <Box
      sx={{
        height: "94vh",
        display: "flex",
        flexDirection: "column",
        backgroundImage: (theme) => theme.palette.custom.landingImage,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        transition: "background-image 0.5s ease-in-out",
      }}
    >
      <Box
        sx={{
          flex: 1,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Paper
          elevation={6}
          sx={{
            p: 4,
            width: { xs: "90%", sm: "70%", md: "550px" },
            textAlign: "center",
            borderRadius: 5,
            mx: "auto",
            position: "absolute",
            top: "50%",
            right: "-10%",
            transform: "translate(-50%, -50%)",
            "@media (maxWidth: 901px)": {
              right: "0",
              width: { xs: "90%", sm: "70%" },
            },
            "@media (maxWidth: 600px)": {
              width: "90%",
            },
          }}
        >
          <Typography
            variant="h5"
            sx={{
              mb: 2,
              fontFamily: "Montserrat",
              fontWeight: "800",
              fontSize: { xs: "28px", md: "32px" },
            }}
          >
            <span sx={{ color: "text.drawerheader" }}>Welcome</span>
            {/* <span style={{ color: "#14348D" }}> Back</span> */}
          </Typography>
          <Typography
            sx={{
              mb: 1,
              fontFamily: "Montserrat",
              fontWeight: "500",
            }}
          >
            Please log in using your authorized credentials to access the{" "}
            {isCnms ? "CNMS" : "RNMS"} dashboard
          </Typography>

          {isCnms && (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                mb: 1,
              }}
            >
              <Typography fontWeight="bold" variant="body2">
                CNMS Login
              </Typography>

              <CustomSwitch
                checked={isLdapLogin}
                onChange={(e) => setIsLdapLogin(e.target.checked)}
              />
              <Typography fontWeight="bold" variant="body2">
                LDAP Login
              </Typography>
            </Box>
          )}

          {/* WRAP EVERYTHING IN A FORM TAG */}
          <form onSubmit={formik.handleSubmit}>
            <Box sx={{ width: "100%" }}>
              <Typography
                sx={{
                  mb: "2",
                  textAlign: "left",
                  fontFamily: "Montserrat",
                  fontWeight: "500",
                }}
              >
                Username
              </Typography>
              <Box sx={{ mb: 3, display: "flex", flexDirection: "column" }}>
                <MInput
                  fullWidth
                  placeholder="Enter a Username"
                  size="small"
                  name="userName" // Added name attribute
                  value={formik.values.userName}
                  onChange={(e) => {
                    const data = usernameRegex(e.target.value);
                    if (data !== undefined) {
                      handleInputChange(e, "userName");
                    }
                  }}
                  errorMessage={formik.errors.userName}
                />
              </Box>
            </Box>

            <Typography
              sx={{
                mb: "2",
                textAlign: "left",
                fontFamily: "Montserrat",
                fontWeight: "500",
              }}
            >
              Password
            </Typography>
            <Box
              sx={{
                mb: 3,
                display: "flex",
                width: "100%",
                flexDirection: "column",
              }}
            >
              <MInput
                fullWidth
                placeholder="Enter a Password"
                size="small"
                name="password" // Added name attribute
                type={showPassword ? "text" : "password"}
                value={formik.values.password}
                onChange={(e) => {
                  const validatedValue = passwordRegex(e.target.value);
                  if (validatedValue !== undefined) {
                    formik.setFieldValue("password", validatedValue);
                  }
                }}
                errorMessage={
                  (formik.touched.password ||
                    formik.values.password.length > 0) &&
                  formik.errors.password
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowPassword(!showPassword)}
                        edge="end"
                      >
                        {showPassword ? (
                          <VisibilityIcon />
                        ) : (
                          <VisibilityOffIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>

            <Typography
              sx={{
                mb: "2",
                textAlign: "left",
                fontFamily: "Montserrat",
                fontWeight: "500",
              }}
            >
              Captcha
            </Typography>
            <Box sx={{ display: "flex", alignItems: "center", mb: 2, gap: 1 }}>
              <Box
                sx={{
                  width: "50%",
                  backgroundColor: "#dcdcdc",
                  textAlign: "center",
                  display: "flex",
                  justifyContent: "center",
                  border: "1px solid white",
                  borderRadius: "5px",
                  padding: "3px",

                  gap: 1,
                }}
              >
                {isCaptchaLoading ? (
                  <span>Loading...</span>
                ) : (
                  <img
                    src={`data:image/png;base64,${captchaData?.image}`}
                    alt="captcha"
                    width={150}
                  />
                )}
                <Button
                  variant=""
                  sx={{
                    height: "40px",
                    backgroundColor: isDark ? "black" : "white",
                    color: isDark ? "white" : "black",

                    mt: 0.5,
                    mr: 1,
                  }}
                  onClick={fetchCaptcha}
                >
                  <RefreshCw />
                </Button>
              </Box>
              <MInput
                placeholder="Enter Captcha "
                size="small"
                name="captcha"
                inputProps={{ maxLength: 5 }}
                value={formik.values.captcha}
                onChange={(e) => {
                  const data = passwordRegex(e.target.value);
                  if (data !== undefined) {
                    handleInputChange(e, "captcha");
                  }
                }}
                errorMessage={formik.touched.captcha && formik.errors.captcha}
              />
            </Box>
            <Box sx={{ display: "flex", mt: 3 }}>
              {isCnms && (
                <Link
                  component="button"
                  type="button"
                  onClick={handleOpenModal} // Trigger the state change
                  sx={{
                    fontSize: "16px",
                    textDecoration: "none",
                    color: isDark ? "white" : "#14138d",
                    fontWeight: 500,
                    "&:hover": { textDecoration: "underline" },
                  }}
                >
                  Reset Admin Password?
                </Link>
              )}
            </Box>
            <MModal
              open={isModalOpen}
              handleClose={handleCloseModal}
              title="Reset Admin Credentials"
              customWidth="450px"
              enableFullScreen={true}
            >
              <Box
                sx={{ p: 1, display: "flex", flexDirection: "column", gap: 2 }}
              >
                <Typography sx={{ fontWeight: "bold" }}>
                  Enter the password recovery Email as configured in CNMS.
                </Typography>

                <Box sx={{ display: "flex", flexDirection: "row", gap: 3 }}>
                  <Box
                    sx={{ display: "flex", flexDirection: "column", flex: 1 }}
                  >
                    <Typography sx={{ mb: 0.5 }}>Email Address *</Typography>
                    <MInput
                      fullWidth
                      label="Admin Email"
                      variant="outlined"
                      value={email}
                      onChange={handleEmailChange} // Now validates on every keypress after touch
                      onBlur={handleEmailBlur} // Marks as touched
                      error={Boolean(emailError)}
                      errorMessage={emailError}
                      disabled={isResetLoading}
                      placeholder="Enter Admin Email"
                    />
                  </Box>

                  <Box
                    sx={{ display: "flex", flexDirection: "column", mt: 3.5 }}
                  >
                    <MButtonPrimary
                      variant="contained"
                      color="primary"
                      fullWidth
                      // onClick={handleResetPassword}
                      onClick={() => setShowConfirm(true)}
                      // Button remains disabled until validation passes
                      disabled={
                        isResetLoading || !email || validateEmail(email) !== ""
                      }
                      sx={{ mt: 1 }}
                      startIcon={
                        isResetLoading ? (
                          <CircularProgress size={20} color="inherit" />
                        ) : null
                      }
                    >
                      {isResetLoading ? "Processing..." : "Reset"}
                    </MButtonPrimary>
                  </Box>
                </Box>
              </Box>
            </MModal>
            <Box sx={{ display: "flex", justifyContent: "center", gap: 4 }}>
              <Button
                type="button"
                variant="outlined"
                sx={{
                  color: isDark ? "white" : "#14138d",
                  width: { xs: "100%", sm: "45%", md: "50%" },
                  display: "flex",
                  borderRadius: "10px",
                  fontFamily: "Montserrat",
                  border: isDark ? "1px solid white" : "1px solid blue",
                  textTransform: "none",
                  fontWeight: "Medium",
                  mt: isCnms ? 1.5 : 1,
                }}
                onClick={handleClear}
              >
                Clear
              </Button>
              <Button
                type="submit" // IMPORTANT: Set type to "submit"
                variant="contained"
                sx={{
                  width: { xs: "100%", sm: "45%", md: "50%" },
                  display: "flex",
                  borderRadius: "10px",
                  backgroundColor: "#14348D",
                  fontFamily: "Montserrat",
                  fontWeight: "700",
                  color: "white",
                  textTransform: "none",
                  mt: 1,
                }}
              >
                Login
              </Button>
            </Box>
          </form>
        </Paper>
      </Box>

      {/* REST OF YOUR CODE (Footer/Dialog/Loader) REMAINS UNCHANGED */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-end",
          alignItems: "flex-start",
          color: "white",
          width: "50%",
          "@media (maxWidth: 1276px)": {
            bottom: "10%",
          },
        }}
      >
        <Typography sx={{ ml: "10%", mb: 1, fontSize: "42px" }}>
          {isCnms ? "Central" : "Remote"} Network Management System
        </Typography>
        <Typography variant="body4" sx={{ ml: "10%", mb: "20%" }}>
          A secure platform for network monitoring, management, and operational
          control.
        </Typography>
        <MDialog
          open={showEndSession?.visible}
          icon={Confirmation_icon}
          onClose={() =>
            setShowEndSession({ visible: false, token: "", message: "" })
          }
          title="Confirmation"
          message={showEndSession?.message}
          confirmText="Yes"
          onConfirm={handleLogoutOfExistingUser}
        />
      </Box>
      {loading && <Loader />}
      <MDialog
              open={showConfirm}
              variant="warning" // or "error" depending on your theme
              title="Confirm Action"
              icon={question_mark} // Replace with a question/warning icon if you have one
              message="Are you sure you want to Reset Admin Password?"
              onConfirm={handleResetPassword}
              onClose={() => setShowConfirm(false)}
      
              // mode="grandchild"
              // isGrandchildFullScreen={isGrandchildFullScreen}
            />
    </Box>
  );
};

export default LoginAtp;
