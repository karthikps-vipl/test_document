import React, { useState, useMemo } from "react"; // Added useMemo
import { Box, Typography, Button, useTheme } from "@mui/material";
import {
  AddCircleOutlineOutlined,
  VisibilityOutlined,
  InfoOutlineRounded,
  EditOutlined,
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import MInput from "../../../components/Reusable/Input/MInput";
import MTable from "../../../components/Reusable/Table/MTable";
import MModal from "../../../components/Reusable/Modal/MModal";
import { FormControl, Select, MenuItem } from "@mui/material";

import {
  personnelNameValidation,
  rankValidation,
  unitValidation,
  primaryMobileValidation,
  afcelPhoneValidation,
  ipPhoneValidation,
  alternateMobileValidation,
  emailValidation,
} from "../../../utility/FormValidation/YupSchema";
import {
  personnelRegex,
  validateInput,
} from "../../../utility/FormValidation/Regex";

import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";

import MButtonPrimary from "../../../components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "../../../components/Reusable/Button/MButtonSecondary";
import MDialog from "../../../components/Reusable/Dialog/MDialog";
import { InventAxios } from "../../../RestAPI/api/axiosApicall";
import { SAVE_CNMS_DETAILS } from "../../../RestAPI/url/endpoint";
import Toast from "../../../components/Reusable/Toast/Toast";
import clear from "@/assets/SVGIcons/clear.svg";
import {
  setRepDetails,
  setSavedRnmsDetails,
} from "../../../store/features/nodeDetailsSlice";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import EditRepDetails from "../configurator/EditRepDetails";
import CNMSKasauli from "@/assets/SVGIcons/cnms/CNMSKasauli.svg";
import {
  setRepresentatives,
  setKasauliDetails,
  setMountAbuDetails,
} from "@/store/features/Cnms/cnmsSlice";
const MAX_REPRESENTATIVES = 5;
const DEFAULT_MOUNT_ABU = {
  siteName: "",
  siteUnitName: "",
  latitude: 24.5314,
  longitude: 72.7333,
};

const DEFAULT_KASAULI = {
  siteName: "",
  siteUnitName: "",
  latitude: 30.8985,
  longitude: 76.9658,
};

const INITIAL_REP = {
  personalName: "",
  rank: "",
  unit: "",
  primaryCivilMobile: "",
  afcelPhone: "",
  ipPhone: "",
  altCivilMobile: "",
  email: "",
};

const CnmsConfiguration = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const cnmsState = useSelector((state) => state.cnmsConfig);

  const savedResponse = cnmsState.savedData;

  console.log("savedResponse", savedResponse);

  // =========================================================
  // SITE STATE
  // =========================================================

  const [mountAbu, setMountAbu] = useState(
    cnmsState.mountAbu || DEFAULT_MOUNT_ABU
  );

  const [kasauli, setKasauli] = useState(cnmsState.kasauli || DEFAULT_KASAULI);

  const [mountAbuReps, setMountAbuReps] = useState(
    cnmsState.representatives?.mountAbu || []
  );

  const [kasauliReps, setKasauliReps] = useState(
    cnmsState.representatives?.kasauli || []
  );

  // =========================================================
  // MODAL STATE
  // =========================================================

  const [isRepModalOpen, setIsRepModalOpen] = useState(false);

  const [currentSite, setCurrentSite] = useState(null);

  const [repForm, setRepForm] = useState(INITIAL_REP);

  const [repTouched, setRepTouched] = useState({});

  const [editModalOpen, setEditModalOpen] = useState({
    visible: false,
    rowData: null,
    site: null,
  });

  const [deleteAllRowsConfirm, setDeleteAllRowsConfirm] = useState(false);

  const [rowToDelete, setRowToDelete] = useState({
    visible: false,
    row: null,
    site: null,
  });

  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const [disableConfirm, setDisableConfirm] = useState(false);

  // =========================================================
  // TOUCHED STATE
  // =========================================================

  const [mountAbuTouched, setMountAbuTouched] = useState({});

  const [kasauliTouched, setKasauliTouched] = useState({});

  // =========================================================
  // SITE VALIDATION
  // =========================================================

  const siteSchema = Yup.object({
    siteName: Yup.string()
      .required("Site Name is required")
      .test(
        "siteName-format",
        "Site Name should be between 5 to 25 alphanumeric characters",
        (value) => {
          if (!value) return false;
          return /^[a-zA-Z0-9]{5,25}$/.test(value);
        }
      ),

    siteUnitName: Yup.string()
      .required("Site Unit Name is required")
      .test(
        "siteUnitName-format",
        "Site Unit Name should be between 3 to 25 alphanumeric characters",
        (value) => {
          if (!value) return false;
          return /^[a-zA-Z0-9]{3,25}$/.test(value);
        }
      ),

    latitude: Yup.string()
      .required("Latitude is required")
      .test("latitude-range", "Should be between -90 to 90", (value) => {
        if (value === undefined || value === "") return false;
        const num = Number(value);
        return Number.isFinite(num) && num >= -90 && num <= 90;
      })
      .test(
        "latitude-decimals",
        "Latitude must have maximum 4 digits after decimal",
        (value) => {
          if (!value || !value.includes(".")) return true;
          return value.split(".")[1].length <= 4;
        }
      ),

    longitude: Yup.string()
      .required("Longitude is required")
      .test("longitude-range", "Should be between -180 to 180", (value) => {
        if (value === undefined || value === "") return false;
        const num = Number(value);
        return Number.isFinite(num) && num >= -180 && num <= 180;
      })
      .test(
        "longitude-decimals",
        "Longitude must have maximum 4 digits after decimal",
        (value) => {
          if (!value || !value.includes(".")) return true;
          return value.split(".")[1].length <= 4;
        }
      ),
  });

  const validateSite = (siteData, touchedFields) => {
    try {
      if (Object.keys(touchedFields).length === 0) {
        return {};
      }

      siteSchema.validateSync(siteData, {
        abortEarly: false,
      });

      return {};
    } catch (error) {
      const errors = {};

      error.inner?.forEach((item) => {
        if (touchedFields[item.path]) {
          errors[item.path] = item.message;
        }
      });

      return errors;
    }
  };

  const isSiteDataValid = (siteData) => {
    try {
      siteSchema.validateSync(siteData, {
        abortEarly: false,
      });

      return true;
    } catch (error) {
      return false;
    }
  };

  const mountAbuErrors = useMemo(
    () => validateSite(mountAbu, mountAbuTouched),
    [mountAbu, mountAbuTouched]
  );

  const kasauliErrors = useMemo(
    () => validateSite(kasauli, kasauliTouched),
    [kasauli, kasauliTouched]
  );

  const isMountAbuValid = isSiteDataValid(mountAbu);

  const isKasauliValid = isSiteDataValid(kasauli);

  const representativeSchema = Yup.object({
    personalName: personnelNameValidation
      .min(5, "Name should be between 5 to 50 characters.")
      .max(50, "Name should be between 5 to 50 characters."),

    rank: rankValidation,

    unit: unitValidation
      .min(3, "Should be between 3 to 20 characters")
      .max(20, "Should be between 3 to 20 characters"),

    primaryCivilMobile: primaryMobileValidation,

    afcelPhone: afcelPhoneValidation,

    ipPhone: ipPhoneValidation,

    altCivilMobile: alternateMobileValidation,

    email: emailValidation
      .min(5, "Enter a valid Email should be between 5 to 50 characters.")
      .max(50, "Enter a valid Email should be between 5 to 50 characters."),
  });

  const validateRepresentative = () => {
    try {
      representativeSchema.validateSync(repForm, {
        abortEarly: false,
      });

      return {};
    } catch (error) {
      const errors = {};

      error.inner?.forEach((item) => {
        if (repTouched[item.path]) {
          errors[item.path] = item.message;
        }
      });

      return errors;
    }
  };

  const repErrors = useMemo(
    () => validateRepresentative(),
    [repForm, repTouched]
  );

  const mandatoryRepValid =
    Boolean(repForm.personalName) &&
    Boolean(repForm.rank) &&
    Boolean(repForm.unit) &&
    Boolean(repForm.primaryCivilMobile) &&
    !repErrors.personalName &&
    !repErrors.rank &&
    !repErrors.unit &&
    !repErrors.primaryCivilMobile;

  const hasNonMandatoryErrors =
    Boolean(repErrors.afcelPhone) ||
    Boolean(repErrors.ipPhone) ||
    Boolean(repErrors.altCivilMobile) ||
    Boolean(repErrors.email);

  const isRepFormValid = mandatoryRepValid && !hasNonMandatoryErrors;

  const handleCoordinateChange = (site, field, value) => {
    if (value === "") {
      handleSiteChange(site, field, "");
      return;
    }
    if (value.length > 20) {
      return;
    }
    if (!/^-?\d+(\.\d+)?$/.test(value) && value !== "-" && value !== ".") {
      return;
    }
    // Minus sign is allowed only at the beginning.
    if (value.includes("-") && !value.startsWith("-")) {
      return;
    }

    // Only one decimal point is allowed.
    if ((value.match(/\./g) || []).length > 1) {
      return;
    }

    // Maximum 4 digits after the decimal point.
    if (value.includes(".")) {
      const decimalPart = value.split(".")[1];
      if (decimalPart.length > 4) {
        return;
      }
    }

    // Validate numeric range when a complete numeric value is available.
    const numberValue = Number(value);

    if (Number.isFinite(numberValue)) {
      const max = field === "latitude" ? 90 : 180;
      const min = -max;

      if (numberValue < min || numberValue > max) {
        return;
      }
    }

    handleSiteChange(site, field, value);
  };

  const handleSiteChange = (site, field, value) => {
    if (site === "mountAbu") {
      setMountAbu((prev) => {
        const updated = {
          ...prev,
          [field]: value,
        };

        dispatch(setMountAbuDetails(updated));

        return updated;
      });

      setMountAbuTouched((prev) => ({
        ...prev,
        [field]: true,
      }));
    } else {
      setKasauli((prev) => {
        const updated = {
          ...prev,
          [field]: value,
        };

        dispatch(setKasauliDetails(updated));

        return updated;
      });

      setKasauliTouched((prev) => ({
        ...prev,
        [field]: true,
      }));
    }
  };

  const handleRepChange = (field, value) => {
    setRepForm((prev) => ({
      ...prev,
      [field]: value,
    }));

    setRepTouched((prev) => ({
      ...prev,
      [field]: true,
    }));
  };

  const clearRepForm = () => {
    setRepForm(INITIAL_REP);
    setRepTouched({});
  };

  const handleAddRepresentative = (site) => {
    const reps = site === "mountAbu" ? mountAbuReps : kasauliReps;

    if (reps.length >= MAX_REPRESENTATIVES) {
      Toast(
        "Limit Reached!",
        "You have reached the maximum of 5 representatives.",
        "warning"
      );

      return;
    }

    clearRepForm();

    setCurrentSite(site);

    setIsRepModalOpen(true);
  };

  const handleAddRep = () => {
    if (!isRepFormValid) {
      return;
    }

    const currentReps = currentSite === "mountAbu" ? mountAbuReps : kasauliReps;

    if (currentReps.length >= MAX_REPRESENTATIVES) {
      Toast(
        "Limit Reached!",
        "You have reached the maximum of 5 representatives.",
        "warning"
      );

      return;
    }

    const newRep = {
      repId: Date.now(),

      personnelName: repForm.personalName,

      personnel: repForm.rank,

      unit: repForm.unit,

      primaryCivilMobile: repForm.primaryCivilMobile,

      afcel: repForm.afcelPhone,

      ipPhone: repForm.ipPhone,

      alternateCivilMobile: repForm.altCivilMobile,

      email: repForm.email,
    };

    let updatedMountAbuReps = mountAbuReps;

    let updatedKasauliReps = kasauliReps;

    if (currentSite === "mountAbu") {
      updatedMountAbuReps = [...mountAbuReps, newRep];

      setMountAbuReps(updatedMountAbuReps);
    } else {
      updatedKasauliReps = [...kasauliReps, newRep];

      setKasauliReps(updatedKasauliReps);
    }

    dispatch(
      setRepresentatives({
        mountAbu: updatedMountAbuReps,

        kasauli: updatedKasauliReps,
      })
    );

    Toast("Success!", "Successfully added representative", "success");

    handleCloseRepModal();
  };

  const handleCloseRepModal = () => {
    setIsRepModalOpen(false);

    setCurrentSite(null);

    clearRepForm();
  };

  const handleEdit = (row, site) => {
    setEditModalOpen({
      visible: true,
      rowData: row,
      site,
    });
  };

  const updateRowById = (id, updatedFields, site) => {
    if (site === "mountAbu") {
      setMountAbuReps((prev) =>
        prev.map((item) =>
          item.repId === id
            ? {
                ...item,
                ...updatedFields,
              }
            : item
        )
      );
    } else {
      setKasauliReps((prev) =>
        prev.map((item) =>
          item.repId === id
            ? {
                ...item,
                ...updatedFields,
              }
            : item
        )
      );
    }

    setEditModalOpen({
      visible: false,
      rowData: null,
      site: null,
    });
  };

  const handleDeleteRow = (row, site) => {
    const list = site === "mountAbu" ? mountAbuReps : kasauliReps;
    if (list.length <= 1) return;

    if (site === "mountAbu") {
      setMountAbuReps((prev) =>
        prev.filter((item) => item.repId !== row.repId)
      );
    } else {
      setKasauliReps((prev) => prev.filter((item) => item.repId !== row.repId));
    }
  };

  const handleClearEverything = () => {
    setMountAbu({
      ...DEFAULT_MOUNT_ABU,
    });

    setKasauli({
      ...DEFAULT_KASAULI,
    });

    setMountAbuReps([]);

    setKasauliReps([]);

    setMountAbuTouched({});

    setKasauliTouched({});

    clearRepForm();

    setIsPreviewMode(false);

    setDeleteAllRowsConfirm(false);

    Toast("Success!", "All configuration fields have been cleared.", "success");
  };

  const canPreview =
    isMountAbuValid &&
    isKasauliValid &&
    mountAbuReps.length > 0 &&
    kasauliReps.length > 0;

  const handlePreview = () => {
    if (!canPreview) {
      Toast(
        "Incomplete Configuration",
        "Please complete both Mount Abu and Kasauli details and add at least one representative to each site.",
        "warning"
      );

      return;
    }

    setIsPreviewMode(true);
  };

  const handleEditPreview = () => {
    setIsPreviewMode(false);
  };

  const buildRepPayload = (reps) => {
    return reps.map((item, index) => ({
      personnelName: item.personnelName,

      personnel: item.personnel,

      unit: item.unit,

      ipPhone: item.ipPhone,

      afcel: item.afcel,

      primaryCivilMobile: item.primaryCivilMobile,

      alternateCivilMobile: item.alternateCivilMobile,

      email: item.email,

      serial: index + 1,
    }));
  };

  const handleSuccess = async () => {
    if (!canPreview) {
      Toast(
        "Incomplete Configuration",
        "Please complete both site configurations.",
        "warning"
      );

      return;
    }

    setDisableConfirm(true);

    try {
      const mountAbuPayload = {
        siteName: mountAbu.siteName,

        siteNickName: mountAbu.siteUnitName,

        isConfigured: true,

        latitude: Number(mountAbu.latitude),

        longitude: Number(mountAbu.longitude),

        siteRepPhNum: "",
        siteRepDesignation: "",
        siteRepName: "",
        siteRepServiceId: "",
        siteRepAfnetPhNum: "",

        remoteNumber: 1,

        imTerminalType: {
          id: 1,
        },

        imTerminalMode: {
          id: 2,
        },

        resRepDetails: buildRepPayload(mountAbuReps),
      };

      const kasauliPayload = {
        siteName: kasauli.siteName,

        siteNickName: kasauli.siteUnitName,

        isConfigured: true,

        latitude: Number(kasauli.latitude),

        longitude: Number(kasauli.longitude),

        siteRepPhNum: "",
        siteRepDesignation: "",
        siteRepName: "",
        siteRepServiceId: "",
        siteRepAfnetPhNum: "",

        remoteNumber: 2,

        imTerminalType: {
          id: 1,
        },

        imTerminalMode: {
          id: 2,
        },

        resRepDetails: buildRepPayload(kasauliReps),
      };

      const payload = [mountAbuPayload, kasauliPayload];

      console.log("CNMS SAVE PAYLOAD:", JSON.stringify(payload, null, 2));

      const resp = await InventAxios(SAVE_CNMS_DETAILS, "post", payload);

      console.log("CNMS SAVE RESPONSE:", resp);

      if (resp?.status === 200 && resp?.data) {
        dispatch(setSavedRnmsDetails(resp.data));

        dispatch(setRepDetails(resp.data));

        Toast("Success!", "Successfully configured CNMS.", "success");

        navigate("/SucessConfigarator");
      } else {
        Toast("Failed!", "Failed to save CNMS details.", "error");
      }
    } catch (error) {
      console.error("CNMS SAVE ERROR:", error);

      Toast("Failed!", "Failed to save CNMS details.", "error");
    } finally {
      setDisableConfirm(false);
    }
  };

  const columns = [
    {
      name: "S. No",
      uid: "sno",
      width: "73px",
    },
    {
      name: "Name",
      uid: "personnelName",
      width: "130px",
    },
    {
      name: "Rank",
      uid: "personnel",
      width: "100px",
    },
    {
      name: "Unit",
      uid: "unit",
      width: "90px",
    },
    {
      name: "IP Phone",
      uid: "ipPhone",
      width: "110px",
    },
    {
      name: "AFCEL",
      uid: "afcel",
      width: "90px",
    },
    {
      name: "Primary. No",
      uid: "primaryCivilMobile",
      width: "150px",
    },
    {
      name: "Alternative. No",
      uid: "alternateCivilMobile",
      width: "150px",
    },
    {
      name: "Email",
      uid: "email",
    },
    {
      name: "Actions",
      uid: "actions",
    },
  ];

  const renderSiteSection = ({
    site,
    title,
    siteData,
    errors,
    reps,
    isSiteValid,
  }) => {
    const isMount = site === "mountAbu";
    const tableHeight =
      reps.length === 0 ? "auto" : `${reps.length * 48 + 60}px`;

    return (
      <Box
        sx={{
          backgroundColor: theme.palette.custom.configuration.configcard,

          borderRadius: isMount ? "20px 20px 0px 0px" : "0px 0px 20px 20px",

          width: "95%",
          ml: 4,
          position: "relative",

          border: "2px solid #eee",

          boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.05)",

          overflow: "hidden",
          mt: 0.3,
          mb: isMount ? 0 : 2,
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            p: 0.5,
            // background: "#F3F3F3",
            pl: 4,
            pr: 4,

            borderRadius: isMount ? "15px 15px 0px 0px" : "0px",
          }}
        >
          <img
            src={CNMSKasauli}
            alt={title}
            style={{
              height: "25px",
              width: "25px",
              objectFit: "contain",

              filter: theme.palette.custom.icon.iconFilter,
            }}
          />

          <Typography
            sx={{
              fontFamily: "Montserrat",
              fontSize: 18,
              color: theme.palette.custom.configuration.configmodaltext,
              fontWeight: 500,
            }}
          >
            {title}
          </Typography>

          {isMount && (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,

                color: theme.palette.custom.configuration.configmodaltext,
                flex: 1,
                justifyContent: "flex-start",
                minWidth: "320px",
              }}
            >
              <InfoOutlineRounded
                sx={{
                  fontSize: 28,
                }}
              />

              <Typography
                sx={{
                  fontFamily: "Montserrat",
                  fontWeight: 600,
                  fontSize: 14,
                  color: theme.palette.text.TitleTextcolor,
                }}
              >
                This configuration is to be done only once and the details have
                to be filled carefully.
              </Typography>
            </Box>
          )}
        </Box>

        <Box
          sx={{
            borderTop: "1px solid #ccc",
          }}
        />

        {/* SITE FIELDS */}

        <Box
          sx={{
            width: "100%",
            padding: "0% 1% 0% 1%",
            ml: 3,
          }}
        >
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "15px",
            }}
          >
            {/* SITE NAME */}

            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                mr: 8,
                width: "90%",
                mt: 0.5,
              }}
            >
              <Typography sx={{ fontSize: "14px" }}>Site Name *</Typography>

              <MInput
                value={siteData.siteName}
                placeholder="Enter Site Name"
                disabled={isPreviewMode}
                readOnly={isPreviewMode}
                onChange={(e) => {
                  const value = e.target.value;

                  // Site Name: alphanumeric only, maximum 25 characters.
                  if (value.length <= 25 && /^[a-zA-Z0-9]*$/.test(value)) {
                    handleSiteChange(site, "siteName", value);
                  }
                }}
                errorMessage={errors.siteName}
              />
            </Box>

            {/* SITE UNIT NAME */}

            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "90%",
                mt: 0.5,
              }}
            >
              <Typography sx={{ fontSize: "14px" }}>
                Site Unit Name *
              </Typography>

              <MInput
                value={siteData.siteUnitName}
                placeholder="Enter Site Unit Name"
                disabled={isPreviewMode}
                readOnly={isPreviewMode}
                onChange={(e) => {
                  const value = e.target.value;

                  if (value.length <= 25 && /^[a-zA-Z0-9]*$/.test(value)) {
                    handleSiteChange(site, "siteUnitName", value);
                  }
                }}
                errorMessage={errors.siteUnitName}
              />
            </Box>

            {/* LATITUDE */}

            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                mb: 1,
                width: "90%",
              }}
            >
              <Typography sx={{ fontSize: "14px" }}>
                Latitude (Dec) *
              </Typography>

              <MInput
                value={siteData.latitude}
                placeholder="-90 to 90"
                disabled={isPreviewMode}
                readOnly={isPreviewMode}
                onChange={(e) => {
                  handleCoordinateChange(site, "latitude", e.target.value);
                }}
                errorMessage={errors.latitude}
              />
            </Box>

            {/* LONGITUDE */}

            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                mr: 2,
                width: "90%",
              }}
            >
              <Typography sx={{ fontSize: "14px" }}>
                Longitude (Dec) *
              </Typography>

              <MInput
                value={siteData.longitude}
                placeholder="-180 to 180"
                disabled={isPreviewMode}
                readOnly={isPreviewMode}
                onChange={(e) => {
                  handleCoordinateChange(site, "longitude", e.target.value);
                }}
                errorMessage={errors.longitude}
              />
            </Box>
          </Box>
        </Box>

        <Box
          sx={{
            borderTop: "1px solid #ccc",
            mt: 0.5,
          }}
        />

        <Box
          sx={{
            width: "100%",
          }}
        >
          <MTable
            typeHeight="configuration"
            configHeight={tableHeight}
            deleteDisable={() => reps.length <= 1}
            editDisable={false}
            columns={
              isPreviewMode
                ? columns.filter((item) => item.uid !== "actions")
                : columns
            }
            tableData={reps}
            handleAdd={() => handleAddRepresentative(site)}
            hideAdd={isPreviewMode}
            handleEdit={(row) => handleEdit(row, site)}
            handleDelete={(row) => {
              setRowToDelete({
                visible: true,
                row,
                site,
              });
            }}
            AddText="Add Rep."
            tableTitle="Representative Details"
            addDisable={!isSiteValid || reps.length >= MAX_REPRESENTATIVES}
            addIcon={<AddCircleOutlineOutlined />}
          />
        </Box>

        {/* Note only (Info text moved to header) */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            gap: 2,
            px: 1,
            py: 1,
            flexWrap: "wrap",
          }}
        >
          <Typography
            sx={{
              color: "#e75656",
              fontSize: "14px",
            }}
          >
            Note: Maximum 5 Rep's can be added.
          </Typography>
        </Box>
      </Box>
    );
  };

  const representativeModal = (
    <MModal
      open={isRepModalOpen}
      handleClose={handleCloseRepModal}
      title="Add Representative"
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          gap: "15px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 8,
            width: "100%",
            mt: 2,
          }}
        >
          <Typography>Personal Name *</Typography>

          <MInput
            label="Personnel Name"
            value={repForm.personalName}
            placeholder="Enter personnel name"
            onChange={(e) => {
              const value = e.target.value;

              if (value.length <= 50 && /^[a-zA-Z\s]*$/.test(value)) {
                handleRepChange("personalName", value);
              }
            }}
            errorMessage={repTouched.personalName && repErrors.personalName}
          />
        </Box>

        {/* RANK */}

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 2,
            width: "100%",
            mt: 2,
          }}
        >
          <Typography>Rank *</Typography>

          <FormControl fullWidth>
            <Select
              size="small"
              value={repForm.rank}
              onChange={(e) => handleRepChange("rank", e.target.value)}
              sx={{
                "& .MuiSelect-select": {
                  fontFamily: "Montserrat",
                },
              }}
            >
              <MenuItem value="AIR CMDE">AIR CMDE</MenuItem>

              <MenuItem value="GP CAPT">GP CAPT</MenuItem>

              <MenuItem value="WG CDR">WG CDR</MenuItem>

              <MenuItem value="SQN LDR">SQN LDR</MenuItem>

              <MenuItem value="FLT LT">FLT LT</MenuItem>

              <MenuItem value="FG OFFR">FG OFFR</MenuItem>

              <MenuItem value="MWO">MWO</MenuItem>

              <MenuItem value="WO">WO</MenuItem>

              <MenuItem value="JWO">JWO</MenuItem>

              <MenuItem value="SGT">SGT</MenuItem>

              <MenuItem value="CPL">CPL</MenuItem>

              <MenuItem value="LAC">LAC</MenuItem>

              <MenuItem value="AC">AC</MenuItem>

              <MenuItem value="AGV">AGV</MenuItem>
            </Select>
          </FormControl>
        </Box>

        {/* UNIT — allow backspace, max 20 typing, min 3 by Yup */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 8,
            width: "100%",
          }}
        >
          <Typography>Unit *</Typography>

          <MInput
            label="Unit"
            value={repForm.unit}
            placeholder="Enter unit"
            onChange={(e) => {
              const value = e.target.value;

              // 👈 only enforce max length so backspace works
              if (value.length <= 20) {
                handleRepChange("unit", value);
              }
            }}
            errorMessage={repTouched.unit && repErrors.unit}
          />
        </Box>

        {/* PRIMARY MOBILE */}

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 2,
            width: "100%",
          }}
        >
          <Typography>Primary Civil Mobile *</Typography>

          <MInput
            label="Primary Civil Mobile"
            value={repForm.primaryCivilMobile}
            placeholder="6-9xxxxxxxxx"
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.primaryMobile) !==
                undefined
              ) {
                handleRepChange("primaryCivilMobile", e.target.value);
              }
            }}
            errorMessage={
              repTouched.primaryCivilMobile && repErrors.primaryCivilMobile
            }
          />
        </Box>

        {/* AFCEL */}

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 8,
            width: "100%",
            mt: 2,
          }}
        >
          <Typography>AFCEL Phone</Typography>

          <MInput
            label="AFCEL Phone"
            value={repForm.afcelPhone}
            placeholder="1-9xxxxxxx"
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.landline) !==
                undefined
              ) {
                handleRepChange("afcelPhone", e.target.value);
              }
            }}
            errorMessage={repTouched.afcelPhone && repErrors.afcelPhone}
          />
        </Box>

        {/* IP PHONE */}

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 8,
            width: "100%",
            mt: 2,
          }}
        >
          <Typography>IP Phone</Typography>

          <MInput
            label="IP Phone"
            value={repForm.ipPhone}
            placeholder="1-9xxxxxxx"
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.landline) !==
                undefined
              ) {
                handleRepChange("ipPhone", e.target.value);
              }
            }}
            errorMessage={repTouched.ipPhone && repErrors.ipPhone}
          />
        </Box>

        {/* ALTERNATE MOBILE */}

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 8,
            width: "100%",
            mt: 2,
          }}
        >
          <Typography>Alternative Civil Phone No.</Typography>

          <MInput
            label="Alternate Civil Mobile No."
            value={repForm.altCivilMobile}
            placeholder="5-9xxxxxxxxx"
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.altMobile) !==
                undefined
              ) {
                handleRepChange("altCivilMobile", e.target.value);
              }
            }}
            errorMessage={repTouched.altCivilMobile && repErrors.altCivilMobile}
          />
        </Box>

        {/* EMAIL — allow backspace, max 50 typing */}

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 8,
            width: "100%",
            mt: 2,
          }}
        >
          <Typography>Email</Typography>

          <MInput
            label="Email"
            value={repForm.email}
            placeholder="example@domain.com"
            onChange={(e) => {
              const value = e.target.value;

              if (value.length <= 50) {
                handleRepChange("email", value);
              }
            }}
            errorMessage={repTouched.email && repErrors.email}
          />
        </Box>
      </Box>

      {/* MODAL BUTTONS */}

      <Box
        sx={{
          float: "right",
          display: "flex",
          mt: 3,
          gap: "7%",
        }}
      >
        <MButtonPrimary onClick={handleAddRep} disabled={!isRepFormValid}>
          <AddCircleOutlineOutlined
            sx={{
              mr: 1,
              fontSize: "25px",
            }}
          />
          Add
        </MButtonPrimary>

        <MButtonSecondary variant="outlined" onClick={clearRepForm}>
          <img
            src={clear}
            alt="clear"
            style={{
              filter: theme.palette.custom.icon.iconFilter,
            }}
          />
          Clear
        </MButtonSecondary>
      </Box>
    </MModal>
  );

  const previewButtons = isPreviewMode ? (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        gap: 3,
        padding: 3,
      }}
    >
      <Button
        variant="contained"
        sx={{
          padding: "8px 20px",
          display: "flex",
          borderRadius: "10px",
          backgroundColor: "#14348D",
          fontFamily: "Montserrat",
          fontWeight: "500",
          color: "white",
          textTransform: "none",
        }}
        onClick={handleEditPreview}
      >
        <EditOutlined
          sx={{
            mr: 1,
            fontSize: "20px",
          }}
        />
        Edit
      </Button>

      <Button
        variant="outlined"
        disabled={disableConfirm}
        sx={{
          color: "text.TitleTextcolor",
          display: "flex",
          borderRadius: "10px",
          fontFamily: "Montserrat",
          textTransform: "none",
          fontWeight: "500",
          padding: "8px 20px",
          border: theme.palette.custom.border,
        }}
        onClick={handleSuccess}
      >
        Confirm
      </Button>
    </Box>
  ) : (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        gap: 2,
        mb: 2,
        mt: 2,
      }}
    >
      <MButtonSecondary
        variant="outlined"
        onClick={() => setDeleteAllRowsConfirm(true)}
      >
        <img
          src={clear}
          alt="clear"
          style={{
            filter: theme.palette.custom.icon.iconFilter,
          }}
        />
        Clear
      </MButtonSecondary>

      <Button
        variant="contained"
        disabled={!canPreview}
        sx={{
          padding: "8px 20px",
          display: "flex",
          borderRadius: "10px",
          backgroundColor: "#14348D",
          fontFamily: "Montserrat",
          fontWeight: "500",
          color: "white",
          textTransform: "none",

          "&.Mui-disabled": {
            backgroundColor: "#cccccc",
            color: "#666666",
          },
        }}
        onClick={handlePreview}
      >
        <VisibilityOutlined
          sx={{
            mr: 1,
            fontSize: "20px",
          }}
        />
        Preview
      </Button>
    </Box>
  );

  return (
    <Box
      sx={{
        height: "91.5vh",
        width: "95%",
        maxWidth: "1400px",

        backgroundColor: theme.palette.custom.configuration.configmodal,

        border: "1px solid #e2e2e2",

        borderRadius: {
          xs: "20px",
          md: "40px",
        },

        display: "flex",
        flexDirection: "column",
        alignItems: "center",

        margin: "1% auto",

        position: "relative",

        overflow: "auto",

        "@media (maxWidth: 600px)": {
          width: "100%",
          margin: "0",
          borderRadius: "0px",
          border: "none",
        },
      }}
    >
      <Box
        sx={{
          height: "100%",
          width: "100%",
        }}
      >
        {/* TITLE */}

        <Typography
          variant="h5"
          sx={{
            ml: "5%",
            mb: 1,
            mt: 1,
            p: 0.5,

            fontWeight: "600",
            fontSize: "17px",
          }}
        >
          CNMS Configurator
          {isPreviewMode ? " Preview" : ""}
        </Typography>

        <Box
          sx={{
            borderTop: "1px solid #ccc",
          }}
        />

        {/* MOUNT ABU */}

        {renderSiteSection({
          site: "mountAbu",
          title: "Mount Abu",
          siteData: mountAbu,
          errors: mountAbuErrors,
          reps: mountAbuReps,
          isSiteValid: isMountAbuValid,
        })}

        {/* KASAULI */}

        {renderSiteSection({
          site: "kasauli",
          title: "Kasauli",
          siteData: kasauli,
          errors: kasauliErrors,
          reps: kasauliReps,
          isSiteValid: isKasauliValid,
        })}

        {/* PREVIEW BUTTONS */}

        {previewButtons}
      </Box>

      {/* REPRESENTATIVE MODAL */}

      {representativeModal}

      {/* EDIT REPRESENTATIVE */}

      {editModalOpen.visible && (
        <EditRepDetails
          rowData={editModalOpen.rowData}
          setEditModalOpen={setEditModalOpen}
          repTableData={
            editModalOpen.site === "mountAbu" ? mountAbuReps : kasauliReps
          }
          setRepTableData={
            editModalOpen.site === "mountAbu" ? setMountAbuReps : setKasauliReps
          }
          onUpdate={(id, updatedFields) =>
            updateRowById(id, updatedFields, editModalOpen.site)
          }
        />
      )}

      {/* CLEAR ALL DIALOG */}

      {deleteAllRowsConfirm && (
        <MDialog
          variant="error"
          title="Confirm Action"
          message="Are you sure you want to clear all the fields?"
          icon={Delete_Icon_}
          open={deleteAllRowsConfirm}
          onConfirm={handleClearEverything}
          onClose={() => setDeleteAllRowsConfirm(false)}
        />
      )}

      {/* DELETE ROW DIALOG */}

      {rowToDelete.visible && (
        <MDialog
          icon={Delete_Icon_}
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          message="Are you sure you want to delete?"
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row, rowToDelete.site);

            setRowToDelete({
              visible: false,
              row: null,
              site: null,
            });

            Toast("Success!", "Successfully deleted row", "success");
          }}
          onClose={() =>
            setRowToDelete({
              visible: false,
              row: null,
              site: null,
            })
          }
        />
      )}
    </Box>
  );
};

export default CnmsConfiguration;
