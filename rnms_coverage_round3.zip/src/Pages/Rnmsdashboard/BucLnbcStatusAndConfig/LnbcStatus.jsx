import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Box, Typography, Grid, Paper } from "@mui/material";

import Toast from "@/components/Reusable/Toast/Toast";
import MTextAreaAntD from "@/components/Reusable/Texarea/MTextArea";
import {
  GET_LNBC_SERIAL_STATUS,
  GET_LNBC_SERIAL_STATUS_AT_CNMS,
} from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";

const LnbcStatus = ({ resourceId, node, pollInterval = 30, setLoading }) => {
  const [Data, setData] = useState({});
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const siteId = node?.siteId;

  // Fetch LNBC Status
  const getData = async () => {
    if (!resourceId) return;

    setLoading?.(true);

    try {
      let response;
      if (isCnms) {
        response = await ConfigurationAxios(
          `${GET_LNBC_SERIAL_STATUS_AT_CNMS}/${resourceId}`,
          "get",
          { siteId: siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${GET_LNBC_SERIAL_STATUS}/${resourceId}`,
          "get"
        );
      }
      console.log("responseresponse", response);
      if (response?.data?.data == null) {
        Toast("Error", "No Response From Device", "error");
      } else if (response?.data?.status === 1) {
        setData(response.data.data);
      } else {
        Toast(
          "Error",
          response?.data?.message || "Unable to fetch LNBC status",
          "error"
        );
      }
    } catch (error) {
      console.error("LNBC Status Error:", error);
      Toast("Error", "Failed to fetch LNBC status.", "error");
    } finally {
      setLoading?.(false);
    }
  };

  // Polling
  useEffect(() => {
    getData();

    const polling = setInterval(() => {
      getData();
    }, (pollInterval || 30) * 1000);

    return () => clearInterval(polling);
  }, [resourceId, siteId, pollInterval]);

  // Last received date/time
  const lastReceived = Data?.readingTime ? Data.readingTime : "--";

  // Device Information
  const deviceInformation = [
    {
      label: "Description",
      value: Data?.description,
    },
    {
      label: "Build Date",
      value: Data?.buildDate,
    },
    {
      label: "Serial Number",
      value: Data?.serialNumber,
    },
    {
      label: "Uptime",
      value: Data?.uptime,
    },
    {
      label: "Part Number",
      value: Data?.partNumber,
    },
    {
      label: "Temperature (°C)",
      value: Data?.temperature,
    },
  ];

  // Device Parameters
  const deviceParameters = [
    {
      label: "WGS Position",
      value: Data?.wgsPosition,
    },
    {
      label: "Number of LNB",
      value: Data?.numberLNB,
    },
    {
      label: "Band Select",
      value: Data?.bandSelect,
    },
  ];

  // LNB Ready Status
  const lnbReadyStatus = [
    {
      label: "LNB-1",
      value: Data?.lnbReadyOne,
    },
    {
      label: "LNB-2",
      value: Data?.lnbReadyTwo,
    },
  ];

  // Reusable field component
  const renderStatusField = (field) => (
    <Box
      sx={{
        p: 1.5,
        border: "1px solid #e0e0e0",
        borderRadius: 2,
        backgroundColor: "#fafafa",
        height: "100%",
      }}
    >
      <Typography
        sx={{
          mb: 1,
          fontSize: "13px",
          fontWeight: 500,
          color: "#555",
        }}
      >
        {field.label}
      </Typography>

      <MTextAreaAntD
        autoSize={{ minRows: 1, maxRows: 2 }}
        value={
          field.value !== null &&
          field.value !== undefined &&
          field.value !== ""
            ? field.value
            : "----"
        }
        showUnit={false}
        onChange={() => {}}
      />
    </Box>
  );

  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: "#f4f6f8",
        p: 2,
      }}
    >
      {/* LAST RECEIVED DATE - TOP RIGHT */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          mb: 2,
          gap: 1,
        }}
      >
        <Typography
          sx={{
            fontSize: "13px",
            color: "#666",
            fontWeight: 500,
          }}
        >
          Last Received Data:
        </Typography>

        <Typography
          sx={{
            fontSize: "13px",
            fontWeight: 600,
            color: "primary.main",
          }}
        >
          {lastReceived}
        </Typography>
      </Box>

      {/* DEVICE INFORMATION - FULL WIDTH */}
      <Paper
        sx={{
          p: 2,
          borderRadius: 2,
          mb: 2,
        }}
      >
        <Typography variant="h6" fontWeight="bold" mb={2}>
          Device Information
        </Typography>

        <Grid container spacing={2}>
          {deviceInformation.map((field, index) => (
            <Grid item xs={12} sm={6} key={index}>
              {renderStatusField(field)}
            </Grid>
          ))}
        </Grid>
      </Paper>

      {/* DEVICE PARAMETERS + LNB READY STATUS */}
      <Grid spacing={2} className="grid grid-cols-2 gap-2">
        {/* DEVICE PARAMETERS - 50% */}
        <Grid item xs={12} md={6}>
          <Paper
            sx={{
              p: 2,
              borderRadius: 2,
              height: "100%",
            }}
          >
            <Typography variant="h6" fontWeight="bold" mb={2}>
              Device Parameters
            </Typography>

            <Grid container spacing={2}>
              {deviceParameters.map((field, index) => (
                <Grid item xs={12} sm={6} key={index}>
                  {renderStatusField(field)}
                </Grid>
              ))}
            </Grid>
          </Paper>
        </Grid>

        {/* LNB READY STATUS - 50% */}
        <Grid item xs={12} md={6}>
          <Paper
            sx={{
              p: 2,
              borderRadius: 2,
              height: "100%",
            }}
          >
            <Typography variant="h6" fontWeight="bold" mb={2}>
              LNB Ready Status
            </Typography>

            <Grid container spacing={2}>
              {lnbReadyStatus.map((field, index) => (
                <Grid item xs={12} sm={6} key={index}>
                  {renderStatusField(field)}
                </Grid>
              ))}
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default LnbcStatus;
