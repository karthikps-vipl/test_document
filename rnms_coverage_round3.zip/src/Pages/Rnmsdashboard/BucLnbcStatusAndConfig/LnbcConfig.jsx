import React, { useEffect, useState } from "react";
import { Box, Typography, CircularProgress } from "@mui/material";
import { useSelector } from "react-redux";
import {
  CONFIG_LNBC_SERIAL,
  CONFIG_LNBC_SERIAL_AT_CNMS,
  GET_LNBC_SERIAL_CONFIG_STATUS,
  GET_LNBC_SERIAL_CONFIG_STATUS_AT_CNMS,
} from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MForm from "@/components/Reusable/Form/MForm";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const LnbcConfig = ({ resourceId, node, pollInterval = 30, setLoading }) => {
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const siteId = node?.siteId;
  const [OnData, setOnData] = useState({
    bandSelectConf: "",
    switchOver: "",
  });

  const [originalData, setOriginalData] = useState({
    bandSelectConf: "",
    switchOver: "",
  });

  const [lastReceived, setLastReceived] = useState("");

  const [savingControl, setSavingControl] = useState(false);
  const [savingConfiguration, setSavingConfiguration] = useState(false);

  const bandOptions = [
    { label: "Not Supported", value: "0" },
    { label: "Low Band", value: "1" },
    { label: "High Band", value: "2" },
  ];

  const switchOverOptions = [
    { label: "Unknown", value: "0" },
    { label: "LNB-1", value: "1" },
    { label: "LNB-2", value: "2" },
  ];

  // Fetch existing configuration
  const fetchConfigData = async () => {
    try {
      setLoading?.(true);

      let response;

      if (isCnms) {
        response = await ConfigurationAxios(
          `${GET_LNBC_SERIAL_CONFIG_STATUS_AT_CNMS}/${resourceId}`,
          "get",
          { siteId: siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${GET_LNBC_SERIAL_CONFIG_STATUS}/${resourceId}`,
          "get"
        );
      }

      if (response?.data?.status === 1 && response?.data?.data) {
        const data = response.data.data;

        const fetchedData = {
          bandSelectConf:
            data.bandSelectConf !== null && data.bandSelectConf !== undefined
              ? String(data.bandSelectConf)
              : "",
          switchOver:
            data.switchOver !== null && data.switchOver !== undefined
              ? String(data.switchOver)
              : "",
        };

        setOnData(fetchedData);
        setOriginalData(fetchedData);

        setLastReceived(data.readingTime || new Date().toLocaleString("en-GB"));
      } else {
        Toast(
          "Error",
          response?.data?.message || "No Response From Device",
          "error"
        );
      }
    } catch (error) {
      Toast("Error", "Failed to fetch LNBC configuration.", "error");
    } finally {
      setLoading?.(false);
    }
  };

  useEffect(() => {
    if (!resourceId) return;

    fetchConfigData();

    // Polling for latest configuration
    const polling = setInterval(() => {
      fetchConfigData();
    }, (pollInterval || 30) * 1000);

    return () => clearInterval(polling);
  }, [resourceId, siteId, pollInterval]);

  // Handle dropdown changes
  const handleInputChange = (field, value) => {
    setOnData((prev) => ({
      ...prev,
      [field]: value !== "" ? String(value) : "",
    }));
  };

  // Save System Control / System Configuration independently
  const handleSave = async (typeConfig) => {
    const isControl = typeConfig === 1;

    const setSaving = isControl ? setSavingControl : setSavingConfiguration;

    const field = isControl ? "bandSelectConf" : "switchOver";

    if (OnData[field] === "") {
      Toast("Error", "Please select a value before saving.", "error");
      return;
    }

    try {
      setSaving(true);
      setLoading?.(true);

      let response;

      const payload = {
        bandSelectConf: Number(OnData.bandSelectConf),
        switchOver: Number(OnData.switchOver),
        typeConfig,
      };

      if (isCnms) {
        response = await ConfigurationAxios(
          `${CONFIG_LNBC_SERIAL_AT_CNMS}/${resourceId}`,
          "post", // Adjust method if necessary (e.g., "put", "patch")
          { ...payload, siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${CONFIG_LNBC_SERIAL}/${resourceId}`,
          "post", // Adjust method if necessary
          payload
        );
      }

      if (response?.data?.status === 1) {
        Toast(
          "Success",
          isControl
            ? "System Control Saved Successfully"
            : "System Configuration Saved Successfully",
          "success"
        );

        setOriginalData((prev) => ({
          ...prev,
          [field]: OnData[field],
        }));

        setLastReceived(new Date().toLocaleString("en-GB"));
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to save configuration.",
          "error"
        );
      }
    } catch (error) {
      Toast("Error", "Failed to save LNBC configuration.", "error");
    } finally {
      setSaving(false);
      setLoading?.(false);
    }
  };

  const controlChanged = OnData.bandSelectConf !== originalData.bandSelectConf;

  const configurationChanged = OnData.switchOver !== originalData.switchOver;

  return (
    <Box sx={{ width: "100%", p: 2 }}>
      {/* Last Received Date */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          mb: 2,
        }}
      >
        <Typography
          sx={{
            fontSize: "13px",
            fontWeight: 500,
            color: "text.secondary",
          }}
        >
          Last Received Data:{" "}
          <Box component="span" sx={{ color: "text.primary", fontWeight: 600 }}>
            {lastReceived || "--"}
          </Box>
        </Typography>
      </Box>

      {/* Two configuration sections */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "1fr 1fr",
          },
          gap: 3,
          alignItems: "stretch",
        }}
      >
        {/* SYSTEM CONTROL */}
        <MForm title="System Control" paddingX={2}>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
            <Box>
              <Typography
                sx={{
                  mb: 0,
                  fontSize: "13px",
                  fontWeight: 500,
                  color: "text.secondary",
                }}
              >
                Band Select
              </Typography>

              <MAlarmSelect
                label=""
                value={OnData.bandSelectConf}
                onChange={(val) => handleInputChange("bandSelectConf", val)}
                options={bandOptions}
                multiple={false}
              />
            </Box>

            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                mt: 2,
              }}
            >
              <MButtonPrimary
                variant="contained"
                onClick={() => handleSave(1)}
                disabled={!controlChanged || savingControl}
                startIcon={
                  savingControl ? (
                    <CircularProgress size={18} color="inherit" />
                  ) : null
                }
              >
                {savingControl ? "Saving..." : "Save"}
              </MButtonPrimary>
            </Box>
          </Box>
        </MForm>

        {/* SYSTEM CONFIGURATION */}
        <MForm title="System Configuration" paddingX={2}>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
            <Box>
              <Typography
                sx={{
                  mb: 0,
                  fontSize: "13px",
                  fontWeight: 500,
                  color: "text.secondary",
                }}
              >
                Switch Over
              </Typography>

              <MAlarmSelect
                label=""
                value={OnData.switchOver}
                onChange={(val) => handleInputChange("switchOver", val)}
                options={switchOverOptions}
                multiple={false}
              />
            </Box>

            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                mt: 2,
              }}
            >
              <MButtonPrimary
                variant="contained"
                onClick={() => handleSave(2)}
                disabled={!configurationChanged || savingConfiguration}
                startIcon={
                  savingConfiguration ? (
                    <CircularProgress size={18} color="inherit" />
                  ) : null
                }
              >
                {savingConfiguration ? "Saving..." : "Save"}
              </MButtonPrimary>
            </Box>
          </Box>
        </MForm>
      </Box>
    </Box>
  );
};

export default LnbcConfig;
