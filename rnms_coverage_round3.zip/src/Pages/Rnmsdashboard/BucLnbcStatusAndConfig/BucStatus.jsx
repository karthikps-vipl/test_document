import React, { useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { Box, Typography, Grid, Paper } from "@mui/material";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

import Toast from "@/components/Reusable/Toast/Toast";
import {
  GET_BUC_SERIAL_STATUS,
  GET_BUC_SERIAL_STATUS_AT_CNMS,
} from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import MTextAreaAntD from "@/components/Reusable/Texarea/MTextArea";

const BucStatus = ({ resourceId, node, pollInterval = 30, setLoading }) => {
  const [OnData, setOnData] = useState({});
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const siteId = node?.siteId;

  // Fetch BUC Status
  const getData = async () => {
    if (!resourceId) return;

    setLoading?.(true);

    try {
      let response;

      if (isCnms) {
        response = await ConfigurationAxios(
          `${GET_BUC_SERIAL_STATUS_AT_CNMS}/${resourceId}`, // Pass the URL
          "get", // Pass the method
          { siteId: siteId } // Pass the object payload
        );
      } else {
        response = await ConfigurationAxios(
          `${GET_BUC_SERIAL_STATUS}/${resourceId}`, // Pass the URL
          "get"
        );
      }

      if (response?.data?.status === 1) {
        setOnData(response.data.data || {});
      } else {
        Toast(
          "Error",
          response?.data?.message || "Unable to fetch BUC status",
          "error"
        );
      }
    } catch (error) {
      console.error("BUC Status Error:", error);
      Toast("Error", "Failed to fetch status", "error");
    } finally {
      setLoading?.(false);
    }
  };

  // Polling
  useEffect(() => {
    getData();

    const polling = setInterval(() => {
      getData();
    }, (pollInterval || 30) * 1000);

    return () => clearInterval(polling);
  }, [resourceId, siteId, pollInterval]);

  // Registry temperature scale
  const ScaleWidget = WIDGET_REGISTRY.scale?.renderCanvas;

  const temperatureWidget = useMemo(
    () => ({
      tableTitle: "Temperature",
      minVal: 0,
      maxVal: 100,
      data: [
        {
          name: "Temperature (°C)",
          currentValue: Number(OnData?.temperature) || 0,
        },
      ],
    }),
    [OnData?.temperature]
  );

  // Common reusable status fields
  const statusFields = [
    {
      label: "Serial Number",
      value: OnData?.serialNumber,
    },
    {
      label: "Part Number",
      value: OnData?.partNumber,
    },
    {
      label: "Module Name",
      value: OnData?.moduleName,
    },
    {
      label: "Uptime",
      value: OnData?.uptime,
    },
    {
      label: "Build Date",
      value: OnData?.buildDate,
    },
    {
      label: "Input Power",
      value: OnData?.inputPower,
    },
    {
      label: "Output Power (dBm)",
      value: OnData?.outputPower,
      unit: "dBm",
    },
    {
      label: "Temperature (Degree C)",
      value: OnData?.temperature,
      unit: "°C",
    },
    {
      label: "Mute",
      value: OnData?.operatingMute,
    },
    {
      label: "PLL Locked",
      value: OnData?.pplLock,
    },
    {
      label: "LO Selected",
      value: OnData?.loSelect,
    },
    // {
    //   label: "Administrative Mute",
    //   value: OnData?.administrativeMute,
    // },
    // {
    //   label: "Central Frequency (GHz)",
    //   value: OnData?.centralFrequecy,
    //   unit: "GHz",
    // },
    {
      label: "Attenuation (dB)",
      value: OnData?.atteneuation,
      unit: "dB",
    },
    // {
    //   label: "Gain (dB)",
    //   value: OnData?.gain,
    //   unit: "dB",
    // },
    {
      label: "Redundancy",
      value: OnData?.redundancyEnableStatus,
    },
    {
      label: "Unit Name",
      value: OnData?.unitName,
    },
    // {
    //   label: "Unit Status",
    //   value: OnData?.unitStatus,
    // },
    // {
    //   label: "System Status",
    //   value: OnData?.systemStatus,
    // },
  ];

  // Reusable display component
  const renderStatusField = (field) => (
    <Box
      sx={{
        p: 1.5,
        border: "1px solid #e0e0e0",
        borderRadius: 2,
        backgroundColor: "#fafafa",
        height: "100%",
      }}
    >
      <Typography
        sx={{
          mb: 1,
          fontSize: "13px",
          fontWeight: 500,
          color: "#555",
        }}
      >
        {field.label}
      </Typography>

      <MTextAreaAntD
        autoSize={{ minRows: 1, maxRows: 2 }}
        value={
          field.value !== null &&
          field.value !== undefined &&
          field.value !== ""
            ? field.value
            : "----"
        }
        showUnit={!!field.unit}
        unit={field.unit || ""}
        onChange={() => {}}
      />
    </Box>
  );

  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: "#f4f6f8",
        p: 2,
        display: "grid",
        gridTemplateColumns: "1fr 0.25fr", // Forces 80% : 20% on screens larger than sm/md
        gap: 2,
        // Ensure it wraps to 1 column on mobile
        "@media (max-width: 600px)": {
          gridTemplateColumns: "1fr",
        },
      }}
    >
      {/* LEFT SIDE - DETAILS (Takes remaining space) */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          minWidth: 0, // Prevents overflow in flex items
        }}
      >
        <Paper
          sx={{
            p: 2,
            borderRadius: 2,
            height: "100%",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography variant="h6" fontWeight="bold" mb={2}>
            BUC Status
          </Typography>

          <Grid container spacing={2}>
            {statusFields.map((field, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                {renderStatusField(field)}
              </Grid>
            ))}
          </Grid>
        </Paper>
      </Box>

      {/* RIGHT SIDE - TEMPERATURE (Fixed 20%) */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          minWidth: 0,
        }}
      >
        <Paper
          sx={{
            p: 2,
            borderRadius: 2,
            height: "100%",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* <Typography variant="h6" fontWeight="bold" textAlign="center" mb={2}>
            Temperature (°C)
          </Typography> */}

          <Box
            sx={{
              height: 300,
              border: "1px solid #e0e0e0",
              borderRadius: 2,
              backgroundColor: "#fff",
              overflow: "hidden",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {ScaleWidget && ScaleWidget(temperatureWidget)}
          </Box>

          {/* <Box sx={{ mt: 2 }}>
            {renderStatusField({
              label: "Current Temperature",
              value: OnData?.temperature,
              unit: "°C",
            })}
          </Box> */}
        </Paper>
      </Box>
    </Box>
  );
};

export default BucStatus;
