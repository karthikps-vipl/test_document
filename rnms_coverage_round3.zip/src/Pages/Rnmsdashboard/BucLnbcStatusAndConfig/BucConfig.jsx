import React, { useEffect, useState, useCallback } from "react";
import { useSelector } from "react-redux";
import {
  Box,
  Typography,
  Grid,
  TextField,
  CircularProgress,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { Update } from "@mui/icons-material";

import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MForm from "@/components/Reusable/Form/MForm";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  CONFIG_BUC_SERIAL,
  CONFIG_BUC_SERIAL_AT_CNMS,
  GET_BUC_SERIAL_CONFIG_STATUS,
  GET_BUC_SERIAL_CONFIG_STATUS_AT_CNMS,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";

const BucConfig = ({ resourceId, node, pollInterval, setLoading }) => {
  const theme = useTheme();
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const siteId = node?.siteId;

  const isDark = theme.palette.mode === "dark";

  const [bucConfigData, setBucConfigData] = useState({
    mute: "",
    centralFrequecy: "",
    atteneuation: "",
    gain: "",
    unitName: "",
  });

  const [redundancyConfigData, setRedundancyConfigData] = useState({
    redundancy: "",
    mode: "",
    setOnline: "",
  });

  const [bucErrors, setBucErrors] = useState({
    centralFrequecy: "",
    atteneuation: "",
    gain: "",
  });

  const [lastReceived, setLastReceived] = useState("--");

  const [bucSaving, setBucSaving] = useState(false);
  const [redundancySaving, setRedundancySaving] = useState(false);

  // --------------------------------------------------
  // DROPDOWN OPTIONS
  // --------------------------------------------------

  const muteOptions = [
    { label: "Mute Off", value: "0" },
    { label: "Mute On", value: "1" },
  ];

  const redundancyOptions = [
    { label: "Disabled", value: "0" },
    { label: "Enabled", value: "1" },
  ];

  const modeOptions = [
    { label: "Cold-Standby", value: "0" },
    { label: "Hot-Standby", value: "1" },
  ];

  const setOnlineOptions = [
    { label: "Active", value: "1" },
    { label: "Standby", value: "2" },
  ];

  // --------------------------------------------------
  // VALIDATION
  // --------------------------------------------------

  const validateField = (field, value) => {
    let min;
    let max;
    let label;

    switch (field) {
      //   case "centralFrequecy":
      //     min = 12.75;
      //     max = 14.5;
      //     label = "Center Frequency";
      //     break;

      case "atteneuation":
        min = 0;
        max = 20;
        label = "Attenuation";
        break;

      //   case "gain":
      //     min = 55;
      //     max = 75;
      //     label = "Gain";
      //     break;

      default:
        return "";
    }

    if (
      value === "" ||
      value === null ||
      value === undefined ||
      !Number.isFinite(Number(value)) ||
      Number(value) < min ||
      Number(value) > max
    ) {
      return `Enter ${label} between ${min} and ${max}`;
    }

    return "";
  };

  const validateAllFields = useCallback(() => {
    const errors = {
      centralFrequecy: validateField(
        "centralFrequecy",
        bucConfigData.centralFrequecy
      ),
      atteneuation: validateField("atteneuation", bucConfigData.atteneuation),
      gain: validateField("gain", bucConfigData.gain),
    };

    setBucErrors(errors);

    return Object.values(errors).every((error) => error === "");
  }, [bucConfigData]);

  const handleBucInputChange = (field, value) => {
    setBucConfigData((prev) => ({
      ...prev,
      [field]: value,
    }));

    setBucErrors((prev) => ({
      ...prev,
      [field]: validateField(field, value),
    }));
  };

  // --------------------------------------------------
  // FETCH CONFIGURATION
  // --------------------------------------------------

  const fetchConfigData = async () => {
    if (!resourceId) return;

    setLoading?.(true);

    try {
      let response;

      if (isCnms) {
        response = await ConfigurationAxios(
          `${GET_BUC_SERIAL_CONFIG_STATUS_AT_CNMS}/${resourceId}`,
          "get",
          { siteId: siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${GET_BUC_SERIAL_CONFIG_STATUS}/${resourceId}`,
          "get"
          // Note: Removed empty object {} to keep it clean, or add params if needed
        );
      }

      if (response?.data?.status === 1) {
        const initialData = response.data.data || {};

        setBucConfigData({
          mute: initialData?.mute != null ? String(initialData.mute) : "",

          centralFrequecy:
            initialData?.centralFrequecy != null
              ? String(initialData.centralFrequecy)
              : "",

          atteneuation:
            initialData?.atteneuation != null
              ? String(initialData.atteneuation)
              : "",

          gain: initialData?.gain != null ? String(initialData.gain) : "",

          unitName: initialData?.unitName || "",
        });

        setRedundancyConfigData({
          redundancy:
            initialData?.redundancy != null
              ? String(initialData.redundancy)
              : "",

          mode: initialData?.mode != null ? String(initialData.mode) : "",

          setOnline:
            initialData?.setOnline != null ? String(initialData.setOnline) : "",
        });

        setLastReceived(initialData?.readingTime || "--");

        setBucErrors({
          centralFrequecy: "",
          atteneuation: "",
          gain: "",
        });
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to fetch BUC configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("BUC Config Fetch Error:", error);
      Toast("Error", "Failed to fetch BUC configuration.", "error");
    } finally {
      setLoading?.(false);
    }
  };

  useEffect(() => {
    fetchConfigData();
  }, [resourceId, siteId]);

  // --------------------------------------------------
  // SAVE BUC CONFIGURATION
  // --------------------------------------------------

  const handleSaveBucConfig = async () => {
    if (!validateAllFields()) {
      Toast("Error", "Please correct the BUC configuration fields.", "error");
      return;
    }

    try {
      setBucSaving(true);
      setLoading?.(true);

      let response;

      const payload = {
        configType: 1,
        mute: Number(bucConfigData.mute),
        // centralFrequecy: Number(bucConfigData.centralFrequecy),
        atteneuation: Number(bucConfigData.atteneuation),
        // gain: Number(bucConfigData.gain),
        unitName: bucConfigData.unitName,
      };

      if (isCnms) {
        response = await ConfigurationAxios(
          `${CONFIG_BUC_SERIAL_AT_CNMS}/${resourceId}`,
          "post", // Assuming config operations are POST; adjust if GET
          { ...payload, siteId: siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${CONFIG_BUC_SERIAL}/${resourceId}`,
          "post", // Assuming config operations are POST; adjust if GET
          payload
        );
      }

      if (response?.data?.status === 1) {
        Toast("Success", "BUC Configuration Saved Successfully", "success");
        fetchConfigData();
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to save BUC configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("BUC Config Save Error:", error);
      Toast("Error", "Failed to save BUC configuration.", "error");
    } finally {
      setBucSaving(false);
      setLoading?.(false);
    }
  };

  // --------------------------------------------------
  // REDUNDANCY INPUT CHANGE
  // --------------------------------------------------

  const handleRedundancyChange = (field, value) => {
    setRedundancyConfigData((prev) => ({
      ...prev,
      [field]: value !== "" ? String(value) : "",
    }));
  };

  // --------------------------------------------------
  // SAVE REDUNDANCY CONFIGURATION
  // --------------------------------------------------

  const handleSaveRedundancyConfig = async () => {
    if (
      redundancyConfigData.redundancy === "" ||
      redundancyConfigData.mode === "" ||
      redundancyConfigData.setOnline === ""
    ) {
      Toast("Error", "Please select all Redundancy settings.", "error");
      return;
    }

    try {
      setRedundancySaving(true);
      setLoading?.(true);

      let response;

      const payload = {
        configType: 2,
        redundancy: Number(redundancyConfigData.redundancy),
        mode: Number(redundancyConfigData.mode),
        setOnline: Number(redundancyConfigData.setOnline),
      };

      if (isCnms) {
        response = await ConfigurationAxios(
          `${CONFIG_BUC_SERIAL_AT_CNMS}/${resourceId}`,
          "post", // Assuming config operations are POST; adjust if GET
          { ...payload, siteId: siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${CONFIG_BUC_SERIAL}/${resourceId}`,
          "post", // Assuming config operations are POST; adjust if GET
          payload
        );
      }
      if (response?.data?.status === 1) {
        Toast(
          "Success",
          "Redundancy Configuration Saved Successfully",
          "success"
        );
        fetchConfigData();
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to save Redundancy configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("Redundancy Save Error:", error);
      Toast("Error", "Failed to save Redundancy configuration.", "error");
    } finally {
      setRedundancySaving(false);
      setLoading?.(false);
    }
  };

  // --------------------------------------------------
  // REUSABLE NUMERIC INPUT
  // --------------------------------------------------

  const renderNumericInput = (label, field, unit, min, max) => (
    <Box sx={{ mb: 1 }}>
      <TextField
        fullWidth
        size="small"
        label={label}
        type="number"
        value={bucConfigData[field]}
        onChange={(e) => handleBucInputChange(field, e.target.value)}
        error={!!bucErrors[field]}
        helperText={
          bucErrors[field] || `Allowed range: ${min} - ${max} ${unit}`
        }
        inputProps={{
          min,
          max,
          step: field === "centralFrequecy" ? 0.01 : 0.1,
        }}
        sx={{
          "& .MuiInputBase-root": {
            fontFamily: "Montserrat",
            backgroundColor: isDark ? "#252525" : "white",
            // Optional: Add a border radius if you want rounded corners
            borderRadius: 2,
            // Optional: Ensure the border color matches the theme for better contrast
            borderColor: isDark ? "#444" : "#ccc",
          },
          "& .MuiInputLabel-root": {
            fontFamily: "Montserrat",
          },
        }}
      />
    </Box>
  );

  // --------------------------------------------------
  // RENDER
  // --------------------------------------------------

  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: "#ffffff",
        p: 2,
      }}
    >
      {/* LAST RECEIVED DATE */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          gap: 1,
          mb: 2,
        }}
      >
        <Typography
          sx={{
            fontSize: "13px",
            color: "#666",
            fontWeight: 500,
            fontFamily: "Montserrat",
          }}
        >
          Last Received Data:
        </Typography>

        <Typography
          sx={{
            fontSize: "13px",
            fontWeight: 600,
            color: "primary.main",
            fontFamily: "Montserrat",
          }}
        >
          {lastReceived}
        </Typography>
      </Box>

      {/* CONFIGURATION SECTIONS */}
      <Grid spacing={2} alignItems="stretch" className="grid grid-cols-2 gap-2">
        {/* ======================================
            BUC CONFIGURATION
        ====================================== */}

        <Grid item xs={12} md={6}>
          <MForm title="BUC Configuration" paddingX={2}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
              }}
            >
              {/* MUTE */}
              <Box sx={{ mb: 2 }}>
                <Typography
                  sx={{
                    fontSize: "13px",
                    fontWeight: 500,
                    color: "text.secondary",
                    mb: 0,
                    fontFamily: "Montserrat",
                  }}
                >
                  Mute
                </Typography>

                <MAlarmSelect
                  label=""
                  value={bucConfigData.mute}
                  onChange={(val) => handleBucInputChange("mute", val)}
                  options={muteOptions}
                  disabled={bucSaving}
                  multiple={false}
                  isDark={isDark}
                />
              </Box>

              {/* CENTRAL FREQUENCY */}
              {/* {renderNumericInput(
                "Center Frequency (GHz)",
                "centralFrequecy",
                "GHz",
                12.75,
                14.5
              )} */}

              {/* ATTENUATION */}
              {renderNumericInput(
                "Attenuation (dB)",
                "atteneuation",
                "dB",
                0,
                20
              )}

              {/* GAIN */}
              {/* {renderNumericInput("Gain (dB)", "gain", "dB", 55, 75)} */}

              {/* SAVE BUTTON */}
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  mt: 1,
                }}
              >
                <MButtonPrimary
                  variant="contained"
                  onClick={handleSaveBucConfig}
                  disabled={
                    bucSaving ||
                    Object.values(bucErrors).some((error) => error !== "") ||
                    !bucConfigData.mute
                  }
                  startIcon={
                    bucSaving ? (
                      <CircularProgress size={18} color="inherit" />
                    ) : (
                      <Update />
                    )
                  }
                >
                  {bucSaving ? "Saving..." : "Save"}
                </MButtonPrimary>
              </Box>
            </Box>
          </MForm>
        </Grid>

        {/* ======================================
            REDUNDANCY
        ====================================== */}

        <Grid item xs={12} md={6}>
          <MForm title="Redundancy" paddingX={2}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 2,
              }}
            >
              {/* REDUNDANCY ENABLE / DISABLE */}
              <Box>
                <Typography
                  sx={{
                    fontSize: "13px",
                    fontWeight: 500,
                    color: "text.secondary",
                    mb: 0,
                    fontFamily: "Montserrat",
                  }}
                >
                  Redundancy
                </Typography>

                <MAlarmSelect
                  label=""
                  value={redundancyConfigData.redundancy}
                  onChange={(val) => handleRedundancyChange("redundancy", val)}
                  options={redundancyOptions}
                  disabled={redundancySaving}
                  multiple={false}
                  isDark={isDark}
                />
              </Box>

              {/* REDUNDANCY MODE */}
              <Box>
                <Typography
                  sx={{
                    fontSize: "13px",
                    fontWeight: 500,
                    color: "text.secondary",
                    mb: 0,
                    fontFamily: "Montserrat",
                  }}
                >
                  Redundancy Mode
                </Typography>

                <MAlarmSelect
                  label=""
                  value={redundancyConfigData.mode}
                  onChange={(val) => handleRedundancyChange("mode", val)}
                  options={modeOptions}
                  disabled={redundancySaving}
                  multiple={false}
                  isDark={isDark}
                />
              </Box>

              {/* SET ONLINE */}
              <Box>
                <Typography
                  sx={{
                    fontSize: "13px",
                    fontWeight: 500,
                    color: "text.secondary",
                    mb: 0,
                    fontFamily: "Montserrat",
                  }}
                >
                  Set Online
                </Typography>

                <MAlarmSelect
                  label=""
                  value={redundancyConfigData.setOnline}
                  onChange={(val) => handleRedundancyChange("setOnline", val)}
                  options={setOnlineOptions}
                  disabled={redundancySaving}
                  multiple={false}
                  isDark={isDark}
                />
              </Box>

              {/* SAVE BUTTON */}
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  mt: 1,
                }}
              >
                <MButtonPrimary
                  variant="contained"
                  onClick={handleSaveRedundancyConfig}
                  disabled={
                    redundancySaving ||
                    redundancyConfigData.redundancy === "" ||
                    redundancyConfigData.mode === "" ||
                    redundancyConfigData.setOnline === ""
                  }
                  startIcon={
                    redundancySaving ? (
                      <CircularProgress size={18} color="inherit" />
                    ) : (
                      <Update />
                    )
                  }
                >
                  {redundancySaving ? "Saving..." : "Save"}
                </MButtonPrimary>
              </Box>
            </Box>
          </MForm>
        </Grid>
      </Grid>
    </Box>
  );
};

export default BucConfig;
