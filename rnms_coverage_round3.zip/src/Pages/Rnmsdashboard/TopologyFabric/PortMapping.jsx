// import React, { useMemo } from "react";
// import { Box, Typography } from "@mui/material";
// import { useSelector } from "react-redux";
// import MTable from "@/components/Reusable/Table/MTable";


// const PortMapping = () => {
//   const resources = useSelector(
//     (state) => state.inventory?.resources || []
//   );

//   console.log("portmappingresources",resources);
  

//   /*
//    * Step 1:
//    * Find all resourceIds that are referenced by connectedTo.
//    *
//    * connectedTo === null is ignored.
//    */
//   const connectedResourceIds = useMemo(() => {
//     if (!Array.isArray(resources)) {
//       return [];
//     }

//     return [
//       ...new Set(
//         resources
//           .map((resource) => resource?.connectedTo)
//           .filter(
//             (connectedTo) =>
//               connectedTo !== null &&
//               connectedTo !== undefined &&
//               connectedTo !== ""
//           )
//       ),
//     ];
//   }, [resources]);

//   /*
//    * Step 2:
//    * Find the actual resource objects using the resourceIds
//    * collected from connectedTo.
//    *
//    * Only resources with isDiscovered === true are displayed.
//    */
    
//   const discoveredConnectedResources = useMemo(() => {
//     if (!Array.isArray(resources) || connectedResourceIds.length === 0) {
//       return [];
//     }

//     return resources.filter(
//       (resource) =>
//         connectedResourceIds.includes(resource?.resourceId) &&
//         resource?.isDiscovered === true
//     );
//   }, [resources, connectedResourceIds]);

//   console.log("discoveredConnectedResources",discoveredConnectedResources.length);
  



//   /*
//    * MTable columns.
//    */
//   const columns = [
//     {
//       uid: "portNo",
//       name: "Port No",
//       width: "100px",
//     },
//     {
//       uid: "device",
//       name: "Device Name",
//       width: "180px",
//     },
//     {
//       uid: "opstatus",
//       name: "Op Status",
//       width: "120px",
//     },
//     {
//       uid: "adminstatus",
//       name: "Admin Status",
//       width: "120px",
//     },
//   ];

//   /*
//    * Step 3:
//    * Prepare table data for every discovered connected resource.
//    *
//    * Each discovered resource gets its own table.
//    */
//   const portMappingTables = useMemo(() => {
//     return discoveredConnectedResources.map((discoveredResource) => {
//       /*
//        * IMPORTANT:
//        *
//        * Only the discovered resource's lstPortInfoDtl
//        * is used to determine the ports for this table.
//        */
//       const discoveredPortInfo = Array.isArray(
//         discoveredResource?.lstPortInfoDtl
//       )
//         ? discoveredResource.lstPortInfoDtl
//         : [];
  
//       /*
//        * Sort the discovered device's ports by portNumber.
//        */
//       const sortedPortInfo = [...discoveredPortInfo].sort((a, b) => {
//         return Number(a?.portNumber ?? 0) - Number(b?.portNumber ?? 0);
//       });
  
//       /*
//        * Build table rows.
//        */
//       const tableData = sortedPortInfo.map((port) => {
//         const portNumber = Number(port?.portNumber);
  
//         /*
//          * IMPORTANT:
//          *
//          * For the DEVICE column:
//          *
//          * Search the TOP-LEVEL resources array and compare
//          * the resource's TOP-LEVEL portNumber.
//          *
//          * We do NOT inspect the matching resource's lstPortInfoDtl.
//          */
//         const matchingResource = resources.find(
//           (resource) =>
//             Number(resource?.portNumber) === portNumber
//         );
  
//         return {
//           /*
//            * From discoveredResource.lstPortInfoDtl
//            */
//           portNo: port?.portNumber ?? "-",
  
//           /*
//            * From the TOP-LEVEL matching resource
//            */
//           device: matchingResource?.resourceName ?? "-",
  
//           /*
//            * From discoveredResource.lstPortInfoDtl
//            */
//           opstatus:
//             port?.opstatus === 1
//               ? "UP"
//               : port?.opstatus === 2  
//               ? "DOWN"
//               : "Unknown",
  
//           /*
//            * From discoveredResource.lstPortInfoDtl
//            */
//           adminstatus:
//             port?.adminstatus === 1
//               ? "UP"
//               : port?.adminstatus === 2
//               ? "DOWN"
//               : "Unknown",
//         };
//       });
  
//       return {
//         resourceId: discoveredResource?.resourceId,
//         resourceName:
//           discoveredResource?.resourceName ||
//           discoveredResource?.resourceId,
//         tableData,
//       };
//     });
//   }, [resources, discoveredConnectedResources]);

//   console.log("Port Mapping Resources:", resources);
//   console.log(
//     "Connected Resource IDs:",
//     connectedResourceIds
//   );
//   console.log(
//     "Discovered Connected Resources:",
//     discoveredConnectedResources
//   );
//   console.log(
//     "Port Mapping Tables:",
//     portMappingTables
//   );

//   return (
//     <Box
//       sx={{
//         width: "100%",
//         height: "100%",
//         display: "flex",
//         flexDirection: "column",
//         backgroundColor: "background.paper",
//         borderLeft: "1px solid",
//         borderColor: "divider",
//         overflow: "hidden",
//       }}
//     >
//       {/* Header */}
//       <Box
//         sx={{
//           px: 1.5,
//           py: 1,
//           borderBottom: "1px solid",
//           borderColor: "divider",
//           flexShrink: 0,
//         }}
//       >
//         <Typography
//           sx={{
//             fontSize: "14px",
//             fontWeight: 600,
//           }}
//         >
//           Port Mapping
//         </Typography>
//       </Box>

//       {/* Tables */}
//       <Box
//         sx={{
//           flex: 1,
//           p: 1.5,
//           overflowY: "auto",
//           overflowX: "hidden",
//         }}
//       >
//         {portMappingTables.length === 0 ? (
//           <Box
//             sx={{
//               display: "flex",
//               justifyContent: "center",
//               alignItems: "center",
//               minHeight: 120,
//               color: "text.secondary",
//             }}
//           >
//             <Typography sx={{ fontSize: "13px" }}>
//               No discovered port mappings available
//             </Typography>
//           </Box>
//         ) : (
//           portMappingTables.map((table) => (
//             <Box
//               key={table.resourceId}
//               sx={{
//                 mb: 2,
//                 width: "100%",
//               }}
//             >
//               <Typography
//                 sx={{
//                   fontSize: "14px",
//                   fontWeight: 600,
//                   mb: 1,
//                   color: "text.primary",
//                 }}
//               >
//                 {table.resourceName}
//               </Typography>

//               <MTable
//                 tableTitle=""
//                 columns={columns}
//                 tableData={table.tableData}
//                 showSearch={true}
//                 showPagination={true}
//                 showSelect={false}
//                 hideAdd={true}
//               />
//             </Box>
//           ))
//         )}
//       </Box>
//     </Box>
//   );
// };

// export default PortMapping;



import React, { useMemo } from "react";
import { Box, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import MTable from "@/components/Reusable/Table/MTable";


const PortMapping = () => {
  const resources = useSelector(
    (state) => state.inventory?.resources || []
  );
  
  console.log("portmappingresources",resources);
  
  /*
   * Step 1:
   * Find all resourceIds that are referenced by connectedTo.
   *
   * connectedTo === null is ignored.
   */
  const connectedResourceIds = useMemo(() => {
    if (!Array.isArray(resources)) {
      return [];
    }

    return [
      ...new Set(
        resources
          .map((resource) => resource?.connectedTo)
          .filter(
            (connectedTo) =>
              connectedTo !== null &&
              connectedTo !== undefined &&
              connectedTo !== ""
          )
      ),
    ];
  }, [resources]);

  /*
   * Step 2:
   * Find the actual resource objects using the resourceIds
   * collected from connectedTo.
   *
   * Only resources with isDiscovered === true are displayed.
   */
    
  const discoveredConnectedResources = useMemo(() => {
    if (!Array.isArray(resources) || connectedResourceIds.length === 0) {
      return [];
    }

    return resources.filter(
      (resource) =>
        connectedResourceIds.includes(resource?.resourceId) &&
        resource?.isDiscovered === true
    );
  }, [resources, connectedResourceIds]);

  console.log("discoveredConnectedResources",discoveredConnectedResources.length);
  



  /*
   * MTable columns.
   */
  const columns = [
    {
      uid: "portNo",
      name: "Port No",
      width: "100px",
    },
    {
      uid: "device",
      name: "Device Name",
      width: "180px",
    },
    {
      uid: "opstatus",
      name: "Op Status",
      width: "120px",
    },
    {
      uid: "adminstatus",
      name: "Admin Status",
      width: "120px",
    },
  ];

  /*
   * Step 3:
   * Prepare table data for every discovered connected resource.
   *
   * Each discovered resource gets its own table.
   */
  const portMappingTables = useMemo(() => {
    return discoveredConnectedResources.map((discoveredResource) => {
      /*
       * IMPORTANT:
       *
       * Only the discovered resource's lstPortInfoDtl
       * is used to determine the ports for this table.
       */
      const discoveredPortInfo = Array.isArray(
        discoveredResource?.lstPortInfoDtl
      )
        ? discoveredResource.lstPortInfoDtl
        : [];


        console.log("discoveredPortInfo",discoveredPortInfo);
        
  
      /*
       * Sort the discovered device's ports by portNumber.
       */
      const sortedPortInfo = [...discoveredPortInfo].sort((a, b) => {
        return Number(a?.portNumber ?? 0) - Number(b?.portNumber ?? 0);
      });
  
      /*
       * Build table rows.
       */
      const tableData = sortedPortInfo.map((port) => {
  
        /*
         * IMPORTANT:
         *
         * For the DEVICE column:
         *
         * Search the TOP-LEVEL resources array and compare
         * the resource's TOP-LEVEL portNumber.
         *
         * We do NOT inspect the matching resource's lstPortInfoDtl.
         */
        const matchingResource = resources.find(
          (resource) => resource?.resourceId === port?.connectedResource
        );

        console.log("resourcesfff",resources);
        

        console.log("matchingResource",matchingResource);
        
        
        return {
          portNo: port?.portNumber ?? "-",
          device: matchingResource?.resourceName ?? "-",
          opstatus:
            port?.opstatus === 1
              ? "UP"
              : port?.opstatus === 2
              ? "DOWN"
              : "Unknown",
          adminstatus:
            port?.adminstatus === 1
              ? "UP"
              : port?.adminstatus === 2
              ? "DOWN"
              : "Unknown",
        };

      });
  
      return {
        resourceId: discoveredResource?.resourceId,
        resourceName:
          discoveredResource?.resourceName ||
          discoveredResource?.resourceId,
        tableData,
      };
    });
  }, [resources, discoveredConnectedResources]);

  console.log("Port Mapping Resources:", resources);
  console.log(
    "Connected Resource IDs:",
    connectedResourceIds
  );
  console.log(
    "Discovered Connected Resources:",
    discoveredConnectedResources
  );
  console.log(
    "Port Mapping Tables:",
    portMappingTables
  );

  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        backgroundColor: "background.paper",
        borderLeft: "1px solid",
        borderColor: "divider",
        overflow: "hidden",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 1.5,
          py: 1,
          borderBottom: "1px solid",
          borderColor: "divider",
          flexShrink: 0,
        }}
      >
        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: 600,
          }}
        >
          Port Mapping
        </Typography>
      </Box>

      {/* Tables */}
      <Box
        sx={{
          flex: 1,
          p: 1.5,
          overflowY: "auto",
          overflowX: "hidden",
        }}
      >
        {portMappingTables.length === 0 ? (
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              minHeight: 120,
              color: "text.secondary",
            }}
          >
            <Typography sx={{ fontSize: "13px" }}>
              No discovered port mappings available
            </Typography>
          </Box>
        ) : (
          portMappingTables.map((table) => (
            <Box
              key={table.resourceId}
              sx={{
                mb: 2,
                width: "100%",
              }}
            >
              <Typography
                sx={{
                  fontSize: "14px",
                  fontWeight: 600,
                  mb: 1,
                  color: "text.primary",
                }}
              >
                {table.resourceName}
              </Typography>

              <MTable
                tableTitle=""
                columns={columns}
                tableData={table.tableData}
                showSearch={true}
                showPagination={true}
                showSelect={false}
                hideAdd={true}
              />
            </Box>
          ))
        )}
      </Box>
    </Box>
  );
};

export default PortMapping;


