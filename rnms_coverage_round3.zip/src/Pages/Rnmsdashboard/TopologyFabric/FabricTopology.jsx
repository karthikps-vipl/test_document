import { memo, useCallback, useEffect, useRef, useState } from "react";
import {
  Canvas,
  Rect,
  Circle,
  Line,
  Triangle,
  Group,
  Image,
  FabricObject,
  loadSVGFromURL,
} from "fabric";
import TopologyEditActions from "../Topology/TopologyEditActions";
import { useDispatch, useSelector } from "react-redux";
import {
  getDeviceReachabilityColor,
  getDeviceReachabilityColorCnms,
  getDeviceStatusIndicator,
  getDeviceStatusIndicatorCnms,
} from "@/lib/utils";
import NodeTooltip from "../Topology/Tooltip/NodeTooltip";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  redoTopologyState,
  saveTopologyState,
  selectCanRedo,
  selectCanUndo,
  undoTopologyState,
} from "@/store/features/Topology/topologyNodesslice";
import UnifiedContextMenu from "@/components/Contextmenu/ContextMenu";
import { mapOpStatus } from "../Topology/topologyConstants";
import { getEdgeColor } from "../Topology/utils";
import { Backdrop, CircularProgress } from "@mui/material";
import PortMapping from "./PortMapping";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";

// FabricObject.customProperties = ["id", "shapeType", "metadata"];
FabricObject.customProperties = [
  "id",
  "shapeType",
  "metadata",
  "stateGraphics",
  "portState",
  "currentState",
];

// const makeId = (prefix) =>
//   `${prefix}-${Math.random().toString(36).slice(2, 10)}`;

const makeId = (prefix) => `${prefix}-${crypto.randomUUID()}`;

const loadFabricImage = async (src) => {
  return Image.fromURL(src, { crossOrigin: "anonymous" });
};

const SUPERADMIN = window.isSuperAdmin;

const portSvgCache = {
  up: null,
  down: null,
  operational_down: null,
  notConfigured: null,
};

const PORT_STATE_ASSET = {
  up: "up",
  operational_down: "operational_down",
  down: "down",
  notConfigured: "notConfigured",
};

// Pre-fetch asset paths asynchronously
const fetchAndCacheSvg = async (type, path) => {
  try {
    const result = await loadSVGFromURL(path);
    // Fabric loadSVGFromURL returns an object containing an 'objects' array
    if (result && Array.isArray(result.objects) && result.objects.length > 0) {
      return result.objects;
    }
    console.warn(
      `Asset parsed but contained no valid vector elements: ${path}`
    );
    return [];
  } catch (err) {
    console.error(
      `Failed loading industrial topology asset profile: ${path}`,
      err
    );
    return [];
  }
};

const preloadPortSvgs = async () => {
  if (
    portSvgCache.up &&
    portSvgCache.operational_down &&
    portSvgCache.down &&
    portSvgCache.notConfigured
  ) {
    return portSvgCache;
  }

  const [up, down, operationalDown, notConfigured] = await Promise.all([
    fetchAndCacheSvg("up", "/assets/topology/Up.svg"),
    fetchAndCacheSvg(
      "operational_down",
      "/assets/topology/Operational-Down.svg"
    ),
    fetchAndCacheSvg("down", "/assets/topology/Down.svg"),
    fetchAndCacheSvg("notConfigured", "/assets/topology/Not-Configured.svg"),
  ]);

  portSvgCache.up = up;
  portSvgCache.operational_down = operationalDown;
  portSvgCache.down = down;
  portSvgCache.notConfigured = notConfigured;

  return portSvgCache;
};

const setPortVisualState = (portObject, state) => {
  if (!portObject) return false;

  const stateContainer = portObject.getObjects()?.[0];

  if (!stateContainer) {
    console.warn("Port state container missing", portObject.metadata);
    return false;
  }

  const stateGroups = stateContainer.getObjects();

  let found = false;

  stateGroups.forEach((svgGroup) => {
    const svgState = svgGroup.metadata?.portState;

    const visible = svgState === state;

    svgGroup.set({
      visible,
      dirty: true,
    });

    if (visible) {
      found = true;
    }
  });

  stateContainer.set({
    dirty: true,
  });

  portObject.set({
    dirty: true,
  });

  if (portObject.group) {
    portObject.group.set({
      dirty: true,
    });
  }

  return found;
};

const restorePortVisualState = (portObject) => {
  if (!portObject) return false;

  const stateContainer = portObject.getObjects()?.[0];

  if (!stateContainer) {
    console.warn(
      "Cannot restore port state: state container missing",
      portObject.metadata
    );
    return false;
  }

  const state = migrateLegacyPortState(
    portObject.metadata?.portState ||
      portObject.metadata?.currentState ||
      "notConfigured"
  );

  let found = false;

  stateContainer.getObjects().forEach((svgGroup) => {
    const svgState = migrateLegacyPortState(svgGroup.metadata?.portState);

    const visible = svgState === state;

    svgGroup.set({
      visible,
      dirty: true,
    });

    if (visible) {
      found = true;
    }
  });

  // Safety fallback
  if (!found) {
    stateContainer.getObjects().forEach((svgGroup) => {
      const svgState = migrateLegacyPortState(svgGroup.metadata?.portState);

      svgGroup.set({
        visible: svgState === "notConfigured",
        dirty: true,
      });
    });

    portObject.metadata = {
      ...portObject.metadata,
      portState: "notConfigured",
      currentState: "notConfigured",
    };

    found = true;
  }

  stateContainer.set({
    dirty: true,
  });

  portObject.set({
    dirty: true,
  });

  if (portObject.group) {
    portObject.group.set({
      dirty: true,
    });
  }

  return found;
};

const applyLinkStatusColors = (canvas, linkStatusData = []) => {
  if (!canvas || !Array.isArray(linkStatusData)) {
    return;
  }

  let updatedCount = 0;

  canvas.getObjects().forEach((obj) => {
    // Only connector groups
    if (obj.metadata?.kind !== "connector") {
      return;
    }

    const linkId = obj.metadata?.linkId;

    if (linkId == null) {
      console.warn("Connector has no linkId:", obj);
      return;
    }

    const latestLink = linkStatusData.find(
      (link) => String(link.linkId) === String(linkId)
    );

    if (!latestLink) {
      console.warn(`No live link status found for connector linkId: ${linkId}`);
      return;
    }

    const color = SUPERADMIN ? "#D3D3D3" : getEdgeColor(latestLink.linkStatus);

    // Keep metadata synchronized with the latest JSON/live status
    obj.metadata = {
      ...obj.metadata,
      linkId: latestLink.linkId,
      linkName: latestLink.linkName,
      linkStatus: latestLink.linkStatus,
    };

    // Update actual Fabric children
    const children = obj.getObjects?.() || [];

    children.forEach((child) => {
      if (child.type === "line") {
        child.set({
          stroke: color,
          dirty: true,
        });
      }

      if (child.type === "triangle") {
        child.set({
          fill: color,
          dirty: true,
        });
      }

      child.dirty = true;
    });

    obj.set({
      dirty: true,
    });

    obj.setCoords();

    updatedCount++;
  });

  canvas.requestRenderAll();
};

const migrateLegacyPortState = (state) => {
  switch (state) {
    case "up":
      return "up";

    case "down":
      return "operational_down";

    case "operational_down":
      return "down";

    case "notConfigured":
      return "notConfigured";

    // Only migrate the genuinely old state name.
    case "adminDown":
      return "down";

    default:
      return state;
  }
};

const migratePortStateMetadata = (portObject) => {
  if (!portObject) return;

  const stateContainer = portObject.getObjects()?.[0];

  if (!stateContainer) {
    console.warn(
      "Cannot migrate port: state container missing",
      portObject.metadata
    );
    return;
  }

  // --------------------------------------------------
  // 1. Migrate SVG state metadata
  // --------------------------------------------------

  stateContainer.getObjects().forEach((svgGroup) => {
    const oldState = svgGroup.metadata?.portState;
    const newState = migrateLegacyPortState(oldState);

    if (oldState !== newState) {
      console.log("Migrating SVG port state:", oldState, "→", newState);
    }

    svgGroup.metadata = {
      ...svgGroup.metadata,
      portState: newState,
    };
  });

  // --------------------------------------------------
  // 2. Migrate port metadata
  // --------------------------------------------------

  const oldPortState = portObject.metadata?.portState;

  const oldCurrentState = portObject.metadata?.currentState;

  const newPortState = migrateLegacyPortState(oldPortState);

  const newCurrentState = migrateLegacyPortState(oldCurrentState);

  const finalState = newPortState || newCurrentState || "notConfigured";

  portObject.metadata = {
    ...portObject.metadata,

    portState: finalState,
    currentState: finalState,
  };

  // --------------------------------------------------
  // 3. Restore the actual SVG visibility
  // --------------------------------------------------

  restorePortVisualState(portObject);
};

const setCanvasBackground = (canvas, image) => {
  image.set({
    left: 0,
    top: 0,
    scaleX: 1,
    scaleY: 1,
    originX: "left",
    originY: "top",
    selectable: false,
    evented: false,
    objectCaching: false,
    noScaleCache: true,
    dirty: true,
  });

  image.filters = [];
  canvas.backgroundImage = image;

  const scaleX = canvas.getWidth() / image.width;
  const scaleY = canvas.getHeight() / image.height;

  canvas.setViewportTransform([scaleX, 0, 0, scaleY, 0, 0]);
  canvas.requestRenderAll();
};

const buildTopologyCache = (canvas, cacheRef) => {
  const cache = cacheRef.current;
  cache.devices.clear();
  cache.indicators.clear();
  cache.ports.clear();
  cache.links.clear();

  canvas.getObjects().forEach((obj) => {
    // 1. Devices
    if (obj.shapeType === "deviceCompositeGroup") {
      const deviceId = obj.metadata?.deviceId;
      if (deviceId) {
        cache.devices.set(deviceId, obj);
      }

      // 2. Ports (Indexed explicitly by visualIndex metadata)
      let portVisualCounter = 1;
      obj.getObjects().forEach((child) => {
        if (
          child.shapeType === "hardwarePort" ||
          child.metadata?.kind === "port-node"
        ) {
          // Fall back to sequential counter if visualIndex is not explicitly set
          const visualIndex =
            child.metadata?.visualIndex || portVisualCounter++;

          // Primary sequential visual key based on visualIndex
          const visualKey = `${deviceId}_v${visualIndex}`;
          cache.ports.set(visualKey, child);

          // Secondary fallback reference using ifindex if present
          if (child.metadata?.ifindex != null) {
            cache.ports.set(`${deviceId}_if_${child.metadata.ifindex}`, child);
          }
        }
      });
    }

    // 3. Status Indicators
    if (obj.shapeType === "deviceStatus") {
      const deviceId = obj.metadata?.deviceId;
      if (deviceId) {
        cache.indicators.set(deviceId, obj);
      }
    }

    // 4. Links / Connectors
    if (obj.metadata?.kind === "connector") {
      const linkId = obj.metadata?.linkId;
      if (linkId) {
        cache.links.set(String(linkId), obj);
      }
    }
  });
};

const updatePortGraphicState = async (portObject, portData) => {
  if (!portObject) return;

  const opstatus = Number(portData.opstatus);
  const adminstatus = Number(portData.adminstatus);

  const nextState = mapOpStatus(opstatus, adminstatus);

  const stateContainer = portObject.getObjects()?.[0];

  console.table(
    stateContainer?.getObjects()?.map((svgGroup) => ({
      portState: svgGroup.metadata?.portState,
      visible: svgGroup.visible,
    }))
  );

  const rendered = setPortVisualState(portObject, nextState);

  if (!rendered) {
    console.error("STATE HAS NO VISUAL ASSET", {
      state: nextState,
      ifindex: portData.ifindex,
    });

    // Fail-safe
    setPortVisualState(portObject, "notConfigured");
  }

  const finalState = rendered ? nextState : "notConfigured";

  portObject.metadata = {
    ...portObject.metadata,
    currentState: finalState,
    portState: finalState,
    details: {
      ...portData,
      opstatus,
      adminstatus,
    },
  };

  portObject.setCoords();
};

const updateResourceTopology = async (resources, canvas, cacheRef, isCnms) => {
  if (SUPERADMIN) {
    return;
  }

  if (!canvas || !Array.isArray(resources)) {
    return;
  }
  const cache = cacheRef.current;
  let canvasChanged = false;

  // ============================================================
  // REDUX TEMPORARILY HAS NO RESOURCES
  //
  // Do NOT destroy/rebuild the topology.
  //
  // Only reset the existing 24+4 switch port graphics to
  // notConfigured. Their visualIndex remains untouched.
  // ============================================================

  if (resources.length === 0) {
    canvas.getObjects().forEach((obj) => {
      if (obj.shapeType !== "deviceCompositeGroup") {
        return;
      }

      if (!is24Plus4Switch(obj)) {
        return;
      }

      const hardwarePorts = obj
        .getObjects()
        .filter(
          (child) =>
            child.shapeType === "hardwarePort" ||
            child.metadata?.kind === "port-node"
        );

      hardwarePorts.forEach((portObject) => {
        portObject.metadata = {
          ...portObject.metadata,
          portState: "notConfigured",
          currentState: "notConfigured",
        };

        // IMPORTANT:
        // Do not touch visualIndex.
        restorePortVisualState(portObject);

        portObject.setCoords();
        portObject.dirty = true;
      });

      obj.dirty = true;
      canvasChanged = true;
    });

    if (canvasChanged) {
      canvas.requestRenderAll();
    }

    return;
  }

  for (const resource of resources) {
    const deviceId = resource.resourceId || resource.ResourceId || resource.id;

    const deviceObject = cache.devices.get(deviceId);
    if (!deviceObject) {
      continue;
    }

    const status = resource.status ?? resource.Status ?? resource.state ?? "";
    const ipAddress =
      resource.resourceIp ?? resource.resourceIP ?? resource.ResourceIp ?? "";

    deviceObject.metadata = {
      ...deviceObject.metadata,
      status,
      ipAddress,
      deviceData: resource,
    };

    deviceObject.dirty = true;

    /************************************************************
     * Update Device Rectangle - Reachability Status
     ************************************************************/
    const deviceRectangle = deviceObject
      .getObjects()
      .find((child) => child.shapeType === "deviceRectangle");

    if (deviceRectangle) {
      // const rectangleColor = isCnms ? getDeviceReachabilityColorCnms : getDeviceReachabilityColor(resource);
      const rectangleColor = isCnms
      ? getDeviceReachabilityColorCnms(resource)
      : getDeviceReachabilityColor(resource);
      deviceRectangle.set({
        stroke: rectangleColor,
        dirty: true,
      });

      deviceRectangle.metadata = {
        ...deviceRectangle.metadata,
        deviceData: resource,
        status,
        reachabilityColor: rectangleColor,
      };

      deviceRectangle.setCoords();

      canvasChanged = true;
    }

    /************************************************************
     * Update Status Indicator Circle - Alarm / Unmanaged /
     * Undiscovered
     ************************************************************/
    const indicator = cache.indicators.get(deviceId);

    if (indicator) {
      const indicatorStatus = isCnms
        ? getDeviceStatusIndicatorCnms(resource)
        : getDeviceStatusIndicator(resource);

      indicator.set({
        fill: indicatorStatus.color,
        visible: indicatorStatus.visible,
        dirty: true,
      });

      indicator.metadata = {
        ...indicator.metadata,
        deviceData: resource,
        status,
        indicatorStatus: indicatorStatus.status,
      };

      indicator.setCoords();
      canvasChanged = true;
    }

    /************************************************************
     * Update Ports via visualIndex Mapping
     ************************************************************/
    const ports =
      resource.lstPortInfoDtl ??
      resource.lstPortInfoDetails ??
      resource.lsportinfodetails ??
      resource.lsPortInfoDtl ??
      resource.ports ??
      [];

    // Map hardware ports inside the device by sorting or matching their visualIndex metadata
    const hardwarePorts = deviceObject
      .getObjects()
      .filter(
        (child) =>
          child.shapeType === "hardwarePort" ||
          child.metadata?.kind === "port-node"
      );

    // Sort hardware ports explicitly by their visualIndex to respect your layout configuration
    hardwarePorts.sort((a, b) => {
      const indexA = a.metadata?.visualIndex || 0;
      const indexB = b.metadata?.visualIndex || 0;
      return indexA - indexB;
    });

    console.log("jfjhardwarePorts", hardwarePorts);

    // ============================================================
    // PORT UPDATE
    // ============================================================

    // If Redux has NO port information,
    // reset ALL existing hardware ports to notConfigured.
    if (!Array.isArray(ports) || ports.length === 0) {
      hardwarePorts.forEach((portObject) => {
        portObject.metadata = {
          ...portObject.metadata,
          portState: "notConfigured",
          currentState: "notConfigured",
        };

        // Activate the existing notConfigured SVG.
        restorePortVisualState(portObject);

        portObject.setCoords();
        portObject.dirty = true;
      });

      canvasChanged = true;
    } else {
      // ============================================================
      // LIVE PORT DATA
      // ============================================================

      const is24Plus4 = is24Plus4Switch(deviceObject);

      if (is24Plus4) {
        // ==========================================================
        // 24 + 4 SWITCH
        //
        // IMPORTANT:
        // Redux array order is completely ignored.
        //
        // We determine the physical visualIndex from the port data.
        // ==========================================================

        const portsByVisualIndex = new Map();

        for (const port of ports) {
          const visualIndex = get24Plus4VisualIndex(port);

          if (!visualIndex) {
            console.warn(
              "Skipping 24+4 switch port because visualIndex could not be resolved:",
              {
                ifindex: port?.ifindex,
                portNumber: port?.portNumber,
                ifdesc: port?.ifdesc,
              }
            );

            continue;
          }

          portsByVisualIndex.set(Number(visualIndex), port);
        }

        // ----------------------------------------------------------
        // Update each EXISTING physical Fabric port.
        //
        // This is important after Redux goes:
        //
        // populated -> empty -> populated
        //
        // The Fabric object itself is never recreated/reordered.
        // Its saved visualIndex remains the source of truth.
        // ----------------------------------------------------------

        for (const portObject of hardwarePorts) {
          const visualIndex = Number(portObject.metadata?.visualIndex);

          if (!Number.isInteger(visualIndex)) {
            continue;
          }

          const port = portsByVisualIndex.get(visualIndex);

          // No telemetry for this physical port.
          // Keep the existing visual position and mark it
          // notConfigured.
          if (!port) {
            portObject.metadata = {
              ...portObject.metadata,
              portState: "notConfigured",
              currentState: "notConfigured",
            };

            restorePortVisualState(portObject);

            portObject.setCoords();
            portObject.dirty = true;

            continue;
          }

          const ifindex =
            port.ifindex ??
            port.Ifindex ??
            port.ifIndex ??
            port.portIndex ??
            visualIndex;

          const rawOpstatus =
            port.opstatus ??
            port.opStatus ??
            port.operstatus ??
            port.Operstatus ??
            port.status;

          const rawAdminstatus =
            port.adminstatus ??
            port.adminStatus ??
            port.Adminstatus ??
            port.adminState;

          const normalizedPortData = {
            ...port,
            ifindex,
            opstatus: Number(rawOpstatus),
            adminstatus: Number(rawAdminstatus),

            // IMPORTANT:
            // Preserve the physical visual position.
            visualIndex,
          };

          await updatePortGraphicState(portObject, normalizedPortData);
        }
      } else {
        // ==========================================================
        // EXISTING BEHAVIOR FOR ALL OTHER DEVICES
        // ==========================================================

        for (let i = 0; i < ports.length; i++) {
          const port = ports[i];

          const targetVisualIndex = i + 1;

          const portObject = hardwarePorts.find(
            (p) => Number(p.metadata?.visualIndex) === targetVisualIndex
          );

          if (!portObject) {
            console.warn(
              `Visual port ${targetVisualIndex} not found for device ${deviceId}`
            );
            continue;
          }

          const ifindex =
            port.ifindex ??
            port.Ifindex ??
            port.ifIndex ??
            port.portIndex ??
            targetVisualIndex;

          const rawOpstatus =
            port.opstatus ??
            port.opStatus ??
            port.operstatus ??
            port.Operstatus ??
            port.status;

          const rawAdminstatus =
            port.adminstatus ??
            port.adminStatus ??
            port.Adminstatus ??
            port.adminState;

          const normalizedPortData = {
            ...port,
            ifindex,
            opstatus: Number(rawOpstatus),
            adminstatus: Number(rawAdminstatus),
          };

          await updatePortGraphicState(portObject, normalizedPortData);
        }
      }

      canvasChanged = true;
    }
  }

  if (canvasChanged) {
    canvas.requestRenderAll();
  }
};

const selectableDefaults = {
  transparentCorners: false,
  cornerColor: "#0f766e",
  _borderColor: "#0f766e",
  get borderColor() {
    return this._borderColor;
  },
  set borderColor(value) {
    this._borderColor = value;
  },
  cornerStyle: "circle",
  padding: 4,
  lockUniScaling: false,
  snapAngle: 90,
};

// const is24Plus4Switch = (deviceObject) => {
//   if (!deviceObject) return false;

//   const deviceData = deviceObject.metadata?.deviceData || {};

//   const resourceId =
//     deviceData.resourceId ||
//     deviceData.ResourceId ||
//     deviceObject.metadata?.deviceId ||
//     "";

//   return (
//     String(resourceId).includes("MCT_EP_SWITCH-24PORT") &&
//     !String(resourceId).includes("MCT_EP_SWITCH-24PORT_LAN_EXT")
//   );
// };

const is24Plus4Switch = (deviceObject) => {
  if (!deviceObject) return false;

  const deviceData = deviceObject.metadata?.deviceData || {};

  // Extracting the resourceId with priority logic
  const resourceId =
    deviceData.resourceId ||
    deviceData.ResourceId ||
    deviceObject.metadata?.deviceId ||
    "";

  const idStr = String(resourceId);

  const ALLOWED_NAMES = [
    "MCT_EP_SWITCH-24PORT",
    "HUB_L3-SWITCH",
    "MCTLSV_L3_Switch",
    "DMRR_ACCESS-SWITCH-1",
    "MCT-CAR-HUB_LAYER3-SWITCH-1",
  ];
  const EXCLUDED_PATTERN = "MCT_EP_SWITCH-24PORT_LAN_EXT";

  return (
    ALLOWED_NAMES.some((name) => idStr.includes(name)) &&
    !idStr.includes(EXCLUDED_PATTERN)
  );
};

const isTenGigabitPort = (port) => {
  const ifdesc =
    port?.ifdesc ??
    port?.Ifdesc ??
    port?.ifDesc ??
    port?.interfaceName ??
    port?.ifname ??
    port?.ifName ??
    "";

  return /^TenGigabitEthernet/i.test(String(ifdesc).trim());
};

const get24Plus4VisualIndex = (port) => {
  if (!port) return null;

  const ifdesc =
    port?.ifdesc ??
    port?.Ifdesc ??
    port?.ifDesc ??
    port?.interfaceName ??
    port?.ifname ??
    port?.ifName ??
    "";

  const normalizedIfdesc = String(ifdesc).trim();

  // ------------------------------------------------------------
  // 25 - 28 MUST be identified ONLY by TenGigabitEthernet.
  //
  // Examples:
  // TenGigabitEthernet1/1/1 -> 25
  // TenGigabitEthernet1/1/2 -> 26
  // TenGigabitEthernet1/1/3 -> 27
  // TenGigabitEthernet1/1/4 -> 28
  // ------------------------------------------------------------

  if (/^TenGigabitEthernet/i.test(normalizedIfdesc)) {
    const match = normalizedIfdesc.match(/\/(\d+)$/);

    if (match) {
      const uplinkNumber = Number(match[1]);

      if (uplinkNumber >= 1 && uplinkNumber <= 4) {
        return 24 + uplinkNumber;
      }
    }

    return null;
  }

  // ------------------------------------------------------------
  // Normal 1 - 24 ports.
  //
  // For these, physical ifindex/portNumber identifies the
  // physical port. Redux array order is NEVER used.
  // ------------------------------------------------------------

  const physicalPortNumber =
    port?.portNumber ?? port?.ifindex ?? port?.ifIndex ?? port?.portIndex;

  const number = Number(physicalPortNumber);

  if (Number.isInteger(number) && number >= 1 && number <= 24) {
    return number;
  }

  return null;
};

const getPortDisplayName = (portObject) => {
  if (!portObject) return "Unknown Port";

  const details = portObject.metadata?.details || {};

  const portName =
    details.ifdesc ??
    details.portname ??
    details.interfaceName ??
    details.interface ??
    details.ifName ??
    details.ifname ??
    details.interface_name ??
    details.name ??
    details.description;

  if (portName) {
    return String(portName);
  }

  return `Port ${portObject.metadata?.ifindex ?? ""}`;
};

const getPortDisplayState = (portObject) => {
  return (
    portObject.metadata?.currentState ||
    portObject.metadata?.portState ||
    "notConfigured"
  );
};

const getInitialTopologyIndicatorColor = (device) => {
  const resourceStateId =
    device?.imResourceType?.imResourceStateInfo?.resourceStateId;

  if (resourceStateId === 2) {
    return "#D3D3D3"; // Unmanaged
  }

  if (resourceStateId === 1) {
    return "#0000ff"; // Managed
  }

  // fallback
  return "#0000ff";
};

const buildDeviceCompositeGroup = async ({
  terminal,
  device,
  deviceData,
  segment,
  radioWidth,
  isCnms,
}) => {
  const markerId = makeId("device");
  const indicatorRadius = Number(radioWidth) > 0 ? Number(radioWidth) : 40;

  const LAN_EXTENSION_SWITCH_NAME = "MCT_EP_SWITCH-24PORT_LAN_EXT";
  // const NORMAL_SWITCH_NAME = "MCT_EP_SWITCH-24PORT";
  const NORMAL_SWITCH_NAMES = [
    "MCT_EP_SWITCH-24PORT",
    "HUB_L3-SWITCH",
    "MCTLSV_L3_Switch",
    "DMRR_ACCESS-SWITCH-1",
    "MCT-CAR-HUB_LAYER3-SWITCH-1",
  ];

  const currentDeviceName = deviceData?.resourceId || device || "";

  const isLanExtensionSwitch = currentDeviceName.includes(
    LAN_EXTENSION_SWITCH_NAME
  );

  // const isNormalSwitch = currentDeviceName.includes(NORMAL_SWITCH_NAME);
  const isNormalSwitch = NORMAL_SWITCH_NAMES.some((name) =>
    currentDeviceName.includes(name)
  );

  // Only normal switch gets ports in SUPERADMIN.
  // LAN extension switch gets NO ports.
  let portsList = [];

  if (isNormalSwitch && !isLanExtensionSwitch) {
    if (SUPERADMIN) {
      // SUPERADMIN always draws 28 physical ports.
      portsList = Array.from({ length: 28 }, (_, index) => ({
        ifindex: index + 1,
        visualIndex: index + 1,
        opstatus: "down",
        adminstatus: "down",
      }));
    } else {
      // Non-SUPERADMIN continues using live Redux/resource ports.
      portsList = deviceData?.lstPortInfoDtl || [];
    }
  }

  const indicatorStatus = SUPERADMIN
    ? {
        visible: true,
        color: getInitialTopologyIndicatorColor(deviceData),
        status: "superadmin",
      }
    : getDeviceStatusIndicator(deviceData);

  const metadata = {
    kind: "device-composite-group",
    markerId,
    terminalId: terminal?.id || "",
    terminalName: terminal?.terminalTypeName || "",
    deviceId: device || "",
    deviceName: deviceData?.resourceName || device || "",
    ipAddress: deviceData?.resourceIp || "",
    status: deviceData?.status || "",
    segment: segment || "",
    radioWidth: indicatorRadius,
    deviceData,
  };

  const portsInFirstRow =
    SUPERADMIN && isNormalSwitch ? 12 : Math.ceil(portsList.length / 2);

  const portsInSecondRow =
    SUPERADMIN && isNormalSwitch ? 16 : Math.floor(portsList.length / 2);

  const maxRowItems = Math.max(portsInFirstRow, portsInSecondRow);

  const portHorizontalSpacing = 70;

  const baseRectWidth = Math.max(
    220,
    maxRowItems * portHorizontalSpacing + 120
  );

  const baseRectHeight = 180;

  const rect = new Rect({
    id: `${markerId}-rectangle`,
    shapeType: "deviceRectangle",
    width: baseRectWidth + 100,
    height: baseRectHeight,
    fill: "transparent",
    // stroke: SUPERADMIN ? "#D3D3D3" : getDeviceReachabilityColor(deviceData),
    stroke: SUPERADMIN 
    ? "#D3D3D3" 
    : (isCnms ? getDeviceReachabilityColorCnms(deviceData) : getDeviceReachabilityColor(deviceData)),

    strokeWidth: SUPERADMIN ? 20 : 20,
    originX: "center",
    originY: "center",
    metadata: {
      kind: "device-rectangle",
      deviceId: device,
      deviceData: deviceData,
      status: deviceData?.status || "",
    },
  });

  const indicator = new Circle({
    id: `${markerId}-status`,
    shapeType: "deviceStatus",
    left: baseRectWidth / 2 + 50,
    top: -baseRectHeight / 4,
    radius: indicatorRadius,
    fill: indicatorStatus.color,
    visible: indicatorStatus.visible,
    strokeWidth: 1,
    originX: "center",
    originY: "center",
    metadata: {
      kind: "device-status",
      deviceId: device,
      deviceData: deviceData,
      status: deviceData?.status || "",
      indicatorStatus: indicatorStatus.status,
    },
  });

  const compositeElements = [rect];

  if (portsList.length > 0) {
    try {
      const RIGHT_SHIFT = 20;
      const rowSpacing = 40;

      let displayPorts = [];

      // ============================================================
      // VISUAL INDEX IS THE ONLY THING USED FOR POSITIONING
      // ifindex is NOT used here.
      // ============================================================

      if (SUPERADMIN && isNormalSwitch) {
        // SUPERADMIN has fixed visual indexes 1..28.
        //
        // Visual layout:
        //
        // 1   3   5   7   9   11  13  15  17  19  21  23
        // 2   4   6   8   10  12  14  16  18  20  22  24  25  26  27  28

        const portMap = new Map(
          portsList.map((port, index) => [
            port.visualIndex ?? index + 1,
            {
              ...port,
              visualIndex: port.visualIndex ?? index + 1,
            },
          ])
        );

        const firstRowIndexes = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23];

        const secondRowIndexes = [
          2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 25, 26, 27, 28,
        ];

        displayPorts = [
          ...firstRowIndexes
            .map((visualIndex) => portMap.get(visualIndex))
            .filter(Boolean),

          ...secondRowIndexes
            .map((visualIndex) => portMap.get(visualIndex))
            .filter(Boolean),
        ];
      } else if (isNormalSwitch && !isLanExtensionSwitch) {
        // ============================================================
        // 24 + 4 SWITCH
        //
        // NEVER use Redux/API array order for visual positioning.
        //
        // 1 - 24  -> physical port number / ifindex
        // 25 - 28 -> ONLY TenGigabitEthernet interface name
        // ============================================================

        const mappedPorts = portsList
          .map((port) => {
            const visualIndex = get24Plus4VisualIndex(port);

            if (!visualIndex) {
              console.warn(
                "Unable to determine visualIndex for 24+4 switch port:",
                port
              );
              return null;
            }

            return {
              ...port,
              visualIndex,
            };
          })
          .filter(Boolean);

        const firstRowIndexes = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23];

        const secondRowIndexes = [
          2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 25, 26, 27, 28,
        ];

        const portMap = new Map(
          mappedPorts.map((port) => [Number(port.visualIndex), port])
        );

        displayPorts = [
          ...firstRowIndexes
            .map((visualIndex) => portMap.get(visualIndex))
            .filter(Boolean),

          ...secondRowIndexes
            .map((visualIndex) => portMap.get(visualIndex))
            .filter(Boolean),
        ];
      } else {
        // ============================================================
        // EXISTING BEHAVIOR FOR ALL OTHER DEVICES
        // ============================================================

        const mappedPorts = portsList.map((port, index) => ({
          ...port,
          visualIndex: index + 1,
        }));

        const oddPorts = mappedPorts.filter(
          (port) => port.visualIndex % 2 === 1
        );

        const evenPorts = mappedPorts.filter(
          (port) => port.visualIndex % 2 === 0
        );

        displayPorts = [...oddPorts, ...evenPorts];
      }

      const firstRowCount = displayPorts.filter(
        (port) => port.visualIndex % 2 === 1
      ).length;

      // Width needs to accommodate 16 ports on row 2.
      const maxPortsInRow =
        SUPERADMIN && isNormalSwitch
          ? 16
          : Math.max(firstRowCount, displayPorts.length - firstRowCount);

      const portHorizontalSpacing = 70;

      const startX =
        -((maxPortsInRow - 1) * portHorizontalSpacing) / 2 + RIGHT_SHIFT;

      for (let i = 0; i < displayPorts.length; i++) {
        const portData = displayPorts[i];

        const visualIndex = Number(portData.visualIndex);

        // ============================================================
        // POSITION ONLY FROM visualIndex
        // ============================================================

        let isSecondRow;
        let colIndex;

        if (SUPERADMIN && isNormalSwitch) {
          // Fixed SUPERADMIN layout:
          //
          // Top:
          // 1  3  5  7  9  11 13 15 17 19 21 23
          //
          // Bottom:
          // 2  4  6  8  10 12 14 16 18 20 22 24 25 26 27 28

          if (visualIndex <= 24) {
            isSecondRow = visualIndex % 2 === 0;

            colIndex = Math.floor((visualIndex - 1) / 2);
          } else {
            // 25,26,27,28 continue on second row
            isSecondRow = true;

            colIndex = 12 + (visualIndex - 25);
          }
        } else {
          // ==========================================================
          // NON-SUPERADMIN
          //
          // 1  3  5  7  9  11 ...
          // 2  4  6  8  10 12 ...
          // ==========================================================

          isSecondRow = visualIndex % 2 === 0;

          colIndex = Math.floor((visualIndex - 1) / 2);
        }

        const posX = startX + colIndex * portHorizontalSpacing;

        const posY = isSecondRow ? rowSpacing : -rowSpacing;

        await preloadPortSvgs();

        // Requirement: SUPERADMIN ports must ALWAYS be "notConfigured" (grey)
        const portState = SUPERADMIN
          ? "notConfigured"
          : mapOpStatus(portData.opstatus, portData.adminstatus);

        // const states = ["up", "down", "adminDown", "notConfigured"];
        const states = ["up", "operational_down", "down", "notConfigured"];
        const svgStateGroups = {};

        for (const state of states) {
          const objects = portSvgCache[state] || [];

          const cloned = await Promise.all(objects.map((o) => o.clone()));

          const stateGroup = new Group(cloned, {
            originX: "center",
            originY: "center",
            objectCaching: false,
            visible: state === portState,
            metadata: {
              kind: "port-svg-state",
              portState: state,
            },
          });

          svgStateGroups[state] = stateGroup;
        }

        // Force active visibility match
        const activeDisplayState = SUPERADMIN ? "notConfigured" : portState;

        if (svgStateGroups[activeDisplayState]) {
          svgStateGroups[activeDisplayState].set({
            visible: true,
            dirty: true,
          });
        } else {
          console.warn(`Missing SVG state group for: ${activeDisplayState}`);

          // Fail-safe: show grey instead of disappearing
          if (svgStateGroups.notConfigured) {
            svgStateGroups.notConfigured.set({
              visible: true,
              dirty: true,
            });
          }
        }

        let svgScaleX = 1;
        let svgScaleY = 1;

        if (Object.keys(svgStateGroups).length > 0) {
          const firstGroup = svgStateGroups.up;
          const currentWidth = firstGroup.width || 1;
          const currentHeight = firstGroup.height || 1;
          const baseScale = Math.min(24 / currentWidth, 18 / currentHeight, 20);

          const PORT_WIDTH_SCALE = 2.0;
          const PORT_HEIGHT_SCALE = 3.0;

          svgScaleX = baseScale * PORT_WIDTH_SCALE;
          svgScaleY = baseScale * PORT_HEIGHT_SCALE;

          Object.values(svgStateGroups).forEach((group) => {
            group.set({
              scaleX: svgScaleX,
              scaleY: svgScaleY,
            });
          });

          const stateContainer = new Group(Object.values(svgStateGroups), {
            originX: "center",
            originY: "center",
            objectCaching: false,
          });

          const portGraphic = new Group([stateContainer], {
            left: posX,
            top: posY,
            originX: "center",
            originY: "center",
            angle: isSecondRow ? 180 : 0,
            objectCaching: false,

            // IMPORTANT:
            // Allow Fabric to inspect this group's children
            // when resolving pointer events.
            subTargetCheck: true,
          });

          portGraphic.id = `${markerId}-port-${i}`;
          portGraphic.shapeType = "hardwarePort";
          portGraphic.stateGraphics = svgStateGroups;

          portGraphic.metadata = {
            kind: "port-node",
            deviceId: device,
            parentDeviceId: device,

            // Used for telemetry/state matching only
            ifindex: portData.ifindex,

            // Used ONLY for visual positioning
            visualIndex: Number(portData.visualIndex),

            portKey: `${device}_${portData.ifindex}`,
            portState: portState,
            svgScaleX: svgScaleX,
            svgScaleY: svgScaleY,
            currentState: portState,
            details: { ...portData },
          };
          portGraphic.setCoords();
          compositeElements.push(portGraphic);
        }
      }
    } catch (err) {
      console.error("Critical error building interface vectors:", err);
    }
  }

  const deviceBodyGroup = new Group(compositeElements, {
    objectCaching: false,
    ...selectableDefaults,
    id: markerId,
    shapeType: "deviceCompositeGroup",
    left: 200,
    top: 150,
    originX: "center",
    originY: "center",
    metadata,
    subTargetCheck: true,
  });

  return {
    deviceBodyGroup,
    statusIndicator: indicator,
  };
};

const buildLineObject = (lineType, link) => {
  const connectorColor = SUPERADMIN ? "#D3D3D3" : getEdgeColor(link.linkStatus);

  const line = new Line([-180, 0, 180, 0], {
    // stroke: getEdgeColor(link.linkStatus),
    stroke: connectorColor,
    strokeWidth: 8,
    strokeLineCap: "round",
    originX: "center",
    originY: "center",
  });
  const objects = [line];

  if (lineType === "arrow" || lineType === "doubleArrow") {
    objects.push(
      new Triangle({
        width: 24,
        height: 30,
        left: 186,
        top: 0,
        // fill: getEdgeColor(link.linkStatus),
        fill: connectorColor,
        angle: 90,
        originX: "center",
        originY: "center",
        metadata: {
          kind: "connector",
          lineType,

          linkId: link.linkId,
          linkName: link.linkName,
          linkStatus: link.linkStatus,
        },
      })
    );
  }

  if (lineType === "doubleArrow") {
    objects.push(
      new Triangle({
        width: 24,
        height: 30,
        left: -186,
        top: 0,
        // fill: "gray",
        fill: connectorColor,
        angle: -90,
        originX: "center",
        originY: "center",
      })
    );
  }

  return new Group(objects, {
    ...selectableDefaults,
    id: makeId(lineType),
    shapeType: lineType,
    left: 120,
    top: 120,
    originX: "center",
    originY: "center",
    metadata: {
      kind: "connector",
      lineType,
      linkId: link.linkId,
      linkName: link.linkName,
      linkStatus: link.linkStatus,
    },
  });
};

const findHoveredPort = (event) => {
  if (!event) return null;

  // Fabric's primary target
  const target = event.target;

  // Fabric's nested targets
  const subTargets = event.subTargets || [];

  const allTargets = [...subTargets, target].filter(Boolean);

  // Find the actual hardware port
  const port = allTargets.find(
    (obj) =>
      obj?.shapeType === "hardwarePort" && obj?.metadata?.kind === "port-node"
  );

  return port || null;
};

const FabricTopology = ({
  topologyRenderMode = "svg",
  setTopologyRenderMode,
  Rnms_TerminalType = "",
  Rnms_siteID = "",
  resources: cnmsResources = [],
  resourcesLoading = false,
  readOnly = false,
}) => {
  const canvasElementRef = useRef(null);
  const canvasHostRef = useRef(null);
  const fabricCanvasRef = useRef(null);

  const topologyFullscreenRef = useRef(null);
  const fullscreenResizeFrameRef = useRef(null);

  const [isTopologyFullscreen, setIsTopologyFullscreen] = useState(false);

  const backgroundImageRef = useRef(null);
  const isSuperAdminCreatingDeviceRef = useRef(false);
  const resourcesRef = useRef([]);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  console.log("isCnmsisCnms", isCnms);
  console.log("Rnms_TerminalTypeedc", Rnms_TerminalType);

  const topologyCacheRef = useRef({
    devices: new Map(), // deviceId -> deviceCompositeGroup
    indicators: new Map(), // deviceId -> statusIndicator
    ports: new Map(), // deviceId_ifindex -> hardwarePort
    links: new Map(), // linkId -> connector
  });

  const lastCreatedDeviceKeyRef = useRef("");
  const [svgReadOnly, setSvgReadOnly] = useState(true);
  const [portMappingOpen, setPortMappingOpen] = useState(false);
  const dispatch = useDispatch();

  const resources = useSelector((state) => state.inventory.resources);

  const topologyResources =
    Array.isArray(cnmsResources) && cnmsResources.length > 0
      ? cnmsResources
      : resources;

  console.log("topologyResources", topologyResources);
  console.log("Rnms_TerminalType", Rnms_TerminalType);
  console.log("Rnms_siteID", Rnms_siteID);

  console.log("ugugjresources", resources);

  const topologyResourcesRef = useRef([]);
  useEffect(() => {
    const latestData =
      Array.isArray(cnmsResources) && cnmsResources.length > 0
        ? cnmsResources
        : Array.isArray(resources)
        ? resources
        : [];

    topologyResourcesRef.current = latestData;
    resourcesRef.current = latestData;
  }, [cnmsResources, resources]);

  //   resources.map((itam)=>{
  //     console.log(item,item.resourceId,item.isDiscovered,item.isMaintainance)
  // })

  const badgeCountsArray = useSelector((state) => state.alarmSlice.badgeCount);

  console.log("yybadgeCountsArray", badgeCountsArray);

  // useEffect(() => {
  //   resourcesRef.current = resources;
  // }, [resources]);

  useEffect(() => {
    resourcesRef.current = topologyResources;
  }, [topologyResources]);

  resources.forEach((item, index) => {
    console.log(
      index + 1,
      "discoverd=",
      item.isDiscovered,
      "isMaintainance=",
      item.isMaintainance,
      item.resourceId,
      "rresource"
    );
  });

  const linkStatusData = useSelector(
    (state) => state.topologySlice.linkStatusData
  );

  const [contextMenuAnchor, setContextMenuAnchor] = useState(null);
  const [contextMenuNode, setContextMenuNode] = useState(null);

  const canUndo = useSelector(selectCanUndo);
  const canRedo = useSelector(selectCanRedo);
  const [placedDevices, setPlacedDevices] = useState([]);

  const presentTopology = useSelector((state) => state.topologySlice.present);

  const saveCanvasState = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;
    const json = canvas.toJSON(["id", "shapeType", "metadata"]);
    dispatch(saveTopologyState(json));
  }, [dispatch]);

  const fabricTerminals = useSelector(
    (state) => state.topologySlice?.terminalTypes ?? []
  );

  const [fabricForm, setFabricForm] = useState({
    terminalId: "",
    deviceId: "",
    deviceList: [],
    selectedDeviceData: null,
    segment: "",
    segmentList: [],
    linkStatusData: [],
    radioWidth: "40",
  });

  // Track the fresh state reference safely across canvas microtasks
  const fabricFormRef = useRef(fabricForm);
  useEffect(() => {
    fabricFormRef.current = fabricForm;
  }, [fabricForm]);

  // useEffect(() => {
  //   preloadPortSvgs();
  // }, []);

  const [selectedObject, setSelectedObject] = useState(null);
  const [isAutoLoadedViewMode, setIsAutoLoadedViewMode] = useState(false);
  const [backgroundImageSource, setBackgroundImageSource] = useState("");

  const [tooltipAnchor, setTooltipAnchor] = useState(null);
  const [activeTooltipNode, setActiveTooltipNode] = useState(null);
  const [portTooltipAnchor, setPortTooltipAnchor] = useState(null);
  const [activePortTooltip, setActivePortTooltip] = useState(null);
  const [tooltipContainer, setTooltipContainer] = useState(null);
  const [isTopologyLoading, setIsTopologyLoading] = useState(false);

  const activeTooltipNodeRef = useRef(null);
  const activePortRef = useRef(null);

  useEffect(() => {
    activeTooltipNodeRef.current = activeTooltipNode;
  }, [activeTooltipNode]);

  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  const loggedInTerminalName =
    repDetails?.imTerminalType?.terminalTypeName || "";
  const autoLoadedRef = useRef(false);

  console.log("loggedInTerminalNametgnf",loggedInTerminalName);
  

  useEffect(() => {
    if (canvasHostRef.current) {
      setTooltipContainer(canvasHostRef.current);
    }
  }, []);

  const handleUndo = () => dispatch(undoTopologyState());
  const handleRedo = () => dispatch(redoTopologyState());

  const syncLatestDeviceData = useCallback(async (canvas) => {
    if (!canvas) return;

    // ==========================================================
    // Always prefer current CNMS props when available.
    // Otherwise preserve existing Redux resource behavior.
    // ==========================================================
    const latestResources =
      Array.isArray(topologyResourcesRef.current) &&
      topologyResourcesRef.current.length > 0
        ? topologyResourcesRef.current
        : resourcesRef.current;

    if (!Array.isArray(latestResources) || latestResources.length === 0) {
      return;
    }

    try {
      // Always use the latest CNMS/resource data
      await updateResourceTopology(
        latestResources,
        canvas,
        topologyCacheRef,
        isCnms
      );

      // Rebuild cache after device data has been updated
      buildTopologyCache(canvas, topologyCacheRef);

      // Make sure Fabric recalculates every object
      canvas.getObjects().forEach((obj) => {
        obj.setCoords();

        if (obj.shapeType === "deviceCompositeGroup") {
          obj.dirty = true;

          obj.getObjects()?.forEach((child) => {
            child.dirty = true;
            child.setCoords?.();
          });
        }

        if (obj.shapeType === "deviceStatus") {
          obj.dirty = true;
          obj.setCoords();
        }
      });

      canvas.requestRenderAll();
    } catch (error) {
      console.error("Failed to sync latest CNMS device data:", error);
    }
  }, []);

  const updatePlacedDevices = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const ids = canvas
      .getObjects()
      .filter((obj) => obj.shapeType === "deviceCompositeGroup")
      .map((obj) => obj.metadata?.deviceId)
      .filter(Boolean);

    setPlacedDevices(ids);
  }, []);

  function createDebouncedHandler(delay = 500) {
    let timerId = null;
    return (callback) => {
      if (timerId) clearTimeout(timerId);
      timerId = setTimeout(() => {
        callback();
      }, delay);
    };
  }
  // Initialize the debouncer instance
  const debouncedLayoutSync = createDebouncedHandler(600);

  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.getObjects().forEach((obj) => {
      if (obj.metadata?.kind !== "connector") return;

      const latestLink = linkStatusData.find(
        (l) => String(l.linkId) === String(obj.metadata.linkId)
      );
      if (!latestLink) return;

      // const color = getEdgeColor(latestLink.linkStatus);
      const color = SUPERADMIN
        ? "#D3D3D3"
        : getEdgeColor(latestLink.linkStatus);

      obj.metadata = {
        ...obj.metadata,
        linkStatus: latestLink.linkStatus,
      };

      obj.getObjects().forEach((child) => {
        if (child.type === "line") {
          child.set({
            stroke: color,
            dirty: true,
          });
        }

        if (child.type === "triangle") {
          child.set({
            fill: color,
            dirty: true,
          });
        }

        child.dirty = true;
      });

      obj.set({
        dirty: true,
      });
    });

    canvas.requestRenderAll();

    // ADDITIONAL SAFETY SYNC
    applyLinkStatusColors(canvas, linkStatusData);
  }, [linkStatusData]);

  useEffect(() => {
    const canvas = fabricCanvasRef.current;

    if (!canvas) {
      return;
    }

    // ==========================================================
    // IMPORTANT:
    // Use CNMS props data when supplied.
    // Otherwise preserve existing Redux resource behavior.
    // ==========================================================
    const latestTopologyResources =
      Array.isArray(cnmsResources) && cnmsResources.length > 0
        ? cnmsResources
        : Array.isArray(resources)
        ? resources
        : [];

    // Keep ref immediately synchronized
    resourcesRef.current = latestTopologyResources;
    topologyResourcesRef.current = latestTopologyResources;

    // If there is no resource data yet, nothing to apply
    if (latestTopologyResources.length === 0) {
      return;
    }

    let cancelled = false;

    const syncCNMSData = async () => {
      try {
        await updateResourceTopology(
          latestTopologyResources,
          canvas,
          topologyCacheRef,
          isCnms
        );

        if (cancelled) return;

        buildTopologyCache(canvas, topologyCacheRef);

        canvas.getObjects().forEach((obj) => {
          obj.dirty = true;
          obj.setCoords();

          if (obj.shapeType === "deviceCompositeGroup") {
            obj.getObjects()?.forEach((child) => {
              child.dirty = true;
              child.setCoords?.();
            });
          }
        });

        canvas.requestRenderAll();
      } catch (error) {
        console.error("CNMS topology synchronization failed:", error);
      }
    };

    syncCNMSData();

    return () => {
      cancelled = true;
    };
  }, [resources, cnmsResources]);

  const handleDeleteCanvas = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    // 1. Wipe all physical drawn vector groups, lines, and marks
    canvas.getObjects().forEach((obj) => canvas.remove(obj));

    // 2. Clear canvas background properties completely
    canvas.backgroundImage = null;
    backgroundImageRef.current = null;
    setBackgroundImageSource("");

    // 3. Reset persistent marker configuration states
    lastCreatedDeviceKeyRef.current = "";
    setSelectedObject(null);

    // 4. Force Fabric engine layout calculations and push empty canvas to Redux undo/redo history stack
    canvas.requestRenderAll();
    buildTopologyCache(canvas, topologyCacheRef);
    saveCanvasState();
    updatePlacedDevices();

    Toast("Success", "Canvas cleared successfully", "success");
  }, [saveCanvasState]);

  const syncObjectsToImage = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    const image = backgroundImageRef.current;
    if (!canvas || !image) return;

    const imageWidth = image.width * image.scaleX;
    const imageHeight = image.height * image.scaleY;
    const imageLeft = image.left;
    const imageTop = image.top;

    canvas.getObjects().forEach((obj) => {
      if (obj.metadata?.imageX == null || obj.metadata?.imageY == null) return;

      obj.set({
        left: imageLeft + obj.metadata.imageX * imageWidth,
        top: imageTop + obj.metadata.imageY * imageHeight,
        scaleX: obj.metadata.imageScaleX
          ? obj.metadata.imageScaleX * imageWidth
          : 1,
        scaleY: obj.metadata.imageScaleY
          ? obj.metadata.imageScaleY * imageHeight
          : 1,
      });
      obj.setCoords();
    });
    canvas.requestRenderAll();
  }, []);

  // const resizeCanvas = useCallback(() => {
  //   const canvas = fabricCanvasRef.current;
  //   const host = canvasHostRef.current;
  //   if (!canvas || !host) return;

  //   const { width, height } = host.getBoundingClientRect();
  //   canvas.setDimensions({ width, height });

  //   const image = canvas.backgroundImage || backgroundImageRef.current;
  //   if (image) {
  //     const scaleX = width / image.width;
  //     const scaleY = height / image.height;
  //     canvas.setViewportTransform([scaleX, 0, 0, scaleY, 0, 0]);
  //     syncObjectsToImage();
  //   }
  //   canvas.requestRenderAll();
  // }, [syncObjectsToImage]);

  const resizeCanvas = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    const host = canvasHostRef.current;
    if (!canvas || !host) return;

    const { width, height } = host.getBoundingClientRect();

    if (width <= 0 || height <= 0) return;

    canvas.setDimensions({
      width,
      height,
    });

    const image = canvas.backgroundImage || backgroundImageRef.current;

    if (image) {
      const scaleX = width / image.width;
      const scaleY = height / image.height;

      canvas.setViewportTransform([scaleX, 0, 0, scaleY, 0, 0]);

      syncObjectsToImage();
    }

    canvas.calcOffset();
    canvas.requestRenderAll();
  }, [syncObjectsToImage]);

  const handleFullscreenChange = useCallback(() => {
    const fullscreenElement = document.fullscreenElement;

    const isFullscreen = fullscreenElement === topologyFullscreenRef.current;

    setIsTopologyFullscreen(isFullscreen);

    // Wait until browser has completed the fullscreen layout.
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        resizeCanvas();

        const canvas = fabricCanvasRef.current;

        if (canvas) {
          canvas.getObjects().forEach((obj) => {
            obj.setCoords();
          });

          canvas.calcOffset();
          canvas.requestRenderAll();
        }
      });
    });
  }, [resizeCanvas]);

  useEffect(() => {
    document.addEventListener("fullscreenchange", handleFullscreenChange);

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, [handleFullscreenChange]);

  const toggleTopologyFullscreen = useCallback(async () => {
    const container = topologyFullscreenRef.current;

    if (!container) return;

    try {
      if (document.fullscreenElement === container) {
        await document.exitFullscreen();
        return;
      }

      // If some other element is fullscreen, exit it first.
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      }

      await container.requestFullscreen();
    } catch (error) {
      console.error("Failed to toggle topology fullscreen:", error);
    }
  }, []);

  useEffect(() => {
    if (fabricCanvasRef.current) return;
    const dpr = window.devicePixelRatio || 1;

    const canvas = new Canvas(canvasElementRef.current, {
      backgroundColor: "#ffffff",
      preserveObjectStacking: true,
      selection: true,
      enableRetinaScaling: true,
      renderOnAddRemove: true,
    });

    canvas.setDimensions(
      {
        width: canvasElementRef.current.clientWidth * dpr,
        height: canvasElementRef.current.clientHeight * dpr,
      },
      { backstoreOnly: true }
    );
    canvas.setDimensions(
      {
        width: canvasElementRef.current.clientWidth,
        height: canvasElementRef.current.clientHeight,
      },
      { cssOnly: true }
    );

    fabricCanvasRef.current = canvas;
    canvas.upperCanvasEl.addEventListener("contextmenu", (e) =>
      e.preventDefault()
    );

    resizeCanvas();

    canvas.on("mouse:over", (event) => {
      const pointerEvent = event.e;
      const hoveredPort = findHoveredPort(event);

      // ==================================================
      // PORT HAS HIGHEST PRIORITY
      // ==================================================
      if (hoveredPort) {
        activePortRef.current = hoveredPort;

        const portName = getPortDisplayName(hoveredPort);
        const portState = getPortDisplayState(hoveredPort);

        setActivePortTooltip({
          name: portName,
          state: portState,
        });

        setPortTooltipAnchor({
          getBoundingClientRect: () => ({
            top: pointerEvent.clientY,
            left: pointerEvent.clientX,
            right: pointerEvent.clientX,
            bottom: pointerEvent.clientY,
            width: 0,
            height: 0,
          }),
        });

        // IMPORTANT:
        // Hide device tooltip while hovering a port
        setTooltipAnchor(null);
        setActiveTooltipNode(null);

        return;
      }

      // ==================================================
      // NORMAL DEVICE HOVER
      // ==================================================
      const target = event.target;

      if (
        target?.shapeType === "deviceCompositeGroup" &&
        target?.metadata?.deviceData
      ) {
        // Hide port tooltip
        activePortRef.current = null;
        setActivePortTooltip(null);
        setPortTooltipAnchor(null);

        // Show device tooltip
        setTooltipAnchor({
          getBoundingClientRect: () => ({
            top: pointerEvent.clientY,
            left: pointerEvent.clientX,
            right: pointerEvent.clientX,
            bottom: pointerEvent.clientY,
            width: 0,
            height: 0,
          }),
        });

        setActiveTooltipNode({
          data: target.metadata.deviceData,
        });
      }
    });

    canvas.on("mouse:move", (event) => {
      const pointerEvent = event.e;
      const hoveredPort = findHoveredPort(event);

      // ==================================================
      // PORT HOVER
      // ==================================================
      if (hoveredPort) {
        activePortRef.current = hoveredPort;

        const portName = getPortDisplayName(hoveredPort);
        const portState = getPortDisplayState(hoveredPort);

        // PORT TOOLTIP ON
        setActivePortTooltip({
          name: portName,
          state: portState,
        });

        setPortTooltipAnchor({
          getBoundingClientRect: () => ({
            top: pointerEvent.clientY,
            left: pointerEvent.clientX,
            right: pointerEvent.clientX,
            bottom: pointerEvent.clientY,
            width: 0,
            height: 0,
          }),
        });

        // DEVICE TOOLTIP OFF
        setTooltipAnchor(null);
        setActiveTooltipNode(null);

        return;
      }

      // ==================================================
      // NOT ON PORT
      // ==================================================

      activePortRef.current = null;

      // PORT TOOLTIP OFF
      setActivePortTooltip(null);
      setPortTooltipAnchor(null);

      // ==================================================
      // DEVICE HOVER
      // ==================================================

      const target = event.target;

      if (
        target?.shapeType === "deviceCompositeGroup" &&
        target?.metadata?.deviceData
      ) {
        // DEVICE TOOLTIP ON
        setTooltipAnchor({
          getBoundingClientRect: () => ({
            top: pointerEvent.clientY,
            left: pointerEvent.clientX,
            right: pointerEvent.clientX,
            bottom: pointerEvent.clientY,
            width: 0,
            height: 0,
          }),
        });

        setActiveTooltipNode({
          data: target.metadata.deviceData,
        });
      } else {
        // Nothing hovered
        setTooltipAnchor(null);
        setActiveTooltipNode(null);
      }
    });

    canvas.on("mouse:out", () => {
      activePortRef.current = null;

      setPortTooltipAnchor(null);
      setActivePortTooltip(null);

      setTooltipAnchor(null);
      setActiveTooltipNode(null);
    });

    canvas.on("object:modified", (e) => {
      const obj = e.target;
      const image = backgroundImageRef.current;
      if (!obj || !image) return;

      debouncedLayoutSync(() => {
        // Extract necessary identifiers safely from your object metadata
        const deviceId = obj.metadata?.deviceId || obj.id;

        if (deviceId) {
          // Perform silent background update (e.g., local state persistence or partial patch)
        }
      });

      const imageWidth = image.width * image.scaleX;
      const imageHeight = image.height * image.scaleY;

      obj.metadata = {
        ...obj.metadata,
        imageX: (obj.left - image.left) / imageWidth,
        imageY: (obj.top - image.top) / imageHeight,
        imageScaleX: obj.scaleX / imageWidth,
        imageScaleY: obj.scaleY / imageHeight,
      };

      saveCanvasState();
    });
    canvas.on("selection:created", (e) => {
      const selected = e.selected?.[0] || null;
      setSelectedObject(selected);

      // Extract and populate existing radius to the input field on click
      if (selected?.shapeType === "deviceStatus" && selected.radius) {
        setFabricForm((current) => ({
          ...current,
          radioWidth: String(selected.radius),
        }));
      } else if (selected?.metadata?.deviceId) {
        const matchingIndicator = canvas
          .getObjects()
          .find(
            (obj) =>
              obj.shapeType === "deviceStatus" &&
              obj.metadata?.deviceId === selected.metadata.deviceId
          );
        if (matchingIndicator?.radius) {
          setFabricForm((current) => ({
            ...current,
            radioWidth: String(matchingIndicator.radius),
          }));
        }
      }
    });

    canvas.on("selection:updated", (e) => {
      const selected = e.selected?.[0] || null;
      setSelectedObject(selected);

      if (selected?.shapeType === "deviceStatus" && selected.radius) {
        setFabricForm((current) => ({
          ...current,
          radioWidth: String(selected.radius),
        }));
      } else if (selected?.metadata?.deviceId) {
        const matchingIndicator = canvas
          .getObjects()
          .find(
            (obj) =>
              obj.shapeType === "deviceStatus" &&
              obj.metadata?.deviceId === selected.metadata.deviceId
          );
        if (matchingIndicator?.radius) {
          setFabricForm((current) => ({
            ...current,
            radioWidth: String(matchingIndicator.radius),
          }));
        }
      }
    });

    canvas.on("selection:cleared", () => setSelectedObject(null));

    canvas.on("mouse:down", (event) => {
      const mouseEvent = event.e;
      if (mouseEvent.button !== 2) return;

      mouseEvent.preventDefault();
      mouseEvent.stopPropagation();

      const target = event.target;

      if (!target || target.shapeType !== "deviceCompositeGroup") return;

      const metadata = target.metadata || {};

      const deviceId =
        metadata.deviceId ||
        metadata.resourceId ||
        metadata.deviceData?.deviceId ||
        metadata.deviceData?.resourceId;

      const latestResources =
        Array.isArray(topologyResourcesRef.current) &&
        topologyResourcesRef.current.length > 0
          ? topologyResourcesRef.current
          : Array.isArray(resourcesRef.current)
          ? resourcesRef.current
          : [];

      let deviceData = metadata.deviceData || null;

      // ==========================================================
      // If Fabric already has the correct data, preserve it.
      // ==========================================================
      if (!deviceData && deviceId && latestResources.length > 0) {
        deviceData = latestResources.find((item) => {
          const itemDeviceId = item?.deviceId ?? item?.resourceId ?? item?.id;

          return String(itemDeviceId) === String(deviceId);
        });
      }

      if (!deviceData && latestResources.length > 0) {
        const normalizedDeviceId = String(deviceId ?? "").trim();

        deviceData = latestResources.find((item) => {
          if (!item) return false;

          const possibleIds = [
            item.deviceId,
            item.resourceId,
            item.id,
            item.nodeId,
            item.deviceID,
            item.resourceID,
          ]
            .filter((value) => value !== undefined && value !== null)
            .map((value) => String(value).trim());

          return normalizedDeviceId && possibleIds.includes(normalizedDeviceId);
        });
      }

      // ==========================================================
      // Last fallback:
      // Preserve the existing behavior exactly.
      // ==========================================================
      if (!deviceData) {
        deviceData = metadata.deviceData;
      }

      if (!deviceData) {
        console.warn("Context menu: device data not found", {
          deviceId,
          metadata,
          latestResources,
        });
        return;
      }

      setTooltipAnchor(null);
      setActiveTooltipNode(null);

      setContextMenuNode({
        data: deviceData,
      });

      setContextMenuAnchor({
        mouseX: mouseEvent.clientX,
        mouseY: mouseEvent.clientY,
      });
    });

    const observer = new ResizeObserver(resizeCanvas);
    if (canvasHostRef.current) observer.observe(canvasHostRef.current);

    return () => {
      observer.disconnect();
      canvas.dispose();
      fabricCanvasRef.current = null;
    };
  }, [resizeCanvas, saveCanvasState]);

  const handleCloseContextMenu = useCallback(() => {
    setContextMenuAnchor(null);
    setContextMenuNode(null);
  }, []);

  const handleFabricUpload = useCallback(
    async (event) => {
      const file = event.target.files?.[0];
      if (!file) return;

      if (!/jpe?g$/i.test(file.name) && file.type !== "image/jpeg") {
        event.target.value = "";
        return;
      }

      const reader = new FileReader();
      reader.onload = async () => {
        const imageSource = reader.result;
        const canvas = fabricCanvasRef.current;
        if (!canvas || !imageSource) return;

        const image = await loadFabricImage(imageSource);
        image.set({ objectCaching: false, noScaleCache: true, dirty: true });

        backgroundImageRef.current = image;
        setBackgroundImageSource(imageSource);
        setCanvasBackground(canvas, image);
        requestAnimationFrame(() => resizeCanvas());
      };
      reader.readAsDataURL(file);
      event.target.value = "";
    },
    [resizeCanvas]
  );

  /* --- FIX APPLIED HERE: Direct access to ref instead of isolated static global form closure scope variables --- */
  const handleAddLine = useCallback(
    (lineType) => {
      const canvas = fabricCanvasRef.current;
      if (!canvas) return;

      const currentForm = fabricFormRef.current;

      const selectedLink = currentForm.linkStatusData.find((item) => {
        return item.linkName?.trim() === currentForm.segment?.trim();
      });

      if (!selectedLink) {
        Toast("warning", "Please select a segment", "warning");
        return;
      }

      const lineObject = buildLineObject(lineType, selectedLink);
      const image = backgroundImageRef.current;

      if (image) {
        const imageWidth = image.width * image.scaleX;
        const imageHeight = image.height * image.scaleY;

        lineObject.metadata = {
          ...lineObject.metadata,
          imageX: (lineObject.left - image.left) / imageWidth,
          imageY: (lineObject.top - image.top) / imageHeight,
          imageScaleX: lineObject.scaleX / imageWidth,
          imageScaleY: lineObject.scaleY / imageHeight,
        };
      }

      canvas.add(lineObject);
      canvas.setActiveObject(lineObject);
      saveCanvasState();
      setSelectedObject(lineObject);
    },
    [saveCanvasState]
  );

  const handleDeleteSelected = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.getActiveObjects().forEach((obj) => {
      canvas.remove(obj);
      saveCanvasState();
    });
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    setSelectedObject(null);
    updatePlacedDevices();
  }, [saveCanvasState]);

  const createDeviceMarker = useCallback(
    async (nextForm) => {
      const canvas = fabricCanvasRef.current;
      if (!canvas) return;

      // =========================================================
      // SUPERADMIN CREATION LOCK
      // Prevent topology reload while creating a device
      // =========================================================
      if (SUPERADMIN) {
        isSuperAdminCreatingDeviceRef.current = true;
      }

      try {
        const terminal = fabricTerminals.find(
          (item) => item.subTypeId === nextForm.terminalId
        );

        const { deviceBodyGroup, statusIndicator } =
          await buildDeviceCompositeGroup({
            terminal,
            device: nextForm.deviceId,
            deviceData: nextForm.selectedDeviceData,
            segment: nextForm.segment,
            radioWidth: nextForm.radioWidth,
            isCnms: isCnms,
          });

        canvas.add(deviceBodyGroup);
        canvas.add(statusIndicator);

        buildTopologyCache(canvas, topologyCacheRef);

        statusIndicator.set({
          left: deviceBodyGroup.left + deviceBodyGroup.width / 2 + 30,
          top: deviceBodyGroup.top - deviceBodyGroup.height / 2 + 20,
        });

        const image = backgroundImageRef.current;

        if (image) {
          const imageWidth = image.width * image.scaleX;
          const imageHeight = image.height * image.scaleY;

          [deviceBodyGroup, statusIndicator].forEach((obj) => {
            obj.metadata = {
              ...obj.metadata,
              imageX: (obj.left - image.left) / imageWidth,
              imageY: (obj.top - image.top) / imageHeight,
              imageScaleX: obj.scaleX / imageWidth,
              imageScaleY: obj.scaleY / imageHeight,
            };
          });
        }

        canvas.setActiveObject(deviceBodyGroup);
        canvas.requestRenderAll();

        saveCanvasState();
        setSelectedObject(deviceBodyGroup);
        updatePlacedDevices();
      } finally {
        // =========================================================
        // IMPORTANT:
        // Unlock ONLY after device creation is completely finished
        // =========================================================
        if (SUPERADMIN) {
          isSuperAdminCreatingDeviceRef.current = false;
        }
      }
    },
    [fabricTerminals, saveCanvasState]
  );

  const applySuperAdminColors = (canvas) => {
    canvas.getObjects().forEach((obj) => {
      // rectangles
      if (obj.shapeType === "deviceRectangle") {
        obj.set({
          stroke: "#D3D3D3",
          strokeWidth: 8,
        });
      }

      // indicators
      if (obj.shapeType === "deviceStatus") {
        obj.set({
          fill: getInitialTopologyIndicatorColor(obj.metadata?.deviceData),
          visible: true,
        });
      }

      // lines
      if (obj.metadata?.kind === "connector") {
        obj.getObjects().forEach((child) => {
          if (child.type === "line") child.set({ stroke: "#D3D3D3" });
          if (child.type === "triangle") child.set({ fill: "#D3D3D3" });
        });
      }

      // ports - Force all switch ports to grey (notConfigured)
      // ports - Force all switch ports to grey (notConfigured)
      if (obj.shapeType === "deviceCompositeGroup") {
        obj.getObjects().forEach((child) => {
          if (
            child.shapeType !== "hardwarePort" &&
            child.metadata?.kind !== "port-node"
          ) {
            return;
          }

          child.shapeType = "hardwarePort";

          child.metadata = {
            ...child.metadata,
            portState: "notConfigured",
            currentState: "notConfigured",
          };

          // IMPORTANT:
          // Do not change SVG fill.
          // Simply activate the notConfigured state.
          restorePortVisualState(child);

          child.dirty = true;
        });

        obj.dirty = true;
      }
    });

    canvas.requestRenderAll();
  };

  const restoreTopology = async (savedTopology, liveResources = []) => {
    const canvas = fabricCanvasRef.current;
    if (!canvas || !savedTopology) return;

    setIsTopologyLoading(true);

    try {
      canvas.getObjects().forEach((obj) => canvas.remove(obj));

      if (savedTopology.backgroundImage) {
        const image = await loadFabricImage(savedTopology.backgroundImage);
        image.set({ objectCaching: false });
        backgroundImageRef.current = image;
        setBackgroundImageSource(savedTopology.backgroundImage);
        setCanvasBackground(canvas, image);
        requestAnimationFrame(() => resizeCanvas());
      }

      // 1. Load base canvas JSON
      await canvas.loadFromJSON(savedTopology.canvas);

      const currentLinkStatusData =
        Array.isArray(linkStatusData) && linkStatusData.length > 0
          ? linkStatusData
          : fabricFormRef.current?.linkStatusData || [];

      applyLinkStatusColors(canvas, currentLinkStatusData);

      canvas.getObjects().forEach((obj) => {
        if (obj.shapeType !== "deviceCompositeGroup") {
          return;
        }

        // Device itself can inspect children
        obj.set({
          subTargetCheck: true,
        });

        obj.getObjects().forEach((child) => {
          if (child.shapeType !== "hardwarePort") {
            return;
          }

          // Port group can inspect its SVG container
          child.set({
            subTargetCheck: true,
            evented: true,
            selectable: false,
          });

          const stateContainer = child.getObjects()?.[0];

          if (stateContainer) {
            stateContainer.set({
              subTargetCheck: true,
              evented: true,
            });
          }

          child.setCoords();
        });

        obj.setCoords();
      });

      // 2. Rehydrate + migrate legacy port states
      canvas.getObjects().forEach((obj) => {
        if (obj.shapeType !== "deviceCompositeGroup") {
          return;
        }

        obj.getObjects().forEach((child) => {
          if (
            child.metadata?.kind !== "port-node" &&
            child.metadata?.ifindex == null
          ) {
            return;
          }

          child.shapeType = "hardwarePort";

          migratePortStateMetadata(child);
        });
      });

      // 3. SUPERADMIN behavior
      if (SUPERADMIN) {
        applySuperAdminColors(canvas);
      }

      // 4. Restore background
      canvas.backgroundImage = backgroundImageRef.current;

      // 5. Build cache AFTER migration
      buildTopologyCache(canvas, topologyCacheRef);

      // Restore every saved port visual state
      canvas.getObjects().forEach((obj) => {
        if (obj.shapeType !== "deviceCompositeGroup") return;

        obj.getObjects().forEach((child) => {
          if (child.shapeType !== "hardwarePort") return;

          restorePortVisualState(child);
        });
      });

      updatePlacedDevices();

      if (Array.isArray(liveResources) && liveResources.length > 0) {
        await updateResourceTopology(
          liveResources,
          canvas,
          topologyCacheRef,
          isCnms
        );
      }

      // IMPORTANT:
      // CNMS/device data must always be the final source of truth
      await syncLatestDeviceData(canvas);

      canvas.getObjects().forEach((obj) => {
        obj.setCoords();
      });

      canvas.requestRenderAll();
      resizeCanvas();

      setTimeout(() => {
        syncObjectsToImage();
        canvas.getObjects().forEach((obj) => obj.setCoords());
        canvas.requestRenderAll();
      }, 0);
    } finally {
      setIsTopologyLoading(false);
    }
  };

  const setCanvasReadOnly = (readonly) => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.discardActiveObject();
    canvas.selection = !readonly;

    canvas.getObjects().forEach((obj) => {
      obj.set({
        selectable: !readonly,
        evented: true,
        lockMovementX: readonly,
        lockMovementY: readonly,
        lockScalingX: readonly,
        lockScalingY: readonly,
        lockRotation: readonly,
        hasControls: !readonly,
        hasBorders: !readonly,
      });
    });
    canvas.requestRenderAll();
  };

  // const autoLoadLoggedInTopology = useCallback(
  //   async (terminalName) => {
  //     try {
  //       const fileName =
  //         terminalName.replace(/-/g, "_").replace(/\s+/g, "_") + ".json";
  //       const response = await fetch(`/saveTopology/${fileName}`);

  //       if (!response.ok) {
  //         const canvas = fabricCanvasRef.current;
  //         if (canvas) {
  //           canvas.getObjects().forEach((obj) => canvas.remove(obj));
  //           canvas.backgroundImage = null;
  //           backgroundImageRef.current = null;
  //           canvas.requestRenderAll();
  //         }
  //         return;
  //       }

  //       const savedTopology = await response.json();
  //       // await restoreTopology(savedTopology);
  //       await restoreTopology(savedTopology, resources);
  //       setCanvasReadOnly(true);
  //       setSvgReadOnly(true);
  //       setIsAutoLoadedViewMode(true);
  //     } catch (err) {
  //       console.error(err);
  //     }
  //   },
  //   [resizeCanvas, resources]
  // );

  const autoLoadLoggedInTopology = useCallback(
    async (terminalName) => {
      if (!terminalName) {
        return;
      }

      try {
        const normalizedTerminalName = String(terminalName)
          .replace(/-/g, "_")
          .replace(/\s+/g, "_");

        const fileName = `${normalizedTerminalName}.json`;

        console.log("bdhbbdfilename",fileName);
        

        console.log("CNMS loading topology:", {
          Rnms_TerminalType,
          Rnms_siteID,
          terminalName,
          fileName,
        });

        const response = await fetch(`/saveTopology/${fileName}`);

        if (!response.ok) {
          const canvas = fabricCanvasRef.current;

          if (canvas) {
            canvas.getObjects().forEach((obj) => canvas.remove(obj));

            canvas.backgroundImage = null;

            backgroundImageRef.current = null;

            canvas.requestRenderAll();
          }

          return;
        }

        const savedTopology = await response.json();

        await restoreTopology(savedTopology, resourcesRef.current);

        setCanvasReadOnly(true);
        setSvgReadOnly(true);
        setIsAutoLoadedViewMode(true);
      } catch (err) {
        console.error("Failed to auto-load CNMS topology:", err);
      }
    },
    [Rnms_TerminalType, Rnms_siteID, resizeCanvas]
  );

  useEffect(() => {
    if (!loggedInTerminalName || autoLoadedRef.current) return;
    autoLoadedRef.current = true;
    autoLoadLoggedInTopology(loggedInTerminalName);
  }, [loggedInTerminalName, autoLoadLoggedInTopology]);

  useEffect(() => {
    if (!Rnms_TerminalType) {
      return;
    }

    if (resourcesLoading) {
      return;
    }

    autoLoadedRef.current = false;
  }, [Rnms_TerminalType, Rnms_siteID]);

  useEffect(() => {
    if (!Rnms_TerminalType) {
      return;
    }

    if (resourcesLoading) {
      return;
    }

    if (autoLoadedRef.current) {
      return;
    }

    autoLoadedRef.current = true;

    autoLoadLoggedInTopology(Rnms_TerminalType);
  }, [
    Rnms_TerminalType,
    Rnms_siteID,
    resourcesLoading,
    autoLoadLoggedInTopology,
  ]);

  const hasLoaded = useRef(false); // default

  const loadTopologyForTerminal = useCallback(
    async (terminalId) => {
      if (Rnms_TerminalType) {
        if (SUPERADMIN && isSuperAdminCreatingDeviceRef.current) {
          return;
        }

        const terminalName = Rnms_TerminalType;

        console.log("terminalNamecnms", terminalName);

        const fileName =
          String(terminalName).replace(/-/g, "_").replace(/\s+/g, "_") +
          ".json";

        console.log("CNMS loadTopologyForTerminal:", {
          Rnms_TerminalType,
          Rnms_siteID,
          terminalId,
          fileName,
        });

        console.log("cnmsfileName", fileName);

        try {
          const response = await fetch(`/saveTopology/${fileName}`);

          if (!response.ok) {
            const canvas = fabricCanvasRef.current;

            if (canvas) {
              canvas.getObjects().forEach((obj) => canvas.remove(obj));

              canvas.backgroundImage = null;
              backgroundImageRef.current = null;

              setBackgroundImageSource("");

              canvas.requestRenderAll();
            }

            setCanvasReadOnly(false);
            setSvgReadOnly(false);
            setIsAutoLoadedViewMode(false);

            Toast(
              "Info",
              "No topology found. Upload image to create topology.",
              "info"
            );

            return;
          }

          const savedTopology = await response.json();

          await restoreTopology(savedTopology, resourcesRef.current);

          setCanvasReadOnly(true);
          setSvgReadOnly(true);
          setIsAutoLoadedViewMode(true);

          Toast("Success", `${terminalName} topology loaded`, "success");
        } catch (error) {
          console.error("Failed to load CNMS topology:", error);
        }

        return;
      }

      // ============================================================
      // EXISTING FABRIC TOPOLOGY BEHAVIOR
      // DO NOT CHANGE THIS PART
      // ============================================================

      if (SUPERADMIN && isSuperAdminCreatingDeviceRef.current) {
        return;
      }

      const terminal = fabricTerminals.find(
        (item) => String(item.subTypeId) === String(terminalId)
      );

      if (!terminal) return;

      const terminalName = terminal.subTypeName || terminal.terminalTypeName;

      const fileName =
        terminalName.replace(/-/g, "_").replace(/\s+/g, "_") + ".json";

      const loadData = async () => {
        hasLoaded.current = true;

        console.log("nnnfileName",fileName);
        

        try {
          const response = await fetch(`/saveTopology/${fileName}`);

          if (!response.ok) {
            const canvas = fabricCanvasRef.current;

            if (canvas) {
              canvas.getObjects().forEach((obj) => canvas.remove(obj));

              canvas.backgroundImage = null;
              backgroundImageRef.current = null;

              setBackgroundImageSource("");

              canvas.requestRenderAll();
            }

            setCanvasReadOnly(false);
            setSvgReadOnly(false);
            setIsAutoLoadedViewMode(false);

            Toast(
              "Info",
              "No topology found. Upload image to create topology.",
              "info"
            );

            return;
          }

          const savedTopology = await response.json();

          await restoreTopology(savedTopology, resourcesRef.current);

          setCanvasReadOnly(false);
          setSvgReadOnly(false);
          setIsAutoLoadedViewMode(false);

          Toast("Success", `${terminalName} topology loaded`, "success");
        } catch (error) {
          console.error(error);
        }
      };
      loadData();
    },
    [fabricTerminals, Rnms_TerminalType, Rnms_siteID]
  );

  useEffect(() => {
    if (!fabricForm.terminalId) return;
    // SUPERADMIN:
    // Do not reload the topology while a device is being created.
    if (SUPERADMIN && isSuperAdminCreatingDeviceRef.current) {
      return;
    }
    hasLoaded.current = false; // Reset flag to allow auto-loading on tab switch
    loadTopologyForTerminal(fabricForm.terminalId);
  }, [fabricForm.terminalId, loadTopologyForTerminal]);

  /* --- FIX APPLIED HERE: Completely decoupled dependency array to protect closure references --- */
  const handleFabricFieldChange = useCallback(
    (field, value) => {
      if (field === "terminalId") {
        lastCreatedDeviceKeyRef.current = "";
        setFabricForm({
          terminalId: value,
          deviceId: "",
          deviceList: [],
          selectedDeviceData: null,
          segment: "",
          segmentList: [],
          linkStatusData: [],
          radioWidth: "40",
        });
        return;
      }

      if (field === "createDeviceMarker") {
        createDeviceMarker({
          ...fabricFormRef.current,
          deviceId: value.deviceId,
          selectedDeviceData: value.selectedDeviceData,
        });
        return;
      }

      if (field === "deleteCanvas") {
        handleDeleteCanvas();
        return;
      }

      if (field === "segment") {
        setFabricForm((current) => ({ ...current, segment: value }));
        return;
      }

      if (field === "linkStatusData") {
        setFabricForm((prev) => ({ ...prev, linkStatusData: value }));
        return;
      }

      if (field === "loadTopology") {
        loadTopologyForTerminal(value);
        return;
      }
      if (field === "radioWidth") {
        const canvas = fabricCanvasRef.current;
        const activeObject = canvas?.getActiveObject();

        // 1. Instantly update text box state so UI remains fluid and responsive
        setFabricForm((current) => ({ ...current, radioWidth: value }));

        const nextRadius = value === "" ? 0 : Number(value);

        // 2. Adjust active shapes visually on screen without triggering Redux re-loads
        if (activeObject && Number.isFinite(nextRadius) && nextRadius > 0) {
          let targetIndicator = null;

          if (activeObject.shapeType === "deviceStatus") {
            targetIndicator = activeObject;
          } else if (activeObject.metadata?.deviceId) {
            targetIndicator = canvas
              .getObjects()
              .find(
                (obj) =>
                  obj.shapeType === "deviceStatus" &&
                  obj.metadata?.deviceId === activeObject.metadata.deviceId
              );
          }

          if (targetIndicator) {
            targetIndicator.set({
              radius: nextRadius,
              width: nextRadius * 2,
              height: nextRadius * 2,
              dirty: true, // clear render caches
            });

            targetIndicator.setCoords();
            canvas.requestRenderAll();
            // 🔥 NOTICE: saveCanvasState() removed from here to prevent selection loss
          }
        }
        return;
      }

      // 3. Add this new action handle so the toolbar can push history when typing ends
      if (field === "commitCanvasState") {
        saveCanvasState();
        return;
      }

      setFabricForm((current) => ({ ...current, [field]: value }));
    },
    [createDeviceMarker, loadTopologyForTerminal, handleDeleteCanvas]
  );

  const handleDeleteAll = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.getObjects().forEach((obj) => canvas.remove(obj));
    saveCanvasState();
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    buildTopologyCache(canvas, topologyCacheRef);
    setSelectedObject(null);
    updatePlacedDevices();
  }, [saveCanvasState]);

  /* --- FIX APPLIED HERE: Using fabricFormRef pool inside Save safely --- */
  // const handleSaveFabric = useCallback(() => {
  //   const canvas = fabricCanvasRef.current;
  //   if (!canvas) return;

  //   canvas.getObjects().forEach((obj) => {
  //     obj.fill = "transparent";
  //   });

  //   const currentForm = fabricFormRef.current;
  //   const terminal = fabricTerminals.find(
  //     (item) => item.subTypeId === currentForm.terminalId
  //   );
  //   const terminalName =
  //     terminal?.terminalTypeName || terminal?.subTypeName || "Topology";
  //   const fileName =
  //     terminalName.replace(/-/g, "_").replace(/\s+/g, "_") + ".json";

  //   if (SUPERADMIN) {
  //     canvas.getObjects().forEach((obj) => {
  //       // device rectangle
  //       if (obj.shapeType === "deviceRectangle") {
  //         obj.set({
  //           stroke: "#D3D3D3",
  //           strokeWidth: 8,
  //         });
  //       }

  //       // device indicator
  //       if (obj.shapeType === "deviceStatus") {
  //         obj.set({
  //           fill: getInitialTopologyIndicatorColor(obj.metadata?.deviceData),
  //         });
  //       }

  //       // connectors
  //       if (obj.metadata?.kind === "connector") {
  //         obj.getObjects().forEach((child) => {
  //           if (child.type === "line") {
  //             child.set({
  //               stroke: "#D3D3D3",
  //             });
  //           }

  //           if (child.type === "triangle") {
  //             child.set({
  //               fill: "#D3D3D3",
  //             });
  //           }
  //         });
  //       }

  //       // Switch ports
  //       if (obj.shapeType === "deviceCompositeGroup") {
  //         obj.getObjects().forEach((child) => {
  //           if (child.shapeType === "hardwarePort") {
  //             const stateContainer = child.getObjects()?.[0];

  //             stateContainer?.getObjects()?.forEach((svgGroup) => {
  //               svgGroup.set({
  //                 fill: "#D3D3D3",
  //               });
  //             });

  //             // IMPORTANT:
  //             // Save the actual Superadmin port state consistently.
  //             child.metadata = {
  //               ...child.metadata,
  //               portState: "notConfigured",
  //               currentState: "notConfigured",
  //             };
  //           }
  //         });
  //       }
  //     });
  //   }

  //   const payload = {
  //     module: "topology",
  //     terminalId: currentForm.terminalId,
  //     terminalName,
  //     backgroundImage: backgroundImageSource,
  //     savedAt: new Date().toISOString(),
  //     canvas: canvas.toJSON(["id", "shapeType", "metadata"]),
  //   };

  //   const blob = new Blob([JSON.stringify(payload, null, 2)], {
  //     type: "application/json",
  //   });
  //   const url = URL.createObjectURL(blob);
  //   const link = document.createElement("a");

  //   link.href = url;
  //   link.download = fileName;
  //   document.body.appendChild(link);
  //   link.click();
  //   document.body.removeChild(link);
  //   URL.revokeObjectURL(url);

  //   Toast("Success", `${fileName} saved successfully`, "success");
  // }, [fabricTerminals, backgroundImageSource]);

  const handleSaveFabric = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.getObjects().forEach((obj) => {
      obj.fill = "transparent";
    });

    const currentForm = fabricFormRef.current;

    const terminal = fabricTerminals.find(
      (item) => item.subTypeId === currentForm.terminalId
    );

    const terminalName =
      terminal?.terminalTypeName || terminal?.subTypeName || "Topology";

    const fileName =
      terminalName.replace(/-/g, "_").replace(/\s+/g, "_") + ".json";

    if (SUPERADMIN) {
      canvas.getObjects().forEach((obj) => {
        // device rectangle
        if (obj.shapeType === "deviceRectangle") {
          obj.set({
            stroke: "#D3D3D3",
            strokeWidth: 8,
          });
        }

        // device indicator
        if (obj.shapeType === "deviceStatus") {
          obj.set({
            fill: getInitialTopologyIndicatorColor(obj.metadata?.deviceData),
          });
        }

        // connectors
        if (obj.metadata?.kind === "connector") {
          obj.getObjects().forEach((child) => {
            if (child.type === "line") {
              child.set({
                stroke: "#D3D3D3",
              });
            }

            if (child.type === "triangle") {
              child.set({
                fill: "#D3D3D3",
              });
            }
          });
        }

        // Switch ports
        if (obj.shapeType === "deviceCompositeGroup") {
          obj.getObjects().forEach((child) => {
            if (child.shapeType === "hardwarePort") {
              const stateContainer = child.getObjects()?.[0];

              stateContainer?.getObjects()?.forEach((svgGroup) => {
                svgGroup.set({
                  fill: "#D3D3D3",
                });
              });

              child.metadata = {
                ...child.metadata,
                portState: "notConfigured",
                currentState: "notConfigured",
              };
            }
          });
        }
      });
    }

    // ---------------------------------------------------------
    // Convert Fabric canvas to JSON
    // ---------------------------------------------------------
    const canvasJson = canvas.toJSON(["id", "shapeType", "metadata"]);

    // ---------------------------------------------------------
    // Fields to remove from deviceData
    // ---------------------------------------------------------
    const DEVICE_DATA_FIELDS_TO_REMOVE = new Set([
      "imSegmentInfo",
      "tmSnmpProfile",
      "remarks",
      "resourceIp",
      "resourceName",
      "macAddress",
      "sysOidValue",
      "serialNumOid",
      "timestamp",
      "resourceDesc",
      "portNumber",
      "resourceSerialno",
      "remoteNum",
      "status",
      "discoveredstatusMessage",
      "discoveryMode",
      "firmwareVersion",
      "lstPortInfoDtl",
    ]);

    // ---------------------------------------------------------
    // Fields to remove from inside imResourceType
    // ---------------------------------------------------------
    const IM_RESOURCE_TYPE_FIELDS_TO_REMOVE = new Set([
      "data",
      "enterpriseOid",
      "firmwareNumOid",
      "sysOidValue",
      "serialNumOid",
      "model",
      "make",
      "isSource",
      "isTarget",
      "resourceTypeId",
      "resourceTypeName",
      "terminalId",
      "resourceNickName",
      "imCommunicationType",
    ]);

    // ---------------------------------------------------------
    // Clean imResourceType
    // ---------------------------------------------------------
    const cleanImResourceType = (imResourceType) => {
      if (!imResourceType || typeof imResourceType !== "object") {
        return imResourceType;
      }

      return Object.fromEntries(
        Object.entries(imResourceType).filter(
          ([key]) => !IM_RESOURCE_TYPE_FIELDS_TO_REMOVE.has(key)
        )
      );
    };

    // ---------------------------------------------------------
    // Clean deviceData
    // ---------------------------------------------------------
    const cleanDeviceData = (deviceData) => {
      if (!deviceData || typeof deviceData !== "object") {
        return deviceData;
      }

      const cleanedDeviceData = Object.fromEntries(
        Object.entries(deviceData).filter(
          ([key]) => !DEVICE_DATA_FIELDS_TO_REMOVE.has(key)
        )
      );

      // Keep imResourceType, but clean specific fields inside it
      if (cleanedDeviceData.imResourceType) {
        cleanedDeviceData.imResourceType = cleanImResourceType(
          cleanedDeviceData.imResourceType
        );
      }

      return cleanedDeviceData;
    };

    // ---------------------------------------------------------
    // Clean metadata
    // ---------------------------------------------------------
    const cleanMetadata = (metadata) => {
      if (!metadata || typeof metadata !== "object") {
        return metadata;
      }

      const cleanedMetadata = {
        ...metadata,
      };

      if (cleanedMetadata.deviceData) {
        cleanedMetadata.deviceData = cleanDeviceData(
          cleanedMetadata.deviceData
        );
      }

      return cleanedMetadata;
    };

    // ---------------------------------------------------------
    // Recursively clean Fabric objects
    // ---------------------------------------------------------
    const cleanFabricObject = (obj) => {
      if (!obj || typeof obj !== "object") {
        return obj;
      }

      const cleanedObject = {
        ...obj,
      };

      if (cleanedObject.metadata) {
        cleanedObject.metadata = cleanMetadata(cleanedObject.metadata);
      }

      if (Array.isArray(cleanedObject.objects)) {
        cleanedObject.objects = cleanedObject.objects.map(cleanFabricObject);
      }

      return cleanedObject;
    };

    const cleanedCanvas = {
      ...canvasJson,
      objects: Array.isArray(canvasJson.objects)
        ? canvasJson.objects.map(cleanFabricObject)
        : [],
    };

    // ---------------------------------------------------------
    // Final payload
    // ---------------------------------------------------------
    const payload = {
      module: "topology",
      terminalId: currentForm.terminalId,
      terminalName,
      backgroundImage: backgroundImageSource,
      savedAt: new Date().toISOString(),
      canvas: cleanedCanvas,
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);

    Toast("Success", `${fileName} saved successfully`, "success");
  }, [fabricTerminals, backgroundImageSource]);

  const applyReduxTopology = useCallback(
    async (json) => {
      const canvas = fabricCanvasRef.current;
      if (!canvas || !json) return;
      setIsTopologyLoading(true);
      try {
        await canvas.loadFromJSON(json);

        const currentLinkStatusData =
          Array.isArray(linkStatusData) && linkStatusData.length > 0
            ? linkStatusData
            : fabricFormRef.current?.linkStatusData || [];

        applyLinkStatusColors(canvas, currentLinkStatusData);

        canvas.getObjects().forEach((obj) => {
          if (obj.shapeType !== "deviceCompositeGroup") {
            return;
          }

          // Device itself can inspect children
          obj.set({
            subTargetCheck: true,
          });

          obj.getObjects().forEach((child) => {
            if (child.shapeType !== "hardwarePort") {
              return;
            }

            // Port group can inspect its SVG container
            child.set({
              subTargetCheck: true,
              evented: true,
              selectable: false,
            });

            const stateContainer = child.getObjects()?.[0];

            if (stateContainer) {
              stateContainer.set({
                subTargetCheck: true,
                evented: true,
              });
            }

            child.setCoords();
          });

          obj.setCoords();
        });

        buildTopologyCache(canvas, topologyCacheRef);
        updatePlacedDevices();

        if (Array.isArray(topologyResources) && topologyResources.length > 0) {
          await updateResourceTopology(
            topologyResources,
            canvas,
            topologyCacheRef,
            isCnms
          );
        }

        canvas.getObjects().forEach((obj) => obj.setCoords());
        canvas.requestRenderAll();
      } catch (err) {
        console.error("Failed applying Redux topology history:", err);
      } finally {
        setIsTopologyLoading(false);
      }
    },
    [topologyResources, linkStatusData]
  );

  useEffect(() => {
    if (!presentTopology) return;
    if (SUPERADMIN && isSuperAdminCreatingDeviceRef.current) {
      return;
    }
    applyReduxTopology(presentTopology);
  }, [presentTopology, applyReduxTopology]);

  return (
    <>
      <Backdrop
        open={isTopologyLoading}
        sx={{
          zIndex: (theme) => theme.zIndex.modal + 1,
          color: "#fff",
        }}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
      {/* <section className="topology-surface"> */}
      <section
        ref={topologyFullscreenRef}
        className={`topology-surface ${
          isTopologyFullscreen ? "topology-surface-fullscreen" : ""
        }`}
      >
        <div
          className="topology-toolbar"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <TopologyEditActions
            currentViewTopology
            topologyRenderMode={topologyRenderMode}
            setTopologyRenderMode={setTopologyRenderMode}
            fabricTerminals={fabricTerminals}
            fabricForm={fabricForm}
            fabricSelectedObject={selectedObject}
            onFabricUpload={handleFabricUpload}
            onFabricAddLine={handleAddLine}
            onFabricDeleteSelected={handleDeleteSelected}
            onFabricSave={handleSaveFabric}
            onFabricFieldChange={handleFabricFieldChange}
            onFabricDeleteAll={handleDeleteAll}
            svgReadOnly={svgReadOnly}
            isAutoLoadedViewMode={isAutoLoadedViewMode}
            onCanvasUndo={handleUndo}
            fabricCanvasRef={fabricCanvasRef}
            onCanvasRedo={handleRedo}
            canUndo={canUndo}
            canRedo={canRedo}
            placedDevices={placedDevices}
            portMappingOpen={portMappingOpen}
            onPortMappingToggle={() => setPortMappingOpen((prev) => !prev)}
          />
          {!isCnms && (
            <CustomeFullscreen
              closeIconvisible={false}
              isFullScreen={isTopologyFullscreen}
              onToggleFullScreen={toggleTopologyFullscreen}
            />
          )}
        </div>
        {/* )} */}

        <div
          style={{
            display: "flex",
            width: "100%",
            height: "100%",
            minHeight: 0,
            overflow: "hidden",
          }}
        >
          <div
            ref={canvasHostRef}
            className="fabric-canvas-host"
            onContextMenu={(e) => e.preventDefault()}
            style={{
              flex: portMappingOpen ? "0 0 61.43%" : "1 1 100%",
              width: portMappingOpen ? "61.43%" : "100%",
              minWidth: 0,
              transition: "width 0.25s ease, flex-basis 0.25s ease",
            }}
          >
            <canvas
              ref={canvasElementRef}
              onContextMenu={(e) => e.preventDefault()}
            />

            <NodeTooltip
              anchorEl={tooltipAnchor}
              activeNode={activeTooltipNode}
              alarms={[]}
              isLoading={false}
              container={tooltipContainer}
            />

            {activePortTooltip && portTooltipAnchor && (
              <div
                style={{
                  position: "fixed",
                  left: portTooltipAnchor.getBoundingClientRect().left + 12,
                  top: portTooltipAnchor.getBoundingClientRect().top + 12,
                  zIndex: 99999,
                  pointerEvents: "none",
                  background: "#111827",
                  color: "#ffffff",
                  padding: "5px 9px",
                  borderRadius: "4px",
                  fontSize: "12px",
                  fontWeight: 500,
                  whiteSpace: "nowrap",
                  boxShadow: "0 2px 8px rgba(0, 0, 0, 0.25)",
                }}
              >
                {activePortTooltip.name} - {activePortTooltip.state}
              </div>
            )}

            <UnifiedContextMenu
              anchor={contextMenuAnchor}
              node={contextMenuNode}
              onClose={handleCloseContextMenu}
              container={tooltipContainer}
              viewOnly={readOnly}
            />
          </div>

          {portMappingOpen && (
            <div
              style={{
                flex: "0 0 38.57%",
                width: "38.57%",
                minWidth: 0,
                height: "100%",
                overflow: "hidden",
              }}
            >
              <PortMapping />
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default memo(FabricTopology);
