import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  Box,
  Grid,
  Paper,
  Typography,
  Divider,
  CircularProgress,
  LinearProgress,
  Switch,
  useTheme,
  TextField,
  Button,
} from "@mui/material";

import {
  LocationOnRounded,
  PanToolRounded,
  RotateLeftRounded,
  ControlCameraRounded,
  CheckCircleRounded,
} from "@mui/icons-material";

import { useSelector } from "react-redux";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";

import Confirmation_icon from "../../../../../src/assets/SVGIcons/question_mark.svg";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  ACU_AUTO_MOVE,
  ACU_GET_ANTENNA_RESET,
  ACU_GET_DEPLOY,
  ACU_GET_LOCATE,
  ACU_GET_MOVE_JOG,
  ACU_GET_NAVIGATIONAL_DATA,
  ACU_GET_STATUS,
  ACU_GET_STATUS_CNMS,
  ACU_GET_STOP,
  ACU_GET_STOW,
} from "@/RestAPI/url/endpoint";
import AcuConfigurationSatelliteTable from "./AcuConfigurationSatelliteTable";
import ChassisView from "./ChassisView";

/* ============================================================================
 * CONSTANTS
 * ========================================================================== */

const TABS = [
  {
    label: "MOVEMENT CONTROL",
    value: "MOVEMENT CONTROL",
  },
  {
    label: "SATELLITE DATA",
    value: "SATELLITE DATA",
  },
];

const JOG_OPTIONS = [
  { value: "Azccw", label: "Azimuth CCW" },
  { value: "Azcw", label: "Azimuth CW" },
  { value: "Elup", label: "Elevation Up" },
  { value: "Eldown", label: "Elevation Down" },
  { value: "Polcw", label: "Polarization CW" },
  { value: "Polccw", label: "Polarization CCW" },
];

const SPEED_OPTIONS = [
  { value: "slow", label: "Slow" },
  { value: "fast", label: "Fast" },
];

const DURATION_OPTIONS = Array.from({ length: 9 }, (_, index) => ({
  value: String(index + 1),
  label: `${index + 1} Sec`,
}));

const SATELLITE_OPTIONS = [
  { value: "1", label: "1" },
  { value: "2", label: "2" },
  { value: "3", label: "3" },
];

const POLARIZATION_OPTIONS = [
  { value: "H", label: "Horizontal" },
  { value: "V", label: "Vertical" },
];

const OPERATION_MESSAGES = {
  jogMove: "Antenna movement in progress",
  deploy: "Antenna deployment in progress",
  stow: "Antenna stowing in progress",
  locate: "Antenna locating in progress",
};

const getColors = (isDark) => ({
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  cardBg: isDark ? "#252525" : "#ffffff",
  border: isDark ? "#404040" : "#e0e0e0",
  heading: isDark ? "#f3f4f6" : "#1f2937",
  text: isDark ? "#d1d5db" : "#4b5563",
  muted: isDark ? "#9ca3af" : "#6b7280",
  success: isDark ? "#86efac" : "#15803d",
  successBg: isDark ? "#14291e" : "#f0fdf4",
  warning: isDark ? "#fdba74" : "#c2410c",
  warningBg: isDark ? "#332417" : "#fff7ed",
  primary: "#14348D",
});

/* ============================================================================
 * COMPONENT
 * ========================================================================== */

const AcuConfigurationMK = ({ node, deviceID }) => {
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const colors = getColors(isDark);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  /*
   * Support both the new node structure and the old resource structure.
   */
  const resource = node;

  const resourceId = node?.resourceId;

  const siteId =
    node?.siteId || resource?.siteId || resource?.imSiteDetail?.siteId;

  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  /* ==========================================================================
   * STATE
   * ======================================================================== */

  const [activeTab, setActiveTab] = useState("MOVEMENT CONTROL");

  const [isInitialLoading, setIsInitialLoading] = useState(true);

  const [loading, setLoading] = useState(false);

  const [navigationalData, setNavigationalData] = useState({});

  const [antennaMovement, setAntennaMovement] = useState(false);

  const [currentMovement, setCurrentMovement] = useState("stop");

  const [jog, setJog] = useState("");
  const [speed, setSpeed] = useState("");
  const [duration, setDuration] = useState("");

  const [autoMovParam, setAutoMoveParam] = useState({
    azimuth: "",
    elevation: "",
  });

  const [autoMoveErr, setAutoMoveErr] = useState(false);

  const [locateData, setLocateData] = useState({
    satelliteIndex: "",
    locatePolDirection: "",
  });

  const [resetValue, setResetValue] = useState("");

  const [showChassis, setShowChassis] = useState(false);

  const [showLocate, setShowLocate] = useState(null);

  const [confirmationDialog, setConfirmationDialog] = useState({
    open: false,
    operation: "",
    message: "",
  });
  const [openConfigDialog, setOpenConfigDialog] = useState(true);
  const [azChange, setAzChange] = useState(false);
  const [elChange, setElChange] = useState(false);
  const [polChange, setPolChange] = useState(false);

  /* ==========================================================================
   * REFS
   * ======================================================================== */

  const pollingRef = useRef(null);
  const mountedRef = useRef(false);

  /*
   * Refs prevent stale state inside polling callbacks.
   */
  const antennaMovementRef = useRef(false);
  const currentMovementRef = useRef("stop");

  const setMovementStatus = (value) => {
    antennaMovementRef.current = value;
    setAntennaMovement(value);
  };

  const setOperation = (value) => {
    currentMovementRef.current = value;
    setCurrentMovement(value);
  };

  /* ==========================================================================
   * OPTIONS
   * ======================================================================== */

  const satelliteOptions = useMemo(() => SATELLITE_OPTIONS, []);

  /* ==========================================================================
   * GAUGE CONFIGURATION
   * ======================================================================== */

  const azimuthWidgetConfig = useMemo(
    () => ({
      gridTitle: "Azimuth",
      minVal: -180,
      maxVal: 180,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(navigationalData?.azimuth) || 0,
        },
      ],
    }),
    [navigationalData?.azimuth]
  );

  const elevationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Elevation",
      minVal: -180,
      maxVal: 180,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(navigationalData?.elevation) || 0,
        },
      ],
    }),
    [navigationalData?.elevation]
  );

  const polarizationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Polarization",
      minVal: -180,
      maxVal: 180,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(navigationalData?.polarization) || 0,
        },
      ],
    }),
    [navigationalData?.polarization]
  );

  /* ==========================================================================
   * HELPERS
   * ======================================================================== */

  const showMessage = (message, type = "error") => {
    Toast(type === "success" ? "Success" : "Error", message, type);
  };

  const stopPolling = useCallback(() => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
  }, []);

  const handleLocateChange = (key, value) => {
    setLocateData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleCloseConfirmation = () => {
    setConfirmationDialog({
      open: false,
      operation: "",
      message: "",
    });
  };

  const getConfirmationMessage = (operation) => {
    const messages = {
      jogMove: "Are you sure you want to move the antenna?",
      deploy: "Are you sure you want to deploy the antenna?",
      stow: "Are you sure you want to stow the antenna?",
      locate: "Are you sure you want to locate the antenna?",
      stop: "Are you sure you want to stop antenna movement?",
    };

    return messages[operation] || "Are you sure you want to continue?";
  };

  const openConfirmationDialog = (operation) => {
    setConfirmationDialog({
      open: true,
      operation,
      message: getConfirmationMessage(operation),
    });
  };

  /* ==========================================================================
   * INITIAL NAVIGATION DATA
   * ======================================================================== */

  const GetNavigationalData = useCallback(async () => {
    if (!resourceId) return;

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_NAVIGATIONAL_DATA}/${resourceId}`,
        "get"
      );

      if (response?.data) {
        if (!mountedRef.current) return;

        setNavigationalData(response.data);

        const gps = response.data?.gpsStatus;
        const fluxGate = response.data?.fluxGateStatus;

        setShowLocate(
          String(gps).toLowerCase() === "ok" &&
            String(fluxGate).toLowerCase() === "ok"
        );
      }
    } catch (error) {
      console.error("Failed to fetch ACU navigation data", error);
    } finally {
      if (mountedRef.current) {
        setLoading(false);
        setIsInitialLoading(false);
      }
    }
  }, [resourceId]);

  /* ==========================================================================
   * GET STATUS / POLLING
   * ======================================================================== */

  const GetStatus = useCallback(async () => {
    if (!resourceId || !mountedRef.current) return;

    try {
      const response = isCnms
        ? await ConfigurationAxios(
            `${ACU_GET_STATUS_CNMS}/${resourceId}`,
            "post",
            { siteId: siteId }
          )
        : await ConfigurationAxios(`${ACU_GET_STATUS}/${resourceId}`, "get");

      if (!mountedRef.current || !response?.data) return;

      const data = response.data;

      setNavigationalData(data);

      /*
       * Existing ACU completion condition:
       * winStatus = No Movement
       */
      if (
        antennaMovementRef.current &&
        String(data?.winStatus || "").toLowerCase() === "no movement"
      ) {
        setMovementStatus(false);
        setOperation("stop");

        setJog("");
        setSpeed("");
        setDuration("");

        setAutoMoveParam({
          azimuth: "",
          elevation: "",
        });

        setAutoMoveErr(false);
      }
    } catch (error) {
      console.error("Failed to fetch ACU status", error);
    }
  }, [resourceId, siteId, isCnms]);

  useEffect(() => {
    if (!resourceId) return;

    mountedRef.current = true;

    GetNavigationalData();

    return () => {
      mountedRef.current = false;
      stopPolling();

      antennaMovementRef.current = false;
      currentMovementRef.current = "stop";
    };
  }, [resourceId, GetNavigationalData, stopPolling]);

  /*
   * Preserve the original ACU polling intervals.
   */
  useEffect(() => {
    if (!resourceId) return;

    stopPolling();

    const interval = isCnms
      ? antennaMovement
        ? 10000
        : 60000
      : antennaMovement
      ? 2000
      : 10000;

    pollingRef.current = setInterval(() => {
      GetStatus();
    }, interval);

    return () => stopPolling();
  }, [antennaMovement, isCnms, resourceId, GetStatus, stopPolling]);

  /* ==========================================================================
   * GAUGE VALUE CHANGE HIGHLIGHT
   * ======================================================================== */

  useEffect(() => {
    if (navigationalData?.azimuth !== undefined) {
      setAzChange(true);

      const timer = setTimeout(() => setAzChange(false), 1000);

      return () => clearTimeout(timer);
    }
  }, [navigationalData?.azimuth]);

  useEffect(() => {
    if (navigationalData?.elevation !== undefined) {
      setElChange(true);

      const timer = setTimeout(() => setElChange(false), 1000);

      return () => clearTimeout(timer);
    }
  }, [navigationalData?.elevation]);

  useEffect(() => {
    if (navigationalData?.polarization !== undefined) {
      setPolChange(true);

      const timer = setTimeout(() => setPolChange(false), 1000);

      return () => clearTimeout(timer);
    }
  }, [navigationalData?.polarization]);

  /* ==========================================================================
   * STOP ANTENNA
   * ======================================================================== */

  const handleStop = async () => {
    if (!resourceId) return;

    setLoading(true);

    const previousMovement = currentMovementRef.current;

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_STOP}/${resourceId}`,
        "get"
      );

      if (response?.status === 200) {
        stopPolling();

        setMovementStatus(false);
        setOperation("stop");

        setJog("");
        setSpeed("");
        setDuration("");

        setAutoMoveParam({
          azimuth: "",
          elevation: "",
        });

        setAutoMoveErr(false);

        showMessage(
          previousMovement === "stop"
            ? "Antenna stopped"
            : `${previousMovement} operation stopped`,
          "success"
        );
      }
    } catch (error) {
      showMessage("Network Error!");
      setOperation("stop");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * JOG MOVEMENT
   * ======================================================================== */

  const handleMove = async () => {
    if (
      !resourceId ||
      antennaMovementRef.current ||
      !jog ||
      !speed ||
      !duration
    ) {
      return;
    }

    setLoading(true);

    const payload = {
      jogMovDirection: jog,
      jogMovSpeed: speed,
      jogMovDuration: duration,
    };

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_MOVE_JOG}/${resourceId}`,
        "post",
        { ...payload }
      );

      if (response?.status === 200) {
        setOperation("jogMove");
        setMovementStatus(true);
      }
    } catch (error) {
      setOperation("stop");
      setMovementStatus(false);

      showMessage("Network Error!");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * DEPLOY
   * ======================================================================== */

  const handleDeploy = async () => {
    if (!resourceId || antennaMovementRef.current) return;

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_DEPLOY}/${resourceId}`,
        "get"
      );

      if (response?.status === 200) {
        setOperation("deploy");
        setMovementStatus(true);
      }
    } catch (error) {
      setOperation("stop");
      setMovementStatus(false);

      showMessage("Network Error!");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * STOW
   * ======================================================================== */

  const handleStow = async () => {
    if (!resourceId || antennaMovementRef.current) return;

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_STOW}/${resourceId}`,
        "get"
      );

      if (response?.status === 200) {
        setOperation("stow");
        setMovementStatus(true);
      }
    } catch (error) {
      setOperation("stop");
      setMovementStatus(false);

      showMessage("Network Error!");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * LOCATE
   * ======================================================================== */

  const handleLocate = async () => {
    if (
      !resourceId ||
      antennaMovementRef.current ||
      !locateData.satelliteIndex ||
      !locateData.locatePolDirection
    ) {
      return;
    }

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_LOCATE}/${resourceId}`,
        "post",
        { ...locateData }
      );

      if (response?.status === 200) {
        setOperation("locate");
        setMovementStatus(true);
      }
    } catch (error) {
      setOperation("stop");
      setMovementStatus(false);

      showMessage("Network Error!");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * AUTO MOVE VALIDATION
   * ======================================================================== */

  const validateAutoMoveParams = (value) => {
    if (value === "" || value === null || value === undefined) {
      return false;
    }

    const number = Number(value);

    if (!Number.isFinite(number) || number < -180 || number > 180) {
      return false;
    }

    /*
     * Allow at most one decimal place.
     */
    return /^-?\d{1,3}(\.\d)?$/.test(String(value));
  };

  const handleAutoMoveChange = (key, value) => {
    setAutoMoveParam((prev) => ({
      ...prev,
      [key]: value,
    }));

    const updated = {
      ...autoMovParam,
      [key]: value,
    };

    setAutoMoveErr(
      !validateAutoMoveParams(updated.azimuth) ||
        !validateAutoMoveParams(updated.elevation)
    );
  };

  /* ==========================================================================
   * AUTO MOVE
   * ======================================================================== */

  const handleAutoMove = async () => {
    if (
      !resourceId ||
      antennaMovementRef.current ||
      !validateAutoMoveParams(autoMovParam.azimuth) ||
      !validateAutoMoveParams(autoMovParam.elevation)
    ) {
      setAutoMoveErr(true);
      return;
    }

    setLoading(true);

    const payload = {
      autoMovAz: Number(autoMovParam.azimuth).toFixed(1),
      autoMovEl: Number(autoMovParam.elevation).toFixed(1),
      autoMovPolDirection: autoMovParam.polarization,
    };

    try {
      const response = await ConfigurationAxios(
        `${ACU_AUTO_MOVE}/${resourceId}`,
        "post",
        { ...payload }
      );

      if (response?.status === 200) {
        setOperation("autoMove");
        setMovementStatus(true);

        setAutoMoveParam({
          azimuth: "",
          elevation: "",
        });

        setAutoMoveErr(false);
      }
    } catch (error) {
      setOperation("stop");
      setMovementStatus(false);

      showMessage("Network Error!");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * ANTENNA ALARM RESET
   * ======================================================================== */

  const handleReset = async () => {
    if (!resourceId || !resetValue || antennaMovementRef.current) {
      return;
    }

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${ACU_GET_ANTENNA_RESET}/${resourceId}`,
        "post",
        { antennaDriveReset: resetValue }
      );

      if (response?.status === 200) {
        const messages = {
          az: "Azimuth Drive Reset successful",
          el: "Elevation Drive Reset successful",
          pol: "Polarization Drive Reset successful",
        };

        showMessage(messages[resetValue], "success");
        setResetValue("");
      }
    } catch (error) {
      showMessage("Failed to perform Reset");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================================================================
   * CONFIRMATION HANDLER
   * ======================================================================== */

  const handleConfirmationYes = () => {
    const operation = confirmationDialog.operation;

    handleCloseConfirmation();

    switch (operation) {
      case "jogMove":
        handleMove();
        break;

      case "deploy":
        handleDeploy();
        break;

      case "stow":
        handleStow();
        break;

      case "locate":
        handleLocate();
        break;

      case "stop":
        handleStop();
        break;

      case "autoMove":
        handleAutoMove();
        break;

      default:
        break;
    }
  };

  /* ==========================================================================
   * STATUS HELPERS
   * ======================================================================== */

  const healthStatus = (status) => {
    const isOk = String(status || "").toLowerCase() === "ok";

    return (
      <Box
        sx={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          minWidth: 65,
          px: 1.5,
          py: 0.5,
          borderRadius: 1,
          fontSize: 12,
          fontWeight: 700,
          color: "#ffffff",
          backgroundColor: isOk ? "#15803d" : "#dc2626",
        }}
      >
        {isOk ? "OK" : "Not OK"}
      </Box>
    );
  };

  const isOperationRunning = antennaMovement;

  const statusBox = (label, value) => (
    <Box
      sx={{
        p: 1,
        mb: 1,
        borderRadius: 1,
        backgroundColor: colors.pageBg,
        border: `1px solid ${colors.border}`,
      }}
    >
      <Typography variant="body2" sx={{ color: colors.text }}>
        <b>{label}:</b> {value || "--"}
      </Typography>
    </Box>
  );

  /* ==========================================================================
   * GAUGE CARD
   * ======================================================================== */

  const renderGauge = (config, changed) => (
    <Box
      sx={{
        height: "100%",
        minHeight: 190,
        p: 1,
        border: `1px solid ${colors.border}`,
        borderRadius: 2,
        backgroundColor: colors.cardBg,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: "background-color 0.3s",
        background: changed ? (isDark ? "#263b50" : "#e3f2fd") : colors.cardBg,
      }}
    >
      {DialGaugeWidget && DialGaugeWidget(config)}
    </Box>
  );

  /* ==========================================================================
   * MOVEMENT CONTROL TAB
   * ======================================================================== */

  const renderMovementControl = () => (
    <Box>
      {/* Loading */}

      {loading && <LinearProgress sx={{ mb: 2 }} />}

      {/* ================================================================
       * POSITION GAUGES
       * ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid className="grid grid-cols-3 gap-2" spacing={2}>
          <Grid item xs={12} md={4}>
            {renderGauge(azimuthWidgetConfig, azChange)}
          </Grid>

          <Grid item xs={12} md={4}>
            {renderGauge(elevationWidgetConfig, elChange)}
          </Grid>

          <Grid item xs={12} md={4}>
            {renderGauge(polarizationWidgetConfig, polChange)}
          </Grid>
        </Grid>
      </Paper>

      {/* ================================================================
       * ANTENNA STATUS
       * ================================================================ */}
      <Box
        sx={{
          p: 1,
          mb: 1,
          borderRadius: 1.5,
          backgroundColor: isOperationRunning
            ? colors.warningBg
            : colors.successBg,
          border: `1px solid ${isOperationRunning ? "#fed7aa" : "#bbf7d0"}`,
        }}
      >
        <Typography
          fontWeight={700}
          sx={{
            color: isOperationRunning ? colors.warning : colors.success,
          }}
        >
          {isOperationRunning
            ? OPERATION_MESSAGES[currentMovement] ||
              "Antenna movement in progress"
            : "Antenna stationary"}
        </Typography>
      </Box>
      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
          display: "grid",
          gridTemplateColumns: "1fr 1.25fr",
          gap: "12px",
        }}
      >
        <Grid>
          {" "}
          <Grid spacing={2}>
            <Grid item xs={12} md={6}>
              {statusBox("Status Window", navigationalData?.winStatus)}

              {statusBox("Alarm Window", navigationalData?.alarmStatus)}
            </Grid>
          </Grid>
          <Grid
            spacing={2}
            alignItems="center"
            className="grid grid-cols-2 gap-2 mb-2"
          >
            <Grid item xs={12} md={8}>
              <MAlarmSelect
                label="Antenna Alarm Reset"
                value={resetValue}
                onChange={(value) => setResetValue(value)}
                options={[
                  {
                    value: "az",
                    label: "Azimuth Drive Reset",
                  },
                  {
                    value: "el",
                    label: "Elevation Drive Reset",
                  },
                  {
                    value: "pol",
                    label: "Polarization Drive Reset",
                  },
                ]}
                multiple={false}
                disabled={isOperationRunning || loading}
                isDark={isDark}
              />
            </Grid>

            <Grid item xs={12} md={4} mt={3}>
              <MButtonPrimary
                fullWidth
                variant="contained"
                disabled={!resetValue || isOperationRunning || loading}
                onClick={handleReset}
                startIcon={<RotateLeftRounded />}
                sx={{ height: 42, borderRadius: 2 }}
              >
                Reset
              </MButtonPrimary>
            </Grid>
          </Grid>
          {statusBox(
            "Alarm Movement Status",
            navigationalData?.alarmMovementStatus
          )}
          <Divider />
          {/* ==============================================================
           * LOCATE
           * ============================================================ */}
          <Grid item xs={12} md={5} mt={1}>
            <Paper
              elevation={0}
              sx={{
                p: 1,
                height: "100%",
                border: `1px solid ${colors.border}`,
                borderRadius: 2,
                backgroundColor: colors.paperBg,
              }}
            >
              <Typography
                variant="subtitle1"
                fontWeight={700}
                textAlign="center"
                sx={{ color: colors.heading, mb: 1 }}
              >
                Locate
              </Typography>

              <Divider sx={{ mb: 1 }} />
              <Grid className="grid grid-cols-2 gap-4">
                <Box>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{ color: colors.text }}
                  >
                    Satellite Prelist
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={locateData.satelliteIndex}
                    onChange={(value) =>
                      handleLocateChange("satelliteIndex", value)
                    }
                    options={satelliteOptions}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Box>

                <Box>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{ color: colors.text }}
                  >
                    Polarization
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={locateData.locatePolDirection}
                    onChange={(value) =>
                      handleLocateChange("locatePolDirection", value)
                    }
                    options={POLARIZATION_OPTIONS}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Box>
              </Grid>
              <Box sx={{ mt: 1, display: "flex", justifyContent: "center" }}>
                <MButtonPrimary
                  variant="contained"
                  fullWidth
                  disabled={
                    isOperationRunning ||
                    !locateData.satelliteIndex ||
                    !locateData.locatePolDirection ||
                    loading
                  }
                  onClick={() => openConfirmationDialog("locate")}
                  sx={{ height: 42, borderRadius: 2 }}
                  startIcon={<LocationOnRounded />}
                >
                  LOCATE
                </MButtonPrimary>
              </Box>
            </Paper>
          </Grid>
        </Grid>
        {/* ================================================================
         * MOVEMENT + LOCATE
         * ================================================================ */}

        <Grid container spacing={2}>
          {/* ==============================================================
           * JOG MOVEMENT
           * ============================================================ */}

          <Grid item xs={12} md={7}>
            <Paper
              elevation={0}
              sx={{
                p: 1,
                height: "100%",
                border: `1px solid ${colors.border}`,
                borderRadius: 2,
                backgroundColor: colors.paperBg,
              }}
            >
              <Grid spacing={2} className="grid grid-cols-4 gap-3">
                {/* JOG */}

                <Grid item xs={12} sm={6}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{ color: colors.text }}
                  >
                    Jog Direction
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={jog}
                    onChange={(value) => setJog(value)}
                    options={JOG_OPTIONS}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* SPEED */}

                <Grid item xs={12} sm={6}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{ color: colors.text }}
                  >
                    Speed
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={speed}
                    onChange={(value) => setSpeed(value)}
                    options={SPEED_OPTIONS}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* DURATION */}

                <Grid item xs={12} sm={6}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{ color: colors.text }}
                  >
                    Duration
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={duration}
                    onChange={(value) => setDuration(value)}
                    options={DURATION_OPTIONS}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* MOVE */}

                <Grid item xs={12} sm={6} display="flex" alignItems="end">
                  <MButtonPrimary
                    fullWidth
                    variant="contained"
                    disabled={
                      isOperationRunning ||
                      !jog ||
                      !speed ||
                      !duration ||
                      loading
                    }
                    onClick={() => openConfirmationDialog("jogMove")}
                    sx={{ height: 42, borderRadius: 2 }}
                    startIcon={<ControlCameraRounded />}
                  >
                    MOVE
                  </MButtonPrimary>
                </Grid>
              </Grid>

              {/* STOW / DEPLOY / STOP */}

              <Grid spacing={1} className="grid grid-cols-3 gap-2 mt-2">
                <MButtonPrimary
                  fullWidth
                  variant="contained"
                  disabled={isOperationRunning || loading}
                  onClick={() => openConfirmationDialog("stow")}
                  sx={{ height: 42, borderRadius: 2 }}
                >
                  STOW
                </MButtonPrimary>

                <MButtonPrimary
                  fullWidth
                  variant="contained"
                  disabled={isOperationRunning || loading}
                  onClick={() => openConfirmationDialog("deploy")}
                  sx={{ height: 42, borderRadius: 2 }}
                >
                  DEPLOY
                </MButtonPrimary>
                <MButtonPrimary
                  fullWidth
                  variant="contained"
                  disabled={loading}
                  onClick={() => openConfirmationDialog("stop")}
                  sx={{
                    height: 42,
                    borderRadius: 2,
                    backgroundColor: "#dc2626",
                    "&:hover": {
                      backgroundColor: "#b91c1c",
                    },
                  }}
                  startIcon={<PanToolRounded />}
                >
                  STOP
                </MButtonPrimary>
              </Grid>

              <Box sx={{ mt: 1 }}>
                {statusBox(
                  "Antenna Position",
                  navigationalData?.antennaPosition
                )}
                {statusBox("Beacon Level", navigationalData?.btrBeaconLevel)}
              </Box>
              {/* ==========================================================
               * AUTO MOVE
               * ======================================================== */}

              <Divider sx={{ my: 1 }} />

              <Typography
                variant="subtitle1"
                fontWeight={700}
                textAlign="center"
                sx={{ color: colors.heading }}
              >
                Auto Move
              </Typography>

              <Grid spacing={2} className="grid grid-cols-2 gap-3">
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    size="small"
                    variant="outlined"
                    label="Azimuth"
                    type="number"
                    value={autoMovParam.azimuth}
                    disabled={isOperationRunning || loading}
                    onChange={(e) =>
                      handleAutoMoveChange("azimuth", e.target.value)
                    }
                    placeholder="-180.0 to 180.0"
                    inputProps={{
                      step: 0.1,
                      min: -180,
                      max: 180,
                    }}
                    error={
                      autoMovParam.azimuth !== "" &&
                      !validateAutoMoveParams(autoMovParam.azimuth)
                    }
                    helperText={
                      autoMovParam.azimuth !== "" &&
                      !validateAutoMoveParams(autoMovParam.azimuth)
                        ? "Enter a value between -180.0 and 180.0 (one decimal place)"
                        : " "
                    }
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    size="small"
                    variant="outlined"
                    label="Elevation"
                    type="number"
                    value={autoMovParam.elevation}
                    disabled={isOperationRunning || loading}
                    onChange={(e) =>
                      handleAutoMoveChange("elevation", e.target.value)
                    }
                    placeholder="-180.0 to 180.0"
                    inputProps={{
                      step: 0.1,
                      min: -180,
                      max: 180,
                    }}
                    error={
                      autoMovParam.elevation !== "" &&
                      !validateAutoMoveParams(autoMovParam.elevation)
                    }
                    helperText={
                      autoMovParam.elevation !== "" &&
                      !validateAutoMoveParams(autoMovParam.elevation)
                        ? "Enter a value between -180.0 and 180.0 (one decimal place)"
                        : " "
                    }
                  />
                </Grid>
              </Grid>
              <Grid item xs={12} align="center" mt={1}>
                <MButtonPrimary
                  fullWidth
                  variant="contained"
                  disabled={
                    isOperationRunning ||
                    loading ||
                    !validateAutoMoveParams(autoMovParam.azimuth) ||
                    !validateAutoMoveParams(autoMovParam.elevation) ||
                    autoMoveErr
                  }
                  onClick={() => openConfirmationDialog("autoMove")}
                  sx={{ height: 42, borderRadius: 2 }}
                >
                  AUTO MOVE
                </MButtonPrimary>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Paper>

      {/* ================================================================
       * CHASSIS VIEW
       * ================================================================ */}

      {/* <Paper
        elevation={0}
        sx={{
          mt: 2,
          p: 2,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography fontWeight={700} sx={{ color: colors.heading }}>
            Chassis View
          </Typography>

          <Switch
            checked={showChassis}
            size="small"
            color="primary"
            onChange={(e) => setShowChassis(e.target.checked)}
          />
        </Box>

        {showChassis && (
          <Box sx={{ mt: 2 }}>
            <ChassisView
              deviceID={deviceID}
              device="acu"
              resource={resource}
              title="Antenna Control Unit"
              // src="../../../../chassisView/acu.svg"
            />
          </Box>
        )}
      </Paper> */}
    </Box>
  );

  /* ==========================================================================
   * SATELLITE DATA TAB
   *
   * Existing component reused for now.
   * We will convert this separately into reusable components.
   * ======================================================================== */

  const renderSatelliteData = () => (
    <Box
      sx={{
        p: 1,
        borderRadius: 2,
        border: `1px solid ${colors.border}`,
        backgroundColor: colors.paperBg,
      }}
    >
      <AcuConfigurationSatelliteTable
        resource={resource}
        deviceID={deviceID}
        showSnackBar={showMessage}
        isDark={isDark}
      />
    </Box>
  );

  /* ==========================================================================
   * MAIN RENDER
   * ======================================================================== */

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: colors.pageBg,
        color: colors.heading,
        minHeight: "100%",
      }}
    >
      {/* INITIAL LOADING */}

      {isInitialLoading ? (
        <Box
          sx={{
            minHeight: 350,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: colors.paperBg,
            borderRadius: 2,
          }}
        >
          <CircularProgress size={40} />

          <Typography sx={{ ml: 2, color: colors.heading }}>
            Loading ACU Configuration...
          </Typography>
        </Box>
      ) : (
        <>
          {/* ============================================================
           * TAB BUTTONS
           * ========================================================== */}

          <Paper
            elevation={0}
            sx={{
              p: 1,
              mb: 1,
              display: "flex",
              gap: 1,
              flexWrap: "wrap",
              border: `1px solid ${colors.border}`,
              borderRadius: 2,
              backgroundColor: colors.paperBg,
            }}
          >
            {TABS.map((tab) => (
              <MButtonPrimary
                key={tab.value}
                variant={activeTab === tab.value ? "contained" : "outlined"}
                color="primary"
                onClick={() => setActiveTab(tab.value)}
                sx={{
                  minWidth: 170,
                  borderRadius: 2,
                  height: 42,
                }}
              >
                {tab.label}
              </MButtonPrimary>
            ))}
          </Paper>

          {/* ============================================================
           * SELECTED TAB
           * ========================================================== */}

          {activeTab === "MOVEMENT CONTROL" && renderMovementControl()}

          {activeTab === "SATELLITE DATA" && renderSatelliteData()}
        </>
      )}

      {/* ================================================================
       * CONFIRMATION DIALOG
       * ================================================================ */}

      <MDialog
        open={confirmationDialog.open}
        title="Confirm Operation"
        message={confirmationDialog.message}
        onConfirm={handleConfirmationYes}
        onClose={handleCloseConfirmation}
        variant="warning"
        icon={Confirmation_icon}
        mode="parent"
      />
      <MDialog
        open={openConfigDialog}
        onClose={() => setOpenConfigDialog(false)}
        onConfirm={() => setOpenConfigDialog(false)}
        title="Information"
        message={
          <>
            Ensure the Antenna top cover is removed physically, before
            initiating any configuration menu.
          </>
        }
        confirmText="OK"
        showButtons={false}
        variant="primary"
        icon={Confirmation_icon}
      >
        <Grid align="center">
          {" "}
          <MButtonPrimary
            fullWidth
            variant="contained"
            onClick={() => setOpenConfigDialog(false)}
            sx={{ height: 42, borderRadius: 2 }}
          >
            OK
          </MButtonPrimary>
        </Grid>
      </MDialog>
    </Box>
  );
};

export default AcuConfigurationMK;
