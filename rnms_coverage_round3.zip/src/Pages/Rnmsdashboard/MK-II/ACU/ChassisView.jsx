import React from 'react'

const ChassisView = () => {
  return (
    <div>
      Chassis View
    </div>
  )
}

export default ChassisView
