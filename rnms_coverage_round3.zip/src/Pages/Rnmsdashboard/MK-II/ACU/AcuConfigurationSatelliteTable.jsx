import React, { useState, useCallback } from "react";

import {
  Box,
  Grid,
  Paper,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  LinearProgress,
  Button,
} from "@mui/material";

import Toast from "@/components/Reusable/Toast/Toast";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_SATELLITE_DATA,
  SAVE_SATELLITE_DATA,
} from "@/RestAPI/url/endpoint";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

// Replace these with your actual endpoint constant names.

// If your project has a reusable button, use that instead.

const bandMap = {
  0: "C",
  1: "Ku",
  2: "C/Ku",
  3: "L",
  4: "X",
  5: "Ka",
  6: "S",
};

const initialData = {
  rwSatName: "",
  rwSatLong: "",
  rwSatBand: "0",
  rwSatLongDirection: "E",
  rwSatInclination: "",
  rwSatPolOffset: "",
  rwSatEphem: "0",
  rwSatPolOffsetDirection: "CW",
};

const AcuConfigurationSatelliteTable = ({ resource, resourceId, isDark}) => {
  const [index, setIndex] = useState("");

  const [data, setData] = useState(initialData);

  const [error, setError] = useState({});

  const [loading, setLoading] = useState(false);

  const [saving, setSaving] = useState(false);

  /* =========================================================
     FETCH SATELLITE DATA
  ========================================================= */
  const satelliteIndexOptions = Array.from({ length: 20 }, (_, i) => ({
    value: String(i + 1),
    label: String(i + 1),
  }));

  const bandOptions = Object.entries(bandMap).map(([value, label]) => ({
    value,
    label,
  }));

  const longitudeDirectionOptions = [
    { value: "E", label: "East" },
    { value: "W", label: "West" },
  ];

  const ephemOptions = [
    { value: "0", label: "None" },
    { value: "1", label: "TLE" },
    { value: "2", label: "IESS-412" },
  ];

  const polarizationDirectionOptions = [
    { value: "CW", label: "CW" },
    { value: "CCW", label: "CCW" },
  ];
  const handleChangeIndex = useCallback(
    async (event) => {
      const selectedIndex = event.target.value;

      setIndex(selectedIndex);
      setLoading(true);
      setError({});

      try {
        const response = await ConfigurationAxios(
          `${GET_SATELLITE_DATA}/${resourceId || resource?.resourceId}`,
          "post",
          {
            rwSatIndex: selectedIndex,
          }
        );

        const result = response?.data;

        if (result?.status) {
          const satelliteData = result.data;

          setData({
            ...initialData,
            ...satelliteData,
            rwSatIndex: selectedIndex,
          });
        } else {
          setData({
            ...initialData,
            rwSatIndex: selectedIndex,
          });

          Toast(
            "Error",
            result?.message || "Failed to fetch satellite data",
            "error"
          );
        }
      } catch (err) {
        Toast(
          "Error",
          err?.message || "Failed to fetch satellite data",
          "error"
        );
      } finally {
        setLoading(false);
      }
    },
    [resourceId, resource]
  );

  /* =========================================================
     FIELD CHANGE
  ========================================================= */

  const handleDataChange = (event, key) => {
    const value = event.target.value;

    setData((prev) => ({
      ...prev,
      [key]: value,
    }));

    setError((prev) => ({
      ...prev,
      [key]: "",
    }));
  };

  /* =========================================================
     VALIDATION
  ========================================================= */

  const validateForm = () => {
    const errors = {};

    if (!data.rwSatName?.trim()) {
      errors.rwSatName = "Enter satellite name";
    }

    if (
      data.rwSatLong === "" ||
      Number(data.rwSatLong) < 0 ||
      Number(data.rwSatLong) > 179.9
    ) {
      errors.rwSatLong = "Longitude should be 0-179.9";
    }

    if (
      data.rwSatInclination === "" ||
      Number(data.rwSatInclination) < 0 ||
      Number(data.rwSatInclination) > 19
    ) {
      errors.rwSatInclination = "Inclination should be 0-19";
    }

    if (
      data.rwSatPolOffset === "" ||
      Number(data.rwSatPolOffset) < 0 ||
      Number(data.rwSatPolOffset) > 90
    ) {
      errors.rwSatPolOffset = "Poll offset should be 0-90";
    }

    setError(errors);

    return Object.keys(errors).length === 0;
  };

  /* =========================================================
     SAVE SATELLITE DATA
  ========================================================= */

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    if (!index) {
      Toast("Error", "Please select satellite index", "error");
      return;
    }

    setSaving(true);

    try {
      const response = await ConfigurationAxios(
        `${SAVE_SATELLITE_DATA}/${resourceId || resource?.resourceId}`,
        "post",
        {
          ...data,
          rwSatIndex: index,
        }
      );

      if (response?.data?.status) {
        Toast(
          "Success",
          response?.data?.message || "Satellite data saved successfully",
          "success"
        );
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to save satellite data",
          "error"
        );
      }
    } catch (err) {
      Toast("Error", err?.message || "Failed to save satellite data", "error");
    } finally {
      setSaving(false);
    }
  };
  const handleChangeIndexValue = (value) => {
    handleChangeIndex({
      target: {
        value: String(value),
      },
    });
  };

  /* =========================================================
     REUSABLE SELECT FIELD
  ========================================================= */

  const renderSelect = (label, key, options, onChange) => (
    <MAlarmSelect
      label={label}
      value={data[key] ?? ""}
      onChange={(value) => {
        if (onChange) {
          onChange(value);
        } else {
          handleDataChange({ target: { value } }, key);
        }
      }}
      options={options}
      multiple={false}
      disabled={loading || saving}
      isDark={isDark}
    />
  );

  /* =========================================================
     REUSABLE TEXT FIELD
  ========================================================= */

  const renderTextField = ({
    label,
    key,
    type = "text",
    placeholder,
    maxLength,
  }) => (
    <TextField
      fullWidth
      size="small"
      variant="outlined"
      label={label}
      type={type}
      placeholder={placeholder}
      value={data[key] ?? ""}
      error={Boolean(error[key])}
      helperText={error[key] || " "}
      onChange={(e) => {
        let value = e.target.value;

        if (maxLength) {
          value = value.slice(0, maxLength);
        }

        handleDataChange({ target: { value } }, key);
      }}
      inputProps={{
        maxLength,
        min: 0,
      }}
    />
  );

  /* =========================================================
     RENDER
  ========================================================= */

  return (
    <Paper
      elevation={0}
      sx={{
        p: 1,
        borderRadius: 2,
        border: "1px solid",
        borderColor: "divider",
        bgcolor: "background.paper",
      }}
    >
      {loading && <LinearProgress sx={{ mb: 2 }} />}

      {/* SATELLITE INDEX */}

      <Grid item xs={12} sm={6} md={3}>
        <MAlarmSelect
          label="Satellite Index"
          value={index}
          onChange={handleChangeIndexValue}
          options={satelliteIndexOptions}
          multiple={false}
          disabled={loading || saving}
          isDark={isDark}
        />
      </Grid>
      <Grid spacing={2} className="grid grid-cols-4 gap-3 mt-2">
        {/* SATELLITE NAME */}

        <Grid item xs={12} sm={6} md={3} mt={2.7}>
          {renderTextField({
            label: "Satellite Name",
            key: "rwSatName",
            placeholder: "10 Characters",
            maxLength: 10,
          })}
        </Grid>

        {/* LONGITUDE */}

        <Grid item xs={12} sm={6} md={3} mt={2.7}>
          {renderTextField({
            label: "Longitude",
            key: "rwSatLong",
            type: "number",
            placeholder: "0-179.9",
          })}
        </Grid>

        {/* BAND */}

        <Grid item xs={12} sm={6} md={3}>
          {renderSelect("Band", "rwSatBand", bandOptions)}
        </Grid>

        {/* LONGITUDE DIRECTION */}

        <Grid item xs={12} sm={6} md={3}>
          {renderSelect(
            "Direction",
            "rwSatLongDirection",
            longitudeDirectionOptions
          )}
        </Grid>

        {/* INCLINATION */}

        <Grid item xs={12} sm={6} md={3} mt={2.7}>
          {renderTextField({
            label: "Inclination",
            key: "rwSatInclination",
            type: "number",
            placeholder: "0-19",
          })}
        </Grid>

        {/* POLARIZATION OFFSET */}

        <Grid item xs={12} sm={6} md={3} mt={2.7}>
          {renderTextField({
            label: "Poll Offset",
            key: "rwSatPolOffset",
            type: "number",
            placeholder: "0-90",
          })}
        </Grid>

        {/* EPHEMERIS */}

        <Grid item xs={12} sm={6} md={3}>
          {renderSelect("Ephem", "rwSatEphem", ephemOptions)}
        </Grid>

        {/* POLARIZATION DIRECTION */}

        <Grid item xs={12} sm={6} md={3}>
          {renderSelect(
            "Direction",
            "rwSatPolOffsetDirection",
            polarizationDirectionOptions
          )}
        </Grid>

        {/* SAVE BUTTON */}

      </Grid>
        <Grid
          item
          xs={12}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent:'center'
          }}
        >
          <MButtonPrimary
            variant="contained"
            color="primary"
            onClick={handleSave}

            disabled={saving || loading || !index}
          >
            {saving ? "Saving..." : "SAVE"}
          </MButtonPrimary>
        </Grid>
    </Paper>
  );
};

export default AcuConfigurationSatelliteTable;
