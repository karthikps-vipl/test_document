import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Box,
  Typography,
  Grid,
  Paper,
  TextField,
  CircularProgress,
  LinearProgress,
  useTheme,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";
import Toast from "@/components/Reusable/Toast/Toast";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  ACU_GET_ALL_SYSTEM_STATUS,
  ACU_GET_ALL_SYSTEM_STATUS_CNMS,
} from "@/RestAPI/url/endpoint";
//   import { LAST_RECEIVED_DATE } from "@/Redux/ActionTypes";

/* ============================================================================
 * THEME COLORS
 * (You can extract this to ./acuColors.js and import it in both
 *  AcuConfiguration and AcuStatusMK to avoid duplication.)
 * ========================================================================== */

const getAcuColors = (isDark) => ({
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  cardBg: isDark ? "#252525" : "#ffffff",

  border: isDark ? "#3a3a3a" : "#e0e0e0",
  innerBorder: isDark ? "#404040" : "#e5e7eb",

  heading: isDark ? "#f3f4f6" : "#1f2937",
  text: isDark ? "#9ca3af" : "#4b5563",
  muted: isDark ? "#6b7280" : "#9ca3af",

  successBg: isDark ? "#14291e" : "#f0fdf4",
  successBorder: isDark ? "#285b3b" : "#bbf7d0",
  successText: isDark ? "#86efac" : "#15803d",

  dangerBg: isDark ? "#2a1515" : "#fef2f2",
  dangerBorder: isDark ? "#7f1d1d" : "#fecaca",
  dangerText: isDark ? "#fca5a5" : "#b91c1c",
});

/* ============================================================================
 * SMALL REUSABLE PRESENTATION HELPERS
 * ========================================================================== */

const StatusBadge = ({ status, colors }) => {
  if (status === null || status === undefined || status === "") {
    return (
      <Typography variant="body2" sx={{ color: colors.muted }}>
        --
      </Typography>
    );
  }

  const ok = String(status).toLowerCase() === "ok";

  return (
    <Box
      sx={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        minWidth: 64,
        height: 26,
        px: 1,
        borderRadius: 1,
        fontWeight: 700,
        fontSize: 12,
        backgroundColor: ok ? colors.successBg : colors.dangerBg,
        border: `1px solid ${ok ? colors.successBorder : colors.dangerBorder}`,
        color: ok ? colors.successText : colors.dangerText,
      }}
    >
      {ok ? "OK" : "Not OK"}
    </Box>
  );
};

const InfoRow = ({ label, children, colors, labelWidth = 120 }) => (
  <Box sx={{ display: "flex", alignItems: "center", gap: 1, py: 0.75 }}>
    <Typography
      variant="body2"
      sx={{ minWidth: labelWidth, fontWeight: 700, color: colors.text }}
    >
      {label}
    </Typography>
    <Box sx={{ color: colors.heading, fontSize: 14, fontWeight: 500 }}>
      {children ?? "--"}
    </Box>
  </Box>
);

const formatCoordinate = (degree, minute, direction) => {
  if (degree === null || degree === undefined || degree === "") {
    return "- -";
  }
  return `${degree}.${minute ?? ""} ${direction ?? ""}`.trim();
};

/* ============================================================================
 * COMPONENT
 * ========================================================================== */

const AcuStatusMK = ({ node }) => {
  const resId = node?.resourceId;
  const siteId = node?.siteId;
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const colors = getAcuColors(isDark);
  const dispatch = useDispatch();

  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  /* ==========================================================================
   * STATE
   * ======================================================================== */

  const [allSystemStatus, setAllSystemStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  /* ==========================================================================
   * REFS
   * ======================================================================== */

  const isMountedRef = useRef(false);
  const pollIntervalRef = useRef(null);

  /* ==========================================================================
   * MOUNT / UNMOUNT
   * ======================================================================== */

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  /*
   * Same behaviour as old code:
   * clear LAST_RECEIVED_DATE when the status panel unmounts.
   */
  // useEffect(() => {
  //   return () => {
  //     dispatch({ type: LAST_RECEIVED_DATE, payload: null });
  //   };
  // }, [dispatch]);

  /* ==========================================================================
   * FETCH ALL SYSTEM STATUS
   *
   * Keeps the old parsing logic:
   * - CNMS  -> data.value is a JSON string
   * - non-CNMS -> data is either an object or a JSON string
   * - status === 7 -> warning toast, still show data
   * ======================================================================== */

  const fetchAllSystemStatus = useCallback(async () => {
    if (!resId || !isMountedRef.current) return;

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${
          isCnms ? ACU_GET_ALL_SYSTEM_STATUS_CNMS : ACU_GET_ALL_SYSTEM_STATUS
        }/${resId}`,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : {}
      );

      if (!isMountedRef.current) return;

      const res = response?.data;

      if (res) {
        const { data, message, status } = res;

        if (status) {
          // dispatch({
          //   type: LAST_RECEIVED_DATE,
          //   payload: data?.readingTime
          //     ? moment(data.readingTime).format("DD-MM-YYYY HH:mm:ss")
          //     : "- -",
          // });

          let parsed = null;

          if (isCnms) {
            const raw = data?.value;
            try {
              parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
            } catch {
              parsed = null;
            }
          } else {
            try {
              parsed = typeof data === "string" ? JSON.parse(data) : data;
            } catch {
              parsed = null;
            }
          }

          if (parsed) {
            setAllSystemStatus(parsed);
          }

          if (status === 7) {
            Toast("Error", message || "ACU status warning", "error");
          }
        } else {
          Toast("Error", message || "Failed to fetch ACU status", "error");
        }
      }
    } catch (error) {
      if (!isMountedRef.current) return;
      Toast("Error", error?.message || "Network Error!", "error");
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
        setIsInitialLoading(false);
      }
    }
  }, [resId, siteId, isCnms, dispatch]);

  /* ==========================================================================
   * POLLING
   *
   * Same intervals as old panel:
   * - CNMS: 60s
   * - non-CNMS: 30s
   * ======================================================================== */

  useEffect(() => {
    if (!resId) return;

    fetchAllSystemStatus();

    pollIntervalRef.current = setInterval(
      fetchAllSystemStatus,
      isCnms ? 60000 : 30000
    );

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
        pollIntervalRef.current = null;
      }
    };
  }, [resId, isCnms, fetchAllSystemStatus]);

  /* ==========================================================================
   * GAUGE CONFIGS
   *
   * Old CustomGauge used azimuth/elevation/polarization + 180.
   * The MK-III dial gauge takes min/max + currentValue, so we feed
   * the raw values and set the ranges here.
   * ======================================================================== */

  const azimuthWidgetConfig = useMemo(
    () => ({
      gridTitle: "Azimuth",
      minVal: -180,
      maxVal: 180,
      unit: "Degree",
      innerRange: 10,
      data: [{ currentValue: Number(allSystemStatus?.azimuth) || 0 }],
    }),
    [allSystemStatus?.azimuth]
  );

  const elevationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Elevation",
      minVal: -75,
      maxVal: 95,
      unit: "Degree",
      innerRange: 10,
      data: [{ currentValue: Number(allSystemStatus?.elevation) || 0 }],
    }),
    [allSystemStatus?.elevation]
  );

  const polarizationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Polarization",
      minVal: -100,
      maxVal: 100,
      unit: "Degree",
      innerRange: 10,
      data: [{ currentValue: Number(allSystemStatus?.polarization) || 0 }],
    }),
    [allSystemStatus?.polarization]
  );

  const gaugeItems = useMemo(
    () => [
      {
        key: "azimuth",
        config: azimuthWidgetConfig,
        label: `Az = ${allSystemStatus?.azimuth ?? "NA"}°`,
      },
      {
        key: "elevation",
        config: elevationWidgetConfig,
        label: `EL = ${allSystemStatus?.elevation ?? "NA"}°`,
      },
      {
        key: "polarization",
        config: polarizationWidgetConfig,
        label: `POL = ${allSystemStatus?.polarization ?? "NA"}° ${
          allSystemStatus?.polDirection ?? ""
        }`.trim(),
      },
    ],
    [
      azimuthWidgetConfig,
      elevationWidgetConfig,
      polarizationWidgetConfig,
      allSystemStatus?.azimuth,
      allSystemStatus?.elevation,
      allSystemStatus?.polarization,
      allSystemStatus?.polDirection,
    ]
  );

  /* ==========================================================================
   * INITIAL LOADING
   * ======================================================================== */

  if (isInitialLoading) {
    return (
      <Box sx={{ p: 1, backgroundColor: colors.pageBg }}>
        <Paper
          elevation={0}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            minHeight: 400,
            borderRadius: 2,
            border: `1px solid ${colors.border}`,
            backgroundColor: colors.paperBg,
          }}
        >
          <CircularProgress size={45} />
          <Typography variant="body1" sx={{ ml: 2, color: colors.heading }}>
            Loading ACU Status...
          </Typography>
        </Paper>
      </Box>
    );
  }

  /* ==========================================================================
   * RENDER
   * ======================================================================== */

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: colors.pageBg,
        color: colors.heading,
      }}
    >
      {/* Polling progress (only after first load) */}
      {loading && <LinearProgress sx={{ mb: 1 }} />}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          mb: 1,
          gap: 1,
        }}
      >
        <Typography
          variant="body2"
          sx={{
            color: colors.text,
            fontWeight: 600,
          }}
        >
          Last Received:
        </Typography>

        <Typography
          variant="body2"
          sx={{
            color: colors.heading,
            fontWeight: 700,
          }}
        >
          {allSystemStatus?.readingTime
            ? moment(allSystemStatus.readingTime).format("DD-MM-YYYY HH:mm:ss")
            : "---"}
        </Typography>
      </Box>
      {/* ==================================================================
       * GAUGES
       * ================================================================ */}
      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", md: "repeat(3, 1fr)" },
            gap: "15px",
          }}
        >
          {gaugeItems.map((item) => (
            <Box
              key={item.key}
              sx={{
                height: "100%",
                border: `1px solid ${colors.innerBorder}`,
                borderRadius: 2,
                p: 1,
                backgroundColor: colors.cardBg,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {DialGaugeWidget && DialGaugeWidget(item.config)}
              <Typography
                variant="caption"
                sx={{
                  mt: 0,
                  fontWeight: 600,
                  color: colors.text,
                  textAlign: "center",
                }}
              >
                {item.label}
              </Typography>
            </Box>
          ))}
        </Grid>
      </Paper>

      {/* ==================================================================
       * DEVICE INFORMATION
       * ================================================================ */}
      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", md: "repeat(3, 1fr)" },
            gap: "15px",
          }}
        >
          <TextField
            label="Device"
            size="small"
            variant="outlined"
            fullWidth
            value={allSystemStatus?.systemName ?? "--"}
            InputProps={{ readOnly: true }}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="Make"
            size="small"
            variant="outlined"
            fullWidth
            value={allSystemStatus?.deviceMake ?? "--"}
            InputProps={{ readOnly: true }}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="Version"
            size="small"
            variant="outlined"
            fullWidth
            value={allSystemStatus?.deviceVersion ?? "--"}
            InputProps={{ readOnly: true }}
            InputLabelProps={{ shrink: true }}
          />
        </Grid>
      </Paper>

      {/* ==================================================================
       * POSITION / SENSORS  +  VEHICLE / SIGNAL
       * ================================================================ */}
      <Paper
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "repeat(2, 1fr)" },
          gap: "10px",
          p: "10px",
          mb: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        {/* --------------------------------------------------------------
         * LEFT: POSITION & SENSORS
         * ------------------------------------------------------------ */}
        <Paper
          elevation={0}
          sx={{
            p: 1,
            borderRadius: 2,
            border: `1px solid ${colors.innerBorder}`,
            backgroundColor: colors.cardBg,
          }}
        >
          {/* <Typography
            variant="subtitle1"
            fontWeight={700}
            sx={{ mb: 1, color: colors.heading }}
          >
            Position &amp; Sensors
          </Typography> */}

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "4px 16px",
            }}
          >
            <InfoRow label="GPS:" colors={colors}>
              <StatusBadge
                status={allSystemStatus?.gpsStatus}
                colors={colors}
              />
            </InfoRow>

            <InfoRow label="Flux Gate:" colors={colors}>
              <StatusBadge
                status={allSystemStatus?.fluxGateStatus}
                colors={colors}
              />
            </InfoRow>

            <InfoRow label="Lat:" colors={colors}>
              {formatCoordinate(
                allSystemStatus?.latDegree,
                allSystemStatus?.latMinute,
                allSystemStatus?.latDirection
              )}
            </InfoRow>

            <InfoRow label="Long:" colors={colors}>
              {formatCoordinate(
                allSystemStatus?.lngDegree,
                allSystemStatus?.lngMinute,
                allSystemStatus?.lngDirection
              )}
            </InfoRow>

            <Box sx={{ gridColumn: "1 / -1" }}>
              <InfoRow label="Source:" colors={colors}>
                {allSystemStatus?.latLngSrc ?? "--"}
              </InfoRow>
            </Box>

            <Box sx={{ gridColumn: "1 / -1" }}>
              <InfoRow label="Satellite Name:" colors={colors}>
                {allSystemStatus?.satName ?? "--"}
              </InfoRow>
            </Box>
          </Box>
        </Paper>

        {/* --------------------------------------------------------------
         * RIGHT: VEHICLE & SIGNAL
         * ------------------------------------------------------------ */}
        <Paper
          elevation={0}
          sx={{
            p: 1,
            borderRadius: 2,
            //   border: `1px solid ${colors.innerBorder}`,
            backgroundColor: colors.cardBg,
          }}
        >
          {/* <Typography
              variant="subtitle1"
              fontWeight={700}
              sx={{ mb: 1, color: colors.heading }}
            >
              Vehicle &amp; Signal
            </Typography> */}

          <Grid sx={{ backgroundColor: colors.border, p: "2px 10px" }}>
            <InfoRow label="Vehicle Heading:" colors={colors}>
              {allSystemStatus?.vehicleHeading ?? "--"}
            </InfoRow>
          </Grid>
          <Grid sx={{ backgroundColor: colors.border, p: "2px 10px", mt: 1 }}>
            <InfoRow label="Vehicle Heading Src:" colors={colors}>
              {allSystemStatus?.vehicleHeadingSource ?? "--"}
            </InfoRow>
          </Grid>

          <Grid
            sx={{
              mt: 2,
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "15px",
            }}
          >
            <TextField
              label="AGC Channel"
              size="small"
              variant="outlined"
              fullWidth
              value={
                allSystemStatus
                  ? allSystemStatus?.agcChannel !== null &&
                    allSystemStatus?.agcChannel !== undefined
                    ? allSystemStatus.agcChannel
                    : "SS"
                  : "SS"
              }
              InputProps={{ readOnly: true }}
              InputLabelProps={{ shrink: true }}
            />

            <TextField
              label="AGC value"
              size="small"
              variant="outlined"
              fullWidth
              value={allSystemStatus?.agcSignalLevel ?? "--"}
              InputProps={{ readOnly: true }}
              InputLabelProps={{ shrink: true }}
            />

            <TextField
              label="Beacon"
              size="small"
              variant="outlined"
              fullWidth
              value={allSystemStatus?.btrBeaconLevel ?? "--"}
              InputProps={{ readOnly: true }}
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
        </Paper>
      </Paper>

      {/* ==================================================================
       * STATUS / ALARM / ANTENNA POSITION
       * ================================================================ */}
      <Paper
        elevation={0}
        sx={{
          p: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", md: "repeat(2, 1fr)" },
            gap: "4px 16px",
          }}
        >
          <Grid sx={{ backgroundColor: colors.border, p: "2px 10px", mt: 1 }}>
            <InfoRow label="Status Window:" colors={colors}>
              {allSystemStatus?.winStatus ?? "--"}
            </InfoRow>
          </Grid>
          <Grid sx={{ backgroundColor: colors.border, p: "2px 10px", mt: 1 }}>
            <InfoRow label="Alarm Window:" colors={colors}>
              {allSystemStatus?.alarmStatus ?? "--"}
            </InfoRow>
          </Grid>

          <Box
            sx={{
              gridColumn: "1 / -1",
              backgroundColor: colors.border,
              p: "2px 10px",
              mt: 1,
            }}
          >
            <InfoRow label="Antenna Position:" colors={colors}>
              {allSystemStatus?.antennaPosition ?? "--"}
            </InfoRow>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default AcuStatusMK;
