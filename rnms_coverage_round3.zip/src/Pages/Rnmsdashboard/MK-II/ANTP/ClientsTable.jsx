import React, { useCallback, useEffect, useRef, useState } from "react";

import { Box, Typography, LinearProgress } from "@mui/material";

import { useDispatch, useSelector } from "react-redux";


import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_LOS_RADIO_CLIENT_TABLE,
  FETCH_LOS_RADIO_CLIENT_TABLE_CNMS,
} from "@/RestAPI/url/endpoint";
import MTable from "@/components/Reusable/Table/MTable";
import Toast from "@/components/Reusable/Toast/Toast";


const ClientsTable = ({ resource, resourceId, siteId }) => {
  const dispatch = useDispatch();

  const isCnms = useSelector((state) => state.nodeDetails?.isCnms);

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  const isMountedRef = useRef(false);
  const intervalRef = useRef(null);
  const requestInProgressRef = useRef(false);

  /* =========================================================
       TABLE COLUMNS
    ========================================================= */

  const columns = [
    {
      name: "S.No.",
      uid: "index",
    },
    {
      name: "Client MAC Address",
      uid: "clientMACAddress",
    },
    {
      name: "SNR (dB)",
      uid: "snr",
    },
    {
      name: "Noise in the Link (dBm)",
      uid: "noiseInLink",
    },
    {
      name: "Rx Level (dBm)",
      uid: "signalRxLevel",
    },
    {
      name: "Signal Quality",
      uid: "signalQuality",
    },
  ];

  const getSignalQuality = (value, withinThreshold) => {
    if (value === null || value === undefined || value === "") {
      return "--";
    }

    const percentage = Math.min(100, Math.max(0, Number(value) || 0));

    const isWithinThreshold =
      withinThreshold === true || String(withinThreshold) === "true";
      const qualityLabel = isWithinThreshold ? "Good" : "Fair";
      const color_progress = isWithinThreshold ? "success" : "error";
    return (
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          gap: 1,
          minWidth: 150,
        }}
      >
        <Box sx={{ width: "55%" }}>
          <LinearProgress
            variant="determinate"
            value={percentage}
            color={color_progress}
            sx={{
              height: 12,
              borderRadius: 2,
            }}
          />
        </Box>

        <Typography
          variant="body2"
          sx={{
            minWidth: 40,
            textAlign: "right",
          }}
        >
          {qualityLabel}%
        </Typography>
      </Box>
    );
  };

  /* =========================================================
       TRANSFORM TABLE DATA
    ========================================================= */

  const fillTable = (data) => {
    if (!Array.isArray(data)) {
      setRows([]);
      return;
    }

    const rowData = data.map((item, index) => ({
      ...item,

      index: index + 1,

      clientMACAddress: item.clientMACAddress ?? "--",

      snr: item.snr ?? "--",

      noiseInLink: item.noiseInLink ?? "--",

      signalRxLevel: item.signalRxLevel ?? "--",

      signalQuality: getSignalQuality(
        item.signalQuality,
        item.signalQualityWithinThreshold
      ),
    }));

    setRows(rowData);
  };

  /* =========================================================
       FETCH CLIENT TABLE DATA
    ========================================================= */

  const fetchTableData = useCallback(async () => {
    if (!isMountedRef.current || requestInProgressRef.current) {
      return;
    }

    requestInProgressRef.current = true;
    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        isCnms
          ? `${FETCH_LOS_RADIO_CLIENT_TABLE_CNMS}/${resourceId}`
          : FETCH_LOS_RADIO_CLIENT_TABLE,

        isCnms ? "post" : "get",

        isCnms ? { siteId: String(siteId) } : {}
      );

      if (!isMountedRef.current) return;

      const result = response?.data;

      if (!result) {
        Toast("Error", "Failed to fetch client table data", "error");
        return;
      }

      const { data, message, status } = result;

      if (status) {
        // Update Last Received Date whenever the API
        // successfully returns a response.

        // updateLastReceivedDate(data?.readingTime);

        let parsedData = [];

        try {
          if (isCnms) {
            const rawData = data?.value;

            parsedData =
              typeof rawData === "string" ? JSON.parse(rawData) : rawData;
          } else {
            if (status === 7 && data?.value) {
              parsedData =
                typeof data.value === "string"
                  ? JSON.parse(data.value)
                  : data.value;
            } else {
              parsedData = typeof data === "string" ? JSON.parse(data) : data;
            }
          }
        } catch (error) {
          console.error("Failed to parse client table data:", error);

          parsedData = [];
        }

        if (isMountedRef.current) {
          fillTable(parsedData);

          if (status === 7) {
            Toast("Error", message || "Client table status warning", "error");
          }
        }
      } else {
        Toast("Error", message || "Failed to fetch client table data", "error");
      }
    } catch (error) {
      if (!isMountedRef.current) return;

      Toast(
        "Error",
        error?.message || "Failed to fetch client table data",
        "error"
      );
    } finally {
      requestInProgressRef.current = false;

      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [isCnms, resourceId, siteId]);

  /* =========================================================
       MOUNT / UNMOUNT AND POLLING
    ========================================================= */

  useEffect(() => {
    isMountedRef.current = true;

    fetchTableData();

    intervalRef.current = setInterval(
      () => {
        fetchTableData();
      },
      isCnms ? 60000 : 30000
    );

    return () => {
      isMountedRef.current = false;

      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [fetchTableData, isCnms]);



  return (
    <Box sx={{ width: "100%", mb: 1 }}>
      {loading && <LinearProgress sx={{ mb: 1 }} />}

      <MTable
        tableTitle="LOS-1 (PDA) CLIENTS"
        columns={columns}
        tableData={rows}
        showSearch={true}
        showPagination={true}
        showMaximazed={false}
        closeIcon={false}
      />
    </Box>
  );
};

export default ClientsTable;
