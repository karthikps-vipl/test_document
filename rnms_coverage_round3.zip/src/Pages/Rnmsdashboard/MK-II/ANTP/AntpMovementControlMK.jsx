import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  CircularProgress,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Tooltip,
  useTheme,
} from "@mui/material";

import {
  RotateRight,
  RotateLeft,
  ArrowUpward,
  ArrowDownward,
  Stop,
  MyLocation,
  Check,
  Close,
  CheckCircleOutline,
} from "@mui/icons-material";
import Confirmation_icon from "../../../../assets/SVGIcons/question_mark.svg";

import { useSelector } from "react-redux";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

import Toast from "@/components/Reusable/Toast/Toast";

import ClientsTable from "./ClientsTable";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";

import {
  GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS,
  GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS,
  GET_SWITCH_TO_REMOTE,
  GET_SWITCH_TO_REMOTE_CNMS,
  GET_AZIMUTH_QUERY,
  GET_ELEVATION_QUERY,
  GET_ELEVATION_UP,
  GET_ALIGN,
  GET_STOP,
  GET_AZIMUTH_CW_DIRECTION,
  GET_ELEVATION_DOWN,
  GET_AZIMUTH_CCW_DIRECTION,
  GET_SWITCH_TO_LOCAL,
} from "@/RestAPI/url/endpoint";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";

/* ============================================================================
     THEME COLORS
  ============================================================================ */

const getColors = (isDark) => ({
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  cardBg: isDark ? "#252525" : "#ffffff",

  border: isDark ? "#3a3a3a" : "#e0e0e0",
  innerBorder: isDark ? "#404040" : "#e5e7eb",

  heading: isDark ? "#f3f4f6" : "#1f2937",
  text: isDark ? "#9ca3af" : "#4b5563",
  muted: isDark ? "#6b7280" : "#9ca3af",

  buttonBg: isDark ? "#303030" : "#eeeeee",
  success: "#16a34a",
  danger: "#dc2626",
});

/* ============================================================================
     MOVEMENT STATUS MESSAGES
  ============================================================================ */

const STATUS_MESSAGES = {
  up: "Elevation up is ON... Press Stop button to halt.",
  down: "Elevation down is ON... Press Stop button to halt.",
  cw: "Azimuth CW is ON... Press Stop button to halt.",
  ccw: "Azimuth CCW is ON... Press Stop button to halt.",
  align: "Align is ON... Press Stop button to halt.",
  stopped: "Successfully Stopped.",
  idle: "No Movement",
};

const SUCCESS_MESSAGES = {
  up: "Elevation up successfully completed.",
  down: "Elevation down successfully completed.",
  cw: "Azimuth CW movement successfully completed.",
  ccw: "Azimuth CCW movement successfully completed.",
  align: "Align successfully completed.",
};

const ERROR_MESSAGES = {
  azimuth: "Failed to fetch Azimuth value.",
  elevation: "Failed to fetch Elevation value.",
  up: "Failed to perform UP command.",
  down: "Failed to perform DOWN command.",
  cw: "Failed to perform CW command.",
  ccw: "Failed to perform CCW command.",
  stop: "Failed to perform Stop command.",
  align: "Failed to perform Align command.",
  local: "Failed to switch to local mode.",
};

/* ============================================================================
     COMPONENT
  ============================================================================ */

const AntpMovementControlMK = ({ node }) => {
  const resId = node?.resourceId;
  const siteId = node?.siteId;

  const isCnms = useSelector((state) => state.nodeDetails?.isCnms);

  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const colors = getColors(isDark);

  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  /* ==========================================================================
       STATE
    ========================================================================== */

  const [azimuth, setAzimuth] = useState(0);
  const [elevation, setElevation] = useState(0);

  const [currentMovement, setCurrentMovement] = useState(null);

  const [antennaStatus, setAntennaStatus] = useState(STATUS_MESSAGES.idle);

  const [loading, setLoading] = useState(false);

  const [isInitialLoading, setIsInitialLoading] = useState(true);

  const [enableLocalToRemote, setEnableLocalToRemote] = useState(false);

  const [remoteModeDialog, setRemoteModeDialog] = useState(false);

  const [remoteLoader, setRemoteLoader] = useState(false);

  const [switchLoader, setSwitchLoader] = useState(false);

  const [movementDialog, setMovementDialog] = useState(false);

  /* ==========================================================================
       REFS
    ========================================================================== */

  const isMountedRef = useRef(false);

  const movementRef = useRef(null);

  const requestRef = useRef(false);

  const movementInProgress = Boolean(currentMovement);

  useEffect(() => {
    movementRef.current = currentMovement;
  }, [currentMovement]);

  useEffect(() => {
    isMountedRef.current = true;

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  /* ==========================================================================
       COMMON API HANDLER
  
       Non-CNMS : GET
       CNMS     : POST with siteId
    ========================================================================== */

  const callAntpApi = useCallback(
    async (endpoint) => {
      if (!endpoint || !resId) {
        throw new Error("ANTP endpoint or resource ID missing");
      }

      const url = `${endpoint}/${resId}`;

      const response = await ConfigurationAxios(
        url,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : {}
      );

      return response?.data;
    },
    [resId, siteId, isCnms]
  );

  /* ==========================================================================
       RESPONSE NORMALIZATION
  
       Handles:
       1. Normal response objects
       2. JSON strings
       3. CNMS data.value JSON response
    ========================================================================== */

  const normalizeResponse = useCallback((response) => {
    let result = response?.data ?? response;

    if (result?.value !== undefined) {
      result = result.value;
    }

    if (typeof result === "string") {
      try {
        result = JSON.parse(result);
      } catch {
        return null;
      }
    }

    return result;
  }, []);

  /* ==========================================================================
       POSITION VALIDATION
    ========================================================================== */

  const validateAzimuth = useCallback((value) => {
    if (value === null || value === undefined) return;

    const number = Number(value);
    if (!Number.isFinite(number)) return;

    setAzimuth(Math.min(360, Math.max(0, number)));
  }, []);

  const validateElevation = useCallback((value) => {
    if (value === null || value === undefined) return;

    const number = Number(value);

    if (!Number.isFinite(number)) return;

    setElevation(Math.min(15, Math.max(-15, number)));
  }, []);

  /* ==========================================================================
       FETCH AZIMUTH
    ========================================================================== */

  const getAzimuthQuery = useCallback(async () => {
    try {
      const response = await callAntpApi(GET_AZIMUTH_QUERY);

      const data = normalizeResponse(response);

      const value = data?.AZIMUTH_RESP_RESPONSE?.azimuth ?? "";
      // data?.AZIMUTH_RESP_RESPONSE?.azimuth;

      if (value !== undefined) {
        validateAzimuth(value);
      } else {
        throw new Error("Azimuth value unavailable");
      }
    } catch (error) {
      console.error("ANTP Azimuth Query:", error);

      Toast("Error", ERROR_MESSAGES.azimuth, "error");
    }
  }, [callAntpApi, normalizeResponse, validateAzimuth]);

  /* ==========================================================================
       FETCH ELEVATION
    ========================================================================== */

  const getElevationQuery = useCallback(async () => {
    try {
      const response = await callAntpApi(GET_ELEVATION_QUERY);

      const data = normalizeResponse(response);

      const value =
        data?.ele_POS_RESP_RESPONSE?.elevation ??
        data?.ELE_POS_RESP_RESPONSE?.elevation;

      if (value !== undefined) {
        validateElevation(value);
      } else {
        throw new Error("Elevation value unavailable");
      }
    } catch (error) {
      console.error("ANTP Elevation Query:", error);

      Toast("Error", ERROR_MESSAGES.elevation, "error");
    }
  }, [callAntpApi, normalizeResponse, validateElevation]);

  /* ==========================================================================
       FETCH BOTH POSITIONS
    ========================================================================== */

  const readBothPositions = useCallback(async () => {
    await Promise.all([getAzimuthQuery(), getElevationQuery()]);
  }, [getAzimuthQuery, getElevationQuery]);

  /* ==========================================================================
       MODE CHECK
    ========================================================================== */

  const checkLocalMode = useCallback(async () => {
    const response = await callAntpApi(
      isCnms
        ? GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS
        : GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS
    );

    const data = normalizeResponse(response);

    return Boolean(data?.localModeStatus ?? data?.data?.localModeStatus);
  }, [callAntpApi, normalizeResponse, isCnms]);

  /* ==========================================================================
       INITIALIZATION
    ========================================================================== */

  const initializeMovementControl = useCallback(async () => {
    setLoading(true);

    try {
      const isLocal = await checkLocalMode();

      if (isLocal) {
        setEnableLocalToRemote(true);
      } else {
        await readBothPositions();

        setEnableLocalToRemote(false);
      }
    } catch (error) {
      console.error("ANTP initialization:", error);

      setEnableLocalToRemote(true);
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
        setIsInitialLoading(false);
      }
    }
  }, [checkLocalMode, readBothPositions]);

  useEffect(() => {
    if (!resId) {
      setIsInitialLoading(false);
      return;
    }

    initializeMovementControl();
  }, [resId, initializeMovementControl]);

  /* ==========================================================================
       SWITCH TO REMOTE MODE
    ========================================================================== */

  const handleSwitchToRemote = async () => {
    setRemoteLoader(true);

    try {
      await callAntpApi(
        isCnms ? GET_SWITCH_TO_REMOTE_CNMS : GET_SWITCH_TO_REMOTE
      );

      const isStillLocal = await checkLocalMode();

      if (isStillLocal) {
        Toast("Error", "Failed to switch remote mode", "error");
      } else {
        Toast("Success", "Switched to remote mode.", "success");

        setEnableLocalToRemote(false);

        await readBothPositions();
      }
    } catch (error) {
      console.error("Switch remote mode:", error);

      Toast("Error", "Failed to switch remote mode", "error");
    } finally {
      if (isMountedRef.current) {
        setRemoteLoader(false);
      }
    }
  };

  /* ==========================================================================
       SWITCH TO LOCAL MODE
    ========================================================================== */

  const handleSwitchToLocal = async () => {
    setSwitchLoader(true);

    try {
      await callAntpApi(GET_SWITCH_TO_LOCAL);

      Toast("Success", "Switched to local mode.", "success");

      setRemoteModeDialog(false);
    } catch (error) {
      console.error("Switch local mode:", error);

      Toast("Error", ERROR_MESSAGES.local, "error");
    } finally {
      if (isMountedRef.current) {
        setSwitchLoader(false);
      }
    }
  };

  /* ==========================================================================
       MOVEMENT COMMAND API
    ========================================================================== */

  const movementEndpoints = useMemo(
    () => ({
      up: GET_ELEVATION_UP,
      down: GET_ELEVATION_DOWN,
      cw: GET_AZIMUTH_CW_DIRECTION,
      ccw: GET_AZIMUTH_CCW_DIRECTION,
      stop: GET_STOP,
      align: GET_ALIGN,
    }),
    []
  );

  /* ==========================================================================
       INITIATE / STOP MOVEMENT
    ========================================================================== */

  const handleMovement = async (type) => {
    if (requestRef.current) return;

    if (type !== "stop" && movementRef.current) return;

    requestRef.current = true;

    setLoading(true);

    try {
      const isLocal = await checkLocalMode();

      if (isLocal) {
        setEnableLocalToRemote(true);

        return;
      }

      const endpoint = movementEndpoints[type];

      if (!endpoint) {
        throw new Error("Invalid movement command");
      }

      await callAntpApi(endpoint);

      if (type === "stop") {
        const previousMovement = movementRef.current;

        movementRef.current = null;
        setCurrentMovement(null);

        setAntennaStatus(STATUS_MESSAGES.stopped);

        // Read the final position after stopping.
        await readBothPositions();

        if (previousMovement) {
          Toast("Success", "Antenna movement stopped.", "success");
        }
      } else {
        movementRef.current = type;

        setCurrentMovement(type);

        setAntennaStatus(STATUS_MESSAGES[type]);

        Toast("Success", `${type.toUpperCase()} command initiated.`, "success");
      }
    } catch (error) {
      console.error("ANTP Movement:", error);

      if (type !== "stop") {
        movementRef.current = null;
        setCurrentMovement(null);
      }

      setAntennaStatus(STATUS_MESSAGES.idle);

      Toast(
        "Error",
        ERROR_MESSAGES[type] || "Movement command failed.",
        "error"
      );
    } finally {
      requestRef.current = false;

      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  };

  /* ==========================================================================
       POLLING DURING MOVEMENT
  
       Poll every 5 seconds.
  
       UP / DOWN   : Elevation
       CW / CCW    : Azimuth
       ALIGN       : Both
    ========================================================================== */

  useEffect(() => {
    if (!currentMovement) return;

    const pollMovement = async () => {
      if (!isMountedRef.current || requestRef.current) return;

      try {
        if (currentMovement === "up" || currentMovement === "down") {
          await getElevationQuery();
        } else if (currentMovement === "cw" || currentMovement === "ccw") {
          await getAzimuthQuery();
        } else if (currentMovement === "align") {
          await readBothPositions();

          // Check whether alignment has completed.
          // Only stop polling when the device explicitly
          // reports antennaMoving === false.

          const response = await callAntpApi(
            isCnms
              ? GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS
              : GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS
          );

          const data = normalizeResponse(response);

          if (data?.antennaMoving === false) {
            movementRef.current = null;

            setCurrentMovement(null);

            setAntennaStatus(SUCCESS_MESSAGES.align);
          }
        }
      } catch (error) {
        console.error("ANTP movement polling:", error);
      }
    };

    const interval = setInterval(pollMovement, 5000);

    return () => clearInterval(interval);
  }, [
    currentMovement,
    getAzimuthQuery,
    getElevationQuery,
    readBothPositions,
    callAntpApi,
    normalizeResponse,
    isCnms,
  ]);

  /* ==========================================================================
       GAUGE CONFIGURATION
    ========================================================================== */

  const azimuthWidgetConfig = useMemo(
    () => ({
      gridTitle: "Azimuth",
      minVal: 0,
      maxVal: 360,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(azimuth) || 0,
        },
      ],
    }),
    [azimuth]
  );

  const elevationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Elevation",
      minVal: -15,
      maxVal: 15,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(elevation) || 0,
        },
      ],
    }),
    [elevation]
  );

  /* ==========================================================================
       MOVEMENT BUTTON CONFIGURATION
    ========================================================================== */

  const movementButtons = [
    {
      key: "cw",
      label: "CW",
      icon: <RotateRight />,
    },
    {
      key: "ccw",
      label: "CCW",
      icon: <RotateLeft />,
    },
    {
      key: "up",
      label: "UP",
      icon: <ArrowUpward />,
    },
    {
      key: "down",
      label: "DOWN",
      icon: <ArrowDownward />,
    },
  ];

  /* ==========================================================================
       INITIAL LOADING
    ========================================================================== */

  if (isInitialLoading) {
    return (
      <Paper
        elevation={0}
        sx={{
          minHeight: 350,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <CircularProgress />

        <Typography color="text.secondary">
          Loading ANTP Movement Control...
        </Typography>
      </Paper>
    );
  }

  /* ==========================================================================
       RENDER
    ========================================================================== */

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: colors.pageBg,
        color: colors.heading,
      }}
    >
      {/* ================================================================
            SWITCH TO REMOTE DIALOG
        ================================================================ */}

      <Dialog open={enableLocalToRemote} maxWidth="xs" fullWidth>
        <DialogTitle>Information</DialogTitle>

        <DialogContent>
          Kindly ensure that remote mode has been selected in the device.
        </DialogContent>

        <DialogActions>
          <Button
            variant="contained"
            onClick={handleSwitchToRemote}
            disabled={remoteLoader}
          >
            {remoteLoader ? (
              <CircularProgress size={20} />
            ) : (
              "Switch To Remote Mode"
            )}
          </Button>

          <Button
            color="secondary"
            onClick={() => setEnableLocalToRemote(false)}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* ================================================================
            SWITCH TO LOCAL CONFIRMATION
        ================================================================ */}

      {/* <Dialog open={remoteModeDialog} maxWidth="xs" fullWidth>
        <DialogTitle>Information</DialogTitle>

        <DialogContent>
          Are you sure you want to switch to local mode?
        </DialogContent>

        <DialogActions>
          <Button
            variant="contained"
            onClick={handleSwitchToLocal}
            disabled={switchLoader}
            startIcon={
              switchLoader ? <CircularProgress size={18} /> : <Check />
            }
          >
            Confirm
          </Button>

          <Button color="secondary" onClick={() => setRemoteModeDialog(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog> */}
      <MDialog
        open={remoteModeDialog}
        title="Information"
        message="Are you sure you want to switch to local mode?"
        onConfirm={handleSwitchToLocal}
        onClose={() => setRemoteModeDialog(false)}
        variant="info"
        confirmText="Confirm"
        cancelText="Close"
        icon={Confirmation_icon} // Optional: Dynamic icon
      />
      {/* ================================================================
            MOVEMENT IN PROGRESS DIALOG
        ================================================================ */}

      <Dialog open={movementDialog} maxWidth="xs" fullWidth>
        <DialogTitle>Information</DialogTitle>

        <DialogContent>
          Antenna movement is in progress. Kindly press the Stop button to
          terminate the movement.
        </DialogContent>

        <DialogActions>
          <Button variant="contained" onClick={() => setMovementDialog(false)}>
            OK
          </Button>
        </DialogActions>
      </Dialog>

      {/* ================================================================
            LOADING
        ================================================================ */}

      {loading && <LinearProgress sx={{ mb: 1 }} />}

      {/* ================================================================
            LOCAL MODE BUTTON
        ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <MButtonPrimary
          variant="contained"
          color="primary"
          disabled={loading || movementInProgress}
          onClick={() => setRemoteModeDialog(true)}
        >
          Switch to Local Mode
        </MButtonPrimary>
      </Paper>

      {/* ================================================================
            GAUGES
        ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              sm: "repeat(2, 1fr)",
            },
            gap: 2,
          }}
        >
          {/* AZIMUTH */}

          <Box
            sx={{
              p: 1,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 2,
              backgroundColor: colors.cardBg,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              minHeight: 220,
            }}
          >
            {DialGaugeWidget && DialGaugeWidget(azimuthWidgetConfig)}

            <Typography fontWeight={700} sx={{ mt: 1 }}>
              Azimuth = {Number(azimuth).toFixed(1)}°
            </Typography>
          </Box>

          {/* ELEVATION */}

          <Box
            sx={{
              p: 1,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 2,
              backgroundColor: colors.cardBg,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              minHeight: 220,
            }}
          >
            {DialGaugeWidget && DialGaugeWidget(elevationWidgetConfig)}

            <Typography fontWeight={700} sx={{ mt: 1 }}>
              Elevation = {Number(elevation).toFixed(1)}°
            </Typography>
          </Box>
        </Grid>
      </Paper>

      {/* ================================================================
            MOVEMENT CONTROLS
        ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid container spacing={2} alignItems="center" justifyContent="center">
          {movementButtons.map((item) => (
            <Grid item xs={6} sm={3} key={item.key}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 0.5,
                }}
              >
                <Tooltip title={item.label}>
                  <span>
                    <IconButton
                      color="success"
                      disabled={
                        loading || movementInProgress || enableLocalToRemote
                      }
                      onClick={() => handleMovement(item.key)}
                      sx={{
                        width: 45,
                        height: 45,
                        backgroundColor: colors.buttonBg,
                        border: `1px solid ${colors.innerBorder}`,
                        "&:hover": {
                          backgroundColor: colors.innerBorder,
                        },
                      }}
                    >
                      {currentMovement === item.key ? (
                        <CircularProgress size={23} />
                      ) : (
                        item.icon
                      )}
                    </IconButton>
                  </span>
                </Tooltip>

                <Typography
                  variant="caption"
                  fontWeight={700}
                  color="text.secondary"
                >
                  {item.label}
                </Typography>
              </Box>
            </Grid>
          ))}

          {/* STOP BUTTON */}

          <Grid item xs={6} sm={3}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 0.5,
              }}
            >
              <IconButton
                color="error"
                disabled={!movementInProgress || loading}
                onClick={() => handleMovement("stop")}
                sx={{
                  width: 45,
                  height: 45,
                  backgroundColor: colors.buttonBg,
                  border: `1px solid ${colors.innerBorder}`,
                }}
              >
                <Stop />
              </IconButton>

              <Typography
                variant="caption"
                fontWeight={700}
                color="text.secondary"
              >
                STOP
              </Typography>
            </Box>
          </Grid>

          {/* ALIGN BUTTON */}

          <Grid item xs={6} sm={3}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 0.5,
              }}
            >
              <MButtonPrimary
                variant="contained"
                color="primary"
                disabled={loading || movementInProgress || enableLocalToRemote}
                onClick={() => handleMovement("align")}
                style={{
                  minWidth: 90,
                  height: 45,
                }}
              >
                {currentMovement === "align" ? (
                  <CircularProgress size={22} color="inherit" />
                ) : (
                  <>
                    <MyLocation sx={{ mr: 0.5 }} />
                    ALIGN
                  </>
                )}
              </MButtonPrimary>

              <Typography
                variant="caption"
                fontWeight={700}
                color="text.secondary"
              >
                ALIGN
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* ================================================================
            ANTENNA POSITION STATUS
        ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
          display: "flex",
          alignItems: "center",
          gap: 1,
        }}
      >
        <Typography
          variant="body2"
          fontWeight={700}
          sx={{ color: colors.heading }}
        >
          Antenna Position:
        </Typography>

        <Typography
          variant="body2"
          sx={{
            color: movementInProgress ? "#d97706" : colors.success,
            fontWeight: 600,
          }}
        >
          {antennaStatus}
        </Typography>
      </Paper>

      {/* ================================================================
            CLIENTS TABLE
        ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
          overflow: "hidden",
        }}
      >
        <ClientsTable resource={node?.resource} {...node} />
      </Paper>
    </Box>
  );
};

export default AntpMovementControlMK;
