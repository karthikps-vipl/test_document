import React, { useState } from "react";
import { Box, Tabs, Tab, Paper } from "@mui/material";
import { Tune, MapOutlined } from "@mui/icons-material";

import AntpMovementControlMK from "./AntpMovementControlMK";
import AntpNavigationControlMK from "./AntpNavigationControlMK";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const AntpControlMK = ({ node }) => {
  const [activeTab, setActiveTab] = useState("MOVEMENT CONTROL");

  // Define your tab configuration
  const TABS = [
    {
      label: "Movement Control",
      value: "MOVEMENT CONTROL",
      icon: <Tune />, // Optional: You can add icons here if MButtonPrimary supports them or via sx
    },
    {
      label: "Navigational Control",
      value: "SATELLITE DATA", // Changed to match your original logic or keep consistent
      icon: <MapOutlined />,
    },
  ];

  return (
    <Box sx={{ width: "100%" }}>
      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          display: "flex",
          gap: 1,
          flexWrap: "wrap",
          border: "1px solid",
          borderColor: "divider", // Or use your theme variable here
          borderRadius: 2,
          height: "100%", // Ensure it takes full height if needed
        }}
      >
        {/* ============================================================
         * TAB BUTTONS
         * ========================================================== */}
        {TABS.map((tab) => (
          <Box
            key={tab.value}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
            }}
          >
            <MButtonPrimary
              key={tab.value}
              variant={activeTab === tab.value ? "contained" : "outlined"}
              color="primary"
              onClick={() => setActiveTab(tab.value)}
              sx={{
                minWidth: 170,
                borderRadius: 2,
                height: 42,
                // Optional: Add icon inside button if your MButtonPrimary supports children
                justifyContent: "center",
                display: "flex",
                alignItems: "center",
              }}
            >
              {tab.label}
              {/* Optional: Render icon if passed via props or children */}
              {/* {tab.icon} */}
            </MButtonPrimary>
          </Box>
        ))}
      </Paper>

      {activeTab === "MOVEMENT CONTROL" && (
        <AntpMovementControlMK node={node} />
      )}

      {activeTab === "SATELLITE DATA" && (
        <AntpNavigationControlMK node={node} />
      )}
    </Box>
  );
};

export default AntpControlMK;
