import React, { useState, useEffect } from "react";

import {
  Box,
  Paper,
  Grid,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
} from "@mui/material";

import { Edit } from "@mui/icons-material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const LocalSite = ({
  navigationalData,
  setNavigationalData,
  helperText,
  setHelperText,
  toggleView,
  modify,
  setModify,
}) => {
  const handleChange = (event, min, max, type, allowDecimal = true) => {
    const { name, value } = event.target;

    // Allow only digits and, optionally, one decimal point.
    const regex = allowDecimal ? /^\d*\.?\d*$/ : /^\d*$/;

    if (!regex.test(value)) {
      setHelperText((previous) => ({
        ...previous,
        [name]: allowDecimal
          ? "Only numeric values are allowed."
          : "Only whole numbers are allowed.",
      }));

      return;
    }

    const numericValue = value === "" ? NaN : Number(value);

    const isInvalid =
      value === "" ||
      !Number.isFinite(numericValue) ||
      numericValue < min ||
      numericValue > max;

    const updates = { [name]: value };

    if (type === "lat" && numericValue === max) {
      updates.latMinute = "0";
      updates.latSecond = "0";
    }

    if (type === "lng" && numericValue === max) {
      updates.lngMinute = "0";
      updates.lngSecond = "0";
    }

    setNavigationalData((previous) => ({
      ...previous,
      ...updates,
    }));

    setHelperText((previous) => ({
      ...previous,
      [name]: isInvalid ? `${min} to ${max} required.` : "",
      ...(type === "lat" && numericValue === max
        ? { latMinute: "", latSecond: "" }
        : {}),
      ...(type === "lng" && numericValue === max
        ? { lngMinute: "", lngSecond: "" }
        : {}),
    }));
  };

  const isMinSecDisabled = (max, current) =>
    current !== "" && Number(current) >= max;



  const field = (
    name,
    label,
    min,
    max,
    type,
    disabled = false,
    allowDecimal = true
  ) => (
    <Grid item xs={3}>
      <TextField
        fullWidth
        size="small"
        name={name}
        label={label}
        type="text"
        value={navigationalData[name] ?? ""}
        disabled={!modify || disabled}
        onChange={(event) => handleChange(event, min, max, type, allowDecimal)}
        error={Boolean(helperText[name])}
        helperText={helperText[name] || ""}
        inputProps={{
          inputMode: allowDecimal ? "decimal" : "numeric",
        }}
      />
    </Grid>
  );

  return (
    <Paper
      elevation={0}
      sx={{
        p: 1,
        height: "100%",
        border: "1px solid",
        borderColor: "divider",
        borderRadius: 2,
      }}
    >
      <Box display="flex" justifyContent="space-between" mb={1}>
        <Typography fontWeight={700} color="primary" variant="body1">
          Local Site
        </Typography>

        <Typography variant="caption" color="text.secondary">
          Source: GPS / Manual
        </Typography>
      </Box>

      <Typography fontWeight={600} mb={1} variant="body2">
        Latitude
      </Typography>

      <Grid spacing={1} className="grid grid-cols-4 gap-3">
        {field("latDegree", "Degree", 0, 90, "lat", false, false)}

        {field(
          "latMinute",
          "Minute",
          0,
          59,
          null,
          isMinSecDisabled(90, navigationalData.latDegree),
          false
        )}

        {field(
          "latSecond",
          "Second",
          0,
          59,
          null,
          isMinSecDisabled(90, navigationalData.latDegree),
          true
        )}

        <Grid item xs={3}>
          <FormControl fullWidth size="small" disabled>
            <InputLabel>Direction</InputLabel>
            <Select
              value={navigationalData.latDirection || "N"}
              label="Direction"
            >
              <MenuItem value="N">North</MenuItem>
              <MenuItem value="S">South</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Typography fontWeight={600} mt={2} mb={1} variant="body2">
        Longitude
      </Typography>

      <Grid spacing={1} className="grid grid-cols-4 gap-3">
        {field("lngDegree", "Degree", 0, 180, "lng", false, false)}

        {field(
          "lngMinute",
          "Minute",
          0,
          59,
          null,
          isMinSecDisabled(180, navigationalData.lngDegree),
          false
        )}

        {field(
          "lngSecond",
          "Second",
          0,
          59,
          null,
          isMinSecDisabled(180, navigationalData.lngDegree),
          true
        )}

        <Grid item xs={3}>
          <FormControl fullWidth size="small" disabled>
            <InputLabel>Direction</InputLabel>
            <Select
              value={navigationalData.lngDirection || "E"}
              label="Direction"
            >
              <MenuItem value="E">East</MenuItem>
              <MenuItem value="W">West</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Grid spacing={1} mt={1} className="grid grid-cols-2 gap-3">
        <Grid item xs={6}>
          <TextField
            fullWidth
            size="small"
            type="text"
            label="Vehicle Heading (Deg)"
            name="heading"
            value={navigationalData.heading ?? ""}
            disabled={!modify}
            onChange={(event) => handleChange(event, 0, 359.9, null, true)}
            error={Boolean(helperText.heading)}
            helperText={helperText.heading || ""}
            inputProps={{ inputMode: "decimal" }}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            size="small"
            type="text"
            label="Altitude (Mtr)"
            name="altitude"
            value={navigationalData.altitude ?? ""}
            disabled={!modify}
            onChange={(event) => handleChange(event, 0, 9999, null, true)}
            error={Boolean(helperText.altitude)}
            helperText={helperText.altitude || ""}
            inputProps={{ inputMode: "decimal" }}
          />
        </Grid>
      </Grid>

      {!toggleView && (
        <Box display="flex" justifyContent="center" mt={2}>
          <MButtonPrimary
            variant="contained"
            startIcon={<Edit />}
            onClick={() => setModify((previous) => !previous)}
            sx={{ minWidth: 110, height: 38, borderRadius: 2 }}
          >
            {modify ? "Done" : "Edit"}
          </MButtonPrimary>
        </Box>
      )}
    </Paper>
  );
};

export default LocalSite;
