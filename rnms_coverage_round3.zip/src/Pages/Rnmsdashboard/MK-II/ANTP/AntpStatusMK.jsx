import React, {
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
  } from "react";
  
  import {
    Box,
    Typography,
    Grid,
    Paper,
    TextField,
    CircularProgress,
    LinearProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    useTheme,
  } from "@mui/material";
  
  import { useSelector } from "react-redux";
  
  import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";
  
  import Toast from "@/components/Reusable/Toast/Toast";
  
//   import {

//     getSwitchToRemote,
//     getSwitchToRemoteCNMS,
//   } from "../../../APIs/CM";
import ClientsTable from "./ClientsTable";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS, GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS, GET_SWITCH_TO_REMOTE, GET_SWITCH_TO_REMOTE_CNMS } from "@/RestAPI/url/endpoint";
  
  
  /* ============================================================================
   * THEME COLORS
   * ========================================================================== */
  
  const getAntpColors = (isDark) => ({
    pageBg: isDark ? "#121212" : "#f4f6f8",
    paperBg: isDark ? "#1e1e1e" : "#ffffff",
    cardBg: isDark ? "#252525" : "#ffffff",
  
    border: isDark ? "#3a3a3a" : "#e0e0e0",
    innerBorder: isDark ? "#404040" : "#e5e7eb",
  
    heading: isDark ? "#f3f4f6" : "#1f2937",
    text: isDark ? "#9ca3af" : "#4b5563",
    muted: isDark ? "#6b7280" : "#9ca3af",
  
    successBg: isDark ? "#14291e" : "#f0fdf4",
    successBorder: isDark ? "#285b3b" : "#bbf7d0",
    successText: isDark ? "#86efac" : "#15803d",
  
    dangerBg: isDark ? "#2a1515" : "#fef2f2",
    dangerBorder: isDark ? "#7f1d1d" : "#fecaca",
    dangerText: isDark ? "#fca5a5" : "#b91c1c",
  });
  
  /* ============================================================================
   * REUSABLE STATUS BADGE
   * ========================================================================== */
  
  const StatusBadge = ({ status, colors }) => {
    if (status === null || status === undefined) {
      return (
        <Typography variant="body2" sx={{ color: colors.muted }}>
          --
        </Typography>
      );
    }
  
    const isOk = Boolean(status);
  
    return (
      <Box
        sx={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          minWidth: 70,
          height: 26,
          px: 1,
          borderRadius: 1,
          fontWeight: 700,
          fontSize: 12,
          backgroundColor: isOk
            ? colors.successBg
            : colors.dangerBg,
          border: `1px solid ${
            isOk ? colors.successBorder : colors.dangerBorder
          }`,
          color: isOk ? colors.successText : colors.dangerText,
        }}
      >
        {isOk ? "OK" : "Not OK"}
      </Box>
    );
  };
  
  /* ============================================================================
   * REUSABLE INFORMATION ROW
   * ========================================================================== */
  
  const InfoRow = ({ label, children, colors }) => (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1,
        py: 0.75,
      }}
    >
      <Typography
        variant="body2"
        sx={{
          minWidth: 110,
          fontWeight: 700,
          color: colors.text,
        }}
      >
        {label}
      </Typography>
  
      <Box
        sx={{
          color: colors.heading,
          fontSize: 14,
          fontWeight: 500,
        }}
      >
        {children ?? "--"}
      </Box>
    </Box>
  );
  
  /* ============================================================================
   * COMPONENT
   * ========================================================================== */
  
  const AntpStatusMK = ({ node }) => {
    const resId = node?.resourceId;
    const siteId = node?.siteId;
  
    const isCnms = useSelector(
      (state) => state.nodeDetails?.isCnms
    );
  
    const theme = useTheme();
    const isDark = theme.palette.mode === "dark";
    const colors = getAntpColors(isDark);
  
    const DialGaugeWidget =
      WIDGET_REGISTRY.circularDialGauge?.renderCanvas;
  
    /* ==========================================================================
     * STATE
     * ======================================================================== */
  
    const [antennaStatus, setAntennaStatus] = useState(null);
  
    const [loading, setLoading] = useState(false);
    const [isInitialLoading, setIsInitialLoading] = useState(true);
  
    const [enableLocalToRemote, setEnableLocalToRemote] =
      useState(false);
  
    const [remoteLoader, setRemoteLoader] = useState(false);
  
    /* ==========================================================================
     * REFS
     * ======================================================================== */
  
    const isMountedRef = useRef(false);
    const pollIntervalRef = useRef(null);
    const resolvedRef = useRef(false);
    const initialCallRef = useRef(true);
  
    /* ==========================================================================
     * MOUNT / UNMOUNT
     * ======================================================================== */
  
    useEffect(() => {
      isMountedRef.current = true;
  
      return () => {
        isMountedRef.current = false;
  
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current);
        }
      };
    }, []);
  
    /* ==========================================================================
     * FETCH ANTENNA POSITIONER STATUS
     *
     * CNMS:
     *   data.value contains JSON.
     *
     * Non-CNMS:
     *   data contains the antenna status.
     *
     * status === 7:
     *   Display warning but retain the returned status data.
     * ======================================================================== */
  
    const fetchAntennaStatus = useCallback(async () => {
      if (!resId || !isMountedRef.current) return;
  
      setLoading(true);
      resolvedRef.current = false;
  
      try {
        const response = await ConfigurationAxios(
            `${
              isCnms 
                ? GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS
                : GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS
            }/${resId}`,
            
            isCnms ? "post" : "get",
            
            isCnms ? { siteId: String(siteId) } : {}
          );
          
  
        if (!isMountedRef.current) return;
  
        const result = response?.data;
  
        if (result) {
          const { data, message, status } = result;
  
          if (status) {
            let parsedData = null;
  
            try {
              if (isCnms) {
                const rawData = data?.value;
  
                parsedData =
                  typeof rawData === "string"
                    ? JSON.parse(rawData)
                    : rawData;
              } else {
                parsedData =
                  typeof data === "string"
                    ? JSON.parse(data)
                    : data;
              }
            } catch (error) {
              console.error(
                "Failed to parse ANTP status:",
                error
              );
            }
  
            if (parsedData) {
              setAntennaStatus(parsedData);
            }
  
            if (status === 7) {
              Toast(
                "Error",
                message || "ANTP status warning",
                "error"
              );
            }
          } else {
            if (initialCallRef.current) {
              setEnableLocalToRemote(true);
            }
  
            Toast(
              "Error",
              message || "Failed to fetch ANTP status",
              "error"
            );
          }
        }
      } catch (error) {
        if (!isMountedRef.current) return;
  
        if (initialCallRef.current) {
          setEnableLocalToRemote(true);
        }
  
        setAntennaStatus(null);
  
        Toast(
          "Error",
          error?.message || "Failed to fetch ANTP status",
          "error"
        );
      } finally {
        if (isMountedRef.current) {
          setLoading(false);
          setIsInitialLoading(false);
  
          initialCallRef.current = false;
          resolvedRef.current = true;
        }
      }
    }, [resId, siteId, isCnms]);
  
    /* ==========================================================================
     * POLLING
     *
     * CNMS     : 60 seconds
     * Non-CNMS : 10 seconds
     * ======================================================================== */
  
    useEffect(() => {
      if (!resId) {
        setIsInitialLoading(false);
        return;
      }
  
      fetchAntennaStatus();
  
      pollIntervalRef.current = setInterval(() => {
        if (resolvedRef.current) {
          fetchAntennaStatus();
        }
      }, isCnms ? 60000 : 30000);
  
      return () => {
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current);
          pollIntervalRef.current = null;
        }
      };
    }, [resId, isCnms, fetchAntennaStatus]);
  
    /* ==========================================================================
     * STATUS VALUES
     * ======================================================================== */
  
    const azimuthValue =
      antennaStatus?.AZIMUTH_RESP_RESPONSE?.azimuth;
    //   antennaStatus?.azStatus;
  
    const elevationValue =
      antennaStatus?.ELE_POS_RESP_RESPONSE?.elevation;
    //   antennaStatus?.elStatus;
  
    const iduHealth = antennaStatus?.idu_HEALTH;
    const oduHealth = antennaStatus?.odu_HEALTH;
  
    /* ==========================================================================
     * GAUGE CONFIGURATIONS
     * ======================================================================== */
  
    const azimuthWidgetConfig = useMemo(
      () => ({
        gridTitle: "Azimuth",
        minVal: 0,
        maxVal: 360,
        unit: "Degree",
        innerRange: 10,
        data: [
          {
            currentValue: Number(azimuthValue) || 0,
          },
        ],
      }),
      [azimuthValue]
    );
  
    const elevationWidgetConfig = useMemo(
      () => ({
        gridTitle: "Elevation",
        minVal: -15,
        maxVal: 15,
        unit: "Degree",
        innerRange: 10,
        data: [
          {
            currentValue: Number(elevationValue) || 0,
          },
        ],
      }),
      [elevationValue]
    );
  
    const gaugeItems = useMemo(
      () => [
        {
          key: "azimuth",
          config: azimuthWidgetConfig,
          label: `Azimuth = ${azimuthValue ?? "--"}°`,
        },
        {
          key: "elevation",
          config: elevationWidgetConfig,
          label: `Elevation = ${elevationValue ?? "--"}°`,
        },
      ],
      [
        azimuthWidgetConfig,
        elevationWidgetConfig,
        azimuthValue,
        elevationValue,
      ]
    );
  
    /* ==========================================================================
     * SWITCH TO REMOTE MODE
     *
     * Preserves the original API sequence:
     * 1. Switch device to remote.
     * 2. Fetch status again.
     * 3. Check localModeStatus.
     * ======================================================================== */
  
    const handleSwitchToRemote = async () => {
      setRemoteLoader(true);
  
      try {

        await ConfigurationAxios(
            `${
              isCnms 
                ? GET_SWITCH_TO_REMOTE_CNMS 
                : GET_SWITCH_TO_REMOTE
            }/${resId}`,
            
            isCnms ? "post" : "get",
            
            isCnms ? { siteId: String(siteId) } : {}
          );
          
          const response = await ConfigurationAxios(
            `${
              isCnms 
                ? GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS
                : GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS
            }/${resId}`,
            
            isCnms ? "post" : "get",
            
            isCnms ? { siteId: String(siteId) } : {}
          );
          
  
        if (response?.data?.localModeStatus) {
          Toast(
            "Error",
            "Failed to switch to remote mode",
            "error"
          );
        } else {
          Toast(
            "Success",
            "Switched to remote mode.",
            "success"
          );
  
          setEnableLocalToRemote(false);
        }
      } catch (error) {
        Toast(
          "Error",
          "Failed to switch remote mode",
          "error"
        );
      } finally {
        if (isMountedRef.current) {
          setRemoteLoader(false);
        }
      }
    };
  
    /* ==========================================================================
     * INITIAL LOADING
     * ======================================================================== */
  
    if (isInitialLoading) {
      return (
        <Box sx={{ p: 1, backgroundColor: colors.pageBg }}>
          <Paper
            elevation={0}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              minHeight: 350,
              borderRadius: 2,
              border: `1px solid ${colors.border}`,
              backgroundColor: colors.paperBg,
            }}
          >
            <CircularProgress size={40} />
  
            <Typography
              variant="body1"
              sx={{ ml: 2, color: colors.heading }}
            >
              Loading ANTP Status...
            </Typography>
          </Paper>
        </Box>
      );
    }
  
    /* ==========================================================================
     * RENDER
     * ======================================================================== */
  
    return (
      <Box
        sx={{
          p: 1,
          backgroundColor: colors.pageBg,
          color: colors.heading,
        }}
      >
        {/* SWITCH TO REMOTE DIALOG */}
  
        <Dialog
          open={enableLocalToRemote}
          maxWidth="xs"
          fullWidth
        >
          <DialogTitle>Information</DialogTitle>
  
          <DialogContent>
            Kindly ensure that remote mode has been selected
            in the device.
          </DialogContent>
  
          <DialogActions>
            <Button
              onClick={handleSwitchToRemote}
              color="primary"
              variant="contained"
              disabled={remoteLoader}
            >
              {remoteLoader ? (
                <CircularProgress size={22} />
              ) : (
                "Switch To Remote Mode"
              )}
            </Button>
  
            <Button
              onClick={() => setEnableLocalToRemote(false)}
              color="secondary"
              variant="contained"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
  
        {/* POLLING PROGRESS */}
  
        {loading && <LinearProgress sx={{ mb: 1 }} />}
  
        {/* IDU / ODU STATUS */}
  
        <Paper
          elevation={0}
          sx={{
            p: 1,
            mb: 1,
            borderRadius: 2,
            border: `1px solid ${colors.border}`,
            backgroundColor: colors.paperBg,
          }}
        >
          {/* <Typography
            variant="subtitle1"
            fontWeight={700}
            sx={{ mb: 1, color: colors.heading }}
          >
            Device Health Status
          </Typography>
   */}
          <Grid
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, 1fr)",
              },
              gap: 2,
            }}
          >
            <Box
              sx={{
                p: 1,
                borderRadius: 2,
                border: `1px solid ${colors.innerBorder}`,
                backgroundColor: colors.cardBg,
              }}
            >
              <InfoRow label="IDU Status:" colors={colors}>
                <StatusBadge
                  status={iduHealth}
                  colors={colors}
                />
              </InfoRow>
            </Box>
  
            <Box
              sx={{
                p: 1,
                borderRadius: 2,
                border: `1px solid ${colors.innerBorder}`,
                backgroundColor: colors.cardBg,
              }}
            >
              <InfoRow label="ODU Status:" colors={colors}>
                <StatusBadge
                  status={oduHealth}
                  colors={colors}
                />
              </InfoRow>
            </Box>
          </Grid>
        </Paper>
  
        {/* AZIMUTH AND ELEVATION GAUGES */}
  
        <Paper
          elevation={0}
          sx={{
            p: 1,
            mb: 1,
            borderRadius: 2,
            border: `1px solid ${colors.border}`,
            backgroundColor: colors.paperBg,
          }}
        >
          {/* <Typography
            variant="subtitle1"
            fontWeight={700}
            sx={{
              mb: 1,
              textAlign: "center",
              color: colors.heading,
            }}
          >
            Antenna Position
          </Typography> */}
  
          <Grid
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                md: "repeat(2, 1fr)",
              },
              gap: 2,
            }}
          >
            {gaugeItems.map((item) => (
              <Box
                key={item.key}
                sx={{
                  border: `1px solid ${colors.innerBorder}`,
                  borderRadius: 2,
                  p: 1,
                  backgroundColor: colors.cardBg,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  minHeight: 220,
                }}
              >
                {DialGaugeWidget &&
                  DialGaugeWidget(item.config)}
  
                {/* <Typography
                  variant="caption"
                  sx={{
                    mt: 1,
                    fontWeight: 600,
                    color: colors.text,
                    textAlign: "center",
                  }}
                >
                  {item.label}
                </Typography> */}
              </Box>
            ))}
          </Grid>
        </Paper>
  
    
        {/* CLIENTS TABLE */}
  
        <Paper
          elevation={0}
          sx={{
            borderRadius: 2,
            border: `1px solid ${colors.border}`,
            backgroundColor: colors.paperBg,
            overflow: "hidden",
          }}
        >
          <ClientsTable
            resource={node?.resource}
            {...node}
          />
        </Paper>
      </Box>
    );
  };
  
  export default AntpStatusMK;