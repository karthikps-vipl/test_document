import React from "react";

import {
  Box,
  Paper,
  Grid,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
} from "@mui/material";

import { Edit } from "@mui/icons-material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const RemoteSite = ({
  navigationalData,
  setNavigationalData,
  helperText,
  setHelperText,
  toggleView,
  modify,
  setModify,
}) => {
  const handleChange = (event, min, max, type, allowDecimal = true) => {
    const { name, value } = event.target;

    const regex = allowDecimal ? /^\d*\.?\d*$/ : /^\d*$/;

    if (!regex.test(value)) {
      setHelperText((previous) => ({
        ...previous,
        [name]: allowDecimal
          ? "Only numeric values are allowed."
          : "Only whole numbers are allowed.",
      }));

      return;
    }

    const numericValue = value === "" ? NaN : Number(value);

    const isInvalid =
      value === "" ||
      !Number.isFinite(numericValue) ||
      numericValue < min ||
      numericValue > max;

    const updates = { [name]: value };

    if (type === "lat" && numericValue === max) {
      updates.rem_latMinute = "0";
      updates.rem_latSecond = "0";
    }

    if (type === "lng" && numericValue === max) {
      updates.rem_lngMinute = "0";
      updates.rem_lngSecond = "0";
    }

    setNavigationalData((previous) => ({
      ...previous,
      ...updates,
    }));

    setHelperText((previous) => ({
      ...previous,
      [name]: isInvalid ? `${min} to ${max} required.` : "",
      ...(type === "lat" && numericValue === max
        ? { rem_latMinute: "", rem_latSecond: "" }
        : {}),
      ...(type === "lng" && numericValue === max
        ? { rem_lngMinute: "", rem_lngSecond: "" }
        : {}),
    }));
  };

  const isMinSecDisabled = (max, current) =>
    current !== "" && Number(current) >= max;

  const field = (name, label, min, max, type, disabled = false) => (
    <Grid item xs={3}>
      <TextField
        fullWidth
        size="small"
        label={label}
        name={name}
        value={navigationalData[name] ?? ""}
        disabled={!modify || disabled}
        onChange={(event) => handleChange(event, min, max, type)}
        error={Boolean(helperText[name])}
        helperText={helperText[name] || ""}
      />
    </Grid>
  );

  return (
    <Paper
      elevation={0}
      sx={{
        p: 1,
        height: "100%",
        border: "1px solid",
        borderColor: "divider",
        borderRadius: 2,
      }}
    >
      <Box display="flex" justifyContent="space-between" mb={1}>
        <Typography fontWeight={700} color="primary" variant="body1">
          Remote Site
        </Typography>

        <Typography variant="caption" color="text.secondary">
          Source: Manual
        </Typography>
      </Box>

      <Typography fontWeight={600} mb={1} variant="body2">
        Latitude
      </Typography>

      <Grid spacing={1} className="grid grid-cols-4 gap-3">
        {field("rem_latDegree", "Degree", 0, 90, "lat", false, false)}

        {field(
          "rem_latMinute",
          "Minute",
          0,
          59,
          null,
          isMinSecDisabled(90, navigationalData.rem_latDegree),
          false
        )}

        {field(
          "rem_latSecond",
          "Second",
          0,
          59,
          null,
          isMinSecDisabled(90, navigationalData.rem_latDegree),
          true
        )}
        <Grid item xs={3}>
          <FormControl fullWidth size="small" disabled>
            <InputLabel>Direction</InputLabel>
            <Select
              value={navigationalData.rem_latDirection || "N"}
              label="Direction"
            >
              <MenuItem value="N">North</MenuItem>
              <MenuItem value="S">South</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Typography fontWeight={600} mt={2} mb={1} variant="body2">
        Longitude
      </Typography>

      <Grid spacing={1} className="grid grid-cols-4 gap-3">
        {field("rem_lngDegree", "Degree", 0, 180, "lng", false, false)}

        {field(
          "rem_lngMinute",
          "Minute",
          0,
          59,
          null,
          isMinSecDisabled(180, navigationalData.rem_lngDegree),
          false
        )}

        {field(
          "rem_lngSecond",
          "Second",
          0,
          59,
          null,
          isMinSecDisabled(180, navigationalData.rem_lngDegree),
          true
        )}

        <Grid item xs={3}>
          <FormControl fullWidth size="small" disabled>
            <InputLabel>Direction</InputLabel>
            <Select
              value={navigationalData.rem_lngDirection || "E"}
              label="Direction"
            >
              <MenuItem value="E">East</MenuItem>
              <MenuItem value="W">West</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Box mt={2}>
        <TextField
          fullWidth
          size="small"
          type="text"
          label="Altitude (Mtr)"
          name="rem_altitude"
          value={navigationalData.rem_altitude ?? ""}
          disabled={!modify}
          onChange={(event) => handleChange(event, 0, 9999, null, true)}
          error={Boolean(helperText.rem_altitude)}
          helperText={helperText.rem_altitude || ""}
          inputProps={{ inputMode: "decimal" }}
        />
      </Box>

      {!toggleView && (
        <Box display="flex" justifyContent="center" mt={2}>
          <MButtonPrimary
            variant="contained"
            startIcon={<Edit />}
            onClick={() => setModify((previous) => !previous)}
            sx={{ minWidth: 110, height: 38, borderRadius: 2 }}
          >
            {modify ? "Done" : "Edit"}
          </MButtonPrimary>
        </Box>
      )}
    </Paper>
  );
};

export default RemoteSite;
