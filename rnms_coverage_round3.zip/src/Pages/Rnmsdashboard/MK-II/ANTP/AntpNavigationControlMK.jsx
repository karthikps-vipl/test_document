import React, { useCallback, useEffect, useMemo, useState } from "react";

import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  TextField,
  CircularProgress,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Autocomplete,
  Switch,
  useTheme,
} from "@mui/material";

import { Save, Edit, Close, Check } from "@mui/icons-material";

import Toast from "@/components/Reusable/Toast/Toast";

import LocalSite from "./LocalSite";
import RemoteSite from "./RemoteSite";
import {
  CALCULATE_DIST,
  GET_ALL_SERIAL_DEVICE_SITES,
  GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS,
  GET_SERIAL_DEVICE_SITES_FOR_GIVEN_ID,
  GET_SWITCH_TO_REMOTE,
  LOS_ANTENNA_ADD_SITE_DATABASE,
} from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { useSelector } from "react-redux";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Confirmation_icon from "../../../../assets/SVGIcons/question_mark.svg";

/* ============================================================
     INITIAL DATA
  ============================================================ */

const INITIAL_DATA = {
  latMinute: "",
  altitude: "",
  siteName: "",
  latSecond: "",
  latDirection: "N",

  lngDegree: "",
  lngMinute: "",
  lngSecond: "",
  lngDirection: "E",

  heading: "",
  latDegree: "",

  rem_latDegree: "",
  rem_latMinute: "",
  rem_latSecond: "",
  rem_latDirection: "N",

  rem_lngDegree: "",
  rem_lngMinute: "",
  rem_lngSecond: "",
  rem_lngDirection: "E",

  rem_altitude: "",
};

/* ============================================================
     RESPONSE NORMALIZATION
  ============================================================ */

const normalizeResponse = (response) => {
  let result = response?.data ?? response;

  if (result?.value !== undefined) {
    result = result.value;
  }

  if (typeof result === "string") {
    try {
      result = JSON.parse(result);
    } catch {
      return null;
    }
  }

  return result;
};

/* ============================================================
     COMPONENT
  ============================================================ */

const AntpNavigationControlMK = ({ node }) => {
  const deviceId = node?.resourceId;

  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";

  const colors = useMemo(
    () => ({
      paper: isDark ? "#1e1e1e" : "#ffffff",
      background: isDark ? "#252525" : "#ffffff",
      border: isDark ? "#404040" : "#e0e0e0",
      heading: isDark ? "#f3f4f6" : "#1f2937",
      text: isDark ? "#9ca3af" : "#4b5563",
    }),
    [isDark]
  );

  /* ============================================================
       STATE
    ============================================================ */

  const [navigationalData, setNavigationalData] = useState({ ...INITIAL_DATA });

  const [allSites, setAllSites] = useState([]);

  const [selectedSite, setSelectedSite] = useState(null);

  const [helperText, setHelperText] = useState({});

  const [calculateDetails, setCalculateDetails] = useState(null);

  const [toggleView, setToggleView] = useState(false);

  //   const [modify, setModify] = useState(false);
  const [localModify, setLocalModify] = useState(false);
  const [remoteModify, setRemoteModify] = useState(false);

  const [loading, setLoading] = useState(true);

  const [enableLocalToRemote, setEnableLocalToRemote] = useState(false);

  const [remoteLoader, setRemoteLoader] = useState(false);

  const [isMounted, setIsMounted] = useState(true);
  const isCnms = useSelector((state) => state.nodeDetails?.isCnms);
  const siteId = node?.siteId;
  const callAntpApi = useCallback(
    async (
      endpoint,
      resourceId = null,
      customPayload = null,
      method = "auto"
    ) => {
      if (!endpoint) {
        throw new Error("ANTP endpoint missing");
      }

      const url = resourceId ? `${endpoint}/${resourceId}` : endpoint;

      let finalMethod;
      if (method === "auto") {
        finalMethod = isCnms ? "post" : "get";
      } else {
        finalMethod = method.toLowerCase();
      }

      // Determine Payload
      let finalPayload;
      if (customPayload !== null) {
        finalPayload = customPayload;
      } else if (method === "auto" && isCnms) {
        finalPayload = { siteId: String(siteId) };
      } else {
        finalPayload = {};
      }

      const response = await ConfigurationAxios(url, finalMethod, finalPayload);
      return response?.data;
    },
    [siteId, isCnms]
  );

  /* ============================================================
       API HANDLER
    ============================================================ */

  const fetchAllSites = useCallback(async () => {
    try {
      const response = await callAntpApi(
        GET_ALL_SERIAL_DEVICE_SITES,
        null,
        null,
        "auto"
      );

      const data = normalizeResponse(response);

      setAllSites(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Fetch sites:", error);
      Toast("Error", "Failed to fetch Sites.", "error");
    }
  }, [callAntpApi]);

  /* ============================================================
       INITIALIZATION
    ============================================================ */

  useEffect(() => {
    setIsMounted(true);

    return () => {
      setIsMounted(false);
    };
  }, []);

  useEffect(() => {
    const initialize = async () => {
      setLoading(true);

      await fetchAllSites();

      if (isMounted) {
        setLoading(false);
      }
    };

    initialize();
  }, [fetchAllSites]);

  /* ============================================================
       FETCH SITE DETAILS
    ============================================================ */

  const getSiteDetailsById = useCallback(
    async (id) => {
      setLoading(true);

      try {
        // Recommended Standard Usage
        const response = await callAntpApi(
          GET_SERIAL_DEVICE_SITES_FOR_GIVEN_ID,
          id,
          null,
          "auto"
        );

        const data = normalizeResponse(response);

        if (!data || typeof data !== "object") {
          throw new Error("Invalid site response");
        }

        setNavigationalData({
          ...INITIAL_DATA,
          ...data,
        });

        setCalculateDetails(null);
        setHelperText({});
      } catch (error) {
        console.error("Fetch site details:", error);

        Toast("Error", "Failed to fetch the site details", "error");
      } finally {
        setLoading(false);
      }
    },
    [callAntpApi]
  );

  /* ============================================================
       RESET
    ============================================================ */

  const reset = useCallback(() => {
    setNavigationalData({ ...INITIAL_DATA });
    setHelperText({});
    setSelectedSite(null);
    setCalculateDetails(null);
  }, []);

  /* ============================================================
       MODE CHANGE
    ============================================================ */

  const handleToggleMode = (event) => {
    const isCreate = event.target.checked;

    setToggleView(isCreate);

    reset();

    setLocalModify(isCreate);
    setRemoteModify(isCreate);
  };

  /* ============================================================
       VALIDATION
    ============================================================ */

  const requiredFields = useMemo(
    () => [
      "siteName",
      "latDegree",
      "latMinute",
      "latSecond",
      "latDirection",
      "lngDegree",
      "lngMinute",
      "lngSecond",
      "lngDirection",
      "heading",
      "altitude",
      "rem_latDegree",
      "rem_latMinute",
      "rem_latSecond",
      "rem_latDirection",
      "rem_lngDegree",
      "rem_lngMinute",
      "rem_lngSecond",
      "rem_lngDirection",
      "rem_altitude",
    ],
    []
  );
  const numericRules = useMemo(
    () => ({
      latDegree: [0, 90, false],
      latMinute: [0, 59, false],
      latSecond: [0, 59, true],

      lngDegree: [0, 180, false],
      lngMinute: [0, 59, false],
      lngSecond: [0, 59, true],

      heading: [0, 359.9, true],
      altitude: [0, 9999, true],

      rem_latDegree: [0, 90, false],
      rem_latMinute: [0, 59, false],
      rem_latSecond: [0, 59, true],

      rem_lngDegree: [0, 180, false],
      rem_lngMinute: [0, 59, false],
      rem_lngSecond: [0, 59, true],

      rem_altitude: [0, 9999, true],
    }),
    []
  );
  const hasInvalidNumericValues = useMemo(
    () =>
      Object.entries(numericRules).some(([key, [min, max, decimal]]) => {
        const value = String(navigationalData[key] ?? "");

        const regex = decimal ? /^\d+(\.\d+)?$/ : /^\d+$/;

        if (!regex.test(value)) return true;

        const number = Number(value);

        return !Number.isFinite(number) || number < min || number > max;
      }),
    [numericRules, navigationalData]
  );

  const isDisabled = useMemo(
    () =>
      requiredFields.some(
        (key) =>
          navigationalData[key] === null ||
          navigationalData[key] === undefined ||
          String(navigationalData[key]).trim() === ""
      ) ||
      hasInvalidNumericValues ||
      Object.values(helperText).some((value) =>
        Boolean(value && value.length > 0)
      ),
    [requiredFields, navigationalData, helperText, hasInvalidNumericValues]
  );

  /* ============================================================
       CALCULATE
    ============================================================ */

  const handleCalculate = async () => {
    if (isDisabled) return;

    setLoading(true);
    setCalculateDetails(null);

    try {
      const response = await callAntpApi(
        CALCULATE_DIST,
        null,
        navigationalData,
        "post"
      );

      const data = normalizeResponse(response);

      const alignResponse = data?.align_RESPONSE ?? data?.data?.align_RESPONSE;

      if (!alignResponse) {
        setEnableLocalToRemote(true);

        Toast("Error", "Failed to calculate", "error");

        return;
      }

      setCalculateDetails({
        azimuth: alignResponse.azimuth,
        elevation: alignResponse.elevation,
      });

      Toast("Success", "Successfully Calculated", "success");
    } catch (error) {
      console.error("Calculate:", error);

      Toast("Error", "Failed to calculate", "error");
    } finally {
      setLoading(false);
    }
  };

  /* ============================================================
       SAVE
    ============================================================ */

  const handleSave = async () => {
    if (isDisabled) return;

    setLoading(true);

    try {
      if (toggleView) {
        const repeatedSite = allSites.find(
          (site) =>
            site.siteName?.toLowerCase() ===
            navigationalData.siteName?.trim().toLowerCase()
        );

        if (repeatedSite) {
          Toast("Error", "Site name already exists.", "error");
          return;
        }
      }
      const response = await callAntpApi(
        LOS_ANTENNA_ADD_SITE_DATABASE,
        null,
        navigationalData,
        "post"
      );

      Toast("Success", "Saved Successfully.", "success");

      reset();

      await fetchAllSites();
    } catch (error) {
      console.error("Save navigation:", error);

      Toast("Error", "Failed to save the data.", "error");
    } finally {
      setLoading(false);
    }
  };

  /* ============================================================
       REMOTE MODE
    ============================================================ */

  const handleSwitchToRemote = async () => {
    setRemoteLoader(true);

    try {
      await callAntpApi(GET_SWITCH_TO_REMOTE, deviceId, null, "auto");

      const response = await callAntpApi(
        GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS,
        deviceId,
        null,
        "auto"
      );

      const data = normalizeResponse(response);

      const isLocal = Boolean(
        data?.localModeStatus ?? data?.data?.localModeStatus
      );

      if (isLocal) {
        Toast("Error", "Failed to switch remote mode", "error");
      } else {
        Toast("Success", "Switched to remote mode.", "success");

        setEnableLocalToRemote(false);
      }
    } catch (error) {
      console.error("Switch remote:", error);

      Toast("Error", "Failed to switch remote mode", "error");
    } finally {
      setRemoteLoader(false);
    }
  };

  /* ============================================================
       RENDER
    ============================================================ */

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: isDark ? "#121212" : "#f4f6f8",
        color: colors.heading,
      }}
    >
      {loading && <LinearProgress sx={{ mb: 1 }} />}

      {/* REMOTE MODE DIALOG */}

      {/* <Dialog open={enableLocalToRemote} maxWidth="xs" fullWidth>
        <DialogTitle>Information</DialogTitle>

        <DialogContent>
          Kindly ensure that remote mode has been selected in the device.
        </DialogContent>

        <DialogActions>
          <MButtonPrimary
            variant="contained"
            onClick={handleSwitchToRemote}
            disabled={remoteLoader}
            startIcon={
              remoteLoader ? (
                <CircularProgress size={18} color="inherit" />
              ) : null
            }
          >
            Switch To Remote Mode
          </MButtonPrimary>

          <MButtonPrimary
            variant="outlined"
            onClick={() => setEnableLocalToRemote(false)}
            disabled={remoteLoader}
          >
            Close
          </MButtonPrimary>
        </DialogActions>
      </Dialog> */}
      <MDialog
        open={enableLocalToRemote}
        title="Information"
        message="Kindly ensure that remote mode has been selected in the device."
        onConfirm={handleSwitchToRemote}
        onClose={() => setEnableLocalToRemote(false)}
        variant="info"
        confirmText="Switch To Remote Mode"
        cancelText="Close"
        icon={Confirmation_icon} // Optional: Dynamic icon
        sx={{ p: 0.25 }}
      />

      {/* SITE SELECTION */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paper,
          borderRadius: 2,
        }}
      >
        <Grid
          spacing={2}
          alignItems="center"
          className="grid grid-cols-3 gap-2"
        >
          {!toggleView && (
            <Grid item xs={12} md={4}>
              <MAlarmSelect
                label="Select Site"
                value={selectedSite?.id ?? ""}
                onChange={(value) => {
                  setCalculateDetails(null);

                  setLocalModify(false);
                  setRemoteModify(false);

                  const site = allSites.find(
                    (item) => String(item.id) === String(value)
                  );

                  setSelectedSite(site || null);

                  if (site) {
                    getSiteDetailsById(site.id);
                  } else {
                    reset();
                  }
                }}
                options={allSites.map((site) => ({
                  value: site.id,
                  label: site.siteName || "",
                }))}
                multiple={false}
                disabled={loading}
                isDark={isDark}
              />
            </Grid>
          )}

          <Grid item xs={12} md={4} mt={!toggleView ? 3 : 0}>
            <TextField
              fullWidth
              size="small"
              label="Site Name"
              value={navigationalData.siteName}
              disabled={!toggleView }
              onChange={(event) => {
                const value = event.target.value;

                setNavigationalData((previous) => ({
                  ...previous,
                  siteName: value,
                }));

                setHelperText((previous) => ({
                  ...previous,
                  siteName:
                    value.length >= 4 && value.length <= 25
                      ? ""
                      : "4 to 25 characters required.",
                }));
              }}
              error={Boolean(helperText.siteName)}
              helperText={helperText.siteName}
            />
          </Grid>

          <Grid item xs={12} md={4} mt={!toggleView ? 3 : 0}>
            <Box
              display="flex"
              alignItems="center"
              justifyContent="center"
              gap={1}
            >
              <Typography fontWeight={600}>Modify</Typography>

              <Switch
                checked={toggleView}
                onChange={handleToggleMode}
                color="primary"
              />

              <Typography fontWeight={600}>Create</Typography>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* LOCAL AND REMOTE SITE */}

      <Grid
        spacing={1}
        sx={{ display: "flex", flexDirection: "column", gap: 1 }}
      >
        <Grid item xs={12} md={6}>
          <LocalSite
            navigationalData={navigationalData}
            setNavigationalData={setNavigationalData}
            helperText={helperText}
            setHelperText={setHelperText}
            toggleView={toggleView}
            modify={localModify}
            setModify={setLocalModify}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <RemoteSite
            navigationalData={navigationalData}
            setNavigationalData={setNavigationalData}
            helperText={helperText}
            setHelperText={setHelperText}
            toggleView={toggleView}
            modify={remoteModify}
            setModify={setRemoteModify}
          />
        </Grid>
      </Grid>

      {/* ACTION BUTTONS */}

      <Box
        display="flex"
        justifyContent="center"
        gap={2}
        mt={2}
        flexWrap="wrap"
      >
        <MButtonPrimary
          variant="contained"
          onClick={handleCalculate}
          disabled={loading || isDisabled}
          sx={{ minWidth: 140, height: 42, borderRadius: 2 }}
        >
          Calculate
        </MButtonPrimary>

        <MButtonPrimary
          variant="contained"
          startIcon={<Save />}
          onClick={handleSave}
          disabled={loading || isDisabled}
          sx={{ minWidth: 140, height: 42, borderRadius: 2 }}
        >
          Save
        </MButtonPrimary>
      </Box>

      {/* CALCULATED RESULTS */}

      {calculateDetails && (
        <Paper
          elevation={0}
          sx={{
            p: 2,
            mt: 2,
            border: `1px solid ${colors.border}`,
            borderRadius: 2,
            backgroundColor: colors.paper,
          }}
        >
          <Typography fontWeight={700} mb={2}>
            Calculated Target Position
          </Typography>

          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label="Target Azimuth (Deg)"
                value={calculateDetails.azimuth ?? ""}
                InputProps={{ readOnly: true }}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                size="small"
                label="Target Elevation (Deg)"
                value={calculateDetails.elevation ?? ""}
                InputProps={{ readOnly: true }}
              />
            </Grid>

            <Grid item xs={12}>
              <Typography textAlign="center" fontWeight={600} color="primary">
                To align, switch to Movement Control and press ALIGN.
              </Typography>
            </Grid>
          </Grid>
        </Paper>
      )}
    </Box>
  );
};

export default AntpNavigationControlMK;
