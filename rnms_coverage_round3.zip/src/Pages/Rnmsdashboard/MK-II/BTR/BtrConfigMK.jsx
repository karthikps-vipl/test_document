import React, { useEffect, useState, useCallback } from "react";
import { useSelector } from "react-redux";
import {
  Box,
  Typography,
  Grid,
  TextField,
  CircularProgress,
  IconButton,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import {
  Update,
  KeyboardArrowUp,
  KeyboardArrowDown,
} from "@mui/icons-material";
import moment from "moment";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  CONFIG_ALL_FIELD_OF_BTR,
  CONFIG_ALL_FIELD_OF_BTR_CNMS,
  GET_BTR_CONFIG_STATUS,
  GET_BTR_CONFIG_STATUS_AT_CNMS,
} from "@/RestAPI/url/endpoint";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MForm from "@/components/Reusable/Form/MForm";
import Toast from "@/components/Reusable/Toast/Toast";

const BtrConfigMK = ({ resourceId, node }) => {
  const theme = useTheme();
  const { isCnms } = useSelector((state) => state?.nodeDetails);
  const siteId = node?.siteId;
  const isDark = theme.palette.mode === "dark";

  // --------------------------------------------------
  // CONFIGURATION STATE
  // --------------------------------------------------

  const [btrConfigData, setBtrConfigData] = useState({
    mhz: "",
    khz: "",
    detectionBandwidth: "",
    sweepBandwidth: "",
    postDetectionBandwidth: "",
  });

  const [btrErrors, setBtrErrors] = useState({
    mhz: "",
    khz: "",
    sweepBandwidth: "",
  });

  const [lastReceived, setLastReceived] = useState("--");
  const [saving, setSaving] = useState(false);
  const [fetching, setFetching] = useState(false);

  // --------------------------------------------------
  // DROPDOWN OPTIONS
  // --------------------------------------------------

  const detectionBandwidthOptions = [
    { label: "2.5 KHz", value: "2.5" },
    { label: "4 KHz", value: "4.0" },
    { label: "280 KHz", value: "280.0" },
  ];

  // --------------------------------------------------
  // VALIDATION
  // --------------------------------------------------

  const validateField = (field, value) => {
    let min;
    let max;
    let label;

    switch (field) {
      case "mhz":
        min = 950;
        max = 1749;
        label = "Beacon Frequency (MHz)";
        break;

      case "khz":
        min = 0;
        max = 999;
        label = "Beacon Frequency (KHz)";
        break;

      case "sweepBandwidth":
        min = 20;
        max = 150;
        label = "Sweep Bandwidth";
        break;

      default:
        return "";
    }

    if (
      value === "" ||
      value === null ||
      value === undefined ||
      !Number.isFinite(Number(value)) ||
      Number(value) < min ||
      Number(value) > max
    ) {
      return `${label} must be between ${min} and ${max}`;
    }

    return "";
  };

  const validateAllFields = useCallback(() => {
    const errors = {
      mhz: validateField("mhz", btrConfigData.mhz),
      khz: validateField("khz", btrConfigData.khz),
      sweepBandwidth: validateField(
        "sweepBandwidth",
        btrConfigData.sweepBandwidth
      ),
    };

    setBtrErrors(errors);

    return Object.values(errors).every((error) => error === "");
  }, [btrConfigData]);

  // --------------------------------------------------
  // INPUT HANDLING
  // --------------------------------------------------

  const handleInputChange = (field, value) => {
    if (value !== "" && !/^\d*$/.test(String(value))) return;

    setBtrConfigData((prev) => ({
      ...prev,
      [field]: value,
    }));

    setBtrErrors((prev) => ({
      ...prev,
      [field]: validateField(field, value),
    }));
  };

  const handleDetectionBandwidthChange = (value) => {
    let postDetectionBandwidth = "";

    if (value === "2.5") {
      postDetectionBandwidth = "1";
    } else if (value === "4.0") {
      postDetectionBandwidth = "2";
    } else {
      postDetectionBandwidth = "3";
    }

    setBtrConfigData((prev) => ({
      ...prev,
      detectionBandwidth: value,
      postDetectionBandwidth,
    }));
  };

  // --------------------------------------------------
  // INCREMENT / DECREMENT
  // --------------------------------------------------

  const handleStepChange = (field, direction) => {
    const ranges = {
      mhz: { min: 950, max: 1749 },
      khz: { min: 0, max: 999 },
      sweepBandwidth: { min: 20, max: 150 },
    };

    const { min, max } = ranges[field];

    setBtrConfigData((prev) => {
      const currentValue = Number(prev[field]);
      let nextValue = currentValue + direction;

      if (nextValue > max) nextValue = min;
      if (nextValue < min) nextValue = max;

      return {
        ...prev,
        [field]: String(nextValue),
      };
    });

    setBtrErrors((prev) => ({
      ...prev,
      [field]: "",
    }));
  };

  // --------------------------------------------------
  // RESPONSE PARSING
  // --------------------------------------------------

  const parseBtrResponse = (data) => {
    let configData = data;

    if (isCnms) {
      configData = JSON.parse(data?.value || "{}");
    }

    const frequency = String(configData?.beaconFrequency || "950.0");
    const frequencyParts = frequency.split(".");

    const mhz = frequencyParts[0] || "950";
    const khz = frequencyParts[1] || "0";

    let detectionBandwidth = String(configData?.detectionBandwidth || "");

    // Older configuration responses may contain the mapped value.
    if (detectionBandwidth === "1") detectionBandwidth = "2.5";
    else if (detectionBandwidth === "2") detectionBandwidth = "4.0";
    else if (detectionBandwidth === "3") detectionBandwidth = "280.0";

    let postDetectionBandwidth = configData?.postDetectionBandwidth || "";

    if (!postDetectionBandwidth) {
      if (detectionBandwidth === "2.5") {
        postDetectionBandwidth = "1";
      } else if (detectionBandwidth === "4.0") {
        postDetectionBandwidth = "2";
      } else {
        postDetectionBandwidth = "3";
      }
    }

    return {
      mhz,
      khz,
      detectionBandwidth,
      sweepBandwidth: String(configData?.sweepBandwidth ?? ""),
      postDetectionBandwidth: String(postDetectionBandwidth),
    };
  };

  // --------------------------------------------------
  // FETCH CONFIGURATION
  // --------------------------------------------------

  const fetchConfigData = useCallback(async () => {
    if (!resourceId) return;

    setFetching(true);

    try {
      let response;

      if (isCnms) {
        response = await ConfigurationAxios(
          `${GET_BTR_CONFIG_STATUS_AT_CNMS}/${resourceId}`,
          "post",
          { siteId: siteId }
        );
      } else {
        response = await ConfigurationAxios(
          `${GET_BTR_CONFIG_STATUS}/${resourceId}`,
          "get"
        );
      }
      if (response?.data?.status) {
        const data = response.data.data;

        if (response.data.status === 7) {
          Toast(
            "Error",
            response.data.message || "BTR configuration returned an error",
            "error"
          );
        }

        const parsedData = parseBtrResponse(data);

        setBtrConfigData(parsedData);

        setLastReceived(
          data?.readingTime
            ? moment(data.readingTime).format("DD-MM-YYYY HH:mm:ss")
            : "--"
        );

        setBtrErrors({
          mhz: "",
          khz: "",
          sweepBandwidth: "",
        });
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to fetch BTR configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("BTR Fetch Error:", error);

      Toast(
        "Error",
        error?.response?.data?.message || "Failed to fetch BTR configuration",
        "error"
      );
    } finally {
      setFetching(false);
    }
  }, [resourceId, siteId, isCnms]);

  // --------------------------------------------------
  // INITIAL FETCH + POLLING
  // --------------------------------------------------

  useEffect(() => {
    if (!resourceId) return undefined;

    fetchConfigData();

    const polling = setInterval(
      () => {
        fetchConfigData();
      },
      isCnms ? 60000 : 30000
    );

    return () => clearInterval(polling);
  }, [fetchConfigData, resourceId, isCnms]);

  // --------------------------------------------------
  // SAVE CONFIGURATION
  // --------------------------------------------------

  const handleSaveBtrConfig = async () => {
    if (!validateAllFields()) {
      Toast("Error", "Please correct the BTR configuration fields.", "error");
      return;
    }

    if (
      !btrConfigData.detectionBandwidth ||
      !btrConfigData.postDetectionBandwidth
    ) {
      Toast("Error", "Please select Detection Bandwidth.", "error");
      return;
    }

    try {
      setSaving(true);

      const beaconFrequency = `${btrConfigData.mhz}.${String(
        btrConfigData.khz
      ).padStart(1, "0")}`;

      const payload = {
        beaconFrequency,
        detectionBandwidth: btrConfigData.postDetectionBandwidth,
        sweepBandwidth: Number(btrConfigData.sweepBandwidth),
      };

      let response;

      if (isCnms) {
        response = await ConfigurationAxios(
          `${CONFIG_ALL_FIELD_OF_BTR_CNMS}/${resourceId}`,
          "post", // Assuming this is a POST request based on "configAllField" context, adjust if it's "get"
          {
            siteId: siteId,
            ...payload,
          }
        );
      } else {
        response = await ConfigurationAxios(
          `${CONFIG_ALL_FIELD_OF_BTR}/${resourceId}`,
          "post", // Adjust "post" to "get" if this endpoint is actually a retrieval
          {
            ...payload,
          }
        );
      }

      if (response?.data?.status) {
        const { data, message, status } = response.data;

        if (data?.readingTime) {
          setLastReceived(
            moment(data.readingTime).format("DD-MM-YYYY HH:mm:ss")
          );
        }

        if (status === 7) {
          Toast("Error", message || "BTR configuration update failed", "error");

          await fetchConfigData();
          return;
        }

        Toast("Success", "BTR Configuration Saved Successfully", "success");

        await fetchConfigData();
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to save BTR configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("BTR Save Error:", error);

      Toast(
        "Error",
        error?.response?.data?.message || "Failed to save BTR configuration",
        "error"
      );
    } finally {
      setSaving(false);
    }
  };

  // --------------------------------------------------
  // REUSABLE NUMERIC INPUT
  // --------------------------------------------------

  const renderNumericInput = (
    label,
    field,
    min,
    max,
    unit,
    showStepper = false
  ) => (
    <Box sx={{ mb: 1 }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "flex-start",
          gap: 0.5,
        }}
      >
        <TextField
          fullWidth
          size="small"
          label={label}
          value={btrConfigData[field]}
          onChange={(e) => handleInputChange(field, e.target.value)}
          error={!!btrErrors[field]}
          helperText={
            btrErrors[field] || `Allowed range: ${min} - ${max} ${unit}`
          }
          inputProps={{
            inputMode: "numeric",
          }}
          disabled={saving}
          sx={{
            "& .MuiInputBase-root": {
              fontFamily: "Montserrat",
              backgroundColor: isDark ? "#252525" : "white",
              borderRadius: 2,
            },
            "& .MuiInputLabel-root": {
              fontFamily: "Montserrat",
            },
          }}
        />

        {showStepper && (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mt: 0.3,
            }}
          >
            <IconButton
              size="small"
              disabled={saving}
              onClick={() => handleStepChange(field, 1)}
              sx={{ p: 0 }}
            >
              <KeyboardArrowUp fontSize="small" />
            </IconButton>

            <IconButton
              size="small"
              disabled={saving}
              onClick={() => handleStepChange(field, -1)}
              sx={{ p: 0 }}
            >
              <KeyboardArrowDown fontSize="small" />
            </IconButton>
          </Box>
        )}
      </Box>
    </Box>
  );

  // --------------------------------------------------
  // RENDER
  // --------------------------------------------------

  return (
    <Box
      sx={{
        width: "100%",
        backgroundColor: isDark ? "background.default" : "#ffffff",
        p: 1,
      }}
    >
      {/* LAST RECEIVED */}

      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          gap: 1,
          mb: 2,
        }}
      >
        <Typography
          sx={{
            fontSize: "13px",
            color: "text.secondary",
            fontWeight: 500,
            fontFamily: "Montserrat",
          }}
        >
          Last Received Data:
        </Typography>

        <Typography
          sx={{
            fontSize: "13px",
            fontWeight: 600,
            color: "primary.main",
            fontFamily: "Montserrat",
          }}
        >
          {lastReceived}
        </Typography>
      </Box>

      {fetching && (
        <Box sx={{ mb: 1 }}>
          <CircularProgress size={18} />
        </Box>
      )}

      <MForm title="BTR Configuration" paddingX={2}>
        <Grid spacing={2} className="grid grid-cols-2 gap-2">
          {/* BEACON FREQUENCY MHz */}

          <Grid item xs={12} md={6}>
            {renderNumericInput(
              "Beacon Frequency (MHz)",
              "mhz",
              950,
              1749,
              "MHz",
              true
            )}
          </Grid>

          {/* BEACON FREQUENCY KHz */}

          <Grid item xs={12} md={6}>
            {renderNumericInput(
              "Beacon Frequency (KHz)",
              "khz",
              0,
              999,
              "KHz",
              true
            )}
          </Grid>

          {/* DETECTION BANDWIDTH */}

          <Grid item xs={12} md={6}>
            <Box sx={{ mb: 1 }}>
              <Typography
                sx={{
                  fontSize: "13px",
                  fontWeight: 500,
                  color: "text.secondary",
                  mb: 0.5,
                  fontFamily: "Montserrat",
                }}
              >
                Detection Bandwidth (KHz)
              </Typography>

              <MAlarmSelect
                label=""
                value={btrConfigData.detectionBandwidth}
                onChange={handleDetectionBandwidthChange}
                options={detectionBandwidthOptions}
                disabled={saving}
                multiple={false}
                isDark={isDark}
              />
            </Box>
          </Grid>

          {/* SWEEP BANDWIDTH */}

          <Grid item xs={12} md={6} mt={3}>
            {renderNumericInput(
              "Sweep Bandwidth (KHz)",
              "sweepBandwidth",
              20,
              150,
              "KHz",
              true
            )}
          </Grid>
        </Grid>

        {/* SAVE BUTTON */}

        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            mt: 2,
          }}
        >
          <MButtonPrimary
            variant="contained"
            onClick={handleSaveBtrConfig}
            disabled={
              saving ||
              fetching ||
              Object.values(btrErrors).some((error) => error !== "") ||
              !btrConfigData.mhz ||
              btrConfigData.khz === "" ||
              !btrConfigData.sweepBandwidth ||
              !btrConfigData.detectionBandwidth
            }
            startIcon={
              saving ? (
                <CircularProgress size={18} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            {saving ? "Saving..." : "Apply"}
          </MButtonPrimary>
        </Box>
      </MForm>
    </Box>
  );
};

export default BtrConfigMK;
