import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Box,
  Typography,
  Grid,
  Paper,
  TextField,
  CircularProgress,
  LinearProgress,
  Divider,
  useTheme,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

import Toast from "@/components/Reusable/Toast/Toast";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";

import {
  GET_BTR_ALL_STATUS,
  GET_BTR_ALL_STATUS_AT_CNMS,
} from "@/RestAPI/url/endpoint";

/* ============================================================================
 * THEME COLORS
 * ========================================================================== */

const getBtrColors = (isDark) => ({
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  cardBg: isDark ? "#252525" : "#ffffff",

  border: isDark ? "#3a3a3a" : "#e0e0e0",
  innerBorder: isDark ? "#404040" : "#e5e7eb",

  heading: isDark ? "#f3f4f6" : "#1f2937",
  text: isDark ? "#9ca3af" : "#4b5563",
  muted: isDark ? "#6b7280" : "#9ca3af",

  successBg: isDark ? "#14291e" : "#f0fdf4",
  successBorder: isDark ? "#285b3b" : "#bbf7d0",
  successText: isDark ? "#86efac" : "#15803d",

  dangerBg: isDark ? "#2a1515" : "#fef2f2",
  dangerBorder: isDark ? "#7f1d1d" : "#fecaca",
  dangerText: isDark ? "#fca5a5" : "#b91c1c",
});

/* ============================================================================
 * STATUS BADGE
 * ========================================================================== */

const StatusBadge = ({ status, colors }) => {
  if (status === null || status === undefined || status === "") {
    return (
      <Typography variant="body2" sx={{ color: colors.muted }}>
        --
      </Typography>
    );
  }

  const ok = String(status).toLowerCase() === "ok";

  return (
    <Box
      sx={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        minWidth: 70,
        height: 26,
        px: 1,
        borderRadius: 1,
        fontWeight: 700,
        fontSize: 12,
        backgroundColor: ok ? colors.successBg : colors.dangerBg,
        border: `1px solid ${ok ? colors.successBorder : colors.dangerBorder}`,
        color: ok ? colors.successText : colors.dangerText,
      }}
    >
      {ok ? "OK" : "Not OK"}
    </Box>
  );
};

/* ============================================================================
 * INFORMATION ROW
 * ========================================================================== */

const InfoRow = ({ label, children, colors, labelWidth = 190 }) => (
  <Box
    sx={{
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 1,
      py: 1,
    }}
  >
    <Typography
      variant="body2"
      sx={{
        minWidth: labelWidth,
        fontWeight: 600,
        color: colors.text,
      }}
    >
      {label}
    </Typography>

    <Box
      sx={{
        color: colors.heading,
        fontSize: 14,
        fontWeight: 500,
      }}
    >
      {children ?? "--"}
    </Box>
  </Box>
);

/* ============================================================================
 * READ ONLY FIELD
 * ========================================================================== */

const ReadOnlyField = ({ label, value }) => (
  <TextField
    label={label}
    size="small"
    variant="outlined"
    fullWidth
    value={value ?? "--"}
    InputProps={{
      readOnly: true,
    }}
    InputLabelProps={{
      shrink: true,
    }}
  />
);

/* ============================================================================
 * RESPONSE PARSER
 * ========================================================================== */

const parseBtrResponse = (data, isCnms) => {
  try {
    const rawData = isCnms ? data?.value : data;

    if (!rawData) return null;

    return typeof rawData === "string" ? JSON.parse(rawData) : rawData;
  } catch (error) {
    console.error("BTR response parsing failed:", error);
    return null;
  }
};

/* ============================================================================
 * COMPONENT
 * ========================================================================== */

const BtrStatusMK = ({ node }) => {
  const resId = node?.resourceId;
  const siteId = node?.siteId;

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const colors = getBtrColors(isDark);

  const dispatch = useDispatch();

  /* ==========================================================================
   * STATE
   * ======================================================================== */

  const [btrStatus, setBtrStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [lastReceivedDate, setLastReceivedDate] = useState("--");
  /* ==========================================================================
   * REFS
   * ======================================================================== */

  const isMountedRef = useRef(false);
  const pollIntervalRef = useRef(null);

  /* ==========================================================================
   * MOUNT / UNMOUNT
   * ======================================================================== */

  useEffect(() => {
    isMountedRef.current = true;

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  /* ==========================================================================
   * FETCH BTR STATUS
   *
   * CNMS:
   * - POST request
   * - Pass siteId in request body
   * - Response data is inside data.value
   *
   * NON-CNMS:
   * - GET request
   * - Response data is directly available in data
   *
   * status === 7:
   * - Parse and display returned status data
   * - Show error toast
   * ======================================================================== */

  const fetchBtrStatus = useCallback(async () => {
    if (!resId || !isMountedRef.current) return;

    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${isCnms ? GET_BTR_ALL_STATUS_AT_CNMS : GET_BTR_ALL_STATUS}/${resId}`,
        isCnms ? "post" : "get",
        isCnms
          ? {
              siteId: String(siteId),
            }
          : {}
      );

      if (!isMountedRef.current) return;

      const res = response?.data;
      const formattedTime = res?.data?.readingTime
        ? moment(res.data.readingTime).format("DD-MM-YYYY HH:mm:ss")
        : "- -";

      // 2. Update the state with the formatted time
      setLastReceivedDate(formattedTime);
      if (res) {
        const { data, message, status } = res;

        if (status) {
          const parsed = parseBtrResponse(data, isCnms);

          if (parsed) {
            setBtrStatus(parsed);
          }

          if (status === 7) {
            Toast("Error", message || "BTR status warning", "error");
          }
        } else {
          Toast("Error", message || "Failed to fetch BTR status", "error");
        }
      }
    } catch (error) {
      if (!isMountedRef.current) return;

      Toast(
        "Error",
        error?.response?.data?.message || error?.message || "Network Error!",
        "error"
      );
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
        setIsInitialLoading(false);
      }
    }
  }, [resId, siteId, isCnms, dispatch]);

  /* ==========================================================================
   * POLLING
   *
   * CNMS     : 60 seconds
   * NON-CNMS : 30 seconds
   * ======================================================================== */

  useEffect(() => {
    if (!resId) {
      setIsInitialLoading(false);
      return;
    }

    fetchBtrStatus();

    pollIntervalRef.current = setInterval(
      fetchBtrStatus,
      isCnms ? 60000 : 30000
    );

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
        pollIntervalRef.current = null;
      }
    };
  }, [resId, isCnms, fetchBtrStatus]);

  /* ==========================================================================
   * INITIAL LOADING
   * ======================================================================== */

  if (isInitialLoading) {
    return (
      <Box
        sx={{
          p: 1,
          backgroundColor: colors.pageBg,
        }}
      >
        <Paper
          elevation={0}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            minHeight: 350,
            borderRadius: 2,
            border: `1px solid ${colors.border}`,
            backgroundColor: colors.paperBg,
          }}
        >
          <CircularProgress size={40} />

          <Typography
            variant="body1"
            sx={{
              ml: 2,
              color: colors.heading,
            }}
          >
            Loading BTR Status...
          </Typography>
        </Paper>
      </Box>
    );
  }

  /* ==========================================================================
   * RENDER
   * ======================================================================== */

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: colors.pageBg,
        color: colors.heading,
      }}
    >
      {/* Polling progress */}

      {loading && <LinearProgress sx={{ mb: 1 }} />}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          mb: 1,
          gap: 1,
        }}
      >
        <Typography
          variant="body2"
          sx={{
            color: colors.text,
            fontWeight: 600,
          }}
        >
          Last Received:
        </Typography>

        <Typography
          variant="body2"
          sx={{
            color: colors.heading,
            fontWeight: 700,
          }}
        >
          {lastReceivedDate}
        </Typography>
      </Box>

      {/* ================================================================
       * DEVICE INFORMATION
       * ================================================================ */}
      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              md: "repeat(2, 1fr)",
            },
            gap: "15px",
          }}
        >
          <ReadOnlyField
            label="Firmware Version"
            value={btrStatus?.softwareVersion}
          />

          <ReadOnlyField label="Access Mode" value={btrStatus?.accessMode} />
        </Grid>
      </Paper>

      {/* ================================================================
       * SYSTEM HEALTH STATUS
       * ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              md: "repeat(2, 1fr)",
            },
            gap: "5px 20px",
          }}
        >
          <Box
            sx={{
              backgroundColor: colors.cardBg,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 1,
              px: 1,
            }}
          >
            <InfoRow label="System Status:" colors={colors}>
              <StatusBadge status={btrStatus?.systemStatus} colors={colors} />
            </InfoRow>
          </Box>

          <Box
            sx={{
              backgroundColor: colors.cardBg,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 1,
              px: 1,
            }}
          >
            <InfoRow label="Chassis Temperature:" colors={colors}>
              <StatusBadge
                status={btrStatus?.chassisTempStatus}
                colors={colors}
              />
            </InfoRow>
          </Box>

          <Box
            sx={{
              backgroundColor: colors.cardBg,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 1,
              px: 1,
            }}
          >
            <InfoRow label="PLL Locked:" colors={colors}>
              <StatusBadge status={btrStatus?.pllStatus} colors={colors} />
            </InfoRow>
          </Box>

          <Box
            sx={{
              backgroundColor: colors.cardBg,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 1,
              px: 1,
            }}
          >
            <InfoRow label="DC Power Supply Status:" colors={colors}>
              <StatusBadge status={btrStatus?.dcPowerStatus} colors={colors} />
            </InfoRow>
          </Box>

          <Box
            sx={{
              backgroundColor: colors.cardBg,
              border: `1px solid ${colors.innerBorder}`,
              borderRadius: 1,
              px: 1,
              gridColumn: {
                xs: "auto",
                md: "1 / -1",
              },
            }}
          >
            <InfoRow label="RF Synthesizer:" colors={colors}>
              <StatusBadge status={btrStatus?.rfStatus} colors={colors} />
            </InfoRow>
          </Box>
        </Grid>
      </Paper>

      {/* ================================================================
       * BEACON INFORMATION
       * ================================================================ */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          borderRadius: 2,
          border: `1px solid ${colors.border}`,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              md: "repeat(2, 1fr)",
            },
            gap: "15px",
          }}
        >
          <ReadOnlyField
            label="Beacon Frequency (MHz)"
            value={btrStatus?.beaconFrequency}
          />

          <ReadOnlyField
            label="Beacon Level (dBm)"
            value={btrStatus?.beaconLevel}
          />

          <ReadOnlyField
            label="Detection Bandwidth (KHz)"
            value={btrStatus?.detectionBandwidth}
          />

          <ReadOnlyField
            label="Sweep Bandwidth (KHz)"
            value={btrStatus?.sweepBandwidth}
          />
        </Grid>
      </Paper>
    </Box>
  );
};

export default BtrStatusMK;
