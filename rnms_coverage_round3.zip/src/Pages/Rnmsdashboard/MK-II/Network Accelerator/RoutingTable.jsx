import React, { useMemo } from "react";

import { Box } from "@mui/material";

import MTable from "@/components/Reusable/Table/MTable";

const RoutingTable = ({ data }) => {
  /* =========================================================
      TABLE COLUMNS
  ========================================================= */

  const columns = [
    {
      name: "S.No.",
      uid: "index",
    },
    {
      name: "Destination",
      uid: "destinationIp",
    },
    {
      name: "Mask",
      uid: "subnetIp",
    },
    {
      name: "Gateway",
      uid: "gateway",
    },
  ];

  /* =========================================================
      TRANSFORM ROUTING TABLE DATA
  ========================================================= */

  const rows = useMemo(() => {
    const routingData = data?.routingTableBeanList;

    if (!Array.isArray(routingData)) {
      return [];
    }

    return routingData.map((item, index) => ({
      ...item,

      index: index + 1,

      destinationIp: item?.destinationIp ?? "--",

      subnetIp: item?.subnetIp ?? "--",

      gateway: item?.gateway ?? "--",
    }));
  }, [data]);

  /* =========================================================
      RENDER
  ========================================================= */

  return (
    <Box
      sx={{
        width: "100%",
        border: "1px solid",
        borderColor: "primary.main",
        borderRadius: 1,
        p: 1,
        mb: 2,
      }}
    >
      <MTable
        tableTitle="Routing Table"
        columns={columns}
        tableData={rows}
        showSearch={false}
        showPagination={true}
        showMaximazed={false}
        closeIcon={false}
      />
    </Box>
  );
};

export default RoutingTable;
