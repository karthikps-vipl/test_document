import React, { useCallback, useEffect, useRef, useState } from "react";

import { Box, LinearProgress, Typography } from "@mui/material";
import { useSelector } from "react-redux";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";



import Toast from "@/components/Reusable/Toast/Toast";

import BridgeMode from "./BridgeMode";
import { GET_ALL_NETWORK_ACCELERATOR_RESPONSE, GET_ALL_NETWORK_ACCELERATOR_RESPONSE_CNMS } from "@/RestAPI/url/endpoint";

const NetworkAcceleratorStatusMk = ({ resource, resourceId, siteId }) => {
  const isCnms = useSelector((state) => state.nodeDetails?.isCnms);

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const isMountedRef = useRef(false);
  const intervalRef = useRef(null);
  const requestInProgressRef = useRef(false);

  /* =========================================================
      PARSE RESPONSE DATA
  ========================================================= */

  const parseResponseData = (responseData, status) => {
    try {
      if (isCnms) {
        const rawData = responseData?.value;

        return typeof rawData === "string"
          ? JSON.parse(rawData)
          : rawData;
      }

      if (status === 7 && responseData?.value !== undefined) {
        const rawData = responseData.value;

        return typeof rawData === "string"
          ? JSON.parse(rawData)
          : rawData;
      }

      return typeof responseData === "string"
        ? JSON.parse(responseData)
        : responseData;
    } catch (error) {
      console.error("Failed to parse Network Accelerator data:", error);
      return null;
    }
  };

  /* =========================================================
      FETCH NETWORK ACCELERATOR DATA
  ========================================================= */

  const fetchData = useCallback(async () => {
    if (!isMountedRef.current || requestInProgressRef.current) {
      return;
    }

    requestInProgressRef.current = true;
    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        isCnms
          ? `${GET_ALL_NETWORK_ACCELERATOR_RESPONSE_CNMS}/${resourceId}`
          : `${GET_ALL_NETWORK_ACCELERATOR_RESPONSE}/${resourceId}`,

        isCnms ? "post" : "get",

        isCnms
          ? { siteId: String(siteId) }
          : {}
      );

      if (!isMountedRef.current) return;

      const result = response?.data;

      if (!result) {
        setError("Failed to fetch Network Accelerator data");
        return;
      }

      const { data: responseData, message, status } = result;

      if (status) {
        const parsedData = parseResponseData(responseData, status);

        if (!parsedData) {
          setError("Failed to parse Network Accelerator data");
          return;
        }

        setError("");
        setData(parsedData);

        if (status === 7) {
          Toast(
            "Error",
            message || "Network Accelerator status warning",
            "error"
          );
        }
      } else {
        setError(message || "Failed to fetch Network Accelerator data");

        Toast(
          "Error",
          message || "Failed to fetch Network Accelerator data",
          "error"
        );
      }
    } catch (error) {
      if (!isMountedRef.current) return;

      setError(
        error?.response?.data?.message ||
        error?.message ||
        "Failed to fetch Network Accelerator data"
      );

      Toast(
        "Error",
        error?.response?.data?.message ||
        error?.message ||
        "Something went wrong",
        "error"
      );
    } finally {
      requestInProgressRef.current = false;

      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [isCnms, resourceId, siteId]);

  /* =========================================================
      MOUNT / UNMOUNT AND POLLING
  ========================================================= */

  useEffect(() => {
    isMountedRef.current = true;

    fetchData();

    intervalRef.current = setInterval(
      fetchData,
      isCnms ? 60000 : 30000
    );

    return () => {
      isMountedRef.current = false;

      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }

      requestInProgressRef.current = false;
    };
  }, [fetchData, isCnms]);

  /* =========================================================
      RENDER
  ========================================================= */

  return (
    <Box sx={{ width: "100%", mb: 1 }}>

      {loading && <LinearProgress sx={{ mb: 1 }} />}

      {error && !data && (
        <Typography color="error" align="center">
          {error}
        </Typography>
      )}

      {data && <BridgeMode data={data} />}

      {!loading && !error && !data && (
        <Typography color="error" align="center">
          Something went wrong!
        </Typography>
      )}

    </Box>
  );
};

export default NetworkAcceleratorStatusMk;