import React from "react";

import { Box, Grid, TextField, Typography } from "@mui/material";

// Replace with your actual reusable TextField import

import RoutingTable from "./RoutingTable";

const BridgeMode = ({ data }) => {
  const isRouterMode = data?.mode === "Router Mode";

  /* =========================================================
      COMMON FIELD COMPONENT
  ========================================================= */

  const renderField = (label, value) => (
    <TextField
    label={label}
    size="small"
    variant="outlined"
    fullWidth
    value={value ?? "--"}
    />
  );

  /* =========================================================
      BRIDGE / SAT INTERFACE
  ========================================================= */

  const renderBridgeInterface = () => (
    <Box
      sx={{
        border: "1px solid",
        borderRadius: 1,
        p: 1,
        mb: 2,
      }}
    >
      <Typography
        variant="body1"
        fontWeight="bold"
        mb={2}
      >
        Bridge/SAT Interface
      </Typography>

      <Grid container spacing={2}>
        <Grid item xs={12}>
          {renderField("IP Address", data?.satInterfaceIp)}
        </Grid>

        <Grid item xs={12}>
          {renderField("Subnet Mask", data?.satInterfaceSubnetIp)}
        </Grid>
      </Grid>
    </Box>
  );

  /* =========================================================
      ROUTER / BRIDGE DETAILS
  ========================================================= */

  return (
    <Box sx={{ width: "100%" }}>
      {isRouterMode ? <RoutingTable data={data} /> : renderBridgeInterface()}

      <Box
        sx={{
          maxWidth: 600,
          mt: 1,
        }}
      >
        <Grid spacing={2} className="grid grid-cols-1 gap-3">
          <Grid item xs={12}>
            {renderField("Mode", data?.mode)}
          </Grid>

          <Grid item xs={12}>
            {renderField("RTT (Round Trip Time msec)", data?.rtt)}
          </Grid>

          <Grid item xs={12}>
            {renderField("UpLink Data Rate (bps)", data?.uplinkDataRate)}
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default BridgeMode;
