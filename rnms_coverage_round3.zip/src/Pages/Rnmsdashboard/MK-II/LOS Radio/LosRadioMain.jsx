import React, { useCallback, useEffect, useRef, useState } from "react";
import { Box, LinearProgress, Typography } from "@mui/material";
import { useSelector } from "react-redux";

import moment from "moment";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_DEVICE_STATUS_RADIO } from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import LosRadioStatus from "./LosRadioStatus";
import ClientsTableLos from "./ClientsTableLos";

const LosRadioMain = ({ node }) => {
  const resourceId = node?.resourceId;
  const siteId = node?.siteId;
  console.log("");
  const isCnms = useSelector((state) => state.nodeDetails?.isCnms);

  const [radioData, setRadioData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastReceivedDate, setLastReceivedDate] = useState("--");

  const isMountedRef = useRef(false);
  const requestInProgressRef = useRef(false);
  const intervalRef = useRef(null);

  const fetchRadioData = useCallback(async () => {
    if (!resourceId || !isMountedRef.current || requestInProgressRef.current) {
      return;
    }

    requestInProgressRef.current = true;
    setLoading(true);

    try {
      const response = await ConfigurationAxios(
        `${FETCH_DEVICE_STATUS_RADIO}/${resourceId}/STATUS`,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : {}
      );

      if (!isMountedRef.current) return;

      const result = response?.data;

      if (!result) {
        Toast("Error", "Failed to fetch LOS Radio status", "error");
        return;
      }

      const { data, message, status } = result;

      if (status === 1 || status === 7) {
        let parsedData = data;

        // CNMS response
        if (isCnms || status === 7) {
          parsedData = data?.value;
        }

        if (typeof parsedData === "string") {
          parsedData = JSON.parse(parsedData);
        }

        if (!parsedData) {
          Toast("Error", "Unable to parse LOS Radio response", "error");
          return;
        }

        setRadioData(parsedData);

        setLastReceivedDate(
          parsedData?.clientStatus?.[0]?.readingTime
            ? moment(parsedData.clientStatus[0].readingTime).format(
                "DD-MM-YYYY HH:mm:ss"
              )
            : "--"
        );

        if (status === 7) {
          Toast("Error", message || "LOS Radio status warning", "error");
        }
      } else {
        Toast("Error", message || "Failed to fetch LOS Radio status", "error");
      }
    } catch (error) {
      if (!isMountedRef.current) return;

      Toast(
        "Error",
        error?.response?.data?.message ||
          error?.message ||
          "Failed to fetch LOS Radio status",
        "error"
      );
    } finally {
      requestInProgressRef.current = false;

      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [resourceId, siteId, isCnms]);

  useEffect(() => {
    isMountedRef.current = true;

    if (!resourceId) {
      setLoading(false);
      return;
    }

    fetchRadioData();

    intervalRef.current = setInterval(fetchRadioData, isCnms ? 60000 : 30000);

    return () => {
      isMountedRef.current = false;

      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [fetchRadioData, resourceId, isCnms]);

  return (
    <Box>
      {loading && <LinearProgress />}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          mb: 1.5,
          gap: 1,
        }}
      >
        <Typography variant="body2">Last Received:</Typography>

        <Typography variant="body2" fontWeight={700}>
          {lastReceivedDate ?? "--"}
        </Typography>
      </Box>
      <ClientsTableLos rows={radioData?.clientStatus || []} loading={loading} />

      <LosRadioStatus
        losStatus={radioData}
        loading={loading}
        // lastReceivedDate={lastReceivedDate}
      />
    </Box>
  );
};

export default LosRadioMain;
