import React from "react";

import { Box, Grid, Paper, TextField, Typography } from "@mui/material";

import { useTheme } from "@mui/material";

const getLosColors = (isDark) => ({
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  border: isDark ? "#3a3a3a" : "#e0e0e0",
  heading: isDark ? "#f3f4f6" : "#1f2937",
  text: isDark ? "#9ca3af" : "#4b5563",
});

const ReadOnlyField = ({ label, value, colors, statusField = false }) => {
  const status = String(value ?? "").toLowerCase();

  const backgroundColor = statusField
    ? status === "ok"
      ? "#aef690"
      : status === "not ok"
      ? "#e38d96"
      : "transparent"
    : "transparent";

  return (
    <TextField
      label={label}
      size="small"
      variant="outlined"
      fullWidth
      value={value ?? "--"}
      InputProps={{ readOnly: true }}
      InputLabelProps={{ shrink: true }}
      sx={{
        "& .MuiInputBase-root": {
          backgroundColor,
          color: colors.heading,
        },
      }}
    />
  );
};

const SectionCard = ({ title, children, colors }) => (
  <Paper
    elevation={0}
    sx={{
      p: 1.5,
      borderRadius: 2,
      border: `1px solid ${colors.border}`,
      backgroundColor: colors.paperBg,
    }}
  >
    <Typography
      variant="subtitle1"
      sx={{
        fontWeight: 700,
        color: colors.heading,
        mb: 1.5,
      }}
    >
      {title}
    </Typography>

    {children}
  </Paper>
);

const WirelessInterface = ({ title, data, colors }) => {
  const fields = [
    ["Frequency Band", data?.frequencyBand],
    ["MAC Address", data?.MACAddress],
    ["Wireless Mode", data?.wirelessMode],
    ["Wireless NW Mode", data?.wirelessNWMode],
    ["Frequency (MHz)", data?.frequency],
    ["SSID", data?.SSID],
    ["Scan List", data?.scanlist],
    ["Power Level (dBm)", data?.powerLevel],
  ];

  return (
    <SectionCard title={title} colors={colors}>
      <Grid container spacing={1.5}>
        {fields.map(([label, value]) => (
          <Grid item xs={12} key={label}>
            <ReadOnlyField label={label} value={value} colors={colors} />
          </Grid>
        ))}
      </Grid>
    </SectionCard>
  );
};

const LosRadioStatus = ({ losStatus }) => {
  const theme = useTheme();

  const colors = getLosColors(theme.palette.mode === "dark");

//   if (!losStatus) {
//     return (
//       <Box sx={{ p: 2 }}>
//         <Typography color="text.secondary">
//           LOS Radio status unavailable.
//         </Typography>
//       </Box>
//     );
//   }

  const authList = losStatus?.authList || [];

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: colors.pageBg,
      }}
    >


      <Grid container spacing={1.5}>
        {/* LINK STATUS */}

        <Grid item xs={12} md={6}>
          <SectionCard title="Link Status" colors={colors}>
            <Grid container spacing={1.5}>
              <Grid item xs={12}>
                <ReadOnlyField
                  label="Link Status"
                  value={losStatus?.linkStatus}
                  colors={colors}
                  statusField
                />
              </Grid>

              <Grid item xs={12}>
                <ReadOnlyField
                  label="System Name"
                  value={losStatus?.sysName}
                  colors={colors}
                />
              </Grid>
            </Grid>
          </SectionCard>
        </Grid>

        {/* LAN INFORMATION */}

        <Grid item xs={12} md={6}>
          <SectionCard title="LAN Interface Information" colors={colors}>
            <Grid container spacing={1.5}>
              <Grid item xs={12}>
                <ReadOnlyField
                  label="IP Address"
                  value={losStatus?.ipConfig?.IPAddress}
                  colors={colors}
                />
              </Grid>

              <Grid item xs={12}>
                <ReadOnlyField
                  label="Subnet Mask"
                  value={losStatus?.ipConfig?.subnetMast}
                  colors={colors}
                />
              </Grid>
            </Grid>
          </SectionCard>
        </Grid>

        {/* ATH1 */}

        <Grid item xs={12} md={6}>
          <WirelessInterface
            title="ATH1 Wireless Interface Information"
            data={authList[1]}
            colors={colors}
          />
        </Grid>

        {/* ATH0 */}

        <Grid item xs={12} md={6}>
          <WirelessInterface
            title="ATH0 Wireless Interface Information"
            data={authList[0]}
            colors={colors}
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default LosRadioStatus;
