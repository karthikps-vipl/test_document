import React, { useMemo } from "react";

import {
  Box,
  Typography,
  LinearProgress,
} from "@mui/material";

import MTable from "@/components/Reusable/Table/MTable";

const ClientsTableLos = ({ rows = [], loading = false }) => {

  const columns = [
    {
      name: "S.No.",
      uid: "index",
    },
    {
      name: "Client MAC Address",
      uid: "clientMACAddress",
    },
    {
      name: "SNR (dB)",
      uid: "snr",
    },
    {
      name: "Noise in the Link (dBm)",
      uid: "noiseInLink",
    },
    {
      name: "Rx Level (dBm)",
      uid: "signalRxLevel",
    },
    {
      name: "Signal Quality",
      uid: "signalQuality",
    },
  ];

  const tableData = useMemo(() => {
    if (!Array.isArray(rows)) return [];

    return rows.map((item, index) => {
      const percentage = Math.min(
        100,
        Math.max(0, Number(item.signalQuality) || 0)
      );

      const withinThreshold =
        item.signalQualityWithinThreshold === true ||
        String(item.signalQualityWithinThreshold) === "true";

      return {
        ...item,

        index: index + 1,

        clientMACAddress:
          item.clientMACAddress ?? "--",

        snr: item.snr ?? "--",

        noiseInLink:
          item.noiseInLink ?? "--",

        signalRxLevel:
          item.signalRxLevel ?? "--",

        signalQuality: (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
              gap: 1,
              minWidth: 150,
            }}
          >
            <Box sx={{ width: "55%" }}>
              <LinearProgress
                variant="determinate"
                value={percentage}
                color={
                  withinThreshold ? "success" : "error"
                }
                sx={{
                  height: 12,
                  borderRadius: 2,
                }}
              />
            </Box>

            <Typography
              variant="body2"
              sx={{
                minWidth: 60,
                textAlign: "right",
              }}
            >
              {item.signalQuality ?? "--"}%
            </Typography>
          </Box>
        ),
      };
    });
  }, [rows]);

  return (
    <Box sx={{ width: "100%", mb: 1 }}>
      {/* {loading && <LinearProgress sx={{ mb: 1 }} />} */}

      <MTable
        tableTitle="Client Status"
        columns={columns}
        tableData={tableData}
        showSearch={true}
        showPagination={true}
        showMaximazed={false}
        closeIcon={false}
      />
    </Box>
  );
};

export default ClientsTableLos;
