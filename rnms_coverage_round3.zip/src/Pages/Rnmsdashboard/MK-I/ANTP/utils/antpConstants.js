
// --- Do not change the Keys and order --- \\
export const AntpConfig = {
    "Mode" : ".1.3.6.1.4.1.38712.3.1.1.3.1.0",
    "Station Longitude (deg)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.6.0",
    "Station Longitude (min)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.7.0",
    "Station Longitude (sec)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.8.0",
    "Station Longitude Hemi" : ".1.3.6.1.4.1.38712.3.1.1.1.1.9.0",
    "Station Latitude (deg)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.10.0",
    "Station Latitude (min)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.11.0",
    "Station Latitude (sec)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.12.0",
    "Station Latitude Hemi" : ".1.3.6.1.4.1.38712.3.1.1.1.1.13.0",
    "Altitude" : ".1.3.6.1.4.1.38712.3.1.1.1.1.14.0",
    "Vehicle Heading" : ".1.3.6.1.4.1.38712.3.1.1.1.1.15.0",
    "Remote GPS Location" : ".1.3.6.1.4.1.38712.3.1.1.4.11.0",
    "Local GPS":".1.3.6.1.4.1.38712.3.1.1.2.5.0",
    "Remote GPS Location RW" : ".1.3.6.1.4.1.38712.3.1.1.4.3.0",
    "Azimuth Position (deg)" : "1.3.6.1.4.1.38712.3.1.1.4.4.0",
    "Elevation Position (deg)" : "1.3.6.1.4.1.38712.3.1.1.4.7.0",
    "Azimuth Movement" : ".1.3.6.1.4.1.38712.3.1.1.4.6.0",
    "Elevation Movement" : ".1.3.6.1.4.1.38712.3.1.1.4.8.0",
    "Homing" : ".1.3.6.1.4.1.38712.3.1.1.4.2.0",
    "LOS" : ".1.3.6.1.4.1.38712.3.1.1.4.9.0",
    "Auto Stow" : ".1.3.6.1.4.1.38712.3.1.1.4.5.0",
    "Stop" : ".1.3.6.1.4.1.38712.3.1.1.4.1.0",
    "Azimuth" : ".1.3.6.1.4.1.38712.3.1.1.4.4.0",
    "Elevation" : ".1.3.6.1.4.1.38712.3.1.1.4.7.0",
}

// --- Do not change the Keys and order --- \\
export const loadLocal = {
    "Station Longitude (deg)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.6.0",
    "Station Longitude (min)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.7.0",
    "Station Longitude (sec)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.8.0",
    "Station Longitude Hemi" : ".1.3.6.1.4.1.38712.3.1.1.1.1.9.0",
    "Station Latitude (deg)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.10.0",
    "Station Latitude (min)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.11.0",
    "Station Latitude (sec)" : ".1.3.6.1.4.1.38712.3.1.1.1.1.12.0",
    "Station Latitude Hemi" : ".1.3.6.1.4.1.38712.3.1.1.1.1.13.0",
    "Altitude" : ".1.3.6.1.4.1.38712.3.1.1.1.1.14.0",
    "Vehicle Heading" : ".1.3.6.1.4.1.38712.3.1.1.1.1.15.0",
}


export const setOid = {
    "Set Remote GPS": ".1.3.6.1.4.1.38712.3.1.1.4.3.0",
    "Set Local GPS": ".1.3.6.1.4.1.38712.3.1.1.2.5.0"
}