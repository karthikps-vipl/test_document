import React, { useEffect, useState } from "react";

import { Paper, Typography, Grid, TextField, Box } from "@mui/material";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const EMPTY_REMOTE = ["", "", "", "", "", "", "", "", ""];

const AntpRemoteSite = ({ data, onLoad, isBusy, colors }) => {
  const [values, setValues] = useState(EMPTY_REMOTE);

  useEffect(() => {
    if (!data) return;

    setValues([
      data.longitudeDeg ?? "",
      data.longitudeMin ?? "",
      data.longitudeSec ?? "",
      data.longitudeHemi ?? "",
      data.latitudeDeg ?? "",
      data.latitudeMin ?? "",
      data.latitudeSec ?? "",
      data.latitudeHemi ?? "",
      data.altitude ?? "",
    ]);
  }, [data]);

  const updateValue = (index, value) => {
    setValues((prev) => {
      const updated = [...prev];
      updated[index] = value;
      return updated;
    });
  };

  const validateNumber = (value, min, max, decimal = false) => {
    if (value === "") return true;

    const regex = decimal ? /^-?\d*\.?\d*$/ : /^\d*$/;

    if (!regex.test(value)) return false;

    const number = Number(value);

    return Number.isFinite(number) && number >= min && number <= max;
  };

  const isValid = () => {
    const [
      lonDeg,
      lonMin,
      lonSec,
      lonHemi,
      latDeg,
      latMin,
      latSec,
      latHemi,
      altitude,
      ,
    ] = values;

    if (values.some((v) => String(v).trim() === "")) {
      return false;
    }

    // Longitude
    if (!isWithinRange(lonDeg, 0, 180)) return false;
    if (!isWithinRange(lonMin, 0, 59)) return false;
    if (!isWithinRange(lonSec, 0, 59)) return false;

    if (!["E", "W"].includes(lonHemi)) return false;

    // Latitude
    if (!isWithinRange(latDeg, 0, 90)) return false;
    if (!isWithinRange(latMin, 0, 59)) return false;
    if (!isWithinRange(latSec, 0, 59)) return false;

    if (!["N", "S"].includes(latHemi)) return false;

    // Altitude
    if (!isWithinRange(altitude, -9999, 9999.9)) {
      return false;
    }

    // Coordinate boundary validation
    if (
      Number(lonDeg) === 180 &&
      (Number(lonMin) !== 0 || Number(lonSec) !== 0)
    ) {
      return false;
    }

    if (
      Number(latDeg) === 90 &&
      (Number(latMin) !== 0 || Number(latSec) !== 0)
    ) {
      return false;
    }

    return true;
  };

  const isValidNumberInput = (
    value,
    allowDecimal = false,
    allowNegative = false
  ) => {
    if (value === "") return true;

    if (allowNegative && allowDecimal) {
      return /^-?\d*\.?\d*$/.test(value);
    }

    if (allowDecimal) {
      return /^\d*\.?\d*$/.test(value);
    }

    return /^\d*$/.test(value);
  };

  const isWithinRange = (value, min, max) => {
    if (value === "" || !Number.isFinite(Number(value))) {
      return false;
    }

    return Number(value) >= min && Number(value) <= max;
  };

  const renderInput = (label, index, min, max, decimal = false) => (
    <TextField
      fullWidth
      size="small"
      type="number"
      label={label}
      value={values[index]}
      disabled={isBusy}
      onChange={(e) => {
        const value = e.target.value;

        const allowNegative = index === 8;

        if (isValidNumberInput(value, decimal, allowNegative)) {
          updateValue(index, value);
        }
      }}
      inputProps={{
        min,
        max,
        step: decimal ? "any" : 1,
      }}
    />
  );

  const renderHemisphere = (label, index, options) => (
    <TextField
      select
      fullWidth
      size="small"
      label={label}
      value={values[index]}
      disabled={isBusy}
      onChange={(e) => updateValue(index, e.target.value)}
      SelectProps={{
        native: true,
      }}
    >
      <option value=""></option>

      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </TextField>
  );

  return (
    <Paper
      elevation={0}
      sx={{
        p: 1,
        height: "100%",
        borderRadius: 2,
        border: `1px solid ${colors.border}`,
        backgroundColor: colors.paperBg,
      }}
    >
      <Typography
        variant="body1"
        fontWeight={700}
        mb={2}
        color={colors.heading}
      >
        Remote Site
      </Typography>

      <Grid spacing={2}>
        <Grid item xs={12} className="grid grid-cols-5 gap-2 mb-2">
          <Typography fontWeight={600} mb={1} variant="body2">
            Longitude
          </Typography>
          <Grid item xs={4}>
            {renderInput("Degrees", 0, 0, 180)}
          </Grid>

          <Grid item xs={4}>
            {renderInput("Minutes", 1, 0, 59)}
          </Grid>

          <Grid item xs={4}>
            {renderInput("Seconds", 2, 0, 59)}
          </Grid>

          <Grid item xs={12}>
            {renderHemisphere("Direction", 3, [
              { value: "E", label: "East" },
              { value: "W", label: "West" },
            ])}
          </Grid>
        </Grid>

        <Grid item xs={12} className="grid grid-cols-5 gap-2 mb-2">
          <Typography fontWeight={600} mb={1} variant="body2">
            Latitude
          </Typography>
          <Grid item xs={4}>
            {renderInput("Degrees", 4, 0, 90)}
          </Grid>

          <Grid item xs={4}>
            {renderInput("Minutes", 5, 0, 59)}
          </Grid>

          <Grid item xs={4}>
            {renderInput("Seconds", 6, 0, 59)}
          </Grid>

          <Grid item xs={12}>
            {renderHemisphere("Direction", 7, [
              { value: "N", label: "North" },
              { value: "S", label: "South" },
            ])}
          </Grid>
        </Grid>

        <Grid
          item
          xs={12}
          sx={{
            display: "grid",
            gridTemplateColumns: "3fr 1fr",
            gap: 2,
            mb: 1,
          }}
        >
          <Grid item xs={12}>
            {renderInput("Altitude (m)", 8, -9999, 9999.9, true)}
          </Grid>
          <MButtonPrimary
            variant="contained"
            disabled={isBusy || !isValid()}
            onClick={() => onLoad(values)}
            sx={{
              borderRadius: "8px",
              minWidth: 120,
            }}
          >
            Load Remote
          </MButtonPrimary>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default AntpRemoteSite;
