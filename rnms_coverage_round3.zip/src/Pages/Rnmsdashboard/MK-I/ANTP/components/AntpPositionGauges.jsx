import React, { useMemo } from "react";
import { Box, Paper, Typography, Grid } from "@mui/material";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

const AntpPositionGauges = ({ position, colors }) => {
  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  const azimuthConfig = useMemo(
    () => ({
      gridTitle: "Azimuth",
      minVal: -180,
      maxVal: 180,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(position.azimuth) || 0,
        },
      ],
    }),
    [position.azimuth]
  );

  const elevationConfig = useMemo(
    () => ({
      gridTitle: "Elevation",
      minVal: -15,
      maxVal: 15,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(position.elevation) || 0,
        },
      ],
    }),
    [position.elevation]
  );

  const GaugeCard = ({ config }) => (
    <Paper
      elevation={0}
      sx={{
        border: `1px solid ${colors.border}`,
        borderRadius: 2,
        backgroundColor: colors.cardBg,
        minHeight: 220,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        p: 1,
      }}
    >
      {DialGaugeWidget && DialGaugeWidget(config)}
    </Paper>
  );

  return (
    <Paper
      elevation={0}
      sx={{
        p: 1,
        mb: 1,
        borderRadius: 2,
        border: `1px solid ${colors.border}`,
        backgroundColor: colors.paperBg,
      }}
    >
      <Grid spacing={2} className="grid grid-cols-2 gap-2">
        <Grid item xs={12} md={6}>
          <GaugeCard config={azimuthConfig} />
        </Grid>

        <Grid item xs={12} md={6}>
          <GaugeCard config={elevationConfig} />
        </Grid>
      </Grid>
    </Paper>
  );
};

export default AntpPositionGauges;
