import React from "react";
import { Box, Paper, CircularProgress } from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const AntpMovementControls = ({
  onMovementStart,
  onMovementStop,
  onAction,
  onCancel,
  stopBtnDetails,
  activeButton,
  isBusy,
  colors,
}) => {
  const movementButtons = [
    { id: "up", label: "UP", area: "up" },
    { id: "down", label: "DOWN", area: "down" },
    { id: "cw", label: "CW", area: "cw" },
    { id: "ccw", label: "CCW", area: "ccw" },
  ];

  const handlePointerDown = (id) => (event) => {
    if (event.button !== undefined && event.button !== 0) return;

    event.preventDefault();

    // Keep receiving pointer events after leaving the button.
    event.currentTarget.setPointerCapture?.(event.pointerId);

    onMovementStart(id);
  };

  const handlePointerRelease = (event) => {
    event.preventDefault();

    if (event.currentTarget.hasPointerCapture?.(event.pointerId)) {
      event.currentTarget.releasePointerCapture?.(event.pointerId);
    }

    onMovementStop();
  };

  const actions = [
    { id: "homing", label: "HOMING" },
    { id: "los", label: "LOS" },
    { id: "auto_stow", label: "AUTO STOW" },
  ];

  return (
    <Paper
      elevation={0}
      sx={{
        p: 2,
        borderRadius: 2,
        border: `1px solid ${colors.border}`,
        backgroundColor: colors.paperBg,
      }}
    >
      {/* ARROW MOVEMENT CONTROLS */}

      <Box
        // sx={{
        //   display: "grid",
        //   gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
        //   gap: 1.5,
        //   maxWidth: 320,
        //   mx: "auto",
        // }}
        className="grid grid-cols-4 gap-2"
      >
        {movementButtons.map((item) => (
          <MButtonPrimary
            key={item.id}
            variant="contained"
            disabled={isBusy || activeButton !== ""}
            onPointerDown={handlePointerDown(item.id)}
            onPointerUp={handlePointerRelease}
            onPointerCancel={handlePointerRelease}
            onContextMenu={(e) => e.preventDefault()}
            sx={{
              gridArea: item.area,
              minWidth: 0,
              minHeight: item.id === "down" ? 55 : 60,
              borderRadius: "10px",
              touchAction: "none",
              userSelect: "none",
              display: "flex",
              flexDirection: "column",
              gap: 0.2,
              fontSize: 14,
            }}
          >
            {activeButton === item.id ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              <>
                {item.label}
              </>
            )}
          </MButtonPrimary>
        ))}
      </Box>

      {/* STOP BUTTON */}
      {!stopBtnDetails.disable && (
        <Box sx={{ mt: 2 }}>
          <MButtonPrimary
            variant="contained"
            fullWidth
            disabled={isBusy && activeButton !== "stop"}
            onClick={onCancel}
            sx={{
              minHeight: 45,
              borderRadius: "8px",
              backgroundColor: "#dc2626",
              "&:hover": {
                backgroundColor: "#b91c1c",
              },
            }}
          >
            {activeButton === "stop" ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              "STOP"
            )}
          </MButtonPrimary>
        </Box>
      )}

      {/* HOMING / LOS / AUTO STOW */}

      <Box
        sx={{
          mt: 2,
          display: "grid",
          gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
          gap: 1,
        }}
      >
        {actions.map((item) => (
          <MButtonPrimary
            key={item.id}
            variant="contained"
            disabled={isBusy || activeButton !== ""}
            onClick={() => onAction(item.id)}
            sx={{
              minWidth: 0,
              minHeight: 45,
              px: 0.5,
              borderRadius: "8px",
              fontSize: 11,
            }}
          >
            {activeButton === item.id ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              item.label
            )}
          </MButtonPrimary>
        ))}
      </Box>
    </Paper>
  );
};

export default AntpMovementControls;
