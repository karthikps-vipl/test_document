import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  Box,
  Paper,
  Typography,
  Grid,
  CircularProgress,
  useTheme,
} from "@mui/material";

import moment from "moment";

import Toast from "@/components/Reusable/Toast/Toast";
import AntpPositionGauges from "./components/AntpPositionGauges";
import AntpMovementControls from "./components/AntpMovementControls";
import AntpLocalSite from "./components/AntpLocalSite";
import AntpRemoteSite from "./components/AntpRemoteSite";
import { AntpConfig, setOid } from "./utils/antpConstants";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_STATUS_BY_DEVICE_AND_TAB,
  SAVE_SNMP_DATA_FOR_DEVICE,
} from "@/RestAPI/url/endpoint";

const getAntpColors = (isDark) => ({
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  cardBg: isDark ? "#252525" : "#ffffff",

  border: isDark ? "#404040" : "#e0e0e0",

  heading: isDark ? "#f3f4f6" : "#1f2937",
  text: isDark ? "#d1d5db" : "#4b5563",

  primary: "#14348D",
});

const createEmptyLocalData = () => ({
  longitudeDeg: "",
  longitudeMin: "",
  longitudeSec: "",
  longitudeHemi: "",

  latitudeDeg: "",
  latitudeMin: "",
  latitudeSec: "",
  latitudeHemi: "",

  altitude: "",
  heading: "",
});

const createEmptyRemoteData = () => ({
  longitudeDeg: "",
  longitudeMin: "",
  longitudeSec: "",
  longitudeHemi: "",

  latitudeDeg: "",
  latitudeMin: "",
  latitudeSec: "",
  latitudeHemi: "",

  altitude: "",
});

const parseGpsData = (value, includeHeading = false) => {
  const parts = String(value || "")
    .trim()
    .split(/\s+/);

  return {
    longitudeDeg: parts[0] ?? "",
    longitudeMin: parts[1] ?? "",
    longitudeSec: parts[2] ?? "",
    longitudeHemi: parts[3] ?? "",

    latitudeDeg: parts[4] ?? "",
    latitudeMin: parts[5] ?? "",
    latitudeSec: parts[6] ?? "",
    latitudeHemi: parts[7] ?? "",

    altitude: parts[8] ?? "",

    ...(includeHeading
      ? {
          heading: parts[9] ?? "",
        }
      : {}),
  };
};

const getGpsString = (values) => {
  return values.join(" ");
};
const ANTP_MOVEMENT_COMMANDS = {
  UP_START: "04",
  UP_STOP: "14",

  DOWN_START: "08",
  DOWN_STOP: "18",

  CW_START: "01",
  CW_STOP: "11",

  CCW_START: "02",
  CCW_STOP: "12",
};

const ANTP_POLLING_INTERVAL = 5000;

const AntpConfigurationMKI = ({ node }) => {
  const resourceId = node?.resourceId;

  const theme = useTheme();

  const isDark = theme.palette.mode === "dark";

  const colors = useMemo(() => getAntpColors(isDark), [isDark]);

  const [position, setPosition] = useState({
    azimuth: 0,
    elevation: 0,
  });

  const [localSite, setLocalSite] = useState(createEmptyLocalData);

  const [remoteSite, setRemoteSite] = useState(createEmptyRemoteData);

  const [source, setSource] = useState("");

  const [lastUpdated, setLastUpdated] = useState(null);

  const [isInitialLoading, setIsInitialLoading] = useState(true);

  const [activeButton, setActiveButton] = useState("");

  const [isBusy, setIsBusy] = useState(false);

  const [activeMovement, setActiveMovement] = useState(null);

  const [isMovementStarting, setIsMovementStarting] = useState(false);
  const [stopBtnDetails, setStopBtnDetails] = useState({
    disable: true,
  });
  const mountedRef = useRef(false);

  const movementRef = useRef(null);

  const busyRef = useRef(false);

  const requestIdRef = useRef(0);

  const movementStartRef = useRef(false);

  const setBusy = (value) => {
    busyRef.current = value;
    setIsBusy(value);
  };

  // --------------------------------------------------
  // FETCH STATUS
  // --------------------------------------------------

  const fetchAntpStatus = useCallback(
    async (initial = false, refreshGps = false) => {
      if (!resourceId || !mountedRef.current) return;

      try {
        // const response = await getSnmspStatus(resourceId, 0, 2);
        const response = await ConfigurationAxios(
          `${GET_STATUS_BY_DEVICE_AND_TAB}/${resourceId}/0/2`,
          "get"
        );
        if (!mountedRef.current) return;

        const data = response?.data;

        if (!data?.status) {
          if (initial) {
            Toast(
              "Error",
              data?.message || "Failed to fetch ANTP status",
              "error"
            );
          }

          return;
        }

        const staticData = data?.data?.static || {};

        const getValue = (key) => staticData[AntpConfig[key]];

        setPosition({
          azimuth: Number(getValue("Azimuth")) || 0,
          elevation: Number(getValue("Elevation")) || 0,
        });

        setSource(getValue("Mode") ?? "");

        setLastUpdated(data?.data?.date || new Date());

        if (initial || refreshGps) {
          setLocalSite(parseGpsData(getValue("Local GPS"), true));

          setRemoteSite(parseGpsData(getValue("Remote GPS Location"), false));
        }
      } catch (error) {
        console.error("ANTP status fetch failed", error);

        if (initial && mountedRef.current) {
          Toast(
            "Error",
            error?.message || "Failed to fetch ANTP status",
            "error"
          );
        }
      } finally {
        if (initial && mountedRef.current) {
          setIsInitialLoading(false);
        }
      }
    },
    [resourceId]
  );

  // --------------------------------------------------
  // INITIAL LOAD AND POLLING
  // --------------------------------------------------

  useEffect(() => {
    if (!resourceId) {
      setIsInitialLoading(false);
      return;
    }

    mountedRef.current = true;

    fetchAntpStatus(true);

    const interval = setInterval(() => {
      // Don't overlap status polling with an active write.
      if (busyRef.current || movementRef.current) {
        return;
      }

      fetchAntpStatus(false);
    }, ANTP_POLLING_INTERVAL);

    return () => {
      mountedRef.current = false;

      clearInterval(interval);

      requestIdRef.current += 1;

      movementRef.current = null;

      movementStartRef.current = false;
    };
  }, [resourceId, fetchAntpStatus]);

  // --------------------------------------------------
  // SAVE SNMP
  // --------------------------------------------------

  const sendEditableValues = useCallback(
    async (payload) => {
      if (!resourceId || !Array.isArray(payload) || !payload.length) {
        return false;
      }

      const requestId = ++requestIdRef.current;

      setBusy(true);

      try {
        // const response = await saveSnmp(resourceId, payload, 0);
        const response = await ConfigurationAxios(
          `${SAVE_SNMP_DATA_FOR_DEVICE}/${resourceId}/0`,
          "post",
          payload
        );

        if (!mountedRef.current || requestId !== requestIdRef.current) {
          return false;
        }

        if (response?.data?.status === false) {
          throw new Error(response?.data?.message || "SNMP operation failed");
        }

        Toast("Success", "ANTP configuration updated successfully", "success");

        return true;
      } catch (error) {
        console.error("ANTP SNMP save failed", error);

        if (mountedRef.current && requestId === requestIdRef.current) {
          Toast(
            "Error",
            error?.response?.data?.message ||
              error?.message ||
              "Failed to update ANTP configuration",
            "error"
          );
        }

        return false;
      } finally {
        if (mountedRef.current && requestId === requestIdRef.current) {
          setBusy(false);
        }
      }
    },
    [resourceId]
  );

  // --------------------------------------------------
  // LOAD LOCAL GPS
  // --------------------------------------------------

  const handleLocalLoad = async (values) => {
    if (busyRef.current || movementRef.current) return;

    const payload = [
      {
        oid: setOid["Set Local GPS"],
        value: getGpsString(values),
      },
    ];

    const success = await sendEditableValues(payload);

    if (success) {
      await fetchAntpStatus(false, true);
    }
  };

  // --------------------------------------------------
  // LOAD REMOTE GPS
  // --------------------------------------------------

  const handleRemoteLoad = async (values) => {
    if (busyRef.current || movementRef.current) return;

    const payload = [
      {
        oid: setOid["Set Remote GPS"],
        value: getGpsString(values),
      },
    ];

    const success = await sendEditableValues(payload);

    if (success) {
      await fetchAntpStatus(false, true);
    }
  };

  // --------------------------------------------------
  // MOVEMENT COMMAND CONFIGURATION
  // --------------------------------------------------

  const getMovementDetails = (direction) => {
    switch (direction) {
      case "up":
        return {
          oid: AntpConfig["Elevation Movement"],
          start: ANTP_MOVEMENT_COMMANDS.UP_START,
          stop: ANTP_MOVEMENT_COMMANDS.UP_STOP,
        };

      case "down":
        return {
          oid: AntpConfig["Elevation Movement"],
          start: ANTP_MOVEMENT_COMMANDS.DOWN_START,
          stop: ANTP_MOVEMENT_COMMANDS.DOWN_STOP,
        };

      case "cw":
        return {
          oid: AntpConfig["Azimuth Movement"],
          start: ANTP_MOVEMENT_COMMANDS.CW_START,
          stop: ANTP_MOVEMENT_COMMANDS.CW_STOP,
        };

      case "ccw":
        return {
          oid: AntpConfig["Azimuth Movement"],
          start: ANTP_MOVEMENT_COMMANDS.CCW_START,
          stop: ANTP_MOVEMENT_COMMANDS.CCW_STOP,
        };

      default:
        return null;
    }
  };

  // --------------------------------------------------
  // START MOVEMENT
  // --------------------------------------------------

  // const handleMovementStart = async (direction) => {
  //   if (
  //     !resourceId ||
  //     busyRef.current ||
  //     movementRef.current ||
  //     !mountedRef.current
  //   ) {
  //     return;
  //   }

  //   const details = getMovementDetails(direction);

  //   if (!details) return;

  //   const movement = {
  //     ...details,
  //     direction,
  //     started: false,
  //     stopRequested: false,
  //   };

  //   movementRef.current = movement;

  //   movementStartRef.current = true;

  //   setActiveButton(direction);

  //   setIsMovementStarting(true);

  //   setBusy(true);

  //   try {
  //     // const success = await saveSnmp(
  //     //   resourceId,
  //     //   [
  //     //     {
  //     //       oid: details.oid,
  //     //       value: details.start,
  //     //     },
  //     //   ],
  //     //   0
  //     // );
  //     const success = await ConfigurationAxios(
  //       `${SAVE_SNMP_DATA_FOR_DEVICE}/${resourceId}/0`,
  //       "post",
  //       [
  //         {
  //           oid: details.oid,
  //           value: details.start,
  //         },
  //       ]
  //     );
  //     if (!mountedRef.current || movementRef.current !== movement) {
  //       return;
  //     }

  //     if (success?.data?.status === false) {
  //       throw new Error(success?.data?.message || "Movement start failed");
  //     }

  //     movement.started = true;

  //     Toast(
  //       "Success",
  //       `${direction.toUpperCase()} movement started`,
  //       "success"
  //     );
  //   } catch (error) {
  //     console.error("ANTP movement start failed", error);

  //     if (mountedRef.current) {
  //       Toast(
  //         "Error",
  //         error?.response?.data?.message ||
  //           error?.message ||
  //           "Movement start failed",
  //         "error"
  //       );

  //       movementRef.current = null;

  //       movementStartRef.current = false;

  //       setActiveButton("");
  //     }
  //   } finally {
  //     if (mountedRef.current) {
  //       setIsMovementStarting(false);

  //       setBusy(false);
  //     }
  //   }
  // };
  // const handleMovementStart = async (direction) => {
  //   if (
  //     !resourceId ||
  //     busyRef.current ||
  //     movementRef.current ||
  //     !mountedRef.current
  //   ) {
  //     return;
  //   }

  //   const details = getMovementDetails(direction);

  //   if (!details) return;

  //   const movement = {
  //     ...details,
  //     direction,
  //     started: false,
  //     stopRequested: false,
  //   };

  //   movementRef.current = movement;

  //   setActiveButton(direction);
  //   setIsMovementStarting(true);
  //   setBusy(true);

  //   try {
  //     const response = await ConfigurationAxios(
  //       `${SAVE_SNMP_DATA_FOR_DEVICE}/${resourceId}/0`,
  //       "post",
  //       [
  //         {
  //           oid: details.oid,
  //           value: details.start,
  //         },
  //       ]
  //     );

  //     if (!mountedRef.current || movementRef.current !== movement) {
  //       return;
  //     }

  //     if (response?.data?.status === false) {
  //       throw new Error(
  //         response?.data?.message || "Movement start failed"
  //       );
  //     }

  //     movement.started = true;

  //     // User already released the button while start was pending.
  //     if (movement.stopRequested) {
  //       setActiveButton("stop");

  //       const stopResponse = await sendMovementStop(movement);

  //       if (stopResponse?.data?.status === false) {
  //         throw new Error(
  //           stopResponse?.data?.message || "Movement stop failed"
  //         );
  //       }

  //       movementRef.current = null;

  //       setActiveButton("");

  //       Toast("Success", "Antenna movement stopped", "success");

  //       return;
  //     }

  //     Toast(
  //       "Success",
  //       `${direction.toUpperCase()} movement started`,
  //       "success"
  //     );
  //   } catch (error) {
  //     console.error("ANTP movement error:", error);

  //     if (mountedRef.current) {
  //       Toast(
  //         "Error",
  //         error?.response?.data?.message ||
  //           error?.message ||
  //           "Movement operation failed",
  //         "error"
  //       );

  //       movementRef.current = null;
  //       setActiveButton("");
  //     }
  //   } finally {
  //     if (mountedRef.current) {
  //       setIsMovementStarting(false);
  //       setBusy(false);
  //     }
  //   }
  // };
  const handleMovementStart = async (direction) => {
    if (
      !resourceId ||
      busyRef.current ||
      movementRef.current ||
      !mountedRef.current
    )
      return;

    const details = getMovementDetails(direction);

    if (!details) return;

    const movement = {
      ...details,
      direction,
      started: false,
      stopRequested: false,
    };

    movementRef.current = movement;

    setActiveButton(direction);
    setBusy(true);

    setStopBtnDetails({
      oid: details.oid,
      command: details.stop,
      disable: false,
    });

    try {
      const response = await ConfigurationAxios(
        `${SAVE_SNMP_DATA_FOR_DEVICE}/${resourceId}/0`,
        "post",
        [
          {
            oid: details.oid,
            value: details.start,
          },
        ]
      );

      if (!mountedRef.current || movementRef.current !== movement) return;

      if (response?.data?.status === false) {
        throw new Error(response?.data?.message || "Movement start failed");
      }

      movement.started = true;

      if (movement.stopRequested) {
        await handleMovementStop();
        return;
      }
    } catch (error) {
      console.error(error);

      movementRef.current = null;

      setStopBtnDetails({ disable: true });
      setActiveButton("");

      Toast("Error", "Movement start failed", "error");
    } finally {
      if (mountedRef.current) {
        setBusy(false);
      }
    }
  };

  const handleCancelButton = async () => {
    const movement = movementRef.current;

    if (!movement) return;

    if (!movement.started) {
      movement.stopRequested = true;
      return;
    }

    await handleMovementStop();
  };

  // --------------------------------------------------
  // STOP MOVEMENT
  // --------------------------------------------------

  // const handleMovementStop = async () => {
  //   const movement = movementRef.current;

  //   if (!resourceId || !movement || busyRef.current) {
  //     return;
  //   }

  //   if (!movement.started) {
  //     movement.stopRequested = true;

  //     return;
  //   }

  //   movementRef.current = null;

  //   setActiveButton("stop");

  //   setBusy(true);

  //   try {
  //     // const response = await saveSnmp(
  //     //   resourceId,
  //     //   [
  //     //     {
  //     //       oid: movement.oid,
  //     //       value: movement.stop,
  //     //     },
  //     //   ],
  //     //   0
  //     // );
  //     const response = await ConfigurationAxios(
  //       `${SAVE_SNMP_DATA_FOR_DEVICE}/${resourceId}/0`,
  //       "post",
  //       [
  //         {
  //           oid: movement.oid,
  //           value: movement.stop,
  //         },
  //       ]
  //     );
  //     if (!mountedRef.current) return;

  //     if (response?.data?.status === false) {
  //       throw new Error(response?.data?.message || "Movement stop failed");
  //     }

  //     Toast("Success", "Antenna movement stopped", "success");
  //   } catch (error) {
  //     console.error("ANTP movement stop failed", error);

  //     if (mountedRef.current) {
  //       Toast(
  //         "Error",
  //         error?.response?.data?.message ||
  //           error?.message ||
  //           "Movement stop failed",
  //         "error"
  //       );
  //     }
  //   } finally {
  //     if (mountedRef.current) {
  //       setBusy(false);
  //       setActiveButton("");
  //     }
  //   }
  // };

  // const handleMovementStop = async () => {
  //   const movement = movementRef.current;

  //   if (!resourceId || !movement) {
  //     return;
  //   }

  //   // IMPORTANT: Check this before checking busyRef.
  //   if (!movement.started || busyRef.current) {
  //     movement.stopRequested = true;
  //     setActiveButton("stop");
  //     return;
  //   }

  //   setActiveButton("stop");
  //   setBusy(true);

  //   try {
  //     const response = await sendMovementStop(movement);

  //     if (!mountedRef.current) return;

  //     if (response?.data?.status === false) {
  //       throw new Error(
  //         response?.data?.message || "Movement stop failed"
  //       );
  //     }

  //     movementRef.current = null;

  //     setActiveButton("");

  //     Toast("Success", "Antenna movement stopped", "success");
  //   } catch (error) {
  //     console.error("ANTP movement stop failed:", error);

  //     if (mountedRef.current) {
  //       // Retain movement reference so STOP can be retried.
  //       setActiveButton(movement.direction);

  //       Toast(
  //         "Error",
  //         error?.response?.data?.message ||
  //           error?.message ||
  //           "Movement stop failed",
  //         "error"
  //       );
  //     }
  //   } finally {
  //     if (mountedRef.current) {
  //       setBusy(false);
  //     }
  //   }
  // };
  const handleMovementStop = async () => {
    const movement = movementRef.current;

    if (!movement || !resourceId) return;

    if (!movement.started) {
      movement.stopRequested = true;
      return;
    }

    if (busyRef.current) return;

    setBusy(true);
    setActiveButton("stop");

    try {
      const response = await ConfigurationAxios(
        `${SAVE_SNMP_DATA_FOR_DEVICE}/${resourceId}/0`,
        "post",
        [
          {
            oid: stopBtnDetails.oid,
            command: stopBtnDetails.command,
          },
        ]
      );

      if (response?.data?.status === false) {
        throw new Error(response?.data?.message || "Stop failed");
      }

      movementRef.current = null;

      setStopBtnDetails({ disable: true });
      setActiveButton("");

      Toast("Success", "Antenna movement stopped", "success");
    } catch (error) {
      console.error("Stop failed", error);

      Toast("Error", "Failed to stop antenna movement", "error");
    } finally {
      setBusy(false);
    }
  };

  // --------------------------------------------------
  // HOMING / AUTO STOW / LOS
  // --------------------------------------------------

  const handleAction = async (action) => {
    if (!resourceId || busyRef.current || movementRef.current) {
      return;
    }

    let oid = "";
    let value = "";

    switch (action) {
      case "homing":
        oid = AntpConfig["Homing"];
        break;

      case "auto_stow":
        oid = AntpConfig["Auto Stow"];
        break;

      case "los":
        oid = AntpConfig["LOS"];
        break;

      default:
        return;
    }

    setActiveButton(action);

    const success = await sendEditableValues([
      {
        oid,
        value,
      },
    ]);

    if (mountedRef.current) {
      setActiveButton("");
    }

    if (success) {
      await fetchAntpStatus(false);
    }
  };

  // --------------------------------------------------
  // RENDER
  // --------------------------------------------------

  if (isInitialLoading) {
    return (
      <Box
        sx={{
          p: 3,
          minHeight: 350,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 2,
          backgroundColor: colors.pageBg,
          color: colors.heading,
        }}
      >
        <CircularProgress size={35} />

        <Typography>Loading ANTP Configuration...</Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: colors.pageBg,
        color: colors.heading,
      }}
    >
      {/* LAST UPDATED AND SOURCE */}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          mb: 1,
          border: `1px solid ${colors.border}`,
          borderRadius: 2,
          backgroundColor: colors.paperBg,
        }}
      >
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6}>
            <Typography variant="body2">
              <b>Source:</b> {source || "---"}
            </Typography>
          </Grid>

          <Grid
            item
            xs={12}
            sm={6}
            sx={{
              textAlign: {
                xs: "left",
                sm: "right",
              },
            }}
          >
            <Typography variant="body2">
              <b>Last Updated:</b>{" "}
              {lastUpdated
                ? moment(lastUpdated).format("DD-MM-YYYY HH:mm:ss")
                : "---"}
            </Typography>
          </Grid>
        </Grid>
      </Paper>

      <Grid sx={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 1 }}>
        {" "}
        {/* POSITION GAUGES */}
        <AntpPositionGauges position={position} colors={colors} />
        {/* MOVEMENT CONTROLS */}
        <AntpMovementControls
          onMovementStart={handleMovementStart}
          onMovementStop={handleMovementStop}
          onCancel={handleCancelButton}
          onAction={handleAction}
          stopBtnDetails={stopBtnDetails}
          activeButton={activeButton}
          isBusy={isBusy}
          colors={colors}
        />
      </Grid>

      {/* LOCAL AND REMOTE SITE */}

      <Grid spacing={2} className="grid grid-cols-2 gap-2">
        <Grid item xs={12} lg={6}>
          <AntpLocalSite
            data={localSite}
            onLoad={handleLocalLoad}
            isBusy={isBusy || Boolean(movementRef.current)}
            colors={colors}
          />
        </Grid>

        <Grid item xs={12} lg={6}>
          <AntpRemoteSite
            data={remoteSite}
            onLoad={handleRemoteLoad}
            isBusy={isBusy || Boolean(movementRef.current)}
            colors={colors}
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default AntpConfigurationMKI;
