/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : TopologyEditActions.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\TopologyEditActions.jsx
   Purpose                  : Created the TopologyEditActions for editing the topology Action from toggling the canvas to svg or node to rack view
   Created Date             : 26-03-2026
 ***********************************************************************************************/
import {
  performRedo,
  performRedoRack,
  performUndo,
  performUndoRack,
  setCurrentViewTopology,
} from "@/store/features/Topology/topologyNodesslice";
import React, { useMemo, useState } from "react";
import { topologyAdminIcons } from "./topologyConstants";
import { useDispatch, useSelector } from "react-redux";
import {
  Box,
  Popover,
  Switch,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Autocomplete,
  Menu,
  useTheme,
} from "@mui/material";

import CableIcon from '@mui/icons-material/Cable';

import {
  ArrowLeftRight,
  ArrowRight,
  Minus,
  ChevronDown,
} from "lucide-react";

// Asset SVG Icon Imports
import uploadIcon from "../../.././assets/superAdmin_icon/upload.svg";
import arrowsIcon from "../../.././assets/superAdmin_icon/arrows.svg";
import deleteArrowIcon from "../../.././assets/superAdmin_icon/Delete arrow.svg";
import deleteIcon from "../../.././assets/superAdmin_icon/delete.svg";
import deleteSvgIcon from "../../.././assets/superAdmin_icon/delete_svg.svg";
import undoIcon from "../../.././assets/superAdmin_icon/undo-1.svg";
import redoIcon from "../../.././assets/superAdmin_icon/undo.svg";
import saveIcon from "../../.././assets/superAdmin_icon/save.svg";

import SettingsForm from "./Tooltip/SettingsForm";
import { InventoryAxios, TopologyAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  LINK_CONFIGURATION,
  MANAGED_UNMANAGED_DEVICES,
} from "@/RestAPI/url/endpoint";

const ACTIVE_COLOR = "#5154FF";
const DEFAULT_COLOR = "#111827"; // Dark Black

const fieldSx = {
  minWidth: 180,
  width: "auto",
  "& .MuiSelect-select": {
    paddingTop: "6px",
    paddingBottom: "6px",
    fontSize: "13px",
  },
  // If you want to keep the height consistent,
  // apply it to the Root, not the InputBase, to avoid theme conflicts
  "& .MuiOutlinedInput-root": {
    height: 34,
  },
};

const ToolbarItem = ({
  icon,
  label,
  active,
  onClick,
  children,
  disabled,
  isDark,
}) => {
  const getTextColor = () => {
    if (active) return isDark ? "#FFFFFF" : ACTIVE_COLOR;
    return isDark ? "#FFFFFF" : DEFAULT_COLOR; // Light grey for dark mode inactive
  };
  const finalColor = getTextColor();

  return (
    <Box
      onClick={disabled ? undefined : onClick}
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        cursor: disabled ? "not-allowed" : "pointer",
        minWidth: 54,
        padding: "2px",
        opacity: disabled ? 0.45 : 1,
        color: finalColor,
        // backgroundColor: "#e3e9f4",
        transition: "color 0.2s ease",
        "&:hover": {
          // 3. Update hover color for dark mode
          color: isDark ? "#FFFFFF" : ACTIVE_COLOR,
          "& .icon-border-box": {
            borderColor: isDark ? "#FFFFFF" : ACTIVE_COLOR,
            borderStyle: "solid",
          },
          "& img": {
            // If dark mode, we might want a different hover effect for icons
            filter: isDark
              ? "brightness(0) invert(1)"
              : "invert(35%) sepia(95%) saturate(3100%) hue-rotate(229deg) brightness(101%) contrast(102%)",
          },
        },
      }}
    >
      <Box
        className="icon-border-box"
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          width: 20,
          height: 20,
          fontWeight: 600,
          border: active
            ? `1px solid ${ACTIVE_COLOR}`
            : "1px solid transparent",
          borderRadius: "8px",
          transition: "border-color 0.2s ease, border-style 0.2s ease",
          "& img": {
            width: "24px",
            height: "24px",
            objectFit: "contain",
            transition: "filter 0.2s ease",
            // 4. Update icon filter for active state in dark mode
            filter: active
              ? isDark
                ? "brightness(0) invert(1)"
                : "invert(35%) sepia(95%) saturate(3100%) hue-rotate(229deg) brightness(101%) contrast(102%)"
              : "none",
          },
        }}
      >
        {children || icon}
      </Box>

      <Box
        sx={{
          fontSize: "10px",
          marginTop: "4px",
          lineHeight: 1,
          textAlign: "center",
          color: "inherit",
        }}
      >
        {label}
      </Box>
    </Box>
  );
};

const StatusCard = ({ label, value, colorClass }) => {
  return (
    <div className="relative flex flex-col justify-center items-center h-full px-2 min-w-[70px]">
      <div
        className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-[80%] rounded-full"
        style={{
          backgroundColor: colorClass.includes("emerald")
            ? "#008000"
            : colorClass.includes("rose")
            ? "#ff0000"
            : colorClass.includes("orange")
            ? "#b8860b"
            : colorClass.includes("indigo")
            ? "#0000ff"
            : "#808080",
        }}
      />
      <div className="flex flex-col items-center leading-tight">
        <span className="text-[14px]">{label}</span>
        <span className="text-md  font-extrabold  " sx={{ color: "text.gray" }}>
          {" "}
          {value}
        </span>
      </div>
    </div>
  );
};

const SUPERADMIN = window.isSuperAdmin;

const TopologyEditActions = ({
  topologyRenderMode = "canvas",
  setTopologyRenderMode,
  canUndo,
  canRedo,
  onCanvasUndo,
  onCanvasRedo,
  onCanvasSave,
  fabricTerminals = [],
  fabricForm = {},
  fabricSelectedObject,
  onFabricUpload,
  onFabricAddLine,
  onFabricDeleteSelected,
  onFabricSave,
  onFabricFieldChange,
  placedDevices = [],
  setIsDeleteAllConfirm,
  canUndoRack,
  canRedoRack,
  onFabricDeleteAll,
  setIsSaveConfirmOpen,
  onAutoLoadTopology,
  svgReadOnly,
  isAutoLoadedViewMode,
  onPortMappingToggle,
  portMappingOpen = false,
}) => {
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const iconStyle = {
    filter: isDark ? "brightness(0) invert(1)" : "none",
    width: "18px", // matching your width attribute
    height: "18px",
  };

  const inputTheme = theme.palette.custom.input;

  const fieldThemeSx = {
    // We apply the background color to the Root element
    "& .MuiOutlinedInput-root": {
      backgroundColor: inputTheme.bg, // This now works!
      color: inputTheme.text,
      borderRadius: "8px",
      "& fieldset": {
        borderColor: inputTheme.border,
      },
      "&:hover fieldset": {
        borderColor: inputTheme.borderColorHover,
      },
      "&.Mui-focused fieldset": {
        borderColor: inputTheme.borderColorHover,
      },
    },
    "& .MuiInputLabel-root": {
      color: inputTheme.label,
    },
    "& .MuiInputLabel-root.Mui-focused": {
      color: inputTheme.borderColorHover,
    },
  };

  const isSvgMode = topologyRenderMode === "svg";
  const dispatch = useDispatch();
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const isSettingFormOpen = Boolean(showSettingsModal);
  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  const { currentViewTopology, deviceStats } = useSelector(
    (state) => state.topologySlice
  );

  const { isCnms } = useSelector((state) => state.nodeDetails);

  /*
   * Find the actual discovered resources for enabling the port mapping.
   */
  const resources = useSelector((state) => state.inventory?.resources || []);
  const connectedResourceIds = useMemo(() => {
    if (!Array.isArray(resources)) {
      return [];
    }

    return [
      ...new Set(
        resources
          .map((resource) => resource?.connectedTo)
          .filter(
            (connectedTo) =>
              connectedTo !== null &&
              connectedTo !== undefined &&
              connectedTo !== ""
          )
      ),
    ];
  }, [resources]);

  const discoveredConnectedResources = useMemo(() => {
    if (!Array.isArray(resources) || connectedResourceIds.length === 0) {
      return [];
    }

    return resources.filter(
      (resource) =>
        connectedResourceIds.includes(resource?.resourceId) &&
        resource?.isDiscovered === true
    );
  }, [resources, connectedResourceIds]);

  let isPortMappingAvailable = discoveredConnectedResources.length > 0;

  console.log("discoveredConnectedResources", isPortMappingAvailable);
  const loggedInTerminalName =
    repDetails?.imTerminalType?.terminalTypeName || "";
  const isViewMode = svgReadOnly && isAutoLoadedViewMode;

  const [activeAction, setActiveAction] = useState("");
  const [arrowMenuAnchor, setArrowMenuAnchor] = useState(null);
  const isArrowMenuOpen = Boolean(arrowMenuAnchor);
  console.log("arrowMenuAnchor", arrowMenuAnchor);

  const handleRenderModeChange = (event) => {
    const svgEnabled = event.target.checked;
    setTopologyRenderMode?.(svgEnabled ? "svg" : "canvas");
    if (svgEnabled && loggedInTerminalName) {
      onAutoLoadTopology?.(loggedInTerminalName);
    }
  };

  console.log("bhjkfabricForm", fabricForm);

  const handleTerminalChange = async (event) => {
    const selectedTerminalId = event.target.value;

    onFabricFieldChange?.("loadTopology", selectedTerminalId);

    onFabricFieldChange?.("terminalId", selectedTerminalId);

    if (!selectedTerminalId) {
      onFabricFieldChange?.("deviceId", "");
      onFabricFieldChange?.("segment", "");
      onFabricFieldChange?.("segmentList", []);
      onFabricFieldChange?.("linkStatusData", []);
      return;
    }

    try {
      const [linkRes, resourceRes] = await Promise.allSettled([
        TopologyAxios(`${LINK_CONFIGURATION}/${selectedTerminalId}`, "get"),
        InventoryAxios(
          `${MANAGED_UNMANAGED_DEVICES}/${selectedTerminalId}`,
          "get"
        ),
      ]);

      /* ---------------- LINK DATA ---------------- */
      if (
        linkRes.status === "fulfilled" &&
        Array.isArray(linkRes.value?.data)
      ) {
        const linkData = linkRes.value.data;

        const segmentList = linkData.map((l) => l.linkName);
        console.log("ghtsegment", segmentList);

        onFabricFieldChange?.("segmentList", segmentList);
        onFabricFieldChange?.("linkStatusData", linkData);

        // ALWAYS reset unless you explicitly want persistence
        onFabricFieldChange?.("segment", "");
      }

      /* ---------------- DEVICE DATA ---------------- */
      if (
        resourceRes.status === "fulfilled" &&
        Array.isArray(resourceRes.value?.data)
      ) {
        const resourceData = resourceRes.value.data;

        onFabricFieldChange?.("deviceList", resourceData);
        onFabricFieldChange?.("deviceId", "");
        onFabricFieldChange?.("selectedDeviceData", null);
      }
    } catch (error) {
      Toast(
        "error",
        "An error occurred while fetching terminal details",
        "error"
      );
    }
  };

  const handleDeviceChange = (event) => {
    const selectedId = event.target.value;
    const selectedDevice = fabricForm.deviceList?.find(
      (item) => item.resourceId === selectedId
    );

    onFabricFieldChange?.("deviceId", selectedId);
    onFabricFieldChange?.("selectedDeviceData", selectedDevice);
    onFabricFieldChange?.("createDeviceMarker", {
      deviceId: selectedId,
      selectedDeviceData: selectedDevice,
    });
  };

  const stats = [
    { label: "Online", value: deviceStats.online, color: "border-emerald-400" },
    { label: "Offline", value: deviceStats.offline, color: "border-rose-300" },
    {
      label: "Maintenance",
      value: deviceStats.maintenance,
      color: "border-orange-200",
    },
    {
      label: "Undiscovered",
      value: deviceStats.undiscovered,
      color: "border-indigo-300",
    },
    {
      label: "Unmanaged",
      value: deviceStats.unmanaged,
      color: "border-gray-400",
    },
  ];

  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        flexDirection: "column",
        background: (theme) => theme.palette.background.secondary,
        p: 0.5,
      }}
    >
      {/* ROW 1 */}
      <Box
        sx={{
          display: "flex",
          width: "100%",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: 1.5,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Box
            className="flex items-center gap-2 px-2 h-8  "
            sx={{ color: "text.primary" }}
          >
            Topology
            {/* <Switch
              checked={!currentViewTopology}
              onChange={() => {
                setTopologyRenderMode("canvas");
                dispatch(setCurrentViewTopology());
              }}
            /> */}
            <Switch
              checked={!currentViewTopology}
              onChange={() => {
                // Let the central state manager orchestrate perspective
                dispatch(setCurrentViewTopology());
              }}
            />
            Rack
          </Box>
        </Box>
        {!SUPERADMIN && (
          <div className="flex justify-end w-[60%] ml-50">
            <div className="flex justify-end items-center h-full px-1">
              {/* <div className="flex justify-end items-center gap-x-3 overflow-x-auto max-w-full"> */}
              {stats.map((stat, index) => (
                <StatusCard
                  key={index}
                  label={stat.label}
                  value={stat.value}
                  colorClass={stat.color}
                />
              ))}
            </div>
            <div className="ml-5">
              <ToolbarItem
                label="Filter"
                isDark={isDark}
                active={activeAction === "filter"}
                onClick={(e) => {
                  setActiveAction("filter");
                  setShowSettingsModal(e.currentTarget);
                }}
              >
                <img
                  src={topologyAdminIcons["settingsFilter"]}
                  alt="filter"
                  width={18}
                  height={18}
                  style={iconStyle} // Use style instead of className
                  className="object-contain"
                />
              </ToolbarItem>
            </div>
            {!isCnms && (
              <div>
                <ToolbarItem
                  label={
                    <span
                      style={{
                        color: isPortMappingAvailable
                          ? theme.palette.text.tabcolor
                          : theme.palette.text.disabled,
                      }}
                    >
                      Port Mapping
                    </span>
                  }
                  isDark={isDark}
                  active={portMappingOpen}
                  disabled={!isPortMappingAvailable}
                  onClick={() => {
                    if (!isPortMappingAvailable) {
                      return;
                    }

                    onPortMappingToggle?.();
                    setActiveAction(portMappingOpen ? "" : "portMapping");
                  }}
                >
                  <Box
                    sx={{
                      width: 20,
                      height: 20,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "10px",
                      fontWeight: 700,
                      color:isDark?"#fff":"#000"
                    }}
                  >
                  <CableIcon />
                  {/* <LanIcon /> */}
                  {/* <HubIcon /> */}
                  </Box>
                </ToolbarItem>
              </div>
            )}
          </div>
        )}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            gap: 1.25,
            flexWrap: "wrap",
          }}
        >
          {isSvgMode && SUPERADMIN && (
            <>
              <FormControl size="small" sx={{ ...fieldThemeSx, ...fieldSx }}>
                <InputLabel>Terminal</InputLabel>
                <Select
                  label="Terminal"
                  value={fabricForm?.terminalId ?? ""}
                  onChange={handleTerminalChange}
                >
                  {fabricTerminals.map((terminal) => (
                    <MenuItem
                      key={terminal.subTypeId}
                      value={terminal.subTypeId}
                    >
                      {terminal.terminalTypeName ||
                        terminal.subTypeName ||
                        `ID: ${terminal.subTypeId}`}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <Autocomplete
                disabled={isViewMode}
                size="small"
                sx={{
                  width: 180,
                  ...fieldThemeSx, // Theme colors
                  ...fieldSx,
                }}
                options={fabricForm?.deviceList || []}
                getOptionDisabled={(option) =>
                  placedDevices.includes(option.resourceId)
                }
                getOptionLabel={(option) =>
                  `${option.resourceName || option.resourceId}${
                    placedDevices.includes(option.resourceId) ? " (Added)" : ""
                  }`
                }
                value={
                  fabricForm.deviceList?.find(
                    (item) => item.resourceId === fabricForm.deviceId
                  ) || null
                }
                onChange={(event, value) => {
                  if (!value) return;
                  handleDeviceChange({ target: { value: value.resourceId } });
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Devices"
                    sx={{ ...fieldThemeSx, ...fieldSx }}
                  />
                )}
              />

              <FormControl size="small" sx={{ ...fieldSx }}>
                <InputLabel>Segment</InputLabel>

                <Select
                  disabled={isViewMode}
                  label="Segment"
                  value={fabricForm.segment}
                  onChange={(e) =>
                    onFabricFieldChange("segment", e.target.value)
                  }
                >
                  {fabricForm.segmentList.map((segment, index) => (
                    <MenuItem key={index} value={segment}>
                      {segment}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <TextField
                size="small"
                type="number"
                label="Radio Width"
                value={fabricForm?.radioWidth ?? ""}
                disabled={isViewMode}
                onChange={(e) =>
                  onFabricFieldChange?.("radioWidth", e.target.value)
                }
                sx={{ ...fieldThemeSx, ...fieldSx, minWidth: 125, width: 95 }}
                slotProps={{ htmlInput: { min: 1 } }}
              />
            </>
          )}

          {!isSvgMode && SUPERADMIN && (
            <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
              <ToolbarItem
                label="Filter"
                isDark={isDark}
                active={activeAction === "filter"}
                onClick={(e) => {
                  setActiveAction("filter");
                  setShowSettingsModal(e.currentTarget);
                }}
              >
                <img
                  src={topologyAdminIcons["settingsFilter"]}
                  alt="filter"
                  width={18}
                  height={18}
                  style={iconStyle} // Use style instead of className
                  className="object-contain"
                />
              </ToolbarItem>
              <ToolbarItem
                label="Delete"
                isDark={isDark}
                active={activeAction === "canvasDelete"}
                onClick={() => {
                  setActiveAction("canvasDelete");
                  setIsDeleteAllConfirm(true);
                }}
              >
                <img
                  src={topologyAdminIcons["delete"]}
                  alt="delete"
                  isDark={isDark}
                  width={18}
                  height={18}
                  style={iconStyle} // Use style instead of className
                  className="object-contain"
                />
              </ToolbarItem>
              {/* <ToolbarItem
                label="View"
                isDark={isDark}
                active={activeAction === "canvasView"}
                onClick={() => setActiveAction("canvasView")}
              >
                <img
                  src={topologyAdminIcons["eye"]}
                  alt="view"
                  width={18}
                  height={18}
                  style={iconStyle} // Use style instead of className
                  className="object-contain"
                />
              </ToolbarItem> */}
              <ToolbarItem
                label="Undo"
                isDark={isDark}
                disabled={currentViewTopology ? !canUndo : !canUndoRack}
                active={activeAction === "canvasUndo"}
                onClick={() => {
                  setActiveAction("canvasUndo");
                  currentViewTopology
                    ? dispatch(performUndo())
                    : dispatch(performUndoRack());
                }}
              >
                <img
                  src={topologyAdminIcons["undo"]}
                  alt="undo"
                  width={18}
                  height={18}
                  style={{ filter: theme.palette.custom.icon.iconFilter }}
                  className="object-contain"
                />
              </ToolbarItem>
              <ToolbarItem
                label="Redo"
                isDark={isDark}
                disabled={currentViewTopology ? !canRedo : !canRedoRack}
                active={activeAction === "canvasRedo"}
                onClick={() => {
                  setActiveAction("canvasRedo");
                  currentViewTopology
                    ? dispatch(performRedo())
                    : dispatch(performRedoRack());
                }}
              >
                <img
                  src={topologyAdminIcons["redo"]}
                  alt="redo"
                  width={18}
                  height={18}
                  style={iconStyle} // Use style instead of className
                  className="object-contain"
                />
              </ToolbarItem>
              <ToolbarItem
                label="Save"
                isDark={isDark}
                active={activeAction === "canvasSave"}
                onClick={() => {
                  setActiveAction("canvasSave");
                  setIsSaveConfirmOpen(true);
                }}
              >
                <img
                  src={topologyAdminIcons["save"]}
                  alt="save"
                  width={18}
                  height={18}
                  style={iconStyle} // Use style instead of className
                  className="object-contain"
                />
              </ToolbarItem>
            </Box>
          )}
        </Box>
      </Box>

      {/* ROW 2 */}
      {isSvgMode && SUPERADMIN && (
        <Box
          sx={{
            display: "flex",
            width: "100%",
            alignItems: "center",
            justifyContent: "flex-start",
            flexWrap: "wrap",
            gap: 1,
            mt: 1,
          }}
        >
          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>Upload</span>
            }
            disabled={isViewMode}
            active={activeAction === "upload"}
            onClick={() => setActiveAction("upload")}
            sx={{ color: theme.palette.text.tabcolor }}
          >
            <label
              style={{
                display: "flex",
                alignItems: "center",
                cursor: "pointer",
                margin: 0,
              }}
            >
              <img
                src={uploadIcon}
                alt="upload"
                style={{ filter: theme.palette.custom.icon.iconFilter }}
              />
              <input
                hidden
                type="file"
                accept=".jpg,.jpeg,image/jpeg"
                onChange={onFabricUpload}
              />
            </label>
          </ToolbarItem>

          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>Delete</span>
            }
            disabled={isViewMode || !fabricSelectedObject}
            active={activeAction === "delete"}
            onClick={() => {
              setActiveAction("delete");
              onFabricDeleteSelected?.();
            }}
          >
            <img
              src={deleteIcon}
              alt="delete selected"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem>

          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>
                Delete All
              </span>
            }
            disabled={isViewMode}
            active={activeAction === "deleteArrow"}
            onClick={() => {
              setActiveAction("deleteArrow");
              onFabricDeleteAll?.();
            }}
          >
            <img
              src={deleteArrowIcon}
              alt="delete arrows"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem>

          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>
                Delete SVG
              </span>
            }
            disabled={isViewMode}
            active={activeAction === "deleteSvg"}
            onClick={() => {
              setActiveAction("deleteSvg");
              onFabricFieldChange?.("deleteCanvas", null);
              setTimeout(() => {
                setActiveAction("");
              }, 400);
            }}
          >
            <img
              src={deleteSvgIcon}
              alt="delete canvas svg"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem>

          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>Arrow</span>
            }
            disabled={isViewMode}
            active={["line", "arrow", "doubleArrow"].includes(activeAction)}
            onClick={(e) => {
              setArrowMenuAnchor(e.currentTarget);
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 0.25 }}>
              <img
                src={arrowsIcon}
                alt="arrow selection dropdown"
                style={{ filter: theme.palette.custom.icon.iconFilter }}
              />
              <ChevronDown size={10} />
            </Box>
          </ToolbarItem>

          <Menu
            anchorEl={arrowMenuAnchor}
            open={isArrowMenuOpen}
            onClose={() => setArrowMenuAnchor(null)}
            slotProps={{ paper: { sx: { borderRadius: "8px", mt: 0.5 } } }}
          >
            <MenuItem
              onClick={() => {
                setActiveAction("line");
                onFabricAddLine?.("line");
                setArrowMenuAnchor(null);
              }}
            >
              <Minus size={14} style={{ marginRight: 8 }} /> Add Line
            </MenuItem>
            <MenuItem
              onClick={() => {
                setActiveAction("arrow");
                onFabricAddLine?.("arrow");
                setArrowMenuAnchor(null);
              }}
            >
              <ArrowRight size={14} style={{ marginRight: 8 }} /> Single Arrow
            </MenuItem>
            <MenuItem
              onClick={() => {
                setActiveAction("doubleArrow");
                onFabricAddLine?.("doubleArrow");
                setArrowMenuAnchor(null);
              }}
            >
              <ArrowLeftRight size={14} style={{ marginRight: 8 }} /> Double
              Arrow
            </MenuItem>
          </Menu>

          {/* <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>View</span>
            }
            active={activeAction === "view"}
            onClick={() => setActiveAction("view")}
          >
            <img
              src={viewEyeIcon}
              alt="view"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem> */}

          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>Undo</span>
            }
            disabled={!canUndo || isViewMode}
            active={activeAction === "undo"}
            onClick={() => {
              setActiveAction("undo");
              onCanvasUndo?.();
            }}
          >
            <img
              src={undoIcon}
              alt="undo"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem>

          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>Redo</span>
            }
            disabled={!canRedo || isViewMode}
            active={activeAction === "redo"}
            onClick={() => {
              setActiveAction("redo");
              onCanvasRedo?.();
            }}
          >
            <img
              src={redoIcon}
              alt="redo"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem>

          {/* {isSvgMode && ( */}
          <ToolbarItem
            label={
              <span style={{ color: theme.palette.text.tabcolor }}>Save</span>
            }
            disabled={isViewMode}
            active={activeAction === "saveJson"}
            onClick={() => {
              setActiveAction("saveJson");
              onFabricSave?.();
            }}
          >
            {/* <Save size={16} />saveIcon */}
            <img
              src={saveIcon}
              alt="save"
              style={{ filter: theme.palette.custom.icon.iconFilter }}
            />
          </ToolbarItem>
          {/* )} */}
        </Box>
      )}

      <Popover
        open={isSettingFormOpen}
        anchorEl={showSettingsModal}
        onClose={() => setShowSettingsModal(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      >
        <SettingsForm setShowSettingsModal={setShowSettingsModal} />
      </Popover>
    </Box>
  );
};

export default TopologyEditActions;
