import React, {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { ReactFlow, Controls, Background, useReactFlow } from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import {
  Box,
  Button,
  Popover,
  TextField,
  Typography,
  useTheme,
} from "@mui/material";
import ImageNode from "./NodeTypes/ImageNode";
import { TopologyAxios } from "../../../RestAPI/api/axiosApicall";
import { FETCH_EXISTING_LINK_CONFIGURATION_DETAILS } from "../../../RestAPI/url/endpoint";

import { useDispatch, useSelector } from "react-redux";
import {
  addNode,
  addNodeToRack,
  deleteAllNodesAndEdges,
  deleteAllNodesAndEdgesOfRack,
  deleteLink,
  hydrateRackFromSavedTopology,
  hydrateTopologyFromSavedTopology,
  onEdgesChange,
  onNodesChange,
  onNodesChangeOfRack,
  pushToUndoStack,
  pushToUndoStackRack,
  selectRackNodes,
  setNodes,
  updateEdgeConfiguration,
  updateNodeLabel,
} from "../../../store/features/Topology/topologyNodesslice";

import useTopologyUtilityMethod from "../../../utility/customHooks/useTopologyUtilityMethods";
import { generateRandomString } from "../../../utility/FormValidation/Regex";
import GroupNode from "./NodeTypes/GroupNode";

import MDialog from "../../../components/Reusable/Dialog/MDialog";

import NodePalette from "./NodePalette/NodePalette";
import EdgeMenu from "./EdgeMenu";
import { topologyAdminIcons } from "./topologyConstants";
import Toast from "@/components/Reusable/Toast/Toast";
import RackNode from "./NodeTypes/RackNode";
import RackFrame from "./NodeTypes/RackFrameNode";
import RackResourceName from "./NodeTypes/RackResourceName";
import MModal from "@/components/Reusable/Modal/MModal";
import BlankNode from "./NodeTypes/BlankNode";
import useFullscreen from "@/utility/customHooks/useFullscreen";
import NodeViewSwitcher from "./NodeViewSwitcher";
import TopologyEditActions from "./TopologyEditActions";
import NodeTooltip from "./Tooltip/NodeTooltip";
import ContextMenu from "@/components/Contextmenu/ContextMenu";
import ImageOnly from "./NodeTypes/ImageOnly";
import SimpleViewNode from "./NodeTypes/SimpleViewNode";

import Confirmation_icon from "../../../assets/SVGIcons/question_mark.svg";
import { getEdgeColor, normalizeTopologyNode } from "./utils";
import { isValidIpV4 } from "@/utility/FormValidation/YupSchema";
import { dispatchContextAction } from "@/core/actions/contextActionDispatcher";
import { FullscreenExit, Fullscreen } from "@mui/icons-material";
import PortMapping from "../TopologyFabric/PortMapping";
import UploadedImageNode from "./NodeTypes/UploadedImageNode";

// const DEVICE_NODE_TYPES = ["commonNode", "simpleViewNode", "imageViewNode"];
const DEVICE_NODE_TYPES = [
  "commonNode",
  "simpleViewNode",
  "imageViewNode",
  "rackNode",
  "rackResourceName",
];
const nodeTypes = {
  simpleViewNode: SimpleViewNode,
  imageViewNode: ImageNode,
  groupNode: GroupNode,
  commonNode: ImageNode,
  rackNode: RackNode,
  rackFrame: RackFrame,
  rackResourceName: RackResourceName,
  blankNode: BlankNode,
  imageOnly: ImageOnly,

  // New feature; existing node types remain unchanged.
  uploadedImage: UploadedImageNode,
};

const deleteIcon = topologyAdminIcons["delete"];
const verticalMenuIcon = topologyAdminIcons["verticalMenu"];

const downloadJson = (payload, fileName) => {
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = fileName;

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
};

const optimizeNodeForSave = (node, saveType) => {
  if (!node) return node;

  // Preserve uploaded image source, dimensions, style and position.
  if (node.type === "uploadedImage") {
    return {
      ...node,
      position: {
        x: Number(node.position?.x) || 0,
        y: Number(node.position?.y) || 0,
      },
      width: Number(node.width ?? node.data?.width ?? 160),
      height: Number(node.height ?? node.data?.height ?? 120),
      style: {
        ...node.style,
        width: Number(node.style?.width ?? node.data?.width ?? 160),
        height: Number(node.style?.height ?? node.data?.height ?? 120),
      },
      data: {
        ...node.data,
      },
    };
  }

  // Preserve your existing blank-node behavior.
  if (node.type === "blankNode") {
    return node;
  }

  // Keep the remainder of your existing implementation unchanged.
  const nodeData = node.data || {};

  const optimizedData = {
    resourceId: nodeData?.resourceId,
    viewMode: nodeData?.viewMode,
    type: nodeData?.type,
    idToGetImage: nodeData?.idToGetImage,
  };

  return {
    ...node,
    data: optimizedData,
  };
};

const SUPERADMIN = window.isSuperAdmin;

// const Topology = ({ topologyRenderMode = "canvas", setTopologyRenderMode, resources}) => {
// AFTER
const Topology = ({
  topologyRenderMode = "canvas",
  setTopologyRenderMode,

  // ---- CNMS additive props (all optional, RNMS unaffected) ----
  readOnly = false, // force view-only (no edit / drag / connect / context menu)
  loading: externalLoading = false, // show loader overlay over canvas
  terminalTypeOverride = "", // override siteDetails.terminalNickname for saved JSON lookup
  skipRackLoad = false, // CNMS is macro-only; skip rack JSON fetch
}) => {
  const {
    nodes,
    edges,
    // rackNodes,
    currentViewTopology,
    undoStack,
    redoStack,
    undoStackRack,
    redoStackRack,
    currentNodeView,
    switchTopology,
  } = useSelector((state) => state.topologySlice);
  const theme = useTheme();

  console.log("terminalTypeOverride", terminalTypeOverride);

  const rackNodes = useSelector(selectRackNodes);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  console.log("errornode", nodes);
  console.log("rackNodes1", rackNodes);

  const isDark = theme.palette.mode === "dark";
  const { siteDetails } = useSelector((state) => state.nodeDetails);
  //  const imageNodePortStatusview = useSelector((state) => state.topologySlice.imagePortStatus)

  const [blankNodePosition, setBlankNodePosition] = useState(null);
  const [blankNodeForm, setBlankNodeForm] = useState({
    text: "",
    color: "#ffffff",
    borderColor: "#ffffff",
  });

  const topologyTerminal_Type =
    terminalTypeOverride || siteDetails?.terminalNickname || "";
    
  console.log("topologyTerminal_Type", topologyTerminal_Type);
  const [blankNodeModalOpen, setBlankNodeModalOpen] = useState(false);

  const nodeTypeToAddToCanvas = currentViewTopology ? "commonNode" : "rackNode";
  // const { getNodesBounds, screenToFlowPosition } = useReactFlow();

  // const { getNodesBounds, screenToFlowPosition, fitView } = useReactFlow();
  const { getNodesBounds, screenToFlowPosition, fitView, getNodes } =
    useReactFlow();

  const [selectedNodes, setSelectedNodes] = useState([]);

  const [isDeleteAllConfirm, setIsDeleteAllConfirm] = useState(false);
  const [isSaveConfirmOpen, setIsSaveConfirmOpen] = useState(false);
  // const [rfInstance, setRfInstance] = useState(null);
  const rfInstanceRef = useRef(null);
  const [openTopoViewsAnchor, setOpenTopoViewsAnchor] = useState(false);
  const [editingNodeId, setEditingNodeId] = useState(null); // <-- Add this state track

  const [edgeMenu, setEdgeMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    edgeId: null,
  });

  console.log("njracknodes", nodes);

  const [anchorEl, setAnchorEl] = useState(null);
  const [activeNode, setActiveNode] = useState(null);
  const [alarms, setAlarms] = useState([]);
  const [loading, setLoading] = useState(false);
  const fetchRequestRef = useRef(0);
  const [portMappingOpen, setPortMappingOpen] = useState(false);
  const handlePortMappingToggle = () => {
    setPortMappingOpen((prev) => !prev);
  };

  const containerRef = useRef(null);

  const getTerminalTypeName = (terminalNickname = "") => {
    return terminalNickname.trim().split(/\s+/)[0] || "";
  };

  // const getTopologyFileName = (terminalNickname = "") => {
  //   return getTerminalTypeName(terminalNickname);
  // };

  // const [maintenanceModal, setMaintenanceModal] = useState({
  //   open: false,
  //   type: null, // 'addDevice' or 'deleteDevice'
  //   nodeData: null,
  // });

  const [formData, setFormData] = useState({ remark: "", resourceIp: "" });
  const [linkPopup, setLinkPopup] = useState({
    open: false,
    edgeId: null,
    anchorEl: null,
  });

  // 2. Add local modal tracking state
  const [renameModal, setRenameModal] = useState({
    isOpen: false,
    nodeId: "",
    currentLabel: "",
  });

  const allNodes = useMemo(() => {
    const sourceNodes = currentViewTopology ? nodes : rackNodes;

    return sourceNodes.map((node) => ({
      ...node,
      id: node.id || crypto.randomUUID(),
      type: node.type || "commonNode",
      position: {
        x: Number(node?.position?.x) || 0,
        y: Number(node?.position?.y) || 0,
      },
      data: node.data || {},
    }));
  }, [currentViewTopology, nodes, rackNodes]);

  console.log("allNodes", allNodes);

  const [linkConfigurations, setLinkConfigurations] = useState([]);

  const fetchLinkConfigurations = async () => {
    try {
      const response = await TopologyAxios(
        FETCH_EXISTING_LINK_CONFIGURATION_DETAILS,
        "get"
      );

      setLinkConfigurations(response?.data || []);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchLinkConfigurations();
  }, []);

  const handleNodeClick = useCallback((event, node) => {
    if (node.type === "blankNode") {
      setEditingNodeId(node.id);

      // Safely extract text/label
      const nodeText = node.data?.text || node.data?.label || "";

      // Check node.data, node.style, or fallback to default white
      const backgroundColor =
        node.data?.color ||
        node.data?.backgroundColor ||
        node.style?.backgroundColor ||
        node.style?.background ||
        "#ffffff";

      const borderColor =
        node.data?.borderColor || node.style?.borderColor || "#ffffff";

      setBlankNodeForm({
        text: nodeText,
        color: backgroundColor,
        borderColor: borderColor,
      });

      setBlankNodeModalOpen(true);
    }
  }, []);

  const handleSaveBlankNodeForm = () => {
    if (editingNodeId) {
      // ---- EDIT / UPDATE MODE ----
      if (currentViewTopology) {
        dispatch(pushToUndoStack());
      } else {
        dispatch(pushToUndoStackRack());
      }

      // Pass text, background color, and border color to Redux
      dispatch(
        updateNodeLabel({
          id: editingNodeId,
          label: blankNodeForm.text,
          color: blankNodeForm.color,
          borderColor: blankNodeForm.borderColor,
        })
      );
    } else {
      // ---- CREATE MODE ----
      handleCreateBlankNode();
    }

    // Reset modal states
    setBlankNodeModalOpen(false);
    setEditingNodeId(null);
    setBlankNodeForm({ text: "", color: "#ffffff", borderColor: "#ffffff" });
  };

  // C. Dynamic Modal Closure Handler
  const handleCloseBlankNodeModal = () => {
    setBlankNodeModalOpen(false);
    setEditingNodeId(null);
    setBlankNodeForm({ text: "", color: "#ffffff", borderColor: "#ffffff" });
  };

  // const rawIp = formData.resourceIp.replace(/_/g, "");
  const rawIpForValidation = (formData?.resourceIp || "").replace(/_/g, "");
  const isIpValid = isValidIpV4(rawIpForValidation);
  // const isRemarkValid = (formData?.remark || "").trim().length >= 5;

  // The button should only be enabled if IP is valid AND Remark is valid
  // const isAddValid = isIpValid && isRemarkValid;

  const formatIPMask = (value = "") => {
    // Strip everything that isn't a number
    let digits = value.replace(/\D/g, "").slice(0, 12);

    let parts = [];
    for (let i = 0; i < 4; i++) {
      let segment = digits.slice(i * 3, i * 3 + 3);
      parts.push(segment.padEnd(3, "_"));
    }
    return parts.join(".");
  };

  // Error state for UI
  // const ipError =
  //   rawIpForValidation.length > 0 &&
  //   rawIpForValidation.split(".").some((seg) => seg.length === 3) &&
  //   !isIpValid;

  // Create an array of resourceIds currently on the canvas
  const usedNodeIds = useMemo(() => {
    return nodes.map((n) => n.data?.resourceId).filter(Boolean);
  }, [nodes]);

  const usedNodeIDsInRack = useMemo(() => {
    return rackNodes.map((n) => n.data?.resourceId).filter(Boolean);
  }, [rackNodes]);

  const topologyContainerRef = useRef(null);

  const canUndo = undoStack.length > 0;
  const canRedo = redoStack.length > 0;

  const canUndoRack = undoStackRack.length > 0;
  const canRedoRack = redoStackRack.length > 0;

  const { isFullscreen, toggleFullscreen } = useFullscreen(containerRef);

  useEffect(() => {
    if (!isFullscreen) return;

    const timer = setTimeout(() => {
      fitView({
        padding: 0.15,
        duration: 500,
        minZoom: 0.01,
        maxZoom: 50,
      });
    }, 200);

    return () => clearTimeout(timer);
  }, [isFullscreen, fitView]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fitView({
        padding: 0.2,
        duration: 300,
      });
    }, 350);

    return () => clearTimeout(timer);
  }, [portMappingOpen, fitView]);

  useEffect(() => {
    const resizeObserver = new ResizeObserver(() => {
      fitView({
        padding: 0.15,
        duration: 300,
      });
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    return () => resizeObserver.disconnect();
  }, [fitView, currentViewTopology]);

  const isTopoViewToolsOpen = Boolean(openTopoViewsAnchor);

  // const { onConnect } = useTopologyUtilityMethod();

  const { onConnect } = useTopologyUtilityMethod({
    onEdgeCreated: (edge) => {
      const targetNode = (currentViewTopology ? nodes : rackNodes).find(
        (n) => n.id === edge.target
      );
      let rf = rfInstanceRef?.current;

      if (!targetNode || !rf) return;

      const domRect = document
        .querySelector(`[data-id="${edge.target}"]`)
        ?.getBoundingClientRect();

      if (!domRect) return;

      setLinkPopup({
        open: true,
        edgeId: edge.id,
        
        // 👇 THIS IS THE FIX
        x: domRect.left - 10, // LEFT SIDE of Device B
        y: domRect.top + domRect.height / 2,
      });
    },
  });

  const [currentTabKey, setCurrentTabKey] = useState(switchTopology || "");

  const dispatch = useDispatch();

  const [menuAnchor, setMenuAnchor] = useState(null);

  console.log("jdbnjftgb", menuAnchor);

  const handleNodeChanges = useCallback(
    (changes) => {
      const shouldPushHistory = changes.some(
        (change) => change.type === "remove" || change.type === "add"
      );
      if (shouldPushHistory) {
        currentViewTopology
          ? dispatch(pushToUndoStack())
          : dispatch(pushToUndoStackRack());
      }

      if (currentViewTopology) {
        setActiveNode(null);
        dispatch(onNodesChange(changes));
      } else {
        setActiveNode(null);
        dispatch(onNodesChangeOfRack(changes));
      }
    },
    [dispatch, currentViewTopology]
  );

  const handleEdgeChanges = useCallback((changes) => {
    const shouldPushHistory = changes.some(
      (change) => change.type === "remove" || change.type === "add"
    );
    if (shouldPushHistory) {
      dispatch(pushToUndoStack());
    }
    dispatch(onEdgesChange(changes));
  }, []);

  const loadSavedRack = useCallback(async () => {
    try {
      const terminalType = getTerminalTypeName(topologyTerminal_Type); // was siteDetails?.terminalNickname

      console.log("terminalTypecnms", terminalType);

      if (!terminalType) {
        console.warn("Terminal type not available");
        return;
      }
      const response = await fetch(
        `/savedRackNode/${encodeURIComponent(terminalType)}.json`
      );
      console.log("responsecnmsrack", response);

      if (!response.ok)
        throw new Error(`Rack JSON not found: ${terminalType}.json`);
      const rackData = await response.json();
      dispatch(hydrateRackFromSavedTopology(rackData?.nodes || []));
    } catch (error) {
      console.error("Failed to load saved rack:", error);
    }
  }, [topologyTerminal_Type, dispatch]);

  const loadSavedTopology = useCallback(async () => {
    try {
      const terminalType = getTerminalTypeName(topologyTerminal_Type); // was siteDetails?.terminalNickname
      if (!terminalType) {
        console.warn("Terminal type not available");
        return;
      }
      const response = await fetch(
        `/savedReactflowTopology/${encodeURIComponent(terminalType)}.json`
      );
      if (!response.ok)
        throw new Error(`Topology JSON not found: ${terminalType}.json`);
      const topologyData = await response.json();
      dispatch(hydrateTopologyFromSavedTopology(topologyData));
    } catch (error) {
      console.error("Failed to load saved topology:", error);
    }
  }, [topologyTerminal_Type, dispatch]); // dep change

  useEffect(() => {
    if (!topologyTerminal_Type) return;

    // CNMS (readOnly) path: wait until Redux has the resource data.
    // This prevents hydrateTopologyFromSavedTopology from merging
    // saved JSON against an empty state.nodes.
    if (readOnly && nodes.length === 0) return;

    loadSavedTopology();
  }, [topologyTerminal_Type, loadSavedTopology, readOnly, nodes.length]);

  useEffect(() => {
    if (!topologyTerminal_Type) return;
    if (readOnly && nodes.length === 0) return;
    loadSavedRack();
  }, [topologyTerminal_Type, loadSavedRack, readOnly, skipRackLoad]);

  const onSelectionEnd = useCallback(() => {
    if (selectedNodes.length > 1) {
      const bounds = getNodesBounds(selectedNodes);
      const groupId = "group-" + generateRandomString(8);

      const newGroupNode = {
        id: groupId,
        type: "groupNode",
        position: { x: bounds.x - 25, y: bounds.y - 25 },
        style: {
          width: bounds.width + 30,
          height: bounds.height + 30,
          backgroundColor: "transparent",
          border: "1px solid gray",
          borderRadius: "10px",
          zIndex: -1,
        },
        data: { label: "" },
      };

      const updatedNodes = nodes.map((node) => {
        if (selectedNodes.some((selectedNode) => selectedNode.id === node.id)) {
          return {
            ...node,
            parentNode: groupId,
            position: {
              x: node?.position?.x,
              y: node?.position?.y,
            },
            extent: "parent",
          };
        }
        return node;
      });

      if (currentViewTopology) {
        dispatch(pushToUndoStack());

        dispatch(setNodes([...updatedNodes, newGroupNode]));
      } else {
        return;
      }
    }
  }, [selectedNodes]);

  const onSelectionChange = useCallback(({ nodes, edges }) => {
    setSelectedNodes(nodes);
  });

  const handleDeleteAllNodes = useCallback(() => {
    // dispatch(pushToUndoStack());

    if (currentViewTopology) {
      dispatch(pushToUndoStack());
      dispatch(deleteAllNodesAndEdges());
    } else {
      dispatch(pushToUndoStackRack());
      dispatch(deleteAllNodesAndEdgesOfRack());
    }
    setIsDeleteAllConfirm(false);
  }, [currentViewTopology, dispatch]);

  const handleCreateBlankNode = () => {
    const newNode = {
      id: "blank-" + generateRandomString(6),
      type: "blankNode",
      position: blankNodePosition,
      data: {
        label: blankNodeForm.text,
        backgroundColor: blankNodeForm.color,
        borderColor: blankNodeForm.borderColor,
      },
    };

    // dispatch(pushToUndoStack());

    if (nodeTypeToAddToCanvas == "commonNode") {
      dispatch(pushToUndoStack());
      dispatch(addNode([newNode]));
    } else if (nodeTypeToAddToCanvas == "rackNode") {
      dispatch(pushToUndoStackRack());
      dispatch(addNodeToRack([newNode]));
    }

    setBlankNodeModalOpen(false);

    setBlankNodeForm({
      text: "",
      color: "#ffffff",
    });
  };

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const getNodeType = (nodeMetadata) => {
    if (nodeMetadata?.type === "imageOnly") {
      return "imageOnly";
    } else {
      if (nodeMetadata?.type === "rackFrame") {
        return "rackFrame";
      } else {
        return nodeTypeToAddToCanvas;
      }
    }
  };

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      // 1. Get the raw string and parse it back to an object
      const rawData = event.dataTransfer.getData("application/reactflow");
      // if (!rawData) return;

      const nodeMetadata = JSON.parse(rawData);
      const fullNodeDataWithCurrentViewMode = {
        ...nodeMetadata,
        viewMode: currentTabKey,
      };

      // 2. Calculate position
      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      // 👇 If blank node
      if (nodeMetadata?.type === "blankNode") {
        setBlankNodePosition(position);
        setBlankNodeModalOpen(true);
        return;
      }

      let newNodes = [];

      const newNode = normalizeTopologyNode({
        id: nodeMetadata.resourceId,
        type: getNodeType(nodeMetadata),
        position,
        data: {
          ...nodeMetadata,
          ...fullNodeDataWithCurrentViewMode,

          // FORCE REQUIRED FIELDS
          type: nodeMetadata.type || "commonNode",
          switchTemplateKey: nodeMetadata.switchTemplateKey || null,
          lstPortInfoDtl: nodeMetadata.lstPortInfoDtl || [],
        },
      });

      console.log(newNode, "newNodenewNode");

      newNodes.push(newNode);
      // dispatch(pushToUndoStack());

      // this is to add resource name which is displayed on the left side of the rack
      if (
        nodeTypeToAddToCanvas == "rackNode" &&
        nodeMetadata?.type != "rackFrame"
      ) {
        newNodes.push({
          id: nodeMetadata.resourceId + "_NodeName",
          type: "rackResourceName",

          position: {
            x: Number(position?.x || 0) + 20,
            y: Number(position?.y || 0) + 10,
          },

          data: nodeMetadata || {},
        });
      }
      if (nodeTypeToAddToCanvas == "commonNode") {
        dispatch(pushToUndoStack());
        dispatch(addNode(newNodes));
        console.log("newNodesnewNodes", newNodes);
      } else if (nodeTypeToAddToCanvas == "rackNode") {
        dispatch(pushToUndoStackRack());
        const validNodes = newNodes.map((node) => ({
          ...node,
          position: {
            x: Number(node.position?.x) || 0,
            y: Number(node.position?.y) || 0,
          },
        }));

        dispatch(addNodeToRack(validNodes));
        // dispatch(addNodeToRack(newNodes));
      }
    },
    [screenToFlowPosition, dispatch, currentNodeView, nodeTypeToAddToCanvas]
  );

  const onEdgeContextMenu = useCallback((event, edge) => {
    event.preventDefault();

    const bounds = topologyContainerRef.current.getBoundingClientRect();

    const flowPosition = screenToFlowPosition({
      x: event.clientX,
      y: event.clientY,
    });

    setLinkPopup({
      open: true,
      edgeId: edge.id,
      x: flowPosition.x,
      y: flowPosition.y,
    });

    const menuHeight = 120;
    const menuWidth = 144;
    const viewportWidth = bounds.width;
    const viewportHeight = bounds.height;

    let newY = event.clientY;
    let newX = event.clientX;

    if (event.clientY + menuHeight > viewportHeight) {
      newY = event.clientY - menuHeight - 10;
    }
    if (event.clientX + menuWidth > viewportWidth) {
      newX = event.clientX - menuWidth;
    }

    setEdgeMenu({
      visible: true,
      x: newX - bounds.left,
      y: newY - bounds.top,

      edgeId: edge.id,
    });
  }, []);

  const handleUploadedImage = useCallback(
    async (file) => {
      if (!file) return;

      const extensionIsValid = /\.(png|svg|jpg|jpeg)$/i.test(file.name);
      const mimeIsValid = ["image/png", "image/svg+xml", "image/jpeg"].includes(
        file.type
      );

      if (!extensionIsValid || !mimeIsValid) {
        Toast("Invalid file", "Please upload a PNG or SVG image.", "error");
        return;
      }

      try {
        const src = await new Promise((resolve, reject) => {
          const reader = new FileReader();

          reader.onload = () => {
            if (typeof reader.result === "string") {
              resolve(reader.result);
            } else {
              reject(new Error("Unable to read image file"));
            }
          };

          reader.onerror = () => reject(new Error("Unable to read image file"));

          reader.readAsDataURL(file);
        });

        // Place the new image in the visible center of the React Flow canvas.
        const flowElement = containerRef.current?.querySelector(".react-flow");

        if (!flowElement) {
          Toast("Error", "Canvas is not ready.", "error");
          return;
        }

        const bounds = flowElement.getBoundingClientRect();

        const position = screenToFlowPosition({
          x: bounds.left + bounds.width / 2,
          y: bounds.top + bounds.height / 2,
        });

        const id = `uploaded-image-${generateRandomString(8)}`;

        const width = 160;
        const height = 120;

        const newNode = {
          id,
          type: "uploadedImage",
          position,
          width,
          height,
          style: {
            width,
            height,
          },
          data: {
            isUploadedImage: true,
            src,
            fileName: file.name,
            mimeType: file.type,
            width,
            height,
          },
        };

        // Preserve the appropriate undo history.
        if (currentViewTopology) {
          dispatch(pushToUndoStack());
          dispatch(addNode([newNode]));
        } else {
          dispatch(pushToUndoStackRack());
          dispatch(addNodeToRack([newNode]));
        }

        Toast("Success", "Image added to canvas.", "success");
      } catch (error) {
        console.error("Failed to upload topology image:", error);

        Toast("Error", "Unable to load the selected image.", "error");
      }
    },
    [containerRef, screenToFlowPosition, currentViewTopology, dispatch]
  );

  const closeContextMenu = useCallback(() => {
    setEdgeMenu({ visible: false, x: 0, y: 0, node: null });
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      closeContextMenu();
    };

    window.addEventListener("click", handleClickOutside);

    return () => {
      window.removeEventListener("click", handleClickOutside);
    };
  }, [edgeMenu.visible]);

  const handleDeleteEdge = () => {
    dispatch(pushToUndoStack());
    dispatch(deleteLink(edgeMenu.edgeId));
  };

  const handleSaveTopology = useCallback(() => {
    try {
      const instance = rfInstanceRef.current;

      if (!instance) {
        Toast("Error", "Canvas not initialized", "error");
        return;
      }

      const terminalNickname = siteDetails?.terminalNickname || "";

      const terminalType =
        getTerminalTypeName(terminalNickname) || "UnknownTerminal";

      // --------------------------------------------------
      // IMPORTANT:
      // Get the latest nodes directly from React Flow.
      // This includes the latest dragged positions.
      // --------------------------------------------------
      const currentNodes = instance.getNodes();

      // --------------------------------------------------
      // OPTIMIZE TOPOLOGY NODES BEFORE SAVING
      //
      // Only MCT_EP_SWITCH-24PORT keeps lstPortInfoDtl.
      // Every other node loses it.
      // --------------------------------------------------
      const optimizedNodes = currentNodes.map((node) =>
        optimizeNodeForSave(node, "topology")
      );

      // --------------------------------------------------
      // Edges remain completely unchanged
      // --------------------------------------------------
      const currentEdges = instance.getEdges();

      const payload = {
        module: "topology",
        renderer: "reactflow",
        version: 1,
        savedAt: new Date().toISOString(),

        nodes: optimizedNodes,
        edges: currentEdges,
      };

      const fileName = `${terminalType}.json`;

      console.log("Saving OPTIMIZED topology JSON:", fileName, payload);

      downloadJson(payload, fileName);

      Toast("Success!", `${fileName} downloaded successfully`, "success");
    } catch (error) {
      console.error("Error downloading topology:", error);

      Toast("Error", "Failed to download topology", "error");
    }

    setIsSaveConfirmOpen(false);
  }, [siteDetails, getTerminalTypeName]);

  const handleSaveRack = useCallback(() => {
    try {
      const instance = rfInstanceRef.current;

      if (!instance) {
        Toast("Error", "Canvas not initialized", "error");
        return;
      }

      const terminalNickname = siteDetails?.terminalNickname || "";

      const terminalType =
        terminalNickname.trim().split(/\s+/)[0] || "UnknownTerminal";

      const currentNodes = instance.getNodes();

      // Rack JSON optimization
      // lstPortInfoDtl is removed from EVERY rack node
      const optimizedNodes = currentNodes.map((node) =>
        optimizeNodeForSave(node, "rack")
      );

      const rackData = {
        nodes: optimizedNodes,
      };

      const blob = new Blob([JSON.stringify(rackData, null, 2)], {
        type: "application/json",
      });

      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = `${terminalType}.json`;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      URL.revokeObjectURL(url);

      Toast(
        "Success!",
        `${terminalType}.json downloaded successfully`,
        "success"
      );
    } catch (error) {
      console.error("Error downloading rack data:", error);

      Toast("Error", "Failed to download rack data", "error");
    }

    setIsSaveConfirmOpen(false);
  }, [siteDetails]);

  const closeTopoViewsTools = () => {
    setOpenTopoViewsAnchor(null);
  };

  const onInit = useCallback((instance) => {
    // setRfInstance(instance); // This triggers re-renders (useful for UI)
    rfInstanceRef.current = instance; // This is an instant reference (useful for logic)
  }, []);

  const whatToSaveTopoOrRack = useCallback(() => {
    if (currentViewTopology) {
      handleSaveTopology();
    } else {
      handleSaveRack();
    }
  }, [currentViewTopology, handleSaveTopology, handleSaveRack]);

  // full screen

  // const onNodeMouseEnter = useCallback(async (event, node) => {
  //   if (
  //     node.type != "commonNode" &&
  //     node.type != "rackNode" &&
  //     node.type != "rackResourceName"
  //   ) {
  //     return;
  //   }

  //   setAnchorEl(event.currentTarget);
  //   setActiveNode(node);
  //   setLoading(true);
  // }, []);

  const onNodeMouseEnter = useCallback(
    (event, hoveredNode) => {
      let targetNode = hoveredNode;
      let targetElement = event.currentTarget;

      // If the uploaded image is hovered, find the device underneath it.
      if (hoveredNode?.type === "uploadedImage") {
        const currentNodes = getNodes();

        const nodeElements =
          containerRef.current?.querySelectorAll(".react-flow__node");

        if (!nodeElements) return;

        const matchingNodes = [];

        nodeElements.forEach((element) => {
          const rect = element.getBoundingClientRect();

          const isUnderPointer =
            event.clientX >= rect.left &&
            event.clientX <= rect.right &&
            event.clientY >= rect.top &&
            event.clientY <= rect.bottom;

          if (!isUnderPointer) return;

          const nodeId = element.getAttribute("data-id");

          const underlyingNode = currentNodes.find(
            (item) => item.id === nodeId
          );

          if (
            underlyingNode &&
            underlyingNode.id !== hoveredNode.id &&
            DEVICE_NODE_TYPES.includes(underlyingNode.type)
          ) {
            matchingNodes.push({
              node: underlyingNode,
              element,
              area: rect.width * rect.height,
            });
          }
        });

        if (matchingNodes.length === 0) {
          setAnchorEl(null);
          setActiveNode(null);
          return;
        }

        matchingNodes.sort((a, b) => a.area - b.area);

        targetNode = matchingNodes[0].node;
        targetElement = matchingNodes[0].element;
      }

      if (!DEVICE_NODE_TYPES.includes(targetNode?.type)) return;

      setAnchorEl(targetElement);
      setActiveNode(targetNode);
      setLoading(true);
    },
    [getNodes]
  );

  const onNodeMouseLeave = useCallback(() => {
    setAnchorEl(null);
    setActiveNode(null);
    fetchRequestRef.current++;
  }, []);

  const onNodeContextMenu = useCallback(
    (event, clickedNode) => {
      // Always prevent the browser's native right-click menu.
      event.preventDefault();

      // Normal device right-click: preserve existing behaviour.
      if (DEVICE_NODE_TYPES.includes(clickedNode?.type)) {
        setMenuAnchor({
          mouseX: event.clientX,
          mouseY: event.clientY,
          node: clickedNode,
        });
        return;
      }

      // Only forward right-clicks from uploaded images.
      if (clickedNode?.type !== "uploadedImage") {
        return;
      }

      // Get all current React Flow nodes.
      const currentNodes = getNodes();

      // Find the actual DOM elements underneath the pointer.
      const nodeElements =
        containerRef.current?.querySelectorAll(".react-flow__node");

      if (!nodeElements) return;

      const matchingNodes = [];

      nodeElements.forEach((element) => {
        const rect = element.getBoundingClientRect();

        const isUnderPointer =
          event.clientX >= rect.left &&
          event.clientX <= rect.right &&
          event.clientY >= rect.top &&
          event.clientY <= rect.bottom;

        if (!isUnderPointer) return;

        const nodeId = element.getAttribute("data-id");

        const targetNode = currentNodes.find((item) => item.id === nodeId);

        // Ignore the uploaded image and all non-device nodes.
        if (
          targetNode &&
          targetNode.id !== clickedNode.id &&
          DEVICE_NODE_TYPES.includes(targetNode.type)
        ) {
          matchingNodes.push({
            node: targetNode,
            area: rect.width * rect.height,
          });
        }
      });

      if (matchingNodes.length === 0) return;

      // Prefer the smallest device node under the pointer.
      matchingNodes.sort((a, b) => a.area - b.area);

      const targetNode = matchingNodes[0].node;

      // Display the underlying device's context menu.
      setMenuAnchor({
        mouseX: event.clientX,
        mouseY: event.clientY,
        node: targetNode,
      });
    },
    [getNodes]
  );

  ("");
  const handleLinkSelection = (event) => {
    const value = event.target.value;

    if (value === "NONE") {
      dispatch(
        updateEdgeConfiguration({
          edgeId: linkPopup.edgeId,
          color: "grey",
          linkId: null,
          linkName: null,
          linkStatus: null,
        })
      );

      setLinkPopup((prev) => ({ ...prev, open: false }));
      return;
    }

    const selected = linkConfigurations.find((item) => item.linkName === value);

    const color = getEdgeColor(selected.linkStatus);

    console.log("linkPopup.edgeId", linkPopup.edgeId);

    dispatch(
      updateEdgeConfiguration({
        edgeId: linkPopup.edgeId,

        color,

        linkId: selected.linkId,

        linkName: selected.linkName,

        linkStatus: selected.linkStatus,
      })
    );

    setLinkPopup((prev) => ({ ...prev, open: false }));
  };

  const handleCloseMenu = () => setMenuAnchor(null);

  const handleMenuAction = (action, nodeData) => {
    console.log("fhbjaction", action);

    const modalActions = [
      "addDevice",
      "deleteDevice",
      "inventory",
      "pollingInterval",
      "alarmSuppression",
    ];

    if (modalActions.includes(action)) {
      if (action === "inventory") {
        dispatchContextAction({
          action: "inventory",
          node: nodeData,
          source: "topology",
        });
      }
      if (action === "pollingInterval") {
        dispatchContextAction({
          action: "pollingInterval",
          node: nodeData,
          source: "topology",
        });
      }
      if (action === "alarmSuppression") {
        dispatchContextAction({
          action: "alarmSuppression",
          node: nodeData,
          source: "topology",
        });
      } else {
        const initialIp =
          action === "addDevice"
            ? formatIPMask(nodeData?.resourceIp || "")
            : "";

        setFormData({
          remark: "", // Usually keep remarks empty for a new action
          resourceIp: initialIp,
        });

        // setMaintenanceModal({
        //   open: true,
        //   type: action,
        //   nodeData,
        // });
      }
    }
    handleCloseMenu();
  };

  const isEditable = SUPERADMIN;

  function whenEditable(callback) {
    return isEditable ? callback : undefined;
  }

  const topologyEvents = {
    onNodesChange: whenEditable(handleNodeChanges),
    onEdgesChange: whenEditable(handleEdgeChanges),
    onConnect: whenEditable(onConnect),
    onSelectionEnd: whenEditable(onSelectionEnd),
    onSelectionChange: whenEditable(onSelectionChange),
    onDrop: onDrop,
    onDragOver: onDragOver,
    onEdgeContextMenu: onEdgeContextMenu,
    onNodeContextMenu: onNodeContextMenu,
  };

  // const topologyEvents = {
  //   // Edit events — gated off in CNMS
  //   onNodesChange: whenEditable(handleNodeChanges),
  //   onEdgesChange: whenEditable(handleEdgeChanges),
  //   onConnect: whenEditable(onConnect),
  //   onSelectionEnd: whenEditable(onSelectionEnd),
  //   onSelectionChange: whenEditable(onSelectionChange),

  //   // Drag / edge context menu — gated off in CNMS
  //   onDrop: readOnly ? undefined : onDrop,
  //   onDragOver: readOnly ? undefined : onDragOver,
  //   onEdgeContextMenu: readOnly ? undefined : onEdgeContextMenu,

  //   // Node context menu — ALWAYS allowed
  //   // (the menu itself decides which items to show via `viewOnly`)
  //   onNodeContextMenu: onNodeContextMenu,
  // };

  const handleSave = useCallback(() => {
    handleSaveTopology();
  }, [handleSaveTopology]);

  const handleClose = () => {
    setRenameModal({
      isOpen: false,
      nodeId: "",
      currentLabel: "",
    });
  };

  return (
    <Box className="flex h-full w-full overflow-hidden ">
      {/* LEFT SIDEBAR - NODE PALETTE */}
      {SUPERADMIN && (
        <Box
          className="w-28 flex-shrink-0 border-r-2 border-[#D0D0D0]  overflow-y-auto"
          sx={{ background: "background.primary" }}
        >
          {/* <NodePalette
            usedNodeIds={currentViewTopology ? usedNodeIds : usedNodeIDsInRack}
          /> */}
          <NodePalette
            usedNodeIds={currentViewTopology ? usedNodeIds : usedNodeIDsInRack}
            onImageUpload={handleUploadedImage}
          />
        </Box>
      )}

      {/* RIGHT SIDE - TOOLBAR + CANVAS */}
      <Box
        className="flex-1 flex flex-col min-w-0 h-full  "
        sx={{ background: (theme) => theme.palette.background.paper }}
      >
        {/* TOP TOOLBAR */}
        <Box className="shrink-0 ">
          <Box
            className="flex items-center gap-2   border-b border-[#D9D9D9] px-2 overflow-hidden"
            sx={{ background: (theme) => theme.palette.background.secondary }}
          >
            <TopologyEditActions
              // currentViewTopology={currentViewTopology}
              // setIsDeleteAllConfirm={setIsDeleteAllConfirm}
              // canUndo={canUndo}
              // canRedo={canRedo}
              // canUndoRack={canUndoRack}
              // canRedoRack={canRedoRack}
              // setIsSaveConfirmOpen={setIsSaveConfirmOpen}
              currentViewTopology={currentViewTopology}
              topologyRenderMode={topologyRenderMode}
              setTopologyRenderMode={setTopologyRenderMode}
              setIsDeleteAllConfirm={setIsDeleteAllConfirm}
              canUndo={canUndo}
              canRedo={canRedo}
              canUndoRack={canUndoRack}
              canRedoRack={canRedoRack}
              setIsSaveConfirmOpen={setIsSaveConfirmOpen}
              onCanvasSave={handleSave}
              onPortMappingToggle={handlePortMappingToggle}
            />
          </Box>
        </Box>

        {/* REACT FLOW CANVAS CONTAINER */}
        <Box
          ref={containerRef}
          className="flex-1 min-h-0 overflow-hidden"
          sx={{
            display: "flex",
            flexDirection: "row",
            backgroundColor: theme.palette.background.toplogybg,
          }}
        >
          {/* ============================= */}
          {/* TOPOLOGY / REACT FLOW AREA */}
          {/* ============================= */}

          <Box
            sx={{
              position: "relative",
              minWidth: 0,
              minHeight: 0,
              // height:"70vh",
              // 5:2 ratio
              flex: portMappingOpen ? "3 1 0%" : "1 1 0%",

              transition: "flex 0.3s ease",
              overflow: "hidden",

              ...(isCnms && { height: "70vh" }),
            }}
          >
            <ReactFlow
              ref={topologyContainerRef}
              nodes={currentViewTopology ? allNodes : rackNodes}
              edges={(currentViewTopology ? edges : []).map((edge) => ({
                ...edge,
                style: {
                  ...edge.style,
                  strokeWidth: 4,
                },
              }))}
              nodeTypes={nodeTypes}
              fitView
              onNodeClick={handleNodeClick}
              style={{
                backgroundColor: theme.palette.background.paper,
                width: "100%",
                height: "100%",
              }}
              onInit={onInit}
              defaultEdgeOptions={{ type: "smoothstep" }}
              nodesDraggable={true}
              elementsSelectable={true}
              proOptions={{ hideAttribution: true }}
              elevateNodesOnSelect={false}
              onNodeMouseEnter={onNodeMouseEnter}
              onNodeMouseLeave={onNodeMouseLeave}
              minZoom={0.01}
              maxZoom={50}
              onPaneClick={() => {
                setLinkPopup({
                  open: false,
                  edgeId: null,
                  x: 0,
                  y: 0,
                });
              }}
              {...topologyEvents}
            >
              {/* EVERYTHING THAT IS CURRENTLY INSIDE YOUR REACTFLOW */}
              <Controls
                showInteractive={false}
                position="bottom-right"
                style={{
                  backgroundColor: theme.palette.custom.reactFlow.controlsBg,
                  color: theme.palette.custom.reactFlow.controlsIcon,
                  border: `1px solid ${theme.palette.custom.reactFlow.controlsBorder}`,
                }}
              />

              <Background
                gap={20}
                variant="dots"
                size={1}
                color={theme.palette.custom.reactFlow.backgroundDots}
              />

              {edgeMenu?.visible && (
                <Box
                  style={{
                    position: "absolute",
                    top: edgeMenu.y,
                    left: edgeMenu.x,
                    display: "flex",
                    flexDirection: "row-reverse",
                    gap: "20px",
                    zIndex: 1000,
                  }}
                >
                  <Box
                    style={{
                      background: "white",
                      border: "2px solid #eeeeee",
                      padding: 10,
                      borderRadius: 6,
                    }}
                  >
                    <EdgeMenu
                      setEdgeMenu={setEdgeMenu}
                      edgeMenu={edgeMenu}
                      edges={edges}
                    />
                  </Box>
                  <Box style={{ backgroundColor: "#", minWidth: 0 }}>
                    <Button
                      onClick={handleDeleteEdge}
                      sx={{ color: "#D75961", minWidth: 0 }}
                    >
                      <img
                        src={deleteIcon}
                        alt="delete"
                        style={{
                          filter:
                            "invert(34%) sepia(92%) saturate(1352%) hue-rotate(337deg) brightness(92%) contrast(90%)",
                        }}
                      />
                    </Button>
                  </Box>
                </Box>
              )}

              {anchorEl && (
                <NodeTooltip
                  anchorEl={anchorEl}
                  activeNode={activeNode}
                  alarms={alarms}
                  isLoading={loading}
                  container={containerRef.current}
                />
              )}

              {/* context menu */}
              {menuAnchor && (
                <ContextMenu
                  anchor={menuAnchor}
                  node={menuAnchor.node}
                  onClose={() => setMenuAnchor(null)}
                  onAction={handleMenuAction}
                  container={containerRef.current}
                  viewOnly={readOnly}
                />
              )}

              <Box
                sx={{
                  float: "right",
                  padding: "10px",
                  zIndex: "100",
                  position: "absolute",
                  right: "0",
                }}
              >
                {currentViewTopology && (
                  <Button
                    sx={{
                      border: "2px solid #D9D9D9",
                      minWidth: "0",
                      borderRadius: "10px",
                      gap: 2,
                    }}
                    onClick={(e) => setOpenTopoViewsAnchor(e.currentTarget)}
                  >
                    <img
                      src={verticalMenuIcon}
                      className={`w-6 h-6 object-contain ${
                        isDark ? "brightness-0 invert" : "red"
                      }`}
                    />
                  </Button>
                )}
                <Popover
                  open={isTopoViewToolsOpen}
                  anchorEl={openTopoViewsAnchor}
                  onClose={closeTopoViewsTools}
                  container={containerRef.current}
                  anchorOrigin={{
                    vertical: "center",
                    horizontal: "left",
                  }}
                  transformOrigin={{
                    vertical: "center",
                    horizontal: "right",
                  }}
                  sx={{ mt: "8%", mr: 5, boxShadow: "none" }}
                >
                  <NodeViewSwitcher
                    currentTabKey={currentTabKey}
                    setCurrentTabKey={setCurrentTabKey}
                  />
                </Popover>
                <Button
                  title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                  onClick={toggleFullscreen}
                  sx={{
                    border: "2px solid #D9D9D9",
                    borderRadius: "10px",
                    minWidth: 0,
                    width: "40px",
                    height: "40px",
                    marginLeft: "13px",
                    // 1. Prevent the button from forcing blue on children
                    color: "#14348d",
                  }}
                >
                  {isFullscreen ? (
                    <FullscreenExit
                      size={30}
                      sx={{
                        // 3. Apply your specific color here
                        // We use color + filter logic to ensure it works in both themes
                        color: "#14348d",
                        filter: theme.palette.custom.icon.iconFilter,
                      }}
                    />
                  ) : (
                    <Fullscreen
                      size={30}
                      sx={{
                        color: "#14348d",
                        filter: theme.palette.custom.icon.iconFilter,
                      }}
                    />
                  )}
                </Button>
              </Box>

              {linkPopup.open && (
                <Box
                  style={{
                    position: "absolute",
                    left: linkPopup.x,
                    top: linkPopup.y,
                    transform: "translate(-50%, -100%)",
                    background: "white",
                    border: "1px solid #ddd",
                    borderRadius: 8,
                    padding: 10,
                    zIndex: 9999,
                    minWidth: 180,
                  }}
                >
                  <Box style={{ fontWeight: 600, marginBottom: 6 }}>
                    Select Link
                  </Box>

                  <Box
                    style={{ padding: 6, cursor: "pointer" }}
                    onClick={() =>
                      handleLinkSelection({ target: { value: "NONE" } })
                    }
                  >
                    NONE
                  </Box>

                  {linkConfigurations.map((item) => (
                    <Box
                      key={item.linkId}
                      style={{ padding: 6, cursor: "pointer" }}
                      onClick={() =>
                        handleLinkSelection({
                          target: { value: item.linkName },
                        })
                      }
                    >
                      {item.linkName}
                    </Box>
                  ))}
                </Box>
              )}
            </ReactFlow>

            {/* Your dialogs can stay here */}
            <MDialog
              open={isDeleteAllConfirm}
              onClose={() => setIsDeleteAllConfirm(false)}
              title="Confirmation"
              message={`Are you sure want to delete all nodes and edges of ${
                currentViewTopology ? "Topology" : "Rack"
              }`}
              confirmText="Yes"
              container={containerRef.current}
              onConfirm={handleDeleteAllNodes}
              icon={deleteIcon}
              variant="error"
            />

            <MDialog
              open={isSaveConfirmOpen}
              onClose={() => setIsSaveConfirmOpen(false)}
              title="Confirmation"
              message={`Are you sure want to Save ${
                currentViewTopology ? "Topology" : "Rack"
              }`}
              confirmText="Save"
              onConfirm={whatToSaveTopoOrRack}
              icon={Confirmation_icon}
              variant="success"
            />
          </Box>

          {/* ============================= */}
          {/* PORT MAPPING */}
          {/* ============================= */}

          {portMappingOpen && (
            <Box
              sx={{
                flex: "2 1 0%",
                minWidth: 0,
                minHeight: 0,
                height: "100%",
                overflow: "hidden",

                borderLeft: "1px solid",
                borderColor: "divider",

                backgroundColor: "background.paper",

                // Smooth opening/closing
                animation: "portMappingOpen 0.3s ease",

                "@keyframes portMappingOpen": {
                  from: {
                    opacity: 0,
                    transform: "translateX(20px)",
                  },
                  to: {
                    opacity: 1,
                    transform: "translateX(0)",
                  },
                },
              }}
            >
              <PortMapping />
            </Box>
          )}
        </Box>

        {SUPERADMIN && (
          <MModal
            open={blankNodeModalOpen}
            handleClose={handleCloseBlankNodeModal}
            title={editingNodeId ? "Update Blank Node" : "Create Blank Node"}
          >
            <Box
              p={2}
              display="flex"
              flexDirection="column"
              gap={2.5}
              minWidth={400}
            >
              {/* Text Label Input Field */}
              <TextField
                label="Node Label Text"
                fullWidth
                variant="outlined"
                size="small"
                value={blankNodeForm.text}
                onChange={(e) =>
                  setBlankNodeForm({ ...blankNodeForm, text: e.target.value })
                }
                autoFocus
              />

              {/* Flex Layout Palette Alignment Container */}
              <Box display="flex" flexDirection="column" gap={2}>
                {/* Background Color Field */}
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <Typography
                    variant="body2"
                    sx={{ fontWeight: 500, color: "text.secondary" }}
                  >
                    Background Color
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      width: "60%",
                      border: "1px solid #ccc",
                      borderRadius: "6px",
                      padding: "4px 8px",
                      height: "40px",
                      backgroundColor: "background.paper",
                    }}
                  >
                    <input
                      type="color"
                      value={blankNodeForm.color}
                      onChange={(e) =>
                        setBlankNodeForm({
                          ...blankNodeForm,
                          color: e.target.value,
                        })
                      }
                      style={{
                        border: "none",
                        width: "30px",
                        height: "24px",
                        cursor: "pointer",
                        backgroundColor: "transparent",
                      }}
                    />
                    <Typography
                      variant="body2"
                      sx={{
                        ml: 1.5,
                        fontFamily: "monospace",
                        textTransform: "uppercase",
                      }}
                    >
                      {blankNodeForm.color}
                    </Typography>
                  </Box>
                </Box>

                {/* Border Color Field */}
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <Typography
                    variant="body2"
                    sx={{ fontWeight: 500, color: "text.secondary" }}
                  >
                    Border Color
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      width: "60%",
                      border: "1px solid #ccc",
                      borderRadius: "6px",
                      padding: "4px 8px",
                      height: "40px",
                      backgroundColor: "background.paper",
                    }}
                  >
                    <input
                      type="color"
                      value={blankNodeForm.borderColor}
                      onChange={(e) =>
                        setBlankNodeForm({
                          ...blankNodeForm,
                          borderColor: e.target.value,
                        })
                      }
                      style={{
                        border: "none",
                        width: "30px",
                        height: "24px",
                        cursor: "pointer",
                        backgroundColor: "transparent",
                      }}
                    />
                    <Typography
                      variant="body2"
                      sx={{
                        ml: 1.5,
                        fontFamily: "monospace",
                        textTransform: "uppercase",
                      }}
                    >
                      {blankNodeForm.borderColor}
                    </Typography>
                  </Box>
                </Box>
              </Box>

              {/* Save & Cancel Action Container */}
              <Box display="flex" justifyContent="space-between" gap={2} mt={1}>
                <Button
                  variant="outlined"
                  sx={{
                    width: "45%",
                    borderRadius: "10px",
                    fontSize: "0.875rem",
                    fontWeight: 500,
                  }}
                  onClick={handleCloseBlankNodeModal}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleSaveBlankNodeForm}
                  sx={{
                    backgroundColor: "#0f2870",
                    width: "45%",
                    borderRadius: "10px",
                    fontSize: "0.875rem",
                    fontWeight: 500,
                    "&:hover": { backgroundColor: "#0b1e54" },
                  }}
                >
                  {editingNodeId ? "Save Changes" : "Add Node"}
                </Button>
              </Box>
            </Box>
          </MModal>
        )}
      </Box>
      {/* {loading && <Loader />} */}
    </Box>
  );
};

export default memo(Topology);
