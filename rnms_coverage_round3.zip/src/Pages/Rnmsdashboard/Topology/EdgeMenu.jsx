/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : EdgeMenu.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\EdgeMenu.jsx
   Purpose                  : Created the EdgeMenu for connecting the devices/nodes with the custom edge color and dotted line 
   Created Date             : 22-03-2026
 ***********************************************************************************************/

import {
  updateLinkType,
  pushToUndoStack,
  updateEdgeColorByContextMenu,
} from "@/store/features/Topology/topologyNodesslice";
import { RightCircleFilled } from "@ant-design/icons";
import { Box, Button } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";

import { ColorPicker, Space } from "antd";

const EdgeMenu = ({ setEdgeMenu, edgeMenu,edges }) => {

  const [color, setColor] = useState("#ff0000");

  const dispatch = useDispatch();

  const handleChangeLinkType = (type) => {
    dispatch(pushToUndoStack());

    dispatch(updateLinkType({ edgeId: edgeMenu.edgeId, type }));
    setEdgeMenu({ ...edgeMenu, visible: false });
  };

  const handleChangeLineColorByMenu = () => {
    console.log(color, "colorcolor");
    dispatch(pushToUndoStack());
    dispatch(
      updateEdgeColorByContextMenu({ edgeId: edgeMenu.edgeId, color: color })
    );
  };

  useEffect(() => {
    if (!edges || !edgeMenu?.edgeId) return;
  
    const currentEdge = edges.find(
      (edge) => edge.id === edgeMenu.edgeId
    );
  
    if (currentEdge?.style?.stroke) {
      setColor(currentEdge.style.stroke);
    }
  }, [edges, edgeMenu.edgeId]);

  return (
    <button 
      className="edge-menu-container nopan" 
      onClick={(e) => e.stopPropagation()} 
      onMouseDown={(e) => e.stopPropagation()}
    >
      <strong>Set Link Type</strong>
      <div
        style={{
            // marginTop: 6,
          display: "flex",
          gap: "10px",
          flexDirection: "column",
        }}
      >
        
        <button onClick={() => handleChangeLinkType("10GE")}>
          <div className="edge-menu-link-container">
            <div
              style={{
                width: "50px",
                height: "1.5px",
                backgroundColor: "grey",
              }}
            ></div>
            <div>10GE</div>
          </div>
        </button>

        <button onClick={() => handleChangeLinkType("1GE")}>
          <div className="edge-menu-link-container">
            <div
              style={{
                width: "50px",
                height: "2px",
                borderBottom: "3px dotted grey",
              }}
            ></div>
            <div>1GE</div>
          </div>
        </button>

        <button onClick={() => handleChangeLinkType("mgmt")}>
          <div className="edge-menu-link-container">
            <div
              style={{
                width: "50px",
                height: "2px",
                borderBottom: "2px dashed grey",
              }}
            ></div>
            <div>Mgmt</div>
          </div>
        </button>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Space>
            <ColorPicker
              value={color}
              onChange={(c) => setColor(c.toHexString())}
              placement="bottomLeft"
              getPopupContainer={() => document.body}
            />
          </Space>
          <Button onClick={handleChangeLineColorByMenu}>
            <RightCircleFilled />
          </Button>
        </Box>
      </div>
    </button>

    // <Menu
    //                 open={Boolean(contextMenu)}
    //                 onClose={handleCloseMenu}
    //                 anchorReference="anchorPosition"
    //                 anchorPosition={
    //                     contextMenu
    //                         ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
    //                         : undefined
    //                 }
    //             >
    //                 {MENU_CONFIG[contextMenu?.node?.type]?.map((item) => (
    //                     <MenuItem key={item} onClick={() => handleMenuClick(item)}>
    //                         {item}
    //                     </MenuItem>
    //                 ))}
    //             </Menu>
  );
};

export default EdgeMenu;
