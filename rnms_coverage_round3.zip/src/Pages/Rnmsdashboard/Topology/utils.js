// /***********************************************************************************************
//    Project                  : IAF-NMS
//    SubSystem                : Topology 
//    File Name                : utils.js
//    Author                   : ARUN - VIPL
//    Package                  : src\Pages\Rnmsdashboard\Topology\utils.js
//    Purpose                  : Created the utils for assigning the values to mapNodeData,mapResourceType and mapsegmantation
//    Created Date             : 30-03-2026
//  ***********************************************************************************************/

// export const mapNodeData = (item, resourceStateName, maxSeverity) => ({
//   resourceStateName,
//   maxSeverity,
//   maintainance: item?.maintainance,
//   discovered: item?.discovered,
//   remarks: item?.remarks,
//   label: item?.resourceName,
//   resourceIp: item?.resourceIp,
//   imResourceType: mapResourceType(item?.imResourceType),
//   imSegmentInfo: mapSegmentInfo(item?.imSegmentInfo),
//   resourceSerialNo: item?.resourceSerialNo,
//   resourceDesc: item?.resourceDesc,
//   firmwareVersion: item?.firmwareVersion,
//   tmSnmpProfile: mapSnmpProfile(item?.tmSnmpProfile),
//   macAddress: item?.macAddress,
//   discoveredTime: item?.discoveredTime,
//   nePollingInfo: mapPollingInfo(item?.nePollingInfo),
//   status: item?.status,
//   discoveryMode: item?.discoveryMode,
//   portNumber: item?.portNumber,
//   devicePosition: item?.devicePosition,
//   discoveredstatusMessage: item?.discoveredstatusMessage,
//   timestamp: item?.timestamp,
//   lstPortInfoDtl: item?.lstPortInfoDtl,
//   latitude: item?.latitude,
//   longitude: item?.longitude,
//   ids: item.id,
// });

// const mapResourceType = (type) => ({
//   resourceTypeId: type?.resourceTypeId,
//   resourceTypeName: type?.resourceTypeName,
//   configurable: type?.configurable,
//   imResourceStateInfo: {
//     resourceStateId: type?.imResourceStateInfo?.resourceStateId,
//   },
//   make: type?.make,
//   model: type?.model,
//   sysOidValue: type?.sysOidValue,
//   enterpriseOid: type?.enterpriseOid,
//   imCommunicationType: {
//     id: type?.imCommunicationType?.id,
//     protoTypeName: type?.imCommunicationType?.protoTypeName,
//   },
//   nodeType: {
//     id: type?.nodeType?.id,
//     name: type?.nodeType?.name,
//     description: type?.nodeType?.description,
//     topologyData: type?.nodeType?.topologyData,
//   },
//   resourceNickName: type?.resourceNickName,
//   data: { ...type?.data },
//   //   configured: type?.data?.configured,
//   //   status: type?.data?.status,
//   //   telnet: type?.data?.telnet,
//   //   ssh: type?.data?.ssh,
//   //   web: type?.data?.web,
//   //   webUrl: type?.data?.webUrl,
//   //   syslog: type?.data?.syslog,
//   //   backUp: type?.data?.backUp,
//   //   upload: type?.data?.upload,
//   // },
//   serialNumOid: type?.serialNumOid,
//   firmwareNumOid: type?.firmwareNumOid,
//   resourceSubType: type?.resourceSubType,
// });

// const mapSegmentInfo = (segment) => ({
//   segmentId: segment?.segmentId,
//   segmentName: segment?.segmentName,
//   segmentDesc: segment?.segmentDesc,
// });

// const mapSnmpProfile = (profile) => ({
//   snmpProfileId: profile?.snmpProfileId,
//   version: profile?.version,
//   port: profile?.port,
//   timeout: profile?.timeout,
//   retries: profile?.retries,
//   username: profile?.username,
//   authPassword: profile?.authPassword,
//   authProtocol: profile?.authProtocol,
//   contextName: profile?.contextName,
//   privPassword: profile?.privPassword,
//   privProtocol: profile?.privProtocol,
//   readCommunity: profile?.readCommunity,
//   securityLevel: profile?.securityLevel,
//   snmpProfileName: profile?.snmpProfileName,
//   writeCommunity: profile?.writeCommunity,
//   ipAddress: profile?.ipAddress,
// });

// const mapPollingInfo = (polling) => ({
//   id: polling?.id,
//   pollingInterval: polling?.pollingInterval,
//   isDefaultPolling: polling?.isDefaultPolling,
//   imResourceInfo: polling?.imResourceInfo,
// });


// export const SWITCH_TEMPLATE_CONFIGS = {
//   switch24: {
//     templateKey: "switch24",
//     resourceName: "24 Port Switch",
//     portCount: 24,
//     portsPerRow: 12,
//     width: 720,
//     height: 232,
//     portImageWidth: 30,
//     shellImageKey: "switch24",
//     portArea: {
//       left: "6.2%",
//       top: "45%",
//       width: "70.5%",
//       height: "30%",
//     },
//   },
//   switch6: {
//     templateKey: "switch6",
//     resourceName: "6 Port Switch",
//     portCount: 6,
//     portsPerRow: 3,
//     width: 720,
//     height: 232,
//     portImageWidth: 28,
//     shellImageKey: "switch6",
//     portArea: {
//       left: "8.5%",
//       top: "48%",
//       width: "70.5%",
//       height: "30%",
//     },
//   },
// }; 


// export function createTopologyNodeId(prefix = "node") {
//   return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
// }

// export function getSwitchTemplateConfig(templateKey) {
//   return SWITCH_TEMPLATE_CONFIGS[templateKey] ?? null;
// }

// export function getPortStatusKey(rawStatus, index = 0) {
//   const normalized = `${rawStatus ?? ""}`.trim().toLowerCase();

//   if (normalized === "up") {
//     return "up";
//   }

//   if (normalized === "down") {
//     return "down";
//   }

//   if (
//     normalized === "admindown" ||
//     normalized === "admin_down" ||
//     normalized === "admin down"
//   ) {
//     return "adminDown";
//   }

//   if (
//     normalized === "notconfigured" ||
//     normalized === "not_configured" ||
//     normalized === "not configured"
//   ) {
//     return "notConfigured";
//   }

//   return "notConfigured";
// }

// export function buildSwitchPorts(portCount, initialStatuses = []) {
//   return Array.from({ length: portCount }, (_, index) => ({
//     id: `port-${index + 1}`,
//     name: `GigabitEthernet0/${index + 1}`,
//     portNumber: index + 1,
//     status: getPortStatusKey(initialStatuses[index], index),
//   }));
// }

// export function isSwitchPortNode(data) {
//   return Boolean(data?.switchTemplateKey);
// }

// export function normalizeSwitchPorts(data) {
//   const template = getSwitchTemplateConfig(data?.switchTemplateKey);

//   if (!template) {
//     return [];
//   }

//   const candidatePorts = Array.isArray(data?.ports) ? data.ports : [];

//   if (!candidatePorts.length) {
//     return buildSwitchPorts(template.portCount);
//   }

//   return candidatePorts
//     .slice(0, template.portCount)
//     .map((port, index) => ({
//       id: port?.id ?? `port-${index + 1}`,
//       name: port?.name ?? `GigabitEthernet0/${index + 1}`,
//       portNumber: port?.portNumber ?? index + 1,
//       status: getPortStatusKey(
//         port?.status ??
//           port?.portStatus ??
//           port?.resourceStateName ??
//           port?.state,
//         index,
//       ),
//     }));
// }

// export function createSwitchPaletteNode(templateKey) {
//   const template = getSwitchTemplateConfig(templateKey);

//   if (!template) {
//     return null;
//   }

//   return {
//     resourceId: createTopologyNodeId(templateKey),
//     resourceName: template.resourceName,
//     type: "switchPortNode",
//     switchTemplateKey: template.templateKey,
//     style: {
//       width: template.width,
//       height: template.height,
//     },
//     ports: buildSwitchPorts(template.portCount),
//   };
// }

// export const SWITCH_PALETTE_ITEMS = Object.values(SWITCH_TEMPLATE_CONFIGS).map(
//   (template) => ({
//     details: {
//       resourceId: template.templateKey,
//       resourceName: template.resourceName,
//     },
//     available: [createSwitchPaletteNode(template.templateKey)],
//     total: 1,
//   }),
// );



/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : utils.js
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\utils.js
   Purpose                  : Created the utils for assigning the values to mapNodeData,mapResourceType and mapsegmantation
   Created Date             : 30-03-2026
 ***********************************************************************************************/

   export const mapNodeData = (item, resourceStateName, maxSeverity) => ({
    resourceStateName,
    maxSeverity,
    maintainance: item?.maintainance,
    discovered: item?.discovered,
    remarks: item?.remarks,
    label: item?.resourceName,
    resourceIp: item?.resourceIp,
    imResourceType: mapResourceType(item?.imResourceType),
    imSegmentInfo: mapSegmentInfo(item?.imSegmentInfo),
    resourceSerialNo: item?.resourceSerialNo,
    resourceDesc: item?.resourceDesc,
    firmwareVersion: item?.firmwareVersion,
    tmSnmpProfile: mapSnmpProfile(item?.tmSnmpProfile),
    macAddress: item?.macAddress,
    discoveredTime: item?.discoveredTime,
    nePollingInfo: mapPollingInfo(item?.nePollingInfo),
    status: item?.status,
    discoveryMode: item?.discoveryMode,
    portNumber: item?.portNumber,
    devicePosition: item?.devicePosition,
    discoveredstatusMessage: item?.discoveredstatusMessage,
    timestamp: item?.timestamp,
    lstPortInfoDtl: item?.lstPortInfoDtl,
    latitude: item?.latitude,
    longitude: item?.longitude,
    ids: item.id,
  });
  
  const mapResourceType = (type) => ({
    resourceTypeId: type?.resourceTypeId,
    resourceTypeName: type?.resourceTypeName,
    configurable: type?.configurable,
    imResourceStateInfo: {
      resourceStateId: type?.imResourceStateInfo?.resourceStateId,
    },
    make: type?.make,
    model: type?.model,
    sysOidValue: type?.sysOidValue,
    enterpriseOid: type?.enterpriseOid,
    imCommunicationType: {
      id: type?.imCommunicationType?.id,
      protoTypeName: type?.imCommunicationType?.protoTypeName,
    },
    nodeType: {
      id: type?.nodeType?.id,
      name: type?.nodeType?.name,
      description: type?.nodeType?.description,
      topologyData: type?.nodeType?.topologyData,
    },
    resourceNickName: type?.resourceNickName,
    data: { ...type?.data },
    //   configured: type?.data?.configured,
    //   status: type?.data?.status,
    //   telnet: type?.data?.telnet,
    //   ssh: type?.data?.ssh,
    //   web: type?.data?.web,
    //   webUrl: type?.data?.webUrl,
    //   syslog: type?.data?.syslog,
    //   backUp: type?.data?.backUp,
    //   upload: type?.data?.upload,
    // },
    serialNumOid: type?.serialNumOid,
    firmwareNumOid: type?.firmwareNumOid,
    resourceSubType: type?.resourceSubType,
  });
  
  const mapSegmentInfo = (segment) => ({
    segmentId: segment?.segmentId,
    segmentName: segment?.segmentName,
    segmentDesc: segment?.segmentDesc,
  });
  
  const mapSnmpProfile = (profile) => ({
    snmpProfileId: profile?.snmpProfileId,
    version: profile?.version,
    port: profile?.port,
    timeout: profile?.timeout,
    retries: profile?.retries,
    username: profile?.username,
    authPassword: profile?.authPassword,
    authProtocol: profile?.authProtocol,
    contextName: profile?.contextName,
    privPassword: profile?.privPassword,
    privProtocol: profile?.privProtocol,
    readCommunity: profile?.readCommunity,
    securityLevel: profile?.securityLevel,
    snmpProfileName: profile?.snmpProfileName,
    writeCommunity: profile?.writeCommunity,
    ipAddress: profile?.ipAddress,
  });
  
  const mapPollingInfo = (polling) => ({
    id: polling?.id,
    pollingInterval: polling?.pollingInterval,
    isDefaultPolling: polling?.isDefaultPolling,
    imResourceInfo: polling?.imResourceInfo,
  });
  
  
  export const SWITCH_TEMPLATE_CONFIGS = {
    "MCT_EP_SWITCH-24PORT": {
      templateKey: "switch24",
      resourceName: "24 Port Switch",
      portCount: 24,
      portsPerRow: 12,
      width: 920,
      height: 232,
      portImageWidth: 30,
      shellImageKey: "switch24",
      portArea: {
        left: "6.2%",
        top: "45%",
        width: "70.5%",
        height: "30%",
      },
    },
    "MCT_EP_SWITCH-6PORT": {
      templateKey: "switch6",
      resourceName: "6 Port Switch",
      portCount: 6,
      portsPerRow: 3,
      width: 720,
      height: 232,
      portImageWidth: 28,
      shellImageKey: "switch6",
      portArea: {
        left: "8.5%",
        top: "48%",
        width: "70.5%",
        height: "30%",
      },
    },
  }; 
  
  
  // export function createTopologyNodeId(prefix = "node") {
  //   return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
  // }
  export function createTopologyNodeId(prefix = "node") {
    // Generates a cryptographically strong random string
    const array = new Uint8Array(6); // 6 bytes = 48 bits of entropy
    crypto.getRandomValues(array);
    const randomPart = Array.from(array, (byte) => byte.toString(36).padStart(2, '0')).join('');
    
    return `${prefix}-${randomPart}`;
  }
  export function getSwitchTemplateConfig(templateKey) {
    if (!templateKey) return null;
    const directMatch = SWITCH_TEMPLATE_CONFIGS[templateKey];
    if (directMatch) return directMatch;
    // Topology nodes store the compact template key (switch6/switch24),
    // while the palette is keyed by the backend model identifier.
    return Object.values(SWITCH_TEMPLATE_CONFIGS).find(
      (template) => template.templateKey === templateKey
    ) ?? null;
  }
  
  export function getPortStatusKey(rawStatus, index = 0) {
    const normalized = `${rawStatus ?? ""}`.trim().toLowerCase();
  
    if (normalized === "up") {
      return "up";
    }
  
    if (normalized === "down") {
      return "down";
    }
  
    if (
      normalized === "admindown" ||
      normalized === "admin_down" ||
      normalized === "admin down"
    ) {
      return "adminDown";
    }
  
    if (
      normalized === "notconfigured" ||
      normalized === "not_configured" ||
      normalized === "not configured"
    ) {
      return "notConfigured";
    }

    const statusMap = {
      1: 'up',             // Admin Up
      2: 'down',           // Admin Down
      3: 'testing',        // Testing
      // Add other cases as per your backend definition
    };

    // return "notConfigured";
    return statusMap[rawStatus] || 'notConfigured'; 
  }
  
  export const SEVERITY_COLOR ={
    major:"#e48087",
    minor:"#FAFC0B",
    warning:"#00FFFF",
    up:"#008000",
    offline:"#ff0000"
  }

export const getBadgeStyles = (severity) => {
      switch (severity?.toLowerCase()) {
        case "minor":
          return { backgroundColor: SEVERITY_COLOR.minor, color: "#000" };
        case "major":
          return { backgroundColor: SEVERITY_COLOR.major, color: "#fff" };
        case "warning":
          return { backgroundColor: SEVERITY_COLOR.warning, color: "#000" };
        default:
          return { backgroundColor: "#D9D9D9", color: "#666" };
      }
    };


  export function buildSwitchPorts(portCount, initialStatuses = []) {
    return Array.from({ length: portCount }, (_, index) => ({
      id: `port-${index + 1}`,
      name: `GigabitEthernet0/${index + 1}`,
      portNumber: index + 1,
      status: getPortStatusKey(initialStatuses[index], index),
    }));
  }
  
  export function isSwitchPortNode(data) {
    return Boolean(data?.switchTemplateKey);
  }
  
  export function normalizeSwitchPorts(data) {
    const template = getSwitchTemplateConfig(data?.switchTemplateKey);
  
    if (!template) {
      return [];
    }
  
    const candidatePorts = Array.isArray(data?.ports) ? data.ports : [];
  
    if (!candidatePorts.length) {
      return buildSwitchPorts(template.portCount);
    }
  
    return candidatePorts
      .slice(0, template.portCount)
      .map((port, index) => ({
        id: port?.id ?? `port-${index + 1}`,
        name: port?.name ?? `GigabitEthernet0/${index + 1}`,
        portNumber: port?.portNumber ?? index + 1,
        status: getPortStatusKey(
          port?.status ??
            port?.portStatus ??
            port?.resourceStateName ??
            port?.state,
          index,
        ),
      }));
  }
  
  export function createSwitchPaletteNode(templateKey) {
    const template = getSwitchTemplateConfig(templateKey);
  
    if (!template) {
      return null;
    }
  
    return {
      resourceId: createTopologyNodeId(templateKey),
      resourceName: template.resourceName,
      type: "switchPortNode",
      switchTemplateKey: template.templateKey,
      style: {
        width: template.width,
        height: template.height,
      },
      ports: buildSwitchPorts(template.portCount),
    };
  }
  
  export const SWITCH_PALETTE_ITEMS = Object.values(SWITCH_TEMPLATE_CONFIGS).map(
    (template) => ({
      details: {
        resourceId: template.templateKey,
        resourceName: template.resourceName,
      },
      available: [createSwitchPaletteNode(template.templateKey)],
      total: 1,
    }),
  );
  
  
  // Add this to determine template key based on resource name or type
  export function getTemplateKeyByResource(node) {
    const name = node.imResourceType?.resourceTypeName || "";
    if (name.includes("24 Port")) return "switch24";
    if (name.includes("6 Port")) return "switch6";
    // Default fallback or add more cases (e.g., 8 port, 48 port)
    return "switch24"; 
  }
  
  export function createDynamicSwitchNode(node) {
    const templateKey = getTemplateKeyByResource(node);
    const template = getSwitchTemplateConfig(templateKey);
    
    // Use ports from API (lstPortInfoDtl) or generate a default set based on template count
    const apiPorts = node.lstPortInfoDtl || [];
    const finalPortCount = apiPorts.length > 0 ? apiPorts.length : (template?.portCount || 0);
  
    const ports = Array.from({ length: finalPortCount }, (_, idx) => {
      const apiPort = apiPorts[idx];
      return {
        id: apiPort?.id || `${node.resourceId}-port-${idx + 1}`,
        name: apiPort?.portName || `Port ${idx + 1}`,
        portNumber: apiPort?.portNumber || idx + 1,
        // Map 'adminStatus' or 'portStatus' to your internal keys
        status: getPortStatusKey(apiPort?.adminStatus || apiPort?.portStatus || "not configured"),
      };
    });
  
    return {
      ...node,
      type: "switchPortNode",
      switchTemplateKey: templateKey,
      ports: ports, // This ensures ports is NEVER empty if the template has a count
      style: {
        width: template?.width || 720,
        height: template?.height || 232,
      },
    };
  }

  export function transformResourceToNode(resource) {
    const isSwitch = resource.imResourceType?.resourceTypeName?.toLowerCase().includes("switch");
    
    if (isSwitch) {
      const templateKey = getTemplateKeyByResource(resource);
      const template = getSwitchTemplateConfig(templateKey);
      // const templatePortCount = template?.portCount || 24;
      
      // const apiPorts = resource.lstPortInfoDtl || [];
      
      // Create the full array based on Template Count
      // const ports = Array.from({ length: templatePortCount }, (_, index) => {
      //   const portNumber = index + 1;
      //   // MATCHING LOGIC: API uses ifindex, but sometimes it starts at 1
      //   const apiPort = apiPorts.find(p => p.ifindex === portNumber);
         
  
      //   return {
      //     id: apiPort ? `${resource.resourceId}-p-${apiPort.ifindex}` : `${resource.resourceId}-p-auto-${portNumber}`,
      //     name: apiPort?.ifportname || `Port ${portNumber}`,
      //     // Use adminstatus from API
      //     status: apiPort ? getPortStatusKey(apiPort.adminstatus) : 'notConfigured',
      //     ifdesc: apiPort?.ifdesc || 'N/A',
      //     ifindex:apiPort?.ifindex || 'N/A'
      //   };
      // });
  
      return {
        ...resource,
        type: 'switchPortNode', 
        switchTemplateKey: templateKey, // CRITICAL: ImageNode needs this
        // ports: ports,
        style: {
          width: template?.width || 720,
          height: template?.height || 232,
        }
      };
    }
  
    return resource;
  }


  // export const transformResourceToNode = (resource) => {
  //   return {
  //     id: resource.resourceId || resource.id,
  //     type: "switchPortNode", // Required by ImageNode
  //     position: resource.position || { x: 0, y: 0 },
  //     data: {
  //       ...resource,
  //       switchTemplateKey: resource.switchTemplateKey || resource.resourceTypeName || "defaultSwitchTemplate",
  //       lstPortInfoDtl: resource.lstPortInfoDtl || [],
  //     },
  //     width: resource.width || 100,
  //     height: resource.height || 100,
  //   };
  // };


  export const normalizeTopologyNode = (node) => {
     
    return {
      ...node,
      type: node.type || "commonNode",
      data: {
        ...node.data,
  
        // CRITICAL FIELDS (your bug fix)
        type: node.data?.type || node.type,
        switchTemplateKey: node.data?.switchTemplateKey || null,
        lstPortInfoDtl: Array.isArray(node.data?.lstPortInfoDtl)
          ? node.data.lstPortInfoDtl
          : [],
      },
    };
  };

  export const getEdgeColor = (status) => {
    if (status === 0) return "red";
    if (status === 1) return "green";
    if (status === 2) return "#ff9800";
    // if (status === 2) return "yellow";
    return "gray";
  };
      


  // export const normalizeTopologyNode = (node) => {
  //   if (!node.data) node.data = {};
  
  //   // Make sure node is compatible with ImageNode
  //   if (node.type === "commonNode" && node.data.lstPortInfoDtl) {
  //     node.type = "switchPortNode"; // required by ImageNode
  //     node.data.switchTemplateKey =
  //       node.data.switchTemplateKey || node.data.resourceTypeName || "defaultSwitchTemplate";
  //   }
  
  //   // Ensure ports list exists
  //   if (!node.data.lstPortInfoDtl) {
  //     node.data.lstPortInfoDtl = [];
  //   }
  
  //   return node;
  // };







  export const getSuperAdminDeviceStatus = (node) => {
    const resourceStateId =
      node?.imResourceType?.imResourceStateInfo?.resourceStateId;
  
    return resourceStateId === 2 ? "unmanaged" : "managed";
  };







  export const getDeviceStatus = (node) => {
    // 1. Unmanaged logic remains the baseline filter
    const resourceStateId = node?.imResourceType?.imResourceStateInfo?.resourceStateId;
    if (resourceStateId === 2) {
      return "unmanaged";
    }
  
    // Extract core boolean flags safely
    const isDiscovered = node?.isDiscovered === true;
    const isMaintainance = node?.isMaintainance === true;
    // Important: Check if isReachable is explicitly defined (not undefined)
    const isReachable = node?.nePollingInfo?.isReachable === true;
    const hasReachabilityData = node?.nePollingInfo?.isReachable !== undefined;
  
    // 2. Logic for "online"
    // Case A: If we have reachability data, both must be true
    // Case B: If we DON'T have reachability data yet (first time), only isDiscovered needs to be true
    if (isDiscovered) {
      if (hasReachabilityData) {
        return isReachable ? "online" : "offline";
      } else {
        // This covers the "first time" check where websocket data hasn't arrived yet
        return "online";
      }
    }
  
    // 3. Condition: isDiscovered: false and isMaintainance: true -> "maintenance"
    if (!isDiscovered && isMaintainance) {
      return "maintenance";
    }
  
    // 4. Condition: isDiscovered: false and isMaintainance: false -> "undiscovered"
    if (!isDiscovered && !isMaintainance) {
      return "undiscovered";
    }
  
    // Fallback
    return "offline";
  };



  export const getDeviceStatusCnms = (node) => {
    // 1. Unmanaged logic remains the baseline filter
    const resourceStateId = node?.imResourceType?.imResourceStateInfo?.resourceStateId;
    if (resourceStateId === 2) {
      return "unmanaged";
    }
  
    // Extract core boolean flags safely
    const isDiscovered = node?.isDiscovered === true;
    const isMaintainance = node?.isMaintainance === true;
    // Important: Check if isReachable is explicitly defined (not undefined)
    const isReachable = node?.isReachable === true;
    const hasReachabilityData = node?.isReachable !== undefined;
  
    // 2. Logic for "online"
    // Case A: If we have reachability data, both must be true
    // Case B: If we DON'T have reachability data yet (first time), only isDiscovered needs to be true
    if (isDiscovered) {
      if (hasReachabilityData) {
        return isReachable ? "online" : "offline";
      } else {
        // This covers the "first time" check where websocket data hasn't arrived yet
        return "online";
      }
    }
  
    // 3. Condition: isDiscovered: false and isMaintainance: true -> "maintenance"
    if (!isDiscovered && isMaintainance) {
      return "maintenance";
    }
  
    // 4. Condition: isDiscovered: false and isMaintainance: false -> "undiscovered"
    if (!isDiscovered && !isMaintainance) {
      return "undiscovered";
    }
  
    // Fallback
    return "offline";
  };





//------------------------------------
import config from "../../../../public/config.json";

const PORT_MATCHING_REGEX = new RegExp(
  config.portDescriptionMatchingString,
  "i"
);

const ALWAYS_ALLOWED_PORT_REGEXES = (
  config.alwaysAllowedPortDescriptionMatchingStrings || []
).map((pattern) => new RegExp(pattern, "i"));

const RESOURCE_PORT_REGEXES = Object.fromEntries(
  Object.entries(config.resourcePortDescriptionConstraints || {}).map(
    ([resourceId, patterns]) => [
      resourceId,
      patterns.map((pattern) => new RegExp(pattern, "i")),
    ]
  )
);

/**
 * Check whether a port should be displayed based on ifdesc.
 */
const isValidPortDescription = (ifdesc) => {
  if (typeof ifdesc !== "string") {
    return false;
  }

  // TenGigabitEthernet is always allowed.
  if (
    ALWAYS_ALLOWED_PORT_REGEXES.some((regex) => regex.test(ifdesc))
  ) {
    return true;
  }

  return PORT_MATCHING_REGEX.test(ifdesc);
};

/**
 * Get the visual index position of a switch port.
 *
 * GigabitEthernet:
 *   1 - 24
 *
 * TenGigabitEthernet:
 *   25 - 28
 */
const getIndexPosition = (port) => {
  const ifdesc = port?.ifdesc;

  if (typeof ifdesc !== "string") {
    return null;
  }

  if (/^TenGigabitEthernet/i.test(ifdesc)) {
    const match = ifdesc.match(/\/(\d+)$/);

    if (!match) {
      return null;
    }

    const tenGigNumber = Number(match[1]);

    if (tenGigNumber >= 1 && tenGigNumber <= 4) {
      return 24 + tenGigNumber;
    }

    return null;
  }

  if (/^GigabitEthernet/i.test(ifdesc)) {
    const match = ifdesc.match(/\/(\d+)$/);

    if (!match) {
      return null;
    }

    const gigNumber = Number(match[1]);

    if (gigNumber >= 1 && gigNumber <= 24) {
      return gigNumber;
    }
  }

  return null;
};

/**
 * Filters and prepares switch ports.
 */
export const filterSwitchPortsImageNode = (ports) => {
  if (!Array.isArray(ports)) {
    return [];
  }

  return ports
    .filter((port) => {
      const { ifdesc, resourceId } = port || {};

      if (!isValidPortDescription(ifdesc)) {
        return false;
      }

      // TenGigabitEthernet bypasses resource-specific GigabitEthernet rules.
      if (
        ALWAYS_ALLOWED_PORT_REGEXES.some((regex) =>
          regex.test(ifdesc)
        )
      ) {
        return true;
      }

      const resourceRegexes = RESOURCE_PORT_REGEXES[resourceId];

      if (!resourceRegexes) {
        return true;
      }

      return resourceRegexes.some((regex) => regex.test(ifdesc));
    })
    .map((port) => ({
      ...port,
      indexPosition: getIndexPosition(port),
    }))
    .filter((port) => port.indexPosition !== null)
    .sort((a, b) => a.indexPosition - b.indexPosition);
};


export const getPortStatus = (port) => {
  // 1. Handle null/undefined port
  if (!port) {
    return "NotConfigured";
  }

  // Normalize values to numbers to ensure comparison works
  const admin = Number(port.adminstatus);
  const op = Number(port.opstatus);

  // 2. Admin status 3 or 0 => Not Configured (Highest Priority)
  if (admin === 3 || admin === 0) {
    return "NotConfigured";
  }

  // 3. Admin status 2 => Administratively Down
  if (admin === 2) {
    return "AdminDown";
  }

  // 4. Admin status 1 => Operational Logic
  if (admin === 1) {
    if (op === 1) {
      return "Up";
    }
    if (op === 2) {
      return "OperationalDown";
    }
    // If op is 6 or any other unexpected value
    return "NotConfigured";
  }

  // 5. Fallback for any other case
  return "NotConfigured";
};