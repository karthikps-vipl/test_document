/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : ImageNode.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\ImageNode.jsx
   Purpose                  : Created the Image Node for the different devices
   Created Date             : 13-03-2026
 ***********************************************************************************************/
import React, { memo, useEffect, useMemo, useState } from "react";
import {
  Handle,
  Position,
  NodeResizer,
  useUpdateNodeInternals,
} from "@xyflow/react";
import { useDispatch, useSelector } from "react-redux";
import { mapOpStatus1, nodeColor, topologyNodes } from "../topologyConstants";
import {
  filterSwitchPortsImageNode,
  getBadgeStyles,
  getDeviceStatus,
  getPortStatus,
  getSuperAdminDeviceStatus,
  getSwitchTemplateConfig,
} from "../utils";
import { updateNodeStyle } from "@/store/features/Topology/topologyNodesslice";
import { setTreeClickedItem } from "@/store/features/Inventory/inventorySlice";

export const Badge = ({ badgeStyles, displayCount }) => (
  <div
    className="absolute -top-[25px] -right-[16px] rounded-full flex items-center justify-center w-[38px] h-[38px] text-2xl font-bold shadow-lg "
    style={{
      backgroundColor: badgeStyles.backgroundColor,
      color: badgeStyles.color,
    }}
  >
    {displayCount}
  </div>
);

const TEN_GIG_PORT_STYLES = {
  25: {
    top: "50%",
    left: "81.5%",
    width: "18px",
    height: "12px",
  },

  26: {
    top: "50%",
    left: "85%",
    width: "18px",
    height: "12px",
  },

  27: {
    top: "50%",
    left: "89%",
    width: "18px",
    height: "12px",
  },

  28: {
    top: "50%",
    left: "93%",
    width: "18px",
    height: "12px",
  },
};

const isSuperAdmin = window.isSuperAdmin;

const ImageNode = ({ id, data, selected }) => {
  const dispatch = useDispatch();
  const updateNodeInternals = useUpdateNodeInternals();

  const treeClickedItem = useSelector(
    (state) => state.inventory.treeClickedItem
  );

  const [hoveredPort, setHoveredPort] = useState(null);

  const [scale, setScale] = useState(1);

  const badgeCountsArray = useSelector((state) => state.alarmSlice.badgeCount);

  console.log("fojdata", badgeCountsArray);

  const resourceId = data?.resourceId;

  console.log("jjjueuhfus", data);

  const currentBadge = useMemo(() => {
    if (Array.isArray(badgeCountsArray)) {
      return badgeCountsArray.find(
        (item) => String(item.id) === String(resourceId)
      );
    }
    return null;
  }, [badgeCountsArray, resourceId]);

  const displayCount = currentBadge ? currentBadge.badgeCount : 0;

  const badgeStyles = getBadgeStyles(currentBadge?.severity);

  console.log("badgeStyles", badgeStyles);

  const isSwitchNode =
    (data?.type === "switchPortNode" || !!data?.switchTemplateKey) &&
    data?.viewMode === "imageViewNode";

  const switchTemplate = getSwitchTemplateConfig(data?.resourceId);

  // const ports = useMemo(() => {
  //   return Array.isArray(data?.lstPortInfoDtl) ? data.lstPortInfoDtl : [];
  // }, [data]);
  const ports = useMemo(() => {
    return filterSwitchPortsImageNode(data?.lstPortInfoDtl);
  }, [data?.lstPortInfoDtl]);

  // const status =
  //   data?.imResourceType?.imResourceStateInfo?.resourceStateName?.toLowerCase();

  console.log("jfhvhports", ports);

  const imageSrc =
    topologyNodes?.[data?.resourceId] ??
    topologyNodes?.[switchTemplate?.shellImageKey];

  // const status = getDeviceStatus(data);
  // console.log("statussss", status);

  const status = isSuperAdmin
  ? getSuperAdminDeviceStatus(data)
  : getDeviceStatus(data);

  const bgColor = nodeColor[status] || "#555";

  console.log("jvdbgColor", status);

  useEffect(() => {
    updateNodeInternals(id);
  }, [data?.lstPortInfoDtl, data?.switchTemplateKey, id, data.viewMode]);

  const getHandleType = (position, index) => {
    switch (position) {
      case Position.Top:
      case Position.Left:
        return index % 2 === 0 ? "source" : "target";
      case Position.Right:
      case Position.Bottom:
        return index % 2 === 0 ? "target" : "source";
      default:
        return "source";
    }
  };

  console.log("fjnvjdata?.viewMode ", data.viewMode);

  const showSwitchWithPorts =
    isSwitchNode ||
    data?.viewMode === "simpleViewNode" ||
    data?.viewMode === "imageViewNode";

  useEffect(() => {
    if (data.resourceId === treeClickedItem) {
      setScale(1.5);
    } else {
      setScale(1);
    }
  }, [treeClickedItem, data.resourceId]);

  useEffect(() => {
    if (scale <= 1) return;

    const timer = setTimeout(() => {
      setScale(1);
      dispatch(setTreeClickedItem(""));
    }, 1000);

    return () => clearTimeout(timer);
  }, [scale, dispatch]);

  const transformStyle = {
    transform: `scale(${scale})`,
    transition: "transform 0.3s ease-in-out",
  };

  return (
    <div
      className="image-node-container"
      style={{
        width: data?.style?.width ?? switchTemplate?.width,
        //  height: data?.style?.height ?? switchTemplate?.height,
        ...transformStyle,
      }}
    >
      <NodeResizer
        minWidth={isSwitchNode ? switchTemplate?.width ?? 220 : 1}
        minHeight={isSwitchNode ? switchTemplate?.height ?? 90 : 1}
        isVisible={selected}
        onResize={(event, params) => {
          dispatch(
            updateNodeStyle({
              id,
              style: {
                width: params.width,
                height: params.height,
              },
            })
          );
        }}
      />

      {renderHandles(
        8,
        Position.Top,
        (side, i) => `${id}-${side}-${i + 1}`,
        getHandleType
      )}
      {renderHandles(
        3,
        Position.Left,
        (side, i) => `${id}-${side}-${i + 1}`,
        getHandleType
      )}
      {renderHandles(
        3,
        Position.Right,
        (side, i) => `${id}-${side}-${i + 1}`,
        getHandleType
      )}
      {renderHandles(
        8,
        Position.Bottom,
        (side, i) => `${id}-${side}-${i + 1}`,
        getHandleType
      )}

      {showSwitchWithPorts && switchTemplate ? (
        <div className="relative">
          <img
            src={topologyNodes[switchTemplate.shellImageKey]}
            alt=""
            style={{ width: "100%", height: "100%", objectFit: "contain" }}
          />
          <div
            className="node-label"
            style={{ backgroundColor: bgColor || "#555" , color:isSuperAdmin? "white" : "black"}}
          >
            {data?.resourceName}
          </div>
          <div
            style={{
              position: "absolute",
              left: switchTemplate.portArea.left,
              top: "35%",
              width: switchTemplate.portArea.width + 20,
              height: switchTemplate.portArea.height+20,
              display: "grid",
              // gridTemplateColumns: `repeat(${switchTemplate.portsPerRow}, minmax(0, 1fr))`,
              // gridTemplateRows: "repeat(2, minmax(0, 1fr))",
              gridTemplateColumns: "repeat(16, minmax(0, 1fr))",
              gridTemplateRows: "repeat(2, minmax(0, 1fr))",
              // gap: switchTemplate.portCount > 6 ? "20px 6px" : "16px 12px",
              columnGap: "20px",
              rowGap: "10px",
              alignItems: "center",
              justifyItems: "center",
              pointerEvents: "none",
            }}
          >
            {/* {ports.map((port, index) => {
              const isBottomRow = index >= switchTemplate.portsPerRow;
              return (
                <img
                  key={port.ifindex}
                  src={mapOpStatus1(port.opstatus, port.adminstatus)}
                  alt={port.adminstatus}
                  style={{
                    width: "100%",
                    maxWidth: `${switchTemplate.portImageWidth}px`,
                    height: "auto",
                    transform: isBottomRow ? "rotate(180deg)" : "none",
                  }}
                />
              );
            })} */}
            {ports.map((port) => {
              const position = port.indexPosition;

              if (!position) {
                return null;
              }

              const isTenGig = position >= 25 && position <= 28;

              const isBottomRow = position % 2 === 0 || isTenGig;

              const tenGigStyle = isTenGig ? TEN_GIG_PORT_STYLES[position] : {};

              return (
                <div
                  key={port.ifindex}
                  className={`switch-port ${isTenGig ? "ten-gig-port" : ""}`}
                  onMouseEnter={() => setHoveredPort(port)}
                  onMouseLeave={() => setHoveredPort(null)}
                  style={{
                    position: isTenGig ? "absolute" : "relative",

                    ...(isTenGig
                      ? tenGigStyle
                      : {
                          gridColumn: Math.ceil(position / 2),
                          gridRow: position % 2 === 0 ? 2 : 1,
                        }),

                    width: isTenGig ? tenGigStyle?.width : "100%",

                    height: isTenGig ? tenGigStyle?.height : "auto",

                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",

                    cursor: "pointer",
                    pointerEvents: "auto",
                    zIndex: hoveredPort?.ifindex === port.ifindex ? 100 : 1,
                  }}
                >
                  <img
                    src={mapOpStatus1(port.opstatus, port.adminstatus)}
                    alt={port.ifportname}
                    style={{
                      width: isTenGig ? "100%" : "100%",

                      height: isTenGig ? "100%" : "auto",

                      maxWidth: isTenGig
                        ? "none"
                        : `${switchTemplate.portImageWidth}px`,

                      objectFit: "contain",

                      transform: isBottomRow ? "rotate(180deg)" : "none",
                    }}
                  />

                  {hoveredPort?.ifindex === port.ifindex && (
                    <div className="switch-port-tooltip">
                      {/* <div>
                        <strong>{port.ifportname}</strong>
                      </div> */}

                      {/* <div>{port.ifdesc}</div> */}
                      <div>{`${port.ifdesc} - ${getPortStatus(port)}`}</div>
                      {/* <div>Status: {getPortStatus(port)}</div> */}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <Badge displayCount={displayCount} badgeStyles={badgeStyles} />
        </div>
      ) : (
        /* 2. CP's mode and standard Image mode stay here (remains the same) */
        <div className="node-content-body">
          {(data?.viewMode === "imageViewNode" ||
            data?.lmResourceType?.resourceTypeId === 906) &&
            imageSrc && (
              <img src={imageSrc} className="node-main-image" alt="" />
            )}
          <div
            className="node-label"
            style={{ backgroundColor: bgColor || "#555", color:isSuperAdmin? "white" : "black"}}
          >
            {data?.resourceName}
          </div>
          {/* <Badge /> */}
          <Badge displayCount={displayCount} badgeStyles={badgeStyles} />

          {data?.viewMode === "CPs" && (
            <div className="parameters-list">
              <strong>Critical Parameters</strong>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const renderHandles = (count, pos, genId, getType) =>
  Array.from({ length: count }).map((_, i) => {
    const isHoriz = pos === Position.Top || pos === Position.Bottom;
    const offset = isHoriz
      ? ((i + 1) * 100) / (count + 1)
      : ((i + 1) * 100) / (count + 1.9);
    return (
      <Handle
        key={`${pos}-${i}`}
        id={genId(pos.toLowerCase(), i)}
        position={pos}
        type={getType(pos, i)}
        className="handle"
        style={{
          [isHoriz ? "left" : "top"]: `${isHoriz ? offset : offset + 3}%`,
          [pos.toLowerCase()]: "-1px",
          transform: isHoriz ? "translateX(-50%)" : "translateY(-50%)",
        }}
      />
    );
  });

export default memo(ImageNode);
