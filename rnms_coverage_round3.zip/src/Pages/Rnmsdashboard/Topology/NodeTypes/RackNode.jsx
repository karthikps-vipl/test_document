/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : RackNode.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\RackNode.jsx
   Purpose                  : Created the Rack Node by import the svg image of rack view and also node resizer
   Created Date             : 16-03-2026
 ***********************************************************************************************/

import { NodeResizer } from "@xyflow/react";
import React, { memo, useEffect, useState } from "react";
import { nodeColor, topologyNodes } from "../topologyConstants";
import { getDeviceStatus, getDeviceStatusCnms, getSuperAdminDeviceStatus } from "../utils";
import { useDispatch, useSelector } from "react-redux";
import { setTreeClickedItem } from "@/store/features/Inventory/inventorySlice";
import { useTheme } from "@mui/material";

const isSuperAdmin = window.isSuperAdmin;

const RackNode = ({ id, data, selected }) => {
  const imageSrc = topologyNodes[data?.resourceId];

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const status = isSuperAdmin
    ? getSuperAdminDeviceStatus(data)
    : isCnms
    ? getDeviceStatusCnms(data)
    : getDeviceStatus(data);

  // const status = getDeviceStatus(data);
  const dispatch = useDispatch();

  const treeClickedItem = useSelector(
    (state) => state.inventory.treeClickedItem
  );

  const [scale, setScale] = useState(1);

  console.log("gjhjstatus", status);

  const bgColor = nodeColor[status];

  useEffect(() => {
    if (data.resourceId === treeClickedItem) {
      setScale(1.5);
    } else {
      setScale(1);
    }
  }, [treeClickedItem, data.resourceId]);

  setTimeout(() => {
    if (scale > 1) {
      setScale(1);
      dispatch(setTreeClickedItem(""));
    }
  }, 1000);

  const transformStyle = {
    transform: `scale(${scale})`,
    transition: "transform 0.3s ease-in-out",
  };

  const theme = useTheme();
  return (
    <div
      style={{
        backgroundColor: bgColor || "#555",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        // width:"100%",
        width: "223px",
        height: "100%",
        textAlign: "center",
        // color: theme.palette.text.linkstatus,
        color: isSuperAdmin ? "white" : theme.palette.text.linkstatus,
        border: "1.5px solid gray",
        ...transformStyle,
      }}
      // sx={{  backgroundColor: 'theme.palette.background.toplogybg',}}
    >
      <NodeResizer isVisible={selected} minWidth={1} minHeight={1} />
      {/* <div> */}
      <img
        style={{ width: "100%", height: "100%" }}
        src={imageSrc}
        alt={data?.resourceName}
      />
      {/* </div> */}
    </div>
  );
};

export default memo(RackNode);
