/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : SimpleViewNode.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\SimpleViewNode.jsx
   Purpose                  : Created the SimpleViewNode of node view by having handlers on 4 different the side
   Created Date             : 18-03-2026
 ***********************************************************************************************/

/* eslint-disable no-unused-vars */
import React, { memo } from "react";
import { Handle, Position } from "@xyflow/react";
import useTopologyUtilityMethod from "../../../../utility/customHooks/useTopologyUtilityMethods";
import { Badge, Box } from "@mui/material";

const isSuperAdmin = window.isSuperAdmi

const simpleViewNode = ({ id, data, type }) => {
  console.log(data, "nodeData");
  console.log(type, "typetype");

  const { nodeColor } = useTopologyUtilityMethod();

  console.log(nodeColor, "nodeColor");

  const status =
    data?.imResourceType?.imResourceStateInfo?.resourceStateName.toLowerCase();

  const generateHandleId = (side, label, index) => `${id}-${side}-${index + 1}`;

  const getHandleType = (position, index) => {
    // For "alternate" and default cases
    let handleType;
    switch (position) {
      case Position.Top:
      case Position.Left:
        handleType = index % 2 === 0 ? "source" : "target";
        break;
      case Position.Right:
      case Position.Bottom:
        handleType = index % 2 === 0 ? "target" : "source";
        break;
      default:
        handleType = "source";
    }

    return handleType;
  };

  const topCount = 8;
  const bottomCount = 8;
  const leftCount = 3;
  const rightCount = 3;
  return (
    <div
      className="image-node-container"
      style={{
        height: "100%",
        width: "100%",
      }}
    >
      {/* <NodeResizer /> */}
      {Array.from({ length: topCount }).map((_, i) => {
        const left = ((i + 1) * 100) / (topCount + 1);
        const handleType = getHandleType(Position.Top, i);

        return (
          // <React.Fragment key={`top-${i}`}>
          // After the SonarQube fixing
          <React.Fragment key={`${i}`}>
            <Handle
              id={generateHandleId("top", data.resourceId, i)}
              position={Position.Top}
              type={handleType}
              isConnectable={true}
              className="handle"
              style={{
                left: `${left}%`,
                // top: "-2px",
                transform: "translateX(-50%)",
              }}
            />
          </React.Fragment>
        );
      })}

      {/* Left Handles */}
      {Array.from({ length: leftCount }).map((_, i) => {
        const top = ((i + 1) * 100) / (leftCount + 1.9);
        const handleType = getHandleType(Position.Left, i);
        return (
          // <React.Fragment key={`left-${i}`}>
          <React.Fragment key={`${i}`}>
            <Handle
              id={generateHandleId("left", data.resourceId, i)}
              position={Position.Left}
              type={handleType}
              isConnectable={true}
              className="handle"
              style={{
                top: `${top + 3}%`,
                left: "1px",
                transform: "translateX(-50%)",
              }}
            />
          </React.Fragment>
        );
      })}

      {/* Right Handles */}
      {Array.from({ length: rightCount }).map((_, i) => {
        const top = ((i + 1) * 100) / (rightCount + 1.9);
        const handleType = getHandleType(Position.Right, i);
        return (
          // <React.Fragment key={`right-${i}`}>
          // After the SonarQube fixing
          <React.Fragment key={`${i}`}>
            <Handle
              id={generateHandleId("right", data.resourceId, i)}
              position={Position.Right}
              type={handleType}
              isConnectable={true}
              className="handle"
              style={{
                top: `${top + 3}%`,
                right: "-5px",
                transform: "translateX(-50%)",
              }}
            />
          </React.Fragment>
        );
      })}

      {/* Bottom Handles */}
      {Array.from({ length: bottomCount }).map((_, i) => {
        const left = ((i + 1) * 100) / (bottomCount + 1);
        const handleType = getHandleType(Position.Bottom, i);
        return (
          // <React.Fragment key={`bottom-${i}`}>
          <React.Fragment key={`${i}`}>
            <Handle
              id={generateHandleId("bottom", data.resourceId, i)}
              position={Position.Bottom}
              type={handleType}
              isConnectable={true}
              className="handle"
              style={{
                left: `${left}%`,
                bottom: "-1px",
                transform: "translateX(-50%)",
              }}
            />
          </React.Fragment>
        );
      })}

      {/* {data?.imResourceType?.resourceTypeId === 906 && (
        <img
          src={topologyNodes[data.resourceId]}
          width={"100%"}
          height={"100%"}
        />
      )} */}

      {/* <div
        className="absolute -top-[12px] -right-[12px] bg-amber-500 rounded-xl text-center w-[25px] h-[25px]  "
      >
        10
      </div> */}

      <Box
        sx={{
          position: "relative",
          display: "inline-block",
          overflow: "visible",
        }}
      >
        <Badge
          badgeContent={0}
          color="primary"
          showZero
          anchorOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
          sx={{
            position: "absolute",
            top: -2,
            right: 0,
            zIndex: 10,
            "& .MuiBadge-badge": {
              fontSize: "10px",
              height: 20,
              minWidth: 20,
            },
          }}
        />
        <div
          className="node-label"
          style={{ backgroundColor: nodeColor[status] || "#ccc", color:isSuperAdmin? "white" : "black"}}
        >
          {data.resourceName}
        </div>
      </Box>
    </div>
  );
};

export default memo(simpleViewNode);
