/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : RackFrameNode.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\RackFrameNode.jsx
   Purpose                  : Created the RackFrameNode by import the svg image of rack view
   Created Date             : 15-03-2026
 ***********************************************************************************************/

import React, { memo } from "react";
import { topologyNodes } from "../topologyConstants";

const RackFrameNode = ({data}) => {
  const rackFrameSrc = topologyNodes["rackFrame"];

  return (
    <div
      style={{
        width:"100%",
        height:"100%",
        pointerEvents:"none",
      }}
    >
      <img
        src={rackFrameSrc}
        alt="Rack Frame"
        draggable={false}
        style={{
          width:"100%",
          height:"100%",
          objectFit:"contain",
          pointerEvents:"none",
        }}
      />
    </div>
  );
};

export default memo(RackFrameNode);
