/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : ImageOnly.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\ImageOnly.jsx
   Purpose                  : Created the Image Node for unabling only the view mode
   Created Date             : 14-03-2026
 ***********************************************************************************************/

import { NodeResizer } from "@xyflow/react";
import React, { memo } from "react";
import { topologyNodes } from "../topologyConstants";

const ImageOnly = ({ id, data, selected }) => {
  const imageSrc = topologyNodes[data.idToGetImage];
 
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: "100%",
      }}
    >
      <NodeResizer isVisible={selected} minWidth={1} minHeight={1} />
      {/* <div> */}

      <img
        style={{ width: "100%", height: "100%" }}
        src={imageSrc}
        alt="Devices"
      />
      {/* </div> */}
    </div>
  );
};

export default memo(ImageOnly);
