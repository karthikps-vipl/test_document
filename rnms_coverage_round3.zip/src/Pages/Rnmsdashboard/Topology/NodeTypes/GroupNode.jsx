/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : GroupNode.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\GroupNode.jsx
   Purpose                  : Created the Group Node defining the right left handlers for the edges
   Created Date             : 13-03-2026
 ***********************************************************************************************/

/* eslint-disable no-unused-vars */
import React, { memo } from "react";
import { Position, Handle } from "@xyflow/react";

const GroupNode = ({ data, id, selected }) => {
  const generateHandleId = (side) => `${id}-${side}`;
  

  return (
    <>
      <Handle
        id={generateHandleId("left")}
        type="target"
        position={Position.Left}
        style={{ width: "5px", height: "5px" }}
      />
      <Handle
        id={generateHandleId("right")}
        type="source"
        position={Position.Right}
        style={{ width: "5px", height: "5px" }}
      />
    </>
  );
};

export default memo(GroupNode);














