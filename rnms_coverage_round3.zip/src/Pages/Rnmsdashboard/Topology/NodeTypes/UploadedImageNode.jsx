import React, { memo } from "react";
import { NodeResizer, useReactFlow } from "@xyflow/react";

const UploadedImageNode = ({ id, data, selected, style }) => {
  const { updateNode } = useReactFlow();

  const handleResizeEnd = (_event, params) => {
    const width = Math.max(20, Math.round(params.width));
    const height = Math.max(20, Math.round(params.height));

    updateNode(id, (node) => ({
      ...node,
      width,
      height,
      style: {
        ...node.style,
        width,
        height,
      },
      data: {
        ...node.data,
        width,
        height,
      },
    }));
  };

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        position: "relative",
      }}
    >
      <NodeResizer
        isVisible={selected}
        minWidth={20}
        minHeight={20}
        onResizeEnd={handleResizeEnd}
      />

      <img
        src={data.src}
        alt={data.fileName || "Uploaded image"}
        draggable={false}
        style={{
          display: "block",
          width: "100%",
          height: "100%",
          objectFit: "fill",
          pointerEvents: "none",
          userSelect: "none",
        }}
      />
    </div>
  );
};

export default memo(UploadedImageNode);