/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : RackResourceName.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\RackResourceName.jsx
   Purpose                  : Created the RackResourceName for data resource
   Created Date             : 17-03-2026
 ***********************************************************************************************/

import React, { memo } from "react";

const RackResourceName = ({ id, data }) => {
  return <div>{data?.resourceName}</div>;
};

export default memo(RackResourceName);
