/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodeTypes 
   File Name                : BlankNode.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeTypes\BlankNode.jsx
   Purpose                  : Created the Blank Node for defining the name/ bordercolor /background color
   Created Date             : 12-03-2026
 ***********************************************************************************************/

// import { useTheme } from "@mui/material";

// import { NodeResizer } from "@xyflow/react";
// import React, { memo } from "react";

// const BlankNode = ({ data, selected }) => {
//   const theme=useTheme()
//   return (
//     <div
//       style={{
//         background: data?.backgroundColor || "#fff",
//         border: `1px solid ${data?.borderColor || "#ccc"}`,
//         fontWeight:600,
//         fontSize:'30px',
//         display: "flex",
//         justifyContent: "center",
//         alignItems: "center",
//         width: "223px",
//         height: "100%",
//         boxSizing: "border-box", // standardizing box geometry model for resize clarity
//       }}
//     >
//       <NodeResizer
//         isVisible={selected}
//         minWidth={10}
//         minHeight={10}
//       />
//       <div
//         style={{
//           textAlign: "center",
//           fontSize: 13,
//           wordBreak: "break-word",
//           padding: "4px",
//           color:theme.palette.text.linkstatus
//         }}
//       >
//         {data?.label || "Blank Node"}
//       </div>
//     </div>
//   );
// };

// export default memo(BlankNode);


import { useTheme } from "@mui/material";
import { NodeResizer } from "@xyflow/react";
import React, { memo } from "react";

const BlankNode = ({ data, selected }) => {
  const theme = useTheme();

  return (
    <div
      style={{
        background:
          data?.backgroundColor || data?.color || "#fff",
        border: `1px solid ${data?.borderColor || "#ccc"}`,
        fontWeight: 600,
        fontSize: "30px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "223px",
        height: "100%",
        boxSizing: "border-box",
      }}
    >
      <NodeResizer
        isVisible={selected}
        minWidth={10}
        minHeight={10}
      />

      <div
        style={{
          textAlign: "center",
          fontSize: 13,
          wordBreak: "break-word",
          padding: "4px",
          color: theme.palette.text.linkstatus,
        }}
      >
        {data?.label || data?.text || "Blank Node"}
      </div>
    </div>
  );
};

export default memo(BlankNode);