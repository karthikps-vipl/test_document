/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : topologyConstants.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\topologyConstants.js
   Purpose                  : Created the topologyConstants for device all the deice name constant, topologyAdminIcons, nodecolor, LinkTypeLegends
   Created Date             : 27-03-2026
 ***********************************************************************************************/
import portAdminDown from "../../../assets/PortStatus/Admin Down.svg";
import portDown from "../../../assets/PortStatus/Down.svg";
import portNotConfigured from "../../../assets/PortStatus/Not Configured.svg";
import portUp from "../../../assets/PortStatus/Up.svg";
import switch24Shell from "../../../assets/PortStatus/port.svg";
import switch6Shell from "../../../assets/PortStatus/port.svg";

import MCT_EP_R_LAP from "../../../assets/Topology Images/RLAP.svg";
import MCT_EP_MODEM_MFTDMA from "../../../assets/Topology Images/REMOTE MODEM.svg";
import MCT_EP_IP_PHONE_4 from "../../../assets/Topology Images/IP PHONE.svg";
import MCT_EP_ACU_WITH_BTR from "../../../assets/Topology Images/ACU+BTR.svg";
import MCT_EP_SERIAL_SERVER from "../../../assets/Topology Images/SERIAL SERVER.svg";
import MCT_EP_LOS_IDU from "../../../assets/Topology Images/LOS IDU.svg";
import MCT_EP_IP_CAMERA_INDOOR from "../../../assets/Topology Images/IP CAMERA.svg";
import MCT_EP_ANTP from "../../../assets/Topology Images/antp.svg";
import MCT_EP_ROUTER from "../../../assets/Topology Images/ROUTER.svg";
import MCT_EP_NETWORK_ACCELARATOR from "../../../assets/Topology Images/NETWORK ACCELERATOR.svg";
import MCT_EP_VOIP_GATEWAY from "../../../assets/Topology Images/VOIP GATEWAY 2.svg";
import MCT_EP_UPS_1_KVA from "../../../assets/Topology Images/ups-1kvg.svg";
import MCT_EP_NGFW from "../../../assets/Topology Images/IPSNGFW.svg";
import MCT_EP_DG_SET from "../../../assets/Topology Images/18.5 KVG DG-1.svg";
// import MCT_EP_SWITCH_24PORT from "../../../assets/Topology Images/switch.svg";
import MCT_EP_SWITCH_24PORT from "../../../assets/PortStatus/port.svg";
import antena from "@/assets/Topology Images/antena.svg";
import pda from "@/assets/Topology Images/pda.svg";
import pda_radio from "@/assets/Topology Images/PDA RADIO.svg";
import RackFrame from "@/assets/Topology Images/Rack-Single.svg";
// import RackSingle from "@/assets/Topology Images/Rack-Single.svg";

import deleteIcon from "@/assets/SVGIcons/DeleteIcon.svg";
import undoIcon from "@/assets/SVGIcons/undo.svg";
import redoIcon from "@/assets/SVGIcons/redo.svg";
import saveIcon from "@/assets/SVGIcons/save.svg";
import viewIcon from "@/assets/SVGIcons/view(eye).svg";
import verticalMenu from "@/assets/SVGIcons/vertical menu.svg";
// import filterIcon from "@/assets/SVGIcons/Filter Svg.2.svg";
import filterIcon from "@/assets/SVGIcons/filter_svg_1.svg";

export const topologyNodes = {
  "MCT_EP_R-LAP": MCT_EP_R_LAP,
  "MCT_EP_DG_SET-2": MCT_EP_DG_SET,
  // "MCT_EP_DIGITAL_GROUND_EQUIPMENT":,
  "MCT_EP_MODEM-MFTDMA": MCT_EP_MODEM_MFTDMA,
  // "MCT_EP_VSAT_ENCRYPTOR":,
  "MCT_EP_IP_PHONE-4": MCT_EP_IP_PHONE_4,
  // "MCT_EP_HEATING_VENTILATION_AC-2":,
  "MCT_EP_DG_SET-1": MCT_EP_DG_SET,
  MCT_EP_ACU_WITH_BTR: MCT_EP_ACU_WITH_BTR,
  "MCT_EP_IP_PHONE-2": MCT_EP_IP_PHONE_4,
  "MCT_EP_IP_PHONE-1": MCT_EP_IP_PHONE_4,
  // "MCT_EP_LOS_ENCRYPTOR":,
  "MCT_EP_IP_PHONE-3": MCT_EP_IP_PHONE_4,
  MCT_EP_SERIAL_SERVER: MCT_EP_SERIAL_SERVER,
  "MCT_EP_SWITCH-24PORT": MCT_EP_SWITCH_24PORT,
  MCT_EP_LOS_IDU: MCT_EP_LOS_IDU,
  "MCT_EP_IP_PHONE-5": MCT_EP_IP_PHONE_4,
  MCT_EP_IP_CAMERA_INDOOR: MCT_EP_IP_CAMERA_INDOOR,
  MCT_EP_ANTP: MCT_EP_ANTP,
  // "MCT_EP_BUC_KU_BAND_UPPER":,
  MCT_EP_ROUTER_WITH_CME: MCT_EP_ROUTER,
  // "MCT_EP_RADIO":,
  // "MCT_EP_HEATING_VENTILATION_AC-1":,
  MCT_EP_ROUTER: MCT_EP_ROUTER,
  // "MCT_EP_RADIO_4.9TP6hhZ":,
  // "MCT_EP_BASE_BAND_UNIT":,
  MCT_EP_NETWORK_ACCELARATOR: MCT_EP_NETWORK_ACCELARATOR,
  // "MCT_EP_BUC_KU_BAND_LOWER":,
  MCT_EP_VOIP_GATEWAY: MCT_EP_VOIP_GATEWAY,
  "MCT_EP_UPS-6_KVA-2": MCT_EP_UPS_1_KVA,
  "MCT_EP_UPS-1_KVA": MCT_EP_UPS_1_KVA,
  "MCT_EP_UPS-6_KVA-1": MCT_EP_UPS_1_KVA,
  MCT_EP_NGFW: MCT_EP_NGFW,
  // "MCT_EP_NVR-INDOOR":,
  rackFrame: RackFrame,
  // RackSingle: RackSingle,
  antena: antena,
  pda: pda,
  "pda radio": pda_radio,
  switch24: switch24Shell,
  switch6: switch6Shell,
};

export const topologyAdminIcons = {
  delete: deleteIcon,
  undo: undoIcon,
  redo: redoIcon,
  save: saveIcon,
  eye: viewIcon,
  verticalMenu: verticalMenu,
  settingsFilter: filterIcon,
};

// export const nodeTypes = {
//   // simpleViewNode: SimpleViewNode,
//   // imageViewNode: ImageNode,
//   // groupNode: GroupNode,
//   commonNode: ImageNode,
//   rackNode: RackNode,
//   rackFrame: RackFrameNode,
//   rackResourceName: RackResourceName,
//   blankNode: BlankNode,
// };

// export const portStatusNodes = {
//   up: portUp,
//   down: portDown,
//   adminDown: portAdminDown,
//   notConfigured: portNotConfigured,
// };

export const portStatusNodes = {
  1: portUp,
  2: portDown,
  3: portAdminDown,
  0: portNotConfigured,
};

export function mapOpStatus(opstatus, adminstatus) {
  const op = Number(opstatus);
  const admin = Number(adminstatus);

  console.log("mapOpStatus INPUT", {
    opstatus,
    adminstatus,
    normalizedOp: op,
    normalizedAdmin: admin,
    opType: typeof opstatus,
    adminType: typeof adminstatus,
  });

  // Admin status 3/0 => Not Configured
  if (admin === 3 || admin === 0) {
    return "notConfigured";
  }

  // Admin status 1 => Operational
  if (admin === 1) {
    if (op === 1) {
      return "up";
    }

    if (op === 2) {
      return "operational_down";
    }
  }

  // Admin status 2 => Administratively Down
  if (admin === 2) {
    // if (op === 1 || op === 2) {
      return "down";
    // }
  }

  console.warn("Unknown port status combination", {
    opstatus,
    adminstatus,
    op,
    admin,
  });

  return "notConfigured";
}


// export function mapOpStatus1(opstatus, adminstatus) {
//   if (adminstatus === 2) return portAdminDown; // Usually 2 is Admin Down in SNMP
//   if (adminstatus === 3 || adminstatus === 0) return portNotConfigured;

//   switch (opstatus) {
//     case 1:
//       return portUp;
//     case 2:
//       return portDown;
//     case 6:
//       return portNotConfigured; // Mapping "notPresent" or similar
//     default:
//       return portNotConfigured;
//   }
// }

export function mapOpStatus1(opstatus, adminstatus) {
  // Ensure we are working with numbers to avoid type mismatch issues
  const op = Number(opstatus);
  const admin = Number(adminstatus);

  // 1. Admin status 3 or 0 => Not Configured (Highest priority)
  if (admin === 3 || admin === 0) {
    return portNotConfigured; 
  }

  // 2. Admin status 2 => Administratively Down
  // In mapOpStatus, if admin is 2, the result is always "down" regardless of op status
  if (admin === 2) {
    return portAdminDown; // Or 'down' depending on your constant definitions
  }

  // 3. Admin status 1 => Operational logic
  if (admin === 1) {
    switch (op) {
      case 1:
        return portUp; // "up"
      case 2:
        // This implements the specific logic from mapOpStatus:
        // If admin is up but op is 2, it is 'operational_down'
        return portDown; 
      case 6:
        return portNotConfigured;
      default:
        return portNotConfigured;
    }
  }

  // Fallback for any unhandled combinations
  return portNotConfigured;
}

// export const nodeColor = {
//   online: '#008000',
//   offline: "#ff0000",
//   maintenance: "#b8860b",
//   undiscovered: "#0000ff",
//   unmanaged: "#808080",
//   managed: "#C9C9FB",
// };

export const nodeColor = {
  online: 'rgb(9, 255, 115)',
  offline: "#F77369",
  maintenance: "#FFC334",
  undiscovered: "#D7EEFF",
  // undiscovered: "#0000ff",
  unmanaged: "#D3D3D3",
  managed: "#0000ff",
};





export const severityColor = {
  Major: "#D75961",
  Minor: "FFFF00",
  Warning: "00FFFF",
};

export const topologyViews = [
  {
    key: "simpleViewNode",
    label: "Simple view",
  },
  {
    key: "imageViewNode",
    label: "Image View",
  },
  {
    key: "CPs",
    label: "CP'S",
  },
];

export const EdgeContextMenuOptions = [
  {
    type: "10GE",
    width: "50px",
    height: "1.5px",
    backgroundColor: "grey",
    borderBottom: "none",
  },
  {
    type: "1GE",
    width: "50px",
    height: "2px",
    backgroundColor: "none",
    borderBottom: "3px dotted grey",
  },
  {
    type: "mgmt",
    width: "50px",
    height: "2px",
    backgroundColor: "none",
    borderBottom: "2px dashed grey",
  },
];

export const LinkTypeLegends = [
  {
    lineType: "solid",
    color: "orange",
    label: "10GE",
  },
  {
    lineType: "dotted",
    color: "orange",
    label: "1GE",
  },
  {
    lineType: "dashed",
    color: "orange",
    label: "Mgmt",
  },
];
