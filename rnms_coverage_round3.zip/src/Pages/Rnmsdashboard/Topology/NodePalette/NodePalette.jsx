// /***********************************************************************************************
//    Project                  : IAF-NMS
//    SubSystem                : NodePalette
//    File Name                : NodePalette.jsx
//    Author                   : ARUN - VIPL
//    Package                  : src\Pages\Rnmsdashboard\Topology\NodePalette\NodePalette.jsx
//    Purpose                  : Implemented the device for dragging the specific device
//    Created Date             : 10-03-2026
//  ***********************************************************************************************/

// import React, { useEffect, useState, memo, useMemo } from "react";
// import { topologyNodes } from "../topologyConstants";
// import { GET_ALL_RESOURCES_BY_TERMINAL } from "@/RestAPI/url/endpoint";
// import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import { Tooltip } from "@mui/material";
// import { useSelector } from "react-redux";
// import { generateRandomString } from "@/utility/FormValidation/Regex";
// import { createSwitchPaletteNode, SWITCH_PALETTE_ITEMS } from "../utils";

// const NodePalette = ({ usedNodeIds = [] }) => {
//   const [allNodes, setAllNodes] = useState([]);

//   console.log("jdijgnode",allNodes);

//   const { siteDetails } = useSelector((state) => state.nodeDetails);

//   useEffect(() => {
//     InventoryAxios(GET_ALL_RESOURCES_BY_TERMINAL + `/${siteDetails?.id}`, "get")
//       .then((res) => {
//         setAllNodes(res.data);
//         console.log("jdndatatata",res.data);

//       })
//       .catch((err) => console.error(err));
//   }, []);

//   // 1. Group nodes by Type ID and filter out those already on the canvas
//   const groupedInventory = useMemo(() => {
//     const groups = {};

//     allNodes.forEach((node) => {
//       const typeId = node.imResourceType.resourceTypeId;
//       const isUsed = usedNodeIds.includes(node.resourceId);

//       if (!groups[typeId]) {
//         groups[typeId] = {
//           details: node, // Keep one for the icon/label
//           available: [],
//           total: 0,
//         };
//       }

//       groups[typeId].total += 1;
//       if (!isUsed) {
//         groups[typeId].available.push(node);
//       }

//     });

//     // Switch templates for topology drag/drop
//     SWITCH_PALETTE_ITEMS.forEach((item) => {
//       groups[item.details.resourceId] = item;
//     });

//     // Add the custom node
//     groups["rackFrame"] = {
//       details: {
//         resourceId: "rackFrame", // Unique ID for the custom node
//         resourceName: "rackFrame", // Name for tooltip
//       },
//       available: [
//         {
//           resourceId: "rackFrame" + generateRandomString(6),
//           type: "rackFrame",
//         },
//       ], // It must be an array even if only one
//       total: 1,
//     };

//     // blank node to enter text to display NA/Power panel /rank name so that user can enter any text
//     groups["blankNode"] = {
//       details: {
//         resourceId: "blankNode", // Unique ID for the custom node
//         resourceName: "blankNode", // Name for tooltip
//       },
//       available: [
//         {
//           resourceId: "blankNode" + generateRandomString(6),
//           type: "blankNode",
//         },
//       ], // It must be an array even if only one
//       total: 1,
//     };

//     groups["antena"] = {
//       details: {
//         resourceId: "antena", // Unique ID for the custom node
//         resourceName: "antena", // Name for tooltip
//       },
//       available: [
//         {
//           resourceId: "antena" + generateRandomString(8),
//           idToGetImage: "antena",
//           type: "imageOnly",
//         },
//       ], // It must be an array even if only one
//       total: 1,
//     };

//     groups["pda"] = {
//       details: {
//         resourceId: "pda", // Unique ID for the custom node
//         resourceName: "pda", // Name for tooltip
//       },
//       available: [
//         {
//           resourceId: "pda" + generateRandomString(8),
//           idToGetImage: "pda",
//           type: "imageOnly",
//         },
//       ], // It must be an array even if only one
//       total: 1,
//     };

//     groups["pda radio"] = {
//       details: {
//         resourceId: "pda radio", // Unique ID for the custom node
//         resourceName: "pda radio", // Name for tooltip
//       },
//       available: [
//         {
//           resourceId: "pda radio" + generateRandomString(8),
//           idToGetImage: "pda radio",
//           type: "imageOnly",
//         },
//       ], // It must be an array even if only one
//       total: 1,
//     };

//     return Object.values(groups);
//   }, [allNodes, usedNodeIds]);

//   // const onDragStart = (event, nodeData) => {
//   //   event.dataTransfer.setData(
//   //     "application/reactflow",
//   //     JSON.stringify(nodeData)
//   //   );
//   //   event.dataTransfer.effectAllowed = "move";
//   // };

//   const onDragStart = (event, nodeData) => {
//     const payload =
//       nodeData?.type === "switchPortNode"
//         ? createSwitchPaletteNode(nodeData.switchTemplateKey)
//         : nodeData;

//     event.dataTransfer.setData(
//       "application/reactflow",
//       JSON.stringify(payload),
//     );
//     event.dataTransfer.effectAllowed = "move";
//   };

//   console.log("dbchgroupedInventory",groupedInventory);

//   return (
//     <Box className="flex flex-col w-full h-full">
//       <Box className="group relative flex flex-col items-center py-1 transition-all border-b-2 text-[13px]  text-center border-[#D0D0D0] bg-gray-50">
//         {groupedInventory.length > 0
//           ? "Resource Details"
//           : "No resources found"}
//       </Box>

//       {groupedInventory.length > 0 ? (
//         groupedInventory.map((group) => {
//           const remainingCount = group.available.length;
//           const isDisabled = remainingCount === 0;
//           const nextAvailableNode = group.available[0];

//           return (
//             <Tooltip
//               title={group?.details?.resourceName}
//               key={group.details.resourceId}
//               placement="right"
//             >
//               <Box
//                 key={group.details.resourceId}
//                 onDragStart={(e) => {
//                   !isDisabled && onDragStart(e, nextAvailableNode);
//                 }}
//                 draggable={!isDisabled}
//                 className={`group relative flex flex-col items-center p-2 transition-all  border-b-2 border-[#D0D0D0] ${
//                   isDisabled
//                     ? "opacity-40 grayscale cursor-not-allowed"
//                     : "cursor-grab"
//                 }`}
//               >

//                 {/* Badge for Count */}
//                 <Box
//                   style={{
//                     display: "flex",
//                     gap: "2px",
//                     flexDirection: "column",
//                   }}
//                 >
//                   <span className="absolute top-3 -right-1 text-[10px]  px-1 z-10">
//                     {group.details.resourceId !== "rackFrame" &&
//                     group.details.resourceId !== "blankNode" &&
//                     group?.available[0]?.type !== "imageOnly" ? (
//                       <p>({remainingCount})</p>
//                     ) : (
//                       ""
//                     )}
//                   </span>

//                   {topologyNodes[group.details.resourceId] ? (
//                     <img
//                       src={topologyNodes[group.details.resourceId]}
//                       // style={{ fontSize: "10px" }}
//                       //   className="w-12 h-12 object-contain"
//                       // alt={group.details.resourceName}
//                     />
//                   ) : (
//                     <p style={{ fontSize: "10px" }}>
//                       {group.details.resourceName}
//                     </p>
//                   )}
//                 </Box>
//               </Box>
//             </Tooltip>
//           );
//         })
//       ) : (
//         <></>
//       )}
//     </Box>
//   );
// };

// export default memo(NodePalette);

/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NodePalette 
   File Name                : NodePalette.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodePalette\NodePalette.jsx
   Purpose                  : Implemented the device for dragging the specific device
   Created Date             : 10-03-2026
 ***********************************************************************************************/

import React, { useEffect, useState, memo, useMemo,useRef } from "react";
import { topologyNodes } from "../topologyConstants";
import { Box, Tooltip,IconButton } from "@mui/material";
import { useSelector } from "react-redux";
import { generateRandomString } from "@/utility/FormValidation/Regex";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
import AddIcon from "@mui/icons-material/Add";

const NodePalette = ({ usedNodeIds = [],onImageUpload, }) => {
  const imageNodePortStatus = useSelector(
    (state) => state.topologySlice.imagePortStatus
  );
  //  const [allNodes, setAllNodes] = useState(imageNodePortStatus || []);

  const [allNodes, setAllNodes] = useState([]);

  const fileInputRef = useRef(null);

const handleImageFileChange = (event) => {
  const file = event.target.files?.[0];

  if (file) {
    onImageUpload?.(file);
  }

  // Allows selecting the same file again.
  event.target.value = "";
};


  // 1. Synchronize local state when the Redux data initially arrives
  useEffect(() => {
    if (imageNodePortStatus && imageNodePortStatus.length > 0) {
      setAllNodes(imageNodePortStatus);
    }
  }, [imageNodePortStatus]);

  const availableResources = useSelector(
    (state) => state.portStatusSlice.availableResources
  );

  console.log("jhbdallNodes", allNodes);

  console.log("jdbimageNodePortStatus", imageNodePortStatus);

  // 3. Sync Local State with Redux WebSocket Updates
  useEffect(() => {
    if (availableResources && availableResources.length > 0) {
      setAllNodes((prevNodes) => {
        return prevNodes.map((node) => {
          const updatedResource = availableResources.find(
            (r) => r.resourceId === node.resourceId
          );

          if (updatedResource) {
            return {
              ...node,
              lstPortInfoDtl: updatedResource.lstPortInfoDtl.map((port) => ({
                ifindex: port.ifindex,
                adminstatus: port.adminstatus,
                // adminstatus: getPortStatusKey(port.adminstatus),
                ...port,
              })),
            };
          }
          return node;
        });
      });
    }
  }, [availableResources]);

  // 4. Grouping Logic

  const groupedInventory = useMemo(() => {
    const groups = {};

    allNodes.forEach((node) => {
      const typeId = node.imResourceType.resourceTypeId;
      const isUsed = usedNodeIds.includes(node.resourceId);

      if (!groups[typeId]) {
        groups[typeId] = {
          details: node,
          available: [],
          total: 0,
        };
      }
      groups[typeId].total += 1;
      if (!isUsed) {
        groups[typeId].available.push(node);
      }
    });

    groups["rackFrame"] = {
      details: {
        resourceId: "rackFrame",
        resourceName: "rackFrame",
      },
      available: [
        {
          resourceId: "rackFrame" + generateRandomString(6),
          type: "rackFrame",
        },
      ],
      total: 1,
    };

    groups["blankNode"] = {
      details: {
        resourceId: "blankNode",
        resourceName: "blankNode",
      },
      available: [
        {
          resourceId: "blankNode" + generateRandomString(6),
          type: "blankNode",
        },
      ],
      total: 1,
    };

    groups["antena"] = {
      details: {
        resourceId: "antena",
        resourceName: "antena",
      },
      available: [
        {
          resourceId: "antena" + generateRandomString(8),
          idToGetImage: "antena",
          type: "imageOnly",
        },
      ],
      total: 1,
    };

    groups["pda"] = {
      details: {
        resourceId: "pda",
        resourceName: "pda",
      },
      available: [
        {
          resourceId: "pda" + generateRandomString(8),
          idToGetImage: "pda",
          type: "imageOnly",
        },
      ],
      total: 1,
    };

    groups["pda radio"] = {
      details: {
        resourceId: "pda radio",
        resourceName: "pda radio",
      },
      available: [
        {
          resourceId: "pda radio" + generateRandomString(8),
          idToGetImage: "pda radio",
          type: "imageOnly",
        },
      ],
      total: 1,
    };

    return Object.values(groups);
  }, [allNodes, usedNodeIds]);

  const onDragStart = (event, nodeData) => {
    event.dataTransfer.setData(
      "application/reactflow",
      JSON.stringify(nodeData)
    );
    event.dataTransfer.effectAllowed = "move";
  };

  console.log("dbchgroupedInventory", groupedInventory);

//   return (
//     <ScrollContainer  className="h-full">
//     <Box className="flex flex-col w-full  " sx={{background: (theme) => theme.palette.background.tabs}}>
//       <Box className="group relative flex flex-col items-center py-1 transition-all border-b-2 text-[13px]  text-center border-[#D0D0D0] "  sx={{background: (theme) => theme.palette.custom.tabs}}>
//         {groupedInventory.length > 0
//           ? "Resource Details"
//           : "No resources found"}
//       </Box>

//       {groupedInventory.length > 0 ? (
//         groupedInventory.map((group) => {
//           const remainingCount = group.available.length;
//           const isDisabled = remainingCount === 0;
//           const nextAvailableNode = group.available[0];

//           return (
//             <Tooltip
//               title={group?.details?.resourceName}
//               key={group.details.resourceId}
//               placement="right"
//             >
//               <button
//                 // key={group.details.resourceId}
//                 // onDragStart={(e) => {
//                 //   !isDisabled && onDragStart(e, nextAvailableNode);
//                 // }}
//                 // draggable={!isDisabled}
//                 // className={`group relative flex flex-col items-center p-2 transition-all  border-b-2 border-[#D0D0D0] ${
//                 //   isDisabled
//                 //     ? "opacity-40 grayscale cursor-not-allowed"
//                 //     : "cursor-grab"
//                 // }`}
//                 type="button" // Prevents accidental form submissions
//                 key={group.details.resourceId}
//                 draggable={!isDisabled}
//                 onDragStart={(e) => {
//                   if (!isDisabled) onDragStart(e, nextAvailableNode);
//                 }}
//                 className={`group relative flex flex-col items-center p-2 transition-all border-b-2 border-[#D0D0D0] w-full ${
//                   isDisabled
//                     ? "opacity-40 grayscale cursor-not-allowed"
//                     : "cursor-grab"
//                 }`}
//               >
//                 {/* Badge for Count */}
//                 <Box
//                   style={{
//                     display: "flex",
//                     gap: "2px",
//                     flexDirection: "column",
//                   }}
//                 >
//                   <span className="absolute top-3 -right-1 text-[10px]  px-1 z-10">
//                     {group.details.resourceId !== "rackFrame" &&
//                     group.details.resourceId !== "blankNode" &&
//                     group?.available[0]?.type !== "imageOnly" ? (
//                       <p>({remainingCount})</p>
//                     ) : (
//                       ""
//                     )}
//                   </span>

//                   {topologyNodes[group.details.resourceId] ? (
//                     <img
//                       src={topologyNodes[group.details.resourceId]}
//                       alt="badge"

//                       // style={{ fontSize: "10px" }}
//                       //   className="w-12 h-12 object-contain"
//                       // alt={group.details.resourceName}
//                     />
//                   ) : (
//                     <p style={{ fontSize: "10px" }}>
//                       {group.details.resourceName}
//                     </p>
//                   )}
//                 </Box>
//               </button>
//             </Tooltip>
//           );
//         })
//       ) : (
//         <></>
//       )}
//     </Box>
//     </ScrollContainer>
//   );

return (
  <Box
    className="flex flex-col w-full h-full min-h-0"
    sx={{
      background: (theme) => theme.palette.background.tabs,
    }}
  >
    <ScrollContainer
      className="flex-1 min-h-0"
      style={{
        height: "auto",
        flex: 1,
        minHeight: 0,
      }}
    >
      <Box
        className="flex flex-col w-full"
        sx={{
          background: (theme) => theme.palette.background.tabs,
        }}
      >
        {/* --- Existing Header Logic --- */}
        <Box
          className="group relative flex flex-col items-center py-1 transition-all border-b-2 text-[13px] text-center border-[#D0D0D0]"
          sx={{ background: (theme) => theme.palette.custom.tabs }}
        >
          {groupedInventory.length > 0
            ? "Resource Details"
            : "No resources found"}
        </Box>

        {/* --- Existing Inventory Mapping Logic --- */}
        {groupedInventory.length > 0 ? (
          groupedInventory.map((group) => {
            const remainingCount = group.available.length;
            const isDisabled = remainingCount === 0;
            const nextAvailableNode = group.available[0];
            return (
              <Tooltip
                title={group?.details?.resourceName}
                key={group.details.resourceId}
                placement="right"
              >
                <button
                  type="button"
                  draggable={!isDisabled}
                  onDragStart={(e) => {
                    if (!isDisabled) onDragStart(e, nextAvailableNode);
                  }}
                  className={`group relative flex flex-col items-center p-2 transition-all border-b-2 border-[#D0D0D0] w-full ${
                    isDisabled
                      ? "opacity-40 grayscale cursor-not-allowed"
                      : "cursor-grab"
                  }`}
                >
                  {/* Badge for Count */}
                  <Box
                    style={{
                      display: "flex",
                      gap: "2px",
                      flexDirection: "column",
                    }}
                  >
                    <span className="absolute top-3 -right-1 text-[10px] px-1 z-10">
                      {group.details.resourceId !== "rackFrame" &&
                      group.details.resourceId !== "blankNode" &&
                      group?.available[0]?.type !== "imageOnly" ? (
                        <p>({remainingCount})</p>
                      ) : (
                        ""
                      )}
                    </span>
                    {topologyNodes[group.details.resourceId] ? (
                      <img
                        src={topologyNodes[group.details.resourceId]}
                        alt="badge"
                      />
                    ) : (
                      <p style={{ fontSize: "10px" }}>
                        {group.details.resourceName}
                      </p>
                    )}
                  </Box>
                </button>
              </Tooltip>
            );
          })
        ) : (
          <></>
        )}
      </Box>
    </ScrollContainer>

    {/* --- New Fixed Upload Control --- */}
    <Box
      className="flex-shrink-0 flex justify-center items-center border-t"
      sx={{
        minHeight: 48,
        borderColor: "divider",
        background: (theme) => theme.palette.background.tabs,
      }}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".jpeg,.jpg,.png,.svg,image/png,image/svg+xml"
        hidden
        onChange={handleImageFileChange}
      />
      <Tooltip title="Upload PNG or SVG image" placement="right">
        <IconButton
          aria-label="Upload image to canvas"
          onClick={() => fileInputRef.current?.click()}
          size="small"
          sx={{
            width: 34,
            height: 34,
            border: "1px solid",
            borderColor: "divider",
            borderRadius: "8px",
          }}
        >
          <AddIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Box>
  </Box>
);
};


export default memo(NodePalette);
