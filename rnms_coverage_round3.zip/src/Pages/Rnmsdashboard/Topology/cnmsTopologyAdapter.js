/**
 * CNMS -> Topology adapter.
 *
 * CNMS resources are normalized into the exact node shape Topology expects:
 *   { id, data: {...fullResource} }
 *
 * Rules:
 *  - id = resourceId (Topology merges by id + data.resourceId)
 *  - data = full resource + defensive aliases Topology's utils may read
 *  - nePollingInfo is guaranteed to exist (calculateStats reads it)
 *  - imResourceType.imResourceStateInfo guaranteed (status calc reads it)
 */

const normalizeResourceForTopology = (resource = {}) => {
    const resourceId = resource?.resourceId;
  
    return {
      ...resource,
  
      // Defensive aliases
      resourceId,
      resourceName: resource?.resourceName ?? "",
      siteId: resource?.siteId ?? "",
      siteName: resource?.imSiteDetail?.siteName ?? "",
  
      // Topology status calc (getUnifiedDevice) reads these:
      isDiscovered: !!resource?.isDiscovered,
      isMaintainance: !!resource?.isMaintainance,
  
      // getUnifiedDevice: hasPollingInfo check -> must be object or null
      nePollingInfo: resource?.nePollingInfo ?? null,
  
      // getUnifiedDevice reads resourceStateId from here
      imResourceType: {
        ...(resource?.imResourceType || {}),
        imResourceStateInfo:
          resource?.imResourceType?.imResourceStateInfo || {
            resourceStateId: 2, // unmanaged fallback
            resourceStateName: "Unmanaged",
          },
      },
  
      // CNMS already provides this on switch resources; keep as-is
      lstPortInfoDtl: resource?.lstPortInfoDtl ?? [],
    };
  };
  
  /**
   * Main export — CNMS resource array -> Topology node array.
   */
  export const toTopologyNodes = (resources = []) =>
    (Array.isArray(resources) ? resources : []).map((resource) => ({
      id: resource?.resourceId,
      data: normalizeResourceForTopology(resource),
    }));
  
  /**
   * Optional: if CNMS ever returns edges in the resource payload.
   * Right now it doesn't, so this is a no-op placeholder.
   */
  export const toTopologyEdges = () => [];