/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : TopologyWrapper.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\TopologyWrapper.jsx
   Purpose                  : Created the TopologyWrapper where main topology file gets wrappers to enable the node
   Created Date             : 27-03-2026
 ***********************************************************************************************/

/* eslint-disable no-undef */
// import React, { useState } from "react";
// import { ReactFlowProvider } from "@xyflow/react";
// import Topology from "./Topology";
// import FabricTopology from "../TopologyFabric/FabricTopology";

// export default function TopologyWrapper(props) {
//   const [topologyRenderMode, setTopologyRenderMode] = useState("canvas");

//   if (topologyRenderMode === "svg") {
//     return (
//       <FabricTopology
//         {...props}
//         topologyRenderMode={topologyRenderMode}
//         setTopologyRenderMode={setTopologyRenderMode}
//       />
//     );
//   }

//   return (
//     <ReactFlowProvider>
//       <Topology
//         {...props}
//         topologyRenderMode={topologyRenderMode}
//         setTopologyRenderMode={setTopologyRenderMode}
//       />
//     </ReactFlowProvider>
//   );
// }

import React, { useMemo } from "react";
import { ReactFlowProvider } from "@xyflow/react";
import { useSelector } from "react-redux";
import Topology from "./Topology";
import FabricTopology from "../TopologyFabric/FabricTopology";

export default function TopologyWrapper(props) {
  // 1. Get backend configuration setup via LandingPage login response
  const siteDetails = useSelector((state) => state.nodeDetails.siteDetails);
   const topologyType = siteDetails?.topologyType; // 1 = Fabric, 2 = ReactFlow

  // const topologyType = 1;
  

  // 2. Track whether user wants to see Macro Topology Map (true) or Micro Rack View (false)
  const { currentViewTopology } = useSelector((state) => state.topologySlice);

  // 3. Evaluate engine choice polymorphically
  const activeEngine = useMemo(() => {
    // CRITICAL CLAUSE: If it's a Rack View layout, always route into ReactFlow canvas.
    if (!currentViewTopology) {
      return "reactflow";
    }
    
    // Otherwise, check the global tenant profile layout assigned by the API
    return topologyType === 1 ? "fabric" : "reactflow";
  }, [topologyType, currentViewTopology]);

  // 4. Mount the designated framework engine wrapper
  if (activeEngine === "fabric") {
    return (
      <FabricTopology
        {...props}
        topologyRenderMode="svg"
      />
    );
  }

  return (
    <ReactFlowProvider>
      <Topology
        {...props}
        topologyRenderMode="canvas"
      />
    </ReactFlowProvider>
  );
}

