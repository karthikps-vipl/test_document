/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : NodeViewSwitcher.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\NodeViewSwitcher.jsx
   Purpose                  : Created the NodeViewSwitcher for showing only the topology views and port mapping for show/hide toogle
   Created Date             : 23-03-2026
 ***********************************************************************************************/
import React from "react";
import useTopologyUtilityMethod from "../../../utility/customHooks/useTopologyUtilityMethods";
import {
  Box,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Switch,
  Typography,
} from "@mui/material";
import { useDispatch } from "react-redux";
import { updateSwitchTopology } from "@/store/features/Topology/topologyNodesslice";

const NodeViewSwitcher = ({ currentTabKey, setCurrentTabKey }) => {
  const { handleNodeViewChange } = useTopologyUtilityMethod();

    const dispatch = useDispatch()

  return (
    <Box
      sx={{
        backgroundColor: " background.paper",
        padding: "10px",
        gap: "10px",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box sx={{ padding: "10px", backgroundColor: "background.paper" }}>
        <Typography sx={{color:'text.primary'}}>Topology Views</Typography>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignContent: "center",
            color:'text.primary'
          }}
        >
          <FormControl component="fieldset">
            <RadioGroup
              aria-label="gender"
              name="topoViews"
              value={currentTabKey}
              onChange={(e) => {
                dispatch(updateSwitchTopology(e.target.value))
                setCurrentTabKey(e.target.value);
                handleNodeViewChange(e.target.value);
              }}
            >
              <FormControlLabel
                value="simpleViewNode"
                control={<Radio />}
                label="Simple View"
              />
              <FormControlLabel
                value="imageViewNode"
                control={<Radio />}
                label="Image View"
              />
              <FormControlLabel
                value="CPs"
                control={<Radio />}
                label="CP'S View"
              />
            </RadioGroup>
          </FormControl>
        </Box>
      </Box>
      <Box sx={{ padding: "10px", backgroundColor: "background.paper",color:'text.primary' }}>
        <Typography>Port mapping</Typography>
        <Box className="flex items-center gap-2 px-2">
          Hide
          <Switch styles={{ color: "green" }} />
          Show
        </Box>
      </Box>
    </Box>
  );
};

export default NodeViewSwitcher;
