/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : SettingsModal.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\SettingsModal.jsx
   Purpose                  : Created the SettingsModal for selecting the device on dropdown of the checkbox
   Created Date             : 24-03-2026
 ***********************************************************************************************/

import React, { useState } from 'react';
import { 
  FormGroup, 
  FormControlLabel, 
  Checkbox, 
  Paper, 
  Typography, 
  Divider 
} from '@mui/material';

const DynamicCheckboxForm = () => {
  // Your initial JSON data
  const initialData = {
    resourceName: false,
    resourceIp: true,
    resourceType: true,
    resourceDesc: false,
    maintenanceStatus: false,
    discoveryStatus: false,
    segmentName: true,
    firmwareVersion: true,
    macAddress: true,
    make: true,
    model: true,
  };

  const [formData, setFormData] = useState(initialData);

  // 1. Logic for "Select All" state
  const keys = Object.keys(formData);
  const isAllChecked = keys.every((key) => formData[key]);
  const isIndeterminate = keys.some((key) => formData[key]) && !isAllChecked;

  // 2. Handle Individual Toggle
  const handleCheck = (key) => (event) => {
    setFormData({ ...formData, [key]: event.target.checked });
  };

  // 3. Handle Select All Toggle
  const handleSelectAll = (event) => {
    const { checked } = event.target;
    const updatedData = {};
    keys.forEach((key) => {
      updatedData[key] = checked;
    });
    setFormData(updatedData);
  };

  // Helper to make "camelCase" keys look like "Normal Labels"
  const formatLabel = (str) => 
    str.replace(/([A-Z])/g, ' $1').replace(/^./, (s) => s.toUpperCase());

  return (
    <Paper sx={{ p: 3, maxWidth: 400, mx: 'auto', mt: 4 }}>
      <Typography variant="h6" gutterBottom>
        Resource Settings
      </Typography>

      {/* Select All Checkbox */}
      <FormControlLabel
        label={<strong>Select All</strong>}
        control={
          <Checkbox
            checked={isAllChecked}
            indeterminate={isIndeterminate}
            onChange={handleSelectAll}
            color="primary"
          />
        }
      />
      
      <Divider sx={{ my: 1 }} />

      {/* Dynamically Generated List */}
      <FormGroup>
        {keys.map((key) => (
          <FormControlLabel
            key={key}
            label={formatLabel(key)}
            control={
              <Checkbox
                checked={formData[key]}
                onChange={handleCheck(key)}
              />
            }
          />
        ))}
      </FormGroup>
    </Paper>
  );
};

export default DynamicCheckboxForm;
