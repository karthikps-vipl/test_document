// /***********************************************************************************************
//    Project                  : IAF-NMS
//    SubSystem                : Tooltip
//    File Name                : SettingsForm.jsx
//    Author                   : ARUN - VIPL
//    Package                  : src\Pages\Rnmsdashboard\Topology\Tooltip\SettingsForm.jsx
//    Purpose                  : Created the SettingsForm for saving the topology in redux
//    Created Date             : 20-03-2026
//  ***********************************************************************************************/

// import React, { useState } from "react";
// import {
//   FormGroup,
//   FormControlLabel,
//   Checkbox,
//   Paper,
//   Typography,
//   Divider,
// } from "@mui/material";
// import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import { SAVE_TOOLTIP_OPTIONS } from "@/RestAPI/url/endpoint";
// import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
// import { useDispatch, useSelector } from "react-redux";
// import { setTopologyTooltipOptions } from "@/store/features/Tooltip/toolTipSlice";
// import Toast from "@/components/Reusable/Toast/Toast";

// const SettingsForm = ({ setShowSettingsModal }) => {
//   const { topologyToolTipOptions } = useSelector(
//     (state) => state.toolTipOptionsSlice
//   );
//   const dispatch = useDispatch();

//   // Your initial JSON data

//   const [formData, setFormData] = useState(topologyToolTipOptions);

//   console.log("formDatafff", formData);

//   // 1. Logic for "Select All" state
//   const keys = Object.keys(formData);
//   console.log(keys, "keys");

//   const isAllChecked = keys.every((key) => formData[key]);
//   const isIndeterminate = keys.some((key) => formData[key]) && !isAllChecked;

//   // 2. Handle Individual Toggle
//   const handleCheck = (key) => (event) => {
//     setFormData({ ...formData, [key]: event.target.checked });
//   };

//   // 3. Handle Select All Toggle
//   const handleSelectAll = (event) => {
//     const { checked } = event.target;
//     const updatedData = {};
//     keys.forEach((key) => {
//       updatedData[key] = checked;
//     });
//     setFormData(updatedData);
//   };

//   // Helper to make "camelCase" keys look like "Normal Labels"
//   const formatLabel = (str) =>
//     str.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase());

//   const SaveSettings = async () => {
//     try {
//       const payload = {
//         id: 2,
//         value: JSON.stringify(formData),
//       };
//       const res = await InventoryAxios(SAVE_TOOLTIP_OPTIONS, "post", payload);
//       if (res.status == 200) {
//         dispatch(setTopologyTooltipOptions(formData));
//         Toast("Success", "Settings saved successfully!", "success");
//       } else {
//         Toast("Failed", "Failed to save settings", "error");
//       }
//     } catch (error) {
//       console.error("Error:", error);
//       Toast("Failed", "Failed to save settings", "error");
//     }
//     setShowSettingsModal(null);
//   };

//   return (
//     <Paper sx={{ p: 1, maxHeight: "300px" }}>
//       <Typography variant="h8" gutterBottom>
//         CONFIGURABLE PARAMETERS
//       </Typography>
//       <br />
//       {/* Select All Checkbox */}
//       <FormControlLabel
//         label={<strong>Select All</strong>}
//         control={
//           <Checkbox
//             checked={isAllChecked}
//             indeterminate={isIndeterminate}
//             onChange={handleSelectAll}
//             color="primary"
//           />
//         }
//       />

//       <Divider sx={{ my: 1 }} />

//       {/* Dynamically Generated List */}
//       <FormGroup>
//         {Object.keys(formData)
//           .filter((key) => key !== "selectAll")
//           .map((key) => (
//             <FormControlLabel
//               key={key}
//               label={formatLabel(key)}
//               control={
//                 <Checkbox checked={formData[key]} onChange={handleCheck(key)} />
//               }
//             />
//           ))}
//       </FormGroup>

//       <MButtonPrimary onClick={SaveSettings}>Save</MButtonPrimary>
//     </Paper>
//   );
// };

// export default SettingsForm;

import React, { useState } from "react";
import {
  FormGroup,
  FormControlLabel,
  Checkbox,
  Paper,
  Typography,
  Divider,
  Box,
  useTheme,
} from "@mui/material";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { SAVE_TOOLTIP_OPTIONS } from "@/RestAPI/url/endpoint";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { useDispatch, useSelector } from "react-redux";
import { setTopologyTooltipOptions } from "@/store/features/Tooltip/toolTipSlice";
import Toast from "@/components/Reusable/Toast/Toast";

const SettingsForm = ({ setShowSettingsModal }) => {
  const { topologyToolTipOptions } = useSelector(
    (state) => state.toolTipOptionsSlice
  );
  const dispatch = useDispatch();
  const [formData, setFormData] = useState(topologyToolTipOptions);

  const theme = useTheme();

  const keys = Object.keys(formData);
  const isAllChecked = keys.every((key) => formData[key]);
  const isIndeterminate = keys.some((key) => formData[key]) && !isAllChecked;

  const handleCheck = (key) => (event) => {
    setFormData({ ...formData, [key]: event.target.checked });
  };

  const handleSelectAll = (event) => {
    const { checked } = event.target;
    const updatedData = {};
    keys.forEach((key) => {
      updatedData[key] = checked;
    });
    setFormData(updatedData);
  };

  const formatLabel = (str) =>
    str.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase());

  const SaveSettings = async () => {
    try {
      const payload = {
        id: 2,
        value: JSON.stringify(formData),
      };
      const res = await InventoryAxios(SAVE_TOOLTIP_OPTIONS, "post", payload);
      if (res.status === 200) {
        dispatch(setTopologyTooltipOptions(formData));
        Toast("Success", "Settings saved successfully!", "success");
      } else {
        Toast("Failed", "Failed to save settings", "error");
      }
    } catch (error) {
      console.error("Error:", error);
      Toast("Failed", "Failed to save settings", "error");
    }
    setShowSettingsModal(null);
  };

  return (
    <Paper
      elevation={3}
      sx={{
        display: "flex",
        flexDirection: "column",
        maxHeight: "450px", // Increased for better usability
        width: "100%",
        overflow: "hidden", // Prevents the Paper itself from scrolling
      }}
    >
      {/* HEADER SECTION: Static */}
      <Box sx={{ p: 2}}>
        <Typography
          variant="subtitle1"
          fontWeight="bold"
          sx={{color:theme.palette.mode === "dark" ? "#ffffff" : "#14348d" }}
        >
          CONFIGURABLE PARAMETERS
        </Typography>
      </Box>

      <Divider />

      {/* SCROLLABLE CONTENT SECTION */}
      <Box
        sx={{
          flexGrow: 1, // Takes up available space
          overflowY: "auto", // Enables scrolling ONLY for this section
          p: 1,
          // Custom scrollbar styling for a cleaner look
          "&::-webkit-scrollbar": { width: "6px" },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#ccc",
            borderRadius: "10px",
          },
        }}
      >
        {/* Select All Checkbox */}
        <FormControlLabel
          label={<strong style={{ fontSize: "0.9rem" }}>Select All</strong>}
          control={
            <Checkbox
              checked={isAllChecked}
              indeterminate={isIndeterminate}
              onChange={handleSelectAll}
              color="primary"
              size="small"
            />
          }
        />
        <Divider sx={{ my: 1 }} />

        {/* Dynamically Generated List */}
        <FormGroup>
          {Object.keys(formData)
            .filter((key) => key !== "selectAll")
            .map((key) => (
              <FormControlLabel
                key={key}
                label={
                  <Typography variant="body2">{formatLabel(key)}</Typography>
                }
                control={
                  <Checkbox
                    checked={formData[key]}
                    onChange={handleCheck(key)}
                    size="small"
                  />
                }
                sx={{ mb: -0.5 }} // Tightens spacing between items
              />
            ))}
        </FormGroup>
      </Box>

      <Divider />

      {/* FOOTER SECTION: Static (Always visible) */}
      <Box sx={{ py: 1, px: 2, display: "flex", justifyContent: "flex-end" }}>
        <MButtonPrimary onClick={SaveSettings} sx={{ minWidth: "100px" }}>
          Save
        </MButtonPrimary>
      </Box>
    </Paper>
  );
};

export default SettingsForm;
