/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Tooltip 
   File Name                : NodeTooltip.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\Topology\Tooltip\NodeTooltip.jsx
   Purpose                  : Flat list tooltip with specialized Alarm highlight section
 ***********************************************************************************************/

import React from "react";
import { useSelector } from "react-redux";
import {
  Popper,
  Fade,
  Paper,
  Typography,
  Box,
  Stack,
  Chip,
  Divider,
} from "@mui/material";
import { ErrorOutline } from "@mui/icons-material";

/**
 * BRAND COLORS EXTRACTED FROM SPECIFICATION IMAGE
 */
const BRAND_COLORS = {
  major: "#F08080", // Soft Red/Pink
  minor: "#DFFF00", // Chartreuse/Yellow
  warning: "#40E0D0", // Turquoise/Cyan
};

const FILTER_MAP = {
  // All fields are now treated as a flat list
  resourceName: { label: "Name", path: "data.resourceName" },
  resourceType: { label: "Type", path: "data.imResourceType.resourceTypeName" },
  make: { label: "Make", path: "data.imResourceType.make" },
  model: { label: "Model", path: "data.imResourceType.model" },
  serialNo: { label: "S/N", path: "data.resourceSerialno" },
  resourceIp: { label: "IP Address", path: "data.resourceIp" },
  macAddress: { label: "MAC", path: "data.macAddress" },
  segmentName: { label: "Segment", path: "data.imSegmentInfo.segmentName" },
  firmwareVersion: { label: "Firmware", path: "data.firmwareVersion" },
  maintenanceStatus: { label: "Maintenance", path: "data.isMaintainance" },
  discoveryStatus: { label: "Discovered", path: "data.isDiscovered" },
  resourceDesc: { label: "Description", path: "data.resourceDesc" },

  // Alarms (handled separately in the UI)
  alarmMajor: {
    label: "Major",
    path: "data.nePollingInfo.maxSeverity",
    color: BRAND_COLORS.major,
  },
  alarmMinor: {
    label: "Minor",
    path: "data.nePollingInfo.maxSeverity",
    color: BRAND_COLORS.minor,
  },
  alarmWarning: {
    label: "Warning",
    path: "data.nePollingInfo.maxSeverity",
    color: BRAND_COLORS.warning,
  },
};

const getNestedValue = (obj, path) => {
  return path.split(".").reduce((acc, part) => acc && acc[part], obj);
};

const NodeTooltip = ({
  anchorEl,
  activeNode,
  alarms,
  isLoading,
  container,
}) => {
  const filters = useSelector(
    (state) => state.toolTipOptionsSlice.topologyToolTipOptions
  );
  const badgeCountsArray = useSelector((state) => state.alarmSlice.badgeCount);

  const cnmsBadgeCountsArray = useSelector(
    (state) => state.alarmSlice.cnmsBadgeCount
  );

  const { isCnms } = useSelector((state) => state.nodeDetails);

  console.log("jfnbjalarms", badgeCountsArray);
  console.log("cnmsBadgeCountsArray", cnmsBadgeCountsArray);
  console.log("cnmsactiveNiiiode", activeNode);

  const isOpen = Boolean(anchorEl) && !!activeNode;


  if (!filters) return null;

  // const getAlarmCountForSpecificDevice = (severityType) => {
  //   if (!Array.isArray(badgeCountsArray)) return 0;

  //   const currentDeviceId =
  //     activeNode?.resourceId || activeNode?.data?.resourceId;

  //   const alarmData = badgeCountsArray.find(
  //     (item) => String(item.id) === String(currentDeviceId)
  //   );

  //   return alarmData?.[severityType] ?? 0;
  // };

  const getAlarmCountForSpecificDevice = (severityType) => {

    if (isCnms) {
      if (!Array.isArray(cnmsBadgeCountsArray)) return 0;
  
      const currentSiteId =
        activeNode?.data?.siteId || activeNode?.siteId;
  
      const currentResourceId =
        activeNode?.data?.resourceId || activeNode?.resourceId;
  
      const alarmData = cnmsBadgeCountsArray.find(
        (item) =>
          String(item.siteId) === String(currentSiteId) &&
          String(item.resourceId) === String(currentResourceId)
      );
  
      return alarmData?.[severityType] ?? 0;
    }
  
    // Existing non-CNMS logic
    if (!Array.isArray(badgeCountsArray)) return 0;
  
    const currentDeviceId =
      activeNode?.data?.resourceId || activeNode?.resourceId;
  
    const alarmData = badgeCountsArray.find(
      (item) => String(item.id) === String(currentDeviceId)
    );
  
    return alarmData?.[severityType] ?? 0;
  };
  

  
  const dataRows = [];
  const alarmChips = [];

  Object.entries(filters).forEach(([key, isEnabled]) => {
    const config = FILTER_MAP[key];
    if (isEnabled && config) {
      if (key.startsWith("alarm")) {
        alarmChips.push({ key, config });
      } else {
        dataRows.push({ key, config });
      }
    }
  });

  return (
    <Popper
      open={isOpen}
      anchorEl={anchorEl}
      placement="right-start"
      transition
      sx={{ zIndex: 1300, pointerEvents: "none" }}
      container={container}
    >
      {({ TransitionProps }) => (
        <Fade {...TransitionProps} timeout={200}>
          <Paper
            elevation={10}
            sx={{
              minWidth: 280,
              borderRadius: 2,
              overflow: "hidden",
              border: "1px solid",
              borderColor: "divider",
            }}
          >
            {/* Header */}
            <Box sx={{ bgcolor: "#a7beec", p: 1.5, color: "black" }}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                  {activeNode?.data?.resourceName || "Device Info"}
                </Typography>
              </Stack>
            </Box>

            <Box sx={{ p: 1.5 }}>
              {/* Flat List of Information */}
              <Stack spacing={0.5}>
                {dataRows.map(({ key, config }) => {
                  const val = getNestedValue(activeNode, config.path);
                  const display =
                    typeof val === "boolean"
                      ? val
                        ? "Yes"
                        : "No"
                      : val ?? "—";
                  return (
                    <Box
                      key={key}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        px: 1,
                        py: 0.3,
                      }}
                    >
                      <Typography
                        variant="caption"
                        sx={{ color: "text.secondary", fontWeight: 500 }}
                      >
                        {config.label}
                      </Typography>
                      <Typography
                        variant="caption"
                        sx={{ color: "text.primary", fontWeight: 600 }}
                      >
                        {display}
                      </Typography>
                    </Box>
                  );
                })}
              </Stack>

              {/* Separator only if alarms exist */}
              {alarmChips.length > 0 && (
                <Divider sx={{ my: 1.5, borderStyle: "dashed" }} />
              )}

              {/* Alarm Section (The only unique visual part) */}
              {alarmChips.length > 0 && (
                <Box sx={{ px: 1 }}>
                  <Stack
                    direction="row"
                    alignItems="center"
                    spacing={0.5}
                    sx={{ mb: 1 }}
                  >
                    <ErrorOutline sx={{ fontSize: 14, color: "error.main" }} />
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: 800,
                        color: "error.main",
                        textTransform: "uppercase",
                        letterSpacing: 0.5,
                      }}
                    >
                      Alarms
                    </Typography>
                  </Stack>
                  <Stack direction="row" spacing={1}>
                    {alarmChips.map(({ key, config }) => {
                      const severityType = key
                        .replace("alarm", "")
                        .toLowerCase();
                      const count =
                        getAlarmCountForSpecificDevice(severityType);
                      return (
                        <Chip
                          key={key}
                          label={`${count}`}
                          size="small"
                          sx={{
                            minWidth: 45,
                            justifyContent: "center",
                            fontWeight: 800,
                            fontSize: "0.75rem",
                            bgcolor: count > 0 ? config.color : "grey.100",
                            color: count > 0 ? "#000" : "text.disabled",
                            border: count > 0 ? "none" : "1px solid",
                            borderColor: "grey.300",
                          }}
                        />
                      );
                    })}
                  </Stack>
                </Box>
              )}
            </Box>
          </Paper>
        </Fade>
      )}
    </Popper>
  );
};

export default NodeTooltip;
