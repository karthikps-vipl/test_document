import React, { useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  TextField,
} from "@mui/material";

const DeviceMaintenance = ({ 
  open, 
  onClose, 
  onConfirm, 
  type, // 'addDevice' or 'deleteDevice'
  formData, 
  setFormData 
}) => {
  
  // Reset form when modal opens/closes or type changes
  useEffect(() => {
    if (open) {
      setFormData({ remark: "", deviceName: "" }); // Initialize your form state
    }
  }, [open, type, setFormData]);

  const isDelete = type === "deleteDevice";

  return (
    <Dialog 
      open={open} 
      onClose={onClose} 
      fullWidth 
      maxWidth={isDelete ? "xs" : "sm"}
      PaperProps={{
        sx: {
          borderRadius: "30px",
          overflow: "hidden",
          // width: widthStyle,
          maxWidth: "50vw",
        },
      }}
    >
      <DialogTitle>
        {isDelete ? "Delete Device" : "Add New Device"}
      </DialogTitle>

      <DialogContent>
        <Box sx={{ mt: 1 }}>
          {isDelete ? (
            <>
              {/* <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Are you sure you want to delete <b>{nodeData?.name || "this device"}</b>? 
                This action cannot be undone.
              </Typography> */}
              <TextField
                fullWidth
                label="Reason for deletion (Remark)"
                multiline
                rows={3}
                variant="outlined"
                placeholder="Please provide a reason..."
                value={formData.remark}
                onChange={(e) => setFormData({ ...formData, remark: e.target.value })}
              />
            </>
          ) : (
            <>
              {/* <Typography variant="body2" sx={{ mb: 2 }}>
                Adding a device to: <b>{nodeData?.name || "this location"}</b>
              </Typography> */}
              {/* Example Add Device Fields */}
              <TextField
                fullWidth
                label="Device Name"
                margin="dense"
                value={formData.deviceName}
                onChange={(e) => setFormData({ ...formData, deviceName: e.target.value })}
              />
              <TextField
                fullWidth
                label="Device ID"
                margin="dense"
              />
            </>
          )}
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} color="inherit">
          Cancel
        </Button>
        <Button
          onClick={() => onConfirm(formData)}
          variant="primary"
          color={isDelete ? "error" : "primary"}
          disabled={isDelete ? !formData.remark.trim() : !formData.deviceName.trim()}
        >
          {isDelete ? "Yes, Delete" : "Add Device"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeviceMaintenance;