/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : AlarmDrawer
   File Name                : AlarmDrawer.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\AlarmDrawer\AlarmDrawer.jsx
   Purpose                  : The purpose is to show Dashboard Tabs to navigate between topology, Fault and port status. 
   Created Date             : 08-01-2026
 *******************************************************************************************/
import AlarmSummaryDisableicon from "../../../assets/SVGIcons/AlarmSummaryDisableicon.svg";
import TopologyEnableIcon from "../../../assets/SVGIcons/TopologyEnableIcon.svg";
import Topologydisableicon from "../../../assets/SVGIcons/Topologydisableicon.svg";
import PortStatusDisableIcon from "../../../assets/SVGIcons/PortStatusDisableIcon.svg";

import BirdEyeViewInactive from "../../../assets/CNMS/BirdEyeViewInactive.svg";
import BirdEyeViewactivetab from "../../../assets/CNMS/BirdEyeViewactivetab.svg";
import mapViewInactive from "../../../assets/CNMS/Map_Disable.svg";
import siteSummaryInactive from "../../../assets/CNMS/Site_Summary_Disable.svg";
import mapViewactivetab from "../../../assets/CNMS/Map_View_Enable.svg";
import alarmCnmsactive from "../../../assets/CNMS/Alarm_Summary_Enable.svg";

import alarmCnmsInactivetab from "../../../assets/CNMS/Alarm_Summary_Disable.svg";

import AlarmSummaryEnableIcon from "../../../assets/SVGIcons/AlarmSummaryEnableIcon.svg";

import PortStatusEnableIcon from "../../../assets/SVGIcons/PortStatusEnableIcon.svg";

import { Tabs } from "antd";
import { Box, Tooltip, Typography, useTheme } from "@mui/material";
import { useSelector } from "react-redux";

const DashboardTabs = ({ activeTabKey, setActiveTabKey }) => {
  const theme = useTheme();

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const renderTabLabel = (key, label, iconEnable, iconDisable) => {
    // Check if this specific tab is the active one
    const isActive = activeTabKey === key;

    return (
      <Tooltip
        title={label}
        placement="top"
        arrow={false}
        overlayInnerStyle={{ backgroundColor: "#808080" }}
      >
        <Box
          className={`flex w-33 items-center justify-center py-5   gap-1 transition-all duration-200 `}
          style={{
            // 1. Handle Background Color
            backgroundColor: isActive
              ? theme.palette.mode === "dark"
                ? "#ffffff"
                : "#E9EFFF"
              : "transparent",

            // 2. Handle Text Color
            color: isActive
              ? theme.palette.mode === "dark"
                ? "#14138d"
                : "#1e3a8a"
              : theme.palette.text.primary,
          }}
        >
          <img
            src={isActive ? iconEnable : iconDisable}
            alt={label}
            className="object-contain"
            style={{
              filter:
                !isActive && theme.palette.mode === "dark"
                  ? "brightness(1.5)"
                  : "none",
            }}
          />

          <Typography
            style={{
              fontSize: "11px",
              // MOVE FONT WEIGHT HERE
              fontWeight: isActive ? "bold" : "normal",
              // IMPORTANT: Also move color here if Typography is overriding it
              color: isActive
                ? theme.palette.mode === "dark"
                  ? "#14138d"
                  : "#1e3a8a"
                : theme.palette.text.primary,
            }}
            className="uppercase"
          >
            {label}
          </Typography>
        </Box>
      </Tooltip>
    );
  };

  const cnmsItems = [
    {
      key: "mapView",
      label: renderTabLabel(
        "mapView",
        "Map",
        mapViewactivetab,
        mapViewInactive,
      ),
    },
    {
      key: "siteSummary",
      label: renderTabLabel(
        "siteSummary",
        "Site summary",
        siteSummaryInactive,
        siteSummaryInactive
      ),
    },
    {
      key: "birdEyeView",
      label: renderTabLabel(
        "birdEyeView",
        "Bird eye view",
        BirdEyeViewactivetab,
        BirdEyeViewInactive
      ),
    },
    {
      key: "alarmSummaryCnms",
      label: renderTabLabel(
        "alarmSummaryCnms",
        "Alarm summary",
        alarmCnmsactive,
        alarmCnmsInactivetab
      ),
    },
  ];

  const rnmsItems = [
    {
      key: "topology",
      label: renderTabLabel(
        "topology",
        "Topology",
        TopologyEnableIcon,
        Topologydisableicon
      ),
    },
    {
      key: "faults",
      label: renderTabLabel(
        "faults",
        "Alarm Summary",
        AlarmSummaryEnableIcon,
        AlarmSummaryDisableicon
      ),
    },
    {
      key: "performance",
      label: renderTabLabel(
        "performance",
        "Port Status",
        PortStatusEnableIcon,
        PortStatusDisableIcon
      ),
    },
  ];

  return (
    <Box
      sx={{
        // This pulls directly from your CustomThemeProvider
        backgroundColor: theme.palette.background.tabs,
        color: theme.palette.text.tabcolor,
        // borderBottom: `1px solid ${theme.palette.divider}`, // Optional: adds a separator
      }}
    >
      <Tabs
        animated={false}
        activeKey={activeTabKey}
        onChange={(key) => setActiveTabKey(key)}
        items={isCnms ? cnmsItems : rnmsItems}
        className="custom-dashboard-tabs"
      />
      <style jsx global>{`
        .custom-dashboard-tabs .ant-tabs-nav {
          margin: 0 !important;
          padding: 0 !important;
        }
        .custom-dashboard-tabs .ant-tabs-tab {
          padding: 0 !important;
          margin: 0 !important;
          // border: 1px solid ${theme.palette.divider} !important;
        }
        .custom-dashboard-tabs .ant-tabs-ink-bar {
          background: #14348d !important;
        }
      `}</style>
    </Box>
  );
};

export default DashboardTabs;
