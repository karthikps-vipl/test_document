import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_CPE_MANAGED_GROUPS_CNMS,
  FETCH_CPE_SECTION,
  FETCH_CPE_SECTION_AT_CNMS,
  GET_NETWORK_SEGMENTS,
  GET_NETWORK_SEGMENTS_CNMS,
  GETCH_CPE_MANAGED_GROUPS,

} from "@/RestAPI/url/endpoint";

// Common API response handler
const extractApiData = (response) => {
  const result = response?.data;

  if (result?.status === 0 || result?.wrongCredential === 1) {
    throw new Error(
      result?.message || "Unable to fetch Gilat data."
    );
  }

  return result?.data ?? {};
};

// RF Cluster API
export const fetchNetworkSegments = async (
  resourceId,
  isCnms = false
) => {
  const endpoint = isCnms
    ? GET_NETWORK_SEGMENTS_CNMS
    : GET_NETWORK_SEGMENTS;

  const response = await ConfigurationAxios(
    `${endpoint}/${encodeURIComponent(resourceId)}`,
    "get"
  );

  return extractApiData(response);
};

// CPE Group API
export const fetchCPEManagedGroups = async (resourceId, isCnms = false) => {
  // Determine the endpoint based on isCnms
  const endpoint = isCnms ? FETCH_CPE_MANAGED_GROUPS_CNMS : GETCH_CPE_MANAGED_GROUPS;

  const response = await ConfigurationAxios(
    `${endpoint}/${encodeURIComponent(resourceId)}`,
    "get"
  );

  return extractApiData(response);
};

// CPE Section API
export const fetchCPESection = async (resourceId, isCnms = false) => {
  // Determine the endpoint based on isCnms
  const endpoint = isCnms ? FETCH_CPE_SECTION_AT_CNMS : FETCH_CPE_SECTION;

  const response = await ConfigurationAxios(
    `${endpoint}/${encodeURIComponent(resourceId)}`,
    "get"
  );

  return extractApiData(response);
};
