import React, { useState, useEffect } from "react";

import { Box, CircularProgress, Typography } from "@mui/material";

import { useSelector } from "react-redux";

import tableJson from "./config/totalNms.json";

import GilatSummary from "./components/GilatSummary";
import GilatDynamicContent from "./components/GilatDynamicContent";

import MForm from "@/components/Reusable/Form/MForm";

import {
  fetchNetworkSegments,
  fetchCPEManagedGroups,
  fetchCPESection,
} from "./hooks/gilatApi";

import {
  transformGilatRfCluster,
  transformGilatCpeGroup,
  transformGilatCpeSection,
} from "./utils/gilatDataMapper";

const GilatSatcomModuleStatus = ({
  resourceId,
  showGilatSatcomModule,
  setShowGilatSatcomModule,
  resourceInfoCnms,
}) => {
  const mainTabs = Object.keys(tableJson);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const [activeMainTab, setActiveMainTab] = useState(mainTabs[0]);

  const [totalNmsData, setTotalNmsData] = useState({});

  const [loading, setLoading] = useState(false);

  const [error, setError] = useState("");

  // ---------------------------------------------
  // FETCH DATA BASED ON MAIN TAB
  // ---------------------------------------------

  useEffect(() => {
    if (!resourceId) {
      return;
    }

    let isMounted = true;

    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");

        let responseData = {};

        switch (activeMainTab) {
          // -------------------------------------
          // RF CLUSTER
          // -------------------------------------

          case "RF Cluster": {
            responseData = await fetchNetworkSegments(resourceId, isCnms);

            if (!isMounted) return;

            const transformedData = transformGilatRfCluster(
              responseData?.rfClusterList
            );

            setTotalNmsData((prev) => ({
              ...prev,

              rfClusterData: transformedData,

              aggregateBandwidth: responseData?.aggregateBandwidth ?? 0,

              totalCPECount:
                responseData?.TotalCPECount ?? responseData?.totalCPECount ?? 0,

              onlineCPECount: responseData?.onlineCPECount ?? 0,

              onlineCPEPercentage: responseData?.onlineCPEPercentage ?? 0,

              readingTime: responseData?.readingTime ?? null,
            }));

            break;
          }

          // -------------------------------------
          // MODULATOR - DEMODULATOR
          // -------------------------------------

          case "Modulator-Demodulator": {
            // API integration pending.
            // Keep the configured tabs visible.

            break;
          }

          // -------------------------------------
          // CPE GROUP
          // -------------------------------------

          case "CPE Group": {
            responseData = await fetchCPEManagedGroups(resourceId);

            if (!isMounted) return;

            const transformedData = transformGilatCpeGroup(
              responseData?.cpeGroup
            );

            setTotalNmsData((prev) => ({
              ...prev,

              cpeGroupData: transformedData,

              aggregateBandwidth: responseData?.aggregateBandwidth ?? 0,

              totalCPECount:
                responseData?.TotalCPECount ?? responseData?.totalCPECount ?? 0,

              onlineCPECount: responseData?.onlineCPECount ?? 0,

              onlineCPEPercentage: responseData?.onlineCPEPercentage ?? 0,

              readingTime: responseData?.readingTime ?? null,
            }));

            break;
          }

          // -------------------------------------
          // CPE SECTION
          // -------------------------------------

          case "CPE Section": {
            responseData = await fetchCPESection(resourceId);

            if (!isMounted) return;

            const transformedData = transformGilatCpeSection(
              responseData?.cpeSectionList
            );

            setTotalNmsData((prev) => ({
              ...prev,

              cpeSectionData: transformedData,

              aggregateBandwidth: responseData?.aggregateBandwidth ?? 0,

              totalCPECount:
                responseData?.TotalCPECount ?? responseData?.totalCPECount ?? 0,

              onlineCPECount: responseData?.onlineCPECount ?? 0,

              onlineCPEPercentage: responseData?.onlineCPEPercentage ?? 0,

              readingTime: responseData?.readingTime ?? null,
            }));

            break;
          }

          default:
            break;
        }
      } catch (err) {
        console.error(`Error fetching ${activeMainTab}:`, err);

        if (isMounted) {
          setError(
            err?.response?.data?.message ||
              err?.message ||
              `Unable to fetch ${activeMainTab} data.`
          );
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [activeMainTab, resourceId, isCnms]);

  // ---------------------------------------------
  // SELECTED CONFIGURATION
  // ---------------------------------------------

  const activeConfig = tableJson[activeMainTab];

  // ---------------------------------------------
  // SELECTED DATA
  // ---------------------------------------------

  const activeData = (() => {
    switch (activeMainTab) {
      case "RF Cluster":
        return totalNmsData?.rfClusterData ?? {};

      case "Modulator-Demodulator":
        return {};

      case "CPE Group":
        return totalNmsData?.cpeGroupData ?? {};

      case "CPE Section":
        return totalNmsData?.cpeSectionData ?? [];

      default:
        return {};
    }
  })();

  // ---------------------------------------------
  // MAIN TAB CHANGE
  // ---------------------------------------------

  const handleMainTabChange = (tab) => {
    if (tab !== activeMainTab) {
      setActiveMainTab(tab);
    }
  };

  // ---------------------------------------------
  // RENDER
  // ---------------------------------------------

  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        overflow: "auto",
        p: 2,
      }}
    >
      {/* MAIN TABS */}

      <Box
        sx={{
          width: "100%",
          overflowX: "auto",
          overflowY: "hidden",

          backgroundColor: (theme) =>
            theme.palette.custom?.rightUtilityDrawer?.tabsbg ??
            theme.palette.background.paper,

          borderRadius: "30px",
          p: 1,
          mb: 2,

          "&::-webkit-scrollbar": {
            display: "none",
          },

          scrollbarWidth: "none",
        }}
      >
        <Box
          sx={{
            display: "flex",
            width: "max-content",
            minWidth: "100%",
            gap: 1,
          }}
        >
          {mainTabs.map((tab) => {
            const isActive = activeMainTab === tab;

            return (
              <Box
                key={tab}
                component="button"
                onClick={() => handleMainTabChange(tab)}
                sx={{
                  border: 0,
                  cursor: "pointer",
                  px: 2.5,
                  py: 1.2,
                  borderRadius: "25px",
                  whiteSpace: "nowrap",
                  fontSize: "12px",
                  fontWeight: 600,
                  fontFamily: "Montserrat",

                  backgroundColor: isActive ? "#14348D" : "transparent",

                  color: isActive ? "#fff" : "text.primary",

                  "&:hover": {
                    backgroundColor: isActive ? "#14348D" : "action.hover",
                  },
                }}
              >
                {tab.toUpperCase()}
              </Box>
            );
          })}
        </Box>
      </Box>

      {/* SUMMARY */}

      <GilatSummary totalNmsData={totalNmsData} />

      {/* INFRASTRUCTURE */}

      <MForm title="Infrastructure" paddingX={2}>
        {loading ? (
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              minHeight: "200px",
            }}
          >
            <CircularProgress size={28} />
          </Box>
        ) : (
          <GilatDynamicContent
            key={activeMainTab}
            config={activeConfig}
            data={activeData}
            title={activeMainTab}
          />
        )}
      </MForm>
    </Box>
  );
};

export default React.memo(GilatSatcomModuleStatus);
