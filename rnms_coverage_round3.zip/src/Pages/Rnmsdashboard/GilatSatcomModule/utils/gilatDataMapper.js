const normalizeRows = (value) => {
    if (Array.isArray(value)) {
      return value;
    }
  
    if (value && typeof value === "object") {
      return [value];
    }
  
    return [];
  };
  
  // ---------------------------------------------
  // RF CLUSTER
  // ---------------------------------------------
  
  export const transformGilatRfCluster = (rfClusterList = []) => {
    if (!Array.isArray(rfClusterList)) {
      return {};
    }
  
    const result = {};
  
    rfClusterList.forEach((cluster, clusterIndex) => {
      const clusterCode =
        cluster?.rfClusterCode ??
        cluster?.rfClusterClode ??
        `Unknown-${clusterIndex + 1}`;
  
      const clusterKey = `Cluster Code-${clusterCode}`;
  
      result[clusterKey] = {};
  
      const networkSegments = Array.isArray(
        cluster?.networkSegmentList
      )
        ? cluster.networkSegmentList
        : [];
  
      networkSegments.forEach((segment, index) => {
        const nsId = segment?.nsID ?? index + 1;
  
        const nsKey = `NS-${nsId}`;
  
        result[clusterKey][nsKey] = {
          General: normalizeRows(segment?.general),
  
          "Forward Link Section": normalizeRows(
            segment?.fwdLink
          ),
  
          "Return Link Section": normalizeRows(
            segment?.returnLink
          ),
  
          "Return Channel Section": normalizeRows(
            segment?.channelList
          ),
  
          "IP Connectivity Section": normalizeRows(
            segment?.ipConnectivity
          ),
        };
      });
    });
  
    return result;
  };
  
  // ---------------------------------------------
  // CPE GROUP
  // ---------------------------------------------
  
  export const transformGilatCpeGroup = (cpeGroup) => {
    const group = cpeGroup || {};
  
    const slaTable = group?.slaTable || {};
  
    return {
      "Managed Group": normalizeRows(
        group?.managedCPEGroup
      ),
  
      "SLA Profile": {
        General: normalizeRows(slaTable?.generalTable),
  
        "Forward Table": normalizeRows(
          slaTable?.forwardTable
        ),
  
        "Return Table": normalizeRows(
          slaTable?.returnTable
        ),
      },
    };
  };
  
  // ---------------------------------------------
  // CPE SECTION
  // ---------------------------------------------
  
  export const transformGilatCpeSection = (cpeSectionList) => {
    return normalizeRows(cpeSectionList);
  };
  