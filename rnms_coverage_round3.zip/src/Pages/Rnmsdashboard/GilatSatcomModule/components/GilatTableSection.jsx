import React from "react";
import { Box } from "@mui/material";
import MTable from "@/components/Reusable/Table/MTable";

const GilatTableSection = ({
  title,
  columns = [],
  data = [],
}) => {
  const tableColumns = Array.isArray(columns)
    ? columns.map((item) => ({
        name: item.title,
        uid: item.field,
      }))
    : [];

  const tableData = Array.isArray(data) ? data : [];

  return (
    <Box sx={{ width: "100%", mb: 1 }}>
      {/* {title && (
        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: 600,
            mb: 1.5,
            fontFamily: "Montserrat",
            color: "text.primary",
          }}
        >
          {title}
        </Typography>
      )} */}

      <MTable
        tableTitle={title || ""}
        columns={tableColumns}
        tableData={tableData}
        showSearch={true}
        showPagination={true}
        showMaximazed={false}
        closeIcon={false}
        typeHeight ="hubTable"
      />
    </Box>
  );
};

export default GilatTableSection;