import React, { useState, useEffect, } from "react";
import { Box, Tabs, Tab, Typography } from "@mui/material";

import GilatTableSection from "./GilatTableSection";

const GilatDynamicContent = ({ config, data, title = "" }) => {
  const [selectedTab, setSelectedTab] = useState(0);

  useEffect(() => {
    setSelectedTab(0);
  }, [config, data]);

  // CASE 1: Direct table
  if (Array.isArray(config)) {
    return (
      <GilatTableSection
        title={title}
        columns={config}
        data={Array.isArray(data) ? data : []}
      />
    );
  }

  const configKeys = Object.keys(config || {});
  const dataKeys = Object.keys(data || {});

  // No configuration
  if (!configKeys.length) {
    return (
      <Typography sx={{ p: 2, color: "text.secondary" }}>
        No configuration available.
      </Typography>
    );
  }

  // CASE 2: Multiple tables at the same level.
  // Example:
  // General: []
  // Forward Link Section: []
  // Return Link Section: []

  const isTableCollection = configKeys.every((key) =>
    Array.isArray(config[key])
  );

  if (isTableCollection) {
    return (
      <Box sx={{ width: "100%" }}>
        {configKeys.map((key) => (
          <GilatTableSection
            key={key}
            title={key}
            columns={config[key]}
            data={Array.isArray(data?.[key]) ? data[key] : []}
          />
        ))}
      </Box>
    );
  }

  // CASE 3: Resolve static or dynamic tabs.

  const isDynamicKey =
    configKeys.length === 1 && !dataKeys.includes(configKeys[0]);

  const actualKeys = isDynamicKey ? dataKeys : configKeys;

  // if (!actualKeys.length) {
  //   return (
  //     <Typography sx={{ p: 2, color: "text.secondary" }}>
  //       No data available.
  //     </Typography>
  //   );
  // }

  const safeSelectedTab = selectedTab >= actualKeys.length ? 0 : selectedTab;

  const activeKey = actualKeys[safeSelectedTab];

  const configKey = isDynamicKey ? configKeys[0] : activeKey;

  const activeConfig = config?.[configKey];
  const activeData = data?.[activeKey];

  // CASE 4: Nested rendering.
  // This recursively handles Cluster Code, NS,
  // IPM-1, MCR-1, SLA Profile, etc.

  return (
    <Box sx={{ width: "100%" }}>
      <Box
        sx={{
          width: "100%",
          overflowX: "auto",
          overflowY: "hidden",
          "&::-webkit-scrollbar": {
            display: "none",
          },
          scrollbarWidth: "none",
        }}
      >
        <Tabs
          value={safeSelectedTab}
          onChange={(event, newValue) => {
            setSelectedTab(newValue);
          }}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
          className="custom-tabs"
          sx={{
            minHeight: "42px",
            "& .MuiTab-root": {
              minHeight: "42px",
              fontSize: "12px",
              fontWeight: 600,
              fontFamily: "Montserrat",
              textTransform: "uppercase",
            },
          }}
        >
          {actualKeys.map((key) => (
            <Tab key={key} label={key.toUpperCase()} />
          ))}
        </Tabs>
      </Box>

      <Box sx={{ pt: 1 }}>
        {/* {activeConfig ? ( */}
          <GilatDynamicContent
            config={activeConfig}
            data={activeData}
            title={activeKey}
          />
        {/* ) : (
          <Typography sx={{ p: 2, color: "text.secondary" }}>
            No configuration available.
          </Typography>
        )} */}
      </Box>
    </Box>
  );
};

export default GilatDynamicContent;
