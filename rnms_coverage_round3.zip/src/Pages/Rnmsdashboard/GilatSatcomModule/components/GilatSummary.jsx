import React from "react";
import { Box, Grid, Typography } from "@mui/material";
import moment from "moment";

const GilatSummary = ({ totalNmsData = {} }) => {
  const readingTime = totalNmsData?.readingTime;

  const summaryItems = [
    {
      label: "Aggregate Bandwidth Parameter",
      value: totalNmsData?.aggregateBandwidth ?? "-",
    },
    {
      label: "CPEs (Online/Total)",
      value: `${totalNmsData?.onlineCPECount ?? 0}/${
        totalNmsData?.totalCPECount ?? 0
      } (${totalNmsData?.onlineCPEPercentage ?? 0}%)`,
    },
    {
      label: "Last Received Date",
      value: readingTime
        ? moment(readingTime).format("DD-MM-YYYY HH:mm:ss")
        : "-",
    },
  ];

  return (
    <Grid spacing={2} sx={{ mb: 1, display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:2 }} >
      {summaryItems.map((item) => (
        <Grid item xs={12} sm={4} key={item.label}>
          <Box
            sx={{
              border: "1px solid",
              borderColor: "divider",
              borderRadius: "8px",
              p: 2,
              height: "100%",
              backgroundColor: "background.paper",
            }}
          >
            <Typography
              sx={{
                fontSize: "12px",
                color: "text.secondary",
                fontFamily: "Montserrat",
                mb: 1,
              }}
            >
              {item.label}
            </Typography>

            <Typography
              sx={{
                fontSize: "15px",
                fontWeight: 700,
                fontFamily: "Montserrat",
              }}
            >
              {item.value}
            </Typography>
          </Box>
        </Grid>
      ))}
    </Grid>
  );
};

export default GilatSummary;