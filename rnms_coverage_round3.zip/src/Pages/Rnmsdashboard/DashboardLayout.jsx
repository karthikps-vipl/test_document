/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : DashboardLayout.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\DashboardLayout.jsx
   Purpose                  : Created the DashboardLayout where all the components get rendered by layout thr dashboard
   Created Date             : 31-03-2026
 ***********************************************************************************************/

import React, { useEffect, useRef, useState } from "react";
import SidebarTree from "./SidebarTree/TreeSidebar";
import RightUtilityDrawer from "./RightUtilityDrawer/RightUtilityDrawer";
import AlarmDrawer from "./AlarmDrawer/AlarmDrawer";

import SecondHeader from "../../components/shared/SecondHeader/SecondHeader";
import { useDispatch, useSelector } from "react-redux";
import TopologyWrapper from "./Topology/TopologyWrapper";
import Fault from "./FAult/AlarmDashboardLayout";
import UseDataFetchingComponent from "./FAult/components/FetchAlarmData";
import PortStatus from "./PortStatus";
import {
  clearUpdateAlarm,
  updateSingleAlarm,
} from "@/store/features/Fault/alarmSlice";
// import { Box, useTheme } from "@mui/material";
import {
  Box,
  useTheme,
  Dialog,
  DialogTitle,
  DialogContent,
  Typography,
  Divider,
} from "@mui/material";

import CnmsMap from "../CnmsDashboard/CnmsMap/CnmsMap";
import Toast from "@/components/Reusable/Toast/Toast";
import MajorSound from "../../assets/audio/MAJOR.wav";
import MinorSound from "../../assets/audio/MINOR.wav";
import WarningSound from "../../assets/audio/WARNING.wav";
import SiteSummaryDashboard from "../CnmsDashboard/CnmsSiteSummary/SiteSummaryDashboard";
import BirdEyeView from "../CnmsDashboard/BirdEyeView/BirdEyeView";
import AlarmDashboardCNMS from "../CnmsDashboard/CnmsAlarmSummary/AlarmDashboardCNMS";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import GlobalCnmsAlarmNotifications from "../CnmsDashboard/CnmsAlarmSummary/GlobalCnmsAlarmNotifications";
import MModal from "@/components/Reusable/Modal/MModal";
import Securitysettings from "./RightUtilityDrawer/components/Security/SecuritySettings";
import ChangePasswordModal from "@/components/Topbar/ChangePasswordModal";
import useLogout from "@/utility/customHooks/useLogout";
import { CertAxios } from "@/RestAPI/api/axiosApicall";
import { GET_ALL_CERTIFICATE_EXPIRE_COUNT } from "@/RestAPI/url/cnmsEndPoint";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MTable from "@/components/Reusable/Table/MTable";
import { CancelOutlined, CheckCircleOutline } from "@mui/icons-material";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import SessionLogoutModal from "../auth/Logout/SessionLogoutModal";
import LogoutDialog from "./LogoutDialog";


const DashboardLayout = ({ handleClose }) => {
  const theme = useTheme();
  const { leftSidebarVisible } = useSelector((state) => state.leftSidebarSlice);
  const [certificateList, setCertificateList] = useState([]);
  const [certificateSummary, setCertificateSummary] = useState({
    certficateExpiredCount: 0,
    certifcateAboutExpireNext30DaysCount: 0
  });

  const [bottomOpen, setBottomOpen] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);
  const { isCnms } = useSelector((state) => state.nodeDetails);
  // const [activeTabKey, setActiveTabKey] = useState("topology");


  const [showLogoutModalWhenCnmsDown, setShowLogoutModalWhenCnmsDown] =
    useState(false);
  const [activeViewKey, setActiveViewKey] = useState(
    isCnms ? "mapView" : "topology"
  );
  const dispatch = useDispatch();
  const { fetchData } = UseDataFetchingComponent();
  const updatedAlarmData = useSelector(
    (state) => state.alarmSlice.updateAlaram
  );
  const { healthStatus, cnmsLinkAvailable } = useSelector(
    (state) => state.cnmsStatus
  );
 

  console.log("cnmsLinkAvailable",cnmsLinkAvailable)
  const wasCnmsPreviouslyUp = useRef(false);
  const loginLinkAvailability = useRef(null);
  

 
  const { userDetails } = useSelector((state) => state.userSlice);
  console.log("userDetails", userDetails.data);
  const [showDefaultPasswordModal, setShowDefaultPasswordModal] =
    useState(false);
  const [showCertificateModal, setshowCertificateModal] = useState(false)
  // const [certificateData, setCertificateData] = useState(null);
  const [showCertificateDetailModal, setShowCertificateDetailModal] = useState(false);


  const { siteDetails } = useSelector(
    (state) => state.nodeDetails
  );
  const formatDate = (dateString) => {
    if (!dateString || dateString === "N/A" || isNaN(new Date(dateString).getTime())) {
      return "—";
    }

    const date = new Date(dateString);

    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const min = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');

    return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
  };
  const fetchCertificateStatus = async () => {
    if (!isCnms) return;
    try {
      let payload = { terminal: siteDetails?.terminalTypeName };
      const response = await CertAxios(GET_ALL_CERTIFICATE_EXPIRE_COUNT, "post", payload);
      const data = response.data; // Assuming this object contains both counts and the list

      // 2. Handle the counts (Assuming data.counts or similar exists, 
      // or that 'data' is the summary and 'data.list' is the array)
      // ADJUST THIS based on your actual API response structure:
      setCertificateSummary({
        certficateExpiredCount: data.certficateExpiredCount || 0,
        certifcateAboutExpireNext30DaysCount: data.certifcateAboutExpireNext30DaysCount || 0
      });

      if (data.certificateList && Array.isArray(data.certificateList)) {
        const processedList = data.certificateList.map((item, index) => ({
          ...item,
          sno: index + 1,

        }));
        setCertificateList(processedList);
      }
      if (isCnms && (data.certficateExpiredCount > 0 || data.certifcateAboutExpireNext30DaysCount > 0)) {
        setshowCertificateModal(true);
      }
    } catch (error) {
      console.error("Error fetching certificate status:", error);
    }
  };
  useEffect(() => {
    fetchCertificateStatus();
  }, []);
  useEffect(() => {
    if (userDetails?.data?.defaultPassword === true) {
      setShowDefaultPasswordModal(true);
    } else {
      setShowDefaultPasswordModal(false);
    }
  }, [userDetails?.data?.defaultPassword]);

  const isEmailUpdateRequired = useSelector(
    (state) => state.userSlice.isEmailUpdateRequired
  );
  console.log(
    "DEBUG: isEmailUpdateRequired value:",
    isEmailUpdateRequired,
    "Type:",
    typeof isEmailUpdateRequired
  );
  const [showModal, setShowModal] = useState(false);
  useEffect(() => {
    // If the flag is true, open the modal
    if (isEmailUpdateRequired) {
      setShowModal(true);
    }
  }, [isEmailUpdateRequired]);

  console.log("activeViewKeycnms", activeViewKey);

  const [isBirdEyeDialogOpen, setIsBirdEyeDialogOpen] = useState(false);

  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  const alarmNotificationSettings = useSelector(
    (state) => state.alarmSlice.alarmNotificationSettings
  );
  // useEffect(() => {
  //   if (updatedAlarmData) {
  //     dispatch(updateSingleAlarm(updatedAlarmData));

  //     console.log(updatedAlarmData, "dededsdazcbfgdf");

  //     const types = { 0: "info", 1: "warning", 2: "error" };
  //     const selectedType = types[updatedAlarmData.severity] || "NA";
  //     if (updatedAlarmData.severity !== -1) {
  //       Toast(
  //         updatedAlarmData.resourceName + "-" + updatedAlarmData.segmentName,
  //         <>
  //           {updatedAlarmData.alarmName}
  //           <br />
  //           {updatedAlarmData.alarmDescription}
  //         </>,

  //         // updatedAlarmData.alarmDescription,
  //         selectedType
  //       );
  //     }
  //   }
  // }, [updatedAlarmData, dispatch]);
  // const ALARM_SOUNDS = {
  //   2: MajorSound,
  //   1: MinorSound,
  //   0: WarningSound,
  // };
  const ALARM_SOUNDS = {
    "MAJOR.wav": MajorSound,
    "MINOR.wav": MinorSound,
    "WARNING.wav": WarningSound,
  };

  const playAlarmSound = (audioFileName) => {
    const sound = ALARM_SOUNDS[audioFileName];

    if (!sound) {
      console.warn("Sound not found:", audioFileName);
      return;
    }

    const audio = new Audio(sound);

    audio.play().catch((error) => {
      console.warn("Unable to play alarm sound:", error);
    });
  };

  const processedAlarmRef = useRef(null);

  const alarmSettingsRef = useRef(alarmNotificationSettings);

  useEffect(() => {
    alarmSettingsRef.current = alarmNotificationSettings;
  }, [alarmNotificationSettings]);
  useEffect(() => {
    if (!updatedAlarmData) {
      return;
    }

    const severity = Number(updatedAlarmData.severity);

    // Ignore cleared/invalid alarm
    if (severity === -1) {
      dispatch(clearUpdateAlarm());
      return;
    }

    // Create a unique ID for this alarm event.
    // If your backend has alarmId/id, that will be used.
    const alarmEventId =
      updatedAlarmData.alarmId ??
      updatedAlarmData.id ??
      `${updatedAlarmData.resourceId}-${updatedAlarmData.alarmName}-${updatedAlarmData.resourceIp
      }-${updatedAlarmData.timestamp ?? updatedAlarmData.alarmTime ?? ""}`;

    // Prevent the same alarm event from being processed twice
    if (processedAlarmRef.current === alarmEventId) {
      console.log("Duplicate alarm ignored:", alarmEventId);
      return;
    }

    processedAlarmRef.current = alarmEventId;

    console.log("Processing NEW alarm:", updatedAlarmData);

    // ==================================================
    // 1. ALWAYS STORE ALARM
    // ==================================================

    dispatch(updateSingleAlarm(updatedAlarmData));

    // ==================================================
    // 2. GET LATEST NOTIFICATION SETTINGS
    // ==================================================

    const settings = alarmSettingsRef.current?.[severity];

    if (!settings) {
      console.warn(
        "Alarm notification settings are not loaded yet for severity:",
        severity
      );

      // Consume the event
      dispatch(clearUpdateAlarm());
      return;
    }

    // ==================================================
    // 3. POPUP
    // ==================================================

    if (settings.isPopup) {
      const types = {
        0: "info",
        1: "warning",
        2: "error",
      };

      const selectedType = types[severity] || "info";

      Toast(
        `${updatedAlarmData.resourceName}-${updatedAlarmData.segmentName}`,
        <>
          {updatedAlarmData.alarmName}
          <br />
          {updatedAlarmData.alarmDescription}
        </>,
        selectedType
      );
    }

    // ==================================================
    // 4. SOUND
    // ==================================================

    if (settings.isMute) {
      console.log("Alarm sound is MUTED for severity:", severity);
    } else {
      console.log("Playing alarm sound:", settings.audioFileName);

      playAlarmSound(settings.audioFileName);
    }

    // ==================================================
    // 5. CONSUME THE EVENT
    // ==================================================

    dispatch(clearUpdateAlarm());
  }, [updatedAlarmData, dispatch]);

  useEffect(() => {
    fetchData();
  }, []);

  // useEffect(() => {
  //   if (updatedAlarmData) {
  //     console.log("Global Listener: Updating Alarm Data for Badge & Charts");
  //     dispatch(updateSingleAlarm(updatedAlarmData));
  //   }
  // }, [updatedAlarmData, dispatch]);

  // Handle dashboard view selection
  const handleViewChange = (viewKey) => {
    if (viewKey === "birdEyeView") {
      // Keep the underlying dashboard on Map View
      setActiveViewKey("mapView");
      setIsBirdEyeDialogOpen(true);
      return;
    }

    setActiveViewKey(viewKey);
  };

  // Close BirdEyeView and return to Map View
  const handleCloseBirdEyeDialog = () => {
    setIsBirdEyeDialogOpen(false);
    setActiveViewKey("mapView");
  };
  const { logoutHandler } = useLogout();
  const handleCloseModaals = () => {
    setshowCertificateModal(false)


  }
  const handleCloseViewModaals = () => {

    setShowCertificateDetailModal(false);

  }

  const handleViewCertificates = () => {
    setShowCertificateDetailModal(true);
  }
  const cnmsColumns = [
    { name: "S. No", uid: "sno", width: "72px" },
    { name: "Terminal", uid: "terminal", width: "150px" },

    { name: "Site ID", uid: "siteId", width: "160px" },
    { name: "Days to Expiry", uid: "daysToExpiry", width: "150px" },

    {
      name: "Certificate Validity",
      uid: "validityStatus",
      width: "220px",
      render: (cellValue, row) => {
        const data = row || cellValue;

        // 1. ENHANCED CHECK: 
        // We check if data exists, AND if certexpirydate exists, 
        // AND if it's not just an empty string or "N/A"
        if (!data || !data.certexpirydate || data.certexpirydate === "N/A" || data.certexpirydate === "") {
          return (
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Typography sx={{ color: "text.secondary" }}>—</Typography>
            </Box>
          );
        }

        const expiryDate = new Date(data.certexpirydate);
        const today = new Date();

        // 2. ADDITIONAL SAFETY:
        // If the date string is invalid (e.g., "undefined" or a broken string), 
        // expiryDate.getTime() will be NaN.
        const isInvalidDate = isNaN(expiryDate.getTime());

        // If it's an invalid date, show the dash instead of "Valid"
        if (isInvalidDate) {
          return (
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Typography >---</Typography>
            </Box>
          );
        }

        const isExpired = expiryDate < today;

        return (
          <Box sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 1
          }}>
            {isExpired ? (
              <>
                <CancelOutlined sx={{ color: "error.main", fontSize: "28px" }} />
                <Typography sx={{ color: "error.main", fontWeight: 'medium' }}>
                  Expired
                </Typography>
              </>
            ) : (
              <>
                <CheckCircleOutline sx={{ color: "success.main", fontSize: "28px" }} />
                <Typography sx={{ color: "success.main", fontWeight: 'medium' }}>
                  Valid
                </Typography>
              </>
            )}
          </Box>
        );
      }
    },
    { name: "MAC/IP Address", uid: "commonName", width: "170px" },

    {
      name: "Certificate Issue Date",
      uid: "certissuedate",
      width: "200px",
      render: (value) => <Typography variant="body2">{formatDate(value)}</Typography>
    },

    // UPDATED: Certificate Expiry Date
    {
      name: "Certificate Expiry Date",
      uid: "certexpirydate",
      width: "220px",
      render: (value) => <Typography variant="body2">{formatDate(value)}</Typography>
    },






  ];
  useEffect(() => {
    // Never show modal if CNMS mode OR link is unavailable
    if (isCnms || cnmsLinkAvailable !== true) {
      return;
    }
  
    const status = Number(healthStatus);
  
    // Wait for initial UP status
    if (!wasCnmsPreviouslyUp.current) {
      if (status === 1) {
        wasCnmsPreviouslyUp.current = true;
      }
      return;
    }
  
    // Show modal only after UP changes to DOWN or OPERATIONALLY DOWN
    if (status === 0 || status === 2) {
      setShowLogoutModalWhenCnmsDown(true);
    }
  }, [isCnms, cnmsLinkAvailable, healthStatus]);
  


  return (
    <Box className="flex flex-col h-full w-full bg-slate-50 overflow-hidden">
      <GlobalCnmsAlarmNotifications />
      {/* 1. HEADER */}
      <Box className="bg-[#F3F3F3] flex items-center">
        {/* <SecondHeader
          activeViewKey={activeViewKey}
          setActiveViewKey={setActiveViewKey}
          /> */}
        <SecondHeader
          activeViewKey={activeViewKey}
          setActiveViewKey={handleViewChange}
        />
      </Box>
      {/* BODY WRAPPER */}
      <Box
        sx={{
          height: "100vh",
          width: "100vw",
          display: "flex",
          overflow: "hidden",
        }}
      >
        <aside
          className={`transition-all  duration-300 flex flex-col z-30 shrink-0 ${leftSidebarVisible ? "w-0 overflow-hidden" : "w-[276px]"
            }`}
          style={{ height: "100%" }}
          sx={{ background: theme.palette.background.tabs }}
        >
          <SidebarTree />
        </aside>

        {/* MAIN CONTENT AREA (This occupies the full remaining width) */}
        <Box className="flex-1 flex flex-col relative overflow-hidden">
          {/* <main className="flex-1 min-h-0 relative overflow-hidden"> */}
          <main
            className={`flex-1 min-h-0 relative ${activeViewKey === "siteSummary"
              ? "overflow-y-auto"
              : "overflow-hidden"
              }`}
          >
            {activeViewKey === "topology" && (
              <TopologyWrapper setSelectedNode={setSelectedNode} />
            )}
            {activeViewKey === "faults" && <Fault />}
            {activeViewKey === "performance" && <PortStatus />}

            {activeViewKey === "mapView" && <CnmsMap />}
            {activeViewKey === "siteSummary" && <SiteSummaryDashboard />}
            {/* {activeViewKey === "birdEyeView" && <BirdEyeView />} */}
            {activeViewKey === "alarmSummaryCnms" && <AlarmDashboardCNMS />}
          </main>

          <Box
            className="shrink-0 z-40"
            sx={{ background: (theme) => theme.palette.background.paper }}
          >
            <AlarmDrawer
              activeTabKey={activeViewKey}
              isOpen={bottomOpen}
              onToggle={() => setBottomOpen(!bottomOpen)}
            />
          </Box>
        </Box>

        {/* RIGHT RAIL - THE FLOATING HOVER RAIL */}
        {/* RIGHT RAIL CONTAINER */}
        <Box
          id="right-rail-container"
          className="relative h-full shrink-0 z-50"
          // This also works in newer MUI versions:
          sx={{
            width: "80px", // Keep the container footprint tiny
            pointerEvents: "none", // IMPORTANT: Allows clicks to pass through the empty space
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <Box sx={{ pointerEvents: "auto" }}>
            <RightUtilityDrawer selectedNode={selectedNode} />{" "}
          </Box>
        </Box>
      </Box>

      <Dialog
        open={isBirdEyeDialogOpen}
        onClose={handleCloseBirdEyeDialog}
        fullWidth
        fullScreen={isMaximized}
        maxWidth="2xl"
        aria-labelledby="bird-eye-dialog-title"
        PaperProps={{
          sx: {
            height: isMaximized ? "100vh" : "92vh",
            // maxHeight: "92vh",
            borderRadius: "14px",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            boxShadow: "0 24px 80px rgba(15, 23, 42, 0.25)",
          },
        }}
      >
        {/* Dialog Header */}
        <DialogTitle
          id="bird-eye-dialog-title"
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 3,
            py: 1.5,
            borderBottom: "1px solid #e5eaee",
            // backgroundColor: "#ffffff",
            flexShrink: 0,
          }}
        >
          <Typography
            sx={{
              fontSize: "18px",
              fontWeight: 700,
              color: "#1a7f9e",
            }}
          >
            Bird's Eye View
          </Typography>
          <CustomeFullscreen
            onClose={handleCloseBirdEyeDialog}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </DialogTitle>

        {/* Dialog Body */}
        <DialogContent
          sx={{
            p: 0,
            overflow: "hidden",
            flex: 1,
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            // backgroundColor: "#f8fafc",
          }}
        >
          {isBirdEyeDialogOpen && <BirdEyeView />}
        </DialogContent>
      </Dialog>

      {showModal && isCnms && (
        <MModal
          open={showModal}
          title="Update Recovery Email"
          enableFullScreen
          info="Please Enter Valid Email Address"
          showCloseButton={false}
          customWidth="800px"
          fullWidth
        >
          <Securitysettings
            isChildFullScreen={true}
            onSuccess={() => {
              console.log("Email updated successfully!");
              setShowModal(false);
            }}
          />
        </MModal>
      )}

      {showDefaultPasswordModal && (
        <ChangePasswordModal
          open={showDefaultPasswordModal}
          onClose={() => setShowDefaultPasswordModal(false)}
          userDetails={userDetails?.data}
          defaultPassword={true}
          showCloseButton={false}
          handleLogout={logoutHandler}
        />
      )}
      {showCertificateModal && isCnms && (
        <MModal
          open={showCertificateModal}
          title="X.509 Certificate Details"
          enableFullScreen

          handleClose={handleCloseModaals}
          customWidth="500px"
        >
          <Box sx={{ p: 1, border: "2px solid #eee", borderRadius: "10px" }}>

            <Box sx={{ p: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center', }}>
              <Typography  >Expired Certificates</Typography>
              <Typography sx={{ fontWeight: 700, }}>
                {certificateSummary?.certficateExpiredCount || 0}
              </Typography>
            </Box>

            <Divider />

            <Box sx={{ p: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography >Expiring within 30 days</Typography>
              <Typography variant="body1" sx={{ fontWeight: 700, }}>
                {certificateSummary?.certifcateAboutExpireNext30DaysCount}
              </Typography>
            </Box>


            <Divider />
            <Box sx={{ display: "flex", gap: 2, justifyContent: 'flex-end', mt: 3 }}>
              <MButtonSecondary onClick={handleCloseModaals} >
                Cancel
              </MButtonSecondary>
              <MButtonPrimary onClick={handleViewCertificates}>
                View
              </MButtonPrimary>
            </Box>
          </Box>
        </MModal>
      )}
      {showCertificateDetailModal && (
        <MModal
          open={showCertificateDetailModal}
          title="X.509 Certificate Details"
          enableFullScreen
          handleClose={handleCloseViewModaals}
          customWidth="900px" // Optional: Adjust width based on your component
        >
          <MTable
            columns={cnmsColumns}
            tableData={certificateList}
            showSearch={true}
            showPagination
            tableTitle="Certificates"
          />
        </MModal>
      )}
         <SessionLogoutModal/>
      {!isCnms && (
        <LogoutDialog
          open={showLogoutModalWhenCnmsDown}
        />
      )}

    </Box>
  );
};

export default DashboardLayout;
