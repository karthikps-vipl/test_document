import React, { useEffect, useRef, useState } from "react";

import {
  Box,
  Typography,
  Avatar,
  IconButton,
  TextField,
  CircularProgress,
  Divider,
  Tooltip,
  Chip,
} from "@mui/material";

import SendIcon from "@mui/icons-material/Send";
import CloseIcon from "@mui/icons-material/Close";
import ClearIcon from "@mui/icons-material/DeleteSweep";
import SmartToyOutlinedIcon from "@mui/icons-material/SmartToyOutlined";
import PersonOutlineOutlinedIcon from "@mui/icons-material/PersonOutlineOutlined";
import StorageOutlinedIcon from "@mui/icons-material/StorageOutlined";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";

import { NmsChatBotAxios } from "@/RestAPI/api/axiosApicall";

import {
  NMS_CHATBOT_DB_QUERY,
  NMS_CHATBOT_QUERY,
} from "@/RestAPI/url/endpoint";

import chatbotsvg from "@/assets/SVGIcons/nms_chat_bot.svg";

const NMSChatBot = ({ isChatBotOpen, setIsChatBotOpen, isDrawerOpen }) => {
  // ==========================================================
  // CHAT STATE
  // ==========================================================

  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hello! 👋 How can I help you today?",
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      type: "received",
    },
  ]);

  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // ==========================================================
  // DATABASE MODE STATE
  // ==========================================================
  // This state controls which API is called
  const [dbConnected, setDbConnected] = useState(false);

  // ==========================================================
  // REF
  // ==========================================================
  const messagesEndRef = useRef(null);

  // ==========================================================
  // SCROLL
  // ==========================================================
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  };

  useEffect(() => {
    if (isChatBotOpen) {
      scrollToBottom();
    }
  }, [messages, isChatBotOpen, isLoading]);

  // ==========================================================
  // TIME
  // ==========================================================
  const getCurrentTime = () => {
    return new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // ==========================================================
  // TOGGLE DB MODE
  // ==========================================================
  const handleToggleDbMode = () => {
    setDbConnected((prev) => !prev);
  };

  // ==========================================================
  // CHAT API
  // ==========================================================
  const callChatbotAPI = async (message) => {
    const payload = {
      query: message,
      use_documents: true,
      use_database: dbConnected, // Pass true if DB mode is selected
      top_k_retrieval: 12,
      top_k_rerank: 5,
    };

    // LOGIC: If dbConnected is true, use NMS_CHATBOT_DB_QUERY, otherwise use NMS_CHATBOT_QUERY
    const endpoint = dbConnected ? NMS_CHATBOT_DB_QUERY : NMS_CHATBOT_QUERY;

    const response = await NmsChatBotAxios(
      endpoint,
      "post",
      payload
    );

    return response;
  };

  // ==========================================================
  // SEND MESSAGE
  // ==========================================================
  const handleSendMessage = async () => {
    const trimmedMessage = inputValue.trim();

    if (!trimmedMessage || isLoading) {
      return;
    }

    const userMessage = {
      id: Date.now(),
      text: trimmedMessage,
      time: getCurrentTime(),
      type: "sent",
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    try {
      const response = await callChatbotAPI(trimmedMessage);
      const data = response?.data;

      const botText =
        data?.answer ||
        data?.response ||
        data?.message ||
        "Sorry, I couldn't find an answer.";

      let sourceText = botText;

      // Add source info if available
      const databaseRows = data?.database?.rows || [];
      const documentsUsed = data?.documents?.count || 0;

      if (databaseRows.length > 0 || documentsUsed > 0) {
        sourceText += "\n\n";
        if (databaseRows.length > 0) {
          sourceText += `📊 NMS DB: ${databaseRows.length} record(s)`;
        }
        if (documentsUsed > 0) {
          if (databaseRows.length > 0) sourceText += "  •  ";
          sourceText += `📄 Documents: ${documentsUsed} source(s)`;
        }
      }

      const botMessage = {
        id: Date.now() + 1,
        text: sourceText,
        time: getCurrentTime(),
        type: "received",
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Chatbot API Error:", error);
      const errorText =
        error?.response?.data?.detail ||
        "Sorry, something went wrong. Please try again.";

      const errorMessage = {
        id: Date.now() + 1,
        text: errorText,
        time: getCurrentTime(),
        type: "received",
        isError: true,
      };

      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  // ==========================================================
  // DRAWER POSITION
  // ==========================================================
  const baseBottomPosition = isDrawerOpen ? "240px" : "1px";
  const windowBottomPosition = isDrawerOpen ? "300px" : "50px";

  return (
    <>
      {/* FLOATING CHAT BUTTON */}
      <Box
        onClick={() => setIsChatBotOpen(!isChatBotOpen)}
        sx={{
          position: "fixed",
          right: "5%",
          bottom: baseBottomPosition,
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: "linear-gradient(135deg, #14348D 0%, #2563EB 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          boxShadow: "0 8px 25px rgba(20, 52, 141, 0.35)",
          zIndex: 1400,
          transition: "bottom 0.5s ease-in-out, transform 0.2s ease",
          "&:hover": { transform: "scale(1.08)" },
        }}
      >
        <img src={chatbotsvg} alt="chat" style={{ width: "25px", height: "25px" }} />
      </Box>

      {/* CHAT WINDOW */}
      {isChatBotOpen && (
        <Box
          sx={{
            position: "fixed",
            bottom: windowBottomPosition,
            right: "5%",
            width: { xs: "calc(100vw - 24px)", sm: "380px" },
            maxWidth: "380px",
            height: { xs: "calc(100vh - 100px)", sm: "540px" },
            maxHeight: "540px",
            backgroundColor: "#F7F9FC",
            borderRadius: "20px",
            display: "flex",
            flexDirection: "column",
            boxShadow: "0 20px 60px rgba(0, 0, 0, 0.20)",
            border: "1px solid #E5EAF2",
            overflow: "hidden",
            zIndex: 9999,
            transition: "bottom 0.5s ease-in-out",
          }}
        >
          {/* HEADER */}
          <Box
            sx={{
              px: 2,
              py: 1.5,
              background: "linear-gradient(135deg, #14348D 0%, #1D4ED8 100%)",
              color: "white",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.3 }}>
              <Box sx={{ position: "relative" }}>
                <Avatar sx={{ width: 40, height: 40, backgroundColor: "white", color: "#14348D" }}>
                  <SmartToyOutlinedIcon />
                </Avatar>
                <Box
                  sx={{
                    position: "absolute",
                    bottom: 0,
                    right: 0,
                    width: 11,
                    height: 11,
                    backgroundColor: "#22C55E",
                    border: "2px solid white",
                    borderRadius: "50%",
                  }}
                />
              </Box>
              <Box>
                <Typography sx={{ fontSize: "15px", fontWeight: 700 }}>NMS ChatBot</Typography>
                <Typography sx={{ fontSize: "11px", opacity: 0.85 }}>
                  {dbConnected ? "DB Mode Active" : "Document Mode"}
                </Typography>
              </Box>
            </Box>

            <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
              <Tooltip title="Clear Chat">
                <IconButton
                  onClick={() => setMessages([{ id: 1, text: "Hello! 👋 How can I help you today?", time: getCurrentTime(), type: "received" }])}
                  sx={{ color: "white" }}
                >
                  <ClearIcon fontSize="small" />
                </IconButton>
              </Tooltip>

              {/* SELECTION BUTTON FOR DB MODE */}
              <Tooltip title={dbConnected ? "Switch to Document Query" : "Switch to Database Query"} placement="bottom">
                <IconButton
                  onClick={handleToggleDbMode}
                  sx={{
                    color: "white",
                    backgroundColor: dbConnected ? "rgba(34,197,94,0.3)" : "rgba(255,255,255,0.1)",
                    "&:hover": { backgroundColor: "rgba(255,255,255,0.2)" },
                  }}
                >
                  {dbConnected ? <CheckCircleOutlineIcon fontSize="small" /> : <StorageOutlinedIcon fontSize="small" />}
                </IconButton>
              </Tooltip>

              <IconButton onClick={() => setIsChatBotOpen(false)} sx={{ color: "white" }}>
                <CloseIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>

          {/* DB STATUS BAR */}
          {dbConnected && (
            <Box sx={{ px: 1.5, py: 0.7, backgroundColor: "#ECFDF5", borderBottom: "1px solid #D1FAE5" }}>
              <Chip
                size="small"
                icon={<CheckCircleOutlineIcon />}
                label="NMS Database Query Mode"
                sx={{ color: "#047857", backgroundColor: "#D1FAE5", fontSize: "10px" }}
              />
            </Box>
          )}

          {/* MESSAGES AREA */}
          <Box
            sx={{
              flex: 1,
              p: 2,
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
              gap: 1.5,
              backgroundColor: "#F7F9FC",
              "&::-webkit-scrollbar": { width: "5px" },
              "&::-webkit-scrollbar-thumb": { backgroundColor: "#CBD5E1", borderRadius: "10px" },
            }}
          >
            {messages.map((message) => {
              const isUser = message.type === "sent";
              return (
                <Box
                  key={message.id}
                  sx={{
                    display: "flex",
                    alignItems: "flex-end",
                    justifyContent: isUser ? "flex-end" : "flex-start",
                    gap: 0.8,
                  }}
                >
                  {!isUser && (
                    <Avatar sx={{ width: 28, height: 28, backgroundColor: "#E8EEFF", color: "#14348D" }}>
                      <SmartToyOutlinedIcon sx={{ fontSize: 17 }} />
                    </Avatar>
                  )}
                  <Box
                    sx={{
                      maxWidth: "80%",
                      px: 1.7,
                      py: 1.2,
                      borderRadius: isUser ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                      backgroundColor: isUser ? "#14348D" : message.isError ? "#FEF2F2" : "white",
                      color: isUser ? "white" : message.isError ? "#B91C1C" : "#1E293B",
                      boxShadow: isUser ? "0 3px 8px rgba(20,52,141,0.18)" : "0 2px 7px rgba(0,0,0,0.06)",
                      border: !isUser ? "1px solid #E8EDF3" : "none",
                      wordBreak: "break-word",
                    }}
                  >
                    <Typography sx={{ fontSize: "13px", lineHeight: 1.5, whiteSpace: "pre-wrap" }}>
                      {message.text}
                    </Typography>
                    <Typography sx={{ fontSize: "9px", mt: 0.6, textAlign: "right", opacity: 0.6 }}>
                      {message.time}
                    </Typography>
                  </Box>
                  {isUser && (
                    <Avatar sx={{ width: 28, height: 28, backgroundColor: "#E2E8F0", color: "#475569" }}>
                      <PersonOutlineOutlinedIcon sx={{ fontSize: 17 }} />
                    </Avatar>
                  )}
                </Box>
              );
            })}

            {isLoading && (
              <Box sx={{ display: "flex", alignItems: "flex-end", gap: 0.8 }}>
                <Avatar sx={{ width: 28, height: 28, backgroundColor: "#E8EEFF", color: "#14348D" }}>
                  <SmartToyOutlinedIcon sx={{ fontSize: 17 }} />
                </Avatar>
                <Box sx={{ backgroundColor: "white", border: "1px solid #E8EDF3", borderRadius: "16px 16px 16px 4px", px: 1.8, py: 1.2, display: "flex", alignItems: "center", gap: 0.8 }}>
                  <CircularProgress size={13} thickness={5} sx={{ color: "#14348D" }} />
                  <Typography sx={{ fontSize: "11px", color: "#64748B" }}>
                    {dbConnected ? "Querying NMS Database..." : "Searching documents..."}
                  </Typography>
                </Box>
              </Box>
            )}
            <div ref={messagesEndRef} />
          </Box>

          <Divider />

          {/* INPUT AREA */}
          <Box sx={{ p: 1.5, backgroundColor: "white" }}>
            <TextField
              fullWidth
              multiline
              maxRows={3}
              placeholder={dbConnected ? "Ask about NMS data..." : "Ask about your documents..."}
              variant="outlined"
              value={inputValue}
              onChange={(e) => e.target.value.length <= 500 && setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              sx={{
                "& .MuiOutlinedInput-root": {
                  borderRadius: "16px",
                  backgroundColor: "#F8FAFC",
                  pr: 0.5,
                  "& fieldset": { borderColor: "#E2E8F0" },
                  "&:hover fieldset": { borderColor: "#14348D" },
                  "&.Mui-focused fieldset": { borderColor: "#14348D" },
                },
                "& .MuiInputBase-input": { fontSize: "13px" },
              }}
              InputProps={{
                endAdornment: (
                  <IconButton
                    onClick={handleSendMessage}
                    disabled={!inputValue.trim() || isLoading}
                    sx={{
                      width: 38,
                      height: 38,
                      color: "white",
                      backgroundColor: inputValue.trim() && !isLoading ? "#14348D" : "#CBD5E1",
                    }}
                  >
                    {isLoading ? <CircularProgress size={17} sx={{ color: "white" }} /> : <SendIcon sx={{ fontSize: 18 }} />}
                  </IconButton>
                ),
              }}
            />
            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 0.5, px: 0.5 }}>
              <Typography sx={{ fontSize: "9px", color: inputValue.length >= 450 ? "#DC2626" : "#94A3B8" }}>
                {inputValue.length}/500
              </Typography>
            </Box>
          </Box>
        </Box>
      )}
    </>
  );
};

export default NMSChatBot;