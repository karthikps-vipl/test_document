// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   TextField,
//   IconButton,
//   InputAdornment,
//   Divider,
//   Tooltip,
// } from "@mui/material";

// import CloseIcon from "@mui/icons-material/Close";
// import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
// import SearchIcon from "@mui/icons-material/Search";
// import SendIcon from "@mui/icons-material/Send";
// import CampaignIcon from "@mui/icons-material/Campaign";
// import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";

// const CnmsChat = ({ isChatOpen, setIsChatOpen,isDrawerOpen }) => {
//   const [searchSite, setSearchSite] = useState("");
//   const [selectedSite, setSelectedSite] = useState("Broadcast");
//   const [message, setMessage] = useState("");

//   // Temporary site data - API integration later
//   const [sites] = useState([
//     { id: 1, name: "Bangalore", lastMessage: "Welcome to Bangalore chat" },
//     { id: 2, name: "Aurangabad", lastMessage: "Site conversation" },
//     { id: 3, name: "Bilaspur", lastMessage: "Site conversation" },
//     { id: 4, name: "Chennai", lastMessage: "Site conversation" },
//     { id: 5, name: "Delhi", lastMessage: "Site conversation" },
//   ]);

//   // Temporary messages - WebSocket integration later
//   const [messages, setMessages] = useState([]);

//   const filteredSites = sites.filter((site) =>
//     site.name.toLowerCase().includes(searchSite.toLowerCase())
//   );

//   const handleSendMessage = () => {
//     if (!message.trim()) return;

//     const newMessage = {
//       id: Date.now(),
//       text: message.trim(),
//       sender: "You",
//       time: new Date().toLocaleTimeString([], {
//         hour: "2-digit",
//         minute: "2-digit",
//       }),
//     };

//     setMessages((prev) => [...prev, newMessage]);
//     setMessage("");
//   };

//   if (!isChatOpen) return null;

//   const windowBottomPosition = isDrawerOpen ? "300px" : "50px";

//   return (
//     <Box
//       sx={{
//         position: "fixed",
//         bottom: windowBottomPosition,
//         right: 125,
//         width: { xs: "95%", sm: 350, md: 550 },
//         height: { xs: "40vh", md: 400 },
//         maxHeight: "calc(100vh - 40px)",
//         backgroundColor: "#fff",
//         borderRadius: "12px",
//         boxShadow: "0px 5px 30px rgba(0,0,0,0.25)",
//         zIndex: 1500,
//         display: "flex",
//         flexDirection: "column",
//         overflow: "hidden",
//         fontFamily: "Arial, sans-serif",
//       }}
//     >
//       {/* HEADER */}
//       <Box
//         sx={{
//           height: 55,
//           minHeight: 55,
//           backgroundColor: "#14348D",
//           color: "#fff",
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "space-between",
//           px: 2,
//         }}
//       >
//         <Typography fontSize={18} fontWeight={600}>
//           CnmsChat
//         </Typography>

//         <Box display="flex" alignItems="center">
//           <Tooltip title="Notifications">
//             <IconButton sx={{ color: "#fff" }}>
//               <NotificationsNoneIcon />
//             </IconButton>
//           </Tooltip>

//           <Tooltip title="Close Chat">
//             <IconButton
//               onClick={() => setIsChatOpen(false)}
//               sx={{ color: "#fff" }}
//             >
//               <CloseIcon />
//             </IconButton>
//           </Tooltip>
//         </Box>
//       </Box>

//       {/* CHAT BODY */}
//       <Box
//         sx={{
//           display: "flex",
//           flex: 1,
//           minHeight: 0,
//           overflow: "hidden",
//         }}
//       >
//         {/* LEFT SIDEBAR */}
//         <Box
//           sx={{
//             width: { xs: "38%", sm: 260 },
//             minWidth: 0,
//             borderRight: "1px solid #e0e0e0",
//             display: "flex",
//             flexDirection: "column",
//             backgroundColor: "#f8f9fc",
//           }}
//         >
//           {/* SEARCH */}
//           <Box sx={{ p: 1.5 }}>
//             <TextField
//               fullWidth
//               size="small"
//               placeholder="Search Site..."
//               value={searchSite}
//               onChange={(e) => setSearchSite(e.target.value)}
//               InputProps={{
//                 startAdornment: (
//                   <InputAdornment position="start">
//                     <SearchIcon fontSize="small" />
//                   </InputAdornment>
//                 ),
//               }}
//               sx={{
//                 "& .MuiOutlinedInput-root": {
//                   borderRadius: "8px",
//                   backgroundColor: "#fff",
//                 },
//               }}
//             />
//           </Box>

//           <Divider />

//           {/* BROADCAST */}
//           <Box
//             onClick={() => setSelectedSite("Broadcast")}
//             sx={{
//               mx: 1,
//               my: 1,
//               p: 1.5,
//               borderRadius: "8px",
//               cursor: "pointer",
//               display: "flex",
//               alignItems: "center",
//               gap: 1.5,
//               backgroundColor:
//                 selectedSite === "Broadcast" ? "#E4EAFF" : "#fff",
//               border:
//                 selectedSite === "Broadcast"
//                   ? "1px solid #14348D"
//                   : "1px solid #e5e5e5",
//               "&:hover": { backgroundColor: "#E4EAFF" },
//             }}
//           >
//             <CampaignIcon sx={{ color: "#14348D" }} />
//             <Typography fontWeight={600} fontSize={13}>
//               Broadcast
//             </Typography>
//           </Box>

//           <Divider />

//           {/* SITE LIST */}
//           <Box sx={{ flex: 1, overflowY: "auto", p: 1 }}>
//             {filteredSites.map((site) => (
//               <Box
//                 key={site.id}
//                 onClick={() => setSelectedSite(site.name)}
//                 sx={{
//                   p: 1,
//                   mb: 1,
//                   borderRadius: "8px",
//                   cursor: "pointer",
//                   backgroundColor:
//                     selectedSite === site.name ? "#E4EAFF" : "#fff",
//                   border:
//                     selectedSite === site.name
//                       ? "1px solid #14348D"
//                       : "1px solid #eee",
//                   "&:hover": { backgroundColor: "#EAF0FF" },
//                 }}
//               >
//                 <Box display="flex" alignItems="center" gap={1}>
//                   <ChatBubbleOutlineIcon
//                     sx={{ color: "#14348D", fontSize: 16 }}
//                   />
//                   <Typography fontSize={12} fontWeight={600}>
//                     {site.name}
//                   </Typography>
//                 </Box>

//                 <Typography
//                   fontSize={11}
//                   color="text.secondary"
//                   sx={{ mt: 0.5, ml: 3 }}
//                   noWrap
//                 >
//                   {site.lastMessage}
//                 </Typography>
//               </Box>
//             ))}

//             {filteredSites.length === 0 && (
//               <Typography
//                 textAlign="center"
//                 color="text.secondary"
//                 fontSize={13}
//                 sx={{ mt: 3 }}
//               >
//                 No sites found
//               </Typography>
//             )}
//           </Box>
//         </Box>

//         {/* RIGHT CHAT PANEL */}
//         <Box
//           sx={{
//             flex: 1,
//             minWidth: 0,
//             display: "flex",
//             flexDirection: "column",
//             backgroundColor: "#fff",
//           }}
//         >
//           {/* CHAT TITLE */}
//           <Box
//             sx={{
//               p: 2,
//               borderBottom: "1px solid #eee",
//               minHeight: 55,
//               display: "flex",
//               alignItems: "center",
//             }}
//           >
//             <Typography fontWeight={600} fontSize={15}>
//               {selectedSite}
//             </Typography>
//           </Box>

//           {/* MESSAGE DISPLAY */}
//           <Box
//             sx={{
//               flex: 1,
//               overflowY: "auto",
//               p: 2,
//               display: "flex",
//               flexDirection: "column",
//               gap: 1.5,
//               backgroundColor: "#FAFBFE",
//             }}
//           >
//             {messages.length === 0 ? (
//               <Box
//                 sx={{
//                   flex: 1,
//                   display: "flex",
//                   alignItems: "center",
//                   justifyContent: "center",
//                   flexDirection: "column",
//                   color: "#9CA3AF",
//                 }}
//               >
//                 <ChatBubbleOutlineIcon sx={{ fontSize: 45, mb: 1 }} />

//                 <Typography fontSize={14}>
//                   No messages yet
//                 </Typography>

//                 <Typography fontSize={12}>
//                   Start a conversation
//                 </Typography>
//               </Box>
//             ) : (
//               messages.map((msg) => (
//                 <Box
//                   key={msg.id}
//                   sx={{
//                     alignSelf: "flex-end",
//                     maxWidth: "75%",
//                     backgroundColor: "#E4EAFF",
//                     borderRadius: "10px 10px 0 10px",
//                     p: 1.5,
//                   }}
//                 >
//                   <Typography fontSize={13}>
//                     {msg.text}
//                   </Typography>

//                   <Typography
//                     fontSize={10}
//                     color="text.secondary"
//                     textAlign="right"
//                     sx={{ mt: 0.5 }}
//                   >
//                     {msg.time}
//                   </Typography>
//                 </Box>
//               ))
//             )}
//           </Box>

//           {/* MESSAGE INPUT */}
//           <Box
//             sx={{
//               p: 1.5,
//               borderTop: "1px solid #eee",
//               display: "flex",
//               alignItems: "center",
//               gap: 1,
//               backgroundColor: "#fff",
//             }}
//           >
//             <TextField
//               fullWidth
//               size="small"
//               placeholder="Type Message..."
//               value={message}
//               onChange={(e) => setMessage(e.target.value.slice(0, 140))}
//               onKeyDown={(e) => {
//                 if (e.key === "Enter" && !e.shiftKey) {
//                   e.preventDefault();
//                   handleSendMessage();
//                 }
//               }}
//               inputProps={{ maxLength: 140 }}
//               sx={{
//                 "& .MuiOutlinedInput-root": {
//                   borderRadius: "20px",
//                 },
//               }}
//             />

//             <Typography
//               fontSize={11}
//               color="text.secondary"
//               sx={{ whiteSpace: "nowrap" }}
//             >
//               {message.length}/140
//             </Typography>

//             <IconButton
//               onClick={handleSendMessage}
//               disabled={!message.trim()}
//               sx={{
//                 backgroundColor: "#14348D",
//                 color: "#fff",
//                 "&:hover": { backgroundColor: "#0D266C" },
//                 "&.Mui-disabled": {
//                   backgroundColor: "#ccc",
//                   color: "#fff",
//                 },
//               }}
//             >
//               <SendIcon fontSize="small" />
//             </IconButton>
//           </Box>
//         </Box>
//       </Box>
//     </Box>
//   );
// };

// export default CnmsChat;

import React, { useEffect, useMemo, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";

import ChatIcon from "@mui/icons-material/Chat";
import Badge from "@mui/material/Badge";

import {
  configureChat,
  setActiveChat,
  resetUnread,
  setTypingStatus,
  setChatOpen,
} from "@/store/features/Chats/chatSlice";

import VerticalTabs from "./VerticalTabs";
import "./chatStyles.css";
import moment from "moment";
import Toast from "@/components/Reusable/Toast/Toast";
import WarningSound from "@/assets/audio/WARNING.wav";

const PUBLIC_TOPIC = "/topic/public";
const ACK_DESTINATION = "/app/sendMessage";

const CnmsChat = ({ isCnms, siteDetails, sites = [], isDrawerOpen }) => {
  const dispatch = useDispatch();

  const {
    conversations,
    active,
    unread,
    notificationEnabled,
    typing,
    selfName,
    chatOpen,
    chatBackendURL,
  } = useSelector((state) => state.chat);

  const previousMessages = useRef({});

  const currentSite = Array.isArray(siteDetails) ? siteDetails[0] : siteDetails;

  const currentSelfName = useMemo(() => {
    if (!currentSite) return "";

    return `${currentSite.siteName} : ${currentSite.id}`;
  }, [currentSite?.siteName, currentSite?.id]);

  // Configure chat identity.
  useEffect(() => {
    if (!currentSelfName) return;

    dispatch(
      configureChat({
        isCnms,
        selfName: currentSelfName,
      })
    );
  }, [dispatch, isCnms, currentSelfName]);

  // Establish independent chat socket connection.
  useEffect(() => {
    if (chatBackendURL !== "") {
      dispatch({
        type: "chatSocket/connect",
      });
    }

    return () => {
      dispatch({
        type: "chatSocket/disconnect",
      });
    };
  }, [dispatch]);

  // JOIN / LEAVE events.
  useEffect(() => {
    if (!currentSelfName) return;

    dispatch({
      type: "chatSocket/send",
      payload: {
        destination: PUBLIC_TOPIC,
        body: {
          type: "JOIN",
          content: "joined",
          sender: currentSelfName,
          reciever: "ALL",
        },
      },
    });

    return () => {
      dispatch({
        type: "chatSocket/send",
        payload: {
          destination: PUBLIC_TOPIC,
          body: {
            type: "LEAVE",
            content: "leaving",
            sender: currentSelfName,
            reciever: "ALL",
          },
        },
      });
    };
  }, [dispatch, currentSelfName]);

  // Notification sound.
  useEffect(() => {
    Object.entries(conversations).forEach(([conversation, messages]) => {
      const previousCount = previousMessages.current[conversation] || 0;

      if (messages.length > previousCount) {
        const latestMessage = messages[messages.length - 1];

        const incoming = isCnms
          ? latestMessage.sender !== "CNMS"
          : latestMessage.sender !== selfName;

        if (incoming && !chatOpen && notificationEnabled) {
          // audioRef.current?.play().catch(() => {});
          new Audio(WarningSound).play();
        }
      }

      previousMessages.current[conversation] = messages.length;
    });
  }, [conversations, notificationEnabled, chatOpen, isCnms, selfName]);

  // Send CHAT.
  const sendMessage = (content, conversation) => {
    const trimmed = content.trim();

    if (!trimmed) return false;

    const message = {
      type: "CHAT",
      content: trimmed,
      sender: isCnms ? "CNMS" : selfName,
      reciever: isCnms ? conversation : selfName,
      dateTime: moment().format("DD-MM-YYYY HH:mm:ss"),
      id: crypto.randomUUID(),
    };

    const conversationKey = isCnms ? conversation : "Broadcast";

    // First attempt to publish through the socket.
    const result = dispatch({
      type: "chatSocket/send",
      payload: {
        destination: PUBLIC_TOPIC,
        body: message,
      },
    });

    // Socket disconnected or publish failed.
    if (!result?.success) {
      Toast("", "Sockets disconnected.", "error");
      return false;
    }

    // Only add the message after successful publishing.
    dispatch({
      type: "chat/receiveChatMessage",
      payload: {
        conversation: conversationKey,
        message: {
          id: message.id,
          sender: message.sender,
          content: message.content,
          dateAndTime: message.dateTime,
        },
      },
    });

    return true;
  };

  // Send TYPING.
  const sendTyping = (conversation) => {
    const message = {
      type: "TYPING",
      sender: isCnms ? "CNMS" : selfName,
      reciever: isCnms ? conversation : selfName,
    };

    const result = dispatch({
      type: "chatSocket/send",
      payload: {
        destination: PUBLIC_TOPIC,
        body: message,
      },
    });

    if (!result.success) {
      Toast("", "Unable to send message CNMS server problem.", "error");
    }
  };

  // Send READ acknowledgement.
  const sendSeen = (conversation) => {
    const message = {
      type: "ACK",
      conversation: isCnms ? conversation : selfName,
      readStatus: true,
      chatsForCnms: isCnms,
    };

    dispatch({
      type: "chatSocket/send",
      payload: {
        destination: ACK_DESTINATION,
        body: message,
      },
    });
  };

  const handleOpen = () => {
    // NEW LOGIC: Check if chat is already open
    if (chatOpen) {
      // Option A: Do nothing (Silent)
      // console.log("Chat is already open");

      // Option B: Toggle it closed (Make it an actual toggle)
      dispatch(setChatOpen(false));
      dispatch(setActiveChat("Broadcast"));
      return;
    }

    // Original logic for opening
    dispatch(setChatOpen(true));
    dispatch(resetUnread());
    sendSeen(active);
  };

  const handleClose = () => {
    dispatch(setChatOpen(false));
    dispatch(setActiveChat("Broadcast"));
  };

  const handleSelectConversation = (conversation) => {
    dispatch(setActiveChat(conversation));
    dispatch(resetUnread());

    dispatch(
      setTypingStatus({
        conversation,
        typing: false,
      })
    );

    sendSeen(conversation);
  };

  // Build CNMS / RNMS tabs.
  const tabs = useMemo(() => {
    if (!isCnms) {
      return [
        {
          label: "CNMS",
          id: "CNMS",
        },
      ];
    }

    const siteTabs = sites.map((site) => ({
      label: `${site.siteName} : ${site.siteId}`,
      id: site.siteId,
      status: site.isMaintainance ? "5" : site.healthStatus?.id,
    }));

    return [
      {
        label: "Broadcast",
        id: "Broadcast",
        status: "black", // to display black text color
      },
      ...siteTabs,
    ];
  }, [isCnms, sites]);

  return (
    <>
      {/* <audio ref={audioRef} preload="auto" /> */}

      {/* {!chatOpen && ( */}
      <button
        className="chat-floating-button"
        onClick={handleOpen}
        title="Chat"
        style={{
          bottom: isDrawerOpen ? "240px" : "5px",
          transition: "bottom 0.5s ease-in-out, transform 0.2s ease",
          "&:hover": { transform: "scale(1.08)" },
        }}
      >
        <Badge badgeContent={unread} invisible={!unread}>
          <ChatIcon />
        </Badge>
      </button>
      {/* )} */}

      {chatOpen && (
        <div
          className="chat-root"
          style={{
            bottom: isDrawerOpen ? "300px" : "50px",
            transition: "bottom 0.5s ease-in-out, transform 0.2s ease",
            "&:hover": { transform: "scale(1.08)" },
            width:isCnms ? "490px" : "350px"
          }}
        >
          <VerticalTabs
            tabs={tabs}
            active={active}
            conversations={conversations}
            typing={typing}
            isCnms={isCnms}
            onSelect={handleSelectConversation}
            onClose={handleClose}
            onSend={sendMessage}
            onTyping={sendTyping}
            onSeen={sendSeen}
          />
        </div>
      )}
    </>
  );
};

export default CnmsChat;
