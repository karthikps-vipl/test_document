import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";

import DoneAllIcon from "@mui/icons-material/DoneAll";
import SendIcon from "@mui/icons-material/Send";

const Chats = ({
  conversation,
  messages,
  typing,
  isCnms,
  onSend,
  onTyping,
}) => {
  const [content, setContent] = useState("");

  const chatEndRef = useRef(null);

  const { selfName, ackChat, ackChatForCnms } = useSelector(
    (state) => state.chat
  );

  // Automatically scroll to latest message.
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, typing]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const trimmed = content.trim();

    if (!trimmed) return;

    onSend(trimmed, conversation);

    setContent("");
  };

  const handleTyping = (value) => {
    setContent(value.slice(0, 140));

    if (value.trim()) {
      onTyping(conversation);
    }
  };

  const isMyMessage = (message) => {
    return isCnms ? message.sender === "CNMS" : message.sender === selfName;
  };

  const isRead = (message, index) => {
    const ackData = isCnms ? ackChatForCnms[conversation] : ackChat[selfName];

    if (!Array.isArray(ackData)) return false;

    const unreadCount = Math.max(0, messages.length - ackData.length);

    return index >= unreadCount;
  };

  return (
    <div className="chat-window">
      <div className="chat-messages">
        {messages.map((message, index) => {
          const mine = isMyMessage(message);

          return (
            <div
              key={`${message.id}-${index}`}
              className={`chat-message-row ${mine ? "sent" : "received"}`}
            >
              <div
                className={`chat-message ${
                  mine ? "sent-message" : "received-message"
                }`}
              >
                <div className="chat-message-content">{message.content}</div>

                <div className="chat-message-time">
                  {message.dateAndTime}

                  {mine && (
                    <DoneAllIcon
                      className={
                        isRead(message, index)
                          ? "chat-read"
                          : "chat-unread-tick"
                      }
                    />
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {typing && (
          <div className="chat-message-row received">
            <div className="chat-message received-message">
              <i>Typing...</i>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      <form className="chat-input-area" onSubmit={handleSubmit}>
        <textarea
          value={content}
          onChange={(e) => handleTyping(e.target.value)}
          placeholder="Type Message Here (140 Characters)"
          maxLength={140}
          rows={2}
          style={{color:'black'}}
        />

        <button type="submit" disabled={!content.trim()} title="Send message">
          <SendIcon />
        </button>
      </form>
    </div>
  );
};

export default Chats;
