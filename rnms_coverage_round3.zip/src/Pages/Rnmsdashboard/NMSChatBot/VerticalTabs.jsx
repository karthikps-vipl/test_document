import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import NotificationsOffIcon from "@mui/icons-material/NotificationsOff";

import { setNotificationEnabled } from "@/store/features/Chats/chatSlice";

import Chats from "./Chats";
import { useTheme } from "@mui/material";

const VerticalTabs = ({
  tabs,
  active,
  conversations,
  typing,
  isCnms,
  onSelect,
  onClose,
  onSend,
  onTyping,
  onSeen,
}) => {
  const dispatch = useDispatch();
  const theme = useTheme();

  const { ackChat, notificationEnabled } = useSelector((state) => state.chat);

  const [search, setSearch] = useState("");

  console.log(tabs, "tabstabstabs");

  const filteredTabs = tabs.filter((tab) =>
    tab.label.toLowerCase().includes(search.toLowerCase())
  );

  const currentTab = isCnms
    ? tabs.find((tab) => tab.label === active)
    : tabs[0];

  const conversation = isCnms ? active : "Broadcast";

  const colorMap1 = {
    // "0": theme.palette.error.light,
    // "1": theme.palette.online.dark,
    // "2": theme.palette.secondary.dark,
    // "3": theme.palette.warning.dark,
    // "4": theme.palette.alert.dark,
    // "5": theme.palette.maintainance // for maintainance.
    0: "red",
    1: "green",
    2: "#f3c106", //amber
    5: "darkgoldenrod", // maintainance
    UP: "green",
    DOWN: "red",
    "OPERATIONAL DOWN": "#f3c106",
    MovedToMaintainance: "darkgoldenrod",
    MovedToMaintainanceROPS: "#80C7DF",

    black: "black", // just for broadcast to display black color
  };

  return (
    <div className="chat-panel">
      <div
        className="chat-header"
        style={{ backgroundColor: theme.palette.background.default }}
      >
        <span>NMS Chat</span>

        <div className="chat-header-actions">
          <button
            title="Toggle notifications"
            onClick={() =>
              dispatch(setNotificationEnabled(!notificationEnabled))
            }
          >
            {notificationEnabled ? (
              <NotificationsActiveIcon />
            ) : (
              <NotificationsOffIcon />
            )}
          </button>

          <button onClick={onClose} title="Close chat">
            <CloseIcon />
          </button>
        </div>
      </div>

      <div className="chat-content">
        {isCnms && (
          <div className="chat-sidebar">
            <div className="chat-search">
              <SearchIcon />

              <input
                placeholder="Search Site"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="chat-tab-list">
              {filteredTabs.map((tab) => {
                const unreadMessages = ackChat[tab.label]?.length || 0;

                return (
                  <button
                    key={tab.id}
                    className={`chat-tab ${
                      active === tab.label ? "active" : ""
                    }`}
                    onClick={() => onSelect(tab.label)}
                  >
                    <span style={{ color: colorMap1[tab.status] }}>
                      {tab.label}
                    </span>

                    {unreadMessages > 0 && (
                      <span className="chat-unread">{unreadMessages}</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="chat-conversation">
          {currentTab ? (
            <Chats
              key={conversation}
              conversation={conversation}
              messages={conversations[conversation] || []}
              typing={!!typing[conversation]}
              isCnms={isCnms}
              onSend={onSend}
              onTyping={onTyping}
              onSeen={onSeen}
            />
          ) : (
            <div className="chat-empty">Select a conversation</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VerticalTabs;
