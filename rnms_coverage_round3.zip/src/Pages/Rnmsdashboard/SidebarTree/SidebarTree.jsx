 
// import React, { useEffect, useState, useMemo } from "react";
// import {
//     Box,
//     List,
//     ListItemButton,
//     ListItemText,
//     Collapse,
//     Menu,
//     MenuItem,
//     Paper,
//     TextField,
//     InputAdornment,
//     Grid
// } from "@mui/material";
// import { ExpandMore, ChevronRight, Search } from "@mui/icons-material";
// import MInput from "../../../components/Reusable/Input/MInput";
// import { useTreeSearch } from "./hooks/useTreeSearch";
// import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import {
//     FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
//     FETCH_ALL_SEGMENTS,
// } from "@/RestAPI/url/endpoint";
// import { useSelector } from 'react-redux';
// import searchIcon from "../../../assets/SVGIcons/search.svg";
// import Base_Band from "../../../assets/SVGIcons/Base_Band.svg";
// import Satcom from "../../../assets/SVGIcons/Satcom.svg";
// import Radio from "../../../assets/SVGIcons/Radio.svg";
// import Power from "../../../assets/SVGIcons/Power.svg";
// import mctep from "../../../assets/SVGIcons/mct-ep.svg";
// import Surveillence from "../../../assets/SVGIcons/Surveillence.svg";
// import Voice from "../../../assets/SVGIcons/Voice.svg";
// import { HomeIcon } from "lucide-react";




// const TreeItem = ({
//     node,
//     level = 0,
//     onRightClick,
//     selected,
//     setSelected,
//     search,
// }) => {
//     const [open, setOpen] = useState(false);
//     const hasChildren = node.children?.length > 0;
//     useEffect(() => {
//         if (search) setOpen(true);
//     }, [search]);
//     const getIcon = () => {
//         if (node.type === 'root') {
//             return <img src={mctep}></img>;
//         } else if (node.type === 'segment') {
//             return node.icon; // Return the icon directly from the node data
//         }
//         return null; // No icon for other types (e.g., devices)
//     };
//     return (
//         <>
//             <ListItemButton
//   sx={{
//     pl: 2 + level * 2,
//     bgcolor:
//       selected?.resourceName === node.resourceName ? "#e3f2fd" : "transparent",
//     gap: 1,
//     display: 'flex',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     position: 'relative',   
    
//   }}
//   onClick={() => {
//     setSelected(node);
//     if (hasChildren) setOpen(!open);
//   }}
//   onContextMenu={(e) => {
//     e.preventDefault();
//     setSelected(node);
//     onRightClick(e, node);
//   }}
// >
//   {getIcon()}
//   <ListItemText primary={node.label}  />
//   {hasChildren ? open ? <ExpandMore  /> : <ChevronRight /> : null}
  
// </ListItemButton>
           
           
//             {hasChildren && (
//                 <Collapse sx={{
                  
//                     "&:before": {   
//                        content: '""',
//                        position: 'absolute',
//                        top: '14%',
//                        left: '8%',
//                        height: '80%',
//                        borderLeft: '2px solid #bcbcbc',  
//                        zIndex: 0,
//                        display: open ? 'block' : 'none',  
//                      },
                     
//                  }} in={open} timeout="auto" >
//                     {node.children.map((child) => (
//                         <TreeItem sx={{"&:hover":{
//         backgroundColor: "red" //Example hover
//      }}}
//                             key={child.resourceName} 
//                             node={child}
//                             level={level + 1}
//                             onRightClick={onRightClick}
//                             selected={selected}
//                             setSelected={setSelected}
//                             search={search}
//                         />
//                     ))}
//                 </Collapse>
//             )}
//         </>
//     );
// };
// const TreeSidebar = () => {
//     const [segments, setSegments] = useState([]);
//     const [resources, setResources] = useState([]);
//     const [selected, setSelected] = useState(null);
//     const [contextMenu, setContextMenu] = useState(null);
//     const [search, setSearch] = useState("");
//     const terminalNickname = useSelector((state) => state.nodeDetails.siteDetails?.terminalTypeName);

//     const segmentIconMap = {
//         1: <img src={Satcom} alt="Satcom" />,
//         2: <img src={Power} alt="Power" />,
//         3: <img src={Base_Band} alt="Base_Band" />, // Or other desired icon
//         4: <img src={Surveillence} alt="Surveillence" />,
//         6: <img src={Radio} alt="Radio" />,
//         8: <img src={Voice} alt="Voice" />,
//     };
//     useEffect(() => {
//         const fetchData = async () => {
//             try {
//                 const [segmentRes, resourceRes] = await Promise.all([
//                     InventoryAxios(FETCH_ALL_SEGMENTS, "get"),
//                     InventoryAxios(
//                         FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
//                         "post",
//                         [1, 2, 3, 4, 5, 6, 7, 8, 9]
//                     ),
//                 ]);
//                 setSegments(segmentRes.data);
//                 setResources(resourceRes.data);
//             } catch (error) {
//                 console.error("API Error:", error);
//             }
//         };
//         fetchData();
//     }, []);
//     /* ===== BUILD TREE ===== */
//     const treeData = useMemo(() => {
//         const root = {
//             resourceName: "root",
//             label: terminalNickname || "Default Root Name", type: "root",
//             children: [],
//         };
//         segments.forEach((segment) => {
//             const segmentNode = {
//                 resourceName: `segment-${segment.segmentId}`,
//                 label: segment.segmentName,
//                 type: "segment",
//                 icon: segmentIconMap[segment.segmentId] || <img src={searchIcon} alt="Default" />,
//                 children: [],
//             };
//             const devices = resources.filter(
//                 (res) => res.imSegmentInfo?.segmentId === segment.segmentId
//             );
//             segmentNode.children = devices
//                 .map((device) => ({
//                     resourceName: device.resourceName,
//                     label: device.resourceName,
//                     type: "device",
//                     resourceIp: device.resourceIp,
//                     status: device.status,
//                     data: device,
//                 }))
//                 .sort((a, b) => a.resourceName.localeCompare(b.resourceName)); // Sorting alphabetically by resourceName
//             root.children.push(segmentNode);
//         });
//         return [root];
//     }, [segments, resources, terminalNickname]);
//     /* ===== REUSABLE SEARCH ===== */
//     const filteredTree = useTreeSearch(treeData, search, {
//         keys: ["label", "resourceName", "resourceIp", "status"],
//         childrenKey: "children",
//     });
//     /* ===== CONTEXT MENU CONFIG ===== */
//     const MENU_CONFIG = {
//         root: ["View RNMS Details", "Inventory Details"],
//         segment: ["View Alarms", "View Details"],
//         device: ["Inventory", "Fault", "Configuration", "Status"],
//     };
//     const handleRightClick = (event, node) => {
//         console.log(node, "nnknknnknk");
//         setContextMenu({
//             mouseX: event.clientX - 2,
//             mouseY: event.clientY - 4,
//             node,
//         });
//     };
//     const handleCloseMenu = () => {
//         setContextMenu(null);
//     };
//     const handleMenuClick = (action) => {
//         console.log("Action:", action);
//         console.log("Node Data:", contextMenu.node);
//         handleCloseMenu();
//     };
//     return (
//         <Paper sx={{ width: '100%', height: "100%", overflow: "auto" }}>
//             <Box p={1}>
//             </Box>
//             <Box px={2} pb={1}>
//                 <TextField
//                     size="small"
//                     variant="outlined"
//                     placeholder="Search Here"
//                     value={search}
                   
//                     onChange={(e) => setSearch(e.target.value)}
//                     InputProps={{
//                         startAdornment: (
//                             <InputAdornment  >
//                                 <Search />
//                             </InputAdornment>
//                         ),
//                     }}
//                 />
//             </Box>
//             <List>
//                 {filteredTree.map((node) => (
//                     <TreeItem
//                         key={node.resourceName}
//                         node={node}
//                         onRightClick={handleRightClick}
//                         selected={selected}
//                         setSelected={setSelected}
//                         search={search}
//                     />
//                 ))}
//             </List>
 
//             <Menu
//         open={Boolean(contextMenu)}
//         onClose={handleCloseMenu}
//         anchorReference="anchorPosition"
//         anchorPosition={
//           contextMenu
//             ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
//             : undefined
//         }
//       >
//         {MENU_CONFIG[contextMenu?.node?.type]?.map((item) => (
//           <MenuItem key={item} onClick={() => handleMenuClick(item)}>
//             {item}
//           </MenuItem>
//         ))}
//       </Menu>

//       {/* RNMS Details Dialog */}
//       <MModal
//         open={isRnmsDetailsDialogOpen}
//         handleClose={handleCloseRNMSDetailsDialog}
//         title="RNMS Details"
//       >
//         <Grid container spacing={2}>
//           <Grid item xs={12} sm={6}>
//             <MInput label="Name" value={rnmsDetails.name} onChange={(e) => setRnmsDetails({...rnmsDetails, name: e.target.value})} />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <MInput label="ID" value={rnmsDetails.id} onChange={(e) => setRnmsDetails({...rnmsDetails, id: e.target.value})} />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <MInput label="Location" value={rnmsDetails.location} onChange={(e) => setRnmsDetails({...rnmsDetails, location: e.target.value})} />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <MInput label="Description" value={rnmsDetails.description} onChange={(e) => setRnmsDetails({...rnmsDetails, description: e.target.value})} />
//           </Grid>
//         </Grid>
//       </MModal>
    
//         </Paper>
//     );
// };
// export default TreeSidebar;
