/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : SidebarTree 
   File Name                : TreeSidebar.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\SidebarTree\TreeSidebar.jsx
   Purpose                  : Created the TreeSidebar for displaying the treeview for parent and child node 
   Created Date             : 04-04-2026
 ***********************************************************************************************/

import {
  Box,
  List,
  ListItemButton,
  ListItemText,
  Collapse,
  Menu,
  MenuItem,
  Paper,
  InputAdornment,
  useTheme,
} from "@mui/material";
// import { ExpandMore, ChevronRight, Search } from "@mui/icons-material";
import {
  ExpandMore,
  ChevronRight,
  Search,
  ApartmentOutlined,
  DriveEta,
  Bolt as BoltIcon,
} from "@mui/icons-material";

import rhombus from "@/assets/CNMS/pictorialView/rhombus.svg";
import star from "@/assets/CNMS/pictorialView/star.svg";
import doctor from "@/assets/CNMS/pictorialView/mctr.svg";
import hexa from "@/assets/CNMS/pictorialView/hexa.svg";
import triangle from "@/assets/CNMS/pictorialView/triangle.svg";
import octa from "@/assets/CNMS/pictorialView/octa.svg";
import square from "@/assets/CNMS/pictorialView/square.svg";

import { useTreeSearch } from "./hooks/useTreeSearch";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
  FETCH_ALL_SEGMENTS,
  VALIDATE_RESOURCE_PASSWORD,
} from "@/RestAPI/url/endpoint";
import { useDispatch, useSelector } from "react-redux";
import searchIcon from "../../../assets/SVGIcons/search_b.svg";
import Base_Band_b from "../../../assets/SVGIcons/Base_Band_b.svg";
import Satcom from "../../../assets/SVGIcons/Satcom.svg";
import Radio from "../../../assets/SVGIcons/Radio.svg";
import Power from "../../../assets/SVGIcons/Power.svg";
import Surveillence from "../../../assets/SVGIcons/Surveillence.svg";
import Voice from "../../../assets/SVGIcons/Voice.svg";
import { useEffect, useMemo, useState } from "react";
import {
  setSegments,
  setTreeClickedItem,
} from "@/store/features/Inventory/inventorySlice";
import { ContextMenuOptions } from "../../../components/Contextmenu/utils";
import NestedSubMenu from "@/components/Contextmenu/SubMenu";
import { dispatchContextAction } from "@/core/actions/contextActionDispatcher";
import MInput from "@/components/Reusable/Input/MInput";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
import { ResourcesSVG } from "@/assets/SVGIcons/ResourcecesSvg";
import PasswordPromptDialog from "../PasswordPromptDialog";
import { CNMSContextMenuOptions } from "@/components/Contextmenu/CNMS_Utils";

const TreeItem = ({
  node,
  level = 0,
  onRightClick,
  selected,
  setSelected,
  search,
  rootClickCount,
  setRootClickCount,
  expandedAll,
  setExpandedAll,
}) => {
  const dispatch = useDispatch();
  const [open, setOpen] = useState(node.type === "root" ? true : false);
  // const [allChildrenOpen, setAllChildrenOpen] = useState(false);
  const hasChildren = node.children?.length > 0;

  useEffect(() => {
    if (expandedAll) {
      setOpen(true);
    } else if (!search && node.type !== "root") {
      setOpen(false);
    }
  }, [expandedAll]);

  useEffect(() => {
    if (
      node.type === "root" &&
      rootClickCount === 1 &&
      !expandedAll &&
      !search
    ) {
      setOpen(true);
    }
  }, [rootClickCount, expandedAll, search, node.type]);

  const handleSingleClick = (e) => {
    e.stopPropagation();

    if (node.type === "device") {
      dispatch(setTreeClickedItem(node.data.resourceId));
    }

    if (node.type === "vehicle") {
      dispatch(setTreeClickedItem(node.data.siteId));
    }

    setSelected(node);

    if (node.type !== "root") {
      setOpen(!open);
      return;
    }

    if (rootClickCount === 0) {
      setOpen(true);
      setRootClickCount(1);
    } else if (rootClickCount === 1) {
      setExpandedAll(true);
      setRootClickCount(2);
    } else {
      setOpen(false);
      setExpandedAll(false);
      setRootClickCount(0);
    }
  };

  useEffect(() => {
    if (search?.trim()) {
      setOpen(true);
    } else if (rootClickCount === 0 && node.type !== "root") {
      setOpen(false);
      setExpandedAll(false);
    }
  }, [search]);

  const handleDoubleClick = (e) => {
    e.stopPropagation();
    if (
      node.type === "root" ||
      node.type === "segment" ||
      node.type === "siteDetails"
    ) {
      const newState = !open;
      setOpen(newState);
      setAllChildrenOpen(newState);
    }
  };

  // const getIcon = () => {
  //   if (node.type === "root") {
  //     return (
  //       <Box
  //         component="img"
  //         src={mctep}
  //         alt="root"
  //         sx={{
  //           width: "20px",
  //           filter: (theme) => theme.palette.custom.icon.iconFilter,
  //         }}
  //       />
  //     );
  //   }

  //   if (node.type === "segment") {
  //     return node.icon;
  //   }

  //   if (node.type === "device") {
  //     return <Box sx={{ ml: 5 }}>{node.icon}</Box>;
  //   }

  //   if (node.type === "siteDetails") {
  //     return <ResourcesSVG size={18} />;
  //   }

  //   if (node.type === "vehicle") {
  //     return (
  //       <Box sx={{ ml: 5 }}>
  //         <ResourcesSVG size={18} />
  //       </Box>
  //     );
  //   }

  //   return null;
  // };

  const getIcon = () => {
    // -------------------------
    // CNMS ROOT
    // -------------------------
    if (node.type === "root") {
      return (
        <ApartmentOutlined
          sx={{
            fontSize: 22,
            color: "inherit",
          }}
        />
      );
    }

    // -------------------------
    // CNMS SITE / TERMINAL TYPE
    // -------------------------
    if (node.type === "siteDetails") {
      return node.icon || null;
    }

    // -------------------------
    // CNMS VEHICLE
    // -------------------------
    if (node.type === "vehicle") {
      return (
        <DriveEta
          sx={{
            fontSize: 20,
            ml: 0.5,
          }}
        />
      );
    }

    // -------------------------
    // RNMS SEGMENT
    // -------------------------
    if (node.type === "segment") {
      return node.icon;
    }

    // -------------------------
    // RNMS DEVICE
    // -------------------------
    if (node.type === "device") {
      return <Box sx={{ ml: 5 }}>{node.icon}</Box>;
    }

    return null;
  };

  const isSelected = selected
    ? selected.resourceName === node.resourceName &&
      selected.data?.resourceId === node.data?.resourceId
    : node.type === "root";

  const getBackgroundColor = () => {
    const isAncestor = (current, target) => {
      if (!current.children || !target) return false;
      return current.children.some(
        (child) =>
          (child.resourceName === target.resourceName &&
            child.data?.resourceId === target.data?.resourceId) ||
          isAncestor(child, target)
      );
    };

    if (isSelected) {
      return "rgb(200, 214, 247)";
    }

    if (isAncestor(node, selected)) {
      if (node.type === "root") {
        return "  rgb(76, 120, 215) ";
      }
      return "rgb(135, 168, 240);";
    }

    return "transparent";
  };

  const getTextColor = () => {
    if (isSelected && (selected || node.type === "root")) {
      return node.type === "root" && !selected
        ? "#14138d"
        : selected?.resourceName === node.resourceName &&
          selected?.data?.resourceId === node.data?.resourceId
        ? "#14138d"
        : "inherit";
    }

    if (getBackgroundColor() !== "transparent") {
      return "#000000";
    }

    return "inherit";
  };

  const isPathNode = (current, target) => {
    if (!current.children || !target) return false;
    return current.children.some(
      (child) =>
        (child.resourceName === target.resourceName &&
          child.data?.resourceId === target.data?.resourceId) ||
        isPathNode(child, target)
    );
  };

  const isHighlightedPath = selected
    ? (selected.resourceName === node.resourceName &&
        selected.data?.resourceId === node.data?.resourceId) ||
      isPathNode(node, selected)
    : node.type === "root";

  return (
    <>
      <ListItemButton
        sx={{
          pl: 1 + level * 2,
          bgcolor: getBackgroundColor(),
          color: getTextColor(),
          "&:hover": {
            bgcolor: isSelected ? getBackgroundColor() : "#5583e5 ",
          },
          gap: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          transition: "background-color 0.2s",
          minHeight: "45px",
          py: "0.5px",
          borderRadius: "10px",
        }}
        onClick={handleSingleClick}
        onDoubleClick={handleDoubleClick}
        onContextMenu={(e) => {
          e.preventDefault();
          setSelected(node);
          onRightClick(e, node);
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          {hasChildren ? open ? <ExpandMore /> : <ChevronRight /> : null}
          {getIcon()}
          <ListItemText
            primary={node.label}
            primaryTypographyProps={{
              fontWeight: isHighlightedPath ? 700 : 400,
              fontSize: "0.9rem",
              color: getTextColor(),
            }}
          />
        </Box>
      </ListItemButton>

      {hasChildren && (
        <Collapse
          in={open}
          timeout="auto"
          sx={{
            position: "relative",
            "&:before": {
              content: '""',
              position: "absolute",
              top: 0,
              left: `${18 + level * 18}px`,
              height: "100%",
              borderLeft: "1.5px solid #bcbcbc",
              zIndex: 1,
            },
          }}
        >
          {node.children.map((child, index) => (
            <TreeItem
              key={`${child.resourceName}-${child.data?.resourceId || index}`}
              node={child}
              level={level + 1}
              onRightClick={onRightClick}
              selected={selected}
              setSelected={setSelected}
              search={search}
              rootClickCount={rootClickCount}
              setRootClickCount={setRootClickCount}
              expandedAll={expandedAll}
              setExpandedAll={setExpandedAll}
            />
          ))}
        </Collapse>
      )}
    </>
  );
};

const StyledIcon = ({ src, alt }) => (
  <Box
    component="img"
    src={src}
    alt={alt}
    sx={{
      width: "18px",
      filter: (theme) => theme.palette.custom.icon.iconFilter,
    }}
  />
);

const TreeSidebar = () => {
  const theme = useTheme();

  const isDark = theme.palette.mode === "dark";
  const [selected, setSelected] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  // const CnmsDeleteSite = useSelector(
  //   (state) => state.remoteRepDetails.CnmsDeleteSite || []
  // );

  const CnmsDiscovery = useSelector(
    (state) => state.siteDiscovery.discoveryResults || []
  );

  const fetchSiteDetails = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails || []
  );

  // const { fetchSiteDetails } = useSelector((state) => state.remoteRepDetails);

  console.log("CnmsDeleteSitetree", CnmsDiscovery);

  const cnmsSiteIconMap = {
    DMRR: rhombus,
    "MCT-MK-I": rhombus,
    "MCT-MK-II": hexa,
    "MCT-MK-III": triangle,
    "HUB-NMS": octa,
    "MCT-LSV": star,
    "MCT-R": doctor,
    "MCT-LSV-ALPHA": null,
    "MCT-TAC": octa,
    "MCT-CARH": hexa,
    "MCT-CARR": square,
  };
  // const cnmsSiteIconMap = {
  //   "MCT-LSV": MCTLSV,
  //   "MCT-MK-I": MCTMKI,
  //   "MCT-MK-II": MCTMKII,
  //   "MCT-MK-III": MCTMKIII,
  //   "MCT-LSV-ALPHA": null, // handled with BoltIcon
  // };

  const getCnmsSiteIcon = (terminalTypeName) => {
    if (terminalTypeName === "MCT-LSV-ALPHA") {
      return <BoltIcon fontSize="small" />;
    }

    const iconSrc =
      cnmsSiteIconMap[terminalTypeName] || cnmsSiteIconMap["MCT-LSV"];

    return (
      <Box
        component="img"
        src={iconSrc}
        alt={terminalTypeName || "MCT-LSV"}
        sx={{
          width: "20px",
          height: "20px",
          objectFit: "contain",
          filter: (theme) => theme.palette.custom.icon.iconFilter,
        }}
      />
    );
  };

  // const filteredSiteDetails = useMemo(() => {

  //   // 1. Create a Set of siteIds to delete for high-performance lookup
  //   const idsToDelete = new Set(CnmsDeleteSite.map((site) => site.siteId));

  //   // 2. Filter the fetchSiteDetails array
  //   // Only keep items whose siteId is NOT in the idsToDelete Set
  //   return fetchSiteDetails.filter((site) => !idsToDelete.has(site.siteId));
  // }, [CnmsDeleteSite, fetchSiteDetails]);

  // const filteredSiteDetails = useMemo(() => {
  //   // 1. Create a Set of siteIds to delete for high-performance lookup
  //   const idsToDelete = new Set(CnmsDeleteSite.map((site) => site.siteId));

  //   // 2. Create a Map of CnmsDiscovery for O(1) lookup and merging
  //   // We use a Map to handle potential duplicate siteIds in the discovery array cleanly
  //   const discoveryMap = new Map();
  //   CnmsDiscovery.forEach((site) => {
  //     discoveryMap.set(site.siteId, site);
  //   });

  //   // 3. Start with the existing fetchSiteDetails (filtered by deletion)
  //   let finalSites = fetchSiteDetails.filter((site) => !idsToDelete.has(site.siteId));

  //   // 4. Iterate through Discovery results to update or add sites
  //   discoveryMap.forEach((discoverySite, siteId) => {
  //     // Check if this siteId already exists in our finalSites array
  //     const existingIndex = finalSites.findIndex((s) => s.siteId === siteId);

  //     if (existingIndex !== -1) {

  //       const existingSite = finalSites[existingIndex];

  //       Object.assign(existingSite, discoverySite);
  //       existingSite.siteId = siteId;
  //     } else {
  //       finalSites.push(discoverySite);
  //     }
  //   });

  //   return finalSites;
  // }, [CnmsDeleteSite, fetchSiteDetails, CnmsDiscovery]);

  const CnmsDeleteAddSite = useSelector(
    (state) => state.remoteRepDetails.CnmsDeleteAddSite || []
  );

  console.log("vgtfetchSiteDetails", fetchSiteDetails);
  console.log("CnmsDeleteAddSite", CnmsDeleteAddSite);

  // Password Prompt States
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [pendingActionOpt, setPendingActionOpt] = useState(null);
  const [authError, setAuthError] = useState(false);
  // const [isVerifying, setIsVerifying] = useState(false);

  const [rootClickCount, setRootClickCount] = useState(1);
  const [expandedAll, setExpandedAll] = useState(false);

  const resources = useSelector((state) => state.inventory.resources);
  const segments = useSelector((state) => state.inventory.segments);
  console.log("resources ", resources);
  console.log("segments ", segments);
  console.log("contextMenufrycc", contextMenu);

  const [search, setSearch] = useState("");

  const terminalNickname = useSelector(
    (state) => state.nodeDetails.siteDetails?.terminalTypeName
  );

  const nestedPrivileges = useSelector(
    (state) => state.userSlice.devicePrivileges
  );
  console.log("nestedPrivileges ", nestedPrivileges);

  const dispatch = useDispatch();

  const segmentIconMap = {
    1: <StyledIcon src={Satcom} alt="Satcom" />,
    2: <StyledIcon src={Power} alt="Power" />,
    3: <StyledIcon src={Base_Band_b} alt="Base_Band_b" />,
    4: <StyledIcon src={Surveillence} alt="Surveillence" />,
    6: <StyledIcon src={Radio} alt="Radio" />,
    8: <StyledIcon src={Voice} alt="Voice" />,
  };

  const cnmsContextMenuItems = (node) => {
    if (!node) return [];

    const options = CNMSContextMenuOptions[node.type] || [];

    if (node.type !== "vehicle") {
      return options;
    }

    const currentSiteId = node.data?.siteId;

    let isMaintenance = node.data?.isMaintainance;

    // Only update if Redux data belongs to this vehicle
    if (
      CnmsDeleteAddSite?.siteId &&
      CnmsDeleteAddSite.siteId === currentSiteId
    ) {
      isMaintenance = CnmsDeleteAddSite.isMaintainance;
    }

    console.log({
      currentSiteId,
      reduxSiteId: CnmsDeleteAddSite?.siteId,
      isMaintenance,
    });

    return options.filter((item) => {
      if (isMaintenance === true && item.value === "cnmsMoveToMaintenance") {
        return false;
      }

      if (isMaintenance === false && item.value === "cnmsAddSite") {
        return false;
      }

      return true;
    });
  };

  const getContextMenuItems = (node) => {
    if (!node) return [];

    if (node.type === "root") {
      return [
        { label: "View RNMS Details", value: "rnms" },
        { label: "Inventory Details", value: "inventoryDetails" },
      ];
    }

    if (node.type === "segment") {
      return [
        { label: "View Details", value: "segmentDetails" },
        { label: "View Active Alarms", value: "segmentAlarms" },
      ];
    }

    if (node.type === "device") {
      const nodeData = node?.data;
      const resourceTypeId = nodeData?.imResourceType?.resourceTypeId;
      const privilegeSet = nestedPrivileges?.[resourceTypeId] || {};
      const deviceCapabilities = nodeData?.imResourceType?.data || {};

      const isMaintenance = nodeData?.isMaintainance;
      const isDiscovered = nodeData?.isDiscovered;

      return ContextMenuOptions.filter((opt) => {
        const hasPermission = privilegeSet?.[opt.previlage] === true;
        const isSupportedByHardware = deviceCapabilities?.[opt.key] !== false;

        if (!hasPermission || !isSupportedByHardware) {
          return false;
        }

        if (!isDiscovered && isMaintenance) {
          return opt.value !== "deleteDevice";
        }

        if (!isDiscovered && !isMaintenance) {
          return opt.value !== "addDevice";
        }

        if (isDiscovered && !isMaintenance) {
          return opt.value !== "addDevice";
        }

        return true;
      });
    }

    return [];
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [segmentRes] = await Promise.all([
          InventoryAxios(FETCH_ALL_SEGMENTS, "get"),
          InventoryAxios(
            FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
            "post",
            [1, 2, 3, 4, 5, 6, 7, 8, 9]
          ),
        ]);

        dispatch(
          setSegments({
            segments: segmentRes.data,
          })
        );
      } catch (error) {
        console.error("API Error:", error);
      }
    };
    fetchData();
  }, [dispatch]);

  const treeData = useMemo(() => {
    if (isCnms) {
      const root = {
        resourceName: "cnms-root",
        // label: "Root",
        label: terminalNickname || "Default Root Name",
        type: "root",
        children: [],
      };

      const groupedSites = {};

      fetchSiteDetails.forEach((site) => {
        const terminalTypeName =
          site?.imTerminalType?.terminalTypeName || "Unknown";

        // const id = site?.imTerminalType?.id || "Unknown";

        if (!groupedSites[terminalTypeName]) {
          groupedSites[terminalTypeName] = [];
        }

        groupedSites[terminalTypeName].push(site);
      });

      console.log("groupedSisddtes", groupedSites);

      Object.entries(groupedSites).forEach(([terminalTypeName, sites]) => {
        const validSite = sites.find((s) => s.imTerminalType?.id);
        const imTerminalTypeId = validSite?.imTerminalType?.id || "Unknown";
        const siteDetailsNode = {
          resourceName: `siteDetails-${terminalTypeName}`,
          label: terminalTypeName,
          type: "siteDetails",
          icon: getCnmsSiteIcon(terminalTypeName),
          data: {
            terminalTypeName,
            sites,
            imTerminalType: { id: imTerminalTypeId },
          },
          children: [],
        };

        siteDetailsNode.children = sites
          .map((site) => ({
            resourceName: `vehicle-${site.siteId || site.remoteNumber}`,
            label: `${site.siteName || "Unknown"} - ${site.remoteNumber ?? ""}`,
            type: "vehicle",
            data: site,
          }))
          .sort((a, b) => a.label.localeCompare(b.label));

        root.children.push(siteDetailsNode);
      });

      root.children.sort((a, b) => a.label.localeCompare(b.label));

      return [root];
    }

    // -----------------------------
    // Existing RNMS tree
    // -----------------------------

    const root = {
      resourceName: "root",
      label: terminalNickname || "Default Root Name",
      type: "root",
      children: [],
    };

    segments.forEach((segment) => {
      const segmentNode = {
        resourceName: `segment-${segment.segmentId}`,
        label: segment.segmentName,
        type: "segment",
        data: segment,
        icon: segmentIconMap[segment.segmentId] || (
          <StyledIcon src={searchIcon} alt="Default" />
        ),
        children: [],
      };

      const devices = resources.filter(
        (res) => res.imSegmentInfo?.segmentId === segment.segmentId
      );

      segmentNode.children = devices
        .map((device) => ({
          resourceName: device.resourceName,
          label: device.resourceName,
          type: "device",
          resourceIp: device.resourceIp,
          status: device.status,
          data: device,
          icon: <ResourcesSVG size={18} />,
        }))
        .sort((a, b) => a.resourceName.localeCompare(b.resourceName));

      root.children.push(segmentNode);
    });

    return [root];
  }, [isCnms, fetchSiteDetails, segments, resources, terminalNickname]);

  const filteredTree = useTreeSearch(treeData, search, {
    keys: ["label", "resourceName", "resourceIp", "status"],
    childrenKey: "children",
  });

  const handleRightClick = (event, node) => {
    setContextMenu({
      mouseX: event.clientX - 2,
      mouseY: event.clientY - 4,
      node,
    });
  };

  const handleCloseMenu = () => setContextMenu(null);

  // Unified execution handler that triggers action dispatch
  const executeAction = (opt, encryptedPassword = null) => {
    const node = contextMenu?.node;

    console.log("nodetgb", node);

    const nodeData = node?.data || "root";

    dispatchContextAction({
      action: opt.value || opt,
      node: {
        ...nodeData,
        nodeType: node.type,
        treeNode: node,
        ...(encryptedPassword ? { password: encryptedPassword } : {}),
      },
      source: "tree",
    });

    handleCloseMenu();
  };

  // Updated click handler to support both status and configuration password checks
  const handleMenuOptionClick = (opt) => {
    const nodeData = contextMenu?.node?.data;
    const deviceCapabilities = nodeData?.imResourceType?.data || {};
    const authConfig = deviceCapabilities?.authentication;
    const expectedEncryptedPassword =
      deviceCapabilities?.authenticationPassword;
    const authPasswordExists = Boolean(expectedEncryptedPassword);

    const isStatusAction =
      opt.value === "status" || opt.value === "deviceStatus";
    const isConfigAction =
      opt.value === "configuration" || opt.value === "deviceConfiguration";

    if (
      contextMenu?.node?.type === "device" &&
      (isStatusAction || isConfigAction) &&
      authConfig === true &&
      authPasswordExists
    ) {
      setPendingActionOpt(opt);
      setAuthError(false);
      setPasswordModalOpen(true);
    } else {
      executeAction(opt);
    }
  };

  const handlePasswordSubmit = async (encryptedPassword) => {
    // setIsVerifying(true);
    setAuthError(false);

    try {
      const nodeData = contextMenu?.node?.data;
      const payload = {
        resourceId: nodeData?.resourceId,
        imResourceType: {
          data: {
            authenticationPassword: encryptedPassword,
          },
        },
      };

      const response = await InventoryAxios(
        VALIDATE_RESOURCE_PASSWORD,
        "post",
        payload
      );

      if (
        response &&
        response.status === 200 &&
        (response.data?.status === 1 || response.data === true)
      ) {
        setPasswordModalOpen(false);
        if (pendingActionOpt) {
          executeAction(pendingActionOpt, encryptedPassword);
          setPendingActionOpt(null);
        }
      } else {
        setAuthError(true);
      }
    } catch (error) {
      console.error("Password validation failed:", error);
      setAuthError(true);
    } finally {
      // setIsVerifying(false);
    }
  };

  const activeNodeData = contextMenu?.node?.data;

  return (
    <Box
      sx={{
        height: "100%",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        bgcolor: "yellow",
        borderRadius: "none",
        borderRight: (theme) => theme.palette.custom.dashboardBorder,
      }}
    >
      <Paper
        elevation={0}
        sx={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          background: theme.palette.background.toplogybg,
          borderRadius: "0px",
          borderRight: (theme) => theme.palette.custom.dashboardBorder,
        }}
      >
        <Box px={2} py={2}>
          <MInput
            fullWidth
            size="small"
            variant="outlined"
            placeholder="Search Here"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={(theme) => ({
              backgroundColor: theme.palette.background.tabs,
              color: theme.palette.text.primary,
            })}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
        </Box>
        <ScrollContainer style={{ height: "100%" }}>
          <List
            sx={{
              flex: 1,
              overflowY: "auto",
              minHeight: 0,
            }}
          >
            {filteredTree.map((node) => (
              <TreeItem
                key={node.resourceName}
                node={node}
                onRightClick={handleRightClick}
                selected={selected}
                setSelected={setSelected}
                search={search}
                rootClickCount={rootClickCount}
                setRootClickCount={setRootClickCount}
                expandedAll={expandedAll}
                setExpandedAll={setExpandedAll}
              />
            ))}
          </List>
        </ScrollContainer>
        <Menu
          open={Boolean(contextMenu)}
          onClose={handleCloseMenu}
          anchorReference="anchorPosition"
          anchorPosition={
            contextMenu
              ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
              : undefined
          }
          PaperProps={{
            sx: {
              borderRadius: "20px",
              "& .MuiMenuItem-root:hover": {
                color: isDark ? "#fff" : "#14348d",
                fontWeight: 900,
              },
            },
          }}
        >
          {isCnms ? (
            cnmsContextMenuItems(contextMenu?.node)?.map((opt) => (
              <MenuItem
                key={opt.value}
                onClick={() => {
                  executeAction(opt);
                }}
              >
                {opt.icon && <ListItemIcon>{opt.icon}</ListItemIcon>}

                <ListItemText>{opt.label}</ListItemText>
              </MenuItem>
            ))
          ) : (
            <div>
              {getContextMenuItems(contextMenu?.node)?.map((opt) => {
                const nodeType = contextMenu?.node?.type;
                const nodeData = contextMenu?.node?.data;

                const isDiscovered = nodeData?.isDiscovered;
                const isMaintenance = nodeData?.isMaintainance;

                let isDisabled = false;

                if (nodeType === "device") {
                  if (!isDiscovered && !isMaintenance) {
                    isDisabled = true;
                  } else if (!isDiscovered && isMaintenance) {
                    isDisabled = opt.value !== "addDevice";
                  }
                  //sonar
                  // } else if (isDiscovered && !isMaintenance) {
                  //   isDisabled = false;
                  // }
                }


                return opt.submenu?.length > 0 ? (
                  <NestedSubMenu
                    key={opt.value}
                    option={opt}
                    nodeData={nodeData}
                    onAction={(value, data) => {
                      console.log("submenu clicked", value, data);
                    }}
                    closeAll={handleCloseMenu}
                    isDisabled={isDisabled}
                  />
                ) : (
                  <MenuItem
                    key={opt.value || opt.label}
                    disabled={isDisabled}
                    onClick={() => handleMenuOptionClick(opt)}
                  >
                    {opt.icon && <ListItemIcon>{opt.icon}</ListItemIcon>}
                    <ListItemText>{opt.label || opt}</ListItemText>
                  </MenuItem>
                );
              })}
            </div>
          )}
        </Menu>
      </Paper>

      {/* Integrated Password Modal inside TreeSidebar */}
      <PasswordPromptDialog
        open={passwordModalOpen}
        onClose={() => {
          setPasswordModalOpen(false);
          setPendingActionOpt(null);
          setAuthError(false);
        }}
        onSubmit={handlePasswordSubmit}
        resourceName={
          activeNodeData?.resourceName ||
          activeNodeData?.resourceNickName ||
          "Device"
        }
        externalError={authError}
      />
    </Box>
  );
};

export default TreeSidebar;

//   node,
//   level = 0,
//   onRightClick,
//   selected,
//   setSelected,
//   search,
//   rootClickCount,
//   setRootClickCount,
//   expandedAll,
//   setExpandedAll,
// }) => {
//   const dispatch = useDispatch();
//   const [open, setOpen] = useState(node.type === "root" ? true : false);
//   const [allChildrenOpen, setAllChildrenOpen] = useState(false);
//   const hasChildren = node.children?.length > 0;

//   useEffect(() => {
//     if (expandedAll) {
//       setOpen(true);
//     } else if (!search && node.type !== "root") {
//       setOpen(false);
//     }
//   }, [expandedAll]);

//   useEffect(() => {
//     if (node.type === "root" && rootClickCount === 1 && !expandedAll && !search) {
//       setOpen(true);
//     }
//   }, [rootClickCount, expandedAll, search, node.type]);

//   const handleSingleClick = (e) => {
//     e.stopPropagation();

//     if (node.type === "device") {
//       dispatch(setTreeClickedItem(node.data.resourceId));
//     }

//     setSelected(node);

//     if (node.type !== "root") {
//       setOpen(!open);
//       return;
//     }

//     if (rootClickCount === 0) {
//       setOpen(true);
//       setRootClickCount(1);
//     } else if (rootClickCount === 1) {
//       setExpandedAll(true);
//       setRootClickCount(2);
//     } else {
//       setOpen(false);
//       setExpandedAll(false);
//       setRootClickCount(0);
//     }
//   };

//   useEffect(() => {
//     if (search?.trim()) {
//       setOpen(true);
//     } else if (rootClickCount === 0 && node.type !== "root") {
//       setOpen(false);
//       setExpandedAll(false);
//     }
//   }, [search]);

//   const handleDoubleClick = (e) => {
//     e.stopPropagation();
//     if (node.type === "root" || node.type === "segment") {
//       const newState = !open;
//       setOpen(newState);
//       setAllChildrenOpen(newState);
//     }
//   };

//   const getIcon = () => {
//     if (node.type === "root") {
//       return (
//         <Box
//           component="img"
//           src={mctep}
//           alt="root"
//           sx={{
//             width: "20px",
//             filter: (theme) => theme.palette.custom.icon.iconFilter
//           }}
//         />
//       );
//     }
//     if (node.type === "segment") {
//       return node.icon;
//     }

//     if (node.type === "device") {
//       return (
//         <Box sx={{ ml: 5 }}>
//           {node.icon}
//         </Box>
//       );
//     }

//     return null;
//   };

//   // Check unique resource identifier to prevent grouping items with the same name
//   const isSelected = selected
//     ? selected.resourceName === node.resourceName && selected.data?.resourceId === node.data?.resourceId
//     : node.type === "root"; // Default root is highlighted if no selection exists

//   // const getBackgroundColor = () => {
//   //   const isAncestor = (current, target) => {
//   //     if (!current.children || !target) return false;
//   //     return current.children.some(
//   //       (child) =>
//   //         (child.resourceName === target.resourceName && child.data?.resourceId === target.data?.resourceId) ||
//   //         isAncestor(child, target)
//   //     );
//   //   };

//   //   if (isSelected) {
//   //     return node.type === "root" && !selected ? "rgb(200, 214, 247)" : (selected?.resourceName === node.resourceName && selected?.data?.resourceId === node.data?.resourceId ? "rgb(200, 214, 247)" : "rgb(108, 129, 178)");
//   //   }

//   //   if (isAncestor(node, selected)) {
//   //     return "rgb(100, 137, 222)";
//   //   }

//   //   return "transparent";
//   // };
//   const getBackgroundColor = () => {
//     const isAncestor = (current, target) => {
//       if (!current.children || !target) return false;
//       return current.children.some(
//         (child) =>
//           (child.resourceName === target.resourceName && child.data?.resourceId === target.data?.resourceId) ||
//           isAncestor(child, target)
//       );
//     };

//     if (isSelected) {
//       return "rgb(200, 214, 247)";
//     }

//     if (isAncestor(node, selected)) {

//       // Give root and segments different ancestor background tints if desired,
//       // or keep root slightly lighter/different so they don't look identically solid.
//       if (node.type === "root") {
//         return "  rgb(76, 120, 215) "; // Distinct tint for root ancestor
//       }
//       return "rgb(135, 168, 240);"; // Tint for segment ancestor
//     }

//     return "transparent";
//   };
//   const getTextColor = () => {
//     if (isSelected && (selected || node.type === "root")) {
//       return node.type === "root" && !selected ? "#14138d" : (selected?.resourceName === node.resourceName && selected?.data?.resourceId === node.data?.resourceId ? "#14138d" : "inherit");
//     }

//     if (getBackgroundColor() !== "transparent") {
//       return "#000000";
//     }

//     return "inherit";
//   };

//   const isPathNode = (current, target) => {
//     if (!current.children || !target) return false;
//     return current.children.some(
//       (child) =>
//         (child.resourceName === target.resourceName && child.data?.resourceId === target.data?.resourceId) ||
//         isPathNode(child, target)
//     );
//   };

//   const isHighlightedPath = selected
//     ? (selected.resourceName === node.resourceName && selected.data?.resourceId === node.data?.resourceId) || isPathNode(node, selected)
//     : node.type === "root";

//   return (
//     <>
//       <ListItemButton
//         sx={{
//           pl: 1 + level * 2,
//           bgcolor: getBackgroundColor(),
//           color: getTextColor(),
//           "&:hover": {
//             bgcolor: isSelected ? getBackgroundColor() : "#5583e5 ",
//           },
//           gap: 1,
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "space-between",
//           transition: "background-color 0.2s",
//           minHeight: "45px",
//           py: "0.5px",
//           borderRadius: "10px",
//         }}
//         onClick={handleSingleClick}
//         onDoubleClick={handleDoubleClick}
//         onContextMenu={(e) => {
//           e.preventDefault();
//           setSelected(node);
//           onRightClick(e, node);
//         }}
//       >
//         <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//           {hasChildren ? open ? <ExpandMore /> : <ChevronRight /> : null}
//           {getIcon()}
//           <ListItemText
//             primary={node.label}
//             primaryTypographyProps={{
//               fontWeight: isHighlightedPath ? 700 : 400,
//               fontSize: "0.9rem",
//               color: getTextColor(),
//             }}
//           />
//         </Box>
//       </ListItemButton>

//       {hasChildren && (
//         <Collapse
//           in={open}
//           timeout="auto"
//           sx={{
//             position: "relative",
//             "&:before": {
//               content: '""',
//               position: "absolute",
//               top: 0,
//               left: `${18 + level * 18}px`,
//               height: "100%",
//               borderLeft: "1.5px solid #bcbcbc",
//               zIndex: 1,
//             },
//           }}
//         >
//           {node.children.map((child, index) => (
//             <TreeItem
//               key={`${child.resourceName}-${child.data?.resourceId || index}`}
//               node={child}
//               level={level + 1}
//               onRightClick={onRightClick}
//               selected={selected}
//               setSelected={setSelected}
//               search={search}
//               rootClickCount={rootClickCount}
//               setRootClickCount={setRootClickCount}
//               expandedAll={expandedAll}
//               setExpandedAll={setExpandedAll}
//             />
//           ))}
//         </Collapse>
//       )}
//     </>
//   );
// };
// const TreeSidebar = () => {
//   const theme = useTheme();
//   const [selected, setSelected] = useState(null);
//   const [contextMenu, setContextMenu] = useState(null);

//   // Password Prompt States
//   const [passwordModalOpen, setPasswordModalOpen] = useState(false);
//   const [pendingActionOpt, setPendingActionOpt] = useState(null);
//   const [authError, setAuthError] = useState(false);
//   const [isVerifying, setIsVerifying] = useState(false);

//   const [rootClickCount, setRootClickCount] = useState(1);
//   const [expandedAll, setExpandedAll] = useState(false);

//   const resources = useSelector((state) => state.inventory.resources);
//   const segments = useSelector((state) => state.inventory.segments);
//   const [search, setSearch] = useState("");

//   const terminalNickname = useSelector(
//     (state) => state.nodeDetails.siteDetails?.terminalTypeName
//   );

//   const nestedPrivileges = useSelector(
//     (state) => state.userSlice.devicePrivileges
//   );

//   const dispatch = useDispatch();

//   const StyledIcon = ({ src, alt }) => (
//     <Box
//       component="img"
//       src={src}
//       alt={alt}
//       sx={{
//         width: "18px",
//         filter: (theme) => theme.palette.custom.icon.iconFilter,
//       }}
//     />
//   );

//   const segmentIconMap = {
//     1: <StyledIcon src={Satcom} alt="Satcom" />,
//     2: <StyledIcon src={Power} alt="Power" />,
//     3: <StyledIcon src={Base_Band_b} alt="Base_Band_b" />,
//     4: <StyledIcon src={Surveillence} alt="Surveillence" />,
//     6: <StyledIcon src={Radio} alt="Radio" />,
//     8: <StyledIcon src={Voice} alt="Voice" />,
//   };

//   const getContextMenuItems = (node) => {
//     if (!node) return [];

//     if (node.type === "root") {
//       return [
//         { label: "View RNMS Details", value: "rnms" },
//         { label: "Inventory Details", value: "inventoryDetails" },
//       ];
//     }

//     if (node.type === "segment") {
//       return [
//         { label: "View Details", value: "segmentDetails" },
//         { label: "View Active Alarms", value: "segmentAlarms" },
//       ];
//     }

//     if (node.type === "device") {
//       const nodeData = node?.data;
//       const resourceTypeId = nodeData?.imResourceType?.resourceTypeId;
//       const privilegeSet = nestedPrivileges?.[resourceTypeId] || {};
//       const deviceCapabilities = nodeData?.imResourceType?.data || {};

//       const isMaintenance = nodeData?.isMaintainance;
//       const isDiscovered = nodeData?.isDiscovered;

//       return ContextMenuOptions.filter((opt) => {
//         const hasPermission = privilegeSet?.[opt.previlage] === true;
//         const isSupportedByHardware = deviceCapabilities?.[opt.key] !== false;

//         if (!hasPermission || !isSupportedByHardware) {
//           return false;
//         }

//         if (!isDiscovered && isMaintenance) {
//           return opt.value !== "deleteDevice";
//         }

//         if (!isDiscovered && !isMaintenance) {
//           return opt.value !== "addDevice";
//         }

//         if (isDiscovered && !isMaintenance) {
//           return opt.value !== "addDevice";
//         }

//         return true;
//       });
//     }

//     return [];
//   };

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const [segmentRes] = await Promise.all([
//           InventoryAxios(FETCH_ALL_SEGMENTS, "get"),
//           InventoryAxios(
//             FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
//             "post",
//             [1, 2, 3, 4, 5, 6, 7, 8, 9]
//           ),
//         ]);

//         dispatch(
//           setSegments({
//             segments: segmentRes.data,
//           })
//         );
//       } catch (error) {
//         console.error("API Error:", error);
//       }
//     };
//     fetchData();
//   }, [dispatch]);

//   const treeData = useMemo(() => {
//     const root = {
//       resourceName: "root",
//       label: terminalNickname || "Default Root Name",
//       type: "root",
//       children: [],
//     };
//     segments.forEach((segment) => {
//       const segmentNode = {
//         resourceName: `segment-${segment.segmentId}`,
//         label: segment.segmentName,
//         type: "segment",
//         data: segment,
//         icon:
//           segmentIconMap[segment.segmentId] || (
//             <StyledIcon src={searchIcon} alt="Default" />
//           ),
//         children: [],
//       };
//       const devices = resources.filter(
//         (res) => res.imSegmentInfo?.segmentId === segment.segmentId
//       );
//       segmentNode.children = devices
//         .map((device) => ({
//           resourceName: device.resourceName,
//           label: device.resourceName,
//           type: "device",
//           resourceIp: device.resourceIp,
//           status: device.status,
//           data: device,
//           icon: <ResourcesSVG size={18} />,
//         }))
//         .sort((a, b) => a.resourceName.localeCompare(b.resourceName));
//       root.children.push(segmentNode);
//     });
//     return [root];
//   }, [segments, resources, terminalNickname]);

//   const filteredTree = useTreeSearch(treeData, search, {
//     keys: ["label", "resourceName", "resourceIp", "status"],
//     childrenKey: "children",
//   });

//   const handleRightClick = (event, node) => {
//     setContextMenu({
//       mouseX: event.clientX - 2,
//       mouseY: event.clientY - 4,
//       node,
//     });
//   };

//   const handleCloseMenu = () => setContextMenu(null);

//   // Unified execution handler that triggers action dispatch
//   const executeAction = (opt, encryptedPassword = null) => {
//     const nodeData = contextMenu?.node?.type === "device" ? contextMenu.node?.data : (contextMenu?.node?.data || "root");

//     dispatchContextAction({
//       action: opt.value || opt,
//       node: {
//         ...(typeof nodeData === "object" ? nodeData : {}),
//         ...(encryptedPassword ? { password: encryptedPassword } : {}),
//       },
//       source: "tree",
//     });
//     handleCloseMenu();
//   };

//   // Click handler checking if password protection is required
//   // const handleMenuOptionClick = (opt) => {
//   //   const nodeData = contextMenu?.node?.data;
//   //   const deviceCapabilities = nodeData?.imResourceType?.data || {};
//   //   const authConfig = deviceCapabilities?.authentication;
//   //   const expectedEncryptedPassword = deviceCapabilities?.authenticationPassword;
//   //   const authPasswordExists = Boolean(expectedEncryptedPassword);

//   //   const isStatusAction = opt.value === "status" || opt.value === "deviceStatus";

//   //   if (contextMenu?.node?.type === "device" && isStatusAction && authConfig === true && authPasswordExists) {
//   //     setPendingActionOpt(opt);
//   //     setAuthError(false);
//   //     setPasswordModalOpen(true);
//   //   } else {
//   //     executeAction(opt);
//   //   }
//   // };

//   const handleMenuOptionClick = (opt) => {
//     const nodeData = contextMenu?.node?.data;
//     const deviceCapabilities = nodeData?.imResourceType?.data || {};
//     const authConfig = deviceCapabilities?.authentication;
//     const expectedEncryptedPassword = deviceCapabilities?.authenticationPassword;
//     const authPasswordExists = Boolean(expectedEncryptedPassword);

//     const isStatusAction = opt.value === "status" || opt.value === "deviceStatus";

//     if (contextMenu?.node?.type === "device" && isStatusAction && authConfig === true && authPasswordExists) {
//       setPendingActionOpt(opt);
//       setAuthError(false);
//       setPasswordModalOpen(true);
//     } else {
//       executeAction(opt);
//     }
//   };

//   const handlePasswordSubmit = async (encryptedPassword) => {
//     setIsVerifying(true);
//     setAuthError(false);

//     try {
//       const nodeData = contextMenu?.node?.data;
//       const payload = {
//         resourceId: nodeData?.resourceId,
//         imResourceType: {
//           data: {
//             authenticationPassword: encryptedPassword,
//           },
//         },
//       };

//       const response = await InventoryAxios(
//         VALIDATE_RESOURCE_PASSWORD,
//         "post",
//         payload
//       );

//       if (
//         response &&
//         response.status === 200 &&
//         (response.data?.status === 1 || response.data === true)
//       ) {
//         setPasswordModalOpen(false);
//         if (pendingActionOpt) {
//           executeAction(pendingActionOpt, encryptedPassword);
//           setPendingActionOpt(null);
//         }
//       } else {
//         setAuthError(true);
//       }
//     } catch (error) {
//       console.error("Password validation failed:", error);
//       setAuthError(true);
//     } finally {
//       setIsVerifying(false);
//     }
//   };

//   const activeNodeData = contextMenu?.node?.data;

//   return (
//     <Box
//       sx={{
//         height: "100%",
//         width: "100%",
//         display: "flex",
//         flexDirection: "column",
//         overflow: "hidden",
//         bgcolor: 'yellow',
//         borderRadius: "none",
//         borderRight: (theme) => theme.palette.custom.dashboardBorder,

//       }}
//     >
//       <Paper
//         elevation={0}
//         sx={{
//           width: "100%",
//           height: "100%",
//           display: "flex",
//           flexDirection: "column",
//           overflow: "hidden",
//           background: theme.palette.background.toplogybg,
//           borderRadius: "0px",
//           borderRight: (theme) => theme.palette.custom.dashboardBorder,
//         }}
//       >
//         <Box px={2} py={2}>
//           <MInput
//             fullWidth
//             size="small"
//             variant="outlined"
//             placeholder="Search Here"
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             sx={(theme) => ({
//               backgroundColor: theme.palette.background.tabs,
//               color: theme.palette.text.primary,
//             })}
//             InputProps={{
//               startAdornment: (
//                 <InputAdornment position="start">
//                   <Search fontSize="small" />
//                 </InputAdornment>
//               ),
//             }}
//           />
//         </Box>
//         <ScrollContainer style={{ height: "100%" }}>
//           <List
//             sx={{
//               flex: 1,
//               overflowY: "auto",
//               minHeight: 0,
//             }}
//           >
//             {filteredTree.map((node) => (
//               <TreeItem
//                 key={node.resourceName}
//                 node={node}
//                 onRightClick={handleRightClick}
//                 selected={selected}
//                 setSelected={setSelected}
//                 search={search}
//                 rootClickCount={rootClickCount}
//                 setRootClickCount={setRootClickCount}
//                 expandedAll={expandedAll}
//                 setExpandedAll={setExpandedAll}
//               />
//             ))}
//           </List>
//         </ScrollContainer>
//         <Menu
//           open={Boolean(contextMenu)}
//           onClose={handleCloseMenu}
//           anchorReference="anchorPosition"
//           anchorPosition={
//             contextMenu
//               ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
//               : undefined
//           }
//           PaperProps={{
//             sx: {
//               borderRadius: "20px",
//               "& .MuiMenuItem-root:hover": {
//                 color: "#14348D",
//                 fontWeight: 900,
//               },
//             },
//           }}
//         >
//           {getContextMenuItems(contextMenu?.node)?.map((opt) => {
//             const nodeType = contextMenu?.node?.type;
//             const nodeData = contextMenu?.node?.data;

//             const isDiscovered = nodeData?.isDiscovered;
//             const isMaintenance = nodeData?.isMaintainance;

//             let isDisabled = false;

//             if (nodeType === "device") {
//               if (!isDiscovered && !isMaintenance) {
//                 isDisabled = true;
//               } else if (!isDiscovered && isMaintenance) {
//                 isDisabled = opt.value !== "addDevice";
//               } else if (isDiscovered && !isMaintenance) {
//                 isDisabled = false;
//               }
//             }

//             return opt.submenu?.length > 0 ? (
//               <NestedSubMenu
//                 key={opt.value}
//                 option={opt}
//                 nodeData={nodeData}
//                 onAction={(value, data) => {
//                   console.log("submenu clicked", value, data);
//                 }}
//                 closeAll={handleCloseMenu}
//                 isDisabled={isDisabled}
//               />
//             ) : (
//               <MenuItem
//                 key={opt.value || opt.label}
//                 disabled={isDisabled}
//                 onClick={() => handleMenuOptionClick(opt)}
//               >
//                 {opt.icon && <ListItemIcon>{opt.icon}</ListItemIcon>}
//                 <ListItemText>{opt.label || opt}</ListItemText>
//               </MenuItem>
//             );
//           })}
//         </Menu>
//       </Paper>

//       {/* Integrated Password Modal inside TreeSidebar */}
//       <PasswordPromptDialog
//         open={passwordModalOpen}
//         onClose={() => {
//           setPasswordModalOpen(false);
//           setPendingActionOpt(null);
//           setAuthError(false);
//         }}
//         onSubmit={handlePasswordSubmit}
//         resourceName={
//           activeNodeData?.resourceName || activeNodeData?.resourceNickName || "Device"
//         }
//         externalError={authError}
//       />
//     </Box>
//   );
// };

// export default TreeSidebar;

// const TreeItem = ({
//   node,
//   level = 0,
//   onRightClick,
//   selected,
//   setSelected,
//   search,
//   rootClickCount,
//   setRootClickCount,
//   expandedAll,
//   setExpandedAll,
// }) => {
//   const dispatch = useDispatch();
//   const [open, setOpen] = useState(node.type === "root" ? true : false);
//   const [allChildrenOpen, setAllChildrenOpen] = useState(false);
//   const hasChildren = node.children?.length > 0;

//   useEffect(() => {
//     if (expandedAll) {
//       setOpen(true);
//     } else if (!search && node.type !== "root") {
//       setOpen(false);
//     }
//   }, [expandedAll]);

//   useEffect(() => {
//     if (node.type === "root" && rootClickCount === 1 && !expandedAll && !search) {
//       setOpen(true);
//     }
//   }, [rootClickCount, expandedAll, search, node.type]);

//   const handleSingleClick = (e) => {
//     e.stopPropagation();

//     if (node.type === "device") {
//       dispatch(setTreeClickedItem(node.data.resourceId));
//     }

//     setSelected(node);

//     if (node.type !== "root") {
//       setOpen(!open);
//       return;
//     }

//     if (rootClickCount === 0) {
//       setOpen(true);
//       setRootClickCount(1);
//     } else if (rootClickCount === 1) {
//       setExpandedAll(true);
//       setRootClickCount(2);
//     } else {
//       setOpen(false);
//       setExpandedAll(false);
//       setRootClickCount(0);
//     }
//   };

//   useEffect(() => {
//     if (search?.trim()) {
//       setOpen(true);
//     } else if (rootClickCount === 0 && node.type !== "root") {
//       setOpen(false);
//       setExpandedAll(false);
//     }
//   }, [search]);

//   const handleDoubleClick = (e) => {
//     e.stopPropagation();
//     if (node.type === "root" || node.type === "segment") {
//       const newState = !open;
//       setOpen(newState);
//       setAllChildrenOpen(newState);
//     }
//   };

//   const getIcon = () => {
//     if (node.type === "root") {
//       return (
//         <Box
//           component="img"
//           src={mctep}
//           alt="root"
//           sx={{
//             width: "20px",
//             filter: (theme) => theme.palette.custom.icon.iconFilter
//           }}
//         />
//       );
//     }
//     if (node.type === "segment") {
//       return node.icon;
//     }

//     if (node.type === "device") {
//       return (
//         <Box sx={{ ml: 5 }}>
//           {node.icon}
//         </Box>
//       );
//     }

//     return null;
//   };

//   // Check unique resource identifier to prevent grouping items with the same name
//   const isSelected = selected
//     ? selected.resourceName === node.resourceName && selected.data?.resourceId === node.data?.resourceId
//     : node.type === "root"; // Default root is highlighted if no selection exists

//   // const getBackgroundColor = () => {
//   //   const isAncestor = (current, target) => {
//   //     if (!current.children || !target) return false;
//   //     return current.children.some(
//   //       (child) =>
//   //         (child.resourceName === target.resourceName && child.data?.resourceId === target.data?.resourceId) ||
//   //         isAncestor(child, target)
//   //     );
//   //   };

//   //   if (isSelected) {
//   //     return node.type === "root" && !selected ? "rgb(200, 214, 247)" : (selected?.resourceName === node.resourceName && selected?.data?.resourceId === node.data?.resourceId ? "rgb(200, 214, 247)" : "rgb(108, 129, 178)");
//   //   }

//   //   if (isAncestor(node, selected)) {
//   //     return "rgb(100, 137, 222)";
//   //   }

//   //   return "transparent";
//   // };
//   const getBackgroundColor = () => {
//     const isAncestor = (current, target) => {
//       if (!current.children || !target) return false;
//       return current.children.some(
//         (child) =>
//           (child.resourceName === target.resourceName && child.data?.resourceId === target.data?.resourceId) ||
//           isAncestor(child, target)
//       );
//     };

//     if (isSelected) {
//       return "rgb(200, 214, 247)";
//     }

//     if (isAncestor(node, selected)) {

//       // Give root and segments different ancestor background tints if desired,
//       // or keep root slightly lighter/different so they don't look identically solid.
//       if (node.type === "root") {
//         return "  rgb(76, 120, 215) "; // Distinct tint for root ancestor
//       }
//       return "rgb(135, 168, 240);"; // Tint for segment ancestor
//     }

//     return "transparent";
//   };
//   const getTextColor = () => {
//     if (isSelected && (selected || node.type === "root")) {
//       return node.type === "root" && !selected ? "#14138d" : (selected?.resourceName === node.resourceName && selected?.data?.resourceId === node.data?.resourceId ? "#14138d" : "inherit");
//     }

//     if (getBackgroundColor() !== "transparent") {
//       return "#000000";
//     }

//     return "inherit";
//   };

//   const isPathNode = (current, target) => {
//     if (!current.children || !target) return false;
//     return current.children.some(
//       (child) =>
//         (child.resourceName === target.resourceName && child.data?.resourceId === target.data?.resourceId) ||
//         isPathNode(child, target)
//     );
//   };

//   const isHighlightedPath = selected
//     ? (selected.resourceName === node.resourceName && selected.data?.resourceId === node.data?.resourceId) || isPathNode(node, selected)
//     : node.type === "root";

//   return (
//     <>
//       <ListItemButton
//         sx={{
//           pl: 1 + level * 2,
//           bgcolor: getBackgroundColor(),
//           color: getTextColor(),
//           "&:hover": {
//             bgcolor: isSelected ? getBackgroundColor() : "#5583e5 ",
//           },
//           gap: 1,
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "space-between",
//           transition: "background-color 0.2s",
//           minHeight: "45px",
//           py: "0.5px",
//           borderRadius: "10px",
//         }}
//         onClick={handleSingleClick}
//         onDoubleClick={handleDoubleClick}
//         onContextMenu={(e) => {
//           e.preventDefault();
//           setSelected(node);
//           onRightClick(e, node);
//         }}
//       >
//         <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//           {hasChildren ? open ? <ExpandMore /> : <ChevronRight /> : null}
//           {getIcon()}
//           <ListItemText
//             primary={node.label}
//             primaryTypographyProps={{
//               fontWeight: isHighlightedPath ? 700 : 400,
//               fontSize: "0.9rem",
//               color: getTextColor(),
//             }}
//           />
//         </Box>
//       </ListItemButton>

//       {hasChildren && (
//         <Collapse
//           in={open}
//           timeout="auto"
//           sx={{
//             position: "relative",
//             "&:before": {
//               content: '""',
//               position: "absolute",
//               top: 0,
//               left: `${18 + level * 18}px`,
//               height: "100%",
//               borderLeft: "1.5px solid #bcbcbc",
//               zIndex: 1,
//             },
//           }}
//         >
//           {node.children.map((child, index) => (
//             <TreeItem
//               key={`${child.resourceName}-${child.data?.resourceId || index}`}
//               node={child}
//               level={level + 1}
//               onRightClick={onRightClick}
//               selected={selected}
//               setSelected={setSelected}
//               search={search}
//               rootClickCount={rootClickCount}
//               setRootClickCount={setRootClickCount}
//               expandedAll={expandedAll}
//               setExpandedAll={setExpandedAll}
//             />
//           ))}
//         </Collapse>
//       )}
//     </>
//   );
// };

// const TreeSidebar = () => {
//   const theme = useTheme();
//   const [selected, setSelected] = useState(null);
//   const [contextMenu, setContextMenu] = useState(null);

//   const [rootClickCount, setRootClickCount] = useState(1);
//   const [expandedAll, setExpandedAll] = useState(false);

//   const resources = useSelector((state) => state.inventory.resources);
//   const segments = useSelector((state) => state.inventory.segments);
//   const [search, setSearch] = useState("");

//   const terminalNickname = useSelector(
//     (state) => state.nodeDetails.siteDetails?.terminalTypeName
//   );

//   const nestedPrivileges = useSelector(
//     (state) => state.userSlice.devicePrivileges
//   );

//   const dispatch = useDispatch();

//   const StyledIcon = ({ src, alt }) => (
//     <Box
//       component="img"
//       src={src}
//       alt={alt}
//       sx={{
//         width: "18px",
//         filter: (theme) => theme.palette.custom.icon.iconFilter,
//       }}
//     />
//   );

//   const segmentIconMap = {
//     1: <StyledIcon src={Satcom} alt="Satcom" />,
//     2: <StyledIcon src={Power} alt="Power" />,
//     3: <StyledIcon src={Base_Band_b} alt=" Base_Band_b" />,
//     4: <StyledIcon src={Surveillence} alt="Surveillence" />,
//     6: <StyledIcon src={Radio} alt="Radio" />,
//     8: <StyledIcon src={Voice} alt="Voice" />,
//   };

//   const getContextMenuItems = (node) => {
//     if (!node) return [];

//     if (node.type === "root") {
//       return [
//         { label: "View RNMS Details", value: "rnms" },
//         { label: "Inventory Details", value: "inventoryDetails" },
//       ];
//     }

//     if (node.type === "segment") {
//       return [
//         { label: "View Details", value: "segmentDetails" },
//         { label: "View Active Alarms", value: "segmentAlarms" },
//       ];
//     }

//     if (node.type === "device") {
//       const nodeData = node?.data;
//       const resourceTypeId = nodeData?.imResourceType?.resourceTypeId;
//       const privilegeSet = nestedPrivileges?.[resourceTypeId] || {};
//       const deviceCapabilities = nodeData?.imResourceType?.data || {};

//       const isMaintenance = nodeData?.isMaintainance;
//       const isDiscovered = nodeData?.isDiscovered;

//       return ContextMenuOptions.filter((opt) => {
//         const hasPermission = privilegeSet?.[opt.previlage] === true;
//         const isSupportedByHardware = deviceCapabilities?.[opt.key] !== false;

//         if (!hasPermission || !isSupportedByHardware) {
//           return false;
//         }

//         if (!isDiscovered && isMaintenance) {
//           return opt.value !== "deleteDevice";
//         }

//         if (!isDiscovered && !isMaintenance) {
//           return opt.value !== "addDevice";
//         }

//         if (isDiscovered && !isMaintenance) {
//           return opt.value !== "addDevice";
//         }

//         return true;
//       });
//     }

//     return [];
//   };

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const [segmentRes, resourceRes] = await Promise.all([
//           InventoryAxios(FETCH_ALL_SEGMENTS, "get"),
//           InventoryAxios(
//             FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
//             "post",
//             [1, 2, 3, 4, 5, 6, 7, 8, 9]
//           ),
//         ]);

//         dispatch(
//           setSegments({
//             segments: segmentRes.data,
//           })
//         );
//       } catch (error) {
//         console.error("API Error:", error);
//       }
//     };
//     fetchData();
//   }, [dispatch]);

//   const treeData = useMemo(() => {
//     const root = {
//       resourceName: "root",
//       label: terminalNickname || "Default Root Name",
//       type: "root",
//       children: [],
//     };
//     segments.forEach((segment) => {
//       const segmentNode = {
//         resourceName: `segment-${segment.segmentId}`,
//         label: segment.segmentName,
//         type: "segment",
//         data: segment,
//         icon:
//           segmentIconMap[segment.segmentId] || (
//             <StyledIcon src={searchIcon} alt="Default" />
//           ),
//         children: [],
//       };
//       const devices = resources.filter(
//         (res) => res.imSegmentInfo?.segmentId === segment.segmentId
//       );
//       segmentNode.children = devices
//         .map((device) => ({
//           resourceName: device.resourceName,
//           label: device.resourceName,
//           type: "device",
//           resourceIp: device.resourceIp,
//           status: device.status,
//           data: device,
//           icon: <ResourcesSVG size={18} />,
//         }))
//         .sort((a, b) => a.resourceName.localeCompare(b.resourceName));
//       root.children.push(segmentNode);
//     });
//     return [root];
//   }, [segments, resources, terminalNickname]);

//   const filteredTree = useTreeSearch(treeData, search, {
//     keys: ["label", "resourceName", "resourceIp", "status"],
//     childrenKey: "children",
//   });

//   const handleRightClick = (event, node) => {
//     setContextMenu({
//       mouseX: event.clientX - 2,
//       mouseY: event.clientY - 4,
//       node,
//     });
//   };

//   const handleCloseMenu = () => setContextMenu(null);

//   return (
//     <Box
//       sx={{
//         height: "100%",
//         width: "100%",
//         display: "flex",
//         flexDirection: "column",
//         overflow: "hidden",
//         bgcolor: 'yellow',
//         borderRadius: "none"
//       }}
//     >
//       <Paper
//         elevation={0}
//         sx={{
//           width: "100%",
//           height: "100%",
//           display: "flex",
//           flexDirection: "column",
//           overflow: "hidden",
//           background: theme.palette.background.toplogybg,
//           borderRadius: "0px",
//           borderRight: (theme) => theme.palette.custom.dashboardBorder,
//         }}
//       >
//         <Box px={2} py={2}>
//           <MInput
//             fullWidth
//             size="small"
//             variant="outlined"
//             placeholder="Search Here"
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             sx={(theme) => ({
//               backgroundColor: theme.palette.background.tabs,
//               color: theme.palette.text.primary,
//             })}
//             InputProps={{
//               startAdornment: (
//                 <InputAdornment position="start">
//                   <Search fontSize="small" />
//                 </InputAdornment>
//               ),
//             }}
//           />
//         </Box>
//         <ScrollContainer style={{ height: "100%" }}>
//           <List
//             sx={{
//               flex: 1,
//               overflowY: "auto",
//               minHeight: 0,
//             }}
//           >
//             {filteredTree.map((node) => (
//               <TreeItem
//                 key={node.resourceName}
//                 node={node}
//                 onRightClick={handleRightClick}
//                 selected={selected}
//                 setSelected={setSelected}
//                 search={search}
//                 rootClickCount={rootClickCount}
//                 setRootClickCount={setRootClickCount}
//                 expandedAll={expandedAll}
//                 setExpandedAll={setExpandedAll}
//               />
//             ))}
//           </List>
//         </ScrollContainer>
//         <Menu
//           open={Boolean(contextMenu)}
//           onClose={handleCloseMenu}
//           anchorReference="anchorPosition"
//           anchorPosition={
//             contextMenu
//               ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
//               : undefined
//           }
//           PaperProps={{
//             sx: {
//               borderRadius: "20px",
//               "& .MuiMenuItem-root:hover": {
//                 color: "#14348D",
//                 fontWeight: 900,
//               },
//             },
//           }}
//         >
//           {getContextMenuItems(contextMenu?.node)?.map((opt) => {
//             const nodeType = contextMenu?.node?.type;
//             const nodeData = contextMenu?.node?.data;

//             const isDiscovered = nodeData?.isDiscovered;
//             const isMaintenance = nodeData?.isMaintainance;

//             let isDisabled = false;

//             if (nodeType === "device") {
//               if (!isDiscovered && !isMaintenance) {
//                 isDisabled = true;
//               } else if (!isDiscovered && isMaintenance) {
//                 isDisabled = opt.value !== "addDevice";
//               } else if (isDiscovered && !isMaintenance) {
//                 isDisabled = false;
//               }
//             }

//             return opt.submenu?.length > 0 ? (
//               <NestedSubMenu
//                 key={opt.value}
//                 option={opt}
//                 nodeData={nodeData}
//                 onAction={(value, data) => {
//                   console.log("submenu clicked", value, data);
//                 }}
//                 closeAll={handleCloseMenu}
//                 isDisabled={isDisabled}
//               />
//             ) : (
//               <MenuItem
//                 key={opt.value || opt.label}
//                 disabled={isDisabled}
//                 onClick={() => {
//                   dispatchContextAction({
//                     action: opt.value,
//                     node: contextMenu.node?.data || "root",
//                     source: "tree",
//                   });
//                   handleCloseMenu();
//                 }}
//               >
//                 <ListItemText>{opt.label || opt}</ListItemText>
//               </MenuItem>
//             );
//           })}
//         </Menu>
//       </Paper>
//     </Box>
//   );
// };

// export default TreeSidebar;
