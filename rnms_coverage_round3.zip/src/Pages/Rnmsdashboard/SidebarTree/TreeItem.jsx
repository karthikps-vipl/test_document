/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : SidebarTree 
   File Name                : TreeItem.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\SidebarTree\TreeItem.jsx
   Purpose                  : Created the TreeItem for toggling the expandmore of treeItem and also added the ChevronRight icon
   Created Date             : 02-04-2026
 ***********************************************************************************************/

import React, { useEffect } from "react";
import {
  ListItemButton,
  ListItemText,
  Collapse,
  Box
} from "@mui/material";
import { ExpandMore, ChevronRight } from "@mui/icons-material";

const TreeItem = ({
  node,
  level = 0,
  onRightClick,
  selected,
  setSelected,
  search,
  expandedNode,
  setExpandedNode,
}) => {
  const hasChildren = node.children?.length > 0;

  const isOpen = expandedNode === node.resourceName;

  useEffect(() => {
    if (search && hasChildren) {
      setExpandedNode(node.resourceName);
    }
  }, [search]);

  const handleClick = () => {
    setSelected(node);

    if (hasChildren) {
      setExpandedNode(isOpen ? null : node.resourceName);
    }
  };

  return (
    <>
      <Box
        sx={{
          position: "relative",
          pl: 2 + level * 3,
        }}
      >
        {/* Vertical Left Border Line */}
        {level > 0 && (
          <Box
            sx={{
              position: "absolute",
              left: level * 19,
              top: 0,
              bottom: 0,
              borderLeft: "2px solid #d0d0d0",
            }}
          />
        )}

        <ListItemButton
          sx={{
            bgcolor:
              selected?.resourceName === node.resourceName
                ? "#e3f2fd"
                : "transparent",
            display: "flex",
            alignItems: "center",
            gap: 1
          }}
          onClick={handleClick}
          onContextMenu={(e) => {
            e.preventDefault();
            setSelected(node);
            onRightClick(e, node);
          }}
        >
          {node.icon}
          <ListItemText primary={node.label} />

          {hasChildren &&
            (isOpen ? <ExpandMore /> : <ChevronRight />)}
        </ListItemButton>
      </Box>

      {hasChildren && (
        <Collapse in={isOpen} timeout="auto" unmountOnExit>
          {node.children.map((child) => (
            <TreeItem
              key={child.resourceName}
              node={child}
              level={level + 1 }
              onRightClick={onRightClick}
              selected={selected}
              setSelected={setSelected}
              search={search}
              expandedNode={expandedNode}
              setExpandedNode={setExpandedNode}
            />
          ))}
        </Collapse>
      )}
    </>
  );
};

export default TreeItem;