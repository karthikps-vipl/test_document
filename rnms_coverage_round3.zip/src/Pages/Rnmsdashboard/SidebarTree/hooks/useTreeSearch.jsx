/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : SidebarTree 
   File Name                : useTreeSearch.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\SidebarTree\hooks\useTreeSearch.jsx
   Purpose                  : Created the useTreeSearch for search functionality of treeView
   Created Date             : 01-04-2026
 ***********************************************************************************************/

import { useMemo } from "react";
import { searchTree } from "../../../../utility/treeSearch";

export const useTreeSearch = (treeData, search, options = {}) => {
  return useMemo(() => {
    if (!search) return treeData;

    return treeData
      .map((node) => searchTree(node, search, options))
      .filter(Boolean);
  }, [treeData, search, options]);
};
