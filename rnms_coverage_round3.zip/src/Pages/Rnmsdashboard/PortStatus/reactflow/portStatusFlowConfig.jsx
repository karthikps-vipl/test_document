import { ReactFlowPortStatusNode } from "../components/ReactFlowPortStatusNode";

export const portStatusNodeTypes = {
  portStatusNode: ReactFlowPortStatusNode,
};

export function createPortStatusNodes(devices) {
  return devices.map((device, index) => ({
    id: device.id,
    type: "portStatusNode",
    position: {
      x: 80,
      y: index * 420,
    },
    data: {
      device,
    },
  }));
}
