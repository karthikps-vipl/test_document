import { Handle, Position } from "reactflow";
// import { PortStatusSwitch } from "./PortStatusSwitch";
import React from "react";

export function ReactFlowPortStatusNode({ data }) {
  return (
    <div className="reactflow-port-node">
      <Handle position={Position.Left} type="target" />
      {/* <PortStatusSwitch device={data.device} /> */}
      <Handle position={Position.Right} type="source" />
    </div>
  );
}
