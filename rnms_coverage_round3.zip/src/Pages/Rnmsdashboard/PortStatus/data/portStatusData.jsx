import down from "../../../../assets/PortStatus/Admin Down.svg";
import operational_down from "../../../../assets/PortStatus/Down.svg";
import portUp from "../../../../assets/PortStatus/Up.svg";
import portNotConfigured from "../../../../assets/PortStatus/Not Configured.svg";


export const PORT_STATUS_META = {
  up: {
    label: "Up",
    color: "#8fd3a8",
    icon: portUp,
  },
  down: {
    label: "Down",
    color: "#ef4747",
    icon: down,
  },
  operational_down: {
    label: "Operational down",
    color: "#fbc02d",
    icon: operational_down,
  },
  notConfigured: {
    label: "Not Configured",
    color: "#808080",
    icon: portNotConfigured,
  },
};

function createSeededRandom(seed) {
  let state = seed
    .split("")
    .reduce((sum, char, index) => sum + char.charCodeAt(0) * (index + 1), 0);

  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

function buildPorts(prefix, total, statusPool) {
  const random = createSeededRandom(`${prefix}-${total}`);

  return Array.from({ length: total }, (_, index) => ({
    id: `${prefix}-${index + 1}`,
    name: `GigabitEthernet0/${index + 1}`,
    status: statusPool[Math.floor(random() * statusPool.length)],
  }));
}



// export const networkDevices = [
//   {
//     id: "switch-l3-01",
//     title: "L3 Switch",
//     site: "Core Network",                         
//     portCount: 24,
//     shellType: "svg24",
//     ports: buildPorts("l3", 24, [
//       "adminDown",
//       "up",
//       "down",
//       "up",
//       "notConfigured",
//       "up",
//     ]),
//   },
//   {
//     id: "switch-ofc-01",
//     title: "Router + Call Manager OFC",
//     site: "Branch Edge",
//     portCount: 6,
//     shellType: "svg6",
//     ports: buildPorts("ofc", 6, ["notConfigured", "up", "down", "up"]),
//   },
// ];
