import React, { useRef } from "react";
import { PORT_STATUS_META } from "./data/portStatusData";
import switch24Shell from "../../../assets/PortStatus/port.svg";
import { useTheme } from "@mui/material";

function PortFace({ port, registerPortRef, direction, index, totalInRow }) {
  console.log("uhfvjfports", port);

  const meta = PORT_STATUS_META[port.status] ?? PORT_STATUS_META.notConfigured;

  // Mathematical distribution: ensures the first port is at 0% and last is at 100%
  const leftPosition = totalInRow <= 1 ? 50 : index * (100 / (totalInRow - 1));
  const theme = useTheme();
  return (
    <div
      className={`port-item ${direction}`}
      style={{ left: `${leftPosition}%` }}
    >
      {/* If top row, name is above. If bottom row, name is below. */}
      {direction === "top" && (
        <span
          className="port-name "
          style={{ color: theme.palette.text.porttextcolor }}
        >
          {port.name}
        </span>
      )}

      <button
        className="port-face"
        type="button"
        title={`${port.name} - ${meta.label}`}
        ref={registerPortRef(port.id)}
      >
        <img src={meta.icon} alt="" aria-hidden="true" />
      </button>

      {direction === "bottom" && (
        <span
          className="port-name"
          style={{ color: theme.palette.text.porttextcolor }}
        >
          {port.name}
        </span>
      )}
    </div>
  );
}

function PortRows({
  topRowPorts,
  bottomRowPorts,
  specialPorts,
  registerPortRef,
}) {
  return (
    <div className="switch-port-container">
      {/* Top Row (12 ports: 1, 3, 5... 23) */}
      <div className="switch-port-grid top-row">
        {topRowPorts.map((port, index) => (
          <PortFace
            key={port.id}
            index={index}
            totalInRow={topRowPorts.length}
            port={port}
            registerPortRef={registerPortRef}
            direction="top"
          />
        ))}
      </div>

      {/* Bottom Row (12 ports: 2, 4, 6... 24) */}
      <div className="switch-port-grid bottom-row">
        {bottomRowPorts.map((port, index) => (
          <PortFace
            key={port.id}
            index={index}
            totalInRow={bottomRowPorts.length}
            port={port}
            registerPortRef={registerPortRef}
            direction="bottom"
          />
        ))}
      </div>

      {/* Special Last 4 Ports (25, 26, 27, 28) - Fully Customizable Position & Size */}
      {specialPorts && specialPorts.length > 0 && (
        <div className="special-ports-layer">
          {specialPorts.map((port, index) => (
            <PortFace
              key={port.id}
              index={index}
              totalInRow={specialPorts.length}
              port={port}
              registerPortRef={registerPortRef}
              direction="bottom"
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function PortStatusSwitch({ device }) {
  const portRefs = useRef(new Map());

  /*
   * Separate TenGigabitEthernet ports from normal ports.
   *
   * IMPORTANT:
   * Do NOT use ifindex >= 25 here.
   * Different devices can have different ifindex values.
   */
  const specialPorts = device.ports.filter(
    (port) => port.isTenGigabit === true
  );

  const regularPorts = device.ports.filter(
    (port) => port.isTenGigabit !== true
  );

  /*
   * IMPORTANT:
   * Use the actual ifindex to determine the row.
   *
   * 1,3,5,7...  -> top row
   * 2,4,6,8...  -> bottom row
   *
   * This prevents ports from shifting position when a WebSocket
   * message comes with ifdesc = null.
   */
  const topRowPorts = regularPorts.filter(
    (port) => Number(port.visualIndex) % 2 === 1
  );
  
  const bottomRowPorts = regularPorts.filter(
    (port) => Number(port.visualIndex) % 2 === 0
  );

  const registerPortRef = (portId) => (node) => {
    if (node) portRefs.current.set(portId, node);
    else portRefs.current.delete(portId);
  };

  return (
    <article className="switch-card">
      <header className="switch-header">
        <h3 className="switch-title">{device.title}</h3>
      </header>
      <div className="switch-body-panel">
        <img
          className="switch-background"
          src={switch24Shell}
          alt="switch shell"
        />
        <div className="ports-layer">
          <PortRows
            topRowPorts={topRowPorts}
            bottomRowPorts={bottomRowPorts}
            specialPorts={specialPorts}
            registerPortRef={registerPortRef}
          />
        </div>
      </div>
    </article>
  );
}
