/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : portStatus 
   File Name                : PortStatusBoard.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\PortStatus\PortStatusBoard.jsx
   Purpose                  : Indicating the color of port status and rendering the switch status
   Created Date             : 13-04-2026
 ***********************************************************************************************/

// import { useTheme } from "@mui/material";
// import { PORT_STATUS_META } from "./data/portStatusData";
// import React from "react";
// import { PortStatusSwitch } from "./PortStatusSwitch";

// export function PortStatusBoard({ devices }) {
//   const theme = useTheme(); // 5. Access theme for the board shell
  
//   const boardBgColor = theme.palette.mode === 'dark' ? 'rgba(214, 209, 209, 0.8)' : '#ffffff';

//   return (
//     <section 
//       className="board-shell"
//       style={{ 
//         backgroundColor: boardBgColor, // 6. Apply background to the whole board
//         transition: 'background-color 0.3s ease' 
//       }}
//     >
//       <div className="device-stack-wrapper">
//         <div className="device-stack">
//           {devices.map((device) => (
//             <div className="device-row" key={device.id}>
//               <PortStatusSwitch device={device} />
//             </div >
//           ))}
//         </div >
//       </div >
//     </section>
//   );
// }


import { useTheme } from "@mui/material";
import React from "react";
import { PortStatusSwitch } from "./PortStatusSwitch";

export function PortStatusBoard({ devices }) {
  const theme = useTheme(); // 5. Access theme for the board shell
  
  const boardBgColor = theme.palette.mode === 'dark' ? 'rgb(84, 84, 84)' : '#ffffff';

  return (
    <section 
      className="board-shell"
      style={{ 
        backgroundColor: boardBgColor, // 6. Apply background to the whole board
        transition: 'background-color 0.3s ease' 
      }}
    >
      <div className="device-stack-wrapper">
        <div className="device-stack">
          {devices.map((device) => (
            <div className="device-row" key={device.id}>
              <PortStatusSwitch device={device} />
            </div >
          ))}
        </div >
      </div >
    </section>
  );
}
