/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : portStatus 
   File Name                : index.jsx
   Author                   : ARUN - VIPL
   Package                  : src\Pages\Rnmsdashboard\PortStatus\index.jsx
   Purpose                  : Main file that calls PortStatusBoard
   Created Date             : 13-04-2026
 ***********************************************************************************************/

// import { PortStatusBoard } from "./PortStatusBoard";

// import React, { useMemo } from "react";
// import "./style.css";
// import { useSelector } from "react-redux";
// import { mapOpStatus } from "../Topology/topologyConstants";
// import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
// import { useTheme } from "@mui/material";
// import LegendStatus from "./LegendStatus";
// import { filterSwitchPorts } from "@/utility/portFilterUtils";

// function PortStatus() {
//   const theme = useTheme();
//   const bgColor = theme.palette.mode === 'dark' ? '#1e1e1e' : '#ffffff';

//   const availableResources = useSelector(
//     (state) => state.portStatusSlice.availableResources
//   );

//   console.log("jdbvhbavailableResources",availableResources);

//   const transformedDevices = useMemo(() => {
//     if (!availableResources) return [];
//     return availableResources.map((device) => {
//       const needsFiltering = filterSwitchPorts(device.resourceId);

//       // 1. Get the initial port list
//       let portList = needsFiltering
//         ? filterSwitchPorts(device.lstPortInfoDtl)
//         : (device.lstPortInfoDtl || []);

//       // 2. SORT the ports by ifindex numerically
//       // This ensures that ifindex 1 comes before ifindex 5, etc.
//       const sortedPortList = [...portList].sort((a, b) => a.ifindex - b.ifindex);

//       return {
//         id: device.resourceId,
//         title: device.resourceName,
//         site: device.imSegmentInfo?.segmentName || "Unknown Site",
//         ports: sortedPortList.map((port) => ({
//           id: `${device.resourceId}-${port.ifindex}`,
//           name: port.ifdesc || `Port ${port.ifindex}`,
//           status: mapOpStatus(port.opstatus, port.adminstatus),
//         })),
//       };
//     });
//   }, [availableResources]);

//   return (
//     <ScrollContainer
//       className="h-full"
//       style={{ backgroundColor: bgColor }}
//     >
//       <main className="app-shell" style={{ backgroundColor: bgColor }}>
//         <div style={{ display: 'flex', flexDirection: 'column', minHeight: "100vh" }}>
//           {transformedDevices.length > 0 && <LegendStatus />}
//           {transformedDevices.length > 0 ? (
//             <PortStatusBoard devices={transformedDevices} />
//           ) : (
//             <p style={{ color: theme.palette.mode === 'dark' ? '#fff' : '#000' }}>
//               No devices available
//             </p>
//           )}
//         </div>
//       </main>
//     </ScrollContainer>
//   );
// }

// export default PortStatus;

import { PortStatusBoard } from "./PortStatusBoard";
import React, { useEffect, useMemo } from "react";
import "./style.css";
import { useDispatch, useSelector } from "react-redux";
import { mapOpStatus } from "../Topology/topologyConstants";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
import { useTheme } from "@mui/material";
import LegendStatus from "./LegendStatus";
import { filterSwitchPorts } from "@/utility/portFilterUtils";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { PORT_RESOURCE_DETAILS } from "@/RestAPI/url/endpoint";
import { setAvailableResources } from "@/store/features/PortStatus/portStatusSlice";

function PortStatus() {
  const theme = useTheme();
  const bgColor = theme.palette.mode === "dark" ? "#3e3e3e" : "#ffffff";
   // Define dispatch inside the component to access the Redux store
   const dispatch = useDispatch();

   // 1. Call the API on mount
   useEffect(() => {
     InventoryAxios(PORT_RESOURCE_DETAILS, "get")
       .then((res) => {
         console.log("klklkllkl2222", res?.data);
         dispatch(setAvailableResources(res.data));
       })
       .catch((error) => {
         console.error("Error fetching resource details:", error);
       });
   }, []); // Empty dependency array ensures this runs only once when the component mounts
 
  //  console.log("jdbvhbavailableResources", availableResources);

  const availableResources = useSelector(
    (state) => state.portStatusSlice.availableResources
  );

  console.log("jdbvhbavailableResources", availableResources);

  const transformedDevices = useMemo(() => {
    if (!availableResources) return [];
    return availableResources.map((device) => {
      const needsFiltering = filterSwitchPorts(device.resourceId);

      // 1. Get the initial port list
      let portList = needsFiltering
        ? filterSwitchPorts(device.lstPortInfoDtl)
        : device.lstPortInfoDtl || [];

      // 2. SORT the ports by ifindex numerically
      // This ensures that ifindex 1 comes before ifindex 5, etc.
      const sortedPortList = [...portList].sort(
        (a, b) => a.ifindex - b.ifindex
      );

      return {
        id: device.resourceId,
        title: device.resourceName,
        site: device.imSegmentInfo?.segmentName || "Unknown Site",
        ports: sortedPortList
          .filter((port) => port?.ifindex != null) // never allow a port without ifindex
          .map((port,index) => {
            const ifdesc = port.ifdesc?.trim?.() || "";
            const ifportname = port.ifportname?.trim?.() || "";
            const iftype = port.iftype?.toString?.() || "";

            // Detect 10G ports from the actual port information.
            const isTenGigabit =
              /TenGigabitEthernet/i.test(ifdesc) ||
              /tengigabitethernet/i.test(ifportname) ||
              /tengigabitethernet/i.test(iftype);

              const visualIndex = index + 1; 

            return {
              id: `${device.resourceId}-${port.ifindex}`,
              name: port.ifdesc,
              status: mapOpStatus(port.opstatus, port.adminstatus),
              ifindex: port.ifindex,
              isTenGigabit,
              iftype: port.iftype,
              visualIndex
            };
          }),
      };
    });
  }, [availableResources]);

  console.log("fugnutransformedDevices",transformedDevices);
  

  return (
    <ScrollContainer className="h-full" style={{ backgroundColor: bgColor }}>
      <main className="app-shell" style={{ backgroundColor: bgColor }}>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            minHeight: "100vh",
          }}
        >
          {transformedDevices.length > 0 && <LegendStatus />}
          {transformedDevices.length > 0 ? (
            <PortStatusBoard devices={transformedDevices} />
          ) : (
            <p
              style={{ color: theme.palette.mode === "dark" ? "#fff" : "#000" }}
            >
              No devices available
            </p>
          )}
        </div>
      </main>
    </ScrollContainer>
  );
}
export default PortStatus;
