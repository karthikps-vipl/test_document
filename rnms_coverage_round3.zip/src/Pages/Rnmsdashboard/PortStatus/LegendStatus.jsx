import React from "react";
import { PORT_STATUS_META } from "./data/portStatusData";
import { Box, useTheme } from "@mui/material";

 const LegendStatus = ({alarmPortLegend}) => {
  const theme = useTheme();
  const statusItems = Object.values(PORT_STATUS_META);
  const alarmLegend = alarmPortLegend === true ? "status-legend-top-alarmdrawer" : "status-legend-top"
 
  const isDarkMode = theme.palette.mode === 'dark';
  const backgroundColor = isDarkMode 
    ? theme.palette.background.secondary 
    : '#ffffff';
  return (
    // <Box className={alarmLegend} sx={{background: (theme) => theme.palette.background.secondary}}>
    <Box
    className={alarmLegend}
    sx={{
      // Force the background color using the calculated variable
      background: backgroundColor,
      // Ensure no other styles override this
      backgroundColor: backgroundColor 
    }}
  >
    {statusItems.map((status, index) => (
        <React.Fragment key={index}>
          {/* The Item */}
          <div className="legend-item">
            <span 
              className="legend-dot" 
              style={{ backgroundColor: status.color || '#ccc' }} 
            />
            <span className="legend-label">{status.label}</span>
          </div>

          {/* The Separator: Only show if it's NOT the last item */}
          {index < statusItems.length - 1 && (
            <span className="legend-separator">|</span>
          )}
        </React.Fragment>
      ))}
    </Box>
  );
};

export default LegendStatus;
