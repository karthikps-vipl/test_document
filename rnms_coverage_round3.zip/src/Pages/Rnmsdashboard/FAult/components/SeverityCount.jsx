/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : SeverityCount.jsX
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\SeverityCount.jsX
   Purpose                  : The purpose is to show the Alarm Total Count like Major, Minor and Warning in fault alarm. 
   Created Date             : 17-02-2026
 *******************************************************************************************/
import Warning from "../../../../assets/svg/FaultIcon/warning.svg";
import Major from "../../../../assets/svg/FaultIcon/major.svg";
import Minor from "../../../../assets/svg/FaultIcon/minor.svg";
import Active from "../../../../assets/svg/FaultIcon/active alram.svg";
import { useSelector } from "react-redux";
import { useTheme } from "@emotion/react";
import { Box } from "@mui/material";
const Card = ({ title, value, bgColor, image }) => {
  const theme = useTheme();

  return (
    <Box className="flex flex-row items-center justify-between   rounded-lg p-2 h-auto" sx={{background:theme.palette.background.cardbg,border:theme.palette.custom.commonBorder}}  >
      <div className="flex flex-row justify-between items-center gap-2 w-full  ">
        <div className="flex flex-row items-center gap-3">
          {/* Using the 'secondary' text color defined in your theme */}
          <span 
            className="flex justify-start text-xl" 
            style={{ color: theme.palette.text.tabcolor }}
          >
            {title}:
          </span>
          
          {/* Using the 'primary' text color defined in your theme */}
          <span 
            className="flex justify-start font-extrabold text-xl"
            style={{ color: theme.palette.text.primary }}
          >
            {value}
          </span>
        </div>
        <div className="flex justify-start p-1">
          <img
            src={image}
            className="p-1 rounded-lg size-10"
            style={{ backgroundColor: bgColor }}
            alt={title}
          />
        </div>
      </div>
    </Box>
  );
};

const SeverityCount = () => {
  const severityCount = useSelector((state) => state.alarmSlice.severityData);
  console.log(severityCount, "severityCount2");
  let minor;
  let major;
  let warning;
  if (severityCount !== null) {
    minor = severityCount[1] || 0;
    major = severityCount[2] || 0;
    warning = severityCount[0] || 0; // Assuming 4 is the key for Warning
  } else if (severityCount === null) {
    minor = 0;
    major = 0;
    warning = 0; // Assuming 4 is the key for Warning
  }

  const activeAlarm = major + minor + warning;
  console.log(activeAlarm, "activeAlarm");
  const data = [
    {
      title: "Active Alarm",
      value: activeAlarm,
      bgColor: "#DBFFEE",
      image: Active,
    },
    {
      title: "Major",
      value: major,
      bgColor: "#FFEBEC",
      image: Major,
    },
    {
      title: "Minor",
      value: minor,
      bgColor: "#FFFFC9",
      image: Minor,
    },
    {
      title: "Warning",
      value: warning,
      bgColor: "#D0FFFF",
      image: Warning,
    },
  ];

  return (
    // <div className="flex w-full justify-center    align-middle text-center  md:gap-8 lg:gap-12 xl:gap-16">
    <div className=" grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 w-full ">
      {data.map((item) => (
        <Card
          key={item.key}
          title={item.title}
          value={item.value}
          bgColor={item.bgColor}
          image={item.image}
        />
      ))}
    </div>
  );
};
export default SeverityCount;
