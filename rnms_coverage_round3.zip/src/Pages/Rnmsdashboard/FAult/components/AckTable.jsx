// /*************************************************************************************
//    Project                  : IAF-NMS
//    SubSystem                : FAult\components
//    File Name                : AckTable.jsx
//    Author                   : SURAJ - VIPL
//    Package                  : src\Pages\Rnmsdashboard\FAult\components\AckTable.jsx
//    Purpose                  : The purpose is to show the table to Acknowledge the Data.
//    Created Date             : 09-02-2026
//  *******************************************************************************************/

import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { UPDATE_WORKFLOW } from "@/RestAPI/url/endpoint";
import { Grid, Box, Typography } from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal";
import MInput from "@/components/Reusable/Input/MInput";
import MTable from "@/components/Reusable/Table/MTable";
import { Update } from "@mui/icons-material";
import { CircularProgress } from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { updateSingleAlarm } from "@/store/features/Fault/alarmSlice";
import Toast from "@/components/Reusable/Toast/Toast";
const STATUS_MAP = { 0: "NOT_ACK", 1: "ACK" };
const STATUS_REVERSE_MAP = { ACK: 1, NOT_ACK: 0 };

const AckTable = ({ isOpen, onCancel, ackdata = [], handleWorkflowUpdate }) => {
  console.log("ackData", ackdata);

  const { userDetails } = useSelector((state) => state.userSlice);
  const userName = userDetails?.data?.userName;
  const [loading, setLoading] = useState(false);
  const [ackComment, setAckComment] = useState("");
  const [status, setStatus] = useState("ACK");
  const [helperMessage, setHelperMessage] = useState(
    "Must be length of 4 - 512"
  );
  const [isError, setIsError] = useState(true);
  const dispatch = useDispatch();
  useEffect(() => {
    if (isOpen && ackdata && ackdata.length > 0) {
      setAckComment("");
      setStatus("ACK");
      setHelperMessage("Must be length of 4 - 512");
      setIsError(true);
    }
  }, [isOpen, ackdata]);

  const validateComment = (value) => {
    const trimmedVal = value.trim();
    let error = false;
    let message = "";

    if (trimmedVal.length === 0) {
      message = "Must be length of 4 - 512";
      error = true;
    } else if (trimmedVal.length < 4) {
      message = `${4 - trimmedVal.length} more character(s) needed`;
      error = true;
    } else if (value.length <= 512) {
      message = `${512 - value.length} characters remaining`;
    } else {
      message = `${value.length - 512}/512 characters exceeded`;
      error = true;
    }

    setHelperMessage(message);
    setIsError(error);
    setAckComment(value);
  };

  const handleSubmit = async () => {
    if (isError || !ackdata.length) return;
    console.log("ackdata", ackdata);
    setLoading(true);
    try {
      const workflowValue = STATUS_REVERSE_MAP[status];
      const payload = ackdata.map((alarm) => ({
        ...alarm,
        workflow: workflowValue,
        ackWorkFlowComments: workflowValue === 1 ? ackComment : "",
        endWorkFlowComments: workflowValue === 0 ? ackComment : null,
        workFlowOperation: true,
        userName: userName,
      }));

      const res = await FaultAxios(
        `${UPDATE_WORKFLOW}/${userName}`,
        "post",
        payload
      );

      if (res.status === 200 || res.status === 201) {
        Toast("Success", "Alarm acknowledged successfully", "success");
        // Universal update: update Redux immediately
        payload.forEach((updatedAlarm) => {
          dispatch(updateSingleAlarm(updatedAlarm));
        });
        onCancel();
      } else {
        Toast("Failed", "Failed to acknowledged alarm ", "error");
      }

      onCancel();
    } catch (error) {
      console.error("Update failed", error);
      Toast("Error","An unexpected error occurred", "error");
    } finally {
      setLoading(false); // Stop Loader
    }
  };

  const tableData = ackdata?.map((item) => ({ ...item })) || [];
  const isSubmitDisabled = isError || !ackdata.length;

  const columns = [
    { name: "SEGMENT", uid: "segmentName" },
    { name: "DEVICE", uid: "resourceName" },
    { name: "IP ADDRESS", uid: "resourceIp" },
    { name: "ALARM NAME", uid: "alarmName" },
    { name: "DESCRIPTION", uid: "alarmDescription" },
  ];

  return (
    <MModal
      open={isOpen}
      title="ALARM WORKFLOW"
      handleClose={onCancel}
      fullWidth
      customWidth="100%"
      enableFullScreen
    >
      <Grid item xs={12}>
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: "bold", color: "#555" }}
        >
          Selected Alarms ({ackdata?.length || 0})
        </Typography>
        <Box
           
        >
          <MTable
            tableData={tableData}
            columns={columns}
            tableTitle="Acknowledge Fault"
            showPagination={true}
            showSearch={true}
          />
        </Box>
      </Grid>

      <Grid
        spacing={2}
        sx={{
      mt:1
        }}
        className="grid grid-cols-2 gap-2 w-full"
      >
        <Grid item xs={12} md={6}>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography variant="caption" sx={{ mb: 0.5 }}>
              Status
            </Typography>
            <MInput fullWidth value={"NOT_ACK"} disabled />
          </Box>
        </Grid>

        <Grid item xs={12} md={6}>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography variant="caption" sx={{ mb: 0.5 }}>
              Comments
            </Typography>
            <MInput
              fullWidth
              placeholder="Describe the action taken..."
              value={ackComment}
              onChange={(e) => validateComment(e.target.value)}
              error={isError}
              helperText={helperMessage}
              inputProps={{ maxLength: 512 }}
            />
          </Box>
        </Grid>
      </Grid>

      <Grid item xs={12} >
        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
          <MButtonPrimary
            variant="contained"
            color="primary"
            sx={{ borderRadius: "8px", px: 4 }}
            disabled={isSubmitDisabled}
            onClick={handleSubmit}
            startIcon={
              loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            Update
          </MButtonPrimary>
        </Box>
      </Grid>
    </MModal>
  );
};

export default AckTable;
