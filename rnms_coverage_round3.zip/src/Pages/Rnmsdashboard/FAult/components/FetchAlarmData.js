/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : FetchAlarmData.js
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\FetchAlarmData.js
   Purpose                  : The purpose is to show All alarm fetched from the API. 
   Created Date             : 13-02-2026
 *******************************************************************************************/

// DataFetchingComponent.js
import React, { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  setAlarmSeverityCount,
  setActiveAllAlarms,
  setBadgeCount,
  setCnmsBadgeCount,
} from "@/store/features/Fault/alarmSlice";

import { FaultAxios } from "../../../../RestAPI/api/axiosApicall";
import { FETCH_ALL_OPEN_ALARM } from "../../../../RestAPI/url/endpoint";

const UseDataFetchingComponent = () => {
  const dispatch = useDispatch();
  const pollingIntervalRef = useRef(null); // To store the timer ID

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const fetchData = async () => {
    try {
      const res = await FaultAxios(FETCH_ALL_OPEN_ALARM, "get");
      if (res.status === 200) {
        const message = res?.data || [];

        const transformedData = message.map((value, index) => ({
          ...value,
          key: index,
        }));

        console.log("vbhfbalaram", transformedData);

        // Push initial data to Redux
        dispatch(setActiveAllAlarms(transformedData));

        // Separate CNMS and non-CNMS badge calculations
        if (isCnms) {
          dispatch(setCnmsBadgeCount(transformedData));
        } else {
          dispatch(setBadgeCount(transformedData));
        }

        // Initial Severity Count calculation
        const counts = { 0: 0, 1: 0, 2: 0 };
        transformedData.forEach((alarm) => {
          if (counts.hasOwnProperty(alarm.severity)) {
            counts[alarm.severity]++;
          }
        });
        dispatch(setAlarmSeverityCount(counts));
      }
    } catch (error) {
      console.error("Error fetching alarms:", error);
    }
  };

  // --- LIVE UPDATING LOGIC ---
  useEffect(() => {
    // 1. Fetch immediately on mount
    fetchData();

    // pollingIntervalRef.current = setInterval(() => {
    //   fetchData();
    // }, 10000); // 10000ms = 10 seconds

    // return () => {
    //   if (pollingIntervalRef.current) {
    //     clearInterval(pollingIntervalRef.current);
    //   }
    // };
  }, []); // Empty dependency array means this runs once on mount

  // REMOVE the dispatches from here.
  // They should only happen inside fetchData or inside your Table's useEffect.

  return { fetchData };
};

export default UseDataFetchingComponent;
