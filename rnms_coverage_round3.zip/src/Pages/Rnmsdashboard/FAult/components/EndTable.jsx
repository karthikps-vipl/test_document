/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : EndTable.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\EndTable.jsx
   Purpose                  : The purpose is to show the table acknowledged data to End the Data and close the fault. 
   Created Date             : 12-02-2026
 *******************************************************************************************/
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { UPDATE_WORKFLOW } from "@/RestAPI/url/endpoint";
import { Grid, Box, Typography, useTheme } from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal";
import MInput from "@/components/Reusable/Input/MInput";
import MTable from "@/components/Reusable/Table/MTable";
import { Update } from "@mui/icons-material";
import { CircularProgress } from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { updateSingleAlarm } from "@/store/features/Fault/alarmSlice";
import Toast from "@/components/Reusable/Toast/Toast";
import { refreshAlarmData } from "@/utility/alarmService";

const EndTable = ({ isOpen, onCancel, ackdata = [] }) => {
  const { userDetails } = useSelector((state) => state.userSlice);
  const userName = userDetails?.data?.userName;
  const [loading, setLoading] = useState(false);
  const theme = useTheme();

  const [endComment, setEndComment] = useState("");
  const [helperMessage, setHelperMessage] = useState(
    "Must be length of 4 - 512"
  );
  const [isError, setIsError] = useState(true);
  const dispatch = useDispatch();
  // Reset state when modal opens to ensure clean input
  useEffect(() => {
    if (isOpen) {
      setEndComment("");
      setHelperMessage("Must be length of 4 - 512");
      setIsError(true);
    }
  }, [isOpen]);

  const validateComment = (value) => {
    const trimmed = value.trim();
    let error = false;
    let message = "";

    if (trimmed.length === 0) {
      message = "Must be length of 4 - 512";
      error = true;
    } else if (trimmed.length < 4) {
      message = `${4 - trimmed.length} more characters needed`;
      error = true;
    } else if (value.length <= 512) {
      message = `${512 - value.length} characters remaining`;
    } else {
      message = `${value.length - 512} characters exceeded`;
      error = true;
    }
    setHelperMessage(message);
    setIsError(error);
    setEndComment(value);
  };

  const handleEndSubmit = async () => {
    if (isError || !ackdata.length) return;
    setLoading(true);
    try {
      const payload = ackdata.map((alarm) => ({
        ...alarm,
        workflow: 2, // Setting to 2 to indicate "END/CLOSED" state
        alarmState: 0, // Setting state to 0 to remove from active view
        endWorkFlowComments: endComment,
        workFlowOperation: true,
        userName: userName,
      }));

      const res = await FaultAxios(
        `${UPDATE_WORKFLOW}/${userName}`,
        "post",
        payload
      );

      // Crucial: Check for success status before closing
      if (res.status === 200 || res.status === 201) {
        await refreshAlarmData(dispatch);
        Toast("Success", "Alarm Ended successfully", "success");

        // Universal update: update Redux immediately
        payload.forEach((updatedAlarm) => {
          dispatch(updateSingleAlarm(updatedAlarm));
        });
        onCancel();
      } else {
        Toast("Failed", "Failed to end the alarm ", "error");
      }
    } catch (error) {
      console.error("End Workflow failed", error);
      Toast("Error", "An unexpected error occurred", "error");
    } finally {
      setLoading(false); // Stop Loader
    }
  };

  const columns = [
    { name: "SEGMENT", uid: "segmentName" },
    { name: "DEVICE", uid: "resourceName" },
    { name: "ALARM NAME", uid: "alarmName" },
    { name: "DESCRIPTION", uid: "alarmDescription" },
    { name: "IP ADDRESS", uid: "resourceIp" },
  ];

  const isSubmitDisabled = isError || !ackdata.length;

  return (
    <MModal
      open={isOpen}
      title="TERMINATE ALARM (END)"
      handleClose={onCancel}
      fullWidth
      customWidth="100%"
      enableFullScreen
    >
      <Grid spacing={2}>
        <Grid item xs={12}>
          <Typography
            variant="subtitle2"
            sx={{
              mb: 1,
              fontWeight: "bold",
              color: theme.palette.text.secondary,
            }}
          >
            Alarms to End ({ackdata?.length})
          </Typography>
          <Box>
            <MTable
              tableData={ackdata}
              columns={columns}
              tableTitle="End Fault"
              showPagination={true}
              showSearch={true}
            />
          </Box>
        </Grid>
        <Grid className="grid grid-cols-2 gap-2 w-full">
          <Grid item xs={12} md={6}>
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography variant="caption" sx={{ mb: 0.5 }}>
                Status
              </Typography>
              <MInput fullWidth value={"ACK"} disabled />
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography variant="caption" sx={{ mb: 0.5 }}>
                Comments
              </Typography>
              <MInput
                fullWidth
                placeholder="Describe the action taken..."
                value={endComment}
                onChange={(e) => validateComment(e.target.value)}
                error={isError}
                helperText={helperMessage}
                inputProps={{ maxLength: 512 }}
              />
            </Box>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12} sx={{ mt: 3 }}>
        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
          <MButtonPrimary
            variant="contained"
            color="primary"
            startIcon={
              loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
            sx={{ borderRadius: "8px", px: 4 }}
            disabled={isSubmitDisabled}
            onClick={handleEndSubmit}
          >
            Update
          </MButtonPrimary>
        </Box>
      </Grid>
    </MModal>
  );
};

export default EndTable;
