/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : SelectedCol.jsX
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\SelectedCol.jsX
   Purpose                  : The purpose is to show the column headers and some functionality for the fault alarm table. 
   Created Date             : 16-02-2026
 *******************************************************************************************/
// import * as React from "react";
// import {
//   MenuItem,
//   FormControl,
//   ListItemText,
//   Select,
//   Checkbox,
// } from "@mui/material";
// import { styled } from "@mui/material/styles";

// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 8;

// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 250,
//     },
//   },
// };

// const COLUMNS_CONFIG = [
//   { id: "segmentName", label: "Segment Name" },
//   { id: "resourceName", label: "Device Name" },
//   { id: "resourceIp", label: "Resource IP" },
//   { id: "alarmName", label: "Alarm Name" },
//   { id: "alarmDescription", label: "Description" },
//   { id: "severity", label: "Severity" },
//   { id: "workflow", label: "Workflow" },
//   { id: "dateTime", label: "Date & Time" },
//   { id: "alarmCount", label: "Alarm Count" },
// ];

// const StyledCheckbox = styled(Checkbox)({
//   "&.Mui-checked": {
//     color: "#1976d2",
//   },
// });

// export default function MultipleSelectCheckmarks({
//   visibleColumns, // This is expected to be a Set of IDs: Set(['alarmName', 'severity'])
//   setVisibleColumns,
// }) {
//   const [open, setOpen] = React.useState(false);

//   // Helper to convert the current Set of IDs back to an array for the Select component
//   const selectedIds = Array.from(visibleColumns);

//   const handleChange = (event) => {
//     const value = event.target.value;
//     // Prevent removing all selections
//     if (value.length === 0) return;
    
//     // Update parent state with a new Set of IDs
//     setVisibleColumns(new Set(value));
//   };

//   return (
//     <div>
//       <FormControl sx={{ mb: 0.8, width: 50, mr: 1.3 }}>
//         <Select
//           labelId="column-hide-select-label"
//           multiple
//           value={selectedIds}
//           onChange={handleChange}
//           onOpen={() => setOpen(true)}
//           onClose={() => setOpen(false)}
//           // renderValue determines what is shown in the "collapsed" box
//           renderValue={() => (
//             <img
//               src="/src/assets/SVGIcons/filter_svg_1.svg"
//               alt="Filter"
//               style={{ width: 20, height: 20, cursor: "pointer" }}
//             />
//           )}
//           MenuProps={MenuProps}
//           sx={{
//             "& .MuiSelect-select": {
//               padding: "6px",
//               display: "flex",
//               alignItems: "center",
//             },
//             width: "60px",
//           }}
//         >
//           {/* 2. ✅ Map over the Config array */}
//           {COLUMNS_CONFIG.map((column) => (
//             <MenuItem key={column.id} value={column.id}>
//               <Checkbox checked={visibleColumns.has(column.id)} />
//               {/* 3. ✅ Use column.label for the UI, but column.id is the 'value' */}
//               <ListItemText primary={column.label} />
//             </MenuItem>
//           ))}
//         </Select>
//       </FormControl>
//     </div>
//   );
// }
import * as React from "react";
import {
  MenuItem,
  FormControl,
  ListItemText,
  Select,
  Checkbox,
} from "@mui/material";
import { styled, useTheme } from "@mui/material/styles";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const COLUMNS_CONFIG = [
  { id: "segmentName", label: "Segment Name" },
  { id: "resourceName", label: "Device Name" },
  { id: "resourceIp", label: "Resource IP" },
  { id: "alarmName", label: "Alarm Name" },
  { id: "alarmDescription", label: "Description" },
  { id: "severity", label: "Severity" },
  { id: "workflow", label: "Workflow" },
  { id: "dateTime", label: "Date & Time" },
  { id: "alarmCount", label: "Alarm Count" },
];

const StyledCheckbox = styled(Checkbox)({
  "&.Mui-checked": {
    color: "#1976d2",
  },
});

export default function MultipleSelectCheckmarks({
  
  visibleColumns, // Expected to be a Set of IDs: Set(['alarmName', 'severity'])
  setVisibleColumns,
}) {
  // Helper to convert the current Set of IDs back to an array for the Select component
  const selectedIds = Array.from(visibleColumns);
const theme=useTheme()
  const handleChange = (event) => {
    const value = event.target.value;
    
    // Prevent removing all selections if that is your business requirement
    if (value.length === 0) return;
    
    // Update parent state with a new Set of IDs
    setVisibleColumns(new Set(value));
  };

  return (
    <div>
      <FormControl sx={{ mb: 0.8, width: 50, mr: 1.3 }}>
        <Select
          labelId="column-hide-select-label"
          multiple
          value={selectedIds}
          onChange={handleChange}
          renderValue={() => (
            <img
              src="/src/assets/SVGIcons/filter_svg_1.svg"
              alt="Filter"
              style={{ width: 20, height: 20, cursor: "pointer" ,filter:theme.palette.custom.icon.iconFilter}}
            />
          )}
          MenuProps={MenuProps}
          sx={{
            "& .MuiSelect-select": {
              padding: "6px",
              display: "flex",
              alignItems: "center",
            },
            width: "60px",
          }}
        >
          {COLUMNS_CONFIG.map((column) => (
            <MenuItem key={column.id} value={column.id}>
              <StyledCheckbox checked={visibleColumns.has(column.id)} />
              <ListItemText primary={column.label} />
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </div>
  );
}