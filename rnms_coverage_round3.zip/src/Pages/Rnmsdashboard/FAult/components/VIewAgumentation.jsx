/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : SeverityCount.jsX
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\SeverityCount.jsX
   Purpose                  : The purpose is to show the View Augmentation which contains more info of the specific Alarm  
   Created Date             : 19-02-2026
 *******************************************************************************************/
import React, { useState, useEffect } from "react";
import { Grid, Box, Typography, Divider } from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal";
import MInput from "@/components/Reusable/Input/MInput";
import MButton from "@/components/Reusable/Button/MButton";
import MTable from "@/components/Reusable/Table/MTable";
import { Save } from "@mui/icons-material";

const ViewAugmentation = ({ isOpen, onCancel, alarmData }) => {

  const [formData, setFormData] = useState({
    alarmName: "",
    source: "",
    category: "",
    assignedTo: "",
    notes: "",
  });

  // Simple table data for occurrences
  const occurrenceData = [
    { name: "Device Alpha", occurrences: 5 },
    { name: "Device Beta", occurrences: 2 },
  ];

  const columns = [
    { name: "NAME", uid: "name" },
    { name: "NO. OF OCCURRENCES", uid: "occurrences" },
  ];

  useEffect(() => {
    if (isOpen && alarmData) {
      setFormData({
        alarmName: alarmData[0]?.alarmName || "",
        source: alarmData[0]?.resourceName || "",
        category: "Network", // Placeholder
        assignedTo: "Admin", // Placeholder
        notes: "",
      });
    }
  }, [isOpen, alarmData]);

  const handleSave = () => {
    console.log("Saving Augmentation Data:", formData);
    onCancel();
  };

  return (
    <MModal
      open={isOpen}
      title="VIEW AUGMENTATION-111"
      handleClose={onCancel}
      fullWidth
      enableFullScreen
    >
      <Grid container spacing={3}>
        {/* Fields Section */}
        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 2 }}>
            General Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                Alarm Name
              </Typography>
              <MInput fullWidth value={formData.alarmName} disabled />
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                Source
              </Typography>
              <MInput fullWidth value={formData.source} disabled />
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                Category
              </Typography>
              <MInput fullWidth value={formData.category} />
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                Assigned To
              </Typography>
              <MInput fullWidth value={formData.assignedTo} />
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                Status
              </Typography>
              <MInput fullWidth value="Active" disabled />
            </Grid>
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Divider sx={{ my: 1 }} />
        </Grid>

        {/* Occurrence Table Section */}
        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            Occurrence Statistics
          </Typography>
          <MTable
            tableTitle=""
            tableData={occurrenceData}
            columns={columns}
            showPagination={true}
            showSearch={true}
          />
        </Grid>

        {/* Action Button */}
        <Grid item xs={12}>
          <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
            <MButton
              variant="contained"
              startIcon={<Save />}
              onClick={handleSave}
              sx={{ borderRadius: "8px", px: 4 }}
            >
              Save Changes
            </MButton>
          </Box>
        </Grid>
      </Grid>
    </MModal>
  );
};

export default ViewAugmentation;
