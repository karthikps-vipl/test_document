/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : AlarmChart.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\AlarmChart.jsx
   Purpose                  : The purpose is to show the chart related data for the Fault Summary. 
   Created Date             : 11-02-2026
 *******************************************************************************************/
import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Label,
} from "recharts";
import _ from "lodash";
import { useSelector } from "react-redux";
import { Box, useTheme } from "@mui/material";

// 1. Keep constants outside to prevent re-renders and dependency issues
const SEVERITY_MAP = {
  warning: 0,
  major: 2,
  minor: 1,
};
const EMPTY_ARRAY = [];

const CustomLegend = (props) => {
  const { payload, title } = props;
  const theme = useTheme();
 
  const gradientMap = {
    Major: "url(#majorGrad)",
    Minor: "url(#minorGrad)",
    Warning: "url(#warningGrad)",
  };

  return (
    <Box className="flex items-center justify-between gap-6   "  sx={{background:theme.palette.background.cardbg}}>
      <span 
        className="text-[11px] font-bold uppercase tracking-widest pb-4"
        style={{ color: theme.palette.text.secondary }}
      >
        {title}
      </span>
      <span className="invisible text-[11px] pb-4">Placeholder</span>
      <ul className="flex gap-4 list-none m-0 pb-4">
        {payload.map((entry, index) => {
          const colorToUse = gradientMap[entry.value] || entry.fill;
          return (
            <li key={`item-${index}`} className="flex items-center gap-2">
              <Box className="w-3 h-3">
                <svg width="15" height="15" viewBox="0 0 12 12">
                  <circle cx="6" cy="6" r="5" fill={colorToUse} />
                </svg>
              </Box>
              <span 
                className="text-xs font-medium"
                style={{ color: theme.palette.text.primary }}
              >
                {entry.value}
              </span>
            </li>
          );
        })}
      </ul>
    </Box>
  );
};

const CustomizedAxisTick = ({ x, y, payload, theme }) => {
  const MAX_LENGTH = 10;
  const formatValue = (val) => {
    if (!val) return "";
    const stringValue = String(val);
    return stringValue.length > MAX_LENGTH
      ? stringValue.substring(0, MAX_LENGTH) + "..."
      : stringValue;
  };

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        x={0}
        y={0}
        dy={8}
        textAnchor="middle"
        fill={theme.palette.text.secondary} // Dynamic color
        fontSize={10}
        fontWeight={500}
      >
        {formatValue(payload.value)}
      </text>
    </g>
  );
};

const AlarmChart = () => {
  const theme = useTheme();
  const chartColors = theme.palette.custom.chart;
  
  const faults = useSelector((state) => state.alarmSlice.fetchAllAlarm) || EMPTY_ARRAY;
  const allSegments = useSelector((state) => state.inventory?.segments) || [];

  const checkSeverity = (fSeverity, targetKey) => {
    return fSeverity === SEVERITY_MAP[targetKey] || fSeverity === targetKey;
  };

  // 1. Logic for Top 10 Faults
  const topTenData = useMemo(() => {
    if (!faults.length) return [];
    return _.chain(faults)
      .filter((f) => f.alarmName && f.alarmName.toUpperCase() !== "NA")
      .sortBy("alarmCount")
      .reverse()
      .uniqBy("alarmName")
      .slice(0, 10)
      .map((f) => {
        const count = Number(f.alarmCount) || 0;
        return {
          name: f.alarmName,
          Major: checkSeverity(f.severity, "major") ? count : 0,
          Minor: checkSeverity(f.severity, "minor") ? count : 0,
          Warning: checkSeverity(f.severity, "warning") ? count : 0,
        };
      })
      .value();
  }, [faults]);

  // 2. Logic for Alarms by Segment
  const segmentData = useMemo(() => {
    if (!allSegments.length) return [];
    const grouped = _.groupBy(faults, (f) => f.segmentName?.trim());
    return allSegments.map((seg) => {
      const trimmedName = seg.segmentName?.trim();
      if (!trimmedName || trimmedName.toUpperCase() === "NA") {
        return null;
      }
      const segmentFaults = grouped[trimmedName] || [];
      return {
        segmentName: seg.segmentName,
        major: _.sumBy(segmentFaults, (f) =>
          checkSeverity(f.severity, "major") ? Number(f.alarmCount) : 0
        ),
        minor: _.sumBy(segmentFaults, (f) =>
          checkSeverity(f.severity, "minor") ? Number(f.alarmCount) : 0
        ),
        warning: _.sumBy(segmentFaults, (f) =>
          checkSeverity(f.severity, "warning") ? Number(f.alarmCount) : 0
        ),
      };
    }).filter(Boolean);
  }, [faults, allSegments]);

  const Gradients = (
    <defs>
      <linearGradient id="majorGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#D75961" />
        <stop offset="100%" stopColor="#FFCED2" />
      </linearGradient>
      <linearGradient id="minorGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#BDBD32" />
        <stop offset="100%" stopColor="#FFFF00" />
      </linearGradient>
      <linearGradient id="warningGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#007C7C" />
        <stop offset="100%" stopColor="#72FFFF" />
      </linearGradient>
    </defs>
  );

  return (
    <Box className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full  "  >
      {/* Top 10 Chart */}
      <Box 
        className="   rounded-[12px] p-4 shadow-sm  "  sx={{background:theme.palette.custom.chart.chartbg,border:theme.palette.custom.commonBorder}}
        // sx={{ 
        //   background: theme.palette.background.paper,
        //   borderColor: theme.palette.divider // Uses theme border color
        // }}
      >
        <ResponsiveContainer width="100%" height={300} >
          <BarChart
            data={topTenData}
            margin={{ top: 5, right: 0, left: 0, bottom: 20 }}
            barGap={8}
            barSize={32}
          >
            {Gradients}
            <CartesianGrid vertical={false} stroke={chartColors.grid} />
            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
              interval={0}
              tick={<CustomizedAxisTick theme={theme} />}
            >
              <Label
                value="Alarm Name"
                position="bottom"
                offset={10}
                style={{
                  textAnchor: "middle",
                  fontSize: 11,
                  fill: theme.palette.text.primary // Replaced 'red' with theme
                }}
              />
            </XAxis>
            <YAxis
              fontSize={10}
              axisLine={false}
              tickLine={false}
              tick={{ fill: chartColors.text }}
            >
              <Label
                value="Alarm Count"
                angle={-90}
                position="insideLeft"
                style={{
                  textAnchor: "middle",
                  fontSize: 11,
                  fill: theme.palette.text.primary // Dynamic color
                }}
              />
            </YAxis>
            <Tooltip
              cursor={{ fill: chartColors.cursor }}
              contentStyle={{
                borderRadius: "8px",
                border: "none",
                boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                backgroundColor: chartColors.tooltipBg,
                color: chartColors.tooltipText, // Use theme tooltip text
              }}
            />
            <Legend
              verticalAlign="top"
              align="right"
              content={(props) => (
                <CustomLegend {...props} title="Top 10 Faults" />
              )}
              wrapperStyle={{
                paddingBottom: "4px",
              }}
            />
            <Bar dataKey="Major" stackId="a" fill="url(#majorGrad)" />
            <Bar dataKey="Minor" stackId="a" fill="url(#minorGrad)" />
            <Bar dataKey="Warning" stackId="a" fill="url(#warningGrad)" />
          </BarChart>
        </ResponsiveContainer>
      </Box>

      {/* Segment Chart */}
      <Box 
        className="  rounded-[12px] p-4 shadow-sm h-[350px]" sx={{background:theme.palette.custom.chart.chartbg,border:theme.palette.custom.commonBorder}}
        // sx={{ 
        //   background: theme.palette.background.paper,
        //   borderColor: theme.palette.divider 
        // }}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={segmentData}
            margin={{ top: 5, right: 0, left: 0, bottom: 20 }}
            barGap={8}
            barSize={32}
          >
            {Gradients}
            <CartesianGrid vertical={false} stroke={chartColors.grid} />
            <XAxis
              dataKey="segmentName"
              axisLine={false}
              tickLine={false}
              interval={0}
              tick={<CustomizedAxisTick theme={theme} />}
            >
              <Label
                value="Segment Types"
                position="bottom"
                offset={10}
                style={{
                  textAnchor: "middle",
                  fontSize: 11,
                  fill: theme.palette.text.primary // Dynamic color
                }}
              />
            </XAxis>
            <YAxis
              fontSize={10}
              axisLine={false}
              tickLine={false}
              tick={{ fill: chartColors.text }}
            >
              <Label
                value="Count"
                angle={-90}
                position="insideLeft"
                style={{
                  textAnchor: "middle",
                  fontSize: 11,
                  fill: theme.palette.text.primary // Dynamic color
                }}
              />
            </YAxis>
            <Tooltip
              cursor={{ fill: chartColors.cursor }}        
              contentStyle={{
                borderRadius: "8px",
                border: "none",
                boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                backgroundColor: chartColors.tooltipBg,
                color: chartColors.tooltipText, // Dynamic color
              }}
            />
            <Legend
              verticalAlign="top"
              align="right"
              content={(props) => (
                <CustomLegend {...props} title="Active Alarms By Segment" />
              )}
              wrapperStyle={{
                paddingBottom: "4px",
              }}
            />
            <Bar dataKey="major" name="Major" stackId="segmentStack" fill="url(#majorGrad)" />
            <Bar dataKey="minor" name="Minor" stackId="segmentStack" fill="url(#minorGrad)" />
            <Bar dataKey="warning" name="Warning" stackId="segmentStack" fill="url(#warningGrad)" />
          </BarChart>
        </ResponsiveContainer>
      </Box>
    </Box>
  );
};

export default AlarmChart;