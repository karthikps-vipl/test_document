/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : ActiveAlarmTable.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\ActiveAlarmTable.jsx
   Purpose                  : The purpose is to show the table related data for the Fault Summary. 
   Created Date             : 10-02-2026
 *******************************************************************************************/
import MTable from "@/components/Reusable/Table/MTable";
import { Box } from "@mui/system";
import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import SelectedCol from "./SelectedCol";
import UseDataFetchingComponent from "./FetchAlarmData";
import AckTable from "./AckTable";
import EndTable from "./EndTable";
import {
  setAlarmSeverityCount,
  updateSingleAlarm,
} from "@/store/features/Fault/alarmSlice";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";

import { severityConfig } from "@/lib/utils";
import { Tooltip } from "antd";

const ActiveAlarmTable = ({ isDrawerMode = false, limit, isCnms = false, }) => {
  const INITIAL_VISIBLE_COLUMNS = [
    "segmentName",
    "resourceName",
    "resourceIp",
    "alarmName",
    "alarmDescription",
    "severity",
    "workflow",
    "dateTime",
    "alarmCount",
  ];
  // const severityConfig = {
  //   MAJOR: {
  //     label: "Major",
  //     dotGradient: "linear-gradient(135deg, #ffced2 0%, #d75961 100%)",
  //   },
  //   MINOR: {
  //     label: "Minor",
  //     dotGradient: "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)",
  //   },
  //   WARNING: {
  //     label: "Warning",
  //     dotGradient: "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)",
  //   },
  // };
  const dispatch = useDispatch();

  // Connect to Redux instead of local state
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const toggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };
  const { fetchData } = UseDataFetchingComponent();
  // Inside ActiveAlarmTable component:
  const [visibleColumns, setVisibleColumns] = React.useState(
    new Set(INITIAL_VISIBLE_COLUMNS)
  );
  // const [severityCounts, setSeverityCounts] = useState({ 1: 0, 2: 0, 3: 0 });
  // const [filterValue, setFilterValue] = useState(""); //Handle your search value
  // const [hasSearchFilter, setHasSearchFilter] = useState(false);
  const segments = useSelector((state) => state.inventory?.segments) || [];
  const resources = useSelector((state) => state.inventory?.resources) || [];
  // const [alarmData, setAlarmData] = useState([]);
  // const alarmData = useSelector((state) => state.alarmSlice.fetchAllAlarm);
  const rnmsAlarmData = useSelector(
    (state) => state.alarmSlice?.fetchAllAlarm || []
  );
  
  // CNMS alarms
  const cnmsAlarmData = useSelector(
    (state) => state.remoteRepDetails?.cnmsOpenAlarm || []
  );
  
  // Select the correct alarm source
  const alarmData = isCnms ? cnmsAlarmData : rnmsAlarmData;
  
  // const updatedAlarmData = useSelector(
  //   (state) => state.alarmSlice?.updateAlaram
  // );

  const [isAckModalOpen, setIsAckModalOpen] = useState(false);
  const [isEndModalOpen, setIsEndModalOpen] = useState(false);
  const [selectedAlarm, setSelectedAlarm] = useState(null);
  console.log(alarmData, "fetchAllAlarmData");

  // useEffect(() => {
  //   if (updatedAlarmData) {
  //     dispatch(updateSingleAlarm(updatedAlarmData));

  //     console.log(updatedAlarmData, "dededsdazcbfgdf");

  //     const types = { 0: "info", 1: "warning", 2: "error" };
  //     const selectedType = types[updatedAlarmData.severity] || "NA";
  //     // alert("hyyhyhyhyhy");
  //     if (updatedAlarmData.severity !== -1) {
  //       Toast(
  //         updatedAlarmData.resourceName + "-" + updatedAlarmData.segmentName,
  //         <>
  //           {updatedAlarmData.alarmName}
  //           <br />
  //           {updatedAlarmData.alarmDescription}
  //         </>,

  //         // updatedAlarmData.alarmDescription,
  //         selectedType
  //       );
  //     }
  //   }
  // }, [updatedAlarmData, dispatch]);

  // useEffect(() => {
  //   fetchData();
  // }, []);

  // useEffect(() => {
  //   setAlarmData(fetchAllAlarmData);
  // }, [fetchAllAlarmData]);

  const handleAcknowledgeClick = (row) => {
    setSelectedAlarm([row]); // Store the entire row data (including alarmId)
    setIsAckModalOpen(true); // Open the modal
    setIsEndModalOpen(true);
  };
  useEffect(() => {
    // Logic to calculate severity totals from current alarmData
    const counts = {
      0: 0, // Warning
      1: 0, // Minor
      2: 0, // Major
    };

    alarmData.forEach((alarm) => {
      const sev = alarm.severity;
      if (counts.hasOwnProperty(sev)) {
        counts[sev] += 1;
      }
    });

    // Dispatch the new counts to Redux so SeverityCount component sees them
    dispatch(setAlarmSeverityCount(counts));
  }, [alarmData, dispatch]);
 
  // const columns = [
  //   {
  //     name: "Segment",
  //     uid: "segmentName",
  //     sortable: true,
  //     width: "144px",
  //     filterType: "dropdown",
  //     // Add the "?" here
  //     filterOptions:
  //       segments?.map((s) => ({
  //         label: s.segmentName,
  //         value: s.segmentName,
  //       })) || [], // fallback to empty array
  //   },
  //   {
  //     name: "Device",
  //     uid: "resourceName",
  //     sortable: true,
  //     filterType: "dropdown",
  //     // Add the "?" here
  //     filterOptions:
  //       resources?.map((r) => ({
  //         label: r.resourceName,
  //         value: r.resourceName,
  //       })) || [], // fallback to empty array
  //   },
  //   { name: "IP Address", uid: "resourceIp", sortable: true, searchIP: true },
  //   { name: "Alarm Name", uid: "alarmName", sortable: true, searchName: true },
  //   {
  //     name: "Description",
  //     uid: "alarmDescription",
  //     width: "244px",

  //     sortable: true,
  //     searching: true,
  //   },

  //   {
  //     name: "Severity",
  //     uid: "severity",
  //     sortable: true,
  //     searchSeverity: true,
  //     filterType: "dropdown",
  //     width: "115px",

  //     // Static options
  //     filterOptions: Object.keys(severityConfig).map((key) => {
  //       return {
  //         label: severityConfig[key].label,
  //         value: key, // Use the string key directly ("MAJOR", "MINOR", etc.)
  //         gradient: severityConfig[key].gradient, // Note: changed from .gradient to .dotGradient to match your config
  //       };
  //     }),
  //   },

  //   {
  //     name: "Work Flow",
  //     uid: "workflow",
  //     filterType: "dropdown",
  //     width: "125px",

  //     filterOptions: [
  //       { label: "ACK", value: 1 },
  //       { label: "NOT_ACK", value: 0 },
  //     ],
  //   },

  //   {
  //     name: "Date and Time",
  //     uid: "dateTime",
  //     sortable: true,
  //     searchDate: true,
  //     filterType: "datetime",
  //   },
  //   { name: "Count", uid: "alarmCount", sortable: true, width: "80px" },
  // ];
  const columns = isCnms
  ? [
      {
        name: "Terminal",
        uid: "terminalTypeName",
        sortable: true,
        width: "100px",
      },
      {
        name: "Site ID",
        uid: "siteId",
        sortable: true,
        width: "100px",
      },
      {
        name: "Site Name",
        uid: "siteName",
        sortable: true,
        width: "150px",
      },
      {
        name: "Device Name",
        uid: "resourceName",
        sortable: true,
        width: "150px",
      },
      {
        name: "Alarm Name",
        uid: "alarmName",
        sortable: true,
        width: "160px",
      },
      {
        name: "Description",
        uid: "alarmDescription",
        sortable: true,
        width: "220px",
      },
      {
        name: "Severity",
        uid: "severity",
        sortable: true,
        width: "115px",
      },
      {
        name: "Work Flow",
        uid: "workflow",
        sortable: true,
        width: "125px",
      },
      {
        name: "Date and Time",
        uid: "dateTime",
        sortable: true,
        width: "180px",
      },
      {
        name: "Count",
        uid: "alarmCount",
        sortable: true,
        width: "80px",
      },
    ]
  : [
      {
        name: "Segment",
        uid: "segmentName",
        sortable: true,
        width: "144px",
        filterType: "dropdown",
        filterOptions:
          segments?.map((s) => ({
            label: s.segmentName,
            value: s.segmentName,
          })) || [],
      },
      {
        name: "Device",
        uid: "resourceName",
        sortable: true,
        filterType: "dropdown",
        filterOptions:
          resources?.map((r) => ({
            label: r.resourceName,
            value: r.resourceName,
          })) || [],
      },
      {
        name: "IP Address",
        uid: "resourceIp",
        sortable: true,
        searchIP: true,
      },
      {
        name: "Alarm Name",
        uid: "alarmName",
        sortable: true,
        searchName: true,
      },
      {
        name: "Description",
        uid: "alarmDescription",
        width: "244px",
        sortable: true,
        searching: true,
      },
      {
        name: "Severity",
        uid: "severity",
        sortable: true,
        searchSeverity: true,
        filterType: "dropdown",
        width: "115px",
        filterOptions: Object.keys(severityConfig).map((key) => ({
          label: severityConfig[key].label,
          value: key,
          gradient: severityConfig[key].gradient,
        })),
      },
      {
        name: "Work Flow",
        uid: "workflow",
        filterType: "dropdown",
        width: "125px",
        filterOptions: [
          { label: "ACK", value: 1 },
          { label: "NOT_ACK", value: 0 },
        ],
      },
      {
        name: "Date and Time",
        uid: "dateTime",
        sortable: true,
        searchDate: true,
        filterType: "datetime",
      },
      {
        name: "Count",
        uid: "alarmCount",
        sortable: true,
        width: "80px",
      },
    ];
  // const filteredAlaramData = React.useMemo(() => {
  //   if (!isDrawerMode) {
  //     return alarmData;
  //   }

  //   return [...alarmData]
  //     .sort((a, b) => new Date(b.dateTime) - new Date(a.dateTime))
  //     .slice(0, limit);
  // }, [alarmData, isDrawerMode, limit]);

  //  const filteredAlaramData = alarmData;
  // const severityMap = {
  //   0: { label: "warning", toastType: "info" },
  //   1: { label: "minor", toastType: "warning" },
  //   2: { label: "major", toastType: "error" },
  // };

  // const workflowMap = {
  //   1: "ACK",
  //   0: "NOT_ACK",
  // };

  // Universal search in the alarm table

  // const filteredAlaramData = React.useMemo(() => {
  //   let filterData = [...alarmData];

  //   if (hasSearchFilter && filterValue) {
  //     filterData = filterData.filter((user) => {
  //       const str = filterValue.toLowerCase();
  //       // Convert created_time to string in the desired format for searching
  //       let userDateTimeStr = "";
  //       if (user.created_time) {
  //         const date = new Date(user.createdTime);
  //         const month = String(date.getMonth() + 1).padStart(2, "0");
  //         const day = String(date.getDate()).padStart(2, "0");
  //         const year = date.getFullYear();
  //         // const hours = String(date.getHours());
  //         const minutes = String(date.getMinutes()).padStart(2, "0");
  //         const seconds = String(date.getSeconds()).padStart(2, "0");
  //         const ampm = date.getHours() >= 12 ? "Pm" : "Am";
  //         const formattedHours =
  //           date.getHours() % 12 === 0 ? 12 : date.getHours() % 12;

  //         userDateTimeStr = `${month}/${day}/${year}, ${formattedHours}:${minutes}:${seconds} ${ampm}`;
  //       }
  //       console.log(userDateTimeStr, "userDateTimeStr");

  //       const userId = user?.alarmId?.toLowerCase();
  //       const userName = user?.alarmName?.toLowerCase();
  //       const userDescription = user?.alarmDescription?.toLowerCase();
  //       // const nodeName = user?.nodeName?.toLowerCase();

  //       const userDevice = user?.resourceName?.toLowerCase();
  //       const userSegment = user?.segmentName?.toLowerCase();

  //       // const userIP = user?.resourceDetails?.resourceIp?.toLowerCase();
  //       const userDateTime = user.created_time?.toLowerCase();
  //       const workflowStateName = workflowMap[user.workflow];
  //       const severityName = severityMap[user.severity];
  //       // alert(userDevice)
  //       console.log(userSegment, "filteredAlaramData");
  //       return (
  //         userName?.includes(str) ||
  //         userId?.includes(str) ||
  //         userDescription?.includes(str) ||
  //         userDevice?.includes(str) ||
  //         userSegment?.includes(str) ||
  //         // userIP?.includes(str) ||
  //         // nodeName?.includes(str) ||
  //         (userDateTime && userDateTime.includes(str)) ||
  //         userDateTimeStr?.includes(str) ||
  //         workflowStateName?.toLowerCase().includes(str) ||
  //         severityName?.toLowerCase().includes(str)
  //       );
  //     });
  //   }

  //   return filterData;
  // }, [alarmData, filterValue, hasSearchFilter]);
  const filteredAlaramData = React.useMemo(() => {
    if (!isDrawerMode) {
      return alarmData;
    }
  
    const recentLimit = Math.max(0, Number(limit) || 0);
  
    return [...alarmData]
      .sort((a, b) => {
        const dateB = new Date(b.dateTime).getTime();
        const dateA = new Date(a.dateTime).getTime();
  
        // Keep invalid/missing dates from breaking the sort.
        if (!Number.isFinite(dateB) || !Number.isFinite(dateA)) {
          return 0;
        }
  
        return dateB - dateA;
      })
      .slice(0, recentLimit);
  }, [alarmData, isDrawerMode, limit]);
  
  const VisibleContent = React.useMemo(() => {
    return (
      <Tooltip
        title="Column Filter"
        placement="bottom"
        arrow={false}
        overlayInnerStyle={{ backgroundColor: "#808080" }}
      >
        <div className="flex flex-col gap-5">
          <div className="flex justify-between gap-3 items-end">
            <div className="flex gap-2 mt-2">
              <SelectedCol
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
              />
            </div>
          </div>
        </div>
      </Tooltip>
    );
  }, [visibleColumns]);

  // const headerColumns = React.useMemo(() => {
  //   // used for the Download the PDF
  //   if (visibleColumns === "") return columns;
  //   return columns.filter((column) =>
  //     Array.from(visibleColumns).includes(column.uid)
  //   );
  // }, [visibleColumns]);
  const headerColumns = React.useMemo(() => {
    // In drawer mode, show all columns for the selected alarm type.
    if (isDrawerMode) {
      return columns;
    }
  
    if (visibleColumns === "") return columns;
  
    return columns.filter((column) =>
      Array.from(visibleColumns).includes(column.uid)
    );
  }, [columns, visibleColumns, isDrawerMode]);
  const handleUpdatedAlarm = useCallback(
    (updatedAlarm) => {
      dispatch(updateSingleAlarm(updatedAlarm));
    },
    [dispatch]
  );
  // useEffect(() => {
  //   if (updatedAlarmData) {
  //     console.log("useEffect - Applying socket update...");
  //     handleUpdatedAlarm(updatedAlarmData);
  //   }
  // }, [updatedAlarmData]);

  return (
    <div className="active-alarm-container mt-0 items-center">
    
       
        <Box

        // className={` ${!isMaximized ? "-mt-9" : "m-0"}`}
        >
          <div className="flex">
            <MTable
              columns={headerColumns}
              tableData={filteredAlaramData}
              tableTitle="Active Alarms"
              showPagination={!isDrawerMode}
              showSearch={!isDrawerMode}
              showVisibleContent={!isDrawerMode}
              showMaximazed={!isDrawerMode}
              // If it's the drawer, we pass null to the download functions
              // so the download icon disappears from MTable
              handleDownloadPDF={
                isDrawerMode
                  ? null
                  : () =>
                      exportToPDF(
                        "Active Alarms",
                        headerColumns,
                        filteredAlaramData,
                        "Alarm_Report",
                        "user"
                      )
              }
              handleDownloadCSV={
                isDrawerMode
                  ? null
                  : () =>
                      exportToCSV("Alarm_Report", columns, filteredAlaramData)
              }
              // ---------------------------

              VisibleContent={VisibleContent}
              isMaximized={isMaximized}
              toggleMaximize={toggleMaximize}
              showSelect={!isDrawerMode}
              // onRowClick={handleAcknowledgeClick}
              onRowClick={isCnms ? undefined : handleAcknowledgeClick}
            />
          </div>
        </Box>
     
      <AckTable
        isOpen={isAckModalOpen}
        onCancel={() => setIsAckModalOpen(false)}
        ackdata={selectedAlarm}
        handleWorkflowUpdate={handleUpdatedAlarm}
        refreshData={fetchData}
      />
      <EndTable
        isOpen={isEndModalOpen}
        onCancel={() => setIsEndModalOpen(false)}
        ackdata={selectedAlarm}
        handleWorkflowUpdate={handleUpdatedAlarm}
        refreshData={fetchData}
      />{" "}
    </div>
  );
};

export default ActiveAlarmTable;
