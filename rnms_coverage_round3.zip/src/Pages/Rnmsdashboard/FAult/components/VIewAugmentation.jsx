/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : SeverityCount.jsX
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\SeverityCount.jsX
   Purpose                  : The purpose is to show the Alarm Timeline which contains more info of the specific Alarm  
   Created Date             : 19-02-2026
 *******************************************************************************************/
import React, { useState, useEffect, useCallback } from "react";
import { Grid, Box, Typography } from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal";
import MTable from "@/components/Reusable/Table/MTable";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { VIEW_ALARM_AUGMENTATION } from "@/RestAPI/url/endpoint";
import MTextAreaAntD from "@/components/Reusable/Texarea/MTextArea";
import { severityConfig } from "@/lib/utils";
const ViewAugmentation = ({ isOpen, onCancel, ackdata = [] }) => {
  const [formData, setFormData] = useState({
    alarmName: "",
    resourceIp: "",
    resourceName: "",
    segmentName: "",
    alarmDescription: "",
    severity:""
  });

  // State to hold the table data returned from API
  const [tableRows, setTableRows] = useState([]);
  const [loading, setLoading] = useState(false);

  // Define columns to match your API response keys
  const columns = [
    { name: "COUNT", uid: "alarmCount" },
    // { name: "ALARM NAME", uid: "alarmName" },
    { name: "ALARM DESCRIPTION", uid: "alarmDescription" },
    { name: "DATE TIME", uid: "dateTime" },
{
      name: "SEVERITY",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",

      // Static options
      filterOptions: Object.keys(severityConfig).map((key) => {
        return {
          label: severityConfig[key].label,
          value: key, // Use the string key directly ("MAJOR", "MINOR", etc.)
          gradient: severityConfig[key].gradient, // Note: changed from .gradient to .dotGradient to match your config
        };
      }),
    },

  ];

  // 1. Handle Form Data Sync
  useEffect(() => {
    if (isOpen && ackdata && ackdata.length > 0) {
      const data = ackdata[0];
      setFormData({
        alarmName: data.alarmName || "NA",
        resourceIp: data.resourceIp || "NA",
        resourceName: data.resourceName || "NA",
        segmentName: data.segmentName || "NA",
        alarmDescription: data.alarmDescription || "NA",
        severity: data.severity || "NA",
      });
    }
  }, [isOpen, ackdata]);

  const fetchAugmentationData = useCallback(async () => {
    if (!isOpen || !ackdata || ackdata.length === 0) return;

    setLoading(true);
    try {
      const payload = ackdata[0];

      const res = await FaultAxios(
        `${VIEW_ALARM_AUGMENTATION}`,
        "post",
        payload
      );

      if (res && res.data && Array.isArray(res.data)) {
        const sortedData = [...res.data].sort((a, b) => {
          return a.alarmCount - b.alarmCount;
        });
        setTableRows(sortedData);
      } else {
        console.warn("API response did not contain a data array!", res);
        setTableRows([]);
      }
    } catch (err) {
      console.error("Error fetching augmentation data:", err);
    } finally {
      setLoading(false);
    }
  }, [isOpen, ackdata]);

  // 3. Trigger API call only when modal opens or ackdata changes
  useEffect(() => {
    fetchAugmentationData();
  }, [fetchAugmentationData]);

  return (
    <MModal
      open={isOpen}
      title="ALARM TIMELINE"
      handleClose={onCancel}
      fullWidth
      customWidth="100%"
      enableFullScreen
    >
      <Grid
        spacing={3}
        sx={{
          display: "grid",
          gridTemplateColumns: "0.32fr 1fr",
          gap: 2,
          // justifyContent: "center",
          alignItems: "center",
        }}
        fullWidth
      >
        {/* Fields Section */}
        <Grid
          item
          xs={12}
          sx={{ borderRight: "2px solid #c1c1c1", paddingRight: "5px", paddingBottom:'5px' }}
        >
          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            Alarm Details
          </Typography>
          <Grid spacing={2} className="grid grid-cols-1 gap-2" fullWidth>
            <Grid item xs={12} md={6}>
              <Typography variant="body2">Segment Name</Typography>
              <MTextAreaAntD
                fullWidth
                value={formData.segmentName}
                disabled
                autoSize={{ minRows: 1 }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="body2">Device Name</Typography>
              <MTextAreaAntD
                fullWidth
                value={formData.resourceName}
                disabled
                autoSize={{ minRows: 1 }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2">IP Address</Typography>
              <MTextAreaAntD
                fullWidth
                value={formData.resourceIp}
                disabled
                autoSize={{ minRows: 1 }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2">Alarm Name</Typography>
              <MTextAreaAntD
                fullWidth
                value={formData.alarmName}
                disabled
                autoSize={{ minRows: 1 }}
              />
            </Grid>
            {/* <Grid item xs={12} md={4}>
              <Typography variant="body2">Description</Typography>
              <MTextAreaAntD
                value={formData.alarmDescription}
                autoSize={{ minRows: 1, maxRows: 3 }}
                disabled
                type="textArea"
                multiline
              />
            </Grid> */}
          </Grid>
        </Grid>

        {/* Occurrence Table Section */}
        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            Occurrence Statistics
          </Typography>
          <Box
            sx={{
              // border: "2px solid #eee",
              borderRadius: "20px",
            }}
          >
            <MTable
              tableData={tableRows} // Use the state from API
              columns={columns}
              tableTitle="Alarm Timeline"
              showPagination={true}
              showSearch={true}
            />
          </Box>
          {loading && (
            <Typography variant="caption">Loading data...</Typography>
          )}
        </Grid>
      </Grid>
    </MModal>
  );
};

export default ViewAugmentation;
