import { MenuItem, Paper } from "@mui/material";
import React from "react";

const AlarmComtextMenu = ({ 
  contextMenu,
  onClose,
  onAction,
  // alarmCount,
  // ackdata,
  selectedKeys,
}) => {


  const node = contextMenu.node
  console.log(
    node,

    "HelloDaataa"
  );

  console.log(Array.from(selectedKeys), "Selected Alarm IDs");
  if (!contextMenu.open) return null;

  const rootItems = [
    { id: "ALARM1", label: "ACK" },
    { id: "ALARM2", label: "SERVICE" },
    { id: "ALARM3", label: "VIEW AUGMENTATION" },
    // { id: 'ALARM4', label: 'RAISE TICKET' },
  ];

  //   const handleMenuClick = (action) => {
  //     console.log("Action:", action);
  //     console.log("Node Data:", contextMenu.node);
  //     handleCloseMenu();
  // };
  //   const handleRightClick = (event, node) => {
  //     setContextMenu({
  //         mouseX: event.clientX - 2,
  //         mouseY: event.clientY - 4,
  //         node,
  //     });
  // };

  //   const handleCloseMenu = () => {
  //     setContextMenu(null);
  // };

  const items = [];
  // Condition 1: ackdata array length > 1
  // if (selectedKeys.size <= 1) {
  if (node.workflow === 0) {
    items.push(rootItems.find((item) => item.id === 'ALARM1'));
  } else if (node.workflow === 1) {
    items.push(rootItems.find((item) => item.id === 'ALARM2'));
  }
    items.push(rootItems.find((item) => item.id === 'ALARM3'));
  // }

  // // (Condition 2: alarmCount > 1
  // console.log(selectedKeys.size,alarmCount > 1 && selectedKeys.size === 1,node.alarmCount , "selectedKeys.size")
  // if (node.alarmCount > 1 && selectedKeys.size === 1) {
  // }

  console.log(items, 'HelloDaataa')
  return (
    <Paper
      sx={{
        position: "fixed",
        top: contextMenu.y,
        left: contextMenu.x,
        zIndex: 1300,
        minWidth: 180,
        boxShadow: 3,
      }}
      onMouseLeave={onClose}
    >
      {items.map((item) => (
        <MenuItem
          key={item.id}
          onClick={() => {
            onAction(item.id, contextMenu.node);
            onClose();
          }}
        >
          {item.label}
        </MenuItem>
      ))}
    </Paper>
  );
};

export default AlarmComtextMenu;
