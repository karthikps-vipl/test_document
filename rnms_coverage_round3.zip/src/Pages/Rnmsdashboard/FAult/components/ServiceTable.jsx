import MModal from '@/components/Reusable/Modal/MModal'
import React from 'react'

const ServiceTable = ({ isOpen, onCancel, ackdata, alarmId, uid }) => {
  return (
    <MModal open={isOpen}
       title={'ALARM WORKFLOW'}
     
       handleClose={onCancel}
       size="5xl"
       style={{ height: '80%', width: '90%', overflowY: 'auto' }}>
   
           Hello Service
       </MModal>
  )
}

export default ServiceTable
