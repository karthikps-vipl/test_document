/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult\components
   File Name                : AlarmContextMenu.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\components\AlarmContextMenu.jsx
   Purpose                  : The purpose is to show the chart related data for the Fault Summary. 
   Created Date             : 12-01-2026
 *******************************************************************************************/

// import { MenuItem, Paper } from "@mui/material";
// import React from "react";

// const AlarmComtextMenu = ({
//   contextMenu,
//   onClose,
//   onAction,
//   selectionMeta,
//   // alarmCount,
//   ackdata,
//   selectedKeys,
// }) => {
//   const node = contextMenu.node;
//   console.log(
//     node,

//     "HelloDaataa"
//   );

//   console.log(Array.from(selectedKeys), "Selected Alarm IDs");
//   console.log(ackdata, "ackdata");
//   if (!selectionMeta || !contextMenu.open) return null;

//   const isMultiSelect = node.alarmCount > 1;

//   const rootItems = [
//     { id: "ALARM1", label: "NOT ACK" },
//     { id: "ALARM2", label: "ACK" },
//     { id: "ALARM3", label: "VIEW AUGMENTATION" },
//     { id: "ALARM4", label: "RAISE TICKET" },
//   ];

//   //   const handleMenuClick = (action) => {
//   //     console.log("Action:", action);
//   //     console.log("Node Data:", contextMenu.node);
//   //     handleCloseMenu();
//   // };
//   //   const handleRightClick = (event, node) => {
//   //     setContextMenu({
//   //         mouseX: event.clientX - 2,
//   //         mouseY: event.clientY - 4,
//   //         node,
//   //     });
//   // };

//   //   const handleCloseMenu = () => {
//   //     setContextMenu(null);
//   // };

//   const items = [];
//   if (selectedKeys.size <= 1) {
//     if (node.workflow === 0) {
//       items.push(rootItems.find((item) => item.id === "ALARM1"));
//     } else if (node.workflow === 1) {
//       items.push(rootItems.find((item) => item.id === "ALARM2"));
//     } else if (node.workflow === 2) {
//       items.push(rootItems.find((item) => item.id === "ALARM3"));
//     }
//     items.push(rootItems.find((item) => item.id === "ALARM4"));
//   }

//   return (
//   );
// };

// export default AlarmComtextMenu;
import { MenuItem, Paper, useTheme } from "@mui/material";
import Ack_Tick_Icon from "@/assets/SVGIcons/Ack_Tick_Icon_org.svg";
import Raise_Ticket_Icon from "@/assets/SVGIcons/Raise_Ticket_Icon.svg";
import End_Icon from "@/assets/SVGIcons/End_Icon.svg";
import { TrendingUp } from "@mui/icons-material";

const AlarmComtextMenu = ({
  contextMenu,
  onClose,
  onAction,
  selectionMeta,
  // finalSelectedRows is no longer strictly needed for visibility
  // because we use selectionMeta flags, but we keep it for safety
}) => {
  if (!selectionMeta || !contextMenu.open) return null;
  const node = contextMenu.node;

  const isMultiSelect = node.alarmCount > 1;
  const theme = useTheme();
  return (
    <Paper
      sx={{
        position: "fixed",
        top: contextMenu.y,
        left: contextMenu.x,
        zIndex: 1300,
        minWidth: 180,
        boxShadow: 3,
      }}
      onMouseLeave={onClose}
    >
      {/* Show ACK if there are rows that need acknowledging */}
      {selectionMeta?.hasNotAck && (
        <MenuItem
          onClick={() => onAction("ACK")}
          sx={{ display: "flex", gap: 1 }}
        >
          {" "}
          <img
            src={Ack_Tick_Icon}
            alt="ACK"
            style={{
              filter: theme.palette.custom.icon.iconFilter,
            }}
          />
          ACK
        </MenuItem>
      )}

      {/* Show END if there are rows that are already acknowledged */}
      {selectionMeta?.hasAck && (
        <MenuItem
          onClick={() => onAction("END")}
          sx={{ display: "flex", gap: 1}}
        >
          {" "}
          <img
            src={End_Icon}
            alt="END"
            style={{
              filter: theme.palette.custom.icon.iconFilter,
            }}
          />
          END
        </MenuItem>
      )}

      {/* Show VIEW if it's a multi-select and contains either type */}
      {(selectionMeta?.hasNotAck || selectionMeta?.hasAck) &&
        isMultiSelect &&
        selectionMeta?.isSingle && (
          <MenuItem
            onClick={() => onAction("VIEW")}
            sx={{ display: "flex", gap: 1 }}
          >
            {/* <img
              src={RnmsDownIcon}
              alt="VIEW"
              style={{
                filter: theme.palette.custom.icon.iconFilter,
              }}
            /> */}
            <TrendingUp
              style={{
                filter: theme.palette.custom.icon.iconFilter,
                color: "#344d96",
              }}
            />
            ALARM TIMELINE
          </MenuItem>
        )}

      {/* Show TICKET only if a single row is selected */}
      {selectionMeta?.isSingle && !selectionMeta?.isTicketRaised && (
        <MenuItem
          onClick={() => onAction("TICKET")}
          sx={{ display: "flex", gap: 1 }}
        >
          <img
            src={Raise_Ticket_Icon}
            alt="TICKET"
            style={{
              width: "23px",
              height: "23px",
              objectFit: "contain",
              filter: selectionMeta?.isTicketRaised
                ? "grayscale(1) opacity(0.45)"
                : theme.palette.custom.icon.iconFilter,
            }}
          />
          RAISE TICKET
        </MenuItem>
      )}
    </Paper>
  );
};
export default AlarmComtextMenu;
