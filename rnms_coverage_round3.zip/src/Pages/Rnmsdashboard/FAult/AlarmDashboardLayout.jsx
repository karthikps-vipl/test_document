/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FAult
   File Name                : AlarmDashboardLayout.jsX
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\FAult\AlarmDashboardLayout.jsx
   Purpose                  : The purpose is to show the Rendering of the Entire Fault Alarm page from this file  
   Created Date             : 20-02-2026
 *******************************************************************************************/
import React from "react";
import ActiveAlarmTable from "./components/ActiveAlarmTable";
import SeverityCount from "./components/SeverityCount";
import AlarmChart from "./components/AlarmChart";
import { useSelector } from "react-redux";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
import { Box } from "@mui/material";

export default function Fault() {
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);
console.log("isMaximizedisMaximized", isMaximized)
  return (
    // <div className="grid grid-rows-auto   px-4 py-1 gap-4">
    <Box
      className={`h-full flex flex-col gap-2 p-2    `} sx={{background: (theme) => theme.palette.background.paper}}
    >
         <ScrollContainer className="h-full">
      {/* If maximized, hide everything except the table */}
      {!isMaximized && (
        <>
          <Box className="sticky top-0 z-10   pb-2 flex-none transition-all duration-300"  sx={{background: (theme) => theme.palette.background.paper}}>
            <SeverityCount />
          </Box>
          <Box className="flex-none transition-all duration-300 "  sx={{background: (theme) => theme.palette.background.paper}}>
            <AlarmChart />
          </Box>
        </>
      )}

      {/* Main Content Area */}
      <div className="flex-grow mt-2">
    <ActiveAlarmTable />
 
       
      </div>
      </ScrollContainer>
    </Box>
  );
}
// export default function Fault() {
//   const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

//   return (
//     <Box
//       // h-full and flex-col are vital to ensure the layout stays within screen bounds
//       className="h-full flex flex-col " 
//       sx={{ 
//         background: (theme) => theme.palette.background.paper,
//         overflow: "hidden" // This prevents the entire page from scrolling
//       }}
//     >
//       {/* 1. FIXED SECTION: This is NOT inside the ScrollContainer */}
//       {!isMaximized && (
//         <Box 
//           className="flex-none z-20 bg-white p-2" 
         
//         >
//           <SeverityCount />
//         </Box>
//       )}

//       {/* 2. SCROLLING SECTION: Everything else goes here */}
//       {/* We use h-full here so the ScrollContainer fills the remaining space */}
//       <Box className="flex-grow h-full">
//         <ScrollContainer className="h-full">
//           <Box className="p-2">
//             {!isMaximized && (
//               <Box className="flex-none pb-4">
//                 <AlarmChart />
//               </Box>
//             )}

//             {/* Main Content Area */}
//             <Box className="w-full">
//               <ActiveAlarmTable />
//             </Box>
//           </Box>
//         </ScrollContainer>
//       </Box>
//     </Box>
//   );
// }