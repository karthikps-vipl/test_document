import React from "react";
import ActiveAlarmTable from "./components/ActiveAlarmTable";
import SeverityCount from "./components/SeverityCount";
import AlarmChart from "./components/AlarmChart";

export default function Fault() {
  return (
    <div className="grid grid-rows-auto p-4 gap-4">
      {/* Severity Count & Filters */}
      <div className="flex justify-start  w-full mt-2">
        <SeverityCount />
      </div>
      <div className="flex  w-full mb-2">
        <AlarmChart />
      </div>

      {/* Main Content Area */}
      <div className="w-full  -mt-4">
        <ActiveAlarmTable />
      </div>
    </div>
  );
}
