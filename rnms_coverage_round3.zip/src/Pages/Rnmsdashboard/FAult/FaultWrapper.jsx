import React from "react";
import ActiveAlarmTable from "./components/ActiveAlarmTable";
import SeverityCount from "./components/SeverityCount";
// import AlarmChart from "./components/AlarmChart";
export default function Fault() {
  return (
    <div className="grid grid-rows-3 gap-4">
      <div className="flex justify-start w-full max-h-20 mt-3">
        <SeverityCount />
      </div>

      <div className="flex justify-center align-middle text-center -mt-14 p-5">
        {/* <div><AlarmChart/> </div> */}
      </div>

      <div className="w-full ">
        <ActiveAlarmTable />
      </div>
    </div>
  );
}
