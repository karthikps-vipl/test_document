import React from "react";
import { Button, Box, Typography } from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal";
import useLogout from "@/utility/customHooks/useLogout";
import { ExitToAppSharp } from "@mui/icons-material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
 
const LogoutDialog = ({ open }) => {
  const { logoutHandler } = useLogout();

  const handleLogout = async () => {
    await logoutHandler();
  };

  return (
    <MModal
      open={open}
      title="CNMS Link Down"
      customWidth="450px"
      showCloseButton={false}
      enableFullScreen={false}
      handleClose={() => {}}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 3,
          py: 2,
        }}
      >
        <Typography
          sx={{
            fontSize: "15px",
            fontWeight: 500,
            textAlign: "center",
          }}
        >
          Link With CNMS is Down, kindly logout.
        </Typography>

        <MButtonPrimary
          startIcon={<ExitToAppSharp />}
          onClick={handleLogout}
        >
          LOGOUT
        </MButtonPrimary>
      </Box>
    </MModal>
  );
};

export default LogoutDialog;
