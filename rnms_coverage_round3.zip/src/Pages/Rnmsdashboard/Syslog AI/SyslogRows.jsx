import React, { useMemo, useState, useEffect } from "react";

import {
  AppBar,
  Toolbar,
  Typography,
  Box,
  Button,
  IconButton,
  Divider,
  Container,
  Stack,
  Paper,
  Grid,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Snackbar,
  Alert,
  Chip,
} from "@mui/material";

import {
  PlayArrow,
  GetApp,
  AppsRounded,
  Storage,
  ErrorOutline,
  ReportProblemOutlined,
  CheckCircleOutline,
  ListAlt,
  PictureAsPdf,
  TableChart,
  CloudDownload,
  Psychology,
} from "@mui/icons-material";

import { useNavigate, useLocation } from "react-router-dom";

import { useSelector } from "react-redux";

import { SyslogAiAxios } from "../../../RestAPI/api/axiosApicall";

import {
  SYSLOG_GET_SYNCED_LOGS,
  SYSLOG_DETAILED_EXPORT_SYNCED,
} from "../../../RestAPI/url/endpoint";

const SyslogRows = () => {
  const navigate = useNavigate();

  const location = useLocation();

  const reduxSelectedDate = useSelector((state) => state.syslog.selectedDate);

  const [filter, setFilter] = useState("all");

  const [allLogs, setAllLogs] = useState([]);

  const [loading, setLoading] = useState(true);

  // ============================================================
  // DATA RECEIVED FROM DASHBOARD
  // ============================================================

  const batchData = location.state?.batchData || {
    id: "0",
    batch: "Manual Entry",
    records: 0,
    crit: 0,
    mod: 0,
    low: 0,
  };

  const selectedModel = location.state?.model || "";

  const dashboardDate = location.state?.selectedDate || reduxSelectedDate || "";

  const liveRowsFromDashboard = Array.isArray(location.state?.liveRows)
    ? location.state.liveRows
    : [];

  const isLive = Boolean(location.state?.live);

  // ============================================================
  // EXPORT STATE
  // ============================================================

  const [anchorEl, setAnchorEl] = useState(null);

  const [exportType, setExportType] = useState(null);

  const [isExporting, setIsExporting] = useState(false);

  const [snackbarOpen, setSnackbarOpen] = useState(false);

  const [snackbarMessage, setSnackbarMessage] = useState("");

  const [snackbarSeverity, setSnackbarSeverity] = useState("success");

  const openExportMenu = Boolean(anchorEl);

  const handleExportClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleOpenPopup = (type) => {
    setExportType(type);
    handleMenuClose();
  };

  const handleClosePopup = () => {
    if (!isExporting) {
      setExportType(null);
    }
  };

  // ============================================================
  // LOAD LIVE BATCH OR COMPLETED BATCH
  // ============================================================

  useEffect(() => {
    const fetchLogs = async () => {
      if (!dashboardDate || !batchData.batch) {
        setAllLogs([]);
        setLoading(false);
        return;
      }

      // ======================================================
      // LIVE BATCH
      // ======================================================
      //
      // During a continuous run the Dashboard already has the
      // processed rows from the SSE event, so use them directly.
      // ======================================================

      if (isLive && liveRowsFromDashboard.length > 0) {
        setAllLogs(liveRowsFromDashboard);

        setLoading(false);

        return;
      }

      // ======================================================
      // COMPLETED BATCH
      // ======================================================

      setLoading(true);

      try {
        const cleanedBatch = batchData.batch
          ? batchData.batch.replace(/\s+/g, "_")
          : "";

        const response = await SyslogAiAxios(
          SYSLOG_GET_SYNCED_LOGS +
            `?selected_date=${encodeURIComponent(
              dashboardDate
            )}&batch_name=${encodeURIComponent(cleanedBatch)}`,
          "get"
        );

        const data = response?.data || {};

        setAllLogs(Array.isArray(data?.logs) ? data.logs : []);
      } catch (error) {
        console.error("Fetch Error:", error);

        const errorMessage =
          error?.response?.data?.detail ||
          error?.response?.data?.message ||
          error?.message ||
          "Failed to load synchronized logs.";

        setSnackbarMessage(`Unable to load logs: ${errorMessage}`);

        setSnackbarSeverity("error");

        setSnackbarOpen(true);

        setAllLogs([]);
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
  }, [dashboardDate, batchData.batch, isLive, liveRowsFromDashboard.length]);

  // ============================================================
  // EXPORT REPORT
  // ============================================================

  const executeDownload = async () => {
    if (!dashboardDate) {
      setSnackbarMessage("Please select a date first.");

      setSnackbarSeverity("warning");

      setSnackbarOpen(true);

      return;
    }

    if (!batchData.batch) {
      setSnackbarMessage("No batch selected for download.");

      setSnackbarSeverity("warning");

      setSnackbarOpen(true);

      return;
    }

    setIsExporting(true);

    try {
      const fileFormat = exportType === "PDF" ? "pdf" : "xlsx";

      const endpoint = `${SYSLOG_DETAILED_EXPORT_SYNCED}/${encodeURIComponent(
        batchData.batch
      )}?type=${encodeURIComponent(fileFormat)}&severity=${encodeURIComponent(
        filter
      )}&selected_date=${encodeURIComponent(dashboardDate)}`;

      const response = await SyslogAiAxios(endpoint, "getBlob");

      if (response.status != 200) {
        let errorMessage = `HTTP ${response.status}`;

        try {
          const errorData = await response.json();

          errorMessage =
            errorData?.detail || errorData?.message || errorMessage;
        } catch {
          // Keep status
          // error.
        }

        throw new Error(errorMessage);
      }

      const blob = await response.data;

      if (!(blob instanceof Blob) || blob.size === 0) {
        throw new Error("Server returned an empty download file.");
      }

      const downloadUrl = window.URL.createObjectURL(blob);

      const link = document.createElement("a");

      const extension = exportType === "PDF" ? "pdf" : "xlsx";

      link.href = downloadUrl;

      link.setAttribute(
        "download",
        `${batchData.batch}_${filter}_${dashboardDate}.${extension}`
      );

      link.style.display = "none";

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);

      window.setTimeout(() => {
        window.URL.revokeObjectURL(downloadUrl);
      }, 1000);

      const completedType = exportType;

      setExportType(null);

      setSnackbarMessage(`${completedType} downloaded successfully!`);

      setSnackbarSeverity("success");

      setSnackbarOpen(true);
    } catch (error) {
      console.error("Export Error:", error);

      let errorMessage = "Download failed";

      if (error?.response?.data instanceof Blob) {
        try {
          const errorText = await error.response.data.text();

          const parsed = JSON.parse(errorText);

          errorMessage = parsed?.detail || parsed?.message || errorMessage;
        } catch {
          // Keep default.
        }
      } else {
        errorMessage =
          error?.response?.data?.detail ||
          error?.response?.data?.message ||
          error?.message ||
          errorMessage;
      }

      setSnackbarMessage(`${exportType || "Export"} failed: ${errorMessage}`);

      setSnackbarSeverity("error");

      setSnackbarOpen(true);
    } finally {
      setIsExporting(false);
    }
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setSnackbarOpen(false);
  };

  const sharedDividerStyle = {
    borderBottomWidth: 2,
    borderColor: "rgba(0, 0, 0, 0.08)",
    opacity: 1,
    my: 2,
    width: "100%",
  };

  // ============================================================
  // NORMALISE DISPLAY DATA
  // ============================================================

  const normalisedLogs = useMemo(() => {
    return (allLogs || []).map((log) => {
      const riskValue = Number(log.risk ?? log.risk_score ?? 0) || 0;

      let aiRiskLevel = log.ai_risk_level;

      if (!aiRiskLevel) {
        if (riskValue >= 9) {
          aiRiskLevel = "EMERGENCY";
        } else if (riskValue >= 8) {
          aiRiskLevel = "CRITICAL";
        } else if (riskValue >= 6) {
          aiRiskLevel = "HIGH";
        } else if (riskValue >= 4) {
          aiRiskLevel = "MEDIUM";
        } else if (riskValue >= 2) {
          aiRiskLevel = "LOW";
        } else {
          aiRiskLevel = "INFO";
        }
      }

      return {
        ...log,

        risk: riskValue,

        ai_risk_level: aiRiskLevel,
      };
    });
  }, [allLogs]);

  // ============================================================
  // FILTERING BY RISK
  // ============================================================

  const displayLogs = useMemo(() => {
    const sortedByRisk = [...normalisedLogs].sort(
      (a, b) => (Number(b.risk) || 0) - (Number(a.risk) || 0)
    );

    let filtered;

    switch (filter) {
      case "crit":
        filtered = sortedByRisk.filter((log) => (Number(log.risk) || 0) >= 8);
        break;

      case "mod":
        filtered = sortedByRisk.filter((log) => {
          const risk = Number(log.risk) || 0;

          return risk >= 5 && risk <= 7;
        });
        break;

      case "low":
        filtered = sortedByRisk.filter((log) => {
          const risk = Number(log.risk) || 0;

          return risk >= 1 && risk <= 4;
        });
        break;

      default:
        filtered = sortedByRisk;
    }

    if (filter === "all") {
      return {
        priority: sortedByRisk.slice(0, 4),

        stream: sortedByRisk.slice(4),
      };
    }

    return {
      priority: [],
      stream: filtered,
    };
  }, [normalisedLogs, filter]);

  const leftCol = displayLogs.stream.filter((_, i) => i % 2 === 0);

  const rightCol = displayLogs.stream.filter((_, i) => i % 2 !== 0);

  // ============================================================
  // LOG BOX
  // ============================================================

  const LogBox = ({ log }) => {
    const getSeverityLabel = (val) => {
      const labels = {
        0: "EMERGENCY",
        1: "ALERT",
        2: "CRITICAL",
        3: "ERROR",
        4: "WARNING",
        5: "NOTICE",
        6: "INFO",
        7: "DEBUG",
      };

      return log.severity_label || labels[val] || "LOG";
    };

    const risk = Number(log.risk ?? log.risk_score ?? 0) || 0;

    return (
      <Paper
        elevation={1}
        sx={{
          mb: 4,
          borderRadius: "8px",
          overflow: "hidden",
          width: "100%",
          border: "1px solid #e0e0e0",
          transition: "all 0.2s ease-in-out",

          "&:hover": {
            transform: "translateY(-4px)",
            boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
            borderColor: log.color,
          },
        }}
      >
        <Box
          sx={{
            bgcolor: log.color || "#e0e0e0",

            p: 1,
            px: 2,

            display: "flex",

            justifyContent: "space-between",

            alignItems: "center",

            color: "black",
          }}
        >
          <Stack direction="row" spacing={2} alignItems="center">
            <Typography
              variant="caption"
              sx={{
                fontWeight: 800,
              }}
            >
              {log.timestamp}
            </Typography>

            <Divider
              orientation="vertical"
              flexItem
              sx={{
                bgcolor: "rgba(0,0,0,0.1)",
                width: "1.5px",
              }}
            />

            <Typography
              variant="subtitle2"
              sx={{
                fontWeight: "bold",
              }}
            >
              {log.hostname || "UNKNOWN"}
            </Typography>
          </Stack>

          <Stack direction="row" spacing={1} alignItems="center">
            <Chip
              label={`RISK: ${risk}/10`}
              size="small"
              sx={{
                bgcolor: "rgba(255,255,255,0.4)",
                fontWeight: "bold",
                height: 22,
                fontSize: "0.7rem",
              }}
            />

            <Chip
              label={log.ai_risk_level || "ANALYSED"}
              size="small"
              variant="outlined"
              sx={{
                fontWeight: "bold",
                height: 22,
                fontSize: "0.65rem",
              }}
            />
          </Stack>
        </Box>

        <Box
          sx={{
            p: 2,
            bgcolor: "white",
          }}
        >
          <Grid
            container
            spacing={1}
            sx={{
              mb: 1.5,
            }}
            justifyContent="space-between"
          >
            <Grid item xs={2.5}>
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  fontWeight: "bold",
                  display: "block",
                }}
              >
                ID
              </Typography>

              <Typography
                variant="body2"
                sx={{
                  fontWeight: "bold",
                }}
              >
                #{log.id}
              </Typography>
            </Grid>

            <Grid item xs={4.5}>
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  fontWeight: "bold",
                  display: "block",
                }}
              >
                FACILITY
              </Typography>

              <Typography
                variant="body2"
                sx={{
                  fontWeight: "bold",
                  textTransform: "uppercase",
                }}
              >
                {log.facility_label || "N/A"}
              </Typography>
            </Grid>

            <Grid item xs={5}>
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  fontWeight: "bold",
                  display: "block",
                }}
              >
                SYS SEVERITY
              </Typography>

              <Typography
                variant="body2"
                sx={{
                  fontWeight: "bold",
                  color: "#d32f2f",
                }}
              >
                {getSeverityLabel(log.severity_val)} (
                {log.severity_val ?? "N/A"})
              </Typography>
            </Grid>
          </Grid>

          <Divider
            sx={{
              my: 1,
              opacity: 0.5,
            }}
          />

          <Typography
            variant="caption"
            sx={{
              color: "primary.main",
              fontWeight: 800,
              textTransform: "uppercase",
              fontSize: "0.65rem",
            }}
          >
            Original Message
          </Typography>

          <Typography
            variant="body2"
            sx={{
              mb: 2,
              color: "text.primary",
              fontFamily: "monospace",
              bgcolor: "#f5f5f5",
              p: 1,
              borderRadius: "4px",
              mt: 0.5,
              wordBreak: "break-all",
            }}
          >
            {log.message || "N/A"}
          </Typography>

          <Typography
            variant="caption"
            sx={{
              color: "secondary.main",
              fontWeight: 800,
              textTransform: "uppercase",
              fontSize: "0.65rem",
            }}
          >
            AI Insight
          </Typography>

          <Box
            sx={{
              display: "flex",
              gap: 1,
              mt: 0.5,
              alignItems: "flex-start",
            }}
          >
            <Psychology
              sx={{
                fontSize: 18,
                color: "secondary.main",
                mt: 0.3,
              }}
            />

            <Typography
              variant="body2"
              sx={{
                fontStyle: "italic",
                color: "text.primary",
                lineHeight: 1.4,
                whiteSpace: "pre-line",
              }}
            >
              {log.ai_insight || "No AI insight available."}
            </Typography>
          </Box>
        </Box>
      </Paper>
    );
  };

  // ============================================================
  // UI
  // ============================================================

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        maxHeight: "100vh",
        bgcolor: "#f8f9fa",
        overflow: "hidden",
      }}
    >
      <AppBar
        position="static"
        color="inherit"
        elevation={1}
        sx={{
          bgcolor: "white",
          flexShrink: 0,
        }}
      >
        <Toolbar
          sx={{
            justifyContent: "space-between",
          }}
        >
          <Stack direction="row" spacing={2} alignItems="center">
            <Stack direction="row" spacing={1} alignItems="center">
              <AppsRounded color="primary" />

              <Typography
                variant="h6"
                sx={{
                  fontWeight: 800,
                  letterSpacing: -0.5,
                }}
              >
                SYSLOG ANOMALY DETECTOR
              </Typography>
            </Stack>

            <Divider
              orientation="vertical"
              flexItem
              sx={{
                height: 24,
                mx: 1,
              }}
            />

            <Stack direction="row" spacing={1} alignItems="center">
              <Typography
                variant="body2"
                sx={{
                  color: "text.secondary",
                  fontWeight: "bold",
                }}
              >
                MODEL:
              </Typography>

              <Chip
                icon={
                  <Psychology
                    sx={{
                      fontSize: "25px !important",
                      color: "primary.main",
                    }}
                  />
                }
                label={
                  selectedModel ? selectedModel.replace(/_/g, " ") : "No Model"
                }
                size="small"
                sx={{
                  fontWeight: 800,
                  borderRadius: "4px",
                  color: "black",
                  px: 1,
                }}
              />
            </Stack>

            {isLive && (
              <Chip
                label="LIVE"
                color="success"
                size="small"
                sx={{
                  fontWeight: 800,
                }}
              />
            )}
          </Stack>
        </Toolbar>
      </AppBar>

      <Box
        sx={{
          flexGrow: 1,
          overflowY: "auto",
          p: 0,
        }}
      >
        <Container
          maxWidth="xxl"
          sx={{
            mt: 4,
            mb: 4,
          }}
          disableGutters
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 3,
              px: 3,
            }}
          >
            <Stack direction="row" spacing={2} alignItems="center">
              <IconButton
                onClick={() => navigate(-1)}
                sx={{
                  border: "1px solid #ddd",
                  bgcolor: "white",
                }}
              >
                <PlayArrow
                  sx={{
                    transform: "rotate(180deg)",
                  }}
                />
              </IconButton>

              <Box>
                <Typography
                  variant="h4"
                  sx={{
                    fontWeight: 900,
                    color: "#1a237e",
                  }}
                >
                  {batchData.batch}

                  {isLive && (
                    <Chip
                      label="LIVE"
                      color="success"
                      size="small"
                      sx={{
                        ml: 1,
                        verticalAlign: "middle",
                        fontWeight: 800,
                      }}
                    />
                  )}
                </Typography>

                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: "bold",
                    color: "text.secondary",
                  }}
                >
                  <Storage
                    sx={{
                      fontSize: 16,
                      verticalAlign: "middle",
                      mr: 0.5,
                    }}
                  />
                  {Number(batchData.records || 0).toLocaleString()} TOTAL
                  RECORDS | DATE: {dashboardDate}
                </Typography>

                {isLive && (
                  <Typography
                    variant="caption"
                    color="success.main"
                    sx={{
                      fontWeight: 700,
                    }}
                  >
                    Live batch received from continuous PostgreSQL processing
                  </Typography>
                )}
              </Box>
            </Stack>

            <Stack direction="row" spacing={1} alignItems="center">
              <Button
                variant={filter === "all" ? "contained" : "outlined"}
                startIcon={<ListAlt />}
                onClick={() => setFilter("all")}
                sx={{
                  fontWeight: "bold",
                  borderRadius: "20px",
                }}
              >
                ALL
              </Button>

              <Button
                variant={filter === "crit" ? "contained" : "outlined"}
                color="error"
                startIcon={<ErrorOutline />}
                onClick={() => setFilter("crit")}
                sx={{
                  fontWeight: "bold",
                  borderRadius: "20px",
                }}
              >
                CRITICAL ({batchData.crit || 0})
              </Button>

              <Button
                variant={filter === "mod" ? "contained" : "outlined"}
                startIcon={<ReportProblemOutlined />}
                onClick={() => setFilter("mod")}
                sx={{
                  fontWeight: "bold",
                  borderRadius: "20px",
                  color: filter === "mod" ? "white" : "#fbc02d",
                  borderColor: "#fbc02d",
                  bgcolor: filter === "mod" ? "#fbc02d" : "transparent",
                  "&:hover": {
                    bgcolor: filter === "mod" ? "#f9a825" : "transparent",
                  },
                }}
              >
                MODERATE ({batchData.mod || 0})
              </Button>

              <Button
                variant={filter === "low" ? "contained" : "outlined"}
                color="success"
                startIcon={<CheckCircleOutline />}
                onClick={() => setFilter("low")}
                sx={{
                  fontWeight: "bold",
                  borderRadius: "20px",
                }}
              >
                LOW ({batchData.low || 0})
              </Button>

              <Divider
                orientation="vertical"
                flexItem
                sx={{
                  mx: 1,
                }}
              />

              <Button
                variant="contained"
                startIcon={<GetApp />}
                onClick={handleExportClick}
                sx={{
                  fontWeight: "bold",
                }}
              >
                EXPORT
              </Button>

              <Menu
                anchorEl={anchorEl}
                open={openExportMenu}
                onClose={handleMenuClose}
                PaperProps={{
                  sx: {
                    width: 180,
                    mt: 1,
                  },
                }}
              >
                <MenuItem onClick={() => handleOpenPopup("PDF")}>
                  <ListItemIcon>
                    <PictureAsPdf fontSize="small" color="error" />
                  </ListItemIcon>

                  <ListItemText>Export to PDF</ListItemText>
                </MenuItem>

                <MenuItem onClick={() => handleOpenPopup("Excel")}>
                  <ListItemIcon>
                    <TableChart fontSize="small" color="success" />
                  </ListItemIcon>

                  <ListItemText>Export to Excel</ListItemText>
                </MenuItem>
              </Menu>
            </Stack>
          </Box>

          <Box
            sx={{
              px: 3,
            }}
          >
            {loading ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  mt: 10,
                }}
              >
                <CircularProgress />
              </Box>
            ) : (
              <Box>
                {filter === "all" && displayLogs.priority.length > 0 && (
                  <Box
                    sx={{
                      mt: 2,
                    }}
                  >
                    <Typography
                      variant="overline"
                      sx={{
                        fontWeight: 800,
                        color: "primary.main",
                        mb: 1,
                        display: "block",
                      }}
                    >
                      PRIORITY ALERTS (TOP 4 HIGHEST RISK)
                    </Typography>

                    <Grid
                      container
                      spacing={3}
                      sx={{
                        width: "100%",
                        m: "0",
                        display: "grid",
                        gridTemplateColumns: "repeat(2,1fr)",
                        gap: "50px",
                      }}
                    >
                      <Grid item xs={12} md={6}>
                        {displayLogs.priority.slice(0, 2).map((log) => (
                          <LogBox key={log.id} log={log} />
                        ))}
                      </Grid>

                      <Grid item xs={12} md={6}>
                        {displayLogs.priority.slice(2, 4).map((log) => (
                          <LogBox key={log.id} log={log} />
                        ))}
                      </Grid>
                    </Grid>

                    <Divider sx={sharedDividerStyle} />
                  </Box>
                )}

                <Box
                  sx={{
                    mt: filter === "all" ? 0 : 2,
                  }}
                >
                  <Typography
                    variant="overline"
                    sx={{
                      fontWeight: 800,
                      color: "text.secondary",
                      mb: 1,
                      display: "block",
                    }}
                  >
                    {filter === "all"
                      ? "GENERAL LOG STREAM"
                      : `${filter.toUpperCase()} LOG STREAM`}{" "}
                    ({displayLogs.stream.length} ITEMS)
                  </Typography>

                  <Box
                    sx={{
                      width: "100%",
                    }}
                  >
                    <Grid
                      container
                      spacing={3}
                      sx={{
                        width: "100%",
                        m: "0",
                        display: "grid",
                        gridTemplateColumns: "repeat(2,1fr)",
                        gap: "50px",
                      }}
                    >
                      <Grid item xs={12} md={6}>
                        {leftCol.map((log) => (
                          <LogBox key={log.id} log={log} />
                        ))}
                      </Grid>

                      <Grid item xs={12} md={6}>
                        {rightCol.map((log) => (
                          <LogBox key={log.id} log={log} />
                        ))}
                      </Grid>
                    </Grid>
                  </Box>
                </Box>
              </Box>
            )}
          </Box>
        </Container>
      </Box>

      <Dialog
        open={Boolean(exportType)}
        onClose={handleClosePopup}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            fontWeight: "bold",
          }}
        >
          {exportType === "PDF" ? (
            <PictureAsPdf color="error" />
          ) : (
            <TableChart color="success" />
          )}
          Export {exportType}
        </DialogTitle>

        <DialogContent dividers>
          <Typography variant="body1">
            Preparing <strong>{filter.toUpperCase()}</strong> report.
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              mt: 1,
            }}
          >
            Engine:{" "}
            <strong>
              {selectedModel ? selectedModel.replace(/_/g, " ") : "N/A"}
            </strong>
          </Typography>

          <Typography variant="body2" color="text.secondary">
            Source: <strong>PostgreSQL</strong>
          </Typography>

          <Typography variant="body2" color="text.secondary">
            Batch: <strong>{batchData.batch}</strong>
          </Typography>

          <Typography variant="body2" color="text.secondary">
            Date: <strong>{dashboardDate}</strong>
          </Typography>
        </DialogContent>

        <DialogActions
          sx={{
            p: 2,
          }}
        >
          <Button onClick={handleClosePopup} disabled={isExporting}>
            Cancel
          </Button>

          <Button
            onClick={executeDownload}
            variant="contained"
            color={exportType === "PDF" ? "error" : "success"}
            disabled={isExporting}
            startIcon={
              isExporting ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <CloudDownload />
              )
            }
          >
            {isExporting ? "Generating..." : "Download"}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={snackbarSeverity}
          variant="filled"
          sx={{
            width: "100%",
          }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default SyslogRows;


// import React, { useMemo, useState, useEffect } from "react";

// import {
//   AppBar,
//   Toolbar,
//   Typography,
//   Box,
//   Button,
//   IconButton,
//   Divider,
//   Container,
//   Stack,
//   Paper,
//   Grid,
//   Menu,
//   MenuItem,
//   ListItemIcon,
//   ListItemText,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   CircularProgress,
//   Snackbar,
//   Alert,
//   Chip,
// } from "@mui/material";

// import {
//   PlayArrow,
//   GetApp,
//   AppsRounded,
//   Storage,
//   ErrorOutline,
//   ReportProblemOutlined,
//   CheckCircleOutline,
//   ListAlt,
//   PictureAsPdf,
//   TableChart,
//   CloudDownload,
//   Psychology,
// } from "@mui/icons-material";

// // import { useNavigate, useLocation } from "react-router-dom";

// import { useSelector } from "react-redux";

// import { SyslogAiAxios } from "../../../RestAPI/api/axiosApicall";

// import {
//   SYSLOG_GET_SYNCED_LOGS,
//   SYSLOG_DETAILED_EXPORT_SYNCED,
// } from "../../../RestAPI/url/endpoint";

// const SyslogRows = ({
//   batchData = {
//     id: "0",
//     batch: "Manual Entry",
//     records: 0,
//     crit: 0,
//     mod: 0,
//     low: 0,
//   },
//   selectedModel = "",
//   selectedDate = "",
//   liveRows = [],
//   live = false,
//   onClose,
// }) => {

//   const reduxSelectedDate = useSelector(
//     (state) => state.syslog.selectedDate
//   );
  
//   const dashboardDate = selectedDate || reduxSelectedDate || "";
  
//   const liveRowsFromDashboard = Array.isArray(liveRows)
//     ? liveRows
//     : [];
  
//   const isLive = Boolean(live);
//   // const navigate = useNavigate();

//   // const location = useLocation();

//   // const reduxSelectedDate = useSelector((state) => state.syslog.selectedDate);

//   const [filter, setFilter] = useState("all");

//   const [allLogs, setAllLogs] = useState([]);

//   const [loading, setLoading] = useState(true);


//   // ============================================================
//   // DATA RECEIVED FROM DASHBOARD
//   // ============================================================

//   // const batchData = location.state?.batchData || {
//   //   id: "0",
//   //   batch: "Manual Entry",
//   //   records: 0,
//   //   crit: 0,
//   //   mod: 0,
//   //   low: 0,
//   // };

//   // const selectedModel = location.state?.model || "";

//   // const dashboardDate = location.state?.selectedDate || reduxSelectedDate || "";

//   // const liveRowsFromDashboard = Array.isArray(location.state?.liveRows)
//   //   ? location.state.liveRows
//   //   : [];

//   // const isLive = Boolean(location.state?.live);

//   // ============================================================
//   // EXPORT STATE
//   // ============================================================

//   const [anchorEl, setAnchorEl] = useState(null);

//   const [exportType, setExportType] = useState(null);

//   const [isExporting, setIsExporting] = useState(false);

//   const [snackbarOpen, setSnackbarOpen] = useState(false);

//   const [snackbarMessage, setSnackbarMessage] = useState("");

//   const [snackbarSeverity, setSnackbarSeverity] = useState("success");

//   const openExportMenu = Boolean(anchorEl);

//   const handleExportClick = (event) => {
//     setAnchorEl(event.currentTarget);
//   };

//   const handleMenuClose = () => {
//     setAnchorEl(null);
//   };

//   const handleOpenPopup = (type) => {
//     setExportType(type);
//     handleMenuClose();
//   };

//   const handleClosePopup = () => {
//     if (!isExporting) {
//       setExportType(null);
//     }
//   };

//   // ============================================================
//   // LOAD LIVE BATCH OR COMPLETED BATCH
//   // ============================================================

//   useEffect(() => {
//     const fetchLogs = async () => {
//       if (!dashboardDate || !batchData.batch) {
//         setAllLogs([]);
//         setLoading(false);
//         return;
//       }

//       // ======================================================
//       // LIVE BATCH
//       // ======================================================
//       //
//       // During a continuous run the Dashboard already has the
//       // processed rows from the SSE event, so use them directly.
//       // ======================================================

//       if (isLive && liveRowsFromDashboard.length > 0) {
//         setAllLogs(liveRowsFromDashboard);

//         setLoading(false);

//         return;
//       }

//       // ======================================================
//       // COMPLETED BATCH
//       // ======================================================

//       setLoading(true);

//       try {
//         const cleanedBatch = batchData.batch
//           ? batchData.batch.replace(/\s+/g, "_")
//           : "";

//         const response = await SyslogAiAxios(
//           SYSLOG_GET_SYNCED_LOGS +
//             `?selected_date=${encodeURIComponent(
//               dashboardDate
//             )}&batch_name=${encodeURIComponent(cleanedBatch)}`,
//           "get"
//         );

//         const data = response?.data || {};

//         setAllLogs(Array.isArray(data?.logs) ? data.logs : []);
//       } catch (error) {
//         console.error("Fetch Error:", error);

//         const errorMessage =
//           error?.response?.data?.detail ||
//           error?.response?.data?.message ||
//           error?.message ||
//           "Failed to load synchronized logs.";

//         setSnackbarMessage(`Unable to load logs: ${errorMessage}`);

//         setSnackbarSeverity("error");

//         setSnackbarOpen(true);

//         setAllLogs([]);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchLogs();
//   }, [dashboardDate, batchData.batch, isLive, liveRowsFromDashboard.length]);

//   // ============================================================
//   // EXPORT REPORT
//   // ============================================================

//   const executeDownload = async () => {
//     if (!dashboardDate) {
//       setSnackbarMessage("Please select a date first.");

//       setSnackbarSeverity("warning");

//       setSnackbarOpen(true);

//       return;
//     }

//     if (!batchData.batch) {
//       setSnackbarMessage("No batch selected for download.");

//       setSnackbarSeverity("warning");

//       setSnackbarOpen(true);

//       return;
//     }

//     setIsExporting(true);

//     try {
//       const fileFormat = exportType === "PDF" ? "pdf" : "xlsx";

//       const endpoint = `${SYSLOG_DETAILED_EXPORT_SYNCED}/${encodeURIComponent(
//         batchData.batch
//       )}?type=${encodeURIComponent(fileFormat)}&severity=${encodeURIComponent(
//         filter
//       )}&selected_date=${encodeURIComponent(dashboardDate)}`;

//       const response = await SyslogAiAxios(endpoint, "getBlob");

//       if (response.status != 200) {
//         let errorMessage = `HTTP ${response.status}`;

//         try {
//           const errorData = await response.json();

//           errorMessage =
//             errorData?.detail || errorData?.message || errorMessage;
//         } catch {
//           // Keep status
//           // error.
//         }

//         throw new Error(errorMessage);
//       }

//       const blob = await response.data;

//       if (!(blob instanceof Blob) || blob.size === 0) {
//         throw new Error("Server returned an empty download file.");
//       }

//       const downloadUrl = window.URL.createObjectURL(blob);

//       const link = document.createElement("a");

//       const extension = exportType === "PDF" ? "pdf" : "xlsx";

//       link.href = downloadUrl;

//       link.setAttribute(
//         "download",
//         `${batchData.batch}_${filter}_${dashboardDate}.${extension}`
//       );

//       link.style.display = "none";

//       document.body.appendChild(link);

//       link.click();

//       document.body.removeChild(link);

//       window.setTimeout(() => {
//         window.URL.revokeObjectURL(downloadUrl);
//       }, 1000);

//       const completedType = exportType;

//       setExportType(null);

//       setSnackbarMessage(`${completedType} downloaded successfully!`);

//       setSnackbarSeverity("success");

//       setSnackbarOpen(true);
//     } catch (error) {
//       console.error("Export Error:", error);

//       let errorMessage = "Download failed";

//       if (error?.response?.data instanceof Blob) {
//         try {
//           const errorText = await error.response.data.text();

//           const parsed = JSON.parse(errorText);

//           errorMessage = parsed?.detail || parsed?.message || errorMessage;
//         } catch {
//           // Keep default.
//         }
//       } else {
//         errorMessage =
//           error?.response?.data?.detail ||
//           error?.response?.data?.message ||
//           error?.message ||
//           errorMessage;
//       }

//       setSnackbarMessage(`${exportType || "Export"} failed: ${errorMessage}`);

//       setSnackbarSeverity("error");

//       setSnackbarOpen(true);
//     } finally {
//       setIsExporting(false);
//     }
//   };

//   const handleSnackbarClose = (event, reason) => {
//     if (reason === "clickaway") {
//       return;
//     }

//     setSnackbarOpen(false);
//   };

//   const sharedDividerStyle = {
//     borderBottomWidth: 2,
//     borderColor: "rgba(0, 0, 0, 0.08)",
//     opacity: 1,
//     my: 2,
//     width: "100%",
//   };

//   // ============================================================
//   // NORMALISE DISPLAY DATA
//   // ============================================================

//   const normalisedLogs = useMemo(() => {
//     return (allLogs || []).map((log) => {
//       const riskValue = Number(log.risk ?? log.risk_score ?? 0) || 0;

//       let aiRiskLevel = log.ai_risk_level;

//       if (!aiRiskLevel) {
//         if (riskValue >= 9) {
//           aiRiskLevel = "EMERGENCY";
//         } else if (riskValue >= 8) {
//           aiRiskLevel = "CRITICAL";
//         } else if (riskValue >= 6) {
//           aiRiskLevel = "HIGH";
//         } else if (riskValue >= 4) {
//           aiRiskLevel = "MEDIUM";
//         } else if (riskValue >= 2) {
//           aiRiskLevel = "LOW";
//         } else {
//           aiRiskLevel = "INFO";
//         }
//       }

//       return {
//         ...log,

//         risk: riskValue,

//         ai_risk_level: aiRiskLevel,
//       };
//     });
//   }, [allLogs]);

//   // ============================================================
//   // FILTERING BY RISK
//   // ============================================================

//   const displayLogs = useMemo(() => {
//     const sortedByRisk = [...normalisedLogs].sort(
//       (a, b) => (Number(b.risk) || 0) - (Number(a.risk) || 0)
//     );

//     let filtered;

//     switch (filter) {
//       case "crit":
//         filtered = sortedByRisk.filter((log) => (Number(log.risk) || 0) >= 8);
//         break;

//       case "mod":
//         filtered = sortedByRisk.filter((log) => {
//           const risk = Number(log.risk) || 0;

//           return risk >= 5 && risk <= 7;
//         });
//         break;

//       case "low":
//         filtered = sortedByRisk.filter((log) => {
//           const risk = Number(log.risk) || 0;

//           return risk >= 1 && risk <= 4;
//         });
//         break;

//       default:
//         filtered = sortedByRisk;
//     }

//     if (filter === "all") {
//       return {
//         priority: sortedByRisk.slice(0, 4),

//         stream: sortedByRisk.slice(4),
//       };
//     }

//     return {
//       priority: [],
//       stream: filtered,
//     };
//   }, [normalisedLogs, filter]);

//   const leftCol = displayLogs.stream.filter((_, i) => i % 2 === 0);

//   const rightCol = displayLogs.stream.filter((_, i) => i % 2 !== 0);

//   // ============================================================
//   // LOG BOX
//   // ============================================================

//   const LogBox = ({ log }) => {
//     const getSeverityLabel = (val) => {
//       const labels = {
//         0: "EMERGENCY",
//         1: "ALERT",
//         2: "CRITICAL",
//         3: "ERROR",
//         4: "WARNING",
//         5: "NOTICE",
//         6: "INFO",
//         7: "DEBUG",
//       };

//       return log.severity_label || labels[val] || "LOG";
//     };

//     const risk = Number(log.risk ?? log.risk_score ?? 0) || 0;

//     return (
//       <Paper
//         elevation={1}
//         sx={{
//           mb: 4,
//           borderRadius: "8px",
//           overflow: "hidden",
//           width: "100%",
//           border: "1px solid #e0e0e0",
//           transition: "all 0.2s ease-in-out",

//           "&:hover": {
//             transform: "translateY(-4px)",
//             boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
//             borderColor: log.color,
//           },
//         }}
//       >
//         <Box
//           sx={{
//             bgcolor: log.color || "#e0e0e0",

//             p: 1,
//             px: 2,

//             display: "flex",

//             justifyContent: "space-between",

//             alignItems: "center",

//             color: "black",
//           }}
//         >
//           <Stack direction="row" spacing={2} alignItems="center">
//             <Typography
//               variant="caption"
//               sx={{
//                 fontWeight: 800,
//               }}
//             >
//               {log.timestamp}
//             </Typography>

//             <Divider
//               orientation="vertical"
//               flexItem
//               sx={{
//                 bgcolor: "rgba(0,0,0,0.1)",
//                 width: "1.5px",
//               }}
//             />

//             <Typography
//               variant="subtitle2"
//               sx={{
//                 fontWeight: "bold",
//               }}
//             >
//               {log.hostname || "UNKNOWN"}
//             </Typography>
//           </Stack>

//           <Stack direction="row" spacing={1} alignItems="center">
//             <Chip
//               label={`RISK: ${risk}/10`}
//               size="small"
//               sx={{
//                 bgcolor: "rgba(255,255,255,0.4)",
//                 fontWeight: "bold",
//                 height: 22,
//                 fontSize: "0.7rem",
//               }}
//             />

//             <Chip
//               label={log.ai_risk_level || "ANALYSED"}
//               size="small"
//               variant="outlined"
//               sx={{
//                 fontWeight: "bold",
//                 height: 22,
//                 fontSize: "0.65rem",
//               }}
//             />
//           </Stack>
//         </Box>

//         <Box
//           sx={{
//             p: 2,
//             bgcolor: "white",
//           }}
//         >
//           <Grid
//             container
//             spacing={1}
//             sx={{
//               mb: 1.5,
//             }}
//             justifyContent="space-between"
//           >
//             <Grid item xs={2.5}>
//               <Typography
//                 variant="caption"
//                 color="text.secondary"
//                 sx={{
//                   fontWeight: "bold",
//                   display: "block",
//                 }}
//               >
//                 ID
//               </Typography>

//               <Typography
//                 variant="body2"
//                 sx={{
//                   fontWeight: "bold",
//                 }}
//               >
//                 #{log.id}
//               </Typography>
//             </Grid>

//             <Grid item xs={4.5}>
//               <Typography
//                 variant="caption"
//                 color="text.secondary"
//                 sx={{
//                   fontWeight: "bold",
//                   display: "block",
//                 }}
//               >
//                 FACILITY
//               </Typography>

//               <Typography
//                 variant="body2"
//                 sx={{
//                   fontWeight: "bold",
//                   textTransform: "uppercase",
//                 }}
//               >
//                 {log.facility_label || "N/A"}
//               </Typography>
//             </Grid>

//             <Grid item xs={5}>
//               <Typography
//                 variant="caption"
//                 color="text.secondary"
//                 sx={{
//                   fontWeight: "bold",
//                   display: "block",
//                 }}
//               >
//                 SYS SEVERITY
//               </Typography>

//               <Typography
//                 variant="body2"
//                 sx={{
//                   fontWeight: "bold",
//                   color: "#d32f2f",
//                 }}
//               >
//                 {getSeverityLabel(log.severity_val)} (
//                 {log.severity_val ?? "N/A"})
//               </Typography>
//             </Grid>
//           </Grid>

//           <Divider
//             sx={{
//               my: 1,
//               opacity: 0.5,
//             }}
//           />

//           <Typography
//             variant="caption"
//             sx={{
//               color: "primary.main",
//               fontWeight: 800,
//               textTransform: "uppercase",
//               fontSize: "0.65rem",
//             }}
//           >
//             Original Message
//           </Typography>

//           <Typography
//             variant="body2"
//             sx={{
//               mb: 2,
//               color: "text.primary",
//               fontFamily: "monospace",
//               bgcolor: "#f5f5f5",
//               p: 1,
//               borderRadius: "4px",
//               mt: 0.5,
//               wordBreak: "break-all",
//             }}
//           >
//             {log.message || "N/A"}
//           </Typography>

//           <Typography
//             variant="caption"
//             sx={{
//               color: "secondary.main",
//               fontWeight: 800,
//               textTransform: "uppercase",
//               fontSize: "0.65rem",
//             }}
//           >
//             AI Insight
//           </Typography>

//           <Box
//             sx={{
//               display: "flex",
//               gap: 1,
//               mt: 0.5,
//               alignItems: "flex-start",
//             }}
//           >
//             <Psychology
//               sx={{
//                 fontSize: 18,
//                 color: "secondary.main",
//                 mt: 0.3,
//               }}
//             />

//             <Typography
//               variant="body2"
//               sx={{
//                 fontStyle: "italic",
//                 color: "text.primary",
//                 lineHeight: 1.4,
//                 whiteSpace: "pre-line",
//               }}
//             >
//               {log.ai_insight || "No AI insight available."}
//             </Typography>
//           </Box>
//         </Box>
//       </Paper>
//     );
//   };

//   // ============================================================
//   // UI
//   // ============================================================

//   return (
//     <Box
//       sx={{
//         display: "flex",
//         flexDirection: "column",
//         height: "100vh",
//         maxHeight: "100vh",
//         bgcolor: "#f8f9fa",
//         overflow: "hidden",
//       }}
//     >
//       <AppBar
//         position="static"
//         color="inherit"
//         elevation={1}
//         sx={{
//           bgcolor: "white",
//           flexShrink: 0,
//         }}
//       >
//         <Toolbar
//           sx={{
//             justifyContent: "space-between",
//           }}
//         >
//           <Stack direction="row" spacing={2} alignItems="center">
//             <Stack direction="row" spacing={1} alignItems="center">
//               <AppsRounded color="primary" />

//               <Typography
//                 variant="h6"
//                 sx={{
//                   fontWeight: 800,
//                   letterSpacing: -0.5,
//                 }}
//               >
//                 SYSLOG ANOMALY DETECTOR
//               </Typography>
//             </Stack>

//             <Divider
//               orientation="vertical"
//               flexItem
//               sx={{
//                 height: 24,
//                 mx: 1,
//               }}
//             />

//             <Stack direction="row" spacing={1} alignItems="center">
//               <Typography
//                 variant="body2"
//                 sx={{
//                   color: "text.secondary",
//                   fontWeight: "bold",
//                 }}
//               >
//                 MODEL:
//               </Typography>

//               <Chip
//                 icon={
//                   <Psychology
//                     sx={{
//                       fontSize: "25px !important",
//                       color: "primary.main",
//                     }}
//                   />
//                 }
//                 label={
//                   selectedModel ? selectedModel.replace(/_/g, " ") : "No Model"
//                 }
//                 size="small"
//                 sx={{
//                   fontWeight: 800,
//                   borderRadius: "4px",
//                   color: "black",
//                   px: 1,
//                 }}
//               />
//             </Stack>

//             {isLive && (
//               <Chip
//                 label="LIVE"
//                 color="success"
//                 size="small"
//                 sx={{
//                   fontWeight: 800,
//                 }}
//               />
//             )}
//           </Stack>
//         </Toolbar>
//       </AppBar>

//       <Box
//         sx={{
//           flexGrow: 1,
//           overflowY: "auto",
//           p: 0,
//         }}
//       >
//         <Container
//           maxWidth="xxl"
//           sx={{
//             mt: 4,
//             mb: 4,
//           }}
//           disableGutters
//         >
//           <Box
//             sx={{
//               display: "flex",
//               justifyContent: "space-between",
//               alignItems: "center",
//               mb: 3,
//               px: 3,
//             }}
//           >
//             <Stack direction="row" spacing={2} alignItems="center">
//               <IconButton
//                 onClick={onClose}
//                 sx={{
//                   border: "1px solid #ddd",
//                   bgcolor: "white",
//                 }}
//               >
//                 <PlayArrow
//                   sx={{
//                     transform: "rotate(180deg)",
//                   }}
//                 />
//               </IconButton>

//               <Box>
//                 <Typography
//                   variant="h4"
//                   sx={{
//                     fontWeight: 900,
//                     color: "#1a237e",
//                   }}
//                 >
//                   {batchData.batch}

//                   {isLive && (
//                     <Chip
//                       label="LIVE"
//                       color="success"
//                       size="small"
//                       sx={{
//                         ml: 1,
//                         verticalAlign: "middle",
//                         fontWeight: 800,
//                       }}
//                     />
//                   )}
//                 </Typography>

//                 <Typography
//                   variant="body2"
//                   sx={{
//                     fontWeight: "bold",
//                     color: "text.secondary",
//                   }}
//                 >
//                   <Storage
//                     sx={{
//                       fontSize: 16,
//                       verticalAlign: "middle",
//                       mr: 0.5,
//                     }}
//                   />
//                   {Number(batchData.records || 0).toLocaleString()} TOTAL
//                   RECORDS | DATE: {dashboardDate}
//                 </Typography>

//                 {isLive && (
//                   <Typography
//                     variant="caption"
//                     color="success.main"
//                     sx={{
//                       fontWeight: 700,
//                     }}
//                   >
//                     Live batch received from continuous PostgreSQL processing
//                   </Typography>
//                 )}
//               </Box>
//             </Stack>

//             <Stack direction="row" spacing={1} alignItems="center">
//               <Button
//                 variant={filter === "all" ? "contained" : "outlined"}
//                 startIcon={<ListAlt />}
//                 onClick={() => setFilter("all")}
//                 sx={{
//                   fontWeight: "bold",
//                   borderRadius: "20px",
//                 }}
//               >
//                 ALL
//               </Button>

//               <Button
//                 variant={filter === "crit" ? "contained" : "outlined"}
//                 color="error"
//                 startIcon={<ErrorOutline />}
//                 onClick={() => setFilter("crit")}
//                 sx={{
//                   fontWeight: "bold",
//                   borderRadius: "20px",
//                 }}
//               >
//                 CRITICAL ({batchData.crit || 0})
//               </Button>

//               <Button
//                 variant={filter === "mod" ? "contained" : "outlined"}
//                 startIcon={<ReportProblemOutlined />}
//                 onClick={() => setFilter("mod")}
//                 sx={{
//                   fontWeight: "bold",
//                   borderRadius: "20px",
//                   color: filter === "mod" ? "white" : "#fbc02d",
//                   borderColor: "#fbc02d",
//                   bgcolor: filter === "mod" ? "#fbc02d" : "transparent",
//                   "&:hover": {
//                     bgcolor: filter === "mod" ? "#f9a825" : "transparent",
//                   },
//                 }}
//               >
//                 MODERATE ({batchData.mod || 0})
//               </Button>

//               <Button
//                 variant={filter === "low" ? "contained" : "outlined"}
//                 color="success"
//                 startIcon={<CheckCircleOutline />}
//                 onClick={() => setFilter("low")}
//                 sx={{
//                   fontWeight: "bold",
//                   borderRadius: "20px",
//                 }}
//               >
//                 LOW ({batchData.low || 0})
//               </Button>

//               <Divider
//                 orientation="vertical"
//                 flexItem
//                 sx={{
//                   mx: 1,
//                 }}
//               />

//               <Button
//                 variant="contained"
//                 startIcon={<GetApp />}
//                 onClick={handleExportClick}
//                 sx={{
//                   fontWeight: "bold",
//                 }}
//               >
//                 EXPORT
//               </Button>

//               <Menu
//                 anchorEl={anchorEl}
//                 open={openExportMenu}
//                 onClose={handleMenuClose}
//                 PaperProps={{
//                   sx: {
//                     width: 180,
//                     mt: 1,
//                   },
//                 }}
//               >
//                 <MenuItem onClick={() => handleOpenPopup("PDF")}>
//                   <ListItemIcon>
//                     <PictureAsPdf fontSize="small" color="error" />
//                   </ListItemIcon>

//                   <ListItemText>Export to PDF</ListItemText>
//                 </MenuItem>

//                 <MenuItem onClick={() => handleOpenPopup("Excel")}>
//                   <ListItemIcon>
//                     <TableChart fontSize="small" color="success" />
//                   </ListItemIcon>

//                   <ListItemText>Export to Excel</ListItemText>
//                 </MenuItem>
//               </Menu>
//             </Stack>
//           </Box>

//           <Box
//             sx={{
//               px: 3,
//             }}
//           >
//             {loading ? (
//               <Box
//                 sx={{
//                   display: "flex",
//                   justifyContent: "center",
//                   mt: 10,
//                 }}
//               >
//                 <CircularProgress />
//               </Box>
//             ) : (
//               <Box>
//                 {filter === "all" && displayLogs.priority.length > 0 && (
//                   <Box
//                     sx={{
//                       mt: 2,
//                     }}
//                   >
//                     <Typography
//                       variant="overline"
//                       sx={{
//                         fontWeight: 800,
//                         color: "primary.main",
//                         mb: 1,
//                         display: "block",
//                       }}
//                     >
//                       PRIORITY ALERTS (TOP 4 HIGHEST RISK)
//                     </Typography>

//                     <Grid
//                       container
//                       spacing={3}
//                       sx={{
//                         width: "100%",
//                         m: "0",
//                         display: "grid",
//                         gridTemplateColumns: "repeat(2,1fr)",
//                         gap: "50px",
//                       }}
//                     >
//                       <Grid item xs={12} md={6}>
//                         {displayLogs.priority.slice(0, 2).map((log) => (
//                           <LogBox key={log.id} log={log} />
//                         ))}
//                       </Grid>

//                       <Grid item xs={12} md={6}>
//                         {displayLogs.priority.slice(2, 4).map((log) => (
//                           <LogBox key={log.id} log={log} />
//                         ))}
//                       </Grid>
//                     </Grid>

//                     <Divider sx={sharedDividerStyle} />
//                   </Box>
//                 )}

//                 <Box
//                   sx={{
//                     mt: filter === "all" ? 0 : 2,
//                   }}
//                 >
//                   <Typography
//                     variant="overline"
//                     sx={{
//                       fontWeight: 800,
//                       color: "text.secondary",
//                       mb: 1,
//                       display: "block",
//                     }}
//                   >
//                     {filter === "all"
//                       ? "GENERAL LOG STREAM"
//                       : `${filter.toUpperCase()} LOG STREAM`}{" "}
//                     ({displayLogs.stream.length} ITEMS)
//                   </Typography>

//                   <Box
//                     sx={{
//                       width: "100%",
//                     }}
//                   >
//                     <Grid
//                       container
//                       spacing={3}
//                       sx={{
//                         width: "100%",
//                         m: "0",
//                         display: "grid",
//                         gridTemplateColumns: "repeat(2,1fr)",
//                         gap: "50px",
//                       }}
//                     >
//                       <Grid item xs={12} md={6}>
//                         {leftCol.map((log) => (
//                           <LogBox key={log.id} log={log} />
//                         ))}
//                       </Grid>

//                       <Grid item xs={12} md={6}>
//                         {rightCol.map((log) => (
//                           <LogBox key={log.id} log={log} />
//                         ))}
//                       </Grid>
//                     </Grid>
//                   </Box>
//                 </Box>
//               </Box>
//             )}
//           </Box>
//         </Container>
//       </Box>

//       <Dialog
//         open={Boolean(exportType)}
//         onClose={handleClosePopup}
//         maxWidth="xs"
//         fullWidth
//       >
//         <DialogTitle
//           sx={{
//             display: "flex",
//             alignItems: "center",
//             gap: 1,
//             fontWeight: "bold",
//           }}
//         >
//           {exportType === "PDF" ? (
//             <PictureAsPdf color="error" />
//           ) : (
//             <TableChart color="success" />
//           )}
//           Export {exportType}
//         </DialogTitle>

//         <DialogContent dividers>
//           <Typography variant="body1">
//             Preparing <strong>{filter.toUpperCase()}</strong> report.
//           </Typography>

//           <Typography
//             variant="body2"
//             color="text.secondary"
//             sx={{
//               mt: 1,
//             }}
//           >
//             Engine:{" "}
//             <strong>
//               {selectedModel ? selectedModel.replace(/_/g, " ") : "N/A"}
//             </strong>
//           </Typography>

//           <Typography variant="body2" color="text.secondary">
//             Source: <strong>PostgreSQL</strong>
//           </Typography>

//           <Typography variant="body2" color="text.secondary">
//             Batch: <strong>{batchData.batch}</strong>
//           </Typography>

//           <Typography variant="body2" color="text.secondary">
//             Date: <strong>{dashboardDate}</strong>
//           </Typography>
//         </DialogContent>

//         <DialogActions
//           sx={{
//             p: 2,
//           }}
//         >
//           <Button onClick={handleClosePopup} disabled={isExporting}>
//             Cancel
//           </Button>

//           <Button
//             onClick={executeDownload}
//             variant="contained"
//             color={exportType === "PDF" ? "error" : "success"}
//             disabled={isExporting}
//             startIcon={
//               isExporting ? (
//                 <CircularProgress size={20} color="inherit" />
//               ) : (
//                 <CloudDownload />
//               )
//             }
//           >
//             {isExporting ? "Generating..." : "Download"}
//           </Button>
//         </DialogActions>
//       </Dialog>

//       <Snackbar
//         open={snackbarOpen}
//         autoHideDuration={4000}
//         onClose={handleSnackbarClose}
//         anchorOrigin={{
//           vertical: "bottom",
//           horizontal: "center",
//         }}
//       >
//         <Alert
//           onClose={handleSnackbarClose}
//           severity={snackbarSeverity}
//           variant="filled"
//           sx={{
//             width: "100%",
//           }}
//         >
//           {snackbarMessage}
//         </Alert>
//       </Snackbar>
//     </Box>
//   );
// };

// export default SyslogRows;
