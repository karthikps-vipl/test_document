import React, { useState, useEffect, useCallback } from "react";
import {
  AppBar, Toolbar, Typography, Box, Button, Select, MenuItem,
  IconButton, Divider, Container, Stack, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Paper, Tooltip, Menu, Snackbar,
  Alert, Chip, CircularProgress, LinearProgress,
} from "@mui/material";

import {
  PlayArrow, Refresh, Visibility, ArrowUpward, Star, StarBorderOutlined,
  PictureAsPdf, AppsRounded, Block, Undo, Stop, Inbox, Report,
  FileDownload, TableChart,
} from "@mui/icons-material";

import dayjs from "dayjs";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";

import {
  toggleStar as toggleStarAction,
  toggleSpam as toggleSpamAction,
  setSelectedDate,
  setSelectedModel,
  clearAuditRows,
} from "../../../store/features/SyslogAI/syslogSlice";

import { SyslogAiAxios } from "@/RestAPI/api/axiosApicall";
import {
  SYSLOG_LOAD_MODEL,
  SYSLOG_RUN_AUDIT,
  SYSLOG_STOP_AUDIT,
  SYSLOG_AUDIT_STATUS,
  SYSLOG_GET_MODELS,
  SYSLOG_BATCH_DOWNLOAD,
  SYSLOG_MASTER_DOWNLOAD,
} from "@/RestAPI/url/endpoint";

const SyslogDashboard = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // ============================================================
  // REDUX STATE — all live audit data comes from here now
  // ============================================================
  const starredRows = useSelector((state) => state.syslog.starredRows) || [];
  const spamRows = useSelector((state) => state.syslog.spamRows) || [];
  const allRows = useSelector((state) => state.syslog.allRows) || [];
  const selectedDate = useSelector((state) => state.syslog.selectedDate);
  const selectedModel = useSelector((state) => state.syslog.selectedModel);
  const masterFiles = useSelector((state) => state.syslog.masterFiles) || {
    pdf: null, excel: null,
  };
  const isRunning = useSelector((state) => state.syslog.isRunning);
  const isStompConnected = useSelector((state) => state.syslog.isStompConnected);
  const lastEvent = useSelector((state) => state.syslog.lastEvent);
  const lastError = useSelector((state) => state.syslog.lastError);

  // ============================================================
  // LOCAL UI STATE (unchanged)
  // ============================================================
  const [buttonDisabled, setButtonDisabled] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [models, setModels] = useState([]);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [downloadAnchor, setDownloadAnchor] = useState(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const [sortConfig, setSortConfig] = useState({ key: "dt", direction: "desc" });
  const [contextMenu, setContextMenu] = useState(null);
  const [selectedRowId, setSelectedRowId] = useState(null);

  const [snackbar, setSnackbar] = useState({
    open: false, message: "", severity: "success",
  });

  // ============================================================
  // DATE HISTORY
  // ============================================================
  const last30Days = [...Array(30)].map((_, i) =>
    dayjs().subtract(i, "day").format("YYYY-MM-DD")
  );

  const [historyLog, setHistoryLog] = useState(() => {
    try {
      const saved = localStorage.getItem("syslog_model_history");
      return saved ? JSON.parse(saved) : {};
    } catch (err) {
      console.error("Failed to read model history:", err);
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("syslog_model_history", JSON.stringify(historyLog));
    } catch (err) {
      console.error("Failed to save model history:", err);
    }
  }, [historyLog]);

  const getModelForDate = (date) => historyLog[date] || "No Model Run";

  // ============================================================
  // React to terminal socket events (snackbar + history)
  // ============================================================
  useEffect(() => {
    if (!lastEvent || !lastEvent._at) return;
    if (lastEvent.type === "stopped") {
      setSnackbar({
        open: true,
        message:
          lastEvent.message ||
          (lastEvent.reason === "no_data"
            ? "No syslog data found for that date."
            : "Audit stopped. Final reports are available."),
        severity: lastEvent.reason === "no_data" ? "warning" : "success",
      });
      if (selectedDate) {
        setHistoryLog((prev) => ({
          ...prev,
          [selectedDate]: selectedModel || "production_model",
        }));
      }
    } else if (lastEvent.type === "error") {
      setSnackbar({
        open: true,
        message: lastEvent.message || "Continuous audit failed.",
        severity: "error",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastEvent?._at]);

  useEffect(() => {
    if (!lastError) return;
    setSnackbar({ open: true, message: lastError, severity: "error" });
  }, [lastError]);

  // ============================================================
  // API: GET MODELS
  // ============================================================
  const fetchModels = useCallback(async () => {
    try {
      const response = await SyslogAiAxios(SYSLOG_GET_MODELS, "get");
      const data = response.data;
      if (Array.isArray(data.models) && data.models.length > 0) {
        setModels(data.models);
        if (!selectedModel) {
          const productionModel =
            data.production_model ||
            data.models.find((m) => m.includes("production")) ||
            data.models[0];
          dispatch(setSelectedModel(productionModel));
        }
      } else {
        setModels([]);
      }
    } catch (err) {
      console.error("Failed to fetch models:", err);
      setSnackbar({
        open: true,
        message: "Could not connect to AI Engine. Check if Backend is running.",
        severity: "error",
      });
    }
  }, [dispatch, selectedModel]);

  // ============================================================
  // API: LOAD MODEL
  // ============================================================
  const handleModelChange = async (event) => {
    const newModel = event.target.value;
    dispatch(setSelectedModel(newModel));
    setIsModelLoading(true);
    try {
      await SyslogAiAxios(SYSLOG_LOAD_MODEL, "post", { model_name: newModel });
      setSnackbar({
        open: true,
        message: `Model ${newModel.replace(/_/g, " ")} loaded successfully!`,
        severity: "success",
      });
    } catch (error) {
      const errorMessage =
        error?.response?.data?.detail ||
        error?.response?.data?.message ||
        error?.message ||
        "Failed to load model";
      setSnackbar({ open: true, message: `Error: ${errorMessage}`, severity: "error" });
    } finally {
      setIsModelLoading(false);
    }
  };

  // ============================================================
  // SYNC AUDIT STATUS (for reconnect-after-refresh)
  // ============================================================
  const syncAuditStatus = useCallback(async (showMessage = false) => {
    try {
      const response = await SyslogAiAxios(SYSLOG_AUDIT_STATUS, "get");
      const data = response?.data || {};
      if (data.running) {
        if (data.selected_date) dispatch(setSelectedDate(data.selected_date));
        // Attach to the already-running socket
        dispatch({ type: "syslogSocket/connect" });
        if (showMessage) {
          setSnackbar({
            open: true,
            message: "An audit is already running. Reconnected.",
            severity: "info",
          });
        }
        return true;
      }
      if (showMessage) {
        setSnackbar({ open: true, message: "No audit is currently running.", severity: "info" });
      }
      return false;
    } catch (err) {
      console.error("Audit status sync error:", err);
      return null;
    }
  }, [dispatch]);

  // ============================================================
  // INITIAL LOAD
  // ============================================================
  useEffect(() => {
    const init = async () => {
      await fetchModels();
      await syncAuditStatus(false);
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ============================================================
  // STOP / RUN
  // ============================================================
  const handleStopClick = async () => {
    setButtonDisabled(true);
    try {
      const response = await SyslogAiAxios(SYSLOG_STOP_AUDIT, "post");
      const data = response?.data || {};
      if (response?.status && response.status >= 400) {
        throw new Error(data?.detail || "Unable to stop audit.");
      }
      setSnackbar({
        open: true,
        message: "Stop requested. Closing stream…",
        severity: "info",
      });
      // Middleware will close the socket when it receives `stopped`.
    } catch (error) {
      console.error("Stop audit error:", error);
      setSnackbar({
        open: true,
        message: error?.message || "Unable to stop audit.",
        severity: "error",
      });
      setButtonDisabled(false);
    }
  };

  const handleRunClick = async () => {
    if (isRunning) {
      await handleStopClick();
      return;
    }
    if (isStarting) return;
    if (!selectedDate) {
      setSnackbar({ open: true, message: "Please select a date first.", severity: "warning" });
      return;
    }
    if (!selectedModel) {
      setSnackbar({ open: true, message: "Please select a model first.", severity: "warning" });
      return;
    }

    setIsStarting(true);
    setButtonDisabled(true);

    // Clear the previous run's rows
    dispatch(clearAuditRows());

    try {
      const alreadyRunning = await syncAuditStatus(false);
      if (alreadyRunning === true) {
        setIsStarting(false);
        setButtonDisabled(false);
        return;
      }

      const response = await SyslogAiAxios(SYSLOG_RUN_AUDIT, "post", {
        date_str: selectedDate,
        model_name: selectedModel,
      });
      const data = response?.data || {};
      if (!["started", "success"].includes(data?.status)) {
        throw new Error(data?.detail || data?.message || "Audit could not be started.");
      }

      setHistoryLog((prev) => ({ ...prev, [selectedDate]: selectedModel }));

      // Open the socket — the middleware subscribes to the audit topic.
      dispatch({ type: "syslogSocket/connect" });

      setSnackbar({
        open: true,
        message: "Continuous PostgreSQL audit started.",
        severity: "success",
      });
    } catch (error) {
      console.error("Audit API error:", error);
      const status = error?.response?.status;

      // -------- 409 recovery ---------
      if (status === 409) {
        try {
          setSnackbar({
            open: true,
            message: "Previous audit still running — stopping it and restarting…",
            severity: "info",
          });
          try { await SyslogAiAxios(SYSLOG_STOP_AUDIT, "post"); } catch (_) { /* noop */ }

          let stopped = false;
          for (let i = 0; i < 30; i++) {
            await new Promise((r) => setTimeout(r, 500));
            try {
              const s = await SyslogAiAxios(SYSLOG_AUDIT_STATUS, "get");
              if (!s?.data?.running) { stopped = true; break; }
            } catch (_) { /* transient */ }
          }

          const retry = await SyslogAiAxios(SYSLOG_RUN_AUDIT, "post", {
            date_str: selectedDate,
            model_name: selectedModel,
            force: true,
          });
          const retryData = retry?.data || {};
          if (!["started", "success"].includes(retryData?.status)) {
            throw new Error(retryData?.detail || "Audit could not be restarted.");
          }

          setHistoryLog((prev) => ({ ...prev, [selectedDate]: selectedModel }));
          dispatch({ type: "syslogSocket/connect" });
          setSnackbar({
            open: true,
            message: stopped ? "Audit restarted successfully." : "Audit restarted (forced).",
            severity: "success",
          });
          return;
        } catch (recoverErr) {
          setSnackbar({
            open: true,
            message: recoverErr?.message || "Could not restart audit.",
            severity: "error",
          });
          dispatch({ type: "syslogSocket/disconnect" });
          return;
        }
      }

      const errorMessage =
        error?.response?.data?.detail ||
        error?.response?.data?.message ||
        error?.message ||
        "Audit failed on server";
      setSnackbar({ open: true, message: errorMessage, severity: "error" });
    } finally {
      setIsStarting(false);
      setButtonDisabled(false);
    }
  };

  // ============================================================
  // STAR / SPAM
  // ============================================================
  const handleToggleStar = (id) => {
    const isCurrentlyStarred = starredRows.includes(id);
    dispatch(toggleStarAction(id));
    setSnackbar({
      open: true,
      message: isCurrentlyStarred ? "Removed from Important" : "Added to Important",
      severity: isCurrentlyStarred ? "info" : "success",
    });
  };

  const handleSpamAction = () => {
    if (!selectedRowId) return;
    const isCurrentlySpam = spamRows.includes(selectedRowId);
    dispatch(toggleSpamAction(selectedRowId));
    setSnackbar({
      open: true,
      message: isCurrentlySpam ? "Restored to Inbox" : "Moved to Spam",
      severity: isCurrentlySpam ? "success" : "warning",
    });
    setContextMenu(null);
  };

  // ============================================================
  // REFRESH
  // ============================================================
  const handleRefreshClick = async () => {
    setButtonDisabled(true);
    try {
      await fetchModels();
      setSnackbar({ open: true, message: "Table refreshed successfully.", severity: "success" });
    } finally {
      setButtonDisabled(false);
    }
  };

  // ============================================================
  // DOWNLOADS (unchanged)
  // ============================================================
  const handleDownloadOpen = (event) => setDownloadAnchor(event.currentTarget);
  const handleDownloadClose = () => setDownloadAnchor(null);

  const extractErrorMessage = async (response, fallback) => {
    try {
      const errorData = await response.json();
      return errorData?.detail || errorData?.message || fallback;
    } catch (_) {
      try { return (await response.text()) || fallback; }
      catch (_) { return fallback; }
    }
  };

  const executeDownload = async (type) => {
    handleDownloadClose();
    if (!selectedDate) {
      setSnackbar({ open: true, message: "Please select a date first.", severity: "warning" });
      return;
    }
    const fileType = type === "PDF" ? "pdf" : "xlsx";
    const endpoint = `${SYSLOG_MASTER_DOWNLOAD}/${fileType}?selected_date=${encodeURIComponent(selectedDate)}`;
    setIsDownloading(true);
    try {
      const response = await SyslogAiAxios(endpoint, "getBlob");
      if (response.status !== 200) {
        const msg = await extractErrorMessage(response, `Download failed (${response.status})`);
        throw new Error(msg);
      }
      const blob = response.data;
      const downloadUrl = window.URL.createObjectURL(blob);
      const extension = type === "PDF" ? "pdf" : "xlsx";
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", `MASTER_${selectedDate}.${extension}`);
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.setTimeout(() => window.URL.revokeObjectURL(downloadUrl), 1000);
      setSnackbar({ open: true, message: `Master ${type} downloaded successfully!`, severity: "success" });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `Download failed: ${error?.message || "Download failed"}`,
        severity: "error",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  const downloadBatchReport = async (row, type) => {
    if (!selectedDate) {
      setSnackbar({ open: true, message: "Please select a date first.", severity: "warning" });
      return;
    }
    const batchName = row?.batch || row?.batch_name;
    if (!batchName) {
      setSnackbar({ open: true, message: `No ${type} report available for this batch.`, severity: "warning" });
      return;
    }
    const fileType = type === "PDF" ? "pdf" : "xlsx";
    const extension = type === "PDF" ? "pdf" : "xlsx";
    const endpoint = `${SYSLOG_BATCH_DOWNLOAD}${encodeURIComponent(batchName)}/${fileType}?selected_date=${encodeURIComponent(selectedDate)}`;
    setIsDownloading(true);
    try {
      const response = await SyslogAiAxios(endpoint, "getBlob");
      if (response.status !== 200) {
        const msg = await extractErrorMessage(response, `Download failed (${response.status})`);
        throw new Error(msg);
      }
      const blob = response.data;
      if (!(blob instanceof Blob) || blob.size === 0) {
        throw new Error("Server returned an empty download file.");
      }
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.setAttribute("download", `${batchName}_${selectedDate}.${extension}`);
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.setTimeout(() => window.URL.revokeObjectURL(downloadUrl), 1000);
      setSnackbar({ open: true, message: `${type} download initiated successfully!`, severity: "success" });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `${type} download failed: ${error.message || "Download failed"}`,
        severity: "error",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  // ============================================================
  // CONTEXT MENU / SORT (unchanged)
  // ============================================================
  const handleContextMenu = (event, id) => {
    event.preventDefault();
    setSelectedRowId(id);
    setContextMenu({ mouseX: event.clientX + 2, mouseY: event.clientY - 6 });
  };

  const handleSort = (key) => {
    let direction = "desc";
    if (sortConfig.key === key && sortConfig.direction === "desc") direction = "asc";
    setSortConfig({ key, direction });
  };

  // ============================================================
  // PROCESSED ROWS (unchanged)
  // ============================================================
  const processedRows = [...(allRows || [])]
    .filter((row) => {
      const isSpam = spamRows.includes(row.id);
      if (activeTab === "spam") return isSpam;
      if (activeTab === "important") return starredRows.includes(row.id) && !isSpam;
      return !isSpam;
    })
    .sort((a, b) => {
      if (!sortConfig.key) return 0;
      const valA = a[sortConfig.key];
      const valB = b[sortConfig.key];
      if (typeof valA === "string" || typeof valB === "string") {
        const sA = String(valA || "");
        const sB = String(valB || "");
        return sortConfig.direction === "asc" ? sA.localeCompare(sB) : sB.localeCompare(sA);
      }
      const nA = Number(valA) || 0;
      const nB = Number(valB) || 0;
      return sortConfig.direction === "asc" ? nA - nB : nB - nA;
    });

  const getTabCount = (tab) => {
    const rows = allRows || [];
    const spam = spamRows || [];
    const starred = starredRows || [];
    if (tab === "all") return rows.filter((r) => !spam.includes(r.id)).length;
    if (tab === "important") {
      return starred.filter((id) => rows.some((r) => r.id === id) && !spam.includes(id)).length;
    }
    if (tab === "spam") return spam.filter((id) => rows.some((r) => r.id === id)).length;
    return 0;
  };

  const getTabIcon = (tab, isActive) => {
    const iconStyle = { color: isActive ? "white" : "primary.main" };
    switch (tab) {
      case "all": return <Inbox fontSize="small" sx={iconStyle} />;
      case "important": return <Star fontSize="small" sx={iconStyle} />;
      case "spam": return <Report fontSize="small" sx={iconStyle} />;
      default: return null;
    }
  };

  // ============================================================
  // UI
  // ============================================================
  return (
    <Box sx={{ flexGrow: 1, bgcolor: "#f4f6f8", minHeight: "100vh" }}>
      <style>{`
        @keyframes rowEntrance {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .row-item { animation: rowEntrance 0.35s ease-out forwards; }
      `}</style>

      <AppBar position="static" color="inherit" elevation={1}>
        <Toolbar sx={{ justifyContent: "space-between" }}>
          <Stack direction="row" spacing={1} alignItems="center">
            <AppsRounded color="primary" />
            <Typography variant="h6" sx={{ fontWeight: "bold" }}>
              SYSLOG ANOMALY DETECTOR
            </Typography>
            {isRunning && (
              <Chip
                label={isStompConnected ? "LIVE" : "CONNECTING…"}
                color={isStompConnected ? "success" : "warning"}
                size="small"
              />
            )}
          </Stack>

          <Stack direction="row" spacing={2} alignItems="center">
            <Typography variant="body2" sx={{ color: "text.secondary" }}>DATE</Typography>

            <Stack direction="row" alignItems="center" spacing={1}>
              <Select
                size="small"
                value={selectedDate || ""}
                onChange={(e) => dispatch(setSelectedDate(e.target.value))}
                disabled={isRunning}
                sx={{ minWidth: 280 }}
                renderValue={(value) => `${value} (${getModelForDate(value)})`}
              >
                {last30Days.map((date) => (
                  <MenuItem key={date} value={date}>
                    <Typography variant="body2">
                      {date} <strong>({getModelForDate(date)})</strong>
                    </Typography>
                  </MenuItem>
                ))}
              </Select>

              <Tooltip title={!masterFiles?.pdf ? "No data to download" : `Download report for ${selectedDate}`}>
                <span>
                  <IconButton
                    size="small"
                    color="primary"
                    disabled={isDownloading || !masterFiles?.pdf || isRunning}
                    onClick={handleDownloadOpen}
                    sx={{ border: "1px solid", borderColor: "divider" }}
                  >
                    {isDownloading ? <CircularProgress size={20} /> : <FileDownload fontSize="small" />}
                  </IconButton>
                </span>
              </Tooltip>
            </Stack>

            <Menu anchorEl={downloadAnchor} open={Boolean(downloadAnchor)} onClose={handleDownloadClose}>
              <MenuItem onClick={() => executeDownload("PDF")}>Download Master PDF</MenuItem>
              <MenuItem onClick={() => executeDownload("Excel")}>Download Master Excel</MenuItem>
            </Menu>

            <Divider orientation="vertical" flexItem sx={{ height: 24 }} />

            <Typography
              variant="body2"
              sx={{ color: isRunning || isModelLoading ? "text.disabled" : "text.secondary" }}
            >
              MODEL
            </Typography>

            <Box sx={{ position: "relative" }}>
              <Select
                size="small"
                value={selectedModel || ""}
                onChange={handleModelChange}
                disabled={isRunning || isModelLoading}
                sx={{ minWidth: 200 }}
              >
                {models.length > 0 ? (
                  models.map((model) => (
                    <MenuItem key={model} value={model}>{model.replace(/_/g, " ")}</MenuItem>
                  ))
                ) : (
                  <MenuItem value={selectedModel || ""} disabled>
                    {selectedModel || "No models found"}
                  </MenuItem>
                )}
              </Select>
              {isModelLoading && (
                <CircularProgress
                  size={20}
                  sx={{ position: "absolute", top: "50%", left: "50%", mt: "-10px", ml: "-10px" }}
                />
              )}
            </Box>

            <Button
              variant="contained"
              startIcon={isRunning ? <Stop /> : <PlayArrow />}
              size="small"
              color={isRunning ? "error" : "primary"}
              onClick={handleRunClick}
              disabled={isModelLoading || isStarting || (buttonDisabled && !isRunning)}
            >
              {isRunning ? "STOP" : isStarting ? "STARTING..." : "RUN"}
            </Button>
          </Stack>
        </Toolbar>
      </AppBar>

      <Container maxWidth={false} sx={{ mt: 4 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", mb: 3 }}>
          <Stack direction="row" spacing={1}>
            {["all", "important", "spam"].map((tab) => {
              const isActive = activeTab === tab;
              return (
                <Button
                  key={tab}
                  startIcon={getTabIcon(tab, isActive)}
                  variant={isActive ? "contained" : "outlined"}
                  onClick={() => setActiveTab(tab)}
                  sx={{
                    borderRadius: "20px", px: 2, textTransform: "capitalize",
                    bgcolor: isActive ? "primary.main" : "transparent",
                    borderColor: "primary.main",
                    color: isActive ? "white" : "primary.main",
                    "&:hover": { bgcolor: isActive ? "primary.dark" : "transparent" },
                  }}
                >
                  {tab} ({getTabCount(tab)})
                </Button>
              );
            })}
          </Stack>

          <Stack direction="row" spacing={2} alignItems="center">
            <Typography variant="body2" color="text.secondary">
              MODEL QUALITY:{" "}
              {allRows.length > 0
                ? `${Number(allRows[allRows.length - 1]?.model_quality_score || 0).toFixed(2)}%`
                : "N/A"}
            </Typography>
            <Button
              startIcon={<Refresh />}
              size="small"
              disabled={buttonDisabled || isRunning}
              onClick={handleRefreshClick}
            >
              REFRESH
            </Button>
          </Stack>
        </Box>

        <TableContainer component={Paper} sx={{ width: "100%", overflowX: "auto" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>
                  <Button
                    onClick={() => handleSort("dt")}
                    endIcon={
                      <ArrowUpward
                        sx={{
                          fontSize: 16,
                          transform: sortConfig.direction === "asc" ? "rotate(0deg)" : "rotate(180deg)",
                        }}
                      />
                    }
                  >
                    DATE / TIME
                  </Button>
                </TableCell>
                <TableCell>BATCH</TableCell>
                <TableCell>RECORDS</TableCell>
                <TableCell sx={{ color: "error.main", fontWeight: "bold" }}>CRITICAL</TableCell>
                <TableCell sx={{ color: "#b28704", fontWeight: "bold" }}>MODERATE</TableCell>
                <TableCell sx={{ color: "success.main", fontWeight: "bold" }}>LOW</TableCell>
                <TableCell>MODEL</TableCell>
                <TableCell align="center">ACTION</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {processedRows.map((row) => (
                <TableRow
                  key={row.id}
                  className="row-item"
                  onContextMenu={(event) => handleContextMenu(event, row.id)}
                >
                  <TableCell>{dayjs(row.dt).format("YYYY-MM-DD HH:mm:ss")}</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>
                    {row.batch}
                    {row.processing && <CircularProgress size={12} sx={{ ml: 1 }} />}
                  </TableCell>
                  <TableCell>{Number(row.records || 0).toLocaleString()}</TableCell>
                  <TableCell sx={{ fontWeight: "bold", color: "error.main" }}>{row.crit}</TableCell>
                  <TableCell sx={{ fontWeight: "bold", color: "#b28704" }}>{row.mod}</TableCell>
                  <TableCell sx={{ fontWeight: "bold", color: "success.main" }}>{row.low}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2">
                        {(row.model || selectedModel || "production_model").replace(/_/g, " ")}
                      </Typography>
                      {row.model_quality_score !== undefined && (
                        <Chip
                          label={`${Number(row.model_quality_score || 0).toFixed(1)}%`}
                          size="small"
                        />
                      )}
                      {row.enriched && <Chip label="AI" size="small" color="primary" />}
                    </Stack>
                  </TableCell>
                  <TableCell align="center">
                    <Stack direction="row" spacing={1} justifyContent="center">
                      <Tooltip title="View Result">
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={() =>
                            navigate("/SyslogRows", {
                              state: {
                                batchData: row,
                                model: row.model || selectedModel,
                                selectedDate: selectedDate,
                                runId: row.run_id,
                                liveRows: row.liveRows || [],
                                live: Boolean(isRunning),
                              },
                            })
                          }
                        >
                          <Visibility />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Download Batch Excel">
                        <IconButton size="small" onClick={() => downloadBatchReport(row, "Excel")}>
                          <TableChart fontSize="small" color="success" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Download Batch PDF">
                        <IconButton size="small" onClick={() => downloadBatchReport(row, "PDF")}>
                          <PictureAsPdf fontSize="small" color="error" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Important">
                        <IconButton size="small" onClick={() => handleToggleStar(row.id)}>
                          {starredRows.includes(row.id) ? <Star color="warning" /> : <StarBorderOutlined />}
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}

              {isRunning && allRows.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} align="center">
                    <Stack spacing={2} alignItems="center" sx={{ py: 5 }}>
                      <CircularProgress />
                      <Typography>Waiting for incoming PostgreSQL syslog data…</Typography>
                      <LinearProgress sx={{ width: "50%" }} />
                    </Stack>
                  </TableCell>
                </TableRow>
              )}

              {!isRunning && allRows.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} align="center">
                    No audit data for {selectedDate}. Click RUN to begin continuous analysis from PostgreSQL.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Container>

      <Menu
        open={contextMenu !== null}
        onClose={() => setContextMenu(null)}
        anchorReference="anchorPosition"
        anchorPosition={
          contextMenu !== null
            ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
            : undefined
        }
      >
        <MenuItem onClick={handleSpamAction}>
          {spamRows.includes(selectedRowId) ? (
            <><Undo fontSize="small" sx={{ mr: 1 }} />Restore</>
          ) : (
            <><Block fontSize="small" sx={{ mr: 1 }} />Move to Spam</>
          )}
        </MenuItem>
      </Menu>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          severity={snackbar.severity}
          variant="filled"
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default SyslogDashboard;
