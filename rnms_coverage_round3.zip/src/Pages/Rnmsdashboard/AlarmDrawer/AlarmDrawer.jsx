/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : AlarmDrawer
   File Name                : AlarmDrawer.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\AlarmDrawer\AlarmDrawer.jsx
   Purpose                  : The purpose is to show AlarmDrawer page to get the recent alarm in IAF-NMS. 
   Created Date             : 07-01-2026
 *******************************************************************************************/

// import React, { useEffect, useState } from "react";
// import {
//   Typography,
//   Box,
//   Select,
//   MenuItem,
//   FormControl,
//   Button,
//   CircularProgress,
//   useTheme,
// } from "@mui/material";
// import { LinkTypeLegends } from "../Topology/topologyConstants";
// import recent10Alarm from "@/assets/SVGIcons/recent10Alarm.svg";
// import ActiveAlarmTable from "../FAult/components/ActiveAlarmTable";
// import {
//   FETCH_MISC_CONFIGURATION_BY_ID,
//   UPDATE_MISC_CONFIGURATION_BASED_ON_ID,
// } from "@/RestAPI/url/endpoint";
// import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import MModal from "@/components/Reusable/Modal/MModal";
// import Toast from "@/components/Reusable/Toast/Toast";
// import NMSChat from "../NMSChat/NMSChat";
// import { useSelector } from "react-redux";

// const AlarmDrawer = ({ activeTabKey, isOpen, onToggle }) => {
//   const theme = useTheme();
//   const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
//   const [isUpdating, setIsUpdating] = useState(false);
//   const [loading, setLoading] = useState(true); // Added loading state
//   const [config, setConfig] = useState({
//     value: "10",
//     min: 0,
//     max: 25,
//     range: [],
//   });
//   const [isChatOpen, setIsChatOpen] = useState(false);
//   const [tempValue, setTempValue] = useState("10");

//   const rackTab = useSelector((state) => state.topologySlice.currentViewTopology)

//   console.log("rackTab", rackTab);

//   // 1. FETCH DATA ON MOUNT
//   const fetchData = async () => {
//     setLoading(true);
//     try {
//       const response = await InventoryAxios(
//         FETCH_MISC_CONFIGURATION_BY_ID,
//         "get"
//       );

//       console.log("API Response:", response);
//       if (response && response.data) {
//         const { value, min, max } = response.data;

//         let range = [];
//         // Ensure we have valid numbers for the loop
//         const start = parseInt(min) || 0;
//         const end = parseInt(max) || 25;

//         for (let i = start; i <= end; i += 5) {
//           range.push(i.toString());
//         }
//         const newConfig = {
//           value: String(value),
//           min: min,
//           max: max,
//           range: range,
//         };

//         setConfig(newConfig);
//         setTempValue(String(value)); // Sync temp value with fetched data
//       }
//     } catch (error) {
//       console.error("Failed to fetch config", error);
//       Toast("error", "Failed to fetch recent alarm data.", "error");
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchData();
//   }, []);

//   // 2. HANDLE UPDATE
//   const handleUpdateSettings = async () => {
//     setIsUpdating(true);
//     try {
//       const payload = {
//         id: 10,
//         value: tempValue, // Use the temporary value here
//         min: config.min,
//         max: config.max,
//       };
//       await InventoryAxios(
//         UPDATE_MISC_CONFIGURATION_BASED_ON_ID,
//         "post",
//         payload
//       );

//       // SUCCESS: Now we update the actual config state so the table updates
//       setConfig((prev) => ({ ...prev, value: tempValue }));

//       Toast("Success!", "Recent Alarm Count Updated Successfully", "success");
//       setIsSettingsModalOpen(false);
//     } catch (error) {
//       console.error("Update error:", error);
//       Toast("Error!", "Failed to Update Recent Alarm Count", "error");
//     } finally {
//       setIsUpdating(false);
//     }
//   };
//   const handleSelectChange = (e) => {
//     setTempValue(e.target.value);
//   };
//   const handleIconClick = (e) => {
//     e.stopPropagation();
//     setIsSettingsModalOpen(true);
//   };
//   const severityConfig = {
//     MAJOR: {
//       label: "Major",
//       dotGradient: "linear-gradient(135deg, #ffced2 0%, #d75961 100%)",
//     },
//     MINOR: {
//       label: "Minor",
//       dotGradient: "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)",
//     },
//     WARNING: {
//       label: "Warning",
//       dotGradient: "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)",
//     },
//   };
//   return (
//     <Box sx={{ background: (theme) => theme.palette.background.topologybg }}>
//       {/* --- RE-ADDED LEGEND SECTION --- */}
//       {activeTabKey === "topology" && !!rackTab && (
//         <Box
//           className="flex justify-center items-center gap-3 py-3 px-4 "
//           sx={{ background: theme.palette.background.alaramdrawer }}
//         >
//           {/* MAJOR */}
//           <div
//             className="flex gap-1 items-center"
//             sx={{ background: theme.palette.background.alaramdrawer }}
//           >
//             <div
//               className="w-3 h-3 rounded-full"
//               style={{ background: severityConfig.MAJOR.dotGradient }}
//             ></div>
//             <div
//               style={{
//                 fontSize: "14px",
//                 color: (theme) => theme.palette.text.gray,
//               }}
//             >
//               Major
//             </div>
//           </div>

//           {/* MINOR */}
//           <div className="flex gap-1  items-center">
//             <div
//               className="w-3 h-3 rounded-full"
//               style={{ background: severityConfig.MINOR.dotGradient }}
//             ></div>
//             <div
//               style={{
//                 fontSize: "14px",
//                 color: (theme) => theme.palette.text.gray,
//               }}
//             >
//               Minor
//             </div>
//           </div>

//           {/* WARNING */}
//           <div className="flex gap-1 items-center">
//             <div
//               className="w-3 h-3 rounded-full"
//               style={{ background: severityConfig.WARNING.dotGradient }}
//             ></div>
//             <div
//               style={{
//                 fontSize: "14px",
//                 color: (theme) => theme.palette.text.gray,
//               }}
//             >
//               Warning
//             </div>
//           </div>

//           {/* LINK TYPE LEGENDS */}
//           {/* {LinkTypeLegends.map((item) => (
//             <div className="flex flex-col items-center ml-2" key={item.label}>
//               <div
//                 style={{
//                   width: "60px",
//                   height: "2px",
//                   borderBottom: `1px ${item.lineType} ${theme.palette.text.TitleTextcolor}`,
//                 }}
//               ></div>
//               <p
//                 style={{
//                   fontSize: "14px",
//                   color: (theme) => theme.palette.text.gray,
//                   margin: 0,
//                 }}
//               >
//                 {item.label}
//               </p>
//             </div>
//           ))} */}
//         </Box>
//       )}

//       <Box
//         className={`z-20 flex flex-col   transition-all duration-500 ease-in-out shrink-0 ${isOpen ? "h-[300px]" : "h-15"
//           }`}
//         sx={{ background: theme.palette.background.alaramdrawer }}
//       >
//         <NMSChat
//               isChatOpen={isChatOpen}
//               setIsChatOpen={setIsChatOpen}
//               theme={theme}
//             />
//         <button
//           onClick={onToggle}
//           className="h-10 flex items-center justify-center mt-5 px-4 cursor-pointer"
//         >
//           <Box className="flex items-center rounded-3xl bg-[#E9EFFF] justify-center">

//             <Box className="flex items-center gap-1 mb-2  ">

//               {/* Use config.value here so the label only changes when OK is pressed */}
//               <span className="text-[#14348D] px-2 py-3 rounded-4xl capitalize text-[15px]">
//                 Recent {loading ? "..." : config.value} Alarms
//               </span>
//               <img
//                 src={recent10Alarm}
//                 alt="settings"
//                 className="cursor-pointer"
//                 style={{ marginRight: "8px" }}
//                 onClick={handleIconClick}
//               />

//             </Box>
//           </Box>
//         </button>

//         <Box
//           className={`flex-1 overflow-y-auto ${isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
//             }`}
//         >
//           {!loading && (
//             /* The table uses config.value, which only updates on OK */
//             <ActiveAlarmTable
//               isDrawerMode={true}
//               limit={parseInt(config.value)}
//             />
//           )}
//         </Box>
//       </Box>

//       <MModal
//         open={isSettingsModalOpen}
//         handleClose={() => setIsSettingsModalOpen(false)}
//         title="Alarms Settings"
//         customWidth="400px"
//       >
//         <Box sx={{ p: 2 }}>
//           <Typography
//             variant="body2"
//             sx={{
//               fontWeight: 600,
//               mb: 2,
//               color: (theme) => theme.palette.text.gray,
//             }}
//           >
//             Recent Alarm Count *
//           </Typography>
//           <FormControl fullWidth size="small">
//             <Select
//               value={tempValue} // Use tempValue for the dropdown selection
//               onChange={handleSelectChange}
//               sx={{ borderRadius: "8px" }}
//               disabled={loading}
//             >
//               {config.range.map((val) => (
//                 <MenuItem key={val} value={val}>
//                   {val}
//                 </MenuItem>
//               ))}
//             </Select>
//           </FormControl>

//           <Box
//             sx={{
//               display: "flex",
//               justifyContent: "flex-end",
//               gap: 1.5,
//               mt: 4,
//             }}
//           >
//             <Button
//               onClick={() => setIsSettingsModalOpen(false)} // Clicking cancel does nothing to config/tempValue
//               variant="outlined"
//               sx={{
//                 textTransform: "none",
//                 borderRadius: "8px",
//                 color: (theme) => theme.palette.text.tabcolor,
//                 borderColor: "#ccc",
//               }}
//             >
//               Cancel
//             </Button>
//             <Button
//               onClick={handleUpdateSettings}
//               variant="contained"
//               disabled={isUpdating || loading}
//               sx={{
//                 textTransform: "none",
//                 borderRadius: "8px",
//                 backgroundColor: "#14348D",
//                 minWidth: "80px",
//               }}
//             >
//               {isUpdating ? (
//                 <CircularProgress size={20} color="inherit" />
//               ) : (
//                 "OK"
//               )}
//             </Button>
//           </Box>
//         </Box>
//       </MModal>

//     </Box>
//   );
// };
// export default AlarmDrawer;
import React, { useEffect, useState } from "react";
import {
  Typography,
  Box,
  Select,
  MenuItem,
  FormControl,
  Button,
  CircularProgress,
  useTheme,
} from "@mui/material";
import recent10Alarm from "@/assets/SVGIcons/recent10Alarm.svg";
import ActiveAlarmTable from "../FAult/components/ActiveAlarmTable";
import {
  FETCH_MISC_CONFIGURATION_BY_ID,
  UPDATE_MISC_CONFIGURATION_BASED_ON_ID,
} from "@/RestAPI/url/endpoint";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MModal from "@/components/Reusable/Modal/MModal";
import Toast from "@/components/Reusable/Toast/Toast";
import NMSChatBot from "../NMSChatBot/NMSChatBot";
import { useSelector } from "react-redux";
import LegendStatus from "../PortStatus/LegendStatus";
import { severityConfig } from "./utils";
import CnmsChat from "../NMSChatBot/CnmsChat";

const AlarmDrawer = ({ activeTabKey, isOpen, onToggle }) => {
  const theme = useTheme();
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState({
    value: "10",
    min: 0,
    max: 25,
    range: [],
  });
  const [isChatBotOpen, setIsChatBotOpen] = useState(false);
  const [tempValue, setTempValue] = useState("10");

  const { isCnms, repDetails } = useSelector((state) => state.nodeDetails);

  console.log("activeTabKey", activeTabKey);

  const rackTab = useSelector(
    (state) => state.topologySlice.currentViewTopology
  );
  const { userDetails } = useSelector((state) => state.userSlice);
  const allSites = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails
  );
  const privData = userDetails.data.group.privileges;
  const chatBotPriv = privData.filter((priv) => priv.key === "nms_chat_bot");
  console.log("aks userDetails= ", chatBotPriv);
  const rnms = chatBotPriv[0]?.rnms;

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await InventoryAxios(
        FETCH_MISC_CONFIGURATION_BY_ID,
        "get"
      );

      if (response?.data) {
        const { value, min, max } = response.data;
        let range = [];
        const start = parseInt(min) || 0;
        const end = parseInt(max) || 25;

        for (let i = start; i <= end; i += 5) {
          range.push(i.toString());
        }
        setConfig({
          value: String(value),
          min: min,
          max: max,
          range: range,
        });
        setTempValue(String(value));
      }
    } catch (error) {
      console.error("Failed to fetch config", error);
      Toast("error", "Failed to fetch recent alarm data.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleUpdateSettings = async () => {
    setIsUpdating(true);
    try {
      const payload = {
        id: 10,
        value: tempValue,
        min: config.min,
        max: config.max,
      };
      await InventoryAxios(
        UPDATE_MISC_CONFIGURATION_BASED_ON_ID,
        "post",
        payload
      );

      setConfig((prev) => ({ ...prev, value: tempValue }));
      Toast("Success!", "Recent Alarm Count Updated Successfully", "success");
      setIsSettingsModalOpen(false);
    } catch (error) {
      console.error("Update error:", error);
      Toast("Error!", "Failed to Update Recent Alarm Count", "error");
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSelectChange = (e) => {
    setTempValue(e.target.value);
  };

  const handleIconClick = (e) => {
    e.stopPropagation();
    setIsSettingsModalOpen(true);
  };

  // const baseBottomPosition = isOpen ? "240px" : "1px";
  return (
    <Box
      sx={{
        background: (theme) => theme.palette.background.topologybg,
        position: "relative",
      }}
    >
      {activeTabKey === "topology" && !!rackTab && (
        <Box
          className="flex justify-around items-center gap-3 py-1 px-4"
          sx={{ background: theme.palette.background.alaramdrawer }}
        >
          {!isCnms && (
            <Box className="flex justify-center items-center gap-3 px-4 legend-label">
              <div className="flex gap-1 items-center">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ background: severityConfig.MAJOR.dotGradient }}
                ></div>
                <span className="legend-label">Major</span>
              </div>

              {/* Separator between Major and Minor */}
              <span className="legend-separator">|</span>

              <div className="flex gap-1 items-center">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ background: severityConfig.MINOR.dotGradient }}
                ></div>
                <span className="legend-label">Minor</span>
              </div>

              {/* Separator between Minor and Warning */}
              <span className="legend-separator">|</span>

              <div className="flex gap-1 items-center">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ background: severityConfig.WARNING.dotGradient }}
                ></div>
                <span className="legend-label">Warning</span>
              </div>
            </Box>
          )}

          {/* LegendStatus Component */}
          {!isCnms && (
            <Box>
              <LegendStatus alarmPortLegend={true} />
            </Box>
          )}
        </Box>
      )}

      {/* --- DRAWER CONTAINER --- */}
      <Box
        className={`z-20 flex flex-col transition-all duration-500 ease-in-out shrink-0 ${
          isOpen ? "h-[300px]" : "h-15"
        }`}
        sx={{
          // background: theme.palette.background.alaramdrawer,
          background:
            isCnms &&
            activeTabKey === "mapView" &&
            theme.palette.mode === "dark"
              ? "#121212"
              : theme.palette.background.alaramdrawer,
          position: "relative",
          overflow: "hidden",
        }}
      >
        <button
          onClick={onToggle}
          className="h-10 flex items-center justify-center mt-5 px-4 cursor-pointer"
        >
          <Box className="flex items-center rounded-3xl bg-[#E9EFFF] justify-center">
            <Box className="flex items-center gap-1 mb-2">
              <span className="text-[#14348D] px-2 py-3 rounded-4xl capitalize text-[15px]">
                Recent {loading ? "..." : config.value} Alarms
              </span>
              <img
                src={recent10Alarm}
                alt="settings"
                className="cursor-pointer"
                style={{ marginRight: "8px" }}
                onClick={handleIconClick}
              />
            </Box>
          </Box>
        </button>

        <Box
          className={`flex-1 overflow-y-auto ${
            isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
        >
          {!loading && (
            <ActiveAlarmTable
              isDrawerMode={true}
              limit={parseInt(config.value)}
            />
          )}
        </Box>
      </Box>
      {/* {isCnms && (
        <IconButton
          onClick={() => setIsCnmsChatOpen(true)}
          sx={{
            color: "#14348D",
            position: "fixed",
            right: "14%",
            bottom: baseBottomPosition,
            zIndex: 1400,
          }}
        >
          <ChatIcon />
        </IconButton>
      )} */}

      {/* NMS Chat rendered outside the drawer flow as a fully independent fixed entity */}
      {/* <NMSChat
        isChatOpen={isChatOpen}
        setIsChatOpen={setIsChatOpen}
        isDrawerOpen={isOpen}
        theme={theme}
      /> */}

      <CnmsChat
        isCnms={isCnms}
        siteDetails={repDetails}
        sites={allSites || []}
        isDrawerOpen={isOpen}
      />

      {rnms && (
        <NMSChatBot
          isChatBotOpen={isChatBotOpen}
          setIsChatBotOpen={setIsChatBotOpen}
          isDrawerOpen={isOpen}
          theme={theme}
        />
      )}

      {/* --- SETTINGS MODAL --- */}
      <MModal
        open={isSettingsModalOpen}
        handleClose={() => setIsSettingsModalOpen(false)}
        title="Alarms Settings"
        customWidth="400px"
      >
        <Box sx={{ p: 2 }}>
          <Typography
            variant="body2"
            sx={{
              fontWeight: 600,
              mb: 2,
              color: (theme) => theme.palette.text.gray,
            }}
          >
            Recent Alarm Count *
          </Typography>
          <FormControl fullWidth size="small">
            <Select
              value={tempValue}
              onChange={handleSelectChange}
              sx={{ borderRadius: "8px" }}
              disabled={loading}
            >
              {config.range.map((val) => (
                <MenuItem key={val} value={val}>
                  {val}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              gap: 1.5,
              mt: 4,
            }}
          >
            <Button
              onClick={() => setIsSettingsModalOpen(false)}
              variant="outlined"
              sx={{
                textTransform: "none",
                borderRadius: "8px",
                color: (theme) => theme.palette.text.tabcolor,
                borderColor: "#ccc",
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdateSettings}
              variant="contained"
              disabled={isUpdating || loading}
              sx={{
                textTransform: "none",
                borderRadius: "8px",
                backgroundColor: "#14348D",
                minWidth: "80px",
              }}
            >
              {isUpdating ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                "OK"
              )}
            </Button>
          </Box>
        </Box>
      </MModal>
    </Box>
  );
};

export default AlarmDrawer;
