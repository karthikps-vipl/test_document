  export const severityConfig = {
    MAJOR: {
      label: "Major",
      dotGradient: "linear-gradient(135deg, #ffced2 0%, #d75961 100%)",
    },
    MINOR: {
      label: "Minor",
      dotGradient: "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)",
    },
    WARNING: {
      label: "Warning",
      dotGradient: "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)",
    },
  };