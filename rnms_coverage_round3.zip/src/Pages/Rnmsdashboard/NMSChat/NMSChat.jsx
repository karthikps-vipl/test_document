// import React, { useState, useEffect, useRef } from 'react';
// import { 
//   Box, Typography, Avatar, IconButton, TextField, useTheme 
// } from '@mui/material';
// import SendIcon from '@mui/icons-material/Send';
// import chatbox_Message from "@/assets/SVGIcons/chatbox_Message.svg"
// const INITIAL_MESSAGES = [
//   { id: 1, text: "adipiscing elit adipiscing elit", time: "10:00 AM", type: "sent" },
//   { id: 2, text: "Lorem ipsum dolor sit amet, consectetuer adipiscing eli adipiscing elit", time: "10:00 AM", type: "received" },
//   { id: 3, text: "adipiscing elit adipiscing elit", time: "12:00 AM", type: "sent" },
//   { id: 4, text: "Lorem ipsum dolor sit amet, consectetuer adipiscing eli adipiscing elit", time: "12:40 AM", type: "received" },
// ];

// const NMSChat = ({ isChatOpen, setIsChatOpen, theme }) => {
//   const [messages, setMessages] = useState(INITIAL_MESSAGES);
//   const [inputValue, setInputValue] = useState("");
  
//   // 1. REFS for Auto-Scrolling
//   const messagesEndRef = useRef(null);

//   const scrollToBottom = () => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   };

//   // Scroll to bottom whenever messages change or chat opens
//   useEffect(() => {
//     if (isChatOpen) {
//       scrollToBottom();
//     }
//   }, [messages, isChatOpen]);

//   const handleSendMessage = () => {
//     if (!inputValue.trim()) return;
    
//     const newMessage = {
//       id: Date.now(),
//       text: inputValue,
//       time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
//       type: 'sent'
//     };
    
//     setMessages(prev => [...prev, newMessage]);
//     setInputValue("");

//     // SIMULATE BOT RESPONSE (Optional - for testing)
//     setTimeout(() => {
//       const botReply = {
//         id: Date.now() + 1,
//         text: "I am processing your request...",
//         time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
//         type: 'received'
//       };
//       setMessages(prev => [...prev, botReply]);
//     }, 1000);
//   };

//   return (
//     <>
//       {/* --- CHAT TRIGGER ICON --- */}
//       <Box
//   onClick={() => setIsChatOpen(!isChatOpen)}
//   sx={{
//     position: 'fixed', // This keeps it relative to the browser window, not the container
//     // bottom: 30,        // Distance from bottom
//     right: "7%",         // Distance from right
//         // Extremely high to stay on top of maps/tables
//     cursor: 'pointer',
//     width: 40,
//     height: 40,
//     borderRadius: '50%',
//     backgroundColor: '#14348D',
//     display: 'flex',
//     alignItems: 'center',
//     justifyContent: 'center',
    
//     '&:hover': { 
//       transform: 'scale(1.1)',
//       backgroundColor: '#1a46b5' 
//     },
//   }}
// >
//   {/* Using a more visible symbol or icon */}
//  <img src={chatbox_Message} style={{ color: 'white', fontSize: '30px', userSelect: 'none' }}></img>
// </Box>

//       {/* --- CHAT WINDOW --- */}
//       {isChatOpen && (
//         <Box
//           sx={{
//             position: 'fixed',
//             bottom: 60,
//             right: "10%",
//             width: { xs: '300px', sm: '350px' }, // Responsive width
//             height: '400px',
          
//             backgroundColor: '#F5F7F9',
//             borderRadius: '16px',
//             display: 'flex',
//             flexDirection: 'column',
//             boxShadow: '0px 10px 30px rgba(0,0,0,0.2)',
//             overflow: 'hidden',
//             border: '1px solid #E0E0E0'
//           }}
//         >
//           {/* 1. CHAT HEADER */}
//           <Box sx={{ 
//             p: 1, 
//             bgcolor: '#14348D', 
//             color: 'white', 
//             display: 'flex', 
//             alignItems: 'center', 
//             justifyContent: 'space-between' 
//           }}>
//             <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//               <Avatar sx={{ width: 32, height: 32, bgcolor: 'black', color: 'white', fontSize: '14px', fontWeight: 'bold' }}>N</Avatar>
//               <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>NMS Chat</Typography>
//             </Box>
//             <IconButton size="small" onClick={() => setIsChatOpen(false)} sx={{ color: 'white', }}>
//               <span style={{ fontSize: '20px' }}>✕</span>
//             </IconButton>
//           </Box>

//           {/* 2. CHAT MESSAGES AREA */}
//           <Box sx={{ 
//             flex: 1, 
//             p: 2, 
//             overflowY: 'auto', 
//             display: 'flex', 
//             flexDirection: 'column', 
//             gap: 2,
//             // Custom Scrollbar for better UI
//             '&::-webkit-scrollbar': { width: '6px' },
//             '&::-webkit-scrollbar-thumb': { backgroundColor: '#ccc', borderRadius: '10px' }
//           }}>
//             <Typography variant="caption" sx={{ alignSelf: 'center', color: '#999', mb: 1 }}>Today</Typography>
            
//             {messages.map((msg) => (
//               <Box
//                 key={msg.id}
//                 sx={{
//                   display: 'flex',
//                   flexDirection: msg.type === 'received' ? 'row' : 'row-reverse',
//                   alignItems: 'flex-start',
//                   gap: 1,
//                   width: '100%'
//                 }}
//               >
//                 {msg.type === 'received' && (
//                   <Avatar sx={{ width: 28, height: 28, bgcolor: '#333', fontSize: '12px' }}>N</Avatar>
//                 )}
//                 <Box sx={{ 
//                   display: 'flex', 
//                   flexDirection: 'column', 
//                   alignItems: msg.type === 'sent' ? 'flex-end' : 'flex-start', 
//                   maxWidth: '75%' 
//                 }}>
//                   <Box
//                     sx={{
//                       p: 1.5,
//                       borderRadius: msg.type === 'sent' ? '15px 15px 2px 15px' : '15px 15px 15px 2px',
//                       bgcolor: msg.type === 'sent' ? '#E8EFFF' : '#FFFFFF',
//                       color: '#333',
//                       fontSize: '13px',
//                       boxShadow: '0px 2px 5px rgba(0,0,0,0.05)',
//                     }}
//                   >
//                     {msg.text}
//                   </Box>
                  
//                   <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.5, px: 0.5 }}>
//                     <Typography variant="caption" sx={{ fontSize: '10px', color: '#999' }}>
//                       {msg.time}
//                     </Typography>
//                     {msg.type === 'sent' && (
//                       <span style={{ fontSize: '10px', color: '#4A90E2' }}>✓✓</span>
//                     )}
//                   </Box>
//                 </Box>
//               </Box>
//             ))}
//             {/* Invisible element to anchor scrolling */}
//             <div ref={messagesEndRef} />
//           </Box>

//           {/* 3. MESSAGE INPUT AREA */}
//           <Box sx={{ p: 2, bgcolor: 'white' }}>
//             <TextField
//               fullWidth
//               placeholder="Type your message (Max 140)..."
//               variant="outlined"
//               value={inputValue}
//               onChange={(e) => {
//                 // Enforce 140 character limit
//                 if (e.target.value.length <= 140) setInputValue(e.target.value);
//               }}
//               onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
//               sx={{
//                 '& .MuiOutlinedInput-root': {
//                   borderRadius: '25px',
//                   pr: 1,
//                   '& fieldset': { borderColor: '#E0E0E0' },
//                   '&:hover fieldset': { borderColor: '#14348D' },
//                 }
//               }}
//               InputProps={{
//                 endAdornment: (
//                   <IconButton 
//                     onClick={handleSendMessage} 
//                     disabled={!inputValue.trim()} // Disable if input is empty
//                     sx={{ color: '#14348D' }}
//                   >
//                     <SendIcon fontSize="small" />
//                   </IconButton>
//                 ),
//               }}
//             />
//           </Box>
//         </Box>
//       )}
//     </>
//   );
// };

// export default NMSChat;
import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, Typography, Avatar, IconButton, TextField 
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import chatbox_Message from "@/assets/SVGIcons/chatbox_Message.svg"

const INITIAL_MESSAGES = [
  { id: 1, text: "adipiscing elit adipiscing elit", time: "10:00 AM", type: "sent" },
  { id: 2, text: "Lorem ipsum dolor sit amet, consectetuer adipiscing eli adipiscing elit", time: "10:00 AM", type: "received" },
  { id: 3, text: "adipiscing elit adipiscing elit", time: "12:00 AM", type: "sent" },
  { id: 4, text: "Lorem ipsum dolor sit amet, consectetuer adipiscing eli adipiscing elit", time: "12:40 AM", type: "received" },
];

const NMSChat = ({ isChatOpen, setIsChatOpen, isDrawerOpen }) => {
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [inputValue, setInputValue] = useState("");
  
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isChatOpen) {
      scrollToBottom();
    }
  }, [messages, isChatOpen]);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      text: inputValue,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'sent'
    };
    
    setMessages(prev => [...prev, newMessage]);
    setInputValue("");

    setTimeout(() => {
      const botReply = {
        id: Date.now() + 1,
        text: "I am processing your request...",
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'received'
      };
      setMessages(prev => [...prev, botReply]);
    }, 1000);
  };

  // Dynamic bottom spacing that matches drawer height changes (300px open vs ~60px closed)
  const baseBottomPosition = isDrawerOpen ? '240px' : '1px';
  const windowBottomPosition = isDrawerOpen ? '300px' : '50px';

  return (
    <>
      {/* --- CHAT TRIGGER ICON (Independent fixed element moving smoothly with drawer state) --- */}
      <Box
      title = "NMS Chat"
        onClick={() => setIsChatOpen(!isChatOpen)}
        sx={{
          position: 'fixed',
          right: '8%',
          bottom: baseBottomPosition,
          cursor: 'pointer',
          width: 44,
          height: 44,
          borderRadius: '50%',
          backgroundColor: '#14348D',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0px 6px 16px rgba(0,0,0,0.3)', 
          zIndex: 1400, 
          transition: 'bottom 0.5s ease-in-out, transform 0.2s ease', // Matches drawer transition duration
          '&:hover': { 
            transform: 'scale(1.1)',
            backgroundColor: '#1a46b5' 
          },
        }}
      >
        <img src={chatbox_Message} alt="chat" style={{ width: '22px', height: '22px', userSelect: 'none' }} />
      </Box>
      {/* --- CHAT WINDOW --- */}
      {isChatOpen && (
        <Box
          sx={{
            position: 'fixed',
            bottom: windowBottomPosition, 
            right: '7%',
            width: { xs: '300px', sm: '350px' },
            height: '400px',
            backgroundColor: '#F5F7F9',
            borderRadius: '16px',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0px 12px 35px rgba(0,0,0,0.25)',
            overflow: 'hidden',
            border: '1px solid #E0E0E0',
            zIndex: 9999, 
            transition: 'bottom 0.5s ease-in-out',
          }}
        >
          {/* 1. CHAT HEADER */}
          <Box sx={{ 
            p: 1.5, 
            bgcolor: '#14348D', 
            color: 'white', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between' 
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Avatar sx={{ width: 32, height: 32, bgcolor: 'black', color: 'white', fontSize: '14px', fontWeight: 'bold' }}>N</Avatar>
              <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>NMS Chat</Typography>
            </Box>
            <IconButton size="small" onClick={() => setIsChatOpen(false)} sx={{ color: 'white' }}>
              <span style={{ fontSize: '18px' }}>✕</span>
            </IconButton>
          </Box>

          {/* 2. CHAT MESSAGES AREA */}
          <Box sx={{ 
            flex: 1, 
            p: 2, 
            overflowY: 'auto', 
            display: 'flex', 
            flexDirection: 'column', 
            gap: 2,
            '&::-webkit-scrollbar': { width: '6px' },
            '&::-webkit-scrollbar-thumb': { backgroundColor: '#ccc', borderRadius: '10px' }
          }}>
            <Typography variant="caption" sx={{ alignSelf: 'center', color: '#999', mb: 1 }}>Today</Typography>
            
            {messages.map((msg) => (
              <Box
                key={msg.id}
                sx={{
                  display: 'flex',
                  flexDirection: msg.type === 'received' ? 'row' : 'row-reverse',
                  alignItems: 'flex-start',
                  gap: 1,
                  width: '100%'
                }}
              >
                {msg.type === 'received' && (
                  <Avatar sx={{ width: 28, height: 28, bgcolor: '#333', fontSize: '12px' }}>N</Avatar>
                )}
                <Box sx={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  alignItems: msg.type === 'sent' ? 'flex-end' : 'flex-start', 
                  maxWidth: '75%' 
                }}>
                  <Box
                    sx={{
                      p: 1.5,
                      borderRadius: msg.type === 'sent' ? '15px 15px 2px 15px' : '15px 15px 15px 2px',
                      bgcolor: msg.type === 'sent' ? '#E8EFFF' : '#FFFFFF',
                      color: '#333',
                      fontSize: '13px',
                      boxShadow: '0px 2px 5px rgba(0,0,0,0.05)',
                    }}
                  >
                    {msg.text}
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.5, px: 0.5 }}>
                    <Typography variant="caption" sx={{ fontSize: '10px', color: '#999' }}>
                      {msg.time}
                    </Typography>
                    {msg.type === 'sent' && (
                      <span style={{ fontSize: '10px', color: '#4A90E2' }}>✓✓</span>
                    )}
                  </Box>
                </Box>
              </Box>
            ))}
            <div ref={messagesEndRef} />
          </Box>

          {/* 3. MESSAGE INPUT AREA */}
          <Box sx={{ p: 2, bgcolor: 'white' }}>
            <TextField
              fullWidth
              placeholder="Type your message (Max 140)..."
              variant="outlined"
              value={inputValue}
              onChange={(e) => {
                if (e.target.value.length <= 140) setInputValue(e.target.value);
              }}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: '25px',
                  pr: 1,
                  '& fieldset': { borderColor: '#E0E0E0' },
                  '&:hover fieldset': { borderColor: '#14348D' },
                }
              }}
              InputProps={{
                endAdornment: (
                  <IconButton 
                    onClick={handleSendMessage} 
                    disabled={!inputValue.trim()}
                    sx={{ color: '#14348D' }}
                  >
                    <SendIcon fontSize="small" />
                  </IconButton>
                ),
              }}
            />
          </Box>
        </Box>
      )}
    </>
  );
};

export default NMSChat;