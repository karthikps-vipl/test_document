
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  InputAdornment,
  IconButton,
  Box,
} from "@mui/material";
import { encryptData } from "@/utility/encryptLogin";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
 
import { SquareIconButton } from "./RightUtilityDrawer/RightUtilityDrawer";
import CloseIcon from "@mui/icons-material/Close";


const PasswordPromptDialog = ({ open, onClose, onSubmit, resourceName, externalError }) => {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); // State for toggling visibility
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("Password cannot be empty");

  // Reset local state when dialog opens/closes
  useEffect(() => {
    if (open) {
      setPassword("");
      setShowPassword(false);
      setError(false);
    }
  }, [open]);

  // Sync external validation errors (like incorrect password check)
  useEffect(() => {
    if (externalError) {
      setError(true);
      setErrorMessage("Incorrect password. Please try again.");
    }
  }, [externalError]);

  const handleSubmit = () => {
    if (!password.trim()) {
      setError(true);
      setErrorMessage("Password cannot be empty");
      return;
    }
    const encryptedPassword = encryptData(password);
    console.log("encryptedPassword", encryptedPassword);
    onSubmit(encryptedPassword);
  };

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  return (
    <Box sx={{borderRadius:"12px",}}>
      <Dialog open={open} onClose={onClose} maxWidth="xs"  PaperProps={{
        sx:{
          borderRadius:"30px"
        }
      }} >
      
     <Box sx={{display:'flex',justifyContent:"flex-end"}}>
       <DialogTitle sx={{color:"#14348d",fontSize:"18px",mr:6,}} > Authentication Required</DialogTitle>
      <SquareIconButton sx={{mt:2,mr:2}} onClick={onClose}>
          <CloseIcon />
        </SquareIconButton></Box>
      <DialogContent >
        <Typography variant="body2" sx={{ mb: 2 }}>
          Device <b>{resourceName}</b> requires authentication to access its status. Please enter your password.
        </Typography>
        <TextField
          autoFocus
          fullWidth
          type={showPassword ? "text" : "password"} // Switches input type dynamically
          label="Password"
          variant="outlined"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
            setError(false);
          }}
          error={error}
          helperText={error ? errorMessage : ""}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {showPassword ? <Visibility /> : < VisibilityOff/>}
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      </DialogContent>
      <DialogActions >
        <Box sx={{mb:1,display:"flex" ,gap:2,mr:2}}>
        <MButtonSecondary onClick={onClose}  variant="outlined">
          Cancel
        </MButtonSecondary>
        <MButtonPrimary onClick={handleSubmit} variant="contained" color="primary">
          Submit
        </MButtonPrimary>
        </Box>
      </DialogActions>
    </Dialog>
    </Box>
  );
};

export default PasswordPromptDialog;