/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : RightUtilityDrawer
   File Name                : RightUtilityDrawer.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\RightUtilityDrawer.jsx
   Purpose                  : A reusable side-drawer component used to display utility 
                              previliges. 
   Created Date             : 20-03-2026
***********************************************************************************************/
import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  Drawer,
  Box,
  Tooltip,
  Popover,
  IconButton,
  Typography,
} from "@mui/material";
import {
  Search,
  Fullscreen as FullscreenIcon,
  ChevronLeft,
  ChevronRight,
  Folder,
} from "lucide-react";
import { useSelector } from "react-redux";
import {
  Close as CloseIcon,
  Description,
  FolderOpen,
  FullscreenExit,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

import { Progress } from "antd";

import {
  FileList,
  IconList,
} from "../../../utility/RightSideBar/iconAndFileList";
import { FETCH_CPU_RAM_DISK } from "@/RestAPI/url/endpoint";
import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";
import ConfigEditRepDetails from "./components/Configuration/RepDetails/ConfigEditRepDetails";
import ConfigAddRepDetails from "./components/Configuration/RepDetails/ConfigAddRepDetails";
import ConfigAddDeviceLogin from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/DeviceLoginManagement/ConfigAddDeviceLogin";
import ConfigEditDeviceLogin from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/DeviceLoginManagement/ConfigEditDeviceLogin";
import ConfigViewDeviceLogin from "./components/Configuration/DeviceLoginManagement/ConfigViewDeviceLogin";
import PerformanceAddThreshold from "./components/Performance/Threshold/PerformanceAddThreshold";
import PerformanceEditThreshold from "./components/Performance/Threshold/PerformanceEditThreshold";
import SiteConfigCreateProfile from "./components/SiteConfiguator/Snmp/SiteConfigCreateProfile";
import SiteConfigEditProfile from "./components/SiteConfiguator/Snmp/SiteConfigEditProfile";
import SiteConfigViewProfile from "./components/SiteConfiguator/Snmp/SiteConfigViewProfile";
import ConfigAddScheduleBackup from "./components/Configuration/ScheduleBackup/ConfigAddScheduleBackup";
import ConfigEditScheduleBackup from "./components/Configuration/ScheduleBackup/ConfigEditScheduleBackup";
import ConfigViewScheduleBackup from "./components/Configuration/ScheduleBackup/ConfigViewScheduleBackup";
import { ReportTreeMenu } from "./ReportTreeMenu";
import reportTreeData from "../../../JsonFile/ReportTreeView.json";
import parentIconAudit from "@/assets/SVGIcons/Audit.svg";
import parentIconFault from "@/assets/SVGIcons/Fault.svg";
import parentIconInventory from "@/assets/SVGIcons/Inventory.svg";
import parentIconPerformance from "@/assets/SVGIcons/Performances.svg";
import parentIconDatabase from "@/assets/SVGIcons/Database.svg";
import HandleReopenAction from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleHistoryAction";
import HelpDeskCreate from "./components/HelpDesk/HelpDeskCreate";
import HandleHistoryAction from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleHistoryAction";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";

const FORM_MAPPING = {
  configuration_rep: {
    CREATE: ConfigAddRepDetails,
    EDIT: ConfigEditRepDetails,
    VIEW: null,
  },
  performance_settings_threshold: {
    CREATE: PerformanceAddThreshold,
    EDIT: PerformanceEditThreshold,
    VIEW: null,
  },
  configuration_device_login_management: {
    CREATE: ConfigAddDeviceLogin,
    EDIT: ConfigEditDeviceLogin,
    VIEW: ConfigViewDeviceLogin,
  },
  site_config_snmp: {
    CREATE: SiteConfigCreateProfile,
    EDIT: SiteConfigEditProfile,
    VIEW: SiteConfigViewProfile,
  },
  configuration_schedule_backup: {
    CREATE: ConfigAddScheduleBackup,
    EDIT: ConfigEditScheduleBackup,
    VIEW: ConfigViewScheduleBackup,
  },
  help_desk_child: {
    CREATE: HelpDeskCreate,
    CLOSE: HelpDeskCreate,
    HISTORY: HandleHistoryAction,
    REOPEN: HandleReopenAction,
  },
};

const SquareIconButton = styled(IconButton)({
  backgroundColor: "#D7EEFF",
  borderRadius: "20%",
  width: "30px",
  height: "30px",
  padding: "0",
  "&:hover": { backgroundColor: "#bde4ff" },
});

const RightUtilityDrawer = ({ selectedNode }) => {
  const [activeParent, setActiveParent] = useState(null);
  const [activeChild, setActiveChild] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchAnchor, setSearchAnchor] = useState(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [drawerWidth, setDrawerWidth] = useState("45%");

  // Track hover state for the expanding sidebar
  const [isHovered, setIsHovered] = useState(false);

  const [subDrawerData, setSubDrawerData] = useState(null);
  const [refreshTicket, setRefreshTicket] = useState(0);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const { userDetails } = useSelector((state) => state.userSlice);
  const privilege = userDetails?.data?.group?.privileges || [];
  const deployedType = "rnms";
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  useEffect(() => {
    if (searchAnchor) {
      const timer = setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [searchAnchor]);
  const triggerRefresh = () => {
    setRefreshTicket((prev) => prev + 1);
  };
  const updateScrollButtons = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;

      // 1. If nothing is scrollable, disable both
      if (scrollWidth <= clientWidth) {
        setCanScrollLeft(false);
        setCanScrollRight(false);
        return;
      }

      // 2. Can scroll left if scrollLeft is greater than 0
      // Using 1 instead of 2 to be more sensitive to the start
      setCanScrollLeft(scrollLeft > 1);

      // 3. Can scroll right if scrollLeft + clientWidth is less than total scrollWidth
      // REMOVED the "- 5" buffer. We want to know if we are EXACTLY at the end.
      // We use a tiny 1px threshold to account for sub-pixel rendering in some browsers
      const isAtRightEnd = Math.ceil(scrollLeft + clientWidth) >= scrollWidth;

      setCanScrollRight(!isAtRightEnd);
    }
  };

  // Setup scroll and resize listeners when active parent changes (tabs mount)
  useEffect(() => {
    const container = scrollRef.current;
    if (container) {
      const timer = setTimeout(updateScrollButtons, 100);

      container.addEventListener("scroll", updateScrollButtons);
      window.addEventListener("resize", updateScrollButtons);

      return () => {
        clearTimeout(timer);
        container.removeEventListener("scroll", updateScrollButtons);
        window.removeEventListener("resize", updateScrollButtons);
      };
    }
  }, [activeParent]);
  /* --- SEARCH POPOVER & SCROLL LOGIC --- */
  // const handleScroll = (dir) => {
  //   if (scrollRef.current) {
  //     const { scrollLeft } = scrollRef.current;
  //     scrollRef.current.scrollTo({
  //       left: dir === "left" ? scrollLeft - 200 : scrollLeft + 200,
  //       behavior: "smooth",
  //     });
  //   }
  // };
  const handleScroll = (dir) => {
    if (scrollRef.current) {
      const { scrollLeft } = scrollRef.current;
      const scrollAmount = 200;

      scrollRef.current.scrollTo({
        left:
          dir === "left"
            ? scrollLeft - scrollAmount
            : scrollLeft + scrollAmount,
        behavior: "smooth",
      });

      // REMOVED setTimeout. The onScroll={updateScrollButtons} in your JSX
      // will catch every frame of this animation automatically.
    }
  };

  const filteredPrivileges = useMemo(() => {
    if (!privilege) return [];
    return privilege.filter((item) =>
      deployedType === "rnms" ? item.rnms : item.cnms
    );
  }, [privilege, deployedType]);

  const parentPrivileges = useMemo(
    () => filteredPrivileges.filter((item) => item.parent === 0),
    [filteredPrivileges]
  );
  const getIconForKey = (key) => IconList[key] || null;

  const getChildren = (parentId) =>
    filteredPrivileges.filter((item) => item.parent === parentId);

  const currentActiveParentObj = useMemo(() => {
    return parentPrivileges.find((p) => p.id === activeParent);
  }, [parentPrivileges, activeParent]);

  const isReportsCategory = useMemo(() => {
    if (!currentActiveParentObj) return false;
    const name = currentActiveParentObj.privilegeName.toLowerCase();
    const key = currentActiveParentObj.key?.toLowerCase() || "";
    return name.includes("report") || key.includes("report");
  }, [currentActiveParentObj]);

  const reportsTreeStructure = useMemo(() => {
    if (!isReportsCategory || !activeParent || !reportTreeData) return [];

    return Object.entries(reportTreeData).reduce(
      (acc, [groupKey, groupData]) => {
        const isGroupValid =
          groupData.terminalType === "BOTH" ||
          groupData.terminalType?.toLowerCase() === deployedType;

        if (!isGroupValid) return acc;

        const childLeaves = (groupData.components || [])
          .filter((child) => {
            return (
              child.terminalType === "BOTH" ||
              child.terminalType?.toLowerCase() === deployedType
            );
          })
          .map((child) => ({
            key: child.key,
            label: child.title.toUpperCase(),
            icon: <Description fontSize="small" style={{ color: "black" }} />,
            children: null,
            activeTabConfig: {
              mainParent: groupData.key,
              key: child.key,
              label: child.title,
              fields: child.fields,
            },
            metaFields: child.fields,
          }));

        if (childLeaves.length > 0) {
          const getParentIcon = (key) => {
            switch (key) {
              case "audit":
                return parentIconAudit;
              case "fault":
                return parentIconFault;
              case "inventory":
                return parentIconInventory;
              case "performance":
                return parentIconPerformance;
              case "database":
                return parentIconDatabase;
              default:
                return <Folder fontSize="small" />;
            }
          };
          acc.push({
            label: groupData.title,
            icon: (
              <img
                src={getParentIcon(groupKey)}
                alt={groupData.title}
                style={{ width: "20px", height: "20px", objectFit: "contain" }}
              />
            ),
            children: childLeaves,
          });
        }

        return acc;
      },
      []
    );
  }, [isReportsCategory, activeParent, deployedType]);

  useEffect(() => {
    if (isReportsCategory && reportsTreeStructure.length > 0 && !activeChild) {
      const firstGroup = reportsTreeStructure[0];
      if (firstGroup.children && firstGroup.children.length > 0) {
        setActiveChild(firstGroup.children[0].key);
      }
    }
  }, [isReportsCategory, reportsTreeStructure]);

  const suggestions = useMemo(() => {
    if (!searchQuery.trim()) return parentPrivileges;
    const lower = searchQuery.toLowerCase();
    return filteredPrivileges.filter(
      (item) =>
        item.privilegeName.toLowerCase().includes(lower) ||
        item.key.toLowerCase().includes(lower)
    );
  }, [searchQuery, filteredPrivileges, parentPrivileges]);

  const handleSelectFromSearch = (item) => {
    if (item.parent === 0) {
      setActiveParent(item.id);
      setActiveChild(null);
    } else {
      setActiveParent(item.parent);
      setActiveChild(item.id);
    }
    setSearchQuery("");
    setSearchAnchor(null);
  };

  const toggleParent = (parentId) => {
    if (activeParent === parentId) {
      setActiveParent(null);
      setActiveChild(null);
      setSubDrawerData(null);
    } else {
      setActiveParent(parentId);
      setActiveChild(null);
    }
  };

  const activeChildKey = useMemo(() => {
    const targetId = activeChild || getChildren(activeParent)[0]?.id;
    return filteredPrivileges.find((i) => i.id === targetId)?.key;
  }, [activeChild, activeParent, filteredPrivileges]);

  const handleTabClick = (childId, e) => {
    setActiveChild(childId);
    setSubDrawerData(null);

    const element = e.currentTarget;
    element.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "start",
    });

    // REMOVED setTimeout. The onScroll event will trigger
    // as the element slides into view.
  };

  return (
    <ScrollContainer className="h-full">
      <div className="flex h-full relative  bg-white">
        {/* ==================== ACTION RAIL (WITH HOVER TO EXPAND) ==================== */}
        <div
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className={`flex flex-col items-center p-4 gap-y-2.5 mt-2 h-full bg-white z-10 transition-all duration-300 ease-in-out border-r border-gray-100 ${
            isHovered ? "w-56" : "w-20"
          }`}
        >
          {/* Search Layout Button Area */}
          <Tooltip title={!isHovered ? "Search" : ""} placement="left" arrow>
            <button
              onClick={(e) => setSearchAnchor(e.currentTarget)}
              className="flex items-center justify-start gap-3 p-3 w-full rounded-xl transition-all border border-gray-300 text-blue-900 hover:bg-gray-200 overflow-hidden"
            >
              <div className="flex-shrink-0 flex items-center justify-center">
                <Search size={18} />
              </div>
              <span
                className={`text-xs font-semibold tracking-wide text-blue-900 transition-all duration-200 whitespace-nowrap ${
                  isHovered
                    ? "opacity-100 translate-x-0"
                    : "opacity-0 -translate-x-4 hidden"
                }`}
              >
                Search Options
              </span>
            </button>
          </Tooltip>

          <Popover
            open={Boolean(searchAnchor)}
            anchorEl={searchAnchor}
            onClose={() => {
              setSearchAnchor(null);
              setSearchQuery("");
            }}
            disableRestoreFocus
            disableEnforceFocus
            anchorOrigin={{ vertical: "center", horizontal: "left" }}
            transformOrigin={{ vertical: "center", horizontal: "right" }}
            sx={{ mt: "8%", mr: 5 }}
          >
            <div className="w-72 p-2">
              <Box
                className="flex items-center rounded-md p-3 mb-2 "
                sx={{
                  border: "2px solid #eee",
                  borderRadius: "15px",
                  backgroundColor: "#F5F8FF",
                }}
              >
                <Search size={18} className="text-gray-500 " />
                <input
                  type="text"
                  ref={inputRef}
                  value={searchQuery}
                  autoFocus
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search privilege..."
                  className="ml-2 w-full outline-none text-sm placeholder-gray-400  "
                />
              </Box>
              <div className=" min-h-[230px] max-h-64">
                {suggestions.length > 0 ? (
                  suggestions.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleSelectFromSearch(item)}
                      className="flex w-full justify-start items-center gap-2 px-2 py-1 text-sm cursor-pointer hover:bg-[#D5E0FF] hover:text-black rounded"
                    >
                      <span className="truncate">{item.privilegeName}</span>
                    </button>
                  ))
                ) : (
                  // 3. Show a "No results" message so the box doesn't look empty
                  <div className="text-sm text-gray-400 p-2 text-center">
                    No results found
                  </div>
                )}
              </div>
            </div>
          </Popover>

          {/* Action Privileges Mapping List Area */}
          {parentPrivileges.map((item) => (
            <Tooltip
              title={!isHovered ? item.privilegeName : ""}
              placement="left"
              key={item.id}
              arrow
            >
              <button
                onClick={() => toggleParent(item.id)}
                className={`flex items-center justify-start gap-3 p-2.5 w-full rounded-xl transition-all border border-gray-300 overflow-hidden ${
                  activeParent === item.id
                    ? "bg-gray-600 text-white shadow-lg border-gray-600"
                    : "hover:bg-gray-200 text-gray-700"
                }`}
              >
                <div className="flex-shrink-0 flex items-center justify-center">
                  <img
                    src={getIconForKey(item.key)}
                    alt=""
                    className="w-6 h-6 object-contain"
                  />
                </div>
                <span
                  className={`text-xs font-semibold tracking-wide transition-all duration-200 whitespace-nowrap truncate ${
                    isHovered
                      ? "opacity-100 translate-x-0"
                      : "opacity-0 -translate-x-4 hidden"
                  } ${
                    activeParent === item.id ? "text-white" : "text-gray-700"
                  }`}
                >
                  {item.privilegeName}
                </span>
              </button>
            </Tooltip>
          ))}
        </div>

        {/* PRIMARY DRAWER */}
        <Drawer
          anchor="right"
          open={!!activeParent}
          onClose={() => {
            setActiveParent(null);
            // RESET STATES HERE
            setIsFullScreen(false);
            setDrawerWidth("45%"); // or whatever your default width is
          }}
          variant="temporary"
          PaperProps={{
            sx: { width: drawerWidth, borderTopLeftRadius: "40px" },
          }}
        >
          <Box className="flex flex-col h-full p-4 ">
            <div className="flex justify-between items-center mb-4">
              <Typography variant="h6" className="font-bold text-blue-900">
                {
                  parentPrivileges.find((p) => p.id === activeParent)
                    ?.privilegeName
                }
              </Typography>
              <Box className="flex gap-2">
                <Tooltip
                  title={
                    isFullScreen ? "Exit Full Screen" : "Enter Full Screen"
                  }
                  // 1. This moves the tooltip out of the "Full Screen" div and attaches it to the HTML Body
                  disablePortal={false}
                  // 2. This forces the tooltip to the absolute front of the entire browser window
                  PopperProps={{
                    style: { zIndex: 99999, position: "fixed" },
                  }}
                  // 3. This ensures it doesn't get stuck if the button moves
                  placement="top"
                >
                  <IconButton
                    onClick={() => {
                      setIsFullScreen(!isFullScreen);
                      setDrawerWidth(!isFullScreen ? "100%" : "45%");
                    }}
                  >
                    {isFullScreen ? (
                      <FullscreenExit size={20} />
                    ) : (
                      <FullscreenIcon size={20} />
                    )}
                  </IconButton>
                </Tooltip>

                <Tooltip title="Close">
                  <span className="inline-block">
                    <SquareIconButton
                      onClick={() => {
                        setActiveParent(null);
                        setIsFullScreen(false); // Reset here as well for safety
                        setDrawerWidth("45%");
                      }}
                      sx={{ color: "#027FDA" }}
                    >
                      <CloseIcon />
                    </SquareIconButton>
                  </span>
                </Tooltip>
              </Box>
            </div>
            <hr className="border-t border-gray-200 -ml-4 mb-4 -mr-3" />

            {isReportsCategory ? (
              <Box
                sx={{ display: "flex", flex: 1, overflow: "hidden", gap: 2 }}
              >
                <Box
                  sx={{
                    width: "255px",
                    borderRight: "1px solid #eee",
                    overflowY: "auto",
                    pr: 1,
                  }}
                >
                  <ReportTreeMenu
                    treeData={reportsTreeStructure}
                    selectedKey={activeChild}
                    onSelect={(selectedKey) => {
                      setActiveChild(selectedKey);
                      setSubDrawerData(null);
                    }}
                  />
                </Box>

                <Box className="flex-1 ">
                  {(() => {
                    if (!activeChild)
                      return (
                        <Typography
                          variant="body2"
                          className="p-4 text-gray-400 text-center"
                        >
                          Select a sub-report option from the nested list.
                        </Typography>
                      );
                    const Component = FileList[activeChild];
                    const flatReportsList = reportsTreeStructure.flatMap(
                      (group) => group.children || []
                    );
                    const selectedReportLeaf = flatReportsList.find(
                      (child) => child.key === activeChild
                    );

                    if (Component) {
                      return (
                        <Component
                          privilegeKey={activeChild}
                          refreshTrigger={triggerRefresh}
                          activeTab={selectedReportLeaf?.activeTabConfig}
                        />
                      );
                    }
                    return (
                      <Typography
                        variant="body2"
                        className="p-4 text-red-400 text-center"
                      >
                        Module layout mapping component error for key:{" "}
                        {activeChild}
                      </Typography>
                    );
                  })()}
                </Box>
              </Box>
            ) : (
              <>
                {/* <div className="flex items-center mb-4">
                <IconButton
                  sx={{ background: "#E9EFFF", color: "#14348D" }}
                  size="small"
                  onClick={() => handleScroll("left")}
                >
                  <ChevronLeft />
                </IconButton>

                <div
                  ref={scrollRef}
                  className="flex overflow-x-auto no-scrollbar scroll-smooth gap-2 bg-[#E9EFFF] p-3 rounded-full flex-1 mx-2"
                >
                  {getChildren(activeParent).map((child) => (
                    <button
                      key={child.id}
                      onClick={(e) => handleTabClick(child.id, e)}
                      className={`px-5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all duration-300 ${
                        activeChild === child.id || (!activeChild && getChildren(activeParent)[0]?.id === child.id)
                        ? "bg-[#14348D] text-white"
                        : "text-[#14348D] hover:bg-blue-200"
                        }`}
                    >
                      {child.privilegeName}
                    </button>
                  ))}
                </div>

                <IconButton
                  sx={{ background: "#E9EFFF", color: "#14348D" }}
                  size="small"
                  onClick={() => handleScroll("right")}
                >
                  <ChevronRight />
                </IconButton>
              </div> */}
                <div className="flex items-center mb-4">
                  <IconButton
                    sx={{
                      background: canScrollLeft ? "#E9EFFF" : "#F3F4F6",
                      color: canScrollLeft ? "#14348D" : "#9CA3AF",
                    }}
                    size="small"
                    onClick={() => handleScroll("left")}
                    disabled={!canScrollLeft}
                    className={`transition-all duration-200 ${
                      !canScrollLeft ? "opacity-50 cursor-not-allowed" : ""
                    }`}
                  >
                    <ChevronLeft />
                  </IconButton>

                  <div
                    ref={scrollRef}
                    onScroll={updateScrollButtons}
                    className="flex overflow-x-auto no-scrollbar scroll-smooth gap-2 bg-[#E9EFFF] p-3 rounded-full flex-1 mx-2"
                  >
                    {getChildren(activeParent).map((child) => (
                      <button
                        key={child.id}
                        onClick={(e) => handleTabClick(child.id, e)}
                        // CHANGE 1 (Part B): Added 'uppercase' class to ensure child tabs display in capital letters
                        className={`px-5 py-1.5 rounded-full text-xs font-medium uppercase whitespace-nowrap transition-all duration-300 ${
                          activeChild === child.id ||
                          (!activeChild &&
                            getChildren(activeParent)[0]?.id === child.id)
                            ? "bg-[#14348D] text-white"
                            : "text-[#14348D] hover:bg-blue-200"
                        }`}
                      >
                        {child.privilegeName}
                      </button>
                    ))}
                  </div>

                  <IconButton
                    sx={{
                      background: canScrollRight ? "#E9EFFF" : "#F3F4F6",
                      color: canScrollRight ? "#14348D" : "#9CA3AF",
                    }}
                    size="small"
                    onClick={() => handleScroll("right")}
                    disabled={!canScrollRight}
                    className={`transition-all duration-200 ${
                      !canScrollRight ? "opacity-50 cursor-not-allowed" : ""
                    }`}
                  >
                    <ChevronRight />
                  </IconButton>
                </div>

                <div className="flex-1 ">
                  {activeParent &&
                    (() => {
                      const Component = FileList[activeChildKey];
                      if (Component) {
                        return (
                          <Component
                            privilegeKey={activeChildKey}
                            refreshTrigger={triggerRefresh}
                            handleAdd={(data) =>
                              setSubDrawerData({ ...data, mode: "CREATE" })
                            }
                            handleEdit={(row) =>
                              setSubDrawerData({ ...row, mode: "EDIT" })
                            }
                            handleView={(row) =>
                              setSubDrawerData({ ...row, mode: "VIEW" })
                            }
                            handleHistory={(row) =>
                              setSubDrawerData({ ...row, mode: "HISTORY" })
                            }
                            handleCloseAction={(row) =>
                              setSubDrawerData({ ...row, mode: "CLOSE" })
                            }
                            handleReopenAction={(data) =>
                              setSubDrawerData({ ...data, mode: "REOPEN" })
                            }
                          />
                        );
                      }
                      return null;
                    })()}
                </div>
              </>
            )}
          </Box>

          {/* SUB DRAWER CONTAINMENT */}
          <Drawer
            anchor="right"
            open={!!subDrawerData}
            onClose={() => setSubDrawerData(null)}
            hideBackdrop={false}
            PaperProps={{
              sx: {
                width: isFullScreen ? "35%" : "25%",
                height: "100%",
                borderTopLeftRadius: "40px",
                border: "1px solid #D5E0FF",
                zIndex: 1301,
              },
            }}
          >
            <Box className="flex flex-col h-full bg-white">
              <div className="p-3 ml-3 flex justify-between items-center">
                <Typography
                  variant="subtitle1"
                  className="font-bold text-[#14348D]"
                >
                  {subDrawerData?.title || subDrawerData?.mode}
                </Typography>
                <SquareIconButton
                  size="small"
                  onClick={() => setSubDrawerData(null)}
                >
                  <CloseIcon />
                </SquareIconButton>
              </div>
              <div style={{ border: "1px solid #eee" }}></div>
              <div className=" pr-2 p-4">
                {(() => {
                  const mode = subDrawerData?.mode;
                  const currentKey = activeChildKey || activeChild;
                  const TargetComponent = FORM_MAPPING[currentKey]?.[mode];

                  if (TargetComponent) {
                    return (
                      <TargetComponent
                        data={subDrawerData}
                        mode={mode}
                        onClose={() => setSubDrawerData(null)}
                        onSuccess={() => {
                          triggerRefresh();
                          setSubDrawerData(null);
                        }}
                      />
                    );
                  }

                  return (
                    <div className="space-y-4">
                      {Object.entries(subDrawerData || {}).map(
                        ([k, v]) =>
                          !["mode", "sno", "id", "title"].includes(k) && (
                            <div
                              key={k}
                              className="border-b border-gray-100 pb-2"
                            >
                              <Typography
                                variant="caption"
                                className="text-gray-400 font-bold uppercase block"
                              >
                                {k.replace(/([A-Z])/g, " $1")}
                              </Typography>
                              <Typography
                                variant="body2"
                                className="text-gray-800 font-medium"
                              >
                                {typeof v === "object"
                                  ? JSON.stringify(v)
                                  : String(v)}
                              </Typography>
                            </div>
                          )
                      )}
                    </div>
                  );
                })()}
              </div>
            </Box>
          </Drawer>
        </Drawer>
      </div>
    </ScrollContainer>
  );
};

export default RightUtilityDrawer;
