import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import { Box, Typography } from "@mui/material";
import moment from "moment";

const SERIES = [
  { key: "UP", name: "UP", color: "#2E7D32" },
  { key: "DOWN", name: "DOWN", color: "#D32F2F" },
  { key: "RNMS_DOWN", name: "RNMS DOWN", color: "#F3C106" },
  { key: "NON_OPS", name: "Maintenance NON-OPS", color: "#B8860B" },
  { key: "R_OPS", name: "Maintenance R-OPS", color: "#34B8B8" },
];

const SiteAvailabilityChart = ({ data = [] }) => {
  const chartData = useMemo(() => {
    const grouped = new Map();

    data.forEach((row) => {
      if (!row.dateTime) return;

      const timestamp = moment(row.dateTime);

      if (!timestamp.isValid()) return;

      const dateKey = timestamp.format("YYYY-MM-DD HH:mm:ss");

      if (!grouped.has(dateKey)) {
        grouped.set(dateKey, {
          dateTime: dateKey,
          timestamp: timestamp.valueOf(),
          UP: 0,
          DOWN: 0,
          RNMS_DOWN: 0,
          NON_OPS: 0,
          R_OPS: 0,
        });
      }

      const point = grouped.get(dateKey);
      const category = row.statusCategory;

      if (Object.prototype.hasOwnProperty.call(point, category)) {
        point[category] +=
          Number(row.durationHours) ||
          (Number(row.durationSeconds) || 0) / 3600;
      }
    });

    return Array.from(grouped.values())
      .sort((a, b) => a.timestamp - b.timestamp)
      .map((point) => ({
        ...point,
        timeLabel: moment(point.dateTime).format("DD MMM HH:mm"),
      }));
  }, [data]);

  const hasData = chartData.length > 0;

  return (
    <Box
      sx={{
        p: 2,
        borderRadius: 3,
        border: "1px solid",
        borderColor: "divider",
        bgcolor: "background.paper",
      }}
    >
      <Typography variant="body2" fontWeight={600} mb={0.5}>
        Site Availability Duration
      </Typography>

      {!hasData ? (
        <Box sx={{ py: 6, textAlign: "center" }}>
          <Typography color="text.secondary">
            No duration data available for the selected period.
          </Typography>
        </Box>
      ) : (
        <Box sx={{ width: "100%", height: 300 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top:20, right: 20, left: 10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />

              <XAxis
                dataKey="timeLabel"
                angle={-35}
                textAnchor="end"
                interval="preserveStartEnd"
                height={65}
                fontSize={10}
              />

              <YAxis
                type="number"
                domain={[0, "auto"]}
                label={{
                  value: "Duration (hours)",
                  angle: -90,
                  position: "middle",
                  offset: 5,
                }}
                fontSize={10}
              />

              <Tooltip
                labelFormatter={(label) => `Date/time: ${label}`}
                formatter={(value, name) => [
                  `${Number(value).toFixed(2)} hours`,
                  name,
                ]}
              />

              <Legend wrapperStyle={{ fontSize: '10px' }}/>

              {SERIES.map((series) => (
                <Bar
                  key={series.key}
                  dataKey={series.key}
                  name={series.name}
                  fill={series.color}
                  stackId="duration"
                  maxBarSize={45}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </Box>
      )}
    </Box>
  );
};

export default SiteAvailabilityChart;
