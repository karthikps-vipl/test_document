import React from "react";
import RealTimeSystemLevel from "./components/RealTimeSystemLevel";
import HistoricalSystemLevel from "./components/HistoricalSystem";
import HistoricalInterfaceLevel from "./components/HistoricalInterfaceLevel";
import RealTimeInterfaceLevel from "./components/RealTimeInterfaceLevel";
import DelayResponse from "./components/DelayResponse";
const MAX_RENDER_POINTS = 300;
const PerformanceRouter = ({ activeTab, fields }) => {
  console.log(activeTab, "gggggggggggg");

  switch (activeTab?.key) {
    case "HistoricalSystemLevel":
      return (
        <HistoricalSystemLevel
          activeTab={activeTab}
          fields={fields}
          MAX_RENDER_POINTS={MAX_RENDER_POINTS}
        />
      );
    case "HistoricalInterfaceLevel":
      return (
        <HistoricalInterfaceLevel
          activeTab={activeTab}
          fields={fields}
          MAX_RENDER_POINTS={MAX_RENDER_POINTS}
        />
      );
    case "RealTimeSystemLevel":
      return (
        <RealTimeSystemLevel
          activeTab={activeTab}
          fields={fields}
          MAX_RENDER_POINTS={MAX_RENDER_POINTS}
        />
      );
    case "RealTimeInterfaceLevel":
      return <RealTimeInterfaceLevel />;

    case "DelayAndResponse":
      return <DelayResponse />;

    default:
      return null;
  }
};

export default PerformanceRouter;
