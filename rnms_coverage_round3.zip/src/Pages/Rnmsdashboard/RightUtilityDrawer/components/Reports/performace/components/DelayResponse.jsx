import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Tooltip,
} from "@mui/material";

import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_DELAY_RESPONSE_DATA,
  FETCH_PERFORMANCE_MONITORING_DEVICES_LIST,
  STOP_DELAY_AND_RESPONSE,
} from "@/RestAPI/url/endpoint";

import Slider from "@/components/Reusable/Slider/Slider";
import { WINDOW_PERIOD_OPTIONS, } from "@/lib/utils";
import SearchIcon from "@mui/icons-material/Search";
import MSelect from "@/components/Reusable/Select/MSelect";
import CustomCard from "@/components/Reusable/Card/CustomCard";
import { CustomLineChart } from "@/components/Charts/CustomLineChart";
import { exportSingleChartWithTable } from "@/components/Reusable/Pdf/downloadPdf";
import PDF_ICON from "@/assets/svg/PDF_Icon(Doc).svg";
import { useDispatch, useSelector } from "react-redux";
import {
  clearDelayAndResponseChartData,
  initDelayAndResponseChart,
  setSubscribeToDelayAndResponsetSocket,
} from "@/store/features/Reports/PerformanceReports/delayAndResponseSlice";
import { normalizeDate } from "@/store/socket/socketTopicHandlers";

const DelayResponse = () => {
  const dispatch = useDispatch();
  const liveChartData = useSelector(
    (state) => state.delayAndResponseSlice.delayAndResponseChartData
  );

  console.log(liveChartData.length, "length");

  const [devices, setDevices] = useState([]);
  // const [intervalList] = useState(INTERVAL_OPTIONS);
  const [loading, setLoading] = useState(false);

  const [formState, setFormState] = useState({
    performanceDevice: "",
    deviceName: "",

    intervalValue: "30",
    intervalLabel: "30 Seconds",
    windowPeriodValue: "",
    windowPeriodLabel: "",
  });

  const [showResp, setShowResp] = useState(false);

  useEffect(() => {
    PerformanceAxios(FETCH_PERFORMANCE_MONITORING_DEVICES_LIST, "get")
      .then((res) => {
        const devices = res.data.map((item) => ({
          value: item.resourceId,
          label: item.resourceName,
          resourceTypeId: item.imResourceType?.resourceTypeId,
        }));

        setDevices(devices);
      })
      .catch(console.error);
  }, []);

  const handleChange = (field, selected) => {
    let updatedValue = selected;

    if (field === "performanceDevice") {
      setFormState((prev) => ({
        ...prev,
        ["performanceDevice"]: selected.value,
        ["deviceName"]: selected.label,
      }));
    } else if (field === "interval") {
      setFormState((prev) => ({
        ...prev,
        ["intervalValue"]: selected.value,
        ["intervalLabel"]: selected.label,
      }));
    } else if (field === "windowPeriod") {
      setFormState((prev) => ({
        ...prev,
        ["windowPeriodValue"]: selected.value,
        ["windowPeriodLabel"]: selected.label,
      }));
    } else {
      updatedValue = selected;
      setFormState((prev) => ({
        ...prev,
        [field]: updatedValue,
      }));
    }
  };

  const handleFormSubmit = async () => {
    setLoading(true);
    const payload = {
      resourceInfoBean: { resourceId: formState.performanceDevice },
      interval: formState.intervalValue.toString(),
    };

    try {
      const resp = await PerformanceAxios(
        FETCH_DELAY_RESPONSE_DATA,
        "post",
        payload
      );

      if (resp.status === 200 && resp.data) {
        const initialPayload = Array.isArray(resp.data)
          ? resp.data[0]
          : resp.data;

        // Dispatches the one-time selected window period along with your base seed API record
        dispatch(
          initDelayAndResponseChart({
            initialPoint: initialPayload
              ? {
                  date: normalizeDate(initialPayload.time),
                  data: parseFloat(initialPayload.delayResponseTime),
                }
              : null,
            windowMinutes: formState.windowPeriodValue,
          })
        );

        dispatch(
          setSubscribeToDelayAndResponsetSocket({
            subscribe: true,
            resourceId: formState.performanceDevice,
          })
        );

        setShowResp(true);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const formatXAxis = (tickItem) => {
    if (!tickItem) return "";

    // High performance split check without heavy generic try/catch parsing loops
    const parts = tickItem.split(", ");
    if (parts.length >= 3) {
      return parts[2]; // Directly returns the time substring part e.g. "9:29:06 AM"
    }
    return tickItem;
  };

  const formatYAxis = (value) => {
    return `${parseFloat(value).toFixed(1)}`;
  };

  const chartConfig = [
    {
      dataKey: "data",
      label: "Data",
      color: "#FF93AA",
      dot: true,
      strokeWidth: 2,
    },
  ];

  const handleChartClose = async () => {
    try {
      const resp = await PerformanceAxios(
        STOP_DELAY_AND_RESPONSE + `/${formState.performanceDevice}`,
        "get"
      );

      if (resp.status === 200) {
        dispatch(clearDelayAndResponseChartData());
        dispatch(setSubscribeToDelayAndResponsetSocket(false));
        setShowResp(false);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = () => {
    return (
      formState.performanceDevice !== "" &&
      formState.intervalValue !== "" &&
      formState.windowPeriodValue !== ""
    );
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 2,
        // FIX: Force this component to span across all grid tracks of the parent
        gridColumn: "1 / -1",
        width: "100%",
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(245px, 1fr))",
          gap: "15px",
        }}
      >
        <MSelect
          label="Device Name *"
          options={devices}
          onChange={(val) => handleChange("performanceDevice", val)}
          value={formState["performanceDevice"]}
          placeholder="Device name"
        />

        {/* <MSelect
          label="Interval *"
          options={intervalList}
          value={formState["intervalValue"]}
          onChange={(val) => handleChange("interval", val)}
          placeholder="Interval"
        /> */}

        <MSelect
          label="Interval (Seconds)"
          options={[{ value: "30", label: "30 Seconds" }]}
          value="30"
          disabled
        />

        <MSelect
          label="Window period *"
          options={WINDOW_PERIOD_OPTIONS}
          value={formState["windowPeriodValue"]}
          onChange={(val) => handleChange("windowPeriod", val)}
          placeholder="Window period"
        />
      </Box>

      <Box display="flex" justifyContent="center" mt={3}>
        <Button
          variant="contained"
          disabled={!isFormValid() || loading}
          onClick={handleFormSubmit}
          startIcon={
            loading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              <SearchIcon />
            )
          }
          sx={{
            bgcolor: "#14348D",
            borderRadius: "8px",
            height: "38px",
            px: 4,
            "&:hover": { bgcolor: "#0f276b" },
          }}
        >
          {loading ? "Fetching..." : "View Report"}
        </Button>
      </Box>

      <Slider
        open={showResp}
        onClose={() => handleChartClose()}
        direction={"top"}
      >
        <Box sx={{ padding: "20px" }}>
          <Box sx={{ textAlign: "center", color: "#14348D" }}>
            DELAY AND RESPONSE - {formState.deviceName}
          </Box>
          <CustomCard style={{ marginTop: "20px", padding: "10px" }}>
            <Box className="chart-top-content-container">
              <Box sx={{ flex: 1 }} />

              <Box
                sx={{ flex: 1, display: "flex", justifyContent: "flex-end" }}
              >
                <Tooltip title="Download report" arrow>
                  <IconButton
                    onClick={() =>
                      exportSingleChartWithTable(
                        `DELAY AND RESPONSE - ${formState.deviceName}`,
                        [
                          { header: "Date Timestamp", dataKey: "date" },
                          {
                            header: `Response Value (milliSeconds)`,
                            dataKey: "data",
                          },
                        ],
                        liveChartData,
                        "delay-reponse-chart-cont",
                        `${formState.deviceName}_Delay_Response_Report`
                      )
                    }
                    sx={{
                      cursor: "pointer",
                      background: "#fff",
                      border: "1.5px solid #D1D5DB",
                      padding: "4px",
                      borderRadius: "4px",
                    }}
                  >
                    <img
                      src={PDF_ICON}
                      alt="Download"
                      style={{
                        width: "20px",
                        height: "20px",
                      }}
                    />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
            <Box
              id="delay-reponse-chart-cont"
              sx={{ bgcolor: "#FFFFFF", p: 1 }}
            >
              <CustomLineChart
                data={liveChartData}
                xAxisKey="date"
                lines={chartConfig}
                xAxisFormatter={formatXAxis}
                yAxisFormatter={formatYAxis}
                height={350}
                xAxisLabel="Time"
                yAxisLabel={`Values in milli-Sec`}
              />
            </Box>
          </CustomCard>
        </Box>
      </Slider>
    </Box>
  );
};

export default DelayResponse;
