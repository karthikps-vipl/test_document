import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Tooltip,
} from "@mui/material";

import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_PERFORMANCE_MONITORING_DEVICES_LIST,
  FETCH_PERF_PARAM_OF_RESOURCE_TYPE,
  FETCH_REAL_TIME_PERFORMANCE_DATA,
  STOP_REAL_TIME_PERFORMANCE_DATA,
} from "@/RestAPI/url/endpoint";

import Slider from "@/components/Reusable/Slider/Slider";
import { WINDOW_PERIOD_OPTIONS } from "@/lib/utils";
import SearchIcon from "@mui/icons-material/Search";
import MSelect from "@/components/Reusable/Select/MSelect";
import CustomCard from "@/components/Reusable/Card/CustomCard";
import { CustomLineChart } from "@/components/Charts/CustomLineChart";
import { exportSingleChartWithTable } from "@/components/Reusable/Pdf/downloadPdf";
import PDF_ICON from "@/assets/svg/PDF_Icon(Doc).svg";
import { useDispatch, useSelector } from "react-redux";
import {
  clearRealtimeChartData,
  initRealTimeChart,
  setSubscribeToRealtimeReportSocket,
} from "@/store/features/Reports/PerformanceReports/realTimeSystemSlice";

const HistoricalSystemLevel = () => {
  const dispatch = useDispatch();
  const liveChartData = useSelector(
    (state) => state.realTimeSystemSlice.realtimeChartData
  );

  console.log(liveChartData.length, "length");

  const [devices, setDevices] = useState([]);
  const [params, setParams] = useState([]);
  // const [intervalList] = useState(INTERVAL_OPTIONS);
  const [loading, setLoading] = useState(false);

  const [formState, setFormState] = useState({
    performanceDevice: "",
    deviceName: "",
    parameterName: "",
    performanceParameter: "",
    perfUnit: "",
    intervalValue: "30",
    intervalLabel: "30 Seconds",
    windowPeriodValue: "",
    windowPeriodLabel: "",
  });

  const [showResp, setShowResp] = useState(false);

  useEffect(() => {
    PerformanceAxios(FETCH_PERFORMANCE_MONITORING_DEVICES_LIST, "get")
      .then((res) => {
        const devices = res.data.map((item) => ({
          value: item.resourceId,
          label: item.resourceName,
          resourceTypeId: item.imResourceType?.resourceTypeId,
        }));

        setDevices(devices);
      })
      .catch(console.error);
  }, []);

  const fetchParams = (resourceTypeId) => {
    PerformanceAxios(
      `${FETCH_PERF_PARAM_OF_RESOURCE_TYPE}/${resourceTypeId}`,
      "get"
    )
      .then((res) => {
        const params = res.data.map((item) => ({
          label: item.paramName,
          value: item.paramId,
          perfUnit: item.perfUnit,
        }));
        setParams(params);
      })
      .catch(console.error);
  };

  const handleChange = (field, selected) => {
    let updatedValue = selected;

    if (field === "performanceDevice") {
      setFormState((prev) => ({
        ...prev,
        ["performanceDevice"]: selected.value,
        ["deviceName"]: selected.label,
      }));
      fetchParams(selected.resourceTypeId);
    } else if (field === "performanceParameter") {
      setFormState((prev) => ({
        ...prev,
        ["performanceParameter"]: selected.value,
        ["parameterName"]: selected.label,
        ["perfUnit"]: selected.perfUnit,
      }));
    } else if (field === "interval") {
      setFormState((prev) => ({
        ...prev,
        ["intervalValue"]: selected.value,
        ["intervalLabel"]: selected.label,
      }));
    } else if (field === "windowPeriod") {
      setFormState((prev) => ({
        ...prev,
        ["windowPeriodValue"]: selected.value,
        ["windowPeriodLabel"]: selected.label,
      }));
    } else {
      // For fromDate and toDate, 'selected' is already the ISO string (or null)
      updatedValue = selected;
      setFormState((prev) => ({
        ...prev,
        [field]: updatedValue,
      }));
    }
  };

  const handleFormSubmit = async () => {
    setLoading(true);
    const payload = {
      resourceInfoBean: { resourceId: formState.performanceDevice },
      perfParamInfoBean: { paramId: formState.performanceParameter },
      interval: formState.intervalValue.toString(),
    };

    try {
      const resp = await PerformanceAxios(
        FETCH_REAL_TIME_PERFORMANCE_DATA,
        "post",
        payload
      );

      if (resp.status === 200 && resp.data) {
        const initialPayload = Array.isArray(resp.data)
          ? resp.data[0]
          : resp.data;

        // Dispatches the one-time selected window period along with your base seed API record
        dispatch(
          initRealTimeChart({
            initialPoint: initialPayload
              ? {
                  date: initialPayload.date,
                  data: parseFloat(initialPayload.data),
                }
              : null,
            windowMinutes: formState.windowPeriodValue,
          })
        );

        dispatch(
          setSubscribeToRealtimeReportSocket({
            subscribe: true,
            resourceId: formState.performanceDevice,
            paramId: formState.performanceParameter,
          })
        );

        setShowResp(true);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const stats = useMemo(() => {
    if (
      !liveChartData ||
      !Array.isArray(liveChartData) ||
      liveChartData.length === 0
    ) {
      return { min: "N/A", max: "N/A", avg: "N/A" };
    }

    // Filter out any invalid items and ensure values are strictly treated as numbers
    const numericValues = liveChartData
      .map((item) => parseFloat(item.data))
      .filter((val) => !isNaN(val));

    if (numericValues.length === 0) {
      return { min: "N/A", max: "N/A", avg: "N/A" };
    }

    const min = Math.min(...numericValues);
    const max = Math.max(...numericValues);
    const sum = numericValues.reduce((acc, curr) => acc + curr, 0);
    const avg = sum / numericValues.length;

    return {
      min: min.toFixed(2),
      max: max.toFixed(2),
      avg: avg.toFixed(2),
    };
  }, [liveChartData]);

  const formatXAxis = (tickItem) => {
    if (!tickItem) return "";

    // High performance split check without heavy generic try/catch parsing loops
    const parts = tickItem.split(", ");
    if (parts.length >= 3) {
      return parts[2]; // Directly returns the time substring part e.g. "9:29:06 AM"
    }
    return tickItem;
  };

  const formatYAxis = (value) => {
    return `${parseFloat(value).toFixed(1)}`;
  };

  const chartConfig = [
    {
      dataKey: "data",
      label: "Data",
      color: "#FF93AA",
      dot: true,
      strokeWidth: 2,
    },
  ];

  const unitLabel = formState?.perfUnit || "Units";

  const handleChartClose = async () => {
    const payload = {
      resourceInfoBean: { resourceId: formState.performanceDevice },
      perfParamInfoBean: { paramId: formState.performanceParameter },
      interval: formState.intervalValue.toString(),
    };

    try {
      const resp = await PerformanceAxios(
        STOP_REAL_TIME_PERFORMANCE_DATA,
        "post",
        payload
      );

      if (resp.status === 200) {
        dispatch(clearRealtimeChartData());
        dispatch(setSubscribeToRealtimeReportSocket(false));
        setShowResp(false);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = () => {
    return (
      formState.performanceDevice !== "" &&
      formState.performanceParameter !== "" &&
      formState.intervalValue !== "" &&
      formState.windowPeriodValue !== ""
    );
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 2,
        // FIX: Force this component to span across all grid tracks of the parent
        gridColumn: "1 / -1",
        width: "100%",
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(245px, 1fr))",
          gap: "15px",
        }}
      >
        <MSelect
          label="Device Name *"
          options={devices}
          onChange={(val) => handleChange("performanceDevice", val)}
          value={formState["performanceDevice"]}
          placeholder="Device name"
        />

        <MSelect
          label="Performance Parameter *"
          options={params}
          value={formState["performanceParameter"]}
          onChange={(val) => handleChange("performanceParameter", val)}
          placeholder="Performance Parameter"
        />

        {/* <MSelect
          label="Interval *"
          options={intervalList}
          value={formState["intervalValue"]}
          onChange={(val) => handleChange("interval", val)}
          placeholder="Interval"
        /> */}
        <Box>
          <MSelect
            label="Interval (Seconds)"
            options={[{ value: "30", label: "30 Seconds" }]}
            value="30"
            disabled
          />
        </Box>

        <MSelect
          label="Window period *"
          options={WINDOW_PERIOD_OPTIONS}
          value={formState["windowPeriodValue"]}
          onChange={(val) => handleChange("windowPeriod", val)}
          placeholder="Window period"
        />
      </Box>

      <Box display="flex" justifyContent="center" mt={3}>
        <Button
          variant="contained"
          disabled={!isFormValid() || loading}
          onClick={handleFormSubmit}
          startIcon={
            loading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              <SearchIcon />
            )
          }
          sx={{
            bgcolor: "#14348D",
            borderRadius: "8px",
            height: "38px",
            px: 4,
            "&:hover": { bgcolor: "#0f276b" },
          }}
        >
          {loading ? "Fetching..." : "View Report"}
        </Button>
      </Box>

      <Slider
        open={showResp}
        onClose={() => handleChartClose()}
        direction={"top"}
      >
        <Box sx={{ padding: "20px" }}>
          <Box sx={{ textAlign: "center", color: "#14348D" }}>
            REAL TIME SYSTEM LEVEL - {formState.deviceName}
          </Box>
          <CustomCard style={{ marginTop: "20px", padding: "10px" }}>
            <Box className="chart-top-content-container">
              <Box
                sx={{ flex: 1, display: "flex", justifyContent: "flex-end" }}
              >
                <Tooltip title="Download report" arrow>
                  <IconButton
                    onClick={() =>
                      exportSingleChartWithTable(
                        `REAL TIME SYSTEM LEVEL - ${formState.deviceName}`,
                        [
                          { header: "Date Timestamp", dataKey: "date" },
                          { header: `Value (${unitLabel})`, dataKey: "data" },
                        ],
                        liveChartData,
                        "realtime-chart-cont",
                        `${formState.deviceName}_Realtime_System_Report`
                      )
                    }
                    sx={{
                      cursor: "pointer",
                      background: "#fff",
                      border: "1.5px solid #D1D5DB",
                      padding: "4px",
                      borderRadius: "4px",
                    }}
                  >
                    <img
                      src={PDF_ICON}
                      alt="Download"
                      style={{
                        width: "25px",
                        height: "25px",
                        objectFit: "contain",
                      }}
                    />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
            <Box id="realtime-chart-cont" sx={{ bgcolor: "#FFFFFF", p: 1 }}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 2,
                  flexWrap: "wrap",
                  mb: 1,
                  fontSize: "15px",
                  color: "#333",
                }}
              >
                <Box>
                  <strong>Device:</strong> {formState.deviceName || "N/A"}
                </Box>

                <Box>
                  <strong>Parameter:</strong> {formState.parameterName || "N/A"}
                </Box>

              </Box>
              <CustomLineChart
                data={liveChartData}
                xAxisKey="date"
                lines={chartConfig}
                xAxisFormatter={formatXAxis}
                yAxisFormatter={formatYAxis}
                height={350}
                xAxisLabel="Date Time"
                yAxisLabel={`Values in ${unitLabel}`}
              />
              
              <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: 2,
                    flexWrap: "wrap",
                    mb: 1.5,
                    fontSize: "15px",
                    color: "#333",
                  }}
                >
                  <Box>
                    <strong>Minimum:</strong> {stats.min}
                  </Box>

                  <Box>
                    <strong>Average:</strong> {stats.avg}
                  </Box>

                  <Box>
                    <strong>Maximum:</strong> {stats.max}
                  </Box>
                </Box>
            </Box>
          </CustomCard>
        </Box>
      </Slider>
    </Box>
  );
};

export default HistoricalSystemLevel;
