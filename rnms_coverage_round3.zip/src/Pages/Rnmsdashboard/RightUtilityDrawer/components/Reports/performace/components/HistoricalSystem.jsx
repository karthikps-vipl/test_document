import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Tooltip,
} from "@mui/material";

import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_HISTORICAL_PERFORMANCE_DATA,
  FETCH_PERFORMANCE_MONITORING_DEVICES_LIST,
  FETCH_PERF_PARAM_OF_RESOURCE_TYPE,
} from "@/RestAPI/url/endpoint";

import Slider from "@/components/Reusable/Slider/Slider";
import SearchIcon from "@mui/icons-material/Search";
import MSelect from "@/components/Reusable/Select/MSelect";
import DateRangePicker from "../../DateRangePicker";
import CustomCard from "@/components/Reusable/Card/CustomCard";
import { CustomLineChart } from "@/components/Charts/CustomLineChart";
import { exportSingleChartWithTable } from "@/components/Reusable/Pdf/downloadPdf";
import PDF_ICON from "@/assets/svg/PDF_Icon(Doc).svg";
import Toast from "@/components/Reusable/Toast/Toast";

const HistoricalSystemLevel = ({ MAX_RENDER_POINTS }) => {
  const [devices, setDevices] = useState([]);
  const [params, setParams] = useState([]);
  const [loading, setLoading] = useState(false);
  const [chartData, setChartData] = useState(null);

  const [formState, setFormState] = useState({
    performanceDevice: "",
    deviceName: "",
    parameterName: "",
    performanceParameter: "",
    fromDate: null,
    toDate: null,
  });

  const [showResp, setShowResp] = useState(false);

  useEffect(() => {
    PerformanceAxios(FETCH_PERFORMANCE_MONITORING_DEVICES_LIST, "get")
      .then((res) => {
        const devices = res.data.map((item) => ({
          value: item.resourceId,
          label: item.resourceName,
          resourceTypeId: item.imResourceType?.resourceTypeId,
        }));

        setDevices(devices);
      })
      .catch(console.error);
  }, []);

  const fetchParams = (resourceTypeId) => {
    PerformanceAxios(
      `${FETCH_PERF_PARAM_OF_RESOURCE_TYPE}/${resourceTypeId}`,
      "get"
    )
      .then((res) => {
        const params = res.data.map((item) => ({
          label: item.paramName,
          value: item.paramId,
        }));
        setParams(params);
      })
      .catch(console.error);
  };

  const handleChange = (field, selected) => {
    let updatedValue = selected;

    if (field === "performanceDevice") {
      setFormState((prev) => ({
        ...prev,
        ["performanceDevice"]: selected.value,
        ["deviceName"]: selected.label,
      }));
      fetchParams(selected.resourceTypeId);
    } else if (field === "performanceParameter") {
      setFormState((prev) => ({
        ...prev,
        ["performanceParameter"]: selected.value,
        ["parameterName"]: selected.label,
      }));
    } else {
      updatedValue = selected;
      setFormState((prev) => ({
        ...prev,
        [field]: updatedValue,
      }));
    }
  };

  const handleFormSubmit = async () => {
    setLoading(true);
    const payload = {
      resourceInfoBean: { resourceId: formState.performanceDevice },
      perfParamInfoBean: { paramId: formState.performanceParameter },
      fromDate: formState.fromDate,
      toDate: formState.toDate,
    };

    try {
      const resp = await PerformanceAxios(
        FETCH_HISTORICAL_PERFORMANCE_DATA,
        "post",
        payload
      );

      if (resp.status === 200 && resp.data) {
        let data = resp.data;

        if (typeof data === "object" && !Array.isArray(data)) {
          setChartData([data]);
        } else {
          if (data.length == 0) {
            Toast("info", "No data found", "info");
            return;
          }
          setChartData(data);
        }
        Toast("Success", "Report loaded successfully", "success");
        setShowResp(true);
      }
    } catch (error) {
      console.error(error);
      Toast("Error", "Something Went Wrong", "error");
    } finally {
      setLoading(false);
    }
  };

  const formatXAxis = (tickItem) => {
    try {
      const timePart = tickItem.split(", ")[2];
      return timePart || tickItem;
    } catch (e) {
      console.error(e);
      return tickItem;
    }
  };

  const formatYAxis = (value) => {
    return `${parseFloat(value).toFixed(1)}`;
  };

  const chartConfig = [
    {
      dataKey: "data",
      label: "Data",
      color: "#FF93AA",
      dot: true,
      strokeWidth: 2,
    },
  ];

  const processedChartData = useMemo(() => {
    if (!chartData || !Array.isArray(chartData)) return [];

    const totalPoints = chartData.length;
    if (totalPoints <= MAX_RENDER_POINTS) return chartData;

    const stride = Math.ceil(totalPoints / MAX_RENDER_POINTS);
    const downsampled = [];

    for (let i = 0; i < totalPoints; i += stride) {
      downsampled.push(chartData[i]);
    }

    if (downsampled[downsampled.length - 1] !== chartData[totalPoints - 1]) {
      downsampled.push(chartData[totalPoints - 1]);
    }
    return downsampled;
  }, [chartData]);

  const stats = useMemo(() => {
    if (!chartData || !Array.isArray(chartData) || chartData.length === 0) {
      return { min: "N/A", max: "N/A", avg: "N/A" };
    }

    const numericValues = chartData
      .map((item) => parseFloat(item.data))
      .filter((val) => !isNaN(val));

    if (numericValues.length === 0) {
      return { min: "N/A", max: "N/A", avg: "N/A" };
    }

    const min = Math.min(...numericValues);
    const max = Math.max(...numericValues);
    const sum = numericValues.reduce((acc, curr) => acc + curr, 0);
    const avg = sum / numericValues.length;

    return {
      min: min.toFixed(2),
      max: max.toFixed(2),
      avg: avg.toFixed(2),
    };
  }, [chartData]);

  const unitLabel = chartData?.[0]?.perfParamInfoBean?.perfUnit || "Units";

  const isFormValid = () => {
    return (
      formState.performanceDevice !== "" &&
      formState.performanceParameter != "" &&
      formState.fromDate !== "" &&
      formState.toDate !== ""
    );
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 2,
        // FIX: Force this component to span across all grid tracks of the parent
        gridColumn: "1 / -1",
        width: "100%",
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(245px, 1fr))",
          gap: "15px",
        }}
      >
        <MSelect
          label="Device Name *"
          options={devices}
          onChange={(val) => handleChange("performanceDevice", val)}
          value={formState["performanceDevice"]}
          placeholder="Select device"
        />

        <MSelect
          label="Performance Parameter *"
          options={params}
          value={formState["performanceParameter"]}
          onChange={(val) => handleChange("performanceParameter", val)}
          placeholder="Select parameter"
        />

        <DateRangePicker
          fieldName="fromDate"
          label="From Date"
          value={formState.fromDate}
          onChange={(val) => handleChange("fromDate", val)}
          allFormValues={formState}
        />

        <DateRangePicker
          fieldName="toDate"
          label="To Date"
          value={formState.toDate}
          onChange={(val) => handleChange("toDate", val)}
          allFormValues={formState}
        />
      </Box>

      <Box display="flex" justifyContent="center" mt={3}>
        <Button
          variant="contained"
          disabled={!isFormValid() || loading}
          onClick={handleFormSubmit}
          startIcon={
            loading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              <SearchIcon />
            )
          }
          sx={{
            bgcolor: "#14348D",
            borderRadius: "8px",
            height: "38px",
            px: 4,
            "&:hover": { bgcolor: "#0f276b" },
          }}
        >
          {loading ? "Fetching..." : "View Report"}
        </Button>
      </Box>

      <Slider
        open={showResp}
        onClose={() => setShowResp(false)}
        direction={"top"}
      >
        <Box sx={{ padding: "20px" }}>
          <Box sx={{ textAlign: "center", color: "#14348D" }}>
            HISTORICAL SYSTEM - {formState.deviceName}
          </Box>
          <CustomCard style={{ marginTop: "20px", padding: "10px" }}>
            <Box className="chart-top-content-container">
              <Box sx={{ flex: 1 }} />

              {/* <Box className="graph-info">
                <Box>Device: {formState.deviceName},</Box>
                <Box>Parameter: {formState.parameterName}</Box>
              </Box> */}

              <Box
                sx={{ flex: 1, display: "flex", justifyContent: "flex-end" }}
              >
                <Tooltip title="Download report" arrow>
                  <IconButton
                    onClick={() =>
                      exportSingleChartWithTable(
                        `Historical Report - ${formState.deviceName}`,
                        [
                          { header: "Date Timestamp", dataKey: "date" },
                          { header: `Value (${unitLabel})`, dataKey: "data" },
                        ],
                        chartData,
                        "hist-chart-cont",
                        `${formState.deviceName}_Historical_Report`
                      )
                    }
                    sx={{
                      cursor: "pointer",
                      background: "#fff",
                      border: "1.5px solid #D1D5DB",
                      padding: "4px",
                      borderRadius: "4px",
                    }}
                  >
                    <img
                      src={PDF_ICON}
                      alt="Download"
                      style={{ width: "20px", height: "20px" }}
                    />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
            <Box id="hist-chart-cont" sx={{ bgcolor: "#FFFFFF", p: 1 }}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 2,
                  flexWrap: "wrap",
                  mb: 1,
                  fontSize: "15px",
                  color: "#333",
                }}
              >
                <Box>
                  <strong>Device:</strong> {formState.deviceName || "N/A"}
                </Box>

                <Box>
                  <strong>Parameter:</strong> {formState.parameterName || "N/A"}
                </Box>
              </Box>
              <CustomLineChart
                data={processedChartData}
                xAxisKey="date"
                lines={chartConfig}
                xAxisFormatter={formatXAxis}
                yAxisFormatter={formatYAxis}
                height={350}
                xAxisLabel="Date Time"
                yAxisLabel={`Values in ${unitLabel}`}
              />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 2,
                  flexWrap: "wrap",
                  mb: 1.5,
                  fontSize: "15px",
                  color: "#333",
                }}
              >
                <Box>
                  <strong>Minimum:</strong> {stats.min}
                </Box>

                <Box>
                  <strong>Average:</strong> {stats.avg}
                </Box>

                <Box>
                  <strong>Maximum:</strong> {stats.max}
                </Box>
              </Box>
            </Box>

            {/* <Box sx={{ textAlign: "center" }}>
              Minimum value:{stats.min}, Average value: {stats.avg}, Maximum
              value: {stats.max}
            </Box> */}
          </CustomCard>
        </Box>
      </Slider>
    </Box>
  );
};

export default HistoricalSystemLevel;
