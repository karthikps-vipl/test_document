import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Tooltip,
} from "@mui/material";

import { PerformanceAxios, TopologyAxios } from "@/RestAPI/api/axiosApicall";

import {
  FETCH_PERFORM_PARAM_FOR_INTERFACE_LEVEL,
  FETCH_PORT_INFO_DETAILS_BY_RESOURCE_ID,
  FETCH_REAL_TIME_INTERFACE_LEVEL_DATA,
  FETCH_RESOURCE_FOR_INTERFACE_LEVEL_REPORT,
  STOP_REAL_TIME_INTERFACE_PERFORMANCE_DATA,
} from "@/RestAPI/url/endpoint";

import Slider from "@/components/Reusable/Slider/Slider";
import { WINDOW_PERIOD_OPTIONS } from "@/lib/utils";
import SearchIcon from "@mui/icons-material/Search";
import MSelect from "@/components/Reusable/Select/MSelect";
import CustomCard from "@/components/Reusable/Card/CustomCard";
import { CustomLineChart } from "@/components/Charts/CustomLineChart";
import { exportSingleChartWithTable } from "@/components/Reusable/Pdf/downloadPdf";
import PDF_ICON from "@/assets/svg/PDF_Icon(Doc).svg";
import { useDispatch, useSelector } from "react-redux";
import {
  clearRealtimeInterfaceLevelChartData,
  initRealTimeInterfaceLevelChart,
  setSubscribeToRealtimeInterfaceLevelReportSocket,
} from "@/store/features/Reports/PerformanceReports/realTimeInterfaceLevelSlice";

const RealTimeInterfaceLevel = () => {
  const dispatch = useDispatch();
  const realtimeInterfaceLevelChartData = useSelector(
    (state) => state.realTimeInterfaceLevelSlice.realtimeInterfaceLevelChartData
  );

  const [devices, setDevices] = useState([]);
  const [params, setParams] = useState([]);
  const [loading, setLoading] = useState(false);
  const [portsList, setPortsList] = useState([]);
  // const [intervalList] = useState(INTERVAL_OPTIONS);

  const [formState, setFormState] = useState({
    performanceDevice: "",
    deviceName: "",
    parameterName: "",
    performanceParameter: "",
    perfUnit: "",
    portName: "",
    portId: "",
    intervalValue: "30",
    intervalLabel: "30 Seconds",
    windowPeriodValue: "",
    windowPeriodLabel: "",
  });

  const [showResp, setShowResp] = useState(false);

  useEffect(() => {
    PerformanceAxios(FETCH_RESOURCE_FOR_INTERFACE_LEVEL_REPORT, "get")
      .then((res) => {
        const devices = res.data.map((item) => ({
          value: item.resourceId,
          label: item.resourceName,
          resourceTypeId: item.imResourceType?.resourceTypeId,
        }));

        setDevices(devices);
      })
      .catch(console.error);

    PerformanceAxios(FETCH_PERFORM_PARAM_FOR_INTERFACE_LEVEL, "get")
      .then((res) => {
        const params = res.data.map((item) => ({
          label: item.paramName,
          value: item.paramId,
        }));
        setParams(params);
      })
      .catch(console.error);
  }, []);

  const fetchPorts = (resourceId) => {
    TopologyAxios(
      FETCH_PORT_INFO_DETAILS_BY_RESOURCE_ID + `/${resourceId}`
    ).then((res) => {
      const ports = res.data.map((item) => ({
        label: item.ifdesc,
        value: item.ifindex,
      }));
      setPortsList(ports);
    });
  };

  const handleChange = (field, selected) => {
    let updatedValue = selected;

    if (field === "performanceDevice") {
      setFormState((prev) => ({
        ...prev,
        ["performanceDevice"]: selected.value,
        ["deviceName"]: selected.label,
      }));
      fetchPorts(selected.value);
    } else if (field === "performanceParameter") {
      setFormState((prev) => ({
        ...prev,
        ["performanceParameter"]: selected.value,
        ["parameterName"]: selected.label,
        ["perfUnit"]: selected.perfUnit,
      }));
    } else if (field === "interval") {
      setFormState((prev) => ({
        ...prev,
        ["intervalValue"]: selected.value,
        ["intervalLabel"]: selected.label,
      }));
    } else if (field === "windowPeriod") {
      setFormState((prev) => ({
        ...prev,
        ["windowPeriodValue"]: selected.value,
        ["windowPeriodLabel"]: selected.label,
      }));
    } else if (field === "portId") {
      setFormState((prev) => ({
        ...prev,
        ["portId"]: selected.value,
        ["portName"]: selected.label,
      }));
    } else {
      // For fromDate and toDate, 'selected' is already the ISO string (or null)
      updatedValue = selected;
      setFormState((prev) => ({
        ...prev,
        [field]: updatedValue,
      }));
    }
  };

  const stats = useMemo(() => {
    if (
      !realtimeInterfaceLevelChartData ||
      !Array.isArray(realtimeInterfaceLevelChartData) ||
      realtimeInterfaceLevelChartData.length === 0
    ) {
      return { min: "N/A", max: "N/A", avg: "N/A" };
    }

    // Filter out any invalid items and ensure values are strictly treated as numbers
    const numericValues = realtimeInterfaceLevelChartData
      .map((item) => parseFloat(item.data))
      .filter((val) => !isNaN(val));

    if (numericValues.length === 0) {
      return { min: "N/A", max: "N/A", avg: "N/A" };
    }

    const min = Math.min(...numericValues);
    const max = Math.max(...numericValues);
    const sum = numericValues.reduce((acc, curr) => acc + curr, 0);
    const avg = sum / numericValues.length;

    return {
      min: min.toFixed(2),
      max: max.toFixed(2),
      avg: avg.toFixed(2),
    };
  }, [realtimeInterfaceLevelChartData]);

  const handleFormSubmit = async () => {
    setLoading(true);
    const payload = {
      ifIndex: formState.portId,
      interval: formState.intervalValue.toString(),
      resourceInfoBean: { resourceId: formState.performanceDevice },
      perfParamInfoBean: { paramId: formState.performanceParameter },
    };

    try {
      const resp = await PerformanceAxios(
        FETCH_REAL_TIME_INTERFACE_LEVEL_DATA,
        "post",
        payload
      );

      if (resp.status === 200 && resp.data) {
        const initialPayload = Array.isArray(resp.data)
          ? resp.data[0]
          : resp.data;

        // Dispatches the one-time selected window period along with your base seed API record
        dispatch(
          initRealTimeInterfaceLevelChart({
            initialPoint: initialPayload
              ? {
                  date: initialPayload.date,
                  data: parseFloat(initialPayload.data),
                }
              : null,
            windowMinutes: formState.windowPeriodValue,
          })
        );

        dispatch(
          setSubscribeToRealtimeInterfaceLevelReportSocket({
            subscribe: true,
            resourceId: formState.performanceDevice,
            paramId: formState.performanceParameter,
            portId: formState.portId,
          })
        );

        setShowResp(true);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const formatXAxis = (tickItem) => {
    try {
      const timePart = tickItem.split(", ")[2];
      return timePart || tickItem;
    } catch (e) {
      console.error(e);
      return tickItem;
    }
  };

  const formatYAxis = (value) => {
    return `${parseFloat(value).toFixed(1)}`;
  };

  const chartConfig = [
    {
      dataKey: "data",
      label: "Data",
      color: "#FF93AA",
      dot: true,
      strokeWidth: 2,
    },
  ];

  const isFormValid = () => {
    return (
      formState.performanceDevice !== "" &&
      formState.performanceParameter !== "" &&
      formState.portId !== "" &&
      // formState.intervalValue !== "" &&
      formState.windowPeriodValue !== ""
    );
  };

  const unitLabel = formState?.perfUnit || "Units";

  const handleChartClose = async () => {
    const payload = {
      resourceInfoBean: { resourceId: formState.performanceDevice },
      perfParamInfoBean: { paramId: formState.performanceParameter },
      interval: formState.intervalValue.toString(),
      ifIndex: formState.portId,
    };

    try {
      const resp = await PerformanceAxios(
        STOP_REAL_TIME_INTERFACE_PERFORMANCE_DATA,
        "post",
        payload
      );

      if (resp.status === 200) {
        dispatch(clearRealtimeInterfaceLevelChartData());
        dispatch(
          setSubscribeToRealtimeInterfaceLevelReportSocket({
            subscribe: true,
            resourceId: formState.performanceDevice,
            paramId: formState.parameterName,
            portId: formState.portId,
          })
        );
        setShowResp(false);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 2,
        gridColumn: "1 / -1",
        width: "100%",
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(245px, 1fr))",
          gap: "15px",
        }}
      >
        <Box>
          <MSelect
            label="Device Name *"
            options={devices}
            onChange={(val) => handleChange("performanceDevice", val)}
            value={formState["performanceDevice"]}
            placeholder="Select device"
          />
        </Box>
        <Box>
          <MSelect
            label="Performance Parameter *"
            options={params}
            value={formState["performanceParameter"]}
            onChange={(val) => handleChange("performanceParameter", val)}
            placeholder="Select parameter"
          />
        </Box>
        <Box>
          <MSelect
            label="Interface Level *"
            options={portsList}
            value={formState["portId"]}
            onChange={(val) => handleChange("portId", val)}
            placeholder="Select Interface"
          />
        </Box>

        {/* IF YOU WANT TO SEND CUSTOM INTERVAL LIST THEN UNCOMMENT THIS  */}
        {/* <Box>
          <MSelect
            label="Interval (Seconds)*"
            options={intervalList}
            value={formState["intervalValue"]}
            onChange={(val) => handleChange("interval", val)}
            placeholder="Interval"
          />
        </Box> */}

        {/* AND COMMENT THE BELOW ONE */}
        <Box disabled>
          <MSelect
            label="Interval (Seconds)*"
            options={[{ value: "30", label: "30 Seconds" }]}
            value="30"
            placeholder="Interval"
            disabled
          />
        </Box>

        <Box>
          <MSelect
            label="Window period *"
            options={WINDOW_PERIOD_OPTIONS}
            value={formState["windowPeriodValue"]}
            onChange={(val) => handleChange("windowPeriod", val)}
            placeholder="Window period"
          />
        </Box>
      </Box>

      <Box display="flex" justifyContent="center" mt={3}>
        <Button
          variant="contained"
          disabled={!isFormValid() || loading}
          onClick={handleFormSubmit}
          startIcon={
            loading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              <SearchIcon />
            )
          }
          sx={{
            bgcolor: "#14348D",
            borderRadius: "8px",
            height: "38px",
            px: 4,
            "&:hover": { bgcolor: "#0f276b" },
          }}
        >
          {loading ? "Fetching..." : "View Report"}
        </Button>
      </Box>

      <Slider
        open={showResp}
        onClose={() => handleChartClose()}
        direction={"top"}
      >
        <Box sx={{ padding: "20px" }}>
          <Box sx={{ textAlign: "center", color: "#14348D" }}>
            REALTIME INTERFACE LEVEL - {formState.deviceName}
          </Box>
          <CustomCard style={{ marginTop: "20px", padding: "10px" }}>
            <Box className="chart-top-content-container">
              <Box sx={{ flex: 1 }} />

              {/* <Box className="graph-info">
                <Box>Device: {formState.deviceName},</Box>
                <Box>Parameter: {formState.parameterName},</Box>
                <Box>Interface : {formState.portName}</Box>
              </Box> */}

              <Box
                sx={{ flex: 1, display: "flex", justifyContent: "flex-end" }}
              >
                <Tooltip title="Download report" arrow>
                  <IconButton
                    onClick={() =>
                      exportSingleChartWithTable(
                        `Realtime system interface Report - ${formState.deviceName}`,
                        [
                          { header: "Date Timestamp", dataKey: "date" },
                          { header: `Value (${unitLabel})`, dataKey: "data" },
                        ],
                        realtimeInterfaceLevelChartData,
                        "realtime-interface-chart-cont",
                        `${formState.deviceName}_Realtime_interface_Report`
                      )
                    }
                    sx={{
                      cursor: "pointer",
                      background: "#fff",
                      border: "1.5px solid #D1D5DB",
                      padding: "4px",
                      borderRadius: "4px",
                    }}
                  >
                    <img
                      src={PDF_ICON}
                      alt="Download"
                      style={{
                        width: "20px",
                        height: "20px",
                      }}
                    />
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
            <Box
              id="realtime-interface-chart-cont"
              sx={{ bgcolor: "#FFFFFF", p: 1 }}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 2,
                  flexWrap: "wrap",
                  mb: 1,
                  fontSize: "15px",
                  color: "#333",
                }}
              >
                <Box>
                  <strong>Device:</strong> {formState.deviceName || "N/A"}
                </Box>

                <Box>
                  <strong>Parameter:</strong> {formState.parameterName || "N/A"}
                </Box>
                <Box>
                  <strong>Interface:</strong> {formState.portName|| "N/A"}
                </Box>


              </Box>
              <CustomLineChart
                data={realtimeInterfaceLevelChartData}
                xAxisKey="date"
                lines={chartConfig}
                xAxisFormatter={formatXAxis}
                yAxisFormatter={formatYAxis}
                height={350}
                xAxisLabel="Date Time"
                yAxisLabel={`Values in ${unitLabel}`}
              />
                              <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: 2,
                    flexWrap: "wrap",
                    mb: 1.5,
                    fontSize: "15px",
                    color: "#333",
                  }}
                >
                  <Box>
                    <strong>Minimum:</strong> {stats.min}
                  </Box>

                  <Box>
                    <strong>Average:</strong> {stats.avg}
                  </Box>

                  <Box>
                    <strong>Maximum:</strong> {stats.max}
                  </Box>
                </Box>
            </Box>
            {/* <Box sx={{ textAlign: "center" }}>
              Minimum value:{stats.min}, Average value: {stats.avg}, Maximum
              value: {stats.max}
            </Box> */}
          </CustomCard>
        </Box>
      </Slider>
    </Box>
  );
};

export default RealTimeInterfaceLevel;
