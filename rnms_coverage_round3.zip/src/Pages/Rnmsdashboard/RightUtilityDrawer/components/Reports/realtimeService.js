import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_REAL_TIME_PERFORMANCE_DATA,
  STOP_REAL_TIME_PERFORMANCE_DATA,
} from "@/RestAPI/url/endpoint";

// START STREAM
export const startRealTimeStream = async (formData) => {
  return PerformanceAxios(FETCH_REAL_TIME_PERFORMANCE_DATA, "post", {
    resourceInfoBean: {
      resourceId: formData.performanceDevice,
    },
    perfParamInfoBean: {
      paramId: Number(formData.performanceParameter),
    },
    interval: formData.interval || "30",
  });
};

// STOP STREAM
export const stopRealTimeStream = async (formData) => {
  return PerformanceAxios(STOP_REAL_TIME_PERFORMANCE_DATA, "post", {
    resourceInfoBean: {
      resourceId: formData.performanceDevice,
    },
    perfParamInfoBean: {
      preporaramId: Number(formData.performanceParameter),
    },
    interval: formData.interval || "30",
  });
};
