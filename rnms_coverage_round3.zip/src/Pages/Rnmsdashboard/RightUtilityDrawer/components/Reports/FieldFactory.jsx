import React from "react";
import AsyncAlarmSelect from "./AsyncAlarmSelect";
import DateRangePicker from "./DateRangePicker";
import UptimeRadio from "./UptimeRadio";
import { Box } from "@mui/material";
import { WINDOW_PERIOD_OPTIONS } from "../../../../../lib/utils";

export const FieldFactory = ({
  fieldName,
  value,
  onChange,
  fetchOptionsFn,
  activeTabKey,
  optionsOverride,
  loadingState,
  allFormValues = {},
}) => {
  const isSingleUserTab =
    activeTabKey === "user_blocked_logs_rnms" ||
    activeTabKey === "user_blocked_logs_cnms";
  const isSingleSelectDevice =
    activeTabKey === "DeviceMaintenance" ||
    activeTabKey === "DeviceAvailability" ||
    activeTabKey === "RealTimeSystemLevel";

  // const selectFetchWrapper = () => {
  //   if (optionsOverride) {
  //     return async () => optionsOverride;
  //   }
  //   return fetchOptionsFn || (async () => []);
  // };
  const selectFetchWrapper = () => {
    if (Array.isArray(optionsOverride) && optionsOverride.length > 0) {
      return async () => optionsOverride;
    }

    return fetchOptionsFn || (async () => []);
  };
  switch (fieldName) {
    case "userName":
      return (
        <AsyncAlarmSelect
          label={isSingleUserTab ? "User Name *" : "User Names *"}
          value={value !== undefined ? value : isSingleUserTab ? "" : []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="userName"
          valueKey="userName"
          multiple={!isSingleUserTab}
        />
      );

    // case "segmentName":
    //   return (
    //     <AsyncAlarmSelect
    //       label="Segments *"
    //       value={value || []}
    //       onChange={onChange}
    //       fetchOptionsFn={selectFetchWrapper()}
    //       labelKey="segmentName"
    //       valueKey="segmentId"
    //       multiple={true}
    //     />
    //   );
    case "segmentName": {
      const isCnmsAlarmReport = activeTabKey === "AlarmReportRNMS";

      return (
        <AsyncAlarmSelect
          label={loadingState ? "Loading Segments..." : "Segments *"}
          value={Array.isArray(value) ? value : value != null ? [value] : []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          directOptions={isCnmsAlarmReport ? optionsOverride || [] : undefined}
          labelKey="segmentName"
          valueKey="segmentId"
          multiple={true}
        />
      );
    }

    case "deviceName": {
      const isSyslogReport = ["SystemLogRNMS", "SystemLogCNMS"].includes(
        activeTabKey
      );

      return (
        <AsyncAlarmSelect
          label={
            loadingState
              ? "Loading Devices..."
              : isSyslogReport
              ? "Device Name *"
              : "Device Name *"
          }
          value={value !== undefined ? value : isSingleSelectDevice ? "" : []}
          onChange={(selectedValue) => {
            const devId =
              typeof selectedValue === "object"
                ? selectedValue?.resourceId
                : selectedValue;

            onChange(selectedValue, devId);
          }}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="resourceName"
          valueKey="resourceId"
          multiple={!isSingleSelectDevice}
        />
      );
    }
    case "alarmName":
      return (
        <AsyncAlarmSelect
          label={loadingState ? "Loading Alarms..." : "Alarms *"}
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="alarmName"
          valueKey="alarmName"
          multiple={true}
        />
      );

    case "severities":
      return (
        <AsyncAlarmSelect
          label="Severities *"
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="label"
          valueKey="value"
          multiple={true}
        />
      );

    case "eventType":
      return (
        <AsyncAlarmSelect
          label="Event Types *"
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="string"
          valueKey="numVal"
          multiple={true}
        />
      );

    case "deviceIdList":
      return (
        <AsyncAlarmSelect
          label="Device Name *"
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="resourceName"
          valueKey="resourceId"
          multiple={true}
        />
      );

    case "syslogSeverities":
      return (
        <AsyncAlarmSelect
          label="Severity *"
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="label"
          valueKey="value"
          multiple={true}
        />
      );

    case "facilities":
      return (
        <AsyncAlarmSelect
          label="Facility *"
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="label"
          valueKey="value"
          multiple={true}
        />
      );
    case "linkTypeId":
      return (
        <AsyncAlarmSelect
          label="Wan Interface Type *"
          value={value !== undefined ? value : ""}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="linkName"
          valueKey="linkId"
          multiple={false}
        />
      );
    case "performanceDevice":
      return (
        <AsyncAlarmSelect
          label="Device Name *"
          value={value || ""}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="resourceName"
          valueKey="resourceId"
          multiple={false}
        />
      );
    case "performanceParameter":
      return (
        <AsyncAlarmSelect
          label="Performance Parameter *"
          value={value ? Number(value) : ""}
          onChange={(val) => onChange(val?.paramId || val)}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="paramName" // Based on standard performance data shapes
          valueKey="paramId"
          multiple={false}
        />
      );

    case "interval":
      return (
        <AsyncAlarmSelect
          label="Interval (Seconds) *"
          value="30" // Freezing it to 30 seconds
          onChange={() => {}} // No-op
          fetchOptionsFn={async () => [{ interval: "30", label: "30 Seconds" }]}
          labelKey="label"
          valueKey="value"
          multiple={false}
          disabled={true} // Keeps it locked down
        />
      );

    case "windowPeriod":
      return (
        <AsyncAlarmSelect
          label="Window Period"
          value={value || 5}
          onChange={onChange}
          fetchOptionsFn={async () => WINDOW_PERIOD_OPTIONS}
          labelKey="label"
          valueKey="value"
          multiple={false}
        />
      );
    case "upTime":
      return (
        <Box sx={{ width: "100%" }}>
          <UptimeRadio value={value} onChange={onChange} />
        </Box>
      );
    case "fromDate":
    case "startDate":
    case "toDate":
    case "endDate":
      return (
        <DateRangePicker
          fieldName={fieldName}
          value={value}
          onChange={onChange}
          allFormValues={allFormValues}
          label={
            fieldName === "fromDate" || fieldName === "startDate"
              ? "From Date *"
              : "To Date *"
          }
        />
      );
    // case "siteType":
    //   return (
    //     <AsyncAlarmSelect
    //       label="Terminal *"
    //       value={value || ""}
    //       onChange={onChange}
    //       fetchOptionsFn={selectFetchWrapper()}
    //       labelKey="terminalTypeName"
    //       valueKey="id"
    //       multiple={false}
    //     />
    //   );
    case "siteType": {
      // These reports must fetch terminal options from their API initializer.
      // Other reports can continue using Redux/optionsOverride.
      const apiTerminalTabs = [
        "SiteAvailability",
        "SiteMaintenance",
        "SiteReachability",
        "SiteRepDetails",
        "AlarmReportRNMS",
        "SystemLogCNMS",
        "foreign_ip_report_cnms",
        "db_SiteBackupLogReport",
        "db_SiteRestoreLogReport",
      ];

      const shouldFetchTerminalFromApi = apiTerminalTabs.includes(activeTabKey);

      return (
        <AsyncAlarmSelect
          key={activeTabKey}
          label="Terminal *"
          value={value ?? ""}
          onChange={onChange}
          fetchOptionsFn={
            shouldFetchTerminalFromApi ? fetchOptionsFn : selectFetchWrapper()
          }
          labelKey="terminalTypeName"
          valueKey="id"
          multiple={false}
          fetchKey={activeTabKey}
        />
      );
    }

    case "siteName": {
      const isMultiSite = [
        "SiteReachability",
        "SiteRepDetails",
        "AlarmReportRNMS",
        "SystemLogCNMS",
      ].includes(activeTabKey);

      const siteOptions = (optionsOverride || []).map((site) => ({
        ...site,
        displayName: `${site.siteName || site.siteNickName || ""}_${
          site.remoteNumber ?? site.remoteNo ?? ""
        }`,
      }));

      return (
        <AsyncAlarmSelect
          label={loadingState ? "Loading Sites..." : "Site Name *"}
          value={
            isMultiSite
              ? Array.isArray(value)
                ? value
                : value != null && value !== ""
                ? [value]
                : []
              : value ?? ""
          }
          onChange={onChange}
          directOptions={siteOptions}
          labelKey="displayName"
          valueKey="siteId"
          multiple={isMultiSite}
        />
      );
    }

    case "multipleTerminal":
      return (
        <AsyncAlarmSelect
          label="Terminal *"
          value={value || []}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          labelKey="terminalTypeName"
          valueKey="id"
          multiple={true}
        />
      );
    case "link":
      return (
        <AsyncAlarmSelect
          label={loadingState ? "Loading Links..." : "Link *"}
          value={value ?? ""}
          onChange={onChange}
          fetchOptionsFn={selectFetchWrapper()}
          directOptions={optionsOverride || []}
          labelKey="linkName"
          valueKey="linkId"
          multiple={false}
        />
      );
    default:
      return null;
  }
};
