import React from "react";
import {
  RadioGroup,
  FormControlLabel,
  Radio,
  FormLabel,
  FormControl,
} from "@mui/material";

const UptimeRadio = ({ value, onChange }) => {
  return (
    // FormControl ensures the label and radio group are treated as one unit
    <FormControl component="fieldset" sx={{ width: "100%" }}>
      <FormLabel component="legend" sx={{ mb: 1 }}>
        Uptime Type *
      </FormLabel>
      <RadioGroup
        row // This keeps the radio buttons in a single line
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
      >
        <FormControlLabel
          value="system"
          control={<Radio />}
          label="System Uptime"
        />
        <FormControlLabel
          value="rnms"
          control={<Radio />}
          label="RNMS Uptime"
        />
      </RadioGroup>
    </FormControl>
  );
};

export default UptimeRadio;
