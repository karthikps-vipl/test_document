import React, { useMemo } from "react";
import { useSelector } from "react-redux";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const ReusableRealTimeLineChart = ({ resourceId, paramId }) => {
  const key = useMemo(
    () => `${String(resourceId)}_${String(paramId)}`,
    [resourceId, paramId]
  );

  const data = useSelector(
    (state) => state.inventory.realtimePerformance?.[key] ?? []
  );

  const chartData = useMemo(() => {
    return data.map((d, i) => {
      const date = new Date(d.timestamp);

      return {
        time: isNaN(date.getTime())
          ? i
          : date.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            }),
        value: Number(d.value ?? 0),
      };
    });
  }, [data]);

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={chartData}>
        <XAxis dataKey="time" hide />
        <YAxis domain={["auto", "auto"]} />
        <Tooltip />
        <Line
          type="monotone"
          dataKey="value"
          stroke="#1976d2"
          dot={false}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default ReusableRealTimeLineChart;
