import React, { useState, useEffect, useRef } from "react";
import { CircularProgress, Box, Typography, useTheme } from "@mui/material";
import MAlarmSelect from "../../../../../components/Reusable/Select/MAlarmSelect";

const AsyncAlarmSelect = ({
  fetchOptionsFn,
  directOptions = null,
  labelKey = "label",
  valueKey = "value",
  label,
  value,
  onChange,
  multiple = true,
  fetchKey,
}) => {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';

  // Use a ref to store the latest fetch function so we don't re-trigger on reference changes
  const fetchFnRef = useRef(fetchOptionsFn);
  useEffect(() => {
    fetchFnRef.current = fetchOptionsFn;
  }, [fetchOptionsFn]);

  // useEffect(() => {
  //   let active = true;
  //   if (!fetchFnRef.current) return;

  //   const loadData = async () => {
  //     setLoading(true);
  //     setError(false);
  //     try {
  //       const data = await fetchFnRef.current();
  //       if (active) {
  //         const mapped = (data || []).map((item) => ({
  //           label: item[labelKey],
  //           value: item[valueKey],
  //         }));
  //         setOptions(mapped);
  //       }
  //     } catch (err) {
  //       console.error(`Error loading options for ${label}:`, err);
  //       if (active) setError(true);
  //     } finally {
  //       if (active) setLoading(false);
  //     }
  //   };

  //   loadData();

  //   return () => {
  //     active = false;
  //   };
  //   // Only re-fetch if structural identification changes, not on every function reference update
  // }, [labelKey, valueKey, label]);
  useEffect(() => {
    let active = true;
  
    const loadData = async () => {
      // Clear options belonging to the previous report immediately.
      setOptions([]);
      setLoading(true);
      setError(false);
  
      try {
        if (!fetchFnRef.current) {
          if (active) setOptions([]);
          return;
        }
  
        const data = await fetchFnRef.current();
  
        if (active) {
          const mapped = (Array.isArray(data) ? data : []).map((item) => ({
            label: item?.[labelKey],
            value: item?.[valueKey],
          }));
  
          setOptions(mapped);
        }
      } catch (err) {
        console.error(`Error loading options for ${label}:`, err);
  
        if (active) {
          setOptions([]);
          setError(true);
        }
      } finally {
        if (active) setLoading(false);
      }
    };
  
    loadData();
  
    return () => {
      active = false;
    };
  }, [labelKey, valueKey, label, fetchKey]);
  useEffect(() => {
    if (!directOptions) return;

    const mapped = (directOptions || []).map((item) => ({
      label: item[labelKey],
      value: item[valueKey],
    }));

    setOptions(mapped);
  }, [directOptions, labelKey, valueKey]);
  if (loading) {
    return (
      <Box display="flex" alignItems="center" height="38px" sx={{ pt: 2.5 }}>
        <CircularProgress size={18} sx={{ mr: 1, color: "#14348D" }} />
        <Typography variant="body2" color="textSecondary">
          Loading...
        </Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Typography
        variant="body2"
        color="error"
        sx={{ lineHeight: "38px", pt: 2.5 }}
      >
        Error loading data.
      </Typography>
    );
  }

  return (
    <MAlarmSelect
      options={options}
      value={value}
      onChange={onChange}
      label={label}
      multiple={multiple}
      isDark = {isDark}
      
    />
  );
};

export default AsyncAlarmSelect;
