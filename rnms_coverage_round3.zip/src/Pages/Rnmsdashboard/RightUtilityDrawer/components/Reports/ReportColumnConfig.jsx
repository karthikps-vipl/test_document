import React from "react";
import moment from "moment";
import {
  auditSeverityMap,
  linkStatusConfig,
  severityConfig,
  syslogFacilityMap,
  syslogSeverityConfig,
} from "@/lib/utils";
import {
  alarmStateConfig,
  currentAlarmStateConfig,
  workflowConfig,
} from "../../../../../lib/utils";

export const REPORT_COLUMN_CONFIGS = {
  AuditLogReport: [
    { name: "S.No", uid: "sno", sortable: false, width: "70px" },

    { name: "User Name", uid: "userName", sortable: true, filterType: "text" },
    {
      name: "IP Address",
      uid: "ipaddress",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Event Type",
      uid: "eventTypeStr",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "auditLogLvl",
      sortable: true,
      filterType: "dropdown",
      // This loops through ["MAJOR", "MINOR", "WARNING", "NORMAL"]
      filterOptions: Object.keys(auditSeverityMap).map((key) => ({
        label: auditSeverityMap[key].label, // e.g., "Major"
        value: key, // e.g., "MAJOR" (Matches row.auditLogLvl exactly)
        gradient: auditSeverityMap[key].gradient,
      })),
      render: (value) => {
        const config = auditSeverityMap[value] || {
          label: value,
          gradient: ["#d9d9d9", "#d9d9d9"],
        };

        return (
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <span
              style={{
                height: "10px",
                width: "10px",
                borderRadius: "50%",
                display: "inline-block",
                background: `linear-gradient(135deg, ${config.gradient[0]}, ${config.gradient[1]})`,
              }}
            />
            <span>{config.label}</span>
          </div>
        );
      },
    },
    {
      name: "Description",
      uid: "auditDesc",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Date and Time",
      uid: "datTimeForm",
      sortable: true,
      filterType: "datetime",
    },
  ],
  user_blocked_logs_rnms: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },

    { name: "User Name", uid: "userName", sortable: true, filterType: "text" },
    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      // Static options
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key), // Ensure it's a number (0, 1, 2)
        gradient: severityConfig[key].gradient, // Pass the gradient through
      })),
    },
    {
      name: "State",
      uid: "alarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: alarmStateConfig,
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
    },
  ],
  foreign_ip_report_rnms: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "60px",
    },
    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      // Static options
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key), // Ensure it's a number (0, 1, 2)
        gradient: severityConfig[key].gradient, // Pass the gradient through
      })),
    },
    {
      name: "State",
      uid: "currentAlarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: currentAlarmStateConfig,
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      renderCell: (params) => {
        const val = params?.row?.dateTime || params?.dateTime;
        return val ? moment(val).format("YYYY-MM-DD HH:mm:ss") : "N/A";
      },
    },
  ],
  AlarmLog: [
    { name: "S.No", uid: "sno", sortable: false, width: "90px" },
    {
      name: "Segment Name",
      uid: "segmentName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Device Name",
      uid: "resourceName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      // Static options
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key), // Ensure it's a number (0, 1, 2)
        gradient: severityConfig[key].gradient, // Pass the gradient through
      })),
    },
    {
      name: "State",
      uid: "alarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: alarmStateConfig,
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
  ],
  DeviceAvailability: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "text",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "Duration",
      uid: "durationSeconds",
      sortable: true,
      filterType: "text",
      render: (val) => {
        if (!val) return "0s";
        const dur = moment.duration(Number(val), "seconds"); // API provides seconds instead of ms
        return `${dur.days()}d ${dur.hours()}h ${dur.minutes()}m ${dur.seconds()}s`;
      },
    },
    {
      name: "Description",
      uid: "remarks",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Availability",
      uid: "available",
      sortable: true,
      filterType: "text",
      render: (value) => (
        <span
          style={{ color: value ? "#2e7d32" : "#d32f2f", fontWeight: "bold" }}
        >
          {value ? "AVAILABLE" : "NOT AVAILABLE"}
        </span>
      ),
    },
  ],
  SystemLogRNMS: [
    { name: "S.No", uid: "sno", sortable: false, width: "60px" },
    {
      name: "Segment Name",
      uid: "segmentName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Device Name",
      uid: "resourceName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Facility",
      uid: "facilityString",
      sortable: true,
      filterType: "dropdown",
      filterOptions: Object.entries(syslogFacilityMap).map(
        ([value, label]) => ({
          value: label,
          label,
        })
      ),
    },
    // {
    //   name: "Facility",
    //   uid: "facility",
    //   sortable: true,
    //   filterType: "dropdown",
    //   filterOptions: Object.entries(syslogFacilityMap).map(
    //     ([value, label]) => ({
    //       value: Number(value),
    //       label,
    //     })
    //   ),
    // },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      severityType: "syslog",
      filterOptions: Object.keys(syslogSeverityConfig).map((key) => ({
        label: syslogSeverityConfig[key].label,
        value: Number(key),
        gradient: syslogSeverityConfig[key].gradient,
      })),
    },
    {
      name: "Message",
      uid: "syslogDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Log Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
  ],
  DeviceMaintenance: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },
    {
      name: "IP Address",
      uid: "resourceIpaddress",
      sortable: true,
      filterType: "text",
    },
    {
      name: "User Name",
      uid: "userDetail",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "datetime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "Description",
      uid: "remarks",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Duration",
      uid: "durationSeconds",
      sortable: true,
      filterType: "text",
      render: (val) => {
        const totalSeconds = Number(val) || 0;

        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = Math.floor(totalSeconds % 60);

        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
      },
    },
    {
      name: "Maintenance",
      uid: "isMaintenance",
      sortable: true,
      filterType: "text",
      render: (value) => (
        <span
          style={{ color: value ? "#f57c00" : "#d32f2f", fontWeight: "bold" }}
        >
          {value ? "YES" : "NO"}
        </span>
      ),
    },
  ],
  UptimeReportRNMS: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },
    {
      name: "Duration",
      uid: "duration",
      sortable: true,
      filterType: "text",
      render: (val) => {
        if (!val) return "0s";
        const dur = moment.duration(Number(val), "seconds");
        return `${dur.days()}d ${dur.hours()}h ${dur.minutes()}m ${dur.seconds()}s`;
      },
    },
    {
      name: "Log Date and Time",
      uid: "logDatetime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },

    {
      name: "Type",
      uid: "type",
      sortable: true,
      filterType: "text",
      render: (value) => {
        // Convert to number to handle "0" or "1" strings
        const numVal = Number(value);

        return (
          <span
            style={{
              color: numVal === 1 ? "#d32f2f" : "#2e7d32",
              fontWeight: "bold",
            }}
          >
            {numVal === 1 ? "Down Time" : "Up Time"}
          </span>
        );
      },
    },
  ],
  Link: [
    { name: "S.No.", uid: "sno", sortable: false, width: "90px" },
    {
      name: "Status",
      uid: "linkStatus",
      sortable: true,
      filterType: "text",

      render: (value) => {
        // Look up the config based on the value, fallback to a default if not found
        const status = linkStatusConfig[value] || {
          label: "Unknown",
          color: "#757575",
        };

        return (
          <span
            style={{
              color: status.color,
              fontWeight: "bold",
              textTransform: "uppercase",
            }}
          >
            {status.label}
          </span>
        );
      },
    },
    {
      name: "Log Date",
      uid: "datetime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "Duration",
      uid: "duration",
      sortable: true,
      filterType: "text",
      render: (val) => {
        if (!val) return "0s";
        const dur = moment.duration(Number(val), "seconds");
        return `${dur.days()}d ${dur.hours()}h ${dur.minutes()}m ${dur.seconds()}s`;
      },
    },
  ],
  LinkCnms: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "90px",
    },
    {
      name: "Duration",
      uid: "duration",
      sortable: true,
      filterType: "text",
      render: (value) => {
        const totalSeconds = Math.max(0, Number(value) || 0);

        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = Math.floor(totalSeconds % 60);

        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
      },
    },

    {
      name: "Log Date",
      uid: "datetime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "Status",
      uid: "linkStatus",
      sortable: true,
      filterType: "text",
      render: (value) => {
        const status = linkStatusConfig[value] || linkStatusConfig[3];

        return (
          <span
            style={{
              color: status.color,
              fontWeight: 700,
              textTransform: "uppercase",
            }}
          >
            {status.label}
          </span>
        );
      },
    },
  ],

  db_BackupStatusLog: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },
    {
      name: "File Name",
      uid: "fileName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Log Date Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "BackUp Mode",
      uid: "backUpMode",
      sortable: true,
      filterType: "text",
    },
  ],
  ACU: [
    { name: "S.No.", uid: "sno", sortable: false, width: "95px" },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "Response",
      uid: "depictionResp",
      sortable: true,
      filterType: "text",
    },
  ],

  // CNMS
  user_blocked_logs_cnms: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },

    {
      name: "User Name",
      uid: "userName",
      sortable: true,
      filterType: "text",
    },

    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key),
        gradient: severityConfig[key].gradient,
      })),
    },

    {
      name: "State",
      uid: "alarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: alarmStateConfig,
    },

    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },

    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
    },
  ],
  foreign_ip_report_cnms: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "60px",
    },
    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      // Static options
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key), // Ensure it's a number (0, 1, 2)
        gradient: severityConfig[key].gradient, // Pass the gradient through
      })),
    },
    {
      name: "State",
      uid: "currentAlarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: currentAlarmStateConfig,
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      renderCell: (params) => {
        const val = params?.row?.dateTime || params?.dateTime;
        return val ? moment(val).format("YYYY-MM-DD HH:mm:ss") : "N/A";
      },
    },
  ],
  SiteMaintenance: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "60px",
    },
    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
      filterType: "text",
    },
    {
      name: "IP Address",
      uid: "siteIpaddress",
      sortable: true,
      filterType: "text",
    },
    {
      name: "User Name",
      uid: "userDetail",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "datetime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
    {
      name: "Description",
      uid: "remarks",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Duration",
      uid: "durationSeconds",
      sortable: true,
      filterType: "text",
      render: (val) => {
        const totalSeconds = Number(val) || 0;

        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = Math.floor(totalSeconds % 60);

        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
      },
    },
    {
      name: "Maintenance",
      uid: "isMaintenance",
      sortable: true,
      filterType: "text",
      render: (value) => (
        <span
          style={{
            color: value ? "#f57c00" : "#d32f2f",
            fontWeight: "bold",
          }}
        >
          {value ? "YES" : "NO"}
        </span>
      ),
    },
  ],

  db_SiteBackupLogReport: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "60px",
    },

    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Site Name",
      uid: "siteName",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Backup Date Time",
      uid: "backupDateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },

    {
      name: "File Name",
      uid: "fileName",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Backup Mode",
      uid: "backupMode",
      sortable: true,
      filterType: "text",
    },
  ],
  db_SiteRestoreLogReport: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "60px",
    },

    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Site Name",
      uid: "siteName",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Restore Date Time",
      uid: "restoreDateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },

    {
      name: "File Name",
      uid: "fileName",
      sortable: true,
      filterType: "text",
    },
  ],
  db_CnmsRestoreStatusLog: [
    { name: "S.No.", uid: "sno", sortable: false, width: "60px" },
    {
      name: "File Name",
      uid: "fileName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Log Date Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
  ],
  SiteAvailability: [
    {
      name: "S.No",
      uid: "sno",
      sortable: false,
      width: "60px",
    },
    {
      name: "Date & Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
    },
    {
      name: "Duration",
      uid: "duration",
      sortable: true,
      filterType: "text",
      render: (val) => {
        if (!val) return "0s";
        const dur = moment.duration(Number(val), "seconds"); // API provides seconds instead of ms
        return `${dur.days()}d ${dur.hours()}h ${dur.minutes()}m ${dur.seconds()}s`;
      },
    },
    {
      name: "Description",
      uid: "description",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Availability",
      uid: "availability",
      sortable: true,
      filterType: "text",
      // Note: I am assuming 'row' is available as the second argument
      render: (val, row) => {
        if (!val) return "N/A";

        // Use the 'statusCategory' calculated in transformResponse
        // This is much more reliable than parsing strings manually
        const category = row?.statusCategory;

        let color = "inherit";

        // 1. Handle Maintenance Types
        if (category === "NON_OPS") {
          color = "#B8860B"; // Dark Orange for Non-Ops
        } else if (category === "R_OPS") {
          color = "#34B8B8"; // Gold for R-Ops
        }
        // 2. Handle existing statuses
        else if (category === "UP") {
          color = "#2E7D32"; // Green
        } else if (category === "DOWN") {
          color = "#D32F2F"; // Red
        } else if (category === "RNMS_DOWN") {
          color = "#F3C106"; // Amber/Yellow
        }
        // Fallback for any other MAINTENANCE string matches
        else if (val.includes("MAINTENANCE")) {
          color = "#ffc107";
        }

        return (
          <span
            style={{
              color: color,
              fontWeight: "bold",
              textTransform: "uppercase",
              fontSize: "11px",
            }}
          >
            {val}
          </span>
        );
      },
    },
  ],
  SiteReachability: [
    {
      name: "S.No",
      uid: "sno",
      sortable: false,
      width: "90px",
    },
    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Site Name",
      uid: "siteName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key),
        gradient: severityConfig[key].gradient,
      })),
    },
    {
      name: "State",
      uid: "currentAlarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: alarmStateConfig,
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
  ],
  SiteRepDetails: [
    {
      name: "S.No.",
      uid: "sno",
      sortable: false,
      width: "80px",
    },
    {
      name: "Terminal",
      uid: "terminal",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Site Name",
      uid: "siteName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Personnel Name",
      uid: "personnelName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Designation",
      uid: "designation",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Unit",
      uid: "unit",
      sortable: true,
      filterType: "text",
    },
    {
      name: "IP Phone",
      uid: "ipPhone",
      sortable: true,
      filterType: "text",
    },
    {
      name: "AFCEL",
      uid: "afcel",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Primary Civil Mobile",
      uid: "primaryCivilMobile",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Alternate Civil Mobile",
      uid: "alternateCivilMobile",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Email",
      uid: "email",
      sortable: true,
      filterType: "text",
    },
  ],
  AlarmReportRNMS: [
    { name: "S.No", uid: "sno", sortable: false, width: "90px" },
    {
      name: "Segment Name",
      uid: "segmentName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Device Name",
      uid: "resourceName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "IP Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "alarmDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      // Static options
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: Number(key), // Ensure it's a number (0, 1, 2)
        gradient: severityConfig[key].gradient, // Pass the gradient through
      })),
    },
    {
      name: "State",
      uid: "alarmState",
      sortable: true,
      filterType: "dropdown",
      filterOptions: alarmStateConfig,
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      name: "Workflow Comments",
      uid: "workflowComments",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
  ],
  SystemLogCNMS: [
    { name: "S.No", uid: "sno", sortable: false, width: "60px" },
    {
      name: "Site ID",
      uid: "siteId",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Site Name",
      uid: "siteName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Site Ip Address",
      uid: "SiteIpAddress",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Device Name",
      uid: "resourceName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Device Ip Address",
      uid: "resourceIp",
      sortable: true,
      filterType: "text",
    },

    {
      name: "Facility",
      uid: "facilityString",
      sortable: true,
      filterType: "dropdown",
      filterOptions: Object.entries(syslogFacilityMap).map(
        ([value, label]) => ({
          value: label,
          label,
        })
      ),
    },

    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      severityType: "syslog",
      filterOptions: Object.keys(syslogSeverityConfig).map((key) => ({
        label: syslogSeverityConfig[key].label,
        value: Number(key),
        gradient: syslogSeverityConfig[key].gradient,
      })),
    },
    {
      name: "Message",
      uid: "syslogDescription",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Log Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
      render: (value) =>
        value ? moment(value).format("YYYY-MM-DD HH:mm:ss") : "N/A",
    },
  ],
};
