import {
  AuditManagementAxios,
  FaultAxios,
  SecurityAxios,
  InventoryAxios,
  TopologyAxios,
  DbAxios, // Import your Topology Axios instance
} from "@/RestAPI/api/axiosApicall";
import {
  GET_ALL_USERS,
  GET_EVNT_TYPE_LIST,
  FETCH_ALL_FILTERED_AUDIT_LOGS,
  FETCH_ALL_USER_BLOCK_ALARM,
  FETCH_ALL_FOREIGN_IP_ALARMS_AT_RNMS,
  GET_ALARM_REPORT,
  GET_SYSLOG_INFO_REPORT,
  FETCH_ALL_SEGMENTS,
  GET_ALL_SEVERITY_KEY_VALUE_PAIR,
  FETCH_LST_OF_RESOURCE_INFO_BASED_ON_SYSLOG,
  GET_SYSLOG_SEVERITY_KEY_VALUE_PAIR,
  GET_SYSLOG_FACILITY_KEY_VALUE_PAIR,
  DEVICE_MAINTENANCE_REPORT,
  FETCH_DEVICE_AVAILABILITY_LOG,
  GET_LINK_STATUS_LOG_REPORT,
  FETCH_EXISTING_LINK_CONFIGURATION_DETAILS,
  FETCH_RNMS_DB_BACKUP_LOGS_BETWEEN_THE_DATES,
  FETCH_FM_ACU_LOG_DETAILS,
  FETCH_VEHICLE_UPTIME_LOG_REPORT,
  FETCH_RNMS_UPTIME_LOG_REPORT,
  FETCH_PERFORMANCE_MONITORING_DEVICES_LIST,
  FETCH_PERF_PARAM_OF_RESOURCE_TYPE,
  FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
} from "../../../../../RestAPI/url/endpoint";
import moment from "moment";
import { PerformanceAxios } from "../../../../../RestAPI/api/axiosApicall";
import {
  FETCH_ALL_FOREIGN_IP_ALARMS,
  FETCH_CNMS_DB_RESTORE_LOG_BETWEEN_THE_DATES,
  FETCH_SITE_AVAILABILITY_OPS_NONOPS_LOG_REPORT,
  FETCH_SITE_DB_BACKUP_LOGS,
  FETCH_SITE_DB_RESTORE_LOGS_BETWEEN_DATES,
  FETCH_SITE_LINK_STATUS_REPORT,
  FETCH_SITE_LINK_STATUS_SUMMARY,
  FETCH_SITE_REP_DETAILS_BY_SITE_ID,
  GET_ALL_RNMS_ESCALATED_ALARM_REPORT,
  GET_ALL_USERS_FOR_DEPLOYED_TERMINAL_TYPE,
  GET_SITE_REACHABILITY_ALARM_REPORT,
  GET_SITE_SYSLOG_REPORT,
  SITE_MAINTENANCE_REPORT,
} from "@/RestAPI/url/cnmsEndPoint";

const defaultPayloadAdapter = (
  formData,
  startKey = "startDate",
  endKey = "endDate",
  mode = "simple"
) => {
  if (mode === "day") {
    return {
      [startKey]: formData.fromDate
        ? moment(formData.fromDate).startOf("day").toISOString()
        : null,
      [endKey]: formData.toDate
        ? moment(formData.toDate).endOf("day").toISOString()
        : null,
    };
  }
  return {
    [startKey]: formData.fromDate
      ? moment(formData.fromDate).toISOString()
      : null,
    [endKey]: formData.toDate ? moment(formData.toDate).toISOString() : null,
  };
};

const getSiteAvailabilityCategory = (row) => {
  const healthStatusValue = String(row?.healthStatus?.value || "")
    .trim()
    .toUpperCase();

  const healthStatusId = row?.healthStatus?.id;

  const siteDetails = row?.imSiteDetails;
  const isMaintenance = Boolean(siteDetails?.isMaintainance);

  const maintenanceType = String(siteDetails?.maintenanceType || "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");

  if (isMaintenance) {
    if (maintenanceType === "NON_OPS" || maintenanceType === 1)
      return "NON_OPS";
    if (maintenanceType === "R_OPS" || maintenanceType === 2) return "R_OPS";
  }

  if (healthStatusValue === "RNMS DOWN" || healthStatusId === 2) {
    return "RNMS_DOWN";
  }

  if (healthStatusValue === "UP" || healthStatusId === 1) {
    return "UP";
  }

  if (healthStatusValue === "DOWN" || healthStatusId === 0) {
    return "DOWN";
  }

  return "DOWN";
};
const hasSiteReachabilityData = (row) =>
  Boolean(
    row?.siteId ||
      row?.imSiteDetails?.siteId ||
      row?.dateTime ||
      row?.datetime ||
      row?.alarmName ||
      row?.alarmDescription ||
      row?.healthStatus?.value
  );
export const ReportActionsRegistry = {
  // AUDIT LOG (CNMS & RNMS)
  AuditLogReport: {
    axiosInstance: AuditManagementAxios,
    endpoint: FETCH_ALL_FILTERED_AUDIT_LOGS,
    initializers: {
      // userName: async () => {
      //   const res = await SecurityAxios(GET_ALL_USERS, "get");
      //   return res?.data || res || [];
      // },
      userName: async (formData, context = {}) => {
        const { isCnms } = context;

        const userEndpoint = isCnms
          ? GET_ALL_USERS_FOR_DEPLOYED_TERMINAL_TYPE
          : GET_ALL_USERS;

        const res = await SecurityAxios(userEndpoint, "get");

        return res?.data || res || [];
      },
      eventType: async () => {
        const res = await AuditManagementAxios(GET_EVNT_TYPE_LIST, "get");
        const raw = res?.data || res || {};
        return raw.eventType || raw;
      },
    },
    transformPayload: (formData) => ({
      eventType: formData.eventType || [],
      userName: (formData.userName || []).map((name, idx) => ({
        id: idx,
        userName: name,
      })),
      ...defaultPayloadAdapter(formData, "startDate", "endDate", "simple"),
    }),
  },

  user_blocked_logs_rnms: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_ALL_USER_BLOCK_ALARM,
    initializers: {
      userName: async () => {
        const res = await SecurityAxios(GET_ALL_USERS, "get");
        return res?.data || res || [];
      },
    },
    transformPayload: (formData) => ({
      userName: Array.isArray(formData.userName)
        ? formData.userName[0]
        : formData.userName || "",
      ...defaultPayloadAdapter(formData, "fromDate", "toDate", "day"),
    }),
  },

  foreign_ip_report_rnms: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_ALL_FOREIGN_IP_ALARMS_AT_RNMS,
    transformPayload: (formData) =>
      defaultPayloadAdapter(formData, "fromDate", "toDate", "day"),
  },

  AlarmLog: {
    axiosInstance: FaultAxios,
    endpoint: GET_ALARM_REPORT,
    initializers: {
      segmentName: async () => {
        const res = await InventoryAxios(FETCH_ALL_SEGMENTS, "get");
        return res?.data || res || [];
      },
      severities: async () => {
        const res = await FaultAxios(GET_ALL_SEVERITY_KEY_VALUE_PAIR, "get");
        const raw = res?.data || res || {};
        return Object.entries(raw).map(([k, v]) => ({ value: k, label: v }));
      },
    },
    transformPayload: (formData) => ({
      resourceIdList: formData.deviceName || [],
      alarmNameList: formData.alarmName || [],
      severityList: formData.severities || [],
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),
  },

  SystemLogRNMS: {
    axiosInstance: FaultAxios,
    endpoint: GET_SYSLOG_INFO_REPORT,
    initializers: {
      deviceName: async () => {
        const res = await InventoryAxios(
          FETCH_LST_OF_RESOURCE_INFO_BASED_ON_SYSLOG,
          "get"
        );
        return res?.data || res || [];
      },
      syslogSeverities: async () => {
        const res = await FaultAxios(GET_SYSLOG_SEVERITY_KEY_VALUE_PAIR, "get");
        const raw = res?.data || res || {};
        return Object.entries(raw).map(([k, v]) => ({ value: k, label: v }));
      },
      facilities: async () => {
        const res = await FaultAxios(GET_SYSLOG_FACILITY_KEY_VALUE_PAIR, "get");
        const raw = res?.data || res || {};
        return Object.entries(raw).map(([k, v]) => ({ value: k, label: v }));
      },
    },
    transformPayload: (formData) => ({
      deviceIdList: formData.deviceName || [],
      severityList: formData.syslogSeverities || [],
      facilityList: formData.facilities || [],
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),
    // transformResponse: (data) =>
    //   data.map((row, index) => ({
    //     sno: index + 1,
    //     segmentName: row?.imResourceInfo?.imSegmentInfo?.segmentName,
    //     resourceName: row?.imResourceInfo?.resourceName,
    //     facilityLabel: row?.facility,
    //     severityLabel: row?.severity,
    //     message: row?.syslogDescription,
    //     logTime: row?.dateTime,
    //   }))
    transformResponse: (data) =>
      data.map((row, index) => ({
        sno: index + 1,

        segmentName: row?.imResourceInfo?.imSegmentInfo?.segmentName || "N/A",

        resourceName: row?.imResourceInfo?.resourceName || "N/A",

        facilityString: row?.facilityString || "N/A",
        // row?.facility !== undefined && row?.facility !== null
        //   ? Number(row.facility)
        //   : null,

        severity:
          row?.severity !== undefined && row?.severity !== null
            ? Number(row.severity)
            : null,

        syslogDescription: row?.syslogDescription || "N/A",

        dateTime: row?.dateTime || null,
      })),
  },

  DeviceMaintenance: {
    axiosInstance: TopologyAxios,
    endpoint: DEVICE_MAINTENANCE_REPORT,
  
    initializers: {
      deviceName: async () => [],
    },
  
    transformPayload: (formData) => ({
      deviceId: formData.deviceName || "",
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate
        ? moment(formData.toDate).toISOString()
        : null,
    }),
  
    transformResponse: (data) => {
      let rows = data;
  
      if (rows && !Array.isArray(rows) && typeof rows === "object") {
        if (Array.isArray(rows.data)) {
          rows = rows.data;
        } else if (Array.isArray(rows.content)) {
          rows = rows.content;
        } else if (Array.isArray(rows.result)) {
          rows = rows.result;
        } else {
          return [];
        }
      }
  
      if (!Array.isArray(rows)) return [];
  
      const validRows = rows.filter((row) => {
        if (!row || typeof row !== "object" || Array.isArray(row)) {
          return false;
        }
  
        return Boolean(
          row.resourceId ||
          row.deviceId ||
          row.resourceName ||
          row.deviceName ||
          row.datetime ||
          row.dateTime ||
          row.startTime ||
          row.endTime ||
          row.duration != null ||
          row.durationSeconds != null ||
          row.remarks ||
          row.isMaintenance === true ||
          String(row.isMaintenance).toLowerCase() === "true"
        );
      });
  
      return validRows.map((row, index) => ({
        ...row,
        sno: index + 1,
      }));
    },
  },
  DeviceAvailability: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_DEVICE_AVAILABILITY_LOG,
    isPathVariableId: true,
  
    initializers: {
      deviceName: async () => [],
    },
  
    transformPayload: (formData) => ({
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate
        ? moment(formData.toDate).toISOString()
        : null,
    }),
  
    transformResponse: (data) => {
      // Accept only actual report rows.
      let rows = data;
  
      if (rows && !Array.isArray(rows) && typeof rows === "object") {
        if (Array.isArray(rows.data)) {
          rows = rows.data;
        } else if (Array.isArray(rows.content)) {
          rows = rows.content;
        } else if (Array.isArray(rows.result)) {
          rows = rows.result;
        } else {
          return [];
        }
      }
  
      if (!Array.isArray(rows)) return [];
  
      const validRows = rows.filter((row) => {
        if (!row || typeof row !== "object" || Array.isArray(row)) {
          return false;
        }
  
        return Boolean(
          row.resourceId ||
          row.deviceId ||
          row.resourceName ||
          row.deviceName ||
          row.datetime ||
          row.dateTime ||
          row.startTime ||
          row.endTime ||
          row.duration != null ||
          row.durationSeconds != null ||
          row.status != null ||
          row.availability != null
        );
      });
  
      return validRows.map((row, index) => ({
        ...row,
        sno: index + 1,
      }));
    },
  },
  
  Link: {
    axiosInstance: TopologyAxios,
    endpoint: GET_LINK_STATUS_LOG_REPORT,
    initializers: {
      linkTypeId: async () => {
        // Triggers the dropdown options fetch
        const res = await TopologyAxios(
          FETCH_EXISTING_LINK_CONFIGURATION_DETAILS,
          "get"
        );
        return res?.data || res || [];
      },
    },
    transformPayload: (formData) => ({
      linkTypeId: Number(formData.linkTypeId) || null,
      fromDate: formData.fromDate
        ? moment(formData.fromDate).format("YYYY-MM-DDTHH:mm:ss")
        : null,
      toDate: formData.toDate
        ? moment(formData.toDate).format("YYYY-MM-DDTHH:mm:ss")
        : null,
    }),
  },
  db_BackupStatusLog: {
    axiosInstance: DbAxios,
    endpoint: FETCH_RNMS_DB_BACKUP_LOGS_BETWEEN_THE_DATES,
    transformPayload: (formData) =>
      defaultPayloadAdapter(formData, "fromDate", "toDate", "day"),
  },
  db_CnmsRestoreStatusLog: {
    axiosInstance: DbAxios,
    endpoint: FETCH_CNMS_DB_RESTORE_LOG_BETWEEN_THE_DATES,
    transformPayload: (formData) =>
      defaultPayloadAdapter(formData, "fromDate", "toDate", "day"),
  },
  ACU: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_FM_ACU_LOG_DETAILS,
  
    transformPayload: (formData) =>
      defaultPayloadAdapter(formData, "fromDate", "toDate", "day"),
  
    transformResponse: (data) => {
      let rows = data;
  
      if (rows && !Array.isArray(rows) && typeof rows === "object") {
        if (Array.isArray(rows.data)) {
          rows = rows.data;
        } else if (Array.isArray(rows.content)) {
          rows = rows.content;
        } else if (Array.isArray(rows.result)) {
          rows = rows.result;
        } else {
          return [];
        }
      }
  
      if (!Array.isArray(rows)) return [];
  
      const validRows = rows.filter((row) => {
        if (!row || typeof row !== "object" || Array.isArray(row)) {
          return false;
        }
  
        return Boolean(
          row.resourceId ||
          row.deviceId ||
          row.resourceName ||
          row.deviceName ||
          row.datetime ||
          row.dateTime ||
          row.eventTime ||
          row.startTime ||
          row.endTime ||
          row.alarmName ||
          row.alarmDescription ||
          row.message ||
          row.duration != null ||
          row.status != null
        );
      });
  
      return validRows.map((row, index) => ({
        ...row,
        sno: index + 1,
      }));
    },
  },
  UptimeReportRNMS: {
    axiosInstance: InventoryAxios,

    transformPayload: (formData, rnmsId) => ({
      rnmsId,
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),
  },
  RealTimeSystemLevel: {
    axiosInstance: PerformanceAxios,
    endpoint: FETCH_PERF_PARAM_OF_RESOURCE_TYPE,

    initializers: {
      performanceDevice: async () => {
        const res = await PerformanceAxios(
          FETCH_PERFORMANCE_MONITORING_DEVICES_LIST,
          "get"
        );
        return res?.data || res || [];
      },

      performanceParameter: async (formData) => {
        if (!formData?.performanceDevice) return [];
        const device = formData.performanceDevice;

        const res = await PerformanceAxios(
          `${FETCH_PERF_PARAM_OF_RESOURCE_TYPE}/${
            device.resourceTypeId || 908
          }`,
          "get"
        );
        return res?.data || res || [];
      },
    },

    transformPayload: (formData) => ({
      resourceInfoBean: {
        resourceId: formData.performanceDevice?.resourceId,
      },
      perfParamInfoBean: {
        paramId: formData.performanceParameter,
      },
      interval: 30,
    }),
  },

  // CNMS
  user_blocked_logs_cnms: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_ALL_USER_BLOCK_ALARM,

    initializers: {
      siteType: async () => [],

      siteName: async () => {
        return [];
      },

      userName: async () => {
        const res = await SecurityAxios(GET_ALL_USERS, "get");
        return res?.data || res || [];
      },
    },

    transformPayload: (formData) => ({
      siteId: formData.siteName || "",
      userName: Array.isArray(formData.userName)
        ? formData.userName[0]
        : formData.userName || "",
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),
  },
  foreign_ip_report_cnms: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_ALL_FOREIGN_IP_ALARMS,

    initializers: {
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const rawData = res?.data || res || [];

        return Array.isArray(rawData) ? rawData : Object.values(rawData || {});
      },

      siteName: async () => [],
    },

    transformPayload: (formData) => ({
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,

      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,

      siteId: formData.siteName || "",
    }),
  },
  db_SiteBackupLogReport: {
    axiosInstance: DbAxios,
    endpoint: FETCH_SITE_DB_BACKUP_LOGS,

    initializers: {
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const rawData = res?.data || res || [];

        return Array.isArray(rawData) ? rawData : Object.values(rawData || {});
      },

      siteName: async () => [],
    },

    transformPayload: (formData) => ({
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,

      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,

      siteId: formData.siteName || "",
    }),

    transformResponse: (data) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});

      return rows.map((row, index) => ({
        sno: index + 1,

        siteId: row?.siteId || row?.siteDetail?.siteId || "N/A",

        siteName:
          row?.siteDetail?.siteName || row?.siteDetail?.siteNickName || "N/A",

        backupDateTime: row?.dateTime || null,

        fileName: row?.fileName || "N/A",

        backupMode: row?.backUpMode || "N/A",
      }));
    },
  },
  db_SiteRestoreLogReport: {
    axiosInstance: DbAxios,
    endpoint: FETCH_SITE_DB_RESTORE_LOGS_BETWEEN_DATES,

    initializers: {
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const rawData = res?.data || res || [];

        return Array.isArray(rawData) ? rawData : Object.values(rawData || {});
      },

      siteName: async () => [],
    },

    transformPayload: (formData) => ({
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,

      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,

      siteId: formData.siteName || "",
    }),

    transformResponse: (data) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});

      return rows.map((row, index) => ({
        sno: index + 1,

        siteId: row?.siteId || row?.siteDetail?.siteId || "N/A",

        siteName:
          row?.siteDetail?.siteName || row?.siteDetail?.siteNickName || "N/A",

        restoreDateTime: row?.restoreDateTime || null,

        fileName: row?.fileName || "N/A",
      }));
    },
  },
  SiteAvailability: {
    axiosInstance: FaultAxios,
    endpoint: FETCH_SITE_AVAILABILITY_OPS_NONOPS_LOG_REPORT,

    initializers: {
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const rawData = res?.data || res || [];

        return Array.isArray(rawData) ? rawData : Object.values(rawData || {});
      },
    },

    transformPayload: (formData) => ({
      siteId: formData.siteName || "",
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),

    transformResponse: (data) => {
      // Extract the actual report rows from common response formats.
      let rows = data;

      if (rows && !Array.isArray(rows) && typeof rows === "object") {
        if (Array.isArray(rows.data)) {
          rows = rows.data;
        } else if (Array.isArray(rows.content)) {
          rows = rows.content;
        } else if (Array.isArray(rows.result)) {
          rows = rows.result;
        } else {
          // Do not interpret metadata or arbitrary object properties
          // as report rows.
          return [];
        }
      }

      // Empty, null, or unexpected responses mean no report data.
      if (!Array.isArray(rows) || rows.length === 0) {
        return [];
      }

      // Remove empty or placeholder records before transforming.
      const validRows = rows.filter((row) => {
        if (!row || typeof row !== "object" || Array.isArray(row)) {
          return false;
        }

        const site = row.imSiteDetails;

        // A valid availability record should identify a site or
        // contain actual availability information.
        return Boolean(
          site?.siteId ||
            site?.siteName ||
            site?.siteNickName ||
            row?.healthStatus?.value ||
            row?.healthStatus?.id != null ||
            row?.datetime ||
            row?.durationSeconds != null
        );
      });

      if (validRows.length === 0) {
        return [];
      }

      return validRows.map((row, index) => {
        const durationSeconds = Number(row?.durationSeconds ?? 0);

        return {
          sno: index + 1,
          dateTime: row?.datetime || null,
          durationSeconds,
          durationHours: durationSeconds / 3600,
          duration: durationSeconds,
          description: row?.remarks || "N/A",
          availability: row?.healthStatus?.value || "UNKNOWN",
          statusCategory: getSiteAvailabilityCategory(row),
          siteId: row?.imSiteDetails?.siteId || "N/A",
          siteName:
            row?.imSiteDetails?.siteName ||
            row?.imSiteDetails?.siteNickName ||
            "N/A",
          siteIpAddress:
            row?.siteIpAddress || row?.imSiteDetails?.ipaddress || "N/A",
          terminalType:
            row?.imSiteDetails?.imTerminalType?.terminalTypeName || "N/A",
          terminalNickname:
            row?.imSiteDetails?.imTerminalType?.terminalNickname || "N/A",
        };
      });
    },
  },
  SiteMaintenance: {
    axiosInstance: InventoryAxios,
    endpoint: SITE_MAINTENANCE_REPORT,

    initializers: {
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const rawData = res?.data || res || [];

        return Array.isArray(rawData) ? rawData : Object.values(rawData || {});
      },

      siteName: async () => [],
    },

    transformPayload: (formData) => ({
      siteId: formData.siteName || "",
      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,
      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),

    transformResponse: (data) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});

      return rows.map((row, index) => {
        const site =
          row?.siteId && typeof row.siteId === "object" ? row.siteId : {};

        return {
          sno: index + 1,

          // Keep the selected site's ID as a string for the table.
          siteId:
            site.siteId ||
            (typeof row?.siteId === "string" ? row.siteId : null) ||
            "N/A",

          siteName: site.siteName || "N/A",

          terminalTypeName: site.imTerminalType?.terminalTypeName || "N/A",

          siteIpaddress: row?.siteIpaddress || site.ipaddress || "N/A",

          userDetail: row?.userDetail || "N/A",

          datetime: row?.datetime || null,

          remarks: row?.remarks || "N/A",

          // The API returns duration in seconds.
          durationSeconds: Number(row?.duration ?? 0),

          isMaintenance:
            row?.isMaintenance === true ||
            String(row?.isMaintenance).toLowerCase() === "true",
        };
      });
    },
  },
  SiteReachability: {
    axiosInstance: FaultAxios,
    endpoint: GET_SITE_REACHABILITY_ALARM_REPORT,

    initializers: {
      // Fetch terminal types directly from the API.
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const rawData = res?.data || res || [];

        return Array.isArray(rawData) ? rawData : Object.values(rawData || {});
      },

      // Sites are fetched after selecting a terminal type
      // in ReportWorkspace, so this initializer stays empty.
      siteName: async () => [],

      // Fetch severity options from the existing severity API.
      severities: async () => {
        const res = await FaultAxios(GET_ALL_SEVERITY_KEY_VALUE_PAIR, "get");

        const raw = res?.data || res || {};

        return Object.entries(raw).map(([value, label]) => ({
          value,
          label,
        }));
      },
    },

    transformPayload: (formData) => ({
      siteIdList: Array.isArray(formData.siteName)
        ? formData.siteName
        : formData.siteName
        ? [formData.siteName]
        : [],

      severityList: (formData.severities || []).map((severity) =>
        String(typeof severity === "object" ? severity.value : severity)
      ),

      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,

      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),

    transformResponse: (data) => {
      const rows = Array.isArray(data)
        ? data
        : data && typeof data === "object"
        ? Object.values(data)
        : [];

      const validRows = rows.filter(hasSiteReachabilityData);

      return validRows.map((row, index) => ({
        ...row,
        sno: index + 1,
      }));
    },
  },
  SiteRepDetails: {
    axiosInstance: InventoryAxios,
    endpoint: FETCH_SITE_REP_DETAILS_BY_SITE_ID,

    // This report uses site IDs in the URL and GET instead of POST.
    method: "get",
    isPathVariableIds: true,

    initializers: {
      // Multiple terminal options.
      multipleTerminal: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const raw = res?.data || res || [];

        return Array.isArray(raw) ? raw : Object.values(raw);
      },

      // Populated when terminals change in ReportWorkspace.
      siteName: async () => [],
    },

    transformPayload: () => ({}),

    transformResponse: (data) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});

      return rows.map((row, index) => {
        const site = row?.siteDetails || {};
        const terminal = site?.imTerminalType || {};

        return {
          sno: index + 1,

          terminal:
            terminal.terminalTypeName || terminal.terminalNickname || "N/A",

          siteId: row?.siteId || site?.siteId || "N/A",

          siteName: site?.siteName || site?.siteNickName || "N/A",

          personnelName: row?.personnelName || "N/A",

          designation: row?.personnel || "N/A",

          unit: row?.unit || "N/A",

          ipPhone: row?.ipPhone || "N/A",

          afcel: row?.afcel || "N/A",

          primaryCivilMobile: row?.primaryCivilMobile || "N/A",

          alternateCivilMobile: row?.alternateCivilMobile || "N/A",

          email: row?.email || "N/A",
        };
      });
    },
  },
  AlarmReportRNMS: {
    axiosInstance: FaultAxios,
    endpoint: GET_ALL_RNMS_ESCALATED_ALARM_REPORT,

    initializers: {
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const raw = res?.data ?? res ?? [];
        return Array.isArray(raw) ? raw : Object.values(raw || {});
      },

      siteName: async () => [],

      segmentName: async () => [],

      deviceName: async () => [],

      alarmName: async () => [],

      severities: async () => {
        const res = await FaultAxios(GET_ALL_SEVERITY_KEY_VALUE_PAIR, "get");

        const raw = res?.data ?? res ?? {};

        return Object.entries(raw).map(([value, label]) => ({
          value: String(value),
          label,
        }));
      },
    },

    transformPayload: (formData) => {
      const normalizeIds = (value, idKey) => {
        const values = Array.isArray(value)
          ? value
          : value != null && value !== ""
          ? [value]
          : [];

        return values
          .map((item) =>
            item && typeof item === "object" ? item[idKey] : item
          )
          .filter(
            (id) => id !== undefined && id !== null && String(id).trim() !== ""
          );
      };

      return {
        siteIdList: normalizeIds(formData.siteName, "siteId"),

        alarmNameList: normalizeIds(formData.alarmName, "alarmName"),

        resourceIdList: normalizeIds(formData.deviceName, "resourceId"),

        fromDate: formData.fromDate
          ? moment(formData.fromDate).toISOString()
          : null,

        toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,

        severityList: normalizeIds(formData.severities, "value").map(String),
      };
    },

    transformResponse: (data) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});

      return rows.map((row, index) => ({
        ...row,

        sno: index + 1,

        segmentName:
          row?.imSiteResourceInfo?.imSegmentInfo?.segmentName ?? "N/A",

        resourceName: row?.imSiteResourceInfo?.resourceName ?? "N/A",
        resourceIp: row?.imSiteResourceInfo?.resourceIp ?? "N/A",


        alarmName: row?.alarmName ?? "N/A",

        alarmDescription: row?.alarmDescription ?? "N/A",

        severity:
          row?.severity !== undefined && row?.severity !== null
            ? Number(row.severity)
            : null,

        alarmState:
          row?.alarmState !== undefined && row?.alarmState !== null
            ? Number(row.alarmState)
            : null,

        workflow:
          row?.workflow !== undefined && row?.workflow !== null
            ? Number(row.workflow)
            : null,

        workflowComments: row?.workflowComments ?? "",

        dateTime: row?.dateTime ?? row?.datetime ?? null,
      }));
    },
  },
  SystemLogCNMS: {
    axiosInstance: FaultAxios,
    endpoint: GET_SITE_SYSLOG_REPORT,

    initializers: {
      // Terminal dropdown
      siteType: async () => {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS,
          "get"
        );

        const raw = res?.data ?? res ?? [];
        return Array.isArray(raw) ? raw : Object.values(raw || {});
      },

      // Sites are populated by ReportWorkspace when terminal changes.
      siteName: async () => [],

      // Devices are populated by ReportWorkspace for the selected terminal.
      deviceName: async () => [],

      syslogSeverities: async () => {
        const res = await FaultAxios(GET_SYSLOG_SEVERITY_KEY_VALUE_PAIR, "get");

        const raw = res?.data ?? res ?? {};

        return Object.entries(raw).map(([value, label]) => ({
          value: String(value),
          label,
        }));
      },

      facilities: async () => {
        const res = await FaultAxios(GET_SYSLOG_FACILITY_KEY_VALUE_PAIR, "get");
        const raw = res?.data || res || {};
        return Object.entries(raw).map(([k, v]) => ({ value: k, label: v }));
      },
    },

    transformPayload: (formData) => {
      const normalizeIds = (value, idKey) => {
        const values = Array.isArray(value)
          ? value
          : value != null && value !== ""
          ? [value]
          : [];
    
        return [
          ...new Set(
            values
              .map((item) =>
                item && typeof item === "object"
                  ? item[idKey] ?? item.value
                  : item
              )
              .filter(
                (id) =>
                  id !== undefined &&
                  id !== null &&
                  String(id).trim() !== ""
              )
              .map(String)
          ),
        ];
      };
    
      // Generate all facility IDs from 0 to 191.
      const allFacilities = Array.from(
        { length: 192 },
        (_, index) => String(index)
      );
    
      return {
        siteIdList: normalizeIds(formData.siteName, "siteId"),
    
        deviceIdList: normalizeIds(formData.deviceName, "resourceId"),
    
        severityList: normalizeIds(
          formData.syslogSeverities,
          "value"
        ),
    
        // Send every facility, matching the working API request.
        facilityList: allFacilities,
    
        fromDate: formData.fromDate
          ? moment(formData.fromDate).toISOString()
          : null,
    
        toDate: formData.toDate
          ? moment(formData.toDate).toISOString()
          : null,
      };
    },

    transformResponse: (data) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});
      console.log("RespData", rows)
      return rows.map((row, index) => ({
        sno: index + 1,

        siteId: row?.imSiteResourceInfo?.imSiteDetail?.siteId || "N/A",
        siteName: row?.imSiteResourceInfo?.imSiteDetail?.siteName || "N/A",
        siteIpAddress: row?.imSiteResourceInfo?.imSiteDetail?.ipaddress || "N/A",

        resourceName: row?.imSiteResourceInfo?.resourceName || "N/A",
        resourceIp: row?.imSiteResourceInfo?.resourceIp || "N/A",

        facilityString: row?.facilityString || "N/A",
        // row?.facility !== undefined && row?.facility !== null
        //   ? Number(row.facility)
        //   : null,

        severity:
          row?.severity !== undefined && row?.severity !== null
            ? Number(row.severity)
            : null,

        syslogDescription: row?.syslogDescription || "N/A",

        dateTime: row?.dateTime || null,
      }));
    },
  },
  LinkCnms: {
    axiosInstance: TopologyAxios,
    endpoint: FETCH_SITE_LINK_STATUS_REPORT,

    initializers: {
      // Sites are sourced from Redux in ReportWorkspace.
      siteName: async () => [],

      // Link options are loaded after selecting a site.
      link: async () => [],
    },

    transformPayload: (formData) => ({
      siteId:
        typeof formData.siteName === "object"
          ? formData.siteName?.siteId || ""
          : formData.siteName || "",

      linkTypeId: Number(
        typeof formData.link === "object"
          ? formData.link?.linkId
          : formData.link
      ),

      fromDate: formData.fromDate
        ? moment(formData.fromDate).toISOString()
        : null,

      toDate: formData.toDate ? moment(formData.toDate).toISOString() : null,
    }),
    transformResponse: (data) => {
      const rows = Array.isArray(data)
        ? data
        : data && typeof data === "object"
        ? Object.values(data)
        : [];
  
      return rows
        .filter(
          (row) =>
            row &&
            typeof row === "object" &&
            !Array.isArray(row)
        )
        .map((row, index) => ({
          sno: index + 1,
          ...row,
  
          siteId: row.siteId || "N/A",
          linkTypeId: row.linkTypeId ?? null,
          linkTypeName: row.linkTypeName || "N/A",
  
          linkStatus:
            row.linkStatus !== undefined &&
            row.linkStatus !== null
              ? Number(row.linkStatus)
              : 3,
  
          datetime: row.datetime || null,
          duration: Number(row.duration ?? 0),
          uptimePercent: Number(row.uptimePercent ?? 0),
          downTimePercent: Number(row.downTimePercent ?? 0),
          opDownTimePercent: Number(row.opDownTimePercent ?? 0),
        }));
    },
  },
  LinkSummary: {
    axiosInstance: TopologyAxios,
    endpoint: FETCH_SITE_LINK_STATUS_SUMMARY,
    method: "get",
    isPathVariableId: true,
    pathVariableField: "siteName",

    initializers: {
      // Site options are loaded from Redux in ReportWorkspace.
      siteName: async () => [],
    },

    transformPayload: () => ({}),

    transformResponse: (data, formData) => {
      const rows = Array.isArray(data) ? data : Object.values(data || {});

      return rows.map((row, index) => ({
        sno: index + 1,
        ...row,
        siteName: formData?.selectedSiteDisplayName || "N/A",
        linkTypeName: row?.linkTypeName || "Unknown Link",
        uptimePercent: Number(row?.uptimePercent ?? 0),
        downTimePercent: Number(row?.downTimePercent ?? 0),
        opDownTimePercent: Number(row?.opDownTimePercent ?? 0),
      }));
    },
  },
};

export const executeReportFetch = async (
  reportKey,
  rawFormData,
  rnmsId,
  context = {}
) => {
  const config = ReportActionsRegistry[reportKey];

  if (!config)
    throw new Error(`No API configuration registered for key: "${reportKey}"`);

  const {
    axiosInstance,
    endpoint,
    transformPayload,
    isPathVariableId,
    isPathVariableIds,
    transformResponse,
    method = "post",
  } = config;

  let finalEndpoint = endpoint;

  let payload = transformPayload(rawFormData, rnmsId, context);
  if (reportKey === "UptimeReportRNMS") {
    finalEndpoint =
      rawFormData.upTime === "system"
        ? FETCH_VEHICLE_UPTIME_LOG_REPORT
        : FETCH_RNMS_UPTIME_LOG_REPORT;
  }

  if (isPathVariableId) {
    const fieldName = config.pathVariableField || "deviceName";
    const selectedValue = rawFormData[fieldName];

    const dynamicId =
      selectedValue && typeof selectedValue === "object"
        ? selectedValue.siteId ?? selectedValue.value ?? ""
        : selectedValue ?? "";

    if (String(dynamicId).trim() === "") {
      throw new Error(`Please select a value for ${fieldName}.`);
    }

    finalEndpoint = `${endpoint}/${encodeURIComponent(
      String(dynamicId).trim()
    )}`;
  }

  // return await axiosInstance(finalEndpoint, "post", payload);
  if (isPathVariableIds) {
    const selectedSiteIds = Array.isArray(rawFormData.siteName)
      ? rawFormData.siteName
      : rawFormData.siteName
      ? [rawFormData.siteName]
      : [];

    if (selectedSiteIds.length === 0) {
      throw new Error("Please select at least one site.");
    }

    finalEndpoint = `${endpoint}/${selectedSiteIds
      .map((id) => String(id).trim())
      .filter(Boolean)
      .join(",")}`;
  }

  const response =
    method.toLowerCase() === "get"
      ? await axiosInstance(finalEndpoint, "get")
      : await axiosInstance(finalEndpoint, "post", payload);

  // Apply report-specific response transformation
  if (transformResponse) {
    const rawData = response?.data ?? response ?? [];
    const transformedData = transformResponse(rawData, rawFormData);

    return {
      ...response,
      data: transformedData,
    };
  }

  return response;
};
