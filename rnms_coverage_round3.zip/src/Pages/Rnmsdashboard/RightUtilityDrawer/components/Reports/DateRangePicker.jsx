import React, { useEffect } from "react";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
import dayjs from "dayjs";
import { Typography, FormHelperText, useTheme } from "@mui/material";
import { Box } from "@mui/system";
import Toast from "@/components/Reusable/Toast/Toast";

const DateRangePicker = ({
  fieldName,
  value,
  onChange,
  label,
  allFormValues = {},
}) => {
  // Normalize variable checks to support both "fromDate/toDate" and "startDate/endDate" configurations
  const isFromField = fieldName === "fromDate" || fieldName === "startDate";
  const isToField = fieldName === "toDate" || fieldName === "endDate";

  const getCorrespondingValue = () => {
    if (isFromField) {
      return allFormValues.toDate || allFormValues.endDate;
    }
    if (isToField) {
      return allFormValues.fromDate || allFormValues.startDate;
    }
    return null;
  };

  useEffect(() => {
    if (!value) {
      const now = dayjs();
      if (isToField) {
        onChange(now.toISOString());
      } else if (isFromField) {
        // Automatically default lookback scope directly to 30 days behind
        // const twentyDaysAgo = now.subtract(30, "day");
        const twentyDaysAgo = now.subtract(7, "day");
        onChange(twentyDaysAgo.toISOString());
      }
    }
  }, [value, fieldName, onChange, isFromField, isToField]);

  const dateValue = value ? dayjs(value) : null;
  const now = dayjs();
  const handleDateChange = (newDate) => {
    console.log("jhfhu", newDate);

    if (!newDate || !newDate.isValid()) {
      onChange(null);
      return;
    }

    const selectedIso = newDate.toISOString();
    const comparativeValue = getCorrespondingValue();

    // if (comparativeValue) {
    //   const comparativeDayjs = dayjs(comparativeValue);
    //   if (isFromField && newDate.isAfter(comparativeDayjs)) {
    //     Toast(
    //       "Error",
    //       "Validation Error: 'Start/From Date' cannot be set later than your current 'End/To Date'.",
    //       "error"
    //     );
    //     return;
    //   }
    //   if (isToField && newDate.isBefore(comparativeDayjs)) {
        // Toast(
        //   "Error",
        //   "Validation Error: 'End/To Date' cannot happen prior to your designated 'Start/From Date'.",
        //   "error"
        // );
    //     return;
    //   }
    // }
    if (isToField) {
      // Cannot select future dates past current time
      if (newDate.isAfter(now)) {
        Toast(
          "Error",
          "Validation Error: 'To Date' cannot be set in the future.",
          "error"
        );
        return;
      }

      if (comparativeValue) {
        const comparativeDayjs = dayjs(comparativeValue);
        if (newDate.isBefore(comparativeDayjs)) {
          Toast(
            "Error",
            "Validation Error: 'To Date' cannot be before 'From Date'.",
            "error"
          );
          return;
        }
        if (newDate.isAfter(comparativeDayjs.add(90, "day"))) {
          Toast(
            "Error",
            "Validation Error: The selected date range cannot exceed 90 days.",
            "error"
          );
          return;
        }
      }
    }

    // Specific validation for 'From Date'
    if (isFromField) {
      // Cannot be older than 90 days from now (or from To Date if specified)
      const maxAllowedPast = now.subtract(90, "day");
      if (newDate.isBefore(maxAllowedPast)) {
        Toast(
          "Error",
          "Validation Error: 'From Date' cannot go beyond 90 days in the past.",
          "error"
        );
        return;
      }

      if (comparativeValue) {
        const comparativeDayjs = dayjs(comparativeValue);
        if (newDate.isAfter(comparativeDayjs)) {
          Toast(
            "Error",
            "Validation Error: 'From Date' cannot be set later than 'To Date'.",
            "error"
          );
          return;
        }
        if (newDate.isBefore(comparativeDayjs.subtract(90, "day"))) {
          Toast(
            "Error",
            "Validation Error: The selected date range cannot exceed 90 days.",
            "error"
          );
          return;
        }
      }
    }
    onChange(selectedIso);
  };

  const hasError = () => {
    const fromVal = allFormValues.fromDate || allFormValues.startDate;
    const toVal = allFormValues.toDate || allFormValues.endDate;
    if (!fromVal || !toVal) return false;
    return dayjs(toVal).isBefore(dayjs(fromVal));
  };

  // const getLimitDate = () => {
  //   const comparativeValue = getCorrespondingValue();
  //   return comparativeValue ? dayjs(comparativeValue) : undefined;
  // };
  const getMinDate = () => {
    const comparativeValue = getCorrespondingValue();
    const comparativeDayjs = comparativeValue ? dayjs(comparativeValue) : null;

    if (isFromField) {
      // Absolute max lookback is 90 days from today, or 90 days before To Date
      const absoluteMin = now.subtract(90, "day");
      if (comparativeDayjs) {
        const relativeMin = comparativeDayjs.subtract(90, "day");
        return relativeMin.isAfter(absoluteMin) ? relativeMin : absoluteMin;
      }
      return absoluteMin;
    }

    if (isToField) {
      return comparativeDayjs || undefined;
    }

    return undefined;
  };

  const getMaxDate = () => {
    const comparativeValue = getCorrespondingValue();
    const comparativeDayjs = comparativeValue ? dayjs(comparativeValue) : null;

    if (isToField) {
      // To Date cannot exceed current time/date
      return now;
    }

    if (isFromField) {
      return comparativeDayjs || now;
    }

    return now;
  };
  const theme = useTheme();
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
        {label && (
          <Typography
            variant="body2"
            sx={{
              // mb: -0.6,
              fontSize: "14px",
              fontWeight: 500,
              color: hasError() ? "#d32f2f" : theme.palette.text.tabcolor,
            }}
          >
            {label}
          </Typography>
        )}

        <DateTimePicker
          label=""
          value={dateValue}
          onChange={handleDateChange}
          maxDate={getMaxDate()}
          minDate={getMinDate()}
          viewRenderers={{
            hours: renderTimeViewClock,
            minutes: renderTimeViewClock,
            seconds: renderTimeViewClock,
          }}
          ampm={false}
          format="DD/MM/YYYY HH:mm"
          slotProps={{
            textField: {
              size: "small",
              fullWidth: true,
              error: hasError(),
              InputLabelProps: { shrink: false },
            },
          }}
        />
        {hasError() && (
          <FormHelperText error sx={{ mt: -0.5 }}>
            Timeline bounds crossover error detected.
          </FormHelperText>
        )}
      </Box>
    </LocalizationProvider>
  );
};

export default DateRangePicker;
