import React, { useMemo } from "react";
import { Box, Card, CardContent, Grid, Typography, Stack } from "@mui/material";
import RouterIcon from "@mui/icons-material/Router";
import LanIcon from "@mui/icons-material/Lan";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import CloudOffIcon from "@mui/icons-material/CloudOff";
import BuildCircleIcon from "@mui/icons-material/BuildCircle";
import EngineeringIcon from "@mui/icons-material/Engineering";

const STATUS_ITEMS = [
  { key: "UP", label: "UP", color: "#2E7D32", icon: CheckCircleOutlineIcon },
  { key: "DOWN", label: "DOWN", color: "#D32F2F", icon: HighlightOffIcon },
  { key: "RNMS_DOWN", label: "RNMS DOWN", color: "#F3C106", icon: CloudOffIcon },
  { key: "NON_OPS", label: "Maintenance NON-OPS", color: "#B8860B", icon: BuildCircleIcon },
  { key: "R_OPS", label: "Maintenance R-OPS", color: "#34B8B8", icon: EngineeringIcon },
];

const formatDuration = (seconds) => {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const remainingSeconds = total % 60;
  return `${days}d ${hours}h ${minutes}m ${remainingSeconds}s`;
};

const SiteAvailabilitySummary = ({ data = [] }) => {
  const summary = useMemo(() => {
    const result = Object.fromEntries(STATUS_ITEMS.map((item) => [item.key, 0]));
    data.forEach((row) => {
      const key = row.statusCategory;
      if (Object.prototype.hasOwnProperty.call(result, key)) {
        result[key] += Number(row.durationSeconds) || 0;
      }
    });
    return result;
  }, [data]);

  const firstRow = data[0] || {};
  const terminalName = firstRow.terminalNickname !== "N/A" && firstRow.terminalNickname ? firstRow.terminalNickname : firstRow.terminalType || "N/A";
  const siteId = firstRow.siteId || "N/A";
  const siteName = firstRow.siteName || "N/A";
  const ipAddress = firstRow.siteIpAddress || "N/A";

  // MODIFIED: height 100% added so they stretch to match the tallest card in the row
  const cardSx = {
    height: "100%", 
    borderRadius: 2,
    border: "1px solid",
    borderColor: "divider",
    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
    display: "flex", // Added to help content alignment
    flexDirection: "column"
  };

  const contentSx = {
    p: 1.5,
    flexGrow: 1, // Ensures content fills the card if height is stretched
    "&:last-child": { pb: 1.5 } 
  };

  return (
    /* IMPORTANT: Added 'container' prop and removed the tailwind 'grid' class 
       which conflicts with MUI Grid */
    <Grid spacing={2} sx={{ mb: 1}} className="grid grid-cols-3 gap-2">
      
      {/* Card 1: Terminal and site information */}
      <Grid item xs={12} md={4}>
        <Card sx={cardSx}>
          <CardContent sx={contentSx}>
            <Stack direction="row" spacing={1} alignItems="center" mb={0.5}>
              <Box sx={{ display: "flex", p: 0.8, borderRadius: 1, bgcolor: "rgba(20,52,141,0.10)", color: "#14348D" }}>
                <RouterIcon fontSize="small" />
              </Box>
              <Typography variant="subtitle2" fontWeight={700}>
                Terminal
              </Typography>
            </Stack>
            <Typography variant="body2" fontWeight={700} sx={{ lineHeight: 1.2 }}>
              {terminalName}
            </Typography>
            <Typography variant="caption" color="text.secondary" display="block">
              ID: <Box component="span" color="text.primary" fontWeight={500}>{siteId}</Box>
            </Typography>
            <Typography variant="caption" color="text.secondary" display="block">
              Name: <Box component="span" color="text.primary" fontWeight={500}>{siteName}</Box>
            </Typography>
          </CardContent>
        </Card>
      </Grid>

      {/* Card 2: IP address */}
      <Grid item xs={12} md={3}>
        <Card sx={cardSx}>
          <CardContent
            sx={{
              ...contentSx,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              textAlign: "center",
            }}
          >
            <LanIcon sx={{ fontSize: 28, color: "#14348D", mb: 0.5 }} />
            <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1 }}>
              IP Address
            </Typography>
            <Typography variant="body2" fontWeight={600} sx={{ overflowWrap: "anywhere" }}>
              {ipAddress}
            </Typography>
          </CardContent>
        </Card>
      </Grid>

      {/* Card 3: Status durations */}
      <Grid item xs={12} md={5}>
        <Card sx={cardSx}>
          <CardContent sx={contentSx}>
            <Typography variant="subtitle2" fontWeight={700} mb={1}>
              Status Duration
            </Typography>
            <Stack spacing={0.2}>
              {STATUS_ITEMS.map((item) => (
                <Typography
                  key={item.key}
                  variant="caption"
                  sx={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 0.5,
                    color: "text.secondary",
                    "& .duration-value": {
                      fontWeight: 600,
                      color: item.color,
                    },
                  }}
                >
                  <Box component="span" sx={{ fontWeight: 500, whiteSpace: 'nowrap' }}>
                    {item.label}:
                  </Box>
                  <Box component="span" className="duration-value">
                    {formatDuration(summary[item.key])}
                  </Box>
                </Typography>
              ))}
            </Stack>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
};

export default SiteAvailabilitySummary;