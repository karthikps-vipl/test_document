import React, { useState, useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  Button,
  Box,
  CircularProgress,
  Typography,
  Slide,
  Backdrop,
  Card,
  CardContent,
  IconButton,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import moment from "moment";
import _ from "lodash"; // Imported to match legacy grouping logic reliably
import MTable from "@/components/Reusable/Table/MTable";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";
import { FieldFactory } from "./FieldFactory";
import {
  FaultAxios,
  InventoryAxios,
  PerformanceAxios,
  TopologyAxios,
} from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST,
  FETCH_REAL_TIME_PERFORMANCE_DATA,
  GET_ALARM_TYPE_FOR_RESOURCE_LIST,
  LINK_CONFIGURATION,
} from "../../../../../RestAPI/url/endpoint";
import {
  executeReportFetch,
  ReportActionsRegistry,
} from "./ReportActionsRegistry";
import { REPORT_COLUMN_CONFIGS } from "./ReportColumnConfig";
import MPieChart from "../../../../../components/PieChart/MPieChart";
import Up_Arrow from "@/assets/SVGIcons/ALL_Reports_View.svg";
import ReusableRealTimeLineChart from "./ReusableRealTimeLineChart";
import { markRealtimeActive } from "@/store/features/Inventory/inventorySlice";
import { Close, Fullscreen, FullscreenExit } from "@mui/icons-material";
import Toast from "../../../../../components/Reusable/Toast/Toast";
import PerformanceRouter from "./performace/PerformanceRouter";
import {
  FETCH_LST_OF_RESOURCE_INFO_BASED_ON_SYSLOG_GIVEN_TERMINAL,
  FETCH_SEGMENT_DETAILS_BASED_ON_TERMINAL_TYPE,
  FETCH_SITEDETAILS_BY_TERMINALTYPE_ID,
  FIND_ALL_RESOURCE_FOR_GIVEN_TERMINAL_TYPE_AND_SEGMENT,
} from "@/RestAPI/url/cnmsEndPoint";
import SiteAvailabilitySummary from "./SiteAvailabilitySummary";
import SiteAvailabilityChart from "./SiteAvailabilityChart";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const ReportWorkspace = ({ activeTab }) => {
  const reduxResources =
    useSelector((state) => state.inventory?.resources) || [];
  const { fetchAllTerminalTypeAlongWithSite = [], fetchSiteDetails = [] } =
    useSelector((state) => state.remoteRepDetails || {});
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [cnmsSites, setCnmsSites] = useState([]);
  const [fetchingCnmsSites, setFetchingCnmsSites] = useState(false);
  const [segmentsList, setSegmentsList] = useState([]);
  const [severitiesList, setSeveritiesList] = useState([]);
  const [devicesList, setDevicesList] = useState([]);
  const [alarmsList, setAlarmsList] = useState([]);
  const [fetchingDevices, setFetchingDevices] = useState(false);
  const [fetchingAlarms, setFetchingAlarms] = useState(false);
  const [siteAvailabilityTerminalTypes, setSiteAvailabilityTerminalTypes] =
    useState([]);
  const [syslogDevices, setSyslogDevices] = useState([]);
  const [syslogSeverities, setSyslogSeverities] = useState([]);
  const [syslogFacilities, setSyslogFacilities] = useState([]);
  const [calculatedSummary, setCalculatedSummary] = useState(null);
  const [perfParams, setPerfParams] = useState([]);
  const [performanceDevices, setPerformanceDevices] = useState([]);
  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  const dispatch = useDispatch();
  const rnmsId = repDetails?.id;
  // const rtData = useSelector((state) => state.inventory.realtimePerformance);
  const [cnmsAlarmSegments, setCnmsAlarmSegments] = useState([]);
  const [cnmsAlarmDevices, setCnmsAlarmDevices] = useState([]);
  const [cnmsAlarmNames, setCnmsAlarmNames] = useState([]);
  const [cnmsLinkOptions, setCnmsLinkOptions] = useState([]);
  const [fetchingCnmsLinks, setFetchingCnmsLinks] = useState(false);
  const [fetchingCnmsAlarmSegments, setFetchingCnmsAlarmSegments] =
    useState(false);

  const [fetchingCnmsAlarmDevices, setFetchingCnmsAlarmDevices] =
    useState(false);

  const [fetchingCnmsAlarmNames, setFetchingCnmsAlarmNames] = useState(false);
  const [selectedSiteName, setSelectedSiteName] = useState("");
  const [selectedSummarySiteName, setSelectedSummarySiteName] = useState("");
  useEffect(() => {
    setFormData({});
    setReportData([]);
    setShowResults(false);
    setDevicesList([]);
    setAlarmsList([]);
    setSyslogDevices([]);
    setSyslogSeverities([]);
    setSyslogFacilities([]);
    setCalculatedSummary(null);
    setCnmsSites([]);
    setSiteAvailabilityTerminalTypes([]);
    setFetchingCnmsSites(false);
    setCnmsAlarmSegments([]);
    setCnmsAlarmDevices([]);
    setCnmsAlarmNames([]);

    setFetchingCnmsAlarmSegments(false);
    setFetchingCnmsAlarmDevices(false);
    setFetchingCnmsAlarmNames(false);

    setCnmsLinkOptions([]);
    setFetchingCnmsLinks(false);
  }, [activeTab]);

  const formattedReduxDevices = useMemo(() => {
    return reduxResources.map((r) => ({
      resourceId: r.resourceId,
      resourceName: r.resourceName || r.resourceDesc || "Unnamed Asset",
    }));
  }, [reduxResources]);

  console.log("reportData", reportData);
  const terminalTypeOptions = useMemo(() => {
    const raw = fetchAllTerminalTypeAlongWithSite;

    const terminalList = Array.isArray(raw) ? raw : Object.values(raw || {});

    return terminalList.map((terminal) => ({
      ...terminal,
      id: terminal.id,
      terminalTypeName: terminal.terminalTypeName,
    }));
  }, [fetchAllTerminalTypeAlongWithSite]);
  useEffect(() => {
    if (activeTab?.key !== "AlarmLog") return;
    const selected = formData.segmentName || [];
    if (selected.length === 0) {
      setDevicesList([]);
      return;
    }
    setFetchingDevices(true);
    InventoryAxios(FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST, "post", selected)
      .then((res) => setDevicesList(res?.data || res || []))
      .catch((err) => console.error("Alarm device load failed", err))
      .finally(() => setFetchingDevices(false));
  }, [formData.segmentName, activeTab]);

  useEffect(() => {
    if (activeTab?.key !== "AlarmLog") return;
    const selectedIds = formData.deviceName || [];
    if (selectedIds.length === 0) {
      setAlarmsList([]);
      return;
    }
    const filteredPayload = devicesList.filter((d) =>
      selectedIds.includes(d.resourceId)
    );
    setFetchingAlarms(true);
    FaultAxios(GET_ALARM_TYPE_FOR_RESOURCE_LIST, "post", filteredPayload);
    // .then((res) => setAlarmsList(res?.data || res || []))
    // .catch((err) => console.error("Alarm list load failed", err))
    // .finally(() => setFetchingAlarms(false));
    FaultAxios(GET_ALARM_TYPE_FOR_RESOURCE_LIST, "post", filteredPayload)
      .then((res) => {
        const rawData = res?.data || res || {};

        const alarmArray = Array.isArray(rawData)
          ? rawData
          : Object.values(rawData);

        const uniqueAlarms = Array.from(
          new Map(
            alarmArray
              .filter((alarm) => alarm?.alarmName)
              .map((alarm) => [alarm.alarmName, alarm])
          ).values()
        );

        setAlarmsList(uniqueAlarms);
      })
      .catch((err) => {
        console.error("Alarm list load failed", err);
        setAlarmsList([]);
      })
      .finally(() => setFetchingAlarms(false));
  }, [formData.deviceName, devicesList, activeTab]);

  useEffect(() => {
    const siteBasedReports = [
      "user_blocked_logs_cnms",
      "SiteAvailability",
      "db_SiteBackupLogReport",
      "db_SiteRestoreLogReport",
      "foreign_ip_report_cnms",
      "SiteMaintenance",
      "SiteReachability",
      "SiteRepDetails",
      "AlarmReportRNMS",
      "SystemLogCNMS",
    ];

    if (!siteBasedReports.includes(activeTab?.key)) {
      setCnmsSites([]);
      setFetchingCnmsSites(false);
      return;
    }

    // SiteRepDetails supports multiple terminal selections.
    if (activeTab.key === "SiteRepDetails") {
      const selectedTerminalIds = Array.isArray(formData.multipleTerminal)
        ? formData.multipleTerminal
        : formData.multipleTerminal
        ? [formData.multipleTerminal]
        : [];

      if (selectedTerminalIds.length === 0) {
        setCnmsSites([]);
        setFetchingCnmsSites(false);
        return;
      }

      // Filter the sites already available in Redux.
      const filteredSites = fetchSiteDetails.filter((site) =>
        selectedTerminalIds.some(
          (terminalId) =>
            String(terminalId) === String(site?.imTerminalType?.id)
        )
      );

      // Remove duplicate sites using siteId.
      const uniqueSites = Array.from(
        new Map(
          filteredSites
            .filter((site) => site?.siteId != null)
            .map((site) => [String(site.siteId), site])
        ).values()
      );

      setCnmsSites(uniqueSites);
      setFetchingCnmsSites(false);

      // Important: do not call the site API for SiteRepDetails.
      return;
    }

    // Existing single-terminal behavior for every other report.
    const terminalTypeId = formData.siteType;

    if (!terminalTypeId) {
      setCnmsSites([]);
      setFetchingCnmsSites(false);
      return;
    }

    let cancelled = false;

    const fetchSites = async () => {
      setFetchingCnmsSites(true);

      try {
        const res = await InventoryAxios(
          `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${terminalTypeId}`,
          "get"
        );

        const raw = res?.data ?? res ?? {};

        const sites = Array.isArray(raw) ? raw : Object.values(raw || {});

        if (!cancelled) {
          setCnmsSites(sites);
        }
      } catch (error) {
        console.error("Site load failed:", error);

        if (!cancelled) {
          setCnmsSites([]);
        }
      } finally {
        if (!cancelled) {
          setFetchingCnmsSites(false);
        }
      }
    };

    fetchSites();

    return () => {
      cancelled = true;
    };
  }, [
    formData.siteType,
    formData.multipleTerminal,
    activeTab?.key,
    fetchSiteDetails,
  ]);

  useEffect(() => {
    if (activeTab?.key !== "RealTimeSystemLevel") return;

    if (!formData.performanceDevice) {
      setPerfParams([]);
      return;
    }

    const selectedDevice = performanceDevices.find(
      (d) => String(d.resourceId) === String(formData.performanceDevice)
    );

    const resourceTypeId =
      selectedDevice?.resourceTypeId ||
      selectedDevice?.imResourceType?.resourceTypeId ||
      selectedDevice?.typeId;

    if (!resourceTypeId) return;

    PerformanceAxios(
      `/PerformanceMgmt/fetchPerfParamOfResourceType/${resourceTypeId}`,
      "get"
    )
      .then((res) => {
        const data = res?.data || res || {};

        console.log("Resource Type:", resourceTypeId);

        console.log("Performance Param API Response:", data);

        const formatted = Array.isArray(data) ? data : Object.values(data);

        console.log("Formatted Params:", formatted);

        setPerfParams(formatted);
      })
      .catch(console.error);
  }, [formData.performanceDevice, performanceDevices, activeTab]);
  useEffect(() => {
    if (activeTab?.key !== "AlarmReportRNMS") return;

    const terminalId = formData.siteType;

    setCnmsAlarmSegments([]);
    setCnmsAlarmDevices([]);
    setCnmsAlarmNames([]);

    if (!terminalId) {
      return;
    }

    let cancelled = false;

    const fetchSegments = async () => {
      setFetchingCnmsAlarmSegments(true);

      try {
        const res = await InventoryAxios(
          `${FETCH_SEGMENT_DETAILS_BASED_ON_TERMINAL_TYPE}/${terminalId}`,
          "get"
        );

        const raw = res?.data ?? res ?? {};
        const segments = Array.isArray(raw) ? raw : Object.values(raw || {});

        // Keep segment ID and name together from imSegmentInfo.
        const uniqueSegments = Array.from(
          new Map(
            segments
              .filter((item) => item?.imSegmentInfo?.segmentId != null)
              .map((item) => {
                const segment = item.imSegmentInfo;

                return [
                  String(segment.segmentId),
                  {
                    segmentId: segment.segmentId,
                    segmentName: segment.segmentName,
                    label: segment.segmentName,
                    value: segment.segmentId,
                  },
                ];
              })
          ).values()
        );

        if (!cancelled) {
          setCnmsAlarmSegments(uniqueSegments);
        }
      } catch (error) {
        console.error("CNMS alarm segment load failed:", error);

        if (!cancelled) {
          setCnmsAlarmSegments([]);
        }
      } finally {
        if (!cancelled) {
          setFetchingCnmsAlarmSegments(false);
        }
      }
    };

    fetchSegments();

    return () => {
      cancelled = true;
    };
  }, [activeTab?.key, formData.siteType]);
  useEffect(() => {
    if (activeTab?.key !== "AlarmReportRNMS") return;

    const terminalId = formData.siteType;

    const selectedSegmentIds = (
      Array.isArray(formData.segmentName)
        ? formData.segmentName
        : formData.segmentName != null
        ? [formData.segmentName]
        : []
    )
      .map((item) =>
        item && typeof item === "object"
          ? item.segmentId ?? item.value ?? item.imSegmentInfo?.segmentId
          : item
      )
      .filter((id) => id != null && String(id).trim() !== "");

    setCnmsAlarmDevices([]);
    setCnmsAlarmNames([]);

    if (!terminalId || selectedSegmentIds.length === 0) {
      return;
    }

    let cancelled = false;

    const fetchDevices = async () => {
      setFetchingCnmsAlarmDevices(true);

      try {
        const res = await InventoryAxios(
          `${FIND_ALL_RESOURCE_FOR_GIVEN_TERMINAL_TYPE_AND_SEGMENT}/${terminalId}`,
          "post",
          selectedSegmentIds
        );

        const raw = res?.data ?? res ?? {};
        const devices = Array.isArray(raw) ? raw : Object.values(raw || {});

        const uniqueDevices = Array.from(
          new Map(
            devices
              .filter((device) => device?.resourceId != null)
              .map((device) => [String(device.resourceId), device])
          ).values()
        );

        if (!cancelled) {
          setCnmsAlarmDevices(uniqueDevices);
        }
      } catch (error) {
        console.error("CNMS alarm device load failed:", error);

        if (!cancelled) {
          setCnmsAlarmDevices([]);
        }
      } finally {
        if (!cancelled) {
          setFetchingCnmsAlarmDevices(false);
        }
      }
    };

    fetchDevices();

    return () => {
      cancelled = true;
    };
  }, [activeTab?.key, formData.siteType, formData.segmentName]);
  useEffect(() => {
    if (activeTab?.key !== "AlarmReportRNMS") return;

    const selectedDeviceIds = (
      Array.isArray(formData.deviceName)
        ? formData.deviceName
        : formData.deviceName != null
        ? [formData.deviceName]
        : []
    ).map((item) =>
      item && typeof item === "object" ? item.resourceId ?? item.value : item
    );

    setCnmsAlarmNames([]);

    if (selectedDeviceIds.length === 0) {
      return;
    }

    const selectedDevices = cnmsAlarmDevices.filter((device) =>
      selectedDeviceIds.some((id) => String(id) === String(device.resourceId))
    );

    if (selectedDevices.length === 0) {
      return;
    }

    let cancelled = false;

    const fetchAlarmNames = async () => {
      setFetchingCnmsAlarmNames(true);

      try {
        const res = await FaultAxios(
          GET_ALARM_TYPE_FOR_RESOURCE_LIST,
          "post",
          selectedDevices
        );

        const raw = res?.data ?? res ?? {};
        const alarms = Array.isArray(raw) ? raw : Object.values(raw || {});

        const uniqueAlarms = Array.from(
          new Map(
            alarms
              .filter((alarm) => alarm?.alarmName)
              .map((alarm) => [
                alarm.alarmName,
                {
                  ...alarm,
                  label: alarm.alarmName,
                  value: alarm.alarmName,
                },
              ])
          ).values()
        );

        if (!cancelled) {
          setCnmsAlarmNames(uniqueAlarms);
        }
      } catch (error) {
        console.error("CNMS alarm names load failed:", error);

        if (!cancelled) {
          setCnmsAlarmNames([]);
        }
      } finally {
        if (!cancelled) {
          setFetchingCnmsAlarmNames(false);
        }
      }
    };

    fetchAlarmNames();

    return () => {
      cancelled = true;
    };
  }, [activeTab?.key, formData.deviceName, cnmsAlarmDevices]);
  useEffect(() => {
    if (activeTab?.key !== "SystemLogCNMS") return;

    const terminalId = formData.siteType;

    setSyslogDevices([]);

    // Clear device selection when terminal changes.
    setFormData((prev) => ({
      ...prev,
      deviceName: [],
    }));

    if (!terminalId) return;

    let cancelled = false;

    const fetchDevices = async () => {
      setFetchingDevices(true);

      try {
        const res = await InventoryAxios(
          `${FETCH_LST_OF_RESOURCE_INFO_BASED_ON_SYSLOG_GIVEN_TERMINAL}/${terminalId}`,
          "get"
        );

        const raw = res?.data ?? res ?? {};
        const devices = Array.isArray(raw) ? raw : Object.values(raw || {});

        const uniqueDevices = Array.from(
          new Map(
            devices
              .filter((device) => device?.resourceId != null)
              .map((device) => [
                String(device.resourceId),
                {
                  ...device,
                  label:
                    device.resourceName ||
                    device.resourceDesc ||
                    "Unnamed Device",
                  value: device.resourceId,
                },
              ])
          ).values()
        );

        if (!cancelled) {
          setSyslogDevices(uniqueDevices);
        }
      } catch (error) {
        console.error("CNMS syslog device load failed:", error);

        if (!cancelled) {
          setSyslogDevices([]);
        }
      } finally {
        if (!cancelled) {
          setFetchingDevices(false);
        }
      }
    };

    fetchDevices();

    return () => {
      cancelled = true;
    };
  }, [activeTab?.key, formData.siteType]);
  const linkCnmsSiteOptions = useMemo(() => {
    const sites = Array.isArray(fetchSiteDetails) ? fetchSiteDetails : [];

    return Array.from(
      new Map(
        sites
          .filter(
            (site) => site?.siteId != null && site?.imTerminalType?.id != null
          )
          .map((site) => [
            String(site.siteId),
            {
              ...site,
              label: site.siteName || site.siteNickName || site.siteId,
              value: site.siteId,
            },
          ])
      ).values()
    );
  }, [fetchSiteDetails]);

  useEffect(() => {
    if (activeTab?.key !== "LinkCnms") return;

    const selectedSiteId =
      typeof formData.siteName === "object"
        ? formData.siteName?.siteId
        : formData.siteName;

    const selectedSite = linkCnmsSiteOptions.find(
      (site) => String(site.siteId) === String(selectedSiteId)
    );

    setSelectedSiteName(selectedSite?.siteName);
    const terminalTypeId = selectedSite?.imTerminalType?.id;

    setCnmsLinkOptions([]);
    setFormData((prev) => ({
      ...prev,
      link: "",
    }));

    if (!selectedSiteId || !terminalTypeId) {
      setFetchingCnmsLinks(false);
      return;
    }

    let cancelled = false;

    const fetchLinks = async () => {
      setFetchingCnmsLinks(true);

      try {
        const response = await TopologyAxios(
          `${LINK_CONFIGURATION}/${terminalTypeId}`,
          "get"
        );

        const raw = response?.data ?? response ?? {};
        const links = Array.isArray(raw) ? raw : Object.values(raw || {});

        const uniqueLinks = Array.from(
          new Map(
            links
              .filter((item) => item?.linkId != null)
              .map((item) => [
                String(item.linkId),
                {
                  ...item,
                  label: item.linkName || String(item.linkId),
                  value: item.linkId,
                },
                console.log("uniqueLinks", links),
              ])
          ).values()
        );

        if (!cancelled) {
          setCnmsLinkOptions(uniqueLinks);
        }
      } catch (error) {
        console.error("CNMS link options load failed:", error);

        if (!cancelled) {
          setCnmsLinkOptions([]);
        }
      } finally {
        if (!cancelled) {
          setFetchingCnmsLinks(false);
        }
      }
    };

    fetchLinks();

    return () => {
      cancelled = true;
    };
  }, [activeTab?.key, formData.siteName, linkCnmsSiteOptions]);
  useEffect(() => {
    if (activeTab?.key !== "LinkSummary") return;

    const selectedSiteId =
      typeof formData.siteName === "object"
        ? formData.siteName?.siteId
        : formData.siteName;

    const selectedSite = linkCnmsSiteOptions.find(
      (site) => String(site.siteId) === String(selectedSiteId)
    );

    const displayName = selectedSite
      ? `${selectedSite.siteName || selectedSite.siteNickName || ""}_${
          selectedSite.remoteNumber ?? selectedSite.remoteNo ?? ""
        }`
      : "";

    setSelectedSummarySiteName(displayName);
  }, [activeTab?.key, formData.siteName, linkCnmsSiteOptions]);

  const handleFieldChange = (fieldName, newValue) => {
    setFormData((prevState) => {
      const updatedState = { ...prevState, [fieldName]: newValue };
      if (fieldName === "segmentName") {
        updatedState["deviceName"] = [];
        updatedState["alarmName"] = [];
      }
      if (fieldName === "deviceName" || fieldName === "deviceIdList") {
        updatedState["alarmName"] = [];
      }
      if (fieldName === "performanceDevice") {
        updatedState["performanceParameter"] = "";
      }
      if (fieldName === "siteType") {
        updatedState["siteName"] = [];
        setCnmsSites([]);
      }
      if (fieldName === "multipleTerminal") {
        updatedState.siteName = [];
        setCnmsSites([]);
      }
      if (activeTab?.key === "AlarmReportRNMS") {
        if (fieldName === "siteType") {
          updatedState.siteName = [];
          updatedState.segmentName = [];
          updatedState.deviceName = [];
          updatedState.alarmName = [];

          setCnmsAlarmSegments([]);
          setCnmsAlarmDevices([]);
          setCnmsAlarmNames([]);
          setCnmsSites([]);
        }

        if (fieldName === "segmentName") {
          updatedState.deviceName = [];
          updatedState.alarmName = [];

          setCnmsAlarmDevices([]);
          setCnmsAlarmNames([]);
        }

        if (fieldName === "deviceName") {
          updatedState.alarmName = [];
          setCnmsAlarmNames([]);
        }
      }
      return updatedState;
    });
  };
  const toBoolean = (value) => {
    if (typeof value === "boolean") {
      return value;
    }

    if (typeof value === "string") {
      return value.toLowerCase() === "true";
    }

    if (typeof value === "number") {
      return value === 1;
    }

    return false;
  };
  const computeReadableDuration = (secondsValue) => {
    const dur = moment.duration(Number(secondsValue) || 0, "seconds");
    return `${dur.days()} days, ${dur.hours()} hours, ${dur.minutes()} minutes, ${dur.seconds()} seconds`;
  };
  const getSelectedRangeSeconds = (fromDate, toDate) => {
    if (!fromDate || !toDate) return 0;

    const from = moment(fromDate);
    const to = moment(toDate);

    if (!from.isValid() || !to.isValid() || to.isBefore(from)) {
      return 0;
    }

    return to.diff(from, "seconds");
  };
  const handleFormSubmit = async () => {
    if (!activeTab?.key) return;
    setLoading(true);
    try {
      const response = await executeReportFetch(
        activeTab.key,
        formData,
        rnmsId,
        { isCnms }
      );

      // const data = response?.data || response || [];
      // const rawRows = Array.isArray(data) ? data : [];
      const data = response?.data || response || {};
      let rawRows = [];

      if (Array.isArray(data)) {
        rawRows = data;
      } else if (data && typeof data === "object") {
        rawRows = Object.values(data);
      } else if (data != null) {
        rawRows = [data];
      }

      // Empty arrays and empty objects should both count as no data.
      const isEmptyResponse =
        data == null ||
        rawRows.length === 0 ||
        rawRows.every(
          (row) =>
            row == null ||
            (typeof row === "object" &&
              !Array.isArray(row) &&
              Object.keys(row).length === 0)
        );

      if (isEmptyResponse && activeTab?.key !== "RealTimeSystemLevel") {
        Toast("No Data", "No records found for the selected criteria", "info");

        setReportData([]);
        setCalculatedSummary(null);
        setShowResults(false);

        return;
      }
      ///sonar
      // const auditSiteInfo =
      //   (activeTab?.key === "AuditLogReport" ||
      //     activeTab?.key === "user_blocked_logs_cnms" ||
      //     activeTab?.key === "foreign_ip_report_cnms") &&
      //   isCnms &&
      //   rawRows.length > 0
      //     ? {
      //         // siteName: rawRows[0]?.siteName || "N/A",
      //         ...(activeTab?.key === "foreign_ip_report_cnms"
      //           ? { terminalTypeName: rawRows[0]?.terminalTypeName || "N/A" }
      //           : { siteName: rawRows[0]?.siteName || "N/A" }),
      //         siteId: rawRows[0]?.siteId || "N/A",
      //       }
      //     : null;

      if (
        activeTab.key === "DeviceMaintenance" ||
        activeTab.key === "DeviceAvailability"
      ) {
        const selectedDeviceLabel =
          formattedReduxDevices.find(
            (d) => String(d.resourceId) === String(formData.deviceName)
          )?.resourceName || "N/A";

        const toBoolean = (value) => {
          if (typeof value === "boolean") return value;

          if (typeof value === "string") {
            return value.toLowerCase() === "true";
          }

          if (typeof value === "number") {
            return value === 1;
          }

          return false;
        };

        const formattedRows = rawRows.map((row, index) => {
          const statusValue =
            row.isMaintenance !== undefined ? row.isMaintenance : row.available;

          return {
            ...row,
            sno: index + 1,

            resourceIpaddress: row.resourceIpaddress || "N/A",

            userDetail: row.userDetail || "N/A",

            // Normalize status
            isMaintenance: toBoolean(statusValue),

            // IMPORTANT: API duration is seconds
            durationSeconds: Number(row.durationSeconds ?? row.duration ?? 0),
          };
        });

        /*
         * Group using the normalized boolean.
         */
        const groupedData = _.groupBy(
          formattedRows,
          (row) => row.isMaintenance
        );

        /*
         * ALL calculations remain in seconds.
         */
        const totalTrueSeconds = (groupedData.true || []).reduce(
          (total, row) => total + Number(row.durationSeconds || 0),
          0
        );

        const totalFalseSeconds = (groupedData.false || []).reduce(
          (total, row) => total + Number(row.durationSeconds || 0),
          0
        );

        if (activeTab.key === "DeviceAvailability") {
          const availableSeconds = totalTrueSeconds;
          const notAvailableSeconds = totalFalseSeconds;

          setCalculatedSummary({
            deviceName: selectedDeviceLabel,

            label1: "Available Time",
            value1: computeReadableDuration(availableSeconds),

            label2: "Not Available Time",
            value2: computeReadableDuration(notAvailableSeconds),

            color1: "#1b5e20",
            color2: "#c62828",

            availableSeconds,
            notAvailableSeconds,

            pieData: [
              {
                name: "Available",
                value: availableSeconds,
                color: "#1b5e20",
              },
              {
                name: "Not Available",
                value: notAvailableSeconds,
                color: "#c62828",
              },
            ].filter((item) => item.value > 0),
          });
        } else {
          const totalMaintenanceSeconds = totalTrueSeconds;

          // Total duration selected by the user
          const selectedRangeSeconds = getSelectedRangeSeconds(
            formData.fromDate,
            formData.toDate
          );

          // Available = Selected Range - Maintenance
          const availableSeconds = Math.max(
            selectedRangeSeconds - totalMaintenanceSeconds,
            0
          );

          // Prevent maintenance from exceeding selected range
          const maintenanceSeconds = Math.min(
            totalMaintenanceSeconds,
            selectedRangeSeconds
          );

          setCalculatedSummary({
            deviceName: selectedDeviceLabel,

            label1: "Maintenance Time",
            value1: computeReadableDuration(maintenanceSeconds),

            label2: "Available Time",
            value2: computeReadableDuration(availableSeconds),

            // Maintenance = Orange
            color1: "#f57c00",

            // Available = Green
            color2: "#2e7d32",

            availableSeconds,
            notAvailableSeconds: maintenanceSeconds,

            pieData: [
              {
                name: "Maintenance",
                value: maintenanceSeconds,
                color: "#f57c00",
              },
              {
                name: "Available",
                value: availableSeconds,
                color: "#2e7d32",
              },
            ].filter((item) => item.value > 0),
          });
        }

        const targetFromDate = formData.fromDate || formData.startDate;

        const targetToDate = formData.toDate || formData.endDate;

        setCalculatedSummary((prev) => ({
          ...prev,
          fromDate: moment(targetFromDate).format("YYYY-MM-DD HH:mm:ss"),
          toDate: moment(targetToDate).format("YYYY-MM-DD HH:mm:ss"),
        }));

        setReportData(formattedRows);
      } else if (activeTab.key === "SiteMaintenance") {
        const rows = rawRows.map((row, index) => ({
          ...row,
          sno: index + 1,
          durationSeconds: Number(row.durationSeconds ?? 0),
          isMaintenance: toBoolean(row.isMaintenance),
        }));

        // Sum only durations belonging to maintenance records.
        const totalMaintenanceSeconds = rows.reduce(
          (total, row) =>
            total + (row.isMaintenance ? Number(row.durationSeconds || 0) : 0),
          0
        );

        // Calculate the total selected range in seconds.
        const selectedRangeSeconds = getSelectedRangeSeconds(
          formData.fromDate,
          formData.toDate
        );

        // Prevent maintenance from exceeding the selected range.
        const maintenanceSeconds = Math.min(
          totalMaintenanceSeconds,
          selectedRangeSeconds
        );

        const availableSeconds = Math.max(
          selectedRangeSeconds - maintenanceSeconds,
          0
        );

        const firstRow = rows[0] || {};

        setCalculatedSummary({
          isSiteMaintenance: true,

          terminalTypeName: firstRow.terminalTypeName || "N/A",
          siteId: firstRow.siteId || formData.siteName || "N/A",
          siteName: firstRow.siteName || "N/A",

          label1: "Maintenance Time",
          value1: computeReadableDuration(maintenanceSeconds),

          label2: "Available Time",
          value2: computeReadableDuration(availableSeconds),

          color1: "#f57c00",
          color2: "#2e7d32",

          availableSeconds,
          notAvailableSeconds: maintenanceSeconds,

          pieData: [
            {
              name: "Maintenance",
              value: maintenanceSeconds,
              color: "#f57c00",
            },
            {
              name: "Available",
              value: availableSeconds,
              color: "#2e7d32",
            },
          ].filter((item) => item.value > 0),

          fromDate: moment(formData.fromDate).format("YYYY-MM-DD HH:mm:ss"),
          toDate: moment(formData.toDate).format("YYYY-MM-DD HH:mm:ss"),
        });

        setReportData(rows);
      } else if (activeTab.key === "Link") {
        let upSec = 0,
          downSec = 0,
          oprDownSec = 0,
          unknownSec = 0;
        let activeLinkTypeName = "Selected Link";

        const rows = rawRows.map((row, idx) => {
          const durVal = Number(row.duration) || 0;
          if (row.linkTypeName) activeLinkTypeName = row.linkTypeName;

          if (row.linkStatus === 1) upSec += durVal;
          else if (row.linkStatus === 0) downSec += durVal;
          else if (row.linkStatus === 2) oprDownSec += durVal;
          else unknownSec += durVal;

          return {
            ...row,
            sno: idx + 1,
          };
        });

        const hasLinkData =
          rows.length > 0 && upSec + downSec + oprDownSec + unknownSec > 0;

        setCalculatedSummary({
          deviceName: activeLinkTypeName,
          isLinkTab: true, // Flag to identify this tab format in the JSX below
          linkStatusBreakdown: [
            {
              label: "Up Time",
              value: computeReadableDuration(upSec),
              color: "#2e7d32",
            },
            {
              label: "Down Time",
              value: computeReadableDuration(downSec),
              color: "#d32f2f",
            },
            {
              label: "Operational Down Time",
              value: computeReadableDuration(oprDownSec),
              color: "#ed6c02",
            },
            {
              label: "Unknown Time",
              value: computeReadableDuration(unknownSec),
              color: "#b8860b",
            },
          ],
          pieData: hasLinkData
            ? [
                { name: "Up", value: upSec, color: "#2e7d32" },
                { name: "Down", value: downSec, color: "#d32f2f" },
                { name: "OprDown", value: oprDownSec, color: "#ed6c02" },
                { name: "Unknown", value: unknownSec, color: "#b8860b" },
              ].filter((item) => item.value > 0)
            : [],
        });

        setReportData(rows);
      } else if (activeTab.key === "LinkCnms") {
        let upSec = 0;
        let downSec = 0;
        let oprDownSec = 0;
        let unknownSec = 0;

        const firstRow = rawRows[0] || {};
        console.log("firstRow", firstRow);

        const currentLinkId = firstRow.linkTypeId || firstRow.linkId;
        const matchedLinkOption = cnmsLinkOptions?.find(
          (option) => option.linkId === currentLinkId
        );
        const displayLinkName = matchedLinkOption
          ? matchedLinkOption.linkName
          : firstRow.linkTypeName || firstRow.linkType || "N/A";

        const rows = rawRows.map((row, index) => {
          const duration = Math.max(0, Number(row.duration) || 0);
          const status = Number(row.linkStatus);

          if (status === 1) upSec += duration;
          else if (status === 0) downSec += duration;
          else if (status === 2) oprDownSec += duration;
          else if (status === 3) unknownSec += duration;

          return {
            ...row,
            sno: index + 1,
            linkStatus: [0, 1, 2, 3].includes(status) ? status : 3,
          };
        });

        const pieData = [
          { name: "Up", value: upSec, color: "#16a34a" },
          { name: "Down", value: downSec, color: "#FF1A1DA6" },
          { name: "OprDown", value: oprDownSec, color: "#ed6c02" },
          { name: "Unknown", value: unknownSec, color: "#b8860b" },
        ].filter((item) => item.value > 0);

        const fromDate = formData.fromDate || formData.startDate;
        const toDate = formData.toDate || formData.endDate;
        console.log("cnmsLinkOptions", cnmsLinkOptions);
        setCalculatedSummary({
          isLinkTab: true,
          isCnmsLinkTab: true,

          // linkTypeName: firstRow.linkTypeName || firstRow.linkType || "N/A",
          linkTypeName: displayLinkName,
          siteId: firstRow.siteId || "N/A",
          siteName: selectedSiteName || "N/A",

          fromDate: fromDate
            ? moment(fromDate).format("YYYY-MM-DD HH:mm:ss")
            : "N/A",

          toDate: toDate ? moment(toDate).format("YYYY-MM-DD HH:mm:ss") : "N/A",

          linkStatusBreakdown: [
            {
              label: "Up",
              value: computeReadableDuration(upSec),
              color: "#16a34a",
            },
            {
              label: "Down",
              value: computeReadableDuration(downSec),
              color: "#FF1A1DA6",
            },
            {
              label: "OprDown",
              value: computeReadableDuration(oprDownSec),
              color: "#ed6c02",
            },
            {
              label: "Unknown",
              value: computeReadableDuration(unknownSec),
              color: "#b8860b",
            },
          ],

          availableSeconds: upSec,
          notAvailableSeconds: downSec,
          pieData,
        });

        setReportData(rows);
      } else if (activeTab.key === "SiteAvailability") {
        console.log("rawRowsrawRows", rawRows);

        const rows = rawRows.map((row, index) => ({
          ...row,
          sno: index + 1,
        }));

        setCalculatedSummary({
          isSiteAvailability: true,
        });

        setReportData(rows);
      } else if (activeTab.key === "SiteReachability") {
        const rows = rawRows.map((row, index) => ({
          ...row,
          sno: index + 1,

          siteId: row?.siteId || "N/A",
          siteName: row?.siteName || "N/A",
          resourceIp: row?.resourceIp || "N/A",
          alarmDescription: row?.alarmDescription || "N/A",

          severity:
            row?.severity !== undefined && row?.severity !== null
              ? Number(row.severity)
              : null,

          alarmState:
            row?.alarmState !== undefined && row?.alarmState !== null
              ? Number(row.alarmState)
              : null,

          workflow:
            row?.workflow !== undefined && row?.workflow !== null
              ? Number(row.workflow)
              : null,

          workflowComments: row?.workflowComments || "",

          dateTime: row?.dateTime || null,
        }));

        setReportData(rows);
      } else if (
        // activeTab.key === "SystemUptime" ||
        activeTab.key === "UptimeReportRNMS"
      ) {
        let upSeconds = 0;
        let downSeconds = 0;

        const rows = rawRows.map((row, index) => {
          const duration = Number(row.duration || 0);

          if (row.status === true) {
            upSeconds += duration;
          } else if (row.status === false) {
            downSeconds += duration;
          }

          return {
            ...row,
            sno: index + 1,
          };
        });

        setCalculatedSummary({
          isUptimeTab: true,

          label1: "Uptime",
          value1: computeReadableDuration(upSeconds),

          label2: "Downtime",
          value2: computeReadableDuration(downSeconds),

          color1: "#2e7d32",
          color2: "#d32f2f",

          availableSeconds: upSeconds,
          notAvailableSeconds: downSeconds,

          pieData: [
            {
              name: "Uptime",
              value: upSeconds,
              color: "#2e7d32",
            },
            {
              name: "Downtime",
              value: downSeconds,
              color: "#d32f2f",
            },
          ].filter((item) => item.value > 0),
        });

        setReportData(rows);
      } else if (activeTab.key === "RealTimeSystemLevel") {
        const payload = {
          resourceInfoBean: {
            resourceId: formData.performanceDevice,
          },
          perfParamInfoBean: {
            paramId: Number(formData.performanceParameter),
          },
          interval: formData.interval || "30",
        };

        // 1. call start API
        await PerformanceAxios(
          FETCH_REAL_TIME_PERFORMANCE_DATA,
          "post",
          payload
        );

        // 2. mark active stream in redux
        // const key = `${formData.performanceDevice}_${formData.performanceParameter}`;
        const key = `${String(formData.performanceDevice)}_${String(
          formData.performanceParameter
        )}`;

        dispatch(markRealtimeActive(key));

        setShowResults(true);
        setLoading(false);
        return;
      } else if (activeTab.key === "LinkSummary") {
        const rows = rawRows.map((row, index) => ({
          ...row,
          sno: index + 1,
          linkTypeName: row?.linkTypeName || "Unknown Link",
          uptimePercent: Number(row?.uptimePercent ?? 0),
          downTimePercent: Number(row?.downTimePercent ?? 0),
          opDownTimePercent: Number(row?.opDownTimePercent ?? 0),
        }));

        // Get the exact site ID used in the API endpoint.
        const selectedSiteId =
          typeof formData.siteName === "object"
            ? formData.siteName?.siteId ?? formData.siteName?.value ?? ""
            : formData.siteName ?? "";

        const fromDate = formData.fromDate || formData.startDate;
        const toDate = formData.toDate || formData.endDate;

        setCalculatedSummary({
          isLinkTab: true,
          isCnmsLinkTab: false,

          // Display the selected site ID from the endpoint.
          siteId: String(selectedSiteId),

          siteName: selectedSummarySiteName || "N/A",

          fromDate: fromDate
            ? moment(fromDate).format("YYYY-MM-DD HH:mm:ss")
            : "N/A",

          toDate: toDate ? moment(toDate).format("YYYY-MM-DD HH:mm:ss") : "N/A",
        });

        setReportData(rows);
      } else {
        setReportData(rawRows);
      }
      Toast("Success", "Report loaded successfully", "success");
      setShowResults(true);
    } catch (error) {
      console.error("Failed to fetch report data:", error);
      if (error.response && error.response.status === 400) {
        Toast("Bad Request", "Invalid request parameters provided.", "error");
      } else {
        // Handle other generic errors (network, 500, etc.)
        Toast("Error", "An error occurred while fetching data.", "error");
      }

      setReportData([]);
      setShowResults(false);
    } finally {
      setLoading(false);
    }
  };
  const handleStopRealtime = async () => {
    setShowResults(false);
  };
  const isFormInvalid = () => {
    if (!activeTab?.fields?.length) return true;
    return activeTab.fields.some((field) => {
      const value = formData[field];
      // if (value === undefined || value === null) return true;
      // if (typeof value === "string" && value.trim() === "") return true;
      // if (Array.isArray(value) && value.length === 0) {
      //   return true;
      // }
      // return false;
      return (
        value === undefined ||
        value === null ||
        (typeof value === "string" && value.trim() === "") ||
        (Array.isArray(value) && value.length === 0)
      );
    });
  };

  const activeColumns = useMemo(
    () => REPORT_COLUMN_CONFIGS[activeTab?.key] || [],
    [activeTab]
  );
  const activeRegistryConfig = ReportActionsRegistry[activeTab?.key];
  const computedReportTitle = useMemo(
    () => activeTab?.label || "Report",
    [activeTab]
  );

  const fetchDropdownOverrides = (fieldName) => {
    if (
      (activeTab?.key === "DeviceMaintenance" ||
        activeTab?.key === "DeviceAvailability") &&
      fieldName === "deviceName"
    ) {
      return formattedReduxDevices;
    }
    if (activeTab?.key === "AlarmLog") {
      if (fieldName === "segmentName")
        return segmentsList.length ? segmentsList : null;
      if (fieldName === "deviceName") return devicesList;
      if (fieldName === "alarmName") return alarmsList;
      if (fieldName === "severities")
        return severitiesList.length ? severitiesList : null;
    }
    if (activeTab?.key === "SiteReachability") {
      if (fieldName === "severities")
        return severitiesList.length ? severitiesList : null;
    }
    if (activeTab?.key === "SystemLogRNMS") {
      if (fieldName === "deviceName")
        return syslogDevices.length ? syslogDevices : null;
      if (fieldName === "syslogSeverities")
        return syslogSeverities.length ? syslogSeverities : null;
      if (fieldName === "facilities")
        return syslogFacilities.length ? syslogFacilities : null;
    }
    if (activeTab?.key === "user_blocked_logs_cnms") {
      if (fieldName === "siteType") {
        return terminalTypeOptions;
      }

      if (fieldName === "siteName") {
        return cnmsSites;
      }
    }
    if (activeTab?.key === "SiteRepDetails") {
      if (fieldName === "multipleTerminal") {
        return terminalTypeOptions;
      }

      if (fieldName === "siteName") {
        return cnmsSites;
      }
    }
    if (activeTab?.key === "AlarmReportRNMS") {
      if (fieldName === "siteType") {
        return siteAvailabilityTerminalTypes;
      }

      if (fieldName === "siteName") {
        return cnmsSites;
      }

      if (fieldName === "segmentName") {
        return cnmsAlarmSegments;
      }

      if (fieldName === "deviceName") {
        return cnmsAlarmDevices;
      }

      if (fieldName === "alarmName") {
        return cnmsAlarmNames;
      }

      if (fieldName === "severities") {
        return severitiesList.length ? severitiesList : null;
      }
    }
    if (activeTab?.key === "SystemLogCNMS") {
      if (fieldName === "siteType") {
        return siteAvailabilityTerminalTypes;
      }

      if (fieldName === "siteName") {
        return cnmsSites;
      }

      if (fieldName === "deviceName") {
        return syslogDevices;
      }

      if (fieldName === "syslogSeverities") {
        return syslogSeverities;
      }

      if (fieldName === "facilities") {
        return syslogFacilities;
      }
    }
    if (activeTab?.key === "LinkCnms" || activeTab?.key === "LinkSummary") {
      if (fieldName === "siteName") {
        return linkCnmsSiteOptions;
      }

      if (activeTab?.key === "LinkCnms" && fieldName === "link") {
        return cnmsLinkOptions;
      }
    }
    /*
     * SiteAvailability
     *
     * Terminal = API
     * Site Name = API
     */
    if (activeTab?.key === "SiteAvailability") {
      if (fieldName === "siteType") {
        return siteAvailabilityTerminalTypes;
      }

      if (fieldName === "siteName") {
        return cnmsSites;
      }
    }

    /*
     * db_SiteBackupLogReport
     * db_SiteRestoreLogReport
     * foreign_ip_report_cnms
     *
     * Terminal = API
     * Site Name = API
     */
    if (
      activeTab?.key === "db_SiteBackupLogReport" ||
      activeTab?.key === "db_SiteRestoreLogReport" ||
      activeTab?.key === "foreign_ip_report_cnms" ||
      activeTab?.key === "SiteMaintenance" ||
      activeTab?.key === "SiteReachability"
    ) {
      if (fieldName === "siteType") {
        return siteAvailabilityTerminalTypes;
      }

      if (fieldName === "siteName") {
        return cnmsSites;
      }
    }
    if (activeTab?.key === "RealTimeSystemLevel") {
      if (fieldName === "performanceDevice") {
        return performanceDevices?.length
          ? performanceDevices.map((d) => ({
              resourceId: d.resourceId,
              resourceName: d.resourceName || d.name,
            }))
          : [];
      }
      if (fieldName === "performanceParameter") return perfParams;
    }
    return null;
  };

  const displayFromDate = formData.fromDate || formData.startDate;
  const displayToDate = formData.toDate || formData.endDate;
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const sanitized_name_custom = computedReportTitle
    .replace(/\s+/g, "_")
    .toUpperCase();

  const formattedFromDate = displayFromDate
    ? moment(displayFromDate).format("YYYY-MM-DD")
    : "";

  const formattedToDate = displayToDate
    ? moment(displayToDate).format("YYYY-MM-DD")
    : "";
  const extraInfo = {
    fromDate: displayFromDate
      ? moment(displayFromDate).format("YYYY-MM-DD HH:mm:ss")
      : "N/A",
    toDate: displayToDate
      ? moment(displayToDate).format("YYYY-MM-DD HH:mm:ss")
      : "N/A",
  };
  const reportFileName =
    formattedFromDate && formattedToDate
      ? `${sanitized_name_custom}_REPORT_${formattedFromDate}_${formattedToDate}`
      : sanitized_name_custom;

  return (
    <Box sx={{ width: "100%", position: "relative" }}>
      <Box
        sx={{
          // bgcolor: "background.primary",
          p: 1,
          borderRadius: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
          mb: 1,
        }}
      >
        <Grid
          container
          spacing={2}
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(245px, 1fr))",
            gap: "15px",
            width: "100%",
            mb: 3,
          }}
        >
          {activeTab?.mainParent === "perfomance" ? (
            // here performance reports will be handled
            <PerformanceRouter
              activeTab={activeTab}
              fields={activeTab?.fields}
            />
          ) : (
            // all reports extect performance will he handled here
            (activeTab?.fields || []).map((fieldName) => {
              const baseFetchFn =
                activeRegistryConfig?.initializers?.[fieldName];
              let interceptedFetchFn = baseFetchFn;

              if (
                baseFetchFn &&
                activeTab?.key !== "DeviceMaintenance" &&
                activeTab?.key !== "DeviceAvailability"
              ) {
                interceptedFetchFn = async () => {
                  const result = await baseFetchFn(formData, {
                    isCnms,
                    rnmsId,
                  });
                  const isTerminalTypeField =
                    fieldName === "multipleTerminal" &&
                    activeTab?.key === "SiteRepDetails";

                  const isExistingTerminalTypeField =
                    fieldName === "siteType" &&
                    [
                      "SiteAvailability",
                      "SiteReachability",
                      "AlarmReportRNMS",
                      "SystemLogCNMS",
                    ].includes(activeTab?.key);

                  if (isTerminalTypeField || isExistingTerminalTypeField) {
                    setSiteAvailabilityTerminalTypes(result || []);
                  }
                  if (activeTab?.key === "AlarmLog") {
                    if (fieldName === "segmentName") setSegmentsList(result);
                    if (fieldName === "severities") setSeveritiesList(result);
                  }
                  if (activeTab?.key === "SiteReachability") {
                    if (fieldName === "severities") setSeveritiesList(result);
                  }
                  // if (activeTab?.key === "SystemLogRNMS") {
                  //   if (fieldName === "deviceName") setSyslogDevices(result);
                  //   if (fieldName === "syslogSeverities")
                  //     setSyslogSeverities(result);
                  //   if (fieldName === "facilities") setSyslogFacilities(result);
                  // }
                  if (
                    activeTab?.key === "SystemLogRNMS" ||
                    activeTab?.key === "SystemLogCNMS"
                  ) {
                    // CNMS devices come from the terminal-specific API effect.
                    if (
                      activeTab?.key === "SystemLogRNMS" &&
                      fieldName === "deviceName"
                    ) {
                      setSyslogDevices(result);
                    }

                    if (fieldName === "syslogSeverities") {
                      setSyslogSeverities(result);
                    }

                    if (fieldName === "facilities") {
                      setSyslogFacilities(result);
                    }
                  }
                  if (activeTab?.key === "RealTimeSystemLevel") {
                    if (fieldName === "performanceDevice") {
                      setPerformanceDevices(result);
                    }
                  }
                  return result;
                };
              }

              return (
                <Box key={fieldName}>
                  <FieldFactory
                    fieldName={fieldName}
                    value={formData[fieldName]}
                    onChange={(val) => handleFieldChange(fieldName, val)}
                    fetchOptionsFn={interceptedFetchFn}
                    activeTabKey={activeTab?.key}
                    allFormValues={formData}
                    optionsOverride={fetchDropdownOverrides(fieldName)}
                    loadingState={
                      activeTab?.key === "LinkCnms"
                        ? fieldName === "link"
                          ? fetchingCnmsLinks
                          : false
                        : activeTab?.key === "SystemLogCNMS"
                        ? fieldName === "siteName"
                          ? fetchingCnmsSites
                          : fieldName === "deviceName"
                          ? fetchingDevices
                          : false
                        : activeTab?.key === "AlarmReportRNMS"
                        ? fieldName === "siteName"
                          ? fetchingCnmsSites
                          : fieldName === "segmentName"
                          ? fetchingCnmsAlarmSegments
                          : fieldName === "deviceName"
                          ? fetchingCnmsAlarmDevices
                          : fieldName === "alarmName"
                          ? fetchingCnmsAlarmNames
                          : false
                        : fieldName === "deviceName"
                        ? fetchingDevices
                        : fieldName === "alarmName"
                        ? fetchingAlarms
                        : fieldName === "siteName"
                        ? fetchingCnmsSites
                        : false
                    }
                  />
                </Box>
              );
            })
          )}
        </Grid>

        <Box display="flex" justifyContent="flex-end" mt={3}>
          {activeTab?.mainParent !== "perfomance" && (
            // <Button
            //   variant="contained"
            //   disabled={isFormInvalid() || loading}
            //   onClick={handleFormSubmit}
            //   startIcon={
            //     loading ? (
            //       <CircularProgress size={18} color="inherit" />
            //     ) : (
            //       <SearchIcon />
            //     )
            //   }
            //   sx={{
            //     bgcolor: "#14348D",
            //     borderRadius: "8px",
            //     height: "38px",
            //     px: 4,
            //     "&:hover": { bgcolor: "#0f276b" },
            //   }}
            // >
            //   {loading ? "Fetching..." : "View Report"}
            // </Button>
            <MButtonPrimary
              variant="contained"
              color="primary"
              // MButtonPrimary usually handles the blue background and hover state automatically
              // We only override border radius and padding here
              sx={{ borderRadius: "8px", px: 4 }}
              onClick={handleFormSubmit}
              disabled={isFormInvalid() || loading}
              startIcon={
                loading ? (
                  <CircularProgress size={18} color="inherit" />
                ) : (
                  <SearchIcon />
                )
              }
            >
              {loading ? "Fetching..." : "View Report"}
            </MButtonPrimary>
          )}
        </Box>
      </Box>

      <Backdrop
        open={showResults}
        onClick={() => setShowResults(false)}
        sx={{ backgroundColor: "rgba(0, 0, 0, 0.4)" }}
      />

      <Slide direction="top" in={showResults} mountOnEnter unmountOnExit>
        <Box
          sx={{
            position: "fixed",
            top: 0,
            right: 0,
            width: isFullscreen ? "100vw" : "45vw",
            height: "100vh",
            // bgcolor: "#fff",
            bgcolor: "background.cardbg",
            zIndex: 1400,
            boxShadow: "-4px 0 24px rgba(0,0,0,0.15)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            borderTopLeftRadius: isFullscreen ? "0px" : "40px",
            transition: "width 0.3s ease-in-out",
          }}
        >
          <Box
            sx={{
              //bgcolor: "#F4F7FE",
              px: 3,
              py: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid #e2e8f0",
            }}
          >
            <Typography
              variant="subtitle1"
              sx={{
                textAlign: "left",
                fontWeight: 600,
                color: "text.TitleTextcolor",
              }}
            >
              Reports
            </Typography>
            <IconButton
              onClick={handleStopRealtime}
              size="medium"
              sx={{
                bgcolor: "#D7EEFF",
                "&:hover": { bgcolor: "#bde4ff" },
                // Only rounds the top-left and top-right corners
                borderTopLeftRadius: "16px",
                borderTopRightRadius: "16px",
                borderBottomLeftRadius: "0px",
                borderBottomRightRadius: "0px",
                px: 6,
                borderBottom: "none",
              }}
            >
              <img
                src={Up_Arrow}
                alt="Close"
                style={{ width: "24px", height: "24px", display: "block" }}
              />
            </IconButton>
            <Box>
              <IconButton
                onClick={toggleFullscreen}
                size="medium"
                sx={{
                  px: 1,
                }}
              >
                {isFullscreen ? <FullscreenExit /> : <Fullscreen />}
              </IconButton>
              <IconButton
                onClick={handleStopRealtime}
                size="medium"
                sx={{
                  //bgcolor: "#E0F2FE", // Slightly different color to distinguish
                  "&:hover": { bgcolor: "#bae6fd" },
                  borderRadius: "2px",
                  p: 1,
                  ml: 2,
                }}
              >
                <Close />
              </IconButton>
            </Box>
          </Box>

          <Box sx={{ p: 3, overflowY: "auto", bgcolor: "Background.cardbg" }}>
            {displayFromDate &&
              displayToDate &&
              activeTab?.key !== "SiteAvailability" && (
                <Card
                  sx={{
                    mb: 3,
                    //bgcolor: "#fcfdfe",
                    border: "1px dashed #b4c2e0",
                    borderRadius: "8px",
                  }}
                >
                  <CardContent sx={{ p: "16px !important" }}>
                    <Grid
                      spacing={2}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-evenly",
                        flexWrap: "wrap",
                        gap: "20px",
                      }}
                    >
                      {calculatedSummary && (
                        <Grid
                          item
                          xs={5}
                          display="flex"
                          alignItems="center"
                          justifyContent="center"
                        >
                          <MPieChart
                            // title={
                            //   activeTab?.key === "DeviceAvailability"
                            //     ? "Availability Ratio"
                            //     : activeTab?.key === "Link"
                            //     ? "Router WAN Interface Status Distribution"
                            //     : activeTab?.key === "SystemUptime" ||
                            //       activeTab?.key === "UptimeReportRNMS"
                            //     ? "Uptime Distribution"
                            //     : "Operational Ratio"
                            // }
                            title={
                              activeTab?.key === "LinkCnms"
                                ? "Site Link Status Summary"
                                : activeTab?.key === "SiteMaintenance"
                                ? "Site Maintenance Ratio"
                                : activeTab?.key === "DeviceAvailability"
                                ? "Availability Ratio"
                                : activeTab?.key === "Link"
                                ? "Router WAN Interface Status Distribution"
                                : activeTab?.key === "UptimeReportRNMS"
                                ? formData.upTime === "system"
                                  ? "System Uptime Ratio"
                                  : "RNMS Uptime Ratio"
                                : "Operational Ratio"
                            }
                            availableSeconds={
                              calculatedSummary.availableSeconds
                            }
                            maintenanceSeconds={
                              calculatedSummary.notAvailableSeconds
                            }
                            pieData={calculatedSummary.pieData}
                          />
                        </Grid>
                      )}
                      <Grid
                        item
                        xs={calculatedSummary ? 7 : 12}
                        sx={{ bgcolor: "Background.cardbg" }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: calculatedSummary ? "column" : "row",
                            gap: calculatedSummary ? 0 : 4,
                            flexWrap: "nowrap",
                            bgcolor: "Background.cardbg",
                          }}
                        >
                          <Typography
                            variant="body2"
                            sx={{ mb: calculatedSummary ? 0.5 : 0 }}
                          >
                            <strong>From Date Time:</strong>{" "}
                            {moment(displayFromDate).format(
                              "YYYY-MM-DD HH:mm:ss"
                            )}
                          </Typography>
                          <Typography
                            variant="body2"
                            sx={{
                              mb: calculatedSummary ? 0.5 : 0,
                              ml: calculatedSummary ? 0 : 2,
                            }}
                          >
                            <strong>To Date Time:</strong>{" "}
                            {moment(displayToDate).format(
                              "YYYY-MM-DD HH:mm:ss"
                            )}
                          </Typography>
                        </Box>
                        {(activeTab?.key === "AuditLogReport" ||
                          activeTab?.key === "user_blocked_logs_cnms" ||
                          activeTab?.key === "foreign_ip_report_cnms") &&
                          isCnms &&
                          reportData.length > 0 && (
                            <Box
                              sx={{
                                display: "flex",
                                flexDirection: calculatedSummary
                                  ? "column"
                                  : "row",
                                gap: 21.5,
                                flexWrap: "nowrap",
                                bgcolor: "Background.cardbg",
                              }}
                            >
                              {activeTab?.key === "foreign_ip_report_cnms" ? (
                                <Typography
                                  variant="body2"
                                  sx={{
                                    mb: calculatedSummary ? 0.5 : 0,
                                    ml: calculatedSummary ? 0 : 2,
                                  }}
                                >
                                  <strong>Terminal:</strong>{" "}
                                  {reportData[0]?.terminalTypeName || "N/A"}
                                </Typography>
                              ) : (
                                <Typography
                                  variant="body2"
                                  sx={{
                                    mb: calculatedSummary ? 0.5 : 0,
                                    ml: calculatedSummary ? 0 : 2,
                                  }}
                                >
                                  <strong>Site Name:</strong>{" "}
                                  {reportData[0]?.siteName || "N/A"}
                                </Typography>
                              )}
                              <Typography
                                variant="body2"
                                sx={{ mb: calculatedSummary ? 0.5 : 0 }}
                              >
                                <strong>Site ID:</strong>{" "}
                                {reportData[0]?.siteId || "N/A"}
                              </Typography>
                            </Box>
                          )}
                        {calculatedSummary && (
                          <>
                            {!calculatedSummary.isUptimeTab &&
                              !calculatedSummary.isSiteMaintenance &&
                              !calculatedSummary.isCnmsLinkTab && (
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>
                                    {calculatedSummary.isLinkTab
                                      ? "Router Wan Interface Type:"
                                      : "Device Name:"}
                                  </strong>{" "}
                                  {calculatedSummary.deviceName}
                                </Typography>
                              )}

                            {calculatedSummary.isSiteMaintenance && (
                              <>
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>Terminal Name:</strong>{" "}
                                  {calculatedSummary.terminalTypeName}
                                </Typography>

                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>Site ID:</strong>{" "}
                                  {calculatedSummary.siteId}
                                </Typography>

                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>Site Name:</strong>{" "}
                                  {calculatedSummary.siteName}
                                </Typography>
                              </>
                            )}

                            {calculatedSummary.isUptimeTab ? (
                              <>
                                {/* Keep your existing uptime summary JSX here. */}
                              </>
                            ) : calculatedSummary.isCnmsLinkTab ? (
                              <>
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>Link Type:</strong>{" "}
                                  {calculatedSummary.linkTypeName}
                                </Typography>

                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>Site ID:</strong>{" "}
                                  {calculatedSummary.siteId}
                                </Typography>

                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>Site Name:</strong>{" "}
                                  {calculatedSummary.siteName}
                                </Typography>

                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>From Date Time:</strong>{" "}
                                  {calculatedSummary.fromDate}
                                </Typography>

                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                  <strong>To Date Time:</strong>{" "}
                                  {calculatedSummary.toDate}
                                </Typography>
                              </>
                            ) : calculatedSummary.isLinkTab ? (
                              calculatedSummary.linkStatusBreakdown.map(
                                (statusItem, index) => (
                                  <Typography
                                    key={index}
                                    variant="body2"
                                    sx={{ mb: 0.5, color: statusItem.color }}
                                  >
                                    <strong>{statusItem.label}:</strong>{" "}
                                    {statusItem.value}
                                  </Typography>
                                )
                              )
                            ) : (
                              <>
                                <Typography
                                  variant="body2"
                                  sx={{
                                    mb: 0.5,
                                    color: calculatedSummary.color1,
                                  }}
                                >
                                  <strong>{calculatedSummary.label1}:</strong>{" "}
                                  {calculatedSummary.value1}
                                </Typography>

                                <Typography
                                  variant="body2"
                                  sx={{ color: calculatedSummary.color2 }}
                                >
                                  <strong>{calculatedSummary.label2}:</strong>{" "}
                                  {calculatedSummary.value2}
                                </Typography>
                              </>
                            )}
                          </>
                        )}
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              )}
            {activeTab?.key === "RealTimeSystemLevel" &&
              formData.performanceDevice &&
              formData.performanceParameter && (
                <Box sx={{ mb: 3 }}>
                  <ReusableRealTimeLineChart
                    resourceId={formData.performanceDevice}
                    paramId={formData.performanceParameter}
                  />
                </Box>
              )}
            {activeTab?.key === "SiteAvailability" && showResults && (
              <Box sx={{ mb: 3 }}>
                <SiteAvailabilitySummary data={reportData} />

                <SiteAvailabilityChart data={reportData} />
              </Box>
            )}
            {activeTab?.key === "LinkSummary" && showResults && (
              <Grid>
                {/* --- Added Link Summary Header --- */}
                <Typography
                  variant="h6"
                  component="div"
                  sx={{
                    fontWeight: 700,
                    mb: 2, // Adds space between title and chart
                    color: "#1e293b", // Subtle dark color,
                    textAlign: "center",
                  }}
                >
                  Link Summary
                </Typography>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  <strong>Site Name:</strong>{" "}
                  {calculatedSummary?.siteName || "N/A"}
                </Typography>
                <Grid
                  container
                  spacing={2}
                  sx={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(auto-fill, minmax(350px, 1fr))",
                    gap: 2,
                    // width: "100%",
                    mb: 1,
                  }}
                >
                  {reportData.map((link, index) => {
                    const pieData = [
                      {
                        name: "Uptime",
                        value: link.uptimePercent,
                        color: "#A3D6BE",
                      },
                      {
                        name: "Downtime",
                        value: link.downTimePercent,
                        color: "#E0DA8C",
                      },
                      {
                        name: "Operational Downtime",
                        value: link.opDownTimePercent,
                        color: "#72BEF1",
                      },
                    ].filter((item) => item.value > 0);

                    return (
                      <Grid
                        item
                        xs={12}
                        sm={6}
                        md={4}
                        key={link.linkTypeId ?? index}
                      >
                        <Card
                          sx={{
                            height: "100%",
                            border: "1px solid #e2e8f0",
                            borderRadius: 2,
                            boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
                          }}
                        >
                          <CardContent>
                            <MPieChart
                              title={link.linkTypeName}
                              pieData={pieData}
                              availableSeconds={link.uptimePercent}
                              maintenanceSeconds={link.downTimePercent}
                            />

                            <Box sx={{ mt: 2 }}>
                              {[
                                {
                                  label: "Uptime",
                                  value: link.uptimePercent,
                                  color: "#A3D6BE",
                                },
                                {
                                  label: "Downtime",
                                  value: link.downTimePercent,
                                  color: "#E0DA8C",
                                },
                                {
                                  label: "Operational Downtime",
                                  value: link.opDownTimePercent,
                                  color: "#72BEF1",
                                },
                              ].map((item) => (
                                <Box
                                  key={item.label}
                                  sx={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    mb: 1,
                                  }}
                                >
                                  <Box
                                    sx={{
                                      display: "flex",
                                      alignItems: "center",
                                      gap: 1,
                                    }}
                                  >
                                    <Box
                                      sx={{
                                        width: 10,
                                        height: 10,
                                        borderRadius: "50%",
                                        bgcolor: item.color,
                                      }}
                                    />
                                    <Typography variant="body2">
                                      {item.label}
                                    </Typography>
                                  </Box>

                                  <Typography variant="body2" fontWeight={600}>
                                    {item.value.toFixed(2)}%
                                  </Typography>
                                </Box>
                              ))}
                            </Box>
                          </CardContent>
                        </Card>
                      </Grid>
                    );
                  })}
                </Grid>
              </Grid>
            )}
            {activeTab?.key !== "LinkSummary" && (
              <Box>
                <MTable
                  columns={activeColumns}
                  tableData={reportData}
                  // tableTitle={activeTab?.key === "SiteRepDetails" ? computedReportTitle : `${computedReportTitle} Details`}
                  tableTitle={
                    activeTab?.key === "SiteRepDetails"
                      ? computedReportTitle
                      : activeTab?.key === "db_BackupStatusLog"
                      ? `${isCnms ? "CNMS" : "RNMS"} ${computedReportTitle}`
                      : `${computedReportTitle} Details`
                  }
                  showPagination={true}
                  showSearch={true}
                  showVisibleContent={true}
                  showSelect={false}
                  handleDownloadPDF={() => {
                    const sanitizedName = computedReportTitle.replace(
                      /\s+/g,
                      "_"
                    );
                    const chartIds = [];
                    if (document.getElementById("report-pie-chart"))
                      chartIds.push("report-pie-chart");
                    if (document.getElementById("report-bar-chart"))
                      chartIds.push("report-bar-chart");
                    exportToPDF(
                      // `${computedReportTitle} Report`,
                      activeTab?.key === "db_BackupStatusLog"
                        ? `${
                            isCnms ? "CNMS" : "RNMS"
                          } ${computedReportTitle} Report`
                        : `${computedReportTitle} Report`,
                      activeColumns,
                      reportData,
                      // `${sanitizedName}_Report`,
                      activeTab?.key === "db_BackupStatusLog"
                        ? `${isCnms ? "CNMS" : "RNMS"} ${sanitizedName}_Report`
                        : `${sanitizedName}_Report`,
                      "NMS User",
                      chartIds,
                      calculatedSummary,
                      null,
                      (activeTab?.key === "AuditLogReport" ||
                        activeTab?.key === "user_blocked_logs_cnms" ||
                        activeTab?.key === "foreign_ip_report_cnms") &&
                        isCnms
                        ? {
                            // siteName: reportData?.[0]?.siteName || "N/A",
                            ...(activeTab?.key === "foreign_ip_report_cnms"
                              ? {
                                  terminalTypeName:
                                    reportData?.[0]?.terminalTypeName || "N/A",
                                }
                              : {
                                  siteName: reportData?.[0]?.siteName || "N/A",
                                }),
                            siteId: reportData?.[0]?.siteId || "N/A",
                          }
                        : null,
                      activeTab?.key === "siteRepDetails" ? null : extraInfo
                    );
                  }}
                  handleDownloadCSV={
                    activeTab?.key === "AuditLogReport"
                      ? () =>
                          exportToCSV(reportFileName, activeColumns, reportData)
                      : undefined
                  }
                />
              </Box>
            )}
          </Box>
        </Box>
      </Slide>
    </Box>
  );
};

export default ReportWorkspace;
