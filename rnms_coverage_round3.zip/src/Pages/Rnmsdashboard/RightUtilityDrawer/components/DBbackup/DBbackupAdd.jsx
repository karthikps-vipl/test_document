import React, { useEffect, useState, useCallback } from "react";
import {
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
} from "@mui/material";
import { TimePicker } from "antd";
import dayjs from "dayjs";

// Reusable Components
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MSelect from "@/components/Reusable/Select/MSelect";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import TextArea from "antd/es/input/TextArea";

// Icons and APIs
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import {
  CREATE_SCHEDULE_TASK,
  FETCH_TASK_BASED_ON_TASK_TYPE,
} from "@/RestAPI/url/endpoint";
import { DbAxios } from "@/RestAPI/api/axiosApicall";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
const DBPreviousupAdd = ({ editData ,isChildFullScreen}) => {
  // UI State
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [mode, setMode] = useState("CREATE");
  const [resources, setResources] = useState([]);
  const [descError, setDescError] = useState("");
  const [remainingChar, setRemainingChar] = useState(
    "255 characters remaining"
  );

  // Form State - Synchronized with API Keys
  const [formData, setFormData] = useState({
    id: null,
    selectedDevice: null, // Will hold the object {id, value, label}
    taskName: "",
    description: "",
    frequency: "",
    scheduleTime: dayjs(),
    selectedDay: 1,
    selectedDate: 1,
    selectedMonth: 1,
  });

  const formatTimeForPicker = (timeArray) => {
    const now = dayjs();
    if (Array.isArray(timeArray) && timeArray.length >= 2) {
      return now
        .hour(timeArray[0])
        .minute(timeArray[1])
        .second(timeArray[2] || 0);
    }
    return now;
  };

  const validateDescription = (e) => {
    const value = e.target.value;
    const MAX_LENGTH = 255;

    if (/^\d/.test(value)) {
      setDescError("Description cannot start with a number");
    }

    setFormData((prev) => ({
      ...prev,
      description: value,
    }));

    setRemainingChar(`${value.length}/${MAX_LENGTH}`);

    if (value.length > MAX_LENGTH) {
      setDescError("Exceeded Maximum Limit");
    } else if (value.trim().length > 0 && value.trim().length <= 2) {
      setDescError("Need more than 2 Characters");
    } else {
      setDescError("");
    }
  };

  const populateEditData = useCallback(
    (e) => {
      const freqMap = { 1: "Daily", 7: "Weekly", 30: "Monthly", 365: "Yearly" };

      // Find the device object in the resources array that matches the API taskTypeId
      const matchedResource =
        resources.find((res) => res.id === e.taskTypeId) || null;

      setFormData({
        id: e.taskId,
        selectedDevice: matchedResource,
        taskName: e.taskName || "",
        description: e.taskDescription || "",
        frequency: freqMap[e.taskTriggerFreq] || "Daily",
        scheduleTime: e.triggerTime
          ? formatTimeForPicker(e.triggerTime.split(":"))
          : dayjs(),
        selectedDay: e.dayofWeek || 1,
        selectedDate: e.dayofMonth || 1,
        selectedMonth: 1,
      });
    },
    [resources]
  );

  // Effect 1: Fetch resources on mount
  useEffect(() => {
    const fetchTaskData = async () => {
      try {
        const response = await DbAxios(FETCH_TASK_BASED_ON_TASK_TYPE, "get");
        const taskData = response?.data; // This is your object

        if (taskData) {
          // 1. MAP THE DATA TO YOUR FORM STATE
          setFormData({
            id: taskData.taskId,
            // Mapping "taskName" from API to formData.taskName
            taskName: taskData.taskName || "",
            // Mapping "taskDescription" from API to formData.description
            description: taskData.taskDescription || "",
            // Mapping "taskTypeId" to a resource object for the MSelect
            selectedDevice: {
              id: taskData.taskTypeId,
              label: taskData.taskName, // Using taskName as a label since we don't have a list
              value: taskData,
            },
            // Mapping "taskTriggerFreq" (7 = Weekly)
            frequency: taskData.taskTriggerFreq === 7 ? "Weekly" : "Daily",
            // Mapping "triggerTime" (e.g., "12:16:00")
            // Note: You might need to adjust this based on how your formatTimeForPicker works
            scheduleTime: taskData.triggerTime
              ? dayjs().set("hour", 12).set("minute", 16)
              : dayjs(),
            // Mapping "dayofWeek"
            selectedDay: taskData.dayofWeek || 1,
            // Mapping "dayofMonth"
            selectedDate: taskData.dayofMonth || 1,
            selectedMonth: 1,
          });

          // 2. PREVENT THE MSELECT CRASH
          // MSelect needs an ARRAY to .map().
          // Since your API gave us one object, we wrap it in an array.
          setResources([
            {
              id: taskData.taskTypeId,
              label: taskData.taskName,
              value: taskData,
            },
          ]);
        }
      } catch (error) {
        console.error("Error fetching task data:", error);
        // Always set an empty array to prevent UI crashes
        setResources([]);
      }
    };

    fetchTaskData();
  }, []);

  // Effect 2: Populate data when resources are loaded AND editData is present
  useEffect(() => {
    if (editData && resources.length > 0) {
      setMode("EDIT");
      populateEditData(editData);
    }
  }, [editData, resources, populateEditData]);

  const handleFinalSchedule = async () => {
    // setShowConfirm(false);
    setLoading(true);

    // 1. Map frequencies to the exact numbers your API expects
    const freqToType = {
      "One Time": 0,
      Daily: 1,
      Weekly: 7,
      Fortnightly: 15, // Added based on your requirement
      Monthly: 30,
      Quarterly: 3, // Added based on your requirement
      Yearly: 365,
    };

    // 2. Determine if we are in a "special" mode where days are zeroed out
    const isSpecialFreq = ["Fortnightly", "Quarterly"].includes(
      formData.frequency
    );

    const payload = {
      // Use 0 instead of null if your API expects a number for taskId
      taskId: formData.selectedDevice?.id || 0,

      taskName: formData.taskName,
      taskDescription: formData.description || null,
      taskLocation: formData.location || "Local",

      // Frequency mapping
      taskTriggerFreq: freqToType[formData.frequency] || 0,
      taskType: 1,

      // Month logic: Only for Yearly (and potentially Monthly/Quarterly if needed)
      triggerMonth:
        formData.frequency === "Yearly" ? formData.selectedMonth : 0,

      // Time format
      triggerTime: formData.scheduleTime.format("HH:mm:ss"),

      // Day Logic:
      // If Fortnightly/Quarterly, send 0.
      // If Weekly, send selectedDay.
      // If Monthly/Yearly, send selectedDate.
      dayofWeek: isSpecialFreq
        ? 0
        : formData.frequency === "Weekly"
        ? formData.selectedDay
        : 0,

      dayofMonth: isSpecialFreq
        ? 0
        : ["Monthly", "Yearly"].includes(formData.frequency)
        ? formData.selectedDate
        : 0,

      fileName: null,
      filePath: null,
    };

    console.log("Sending Payload:", payload); // Debugging

    try {
      const response = await DbAxios(CREATE_SCHEDULE_TASK, "post", payload);

      if (response?.status === 200 || response?.data?.success) {
        Toast(
          "Success!",
          `Schedule ${mode === "CREATE" ? "created" : "updated"} successfully.`,
          "success"
        );
      } else {
        Toast(
          "Error!",
          "Failed to process schedule.",
          "error"
        );
      }
    } catch (error) {
      console.error("Schedule API Error:", error);
      // Check if error contains the specific server message
      // const errMsg = error.response?.data?.message || "Server Error.";
      Toast("Error!", "Server Error", "error");
    } finally {
      setLoading(false);
    }
  };

  const checkIsNextDisabled = () => {
    if (activeStep === 0) {
      const hasDevice = !!formData.selectedDevice;
      const hasValidDesc =
        formData.description && formData.description.trim().length >= 3;
      return !(hasDevice && hasValidDesc);
    }
    if (activeStep === 1) {
      return !formData.frequency;
    }
    return false;
  };

  // Dropdown Options
  const dateOptions = Array.from({ length: 31 }, (_, i) => ({
    label: i + 1,
    value: i + 1,
  }));
  const daysOptions = [
    { label: "Monday", value: 1 },
    { label: "Tuesday", value: 2 },
    { label: "Wednesday", value: 3 },
    { label: "Thursday", value: 4 },
    { label: "Friday", value: 5 },
    { label: "Saturday", value: 6 },
    { label: "Sunday", value: 7 },
  ];
  const monthOptions = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ].map((m, i) => ({ label: m, value: i + 1 }));

  const getScheduleDescription = () => {
    if (!formData.scheduleTime) return "";

    // This gets the formatted time (e.g., "11:00 PM")
    const time = formData.scheduleTime.format("hh:mm A");
    const { frequency, selectedDate, selectedMonth } = formData;
    const day = formData.selectedDay || "the selected day";
    switch (frequency) {
      case "Daily":
        return `This will take a database backup every day at ${time}.`;

      case "Weekly":
        // Assuming you have a selectedDay (e.g., Monday) in your formData
        return `This will take a database backup every ${day} at ${time}.`;

      case "Fortnightly":
        return `This will take a database backup on the 1st and 15th of every month at ${time}.`;

      case "Monthly":
        // Assuming selectedDate is the day of the month (e.g., 15)
        return `This will take a database backup on the ${selectedDate}${
          selectedDate === "1"
            ? "st"
            : selectedDate === "2"
            ? "nd"
            : selectedDate === "3"
            ? "rd"
            : "th"
        } of every month at ${time}.`;

      case "Quarterly":
        return `This will take a database backup once every 3 months at ${time}.`;

      case "Yearly":
        // selectedMonth and selectedDate should be human-readable (e.g., "January", "15th")
        return `This will run yearly on ${selectedMonth} ${selectedDate} at ${time}.`;

      default:
        return "";
    }
  };

  return (
    <Box sx={{ mt: 2, ml: 2, width: "100%" }}>
      {/* Progress Stepper */}
      <Stepper activeStep={activeStep} sx={{ mb: 1, mr: 4 }}>
        {["Task", "Frequency", "Trigger"].map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {/* MAIN ROW CONTAINER */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          alignItems: "stretch",
          gap: 3,
          width: "100%",
        }}
      >
        {/* BOX 1: TASK DETAILS */}
        <Box
          sx={{
            flex: 1,
            p: 3,
            borderRadius: "10px",
             
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 2.5,
              flexGrow: 1,
            }}
          >
            <Box>
              <Typography sx={{ mb: 1 }}>Task Name *</Typography>
              <MInput
                placeholder="Enter Task Name"
                fullWidth
                value={formData.taskName}
                onChange={(e) =>
                  setFormData({ ...formData, taskName: e.target.value })
                }
              />
            </Box>
            <Box>
              <Typography sx={{ mb: 1 }}>Task Type *</Typography>
              <MSelect
                options={resources}
                value={formData.selectedDevice}
                onChange={(val) =>
                  setFormData({ ...formData, selectedDevice: val })
                }
                placeholder="Select Device"
                fullWidth
                disabled={true}
              />
            </Box>
            <Box>
              <Typography sx={{ mb: 1 }}>Task Description *</Typography>
              <TextArea
                rows={3}
                value={formData.description}
                onChange={validateDescription}
                placeholder="Min 3 characters"
                style={{ width: "100%", resize: "none" }}
              />
              <Typography
                variant="caption"
                sx={{ color: descError ? "#e75656" : "textSecondary" }}
              >
                {descError || remainingChar}
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* BOX 2: FREQUENCY */}
        <Box
          sx={{
            flex: 1,
            p: 3,
            ml: 5,
            borderRadius: "10px",
            display: "flex",
            flexDirection: "column",
            transition: "all 0.3s ease",
          }}
        >
          {activeStep >= 1 ? (
            <Box sx={{ flexGrow: 1 }}>
              <Typography sx={{}}>Trigger Type *</Typography>
              <RadioGroup
                value={formData.frequency}
                onChange={(e) =>
                  setFormData({ ...formData, frequency: e.target.value })
                }
              >
                {[
                  "Daily",
                  "Weekly",
                  "Fortnightly",
                  "Monthly",
                  "Quarterly",
                  "Yearly",
                ].map((item) => (
                  <FormControlLabel
                    key={item}
                    value={item}
                    control={<Radio size="small" />}
                    label={item}
                  />
                ))}
              </RadioGroup>
            </Box>
          ) : (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "100%",
              }}
            />
          )}
        </Box>

        {/* BOX 3: TRIGGER DETAILS */}
        <Box
          sx={{
            flex: 1,
            p: 3,
            borderRadius: "10px",
            display: "flex",
            flexDirection: "column",
            transition: "all 0.3s ease",
          }}
        >
          {activeStep >= 2 ? (
            <Box sx={{ flexGrow: 1 }}>
              {!["Quarterly", "Fortnightly"].includes(formData.frequency) && (
                <>
                  <Typography sx={{ mb: 1 }}>Time *</Typography>
                  <TimePicker
                    value={formData.scheduleTime}
                    onChange={(time) =>
                      setFormData({ ...formData, scheduleTime: time })
                    }
                    format="HH:mm:ss"
                    style={{ height: 45, width: "100%" }}
                    allowClear={false}
                    getPopupContainer={(trigger) => trigger.parentElement}
                  />
                  {formData.frequency === "Weekly" && (
                    <Box sx={{ mt: 2 }}>
                      <Typography sx={{ mb: 1 }}>Select Day *</Typography>
                      <MSelect
                        options={daysOptions}
                        value={formData.selectedDay}
                        onChange={(val) =>
                          setFormData({ ...formData, selectedDay: val.value })
                        }
                      />
                    </Box>
                  )}
                  {["Monthly", "Yearly"].includes(formData.frequency) && (
                    <Box sx={{ mt: 2 }}>
                      <Typography sx={{ mb: 1 }}>Select Date *</Typography>
                      <MSelect
                        options={dateOptions}
                        value={formData.selectedDate}
                        onChange={(val) =>
                          setFormData({ ...formData, selectedDate: val.value })
                        }
                      />
                    </Box>
                  )}
                  {formData.frequency === "Yearly" && (
                    <Box sx={{ mt: 2 }}>
                      <Typography sx={{ mb: 1 }}>Select Month *</Typography>
                      <MSelect
                        options={monthOptions}
                        value={formData.selectedMonth}
                        onChange={(val) =>
                          setFormData({ ...formData, selectedMonth: val.value })
                        }
                      />
                    </Box>
                  )}
                </>
              )}
              {/* Check if frequency is one of the two specific types */}
              {["Fortnightly", "Quarterly"].includes(formData.frequency) &&
                getScheduleDescription() && (
                  <Box sx={{ p: 1 }}>
                    <Typography color="text.secondary">
                      {getScheduleDescription()}
                    </Typography>
                  </Box>
                )}
            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 4 }}>
            <MButtonPrimary
  variant="contained"
  onClick={() => setShowConfirm(true)}
>
  {mode === "CREATE" ? "Schedule" : "Update"}
</MButtonPrimary>
</Box>
            </Box>
          ) : (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "100%",
              }}
            />
          )}
        </Box>
      </Box>

      {/* NAVIGATION BUTTONS: Bottom Center, Outside the boxes */}
      <Box sx={{ display: "flex", justifyContent: "center", mt: 4, gap: 2 }}>
        <MButtonSecondary
          variant="outlined"
          //  sx={{
          //    color: "#14348D !important",
          //    borderRadius: "10px",
          //    textTransform: "none",
          //    fontFamily: "Montserrat",
          //    border: "1px solid #14348D !important",

          //  }}
          onClick={() => setActiveStep(activeStep - 1)}
          disabled={activeStep === 0}
        >
          Previous
        </MButtonSecondary>

        {/* NEXT BUTTON: Only shows for Step 0 and Step 1 */}
        {activeStep === 0 && (
          <MButtonPrimary
            sx={{ p: 3, width: "20%" }}
            disabled={checkIsNextDisabled()}
            onClick={() => setActiveStep(1)}
          >
            Next
          </MButtonPrimary>
        )}

        {activeStep === 1 && (
          <MButtonPrimary
            sx={{ p: 3 }}
            disabled={checkIsNextDisabled()}
            onClick={() => setActiveStep(2)}
          >
            Next
          </MButtonPrimary>
        )}
        {activeStep === 2 && (
          <MButtonPrimary
            sx={{ p: 3 }}
            disabled={activeStep === 2}
            onClick={() => setActiveStep(2)}
          >
            Next
          </MButtonPrimary>
        )}
      </Box>

      <MDialog
  isInsideDrawer={true}
  open={showConfirm}
  variant="info"
  mode="child"
  isChildFullScreen={isChildFullScreen}
  icon={Confirmation_icon}
  title="Confirm Action"
  message={getScheduleDescription()}
  onConfirm={handleFinalSchedule}
  isSubmitting={loading}
  // This prevents users from clicking "Confirm" multiple times or closing while saving
  onClose={loading ? undefined : () => setShowConfirm(false)}
/>
    </Box>
  );
};
export default DBPreviousupAdd;
