
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { Box, CircularProgress, FormControl, FormControlLabel, Radio, RadioGroup, Typography } from "@mui/material";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";

 import React, {  useState } from "react";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { EXECUTE_BACKUP_COMMAND } from "@/RestAPI/url/endpoint";
import {DbAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MForm from "@/components/Reusable/Form/MForm";
import { useSelector } from "react-redux";

 
const DBManual = ({isChildFullScreen}) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [performBackup, setPerformBackup] = useState('no');
  const siteDetails = useSelector((state) => state.nodeDetails?.siteDetails);
  console.log(siteDetails,"siteDetails")
  const handlePerformBackup = async () => {
    setShowConfirm(false); 
    setLoading(true);
    
    try {
      // Note: Ensure method is "post" if required by backend
      const response = await DbAxios(EXECUTE_BACKUP_COMMAND, "get"); 
      
      if (response?.status === 200 || response?.data?.success) {
       Toast("Success!", "Site DB Backup taken successfully.", "success");
       setPerformBackup('no'); 
      } else {
         Toast("Error!", "Backup Failed!", "error");
      }
    } catch (error) {
      console.error("Backup Error:", error);
       Toast("Error!", "Backup Failed! Check server logs.", "error");
    } finally {
      setLoading(false);
    }
  };

  // REMOVED: The if (loading) return block that was replacing the whole UI

  return (
    <MForm title="Manual Backup">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <FormControl component="fieldset" sx={{ width: '100%' }}>
                <Box>
                    <Typography sx={{ fontFamily: "Montserrat" }}>
                        Do you want to take Database Backup?
                    </Typography>
                </Box>
                <RadioGroup
                    sx={{
                        display: 'flex',
                        flexDirection: "row",
                        justifyContent: "start",
                        alignItems: "center",
                        width: '100%',
                        marginTop: '10px',
                    }}
                    value={performBackup}
                    onChange={(e) => setPerformBackup(e.target.value)}
                    name="manual_backup_choice"
                    // Disable radio buttons while loading to prevent state changes mid-process
                    disabled={loading} 
                >
                    <FormControlLabel value={'yes'} control={<Radio size="small" />} label="Yes" />
                    <FormControlLabel value={'no'} control={<Radio size="small" />} label="No" />
                </RadioGroup>
            </FormControl>

            {/* ACTION BUTTON */}
            <Box display="flex" justifyContent="flex-start">
                <MButtonPrimary
                    // Disable button if loading OR if 'no' is selected
                    disabled={loading || performBackup === 'no'}
                    onClick={() => setShowConfirm(true)}
                >
                    {/* This handles the loader inside the button */}
                    {loading ? (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <CircularProgress size={20} color="inherit" />
                        <span>Processing...</span>
                      </Box>
                    ) : (
                      "Backup"
                    )}
                </MButtonPrimary>
            </Box>
        </Box>

        <MDialog
            open={showConfirm}
            variant="info"
            icon={Confirmation_icon}
            title="Confirm Action"
            message="Are you sure you want to take the database backup?"
            onConfirm={handlePerformBackup}
            onClose={() => setShowConfirm(false)}
            mode="child"
            isChildFullScreen={isChildFullScreen}
        />
    </MForm>
  );
};

export default DBManual;
 