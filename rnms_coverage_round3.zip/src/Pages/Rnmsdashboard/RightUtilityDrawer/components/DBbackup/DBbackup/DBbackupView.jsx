 

import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useState } from "react";
import {  DbAxios } from "@/RestAPI/api/axiosApicall";
import {  VIEW_SCHEDULED_TASK } from "@/RestAPI/url/endpoint";
import { Box, CircularProgress } from "@mui/material";
import {  exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
const dateFormat = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "N/A"; 
  
    const pad = (num) => String(num).padStart(2, '0');
  
    const day = pad(date.getDate());
    const month = pad(date.getMonth() + 1);
    const year = date.getFullYear();
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());
  
    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
  };
  
const DBbackupView = ({ refreshTrigger,privilegeKey }) => {
    const [scheduleDetails, setScheduleDetails] = useState([]);
    const [loading, setLoading] = useState(true);
  
    // KEEP YOUR COLUMNS EXACTLY LIKE THIS
    const columns = [
      { name: "S. No ", uid: "sno",width:'70px' },
      { name: "Task Name", uid: "taskName",width:'140px' },
      { name: "Task Description", uid: "taskDescription" ,width:'250px'},
      { name: " Last Execution", uid: "lastExecution",width:'180px' },
      { name: "Frequency", uid: "triggerTypeString" ,width:'110px'},
      { name: "Time ", uid: "time" },
    ];
  
    useEffect(() => {
      const fetchData = async () => {
        try {
          setLoading(true);
          const response = await DbAxios(VIEW_SCHEDULED_TASK, "get");
          const data = response?.data || [];
          
          if (data && Array.isArray(data)) {
            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    
            const processedData = data.map((item, index) => {
              
              // 1. Logic for the "Time" column
              const calculateTimeValue = () => {
                const type = item?.taskTriggerType;
                const tTime = item?.triggerTime;
    
                // Handle different trigger types based on your freqToType mapping
                if (type === 0) return tTime ? tTime : "NA"; // One Time
                if (type === 1) return tTime ? tTime : "NA"; // Daily
                if (type === 7) return tTime && item?.dayOfWeek ? `${daysOfWeek[item.dayOfWeek - 1]}, ${tTime}` : "NA"; // Weekly
                if (type === 15) return tTime && item?.dayOfMonth ? `${item.dayOfMonth}, ${tTime}` : "NA"; // Fortnightly
                if (type === 30) return tTime && item?.dayOfMonth ? `${item.dayOfMonth}, ${tTime}` : "NA"; // Monthly
                if (type === 3) return tTime && item?.dayOfMonth ? `${item.dayOfMonth}, ${tTime}` : "NA"; // Quarterly (Added this)
                if (type === 365) {
                  return tTime && item?.dayOfMonth && item?.triggerMonth
                    ? `${item.dayOfMonth} / ${months[item.triggerMonth - 1]}, ${tTime}`
                    : "NA";
                }
                
                // Default fallback if type matches nothing above
                return tTime || "NA"; 
              };
    
              // 2. Ensure lastExecution uses the available string from API if possible
              // The API provides lastRuntimeString which is already formatted
              const formattedExecution = item?.lastRuntimeString || 
                                         (item?.lastRuntime ? dateFormat(item.lastRuntime) : 'N/A');
    
              return {
                sno: index + 1,  
                taskName: item?.taskName ?? 'N/A',
                taskDescription: item?.taskDescription ?? 'N/A',
                lastExecution: formattedExecution,
                triggerTypeString: item?.triggerTypeString ?? 'N/A', // "Invalid" in your JSON, check if API can provide better
                time: calculateTimeValue(), 
                id: item.taskId || index, // Changed item.id to item.taskId based on your JSON
                resourceId: item?.resourceInfo?.resourceId
              };
            });
    
            setScheduleDetails(processedData);
          }
        } catch (error) {
          console.error("Fetch Error:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchData();
    }, [refreshTrigger]);
    
    // Ensure columns mapping is correct
    const tableColumns = columns.map(col => ({
      ...col,
      field: col.uid 
    }));
  
    return (
      <Box  >
        {loading ? (
          <Box className="flex justify-center p-10">
            <CircularProgress size={30} />
          </Box>
        ) : (
          <MTable
          privilegeKey={privilegeKey}
            //tableTitle="Schedule Backup"
            columns={tableColumns} 
            tableData={scheduleDetails}
            showPagination={true}
            handleDownloadPDF={() => exportToPDF("Schedule Backup Report", columns, scheduleDetails,"Schedule_Backup_Report")}
             showSearch={true}
          />
        )}
       
      </Box>
    );
  };
  
  export default DBbackupView;