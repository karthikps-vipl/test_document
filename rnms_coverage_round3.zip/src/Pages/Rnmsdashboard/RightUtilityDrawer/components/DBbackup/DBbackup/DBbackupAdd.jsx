import React, { useEffect, useState, useCallback } from "react";
import {
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  useTheme,
  CircularProgress,
} from "@mui/material";
import { TimePicker } from "antd";
import dayjs from "dayjs";

 
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MSelect from "@/components/Reusable/Select/MSelect";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import TextArea from "antd/es/input/TextArea";

 
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import {
  CREATE_SCHEDULE_TASK,
  FETCH_TASK_BASED_ON_TASK_TYPE,
} from "@/RestAPI/url/endpoint";
import { DbAxios } from "@/RestAPI/api/axiosApicall";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";

const freqMap = {
  0: "One Time",
  1: "Daily",
  3: "Quarterly",
  7: "Weekly",
  15: "Fortnightly",
  30: "Monthly",
  365: "Yearly",
};

const freqToType = {
  "One Time": 0,
  Daily: 1,
  Weekly: 7,
  Fortnightly: 15,
  Monthly: 30,
  Quarterly: 3,
  Yearly: 365,
};




const DBPreviousupAdd = ({ editData,isChildFullScreen }) => {
  const theme = useTheme();



  const [activeStep, setActiveStep] = useState(0);

  const [loading, setLoading] = useState(false);

  const [showConfirm, setShowConfirm] = useState(false);

  const [mode, setMode] = useState("CREATE");

  const [resources, setResources] = useState([]);

  const [descError, setDescError] = useState("");

  const [remainingChar, setRemainingChar] = useState(
    "255 characters remaining"
  );


  const [formData, setFormData] = useState({
    id: null,

    selectedDevice: null,

    taskName: "",

    description: "",

    frequency: "Daily",

    scheduleTime: dayjs(),

    selectedDay: 1,

    selectedDate: 1,

    selectedMonth: 1,

    location: "Local",
  });




  const formatTimeForPicker = (timeArray) => {
    const now = dayjs();

    if (Array.isArray(timeArray) && timeArray.length >= 2) {
      return now
        .hour(Number(timeArray[0]) || 0)
        .minute(Number(timeArray[1]) || 0)
        .second(Number(timeArray[2]) || 0);
    }

    return now;
  };



  const validateDescription = (e) => {
    const value = e.target.value;

    const MAX_LENGTH = 255;

    let error = "";

    if (/^\d/.test(value)) {
      error = "Description cannot start with a number";
    }

    if (value.length > MAX_LENGTH) {
      error = "Exceeded Maximum Limit";
    } else if (
      value.trim().length > 0 &&
      value.trim().length <= 2
    ) {
      error = "Need more than 2 Characters";
    }

    setDescError(error);

    setFormData((prev) => ({
      ...prev,
      description: value,
    }));

    setRemainingChar(`${value.length}/${MAX_LENGTH}`);
  };




  const dateOptions = Array.from(
    { length: 31 },
    (_, i) => ({
      label: i + 1,
      value: i + 1,
    })
  );



  const daysOptions = [
    {
      label: "Monday",
      value: 1,
    },
    {
      label: "Tuesday",
      value: 2,
    },
    {
      label: "Wednesday",
      value: 3,
    },
    {
      label: "Thursday",
      value: 4,
    },
    {
      label: "Friday",
      value: 5,
    },
    {
      label: "Saturday",
      value: 6,
    },
    {
      label: "Sunday",
      value: 7,
    },
  ];


  const monthOptions = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ].map((month, index) => ({
    label: month,
    value: index + 1,
  }));




  useEffect(() => {
    const fetchTaskData = async () => {
      try {
        setLoading(true);

        const response = await DbAxios(
          FETCH_TASK_BASED_ON_TASK_TYPE,
          "get"
        );

        const taskData = response?.data;

        console.log(
          "Existing DB Backup Task:",
          taskData
        );

  

        if (!taskData) {
          setMode("CREATE");

          setFormData({
            id: null,
            selectedDevice: null,
            taskName: "",
            description: "",
            frequency: "Daily",
            scheduleTime: dayjs(),
            selectedDay: 1,
            selectedDate: 1,
            selectedMonth: 1,
            location: "Local",
          });

          setResources([]);

          return;
        }



        const frequencyCode = Number(
          taskData.taskTriggerFreq
        );

        const savedFrequency =
          freqMap[frequencyCode] || "Daily";

        console.log(
          "Frequency Code:",
          frequencyCode
        );

        console.log(
          "Mapped Frequency:",
          savedFrequency
        );



        const matchedResource = {
          id: taskData.taskTypeId,

          label: taskData.taskName,

          value: taskData,
        };



        setResources([
          matchedResource,
        ]);


      

        setFormData({
          id: taskData.taskId || null,

          selectedDevice:
            matchedResource,

          taskName:
            taskData.taskName || "",

          description:
            taskData.taskDescription || "",

          frequency:
            savedFrequency,

          scheduleTime:
            taskData.triggerTime
              ? formatTimeForPicker(
                  taskData.triggerTime.split(":")
                )
              : dayjs(),

          selectedDay:
            Number(taskData.dayofWeek) || 1,

          selectedDate:
            Number(taskData.dayofMonth) || 1,

          selectedMonth:
            Number(taskData.triggerMonth) || 1,

          location:
            taskData.taskLocation || "Local",
        });





        setMode("EDIT");


    

        setActiveStep(0);


   

        const description =
          taskData.taskDescription || "";

        setRemainingChar(
          `${description.length}/255`
        );

      } catch (error) {
        console.error(
          "Error fetching task data:",
          error
        );

        setResources([]);

        setMode("CREATE");

      } finally {
        setLoading(false);
      }
    };

    fetchTaskData();
  }, []);



  useEffect(() => {
    if (!editData) {
      return;
    }

    console.log(
      "editData received:",
      editData
    );

    const frequencyCode =
      Number(editData.taskTriggerFreq);

    const savedFrequency =
      freqMap[frequencyCode] || "Daily";

    const matchedResource =
      resources.find(
        (resource) =>
          resource.id === editData.taskTypeId
      ) || {
        id: editData.taskTypeId,
        label: editData.taskName,
        value: editData,
      };


    setFormData({
      id:
        editData.taskId || null,

      selectedDevice:
        matchedResource,

      taskName:
        editData.taskName || "",

      description:
        editData.taskDescription || "",

      frequency:
        savedFrequency,

      scheduleTime:
        editData.triggerTime
          ? formatTimeForPicker(
              editData.triggerTime.split(":")
            )
          : dayjs(),

      selectedDay:
        Number(editData.dayofWeek) || 1,

      selectedDate:
        Number(editData.dayofMonth) || 1,

      selectedMonth:
        Number(editData.triggerMonth) || 1,

      location:
        editData.taskLocation || "Local",
    });

    setMode("EDIT");

    setActiveStep(0);

    const description =
      editData.taskDescription || "";

    setRemainingChar(
      `${description.length}/255`
    );

  }, [editData, resources]);


  const getScheduleDescription = () => {
    if (!formData.scheduleTime) {
      return "";
    }

    const time =
      formData.scheduleTime.format(
        "hh:mm A"
      );

    const {
      frequency,
      selectedDate,
      selectedMonth,
    } = formData;

    const day =
      formData.selectedDay ||
      "the selected day";




    if (frequency === "Daily") {
      return `This will take a database backup every day at ${time}.`;
    }



    if (frequency === "Weekly") {
      const selectedDayObject =
        daysOptions.find(
          (item) =>
            item.value ===
            Number(formData.selectedDay)
        );

      const dayName =
        selectedDayObject?.label ||
        day;

      return `This will take a database backup every ${dayName} at ${time}.`;
    }




    if (frequency === "Fortnightly") {
      return `This will take a database backup on the 1st and 15th of every month at ${time}.`;
    }



    if (frequency === "Monthly") {
      const date =
        Number(selectedDate) || 1;

      let suffix = "th";

      if (
        date % 100 < 11 ||
        date % 100 > 13
      ) {
        if (date % 10 === 1) {
          suffix = "st";
        } else if (date % 10 === 2) {
          suffix = "nd";
        } else if (date % 10 === 3) {
          suffix = "rd";
        }
      }

      return `This will take a database backup on the ${date}${suffix} of every month at ${time}.`;
    }



    if (frequency === "Quarterly") {
      return `This will take a database backup once every 3 months at ${time}.`;
    }




    if (frequency === "Yearly") {
      const monthObject =
        monthOptions.find(
          (item) =>
            item.value ===
            Number(selectedMonth)
        );

      const monthName =
        monthObject?.label ||
        "selected month";

      const date =
        Number(selectedDate) || 1;

      let suffix = "th";

      if (
        date % 100 < 11 ||
        date % 100 > 13
      ) {
        if (date % 10 === 1) {
          suffix = "st";
        } else if (date % 10 === 2) {
          suffix = "nd";
        } else if (date % 10 === 3) {
          suffix = "rd";
        }
      }

      return `This will run yearly on ${monthName} ${date}${suffix} at ${time}.`;
    }




    if (frequency === "One Time") {
      return `This will run once at ${time}.`;
    }


    return "";
  };



  const checkIsNextDisabled = () => {



    if (activeStep === 0) {
      const hasDevice =
        !!formData.selectedDevice;

      const hasTaskName =
        formData.taskName &&
        formData.taskName.trim().length > 0;

      const hasValidDesc =
        formData.description &&
        formData.description.trim().length >= 3 &&
        formData.description.length <= 255;

      return !(
        hasDevice &&
        hasTaskName &&
        hasValidDesc
      );
    }



    if (activeStep === 1) {
      return !formData.frequency;
    }


    return false;
  };




  const handleNext = () => {
    if (activeStep < 2) {
      setActiveStep(
        (prev) => prev + 1
      );
    }
  };



  const handlePrevious = () => {
    if (activeStep > 0) {
      setActiveStep(
        (prev) => prev - 1
      );
    }
  };



  const handleFrequencyChange = (event) => {
    const newFrequency =
      event.target.value;

    console.log(
      "Frequency changed to:",
      newFrequency
    );


    setFormData((prev) => ({
      ...prev,

      frequency:
        newFrequency,

     

      selectedDay:
        newFrequency === "Weekly"
          ? prev.selectedDay
          : 1,

      selectedDate:
        ["Monthly", "Yearly"].includes(
          newFrequency
        )
          ? prev.selectedDate
          : 1,

      selectedMonth:
        newFrequency === "Yearly"
          ? prev.selectedMonth
          : 1,
    }));
  };




  const handleFinalSchedule = async () => {
    setShowConfirm(false);

    setLoading(true);

    try {


      const frequencyCode =
        freqToType[
          formData.frequency
        ] ?? 0;


 

      


     

      const payload = {

        // IMPORTANT:
        // Use actual taskId for update
        taskId:
          formData.id ||
          formData.selectedDevice?.id ||
          0,


        taskName:
          formData.taskName,


        taskDescription:
          formData.description || null,


        taskLocation:
          formData.location ||
          "Local",


        taskTriggerFreq:
          frequencyCode,


        taskTypeId:
          formData.selectedDevice?.id ||
          1,


  

        triggerMonth:
          formData.frequency === "Yearly"
            ? Number(
                formData.selectedMonth
              )
            : 0,


 

        triggerTime:
          formData.scheduleTime
            ? formData.scheduleTime.format(
                "HH:mm:ss"
              )
            : "00:00:00",


    

        dayofWeek:
          formData.frequency === "Weekly"
            ? Number(
                formData.selectedDay
              )
            : 0,


    

        dayofMonth:
          ["Monthly", "Yearly"].includes(
            formData.frequency
          )
            ? Number(
                formData.selectedDate
              )
            : 0,


        fileName:
          null,


        filePath:
          null,
      };


     




      const response =
        await DbAxios(
          CREATE_SCHEDULE_TASK,
          "post",
          payload
        );


      

      if (
        response?.status === 200 &&
        response?.data
      ) {

        Toast(
          "Success!",
          `Schedule ${
            mode === "CREATE"
              ? "created"
              : "updated"
          } successfully.`,
          "success"
        );


    

        setMode("EDIT");


    

        setActiveStep(2);

      } else {

        Toast(
          "Error!",
          "Failed to process schedule.",
          "error"
        );
      }

    } catch (error) {

      console.error(
        "Schedule API Error:",
        error
      );

      Toast(
        "Error!",
        "Server error",
        "error"
      );

    } finally {

      setLoading(false);
    }
  };



 




  return (
    <Box
      sx={{
        p: 1,
        borderRadius: "10px",
        ml: 2,
        border: "2px solid #eee",
      }}
>

      <Typography
        variant="subtitle1"
        sx={{
          color: "text.TitleTextcolor",
          ml: 2,
          p: 0.5,
        }}
      >
        Schedule DB Config Backup
      </Typography>


   

      <Box
        sx={{
          borderTop:
            "2px solid #eeee",
          ml: -1,
          mr: -1,
          mt: 1,
        }}
      />




      <Stepper
        activeStep={activeStep}
        sx={{
          ml: 2,
          mr: 4,
          mt: 2,
        }}
      >
        {[
          "Task",
          "Frequency",
          "Trigger",
        ].map((label) => (
          <Step key={label}>
            <StepLabel>
              {label}
            </StepLabel>
          </Step>
        ))}
      </Stepper>


 

      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          alignItems: "stretch",
          gap: 3,
          width: "100%",
          mt: 2,
        }}
      >


        <Box
          sx={{
            flex: 1,
            p: 4,
            borderRadius: "10px",
            bgcolor:
              "background.paper",
            display: "flex",
            flexDirection: "column",
            border:
              "1px solid #d9d9d9",
          }}
        >

          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 2.5,
              flexGrow: 1,
            }}
          >

      

            <Box>

              <Typography
                sx={{ mb: 1 }}
              >
                Task Name *
              </Typography>

              <MInput
                placeholder="Enter Task Name"
                fullWidth
                value={
                  formData.taskName
                }
                onChange={(e) =>
                  setFormData(
                    (prev) => ({
                      ...prev,
                      taskName:
                        e.target.value,
                    })
                  )
                }
              />

            </Box>



            <Box>

              <Typography
                sx={{ mb: 1 }}
              >
                Task Type *
              </Typography>

              <MSelect
                options={resources}
                value={
                  formData.selectedDevice
                }
                onChange={(val) =>
                  setFormData(
                    (prev) => ({
                      ...prev,
                      selectedDevice:
                        val,
                    })
                  )
                }
                placeholder="Select Device"
                fullWidth
                disabled={true}
              />

            </Box>


        

            <Box>

              <Typography
                sx={{ mb: 1 }}
              >
                Task Description *
              </Typography>

              <TextArea
                rows={3}
                maxLength={255} 
                value={
                  formData.description
                }
                onChange={
                  validateDescription
                }
                placeholder="Min 3 characters"
                className={
                  theme.palette.mode ===
                  "dark"
                    ? "dark-ant-textarea"
                    : ""
                }
                style={{
                  borderColor:
                    descError
                      ? "#ff4d4f"
                      : "#d9d9d9",

                  fontFamily:
                    "Montserrat",

                  resize: "none",

                  width: "100%",

                  background:
                    theme.palette.mode ===
                    "dark"
                      ? "#121212"
                      : "#ffffff",

                  color:
                    theme.palette.mode ===
                    "dark"
                      ? "#ffffff"
                      : "rgba(0, 0, 0, 0.88)",
                }}
              />

              <Typography
                variant="caption"
                sx={{
                  color: descError
                    ? "#e75656"
                    : "textSecondary",
                }}
              >
                {
                  descError ||
                  remainingChar
                }
              </Typography>

            </Box>

          </Box>

        </Box>



        <Box
          sx={{
            flex: 1,
            p: 3,
            borderRadius: "10px",
            display: "flex",
            flexDirection: "column",
            transition:
              "all 0.3s ease",
            border:
              "1px solid #d9d9d9",
          }}
        >

          {activeStep >= 1 ? (

            <Box
              sx={{
                flexGrow: 1,
              }}
            >

              <Typography>
                Trigger Type *
              </Typography>


       

              <RadioGroup
                value={
                  formData.frequency
                }
                onChange={
                  handleFrequencyChange
                }
              >

                {[
                  "Daily",
                  "Weekly",
                  "Fortnightly",
                  "Monthly",
                  "Quarterly",
                  "Yearly",
                ].map((item) => (

                  <FormControlLabel
                    key={item}
                    value={item}
                    control={
                      <Radio
                        size="small"
                      />
                    }
                    label={item}
                  />

                ))}

              </RadioGroup>

            </Box>

          ) : (

            <Box
              sx={{
                display: "flex",
                alignItems:
                  "center",
                justifyContent:
                  "center",
                height: "100%",
              }}
            />

          )}

        </Box>



        <Box
          sx={{
            flex: 1,
            p: 4,
            borderRadius: "10px",
            display: "flex",
            flexDirection: "column",
            transition:
              "all 0.3s ease",
            border:
              "1px solid #d9d9d9",
          }}
        >

          {activeStep >= 2 ? (

            <Box
              sx={{
                flexGrow: 1,
              }}
            >

           

              {![
                "Quarterly",
                "Fortnightly",
              ].includes(
                formData.frequency
              ) && (

                <>

   

                  <Typography
                    sx={{ mb: 1 }}
                  >
                    Time *
                  </Typography>

                  <TimePicker
                    value={
                      formData.scheduleTime
                    }
                    onChange={(time) =>
                      setFormData(
                        (prev) => ({
                          ...prev,
                          scheduleTime:
                            time,
                        })
                      )
                    }
                    format="HH:mm:ss"
                    style={{
                      height: 45,
                      width: "100%",
                      background:
                        theme.palette
                          .mode ===
                        "dark"
                          ? "#121212"
                          : "#ffffff",
                      color:
                        theme.palette
                          .mode ===
                        "dark"
                          ? "#ffffff"
                          : "rgba(0, 0, 0, 0.88)",
                    }}
                    allowClear={false}
                    getPopupContainer={(
                      trigger
                    ) =>
                      trigger.parentElement
                    }
                  />


             

                  {formData.frequency ===
                    "Weekly" && (

                    <Box sx={{ mt: 2 }}>

                      <Typography
                        sx={{ mb: 1 }}
                      >
                        Select Day *
                      </Typography>

                      <MSelect
                        options={
                          daysOptions
                        }
                        value={
                          formData.selectedDay
                        }
                        onChange={(val) =>
                          setFormData(
                            (prev) => ({
                              ...prev,
                              selectedDay:
                                val?.value,
                            })
                          )
                        }
                      />

                    </Box>

                  )}


                

                  {[
                    "Monthly",
                    "Yearly",
                  ].includes(
                    formData.frequency
                  ) && (

                    <Box sx={{ mt: 2 }}>

                      <Typography
                        sx={{ mb: 1 }}
                      >
                        Select Date *
                      </Typography>

                      <MSelect
                        options={
                          dateOptions
                        }
                        value={
                          formData.selectedDate
                        }
                        onChange={(val) =>
                          setFormData(
                            (prev) => ({
                              ...prev,
                              selectedDate:
                                val?.value,
                            })
                          )
                        }
                      />

                    </Box>

                  )}



                  {formData.frequency ===
                    "Yearly" && (

                    <Box sx={{ mt: 2 }}>

                      <Typography
                        sx={{ mb: 1 }}
                      >
                        Select Month *
                      </Typography>

                      <MSelect
                        options={
                          monthOptions
                        }
                        value={
                          formData.selectedMonth
                        }
                        onChange={(val) =>
                          setFormData(
                            (prev) => ({
                              ...prev,
                              selectedMonth:
                                val?.value,
                            })
                          )
                        }
                      />

                    </Box>

                  )}

                </>

              )}


              {[
                "Fortnightly",
                "Quarterly",
              ].includes(
                formData.frequency
              ) && (

                <Box sx={{ p: 1 }}>

                  <Typography
                    color="text.secondary"
                  >
                    {
                      getScheduleDescription()
                    }
                  </Typography>

                </Box>

              )}


             

              <Box
                sx={{
                  display: "flex",
                  justifyContent:
                    "flex-end",
                  mt: 4,
                }}
              >

                <MButtonPrimary
                  variant="contained"
                  onClick={() =>
                    setShowConfirm(
                      true
                    )
                  }
                >
                  {mode === "CREATE"
                    ? "Schedule"
                    : "Update"}
                </MButtonPrimary>

              </Box>

            </Box>

          ) : (

            <Box
              sx={{
                display: "flex",
                alignItems:
                  "center",
                justifyContent:
                  "center",
                height: "100%",
              }}
            />

          )}

        </Box>

      </Box>




      <Box
        sx={{
          display: "flex",
          justifyContent:
            "center",
          mt: 4,
          gap: 2,
        }}
      >



        <MButtonSecondary
          variant="outlined"
          onClick={
            handlePrevious
          }
          disabled={
            activeStep === 0
          }
        >
          Previous
        </MButtonSecondary>


   

        {activeStep === 0 && (

          <MButtonPrimary
            sx={{
              p: 3,
              width: "20%",
            }}
            disabled={
              checkIsNextDisabled()
            }
            onClick={
              handleNext
            }
          >
            Next
          </MButtonPrimary>

        )}


        

        {activeStep === 1 && (

          <MButtonPrimary
            sx={{
              p: 3,
            }}
            disabled={
              checkIsNextDisabled()
            }
            onClick={
              handleNext
            }
          >
            Next
          </MButtonPrimary>

        )}


      </Box>




      <MDialog
        isInsideDrawer={true}

        open={showConfirm}
        isSubmitting={loading}
        variant="info"

        mode="child"
        
        isChildFullScreen={isChildFullScreen}

        icon={Confirmation_icon}

        title="Confirm Action"

        message={
          getScheduleDescription()
        }

        onConfirm={
          handleFinalSchedule
        }

        onClose={
          loading
            ? undefined
            : () =>
                setShowConfirm(
                  false
                )
        }
      />

    </Box>
  );
};


export default DBPreviousupAdd;
