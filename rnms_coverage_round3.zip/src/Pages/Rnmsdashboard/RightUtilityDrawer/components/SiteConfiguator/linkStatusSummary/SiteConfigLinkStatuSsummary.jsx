import MForm from "@/components/Reusable/Form/MForm";
import Toast from "@/components/Reusable/Toast/Toast";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_LINK_STATUS_SUMMARY } from "@/RestAPI/url/endpoint";
import { Box, CircularProgress, Grid, Paper, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import StopIcon from "@mui/icons-material/Stop";
const SiteConfigLinkStatuSsummary = ({ refreshTrigger }) => {
    const [snmpData, setSnmpData] = useState([]);
    const [loading, setLoading] = useState(false);

    // --- 1. CONFIGURATION ---
    // const theme = useTheme()
    // const chartColors = theme.palette.custom.chart;

    // Helper to map your API status to colors
    const getColor = (name) => {
        switch (name) {
            case "Uptime": return "#FEB5B5";        // Reddish
            case "DownTime": return "#FFF692";      // Yellowish
            case "Operational DownTime": return "#72BEF1"; // Bluish
            default: return "#8884d8";
        }
    };

    // --- 2. DATA TRANSFORMER ---
    // Converts API object into Recharts array format: [{ name: '...', value: 10 }, ...]
    const formatDataForRecharts = (item) => {
        return [
            { name: "Uptime", value: item.uptimePercent || 0 },
            { name: "DownTime", value: item.downTimePercent || 0 },
            { name: "Operational DownTime", value: item.opDownTimePercent || 0 },
        ].filter(entry => entry.value > 0); // Hide slices with 0 value
    };

    // --- 3. API FETCHING ---
    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const response = await TopologyAxios(FETCH_LINK_STATUS_SUMMARY, "get");
                const data = response?.data || [];
                console.log("ahfkjfjkahfjahf", data)
                setSnmpData(data);
            } catch (error) {
                console.error("Error fetching Snmp Details:", error);
                Toast("Error!", "Failed to fetch Snmp Details", "error");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [refreshTrigger]);
    return (
        <MForm title="Router Wan Interface Status Summary">
            {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                    <CircularProgress />
                </Box>
            ) : snmpData.length > 0 ? (
                <>
                    {/* 1. GLOBAL LEGEND (Appears once above all cards) */}
                    <Grid
                        container
                        spacing={2}

                        alignItems="center"
                        justifyContent="center"
                        marginBottom={2}
                    >
                        <Grid item xs={12} md={3}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, }}>
                                <Typography variant="body2">Uptime</Typography>
                                <StopIcon sx={{ color: "#FEB5B5", fontSize: '1.2rem', }} />
                            </Box>
                        </Grid>


                        <Typography variant="body2">DownTime</Typography>
                        <StopIcon sx={{ color: "#FFF692", fontSize: '1.2rem' }} />


                        <Grid item xs={12} md={4}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <Typography variant="body2">Operational DownTime</Typography>
                                <StopIcon sx={{ color: "#72BEF1", fontSize: '1.2rem' }} />
                            </Box>
                        </Grid>
                    </Grid>

                    {/* 2. THE CARDS CONTAINER */}
                    <Box
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 items-start"
                        sx={{
                            width: '100%',
                        }}
                    >
                        {snmpData.map((item, index) => {
                            const pieData = formatDataForRecharts(item);

                            return (
                                <Paper
                                    key={index}
                                    elevation={0}
                                    sx={{
                                        display: 'flex',
                                        flexDirection: 'column',

                                        p: 0.5,
                                        border: '2px solid #eee'
                                    }}
                                >
                                    <Typography sx={{ textAlign: 'center', }}   >
                                        {item.linkTypeName || item.name || `Device ${index + 1}`}
                                    </Typography>

                                    <Box className="w-full h-[200px]  ">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie
                                                    data={pieData}
                                                    cx="50%"
                                                    cy="50%"
                                                    labelLine={false}
                                                    dataKey="value"
                                                    isAnimationActive={false}
                                                    label={({ cx, cy, midAngle, outerRadius, percent, payload }) => {
                                                        const RADIAN = Math.PI / 180;
                                                        const radius = outerRadius * 0.55;
                                                        const x = cx + radius * Math.cos(-midAngle * RADIAN);
                                                        const y = cy + radius * Math.sin(-midAngle * RADIAN);

                                                        return (
                                                            <g>
                                                                {/* Line 1: The Percentage (e.g., 75%) */}
                                                                <text
                                                                    x={x}
                                                                    y={y - 8}
                                                                    fill="#000000"
                                                                    textAnchor="middle"
                                                                    dominantBaseline="central"
                                                                    style={{ fontSize: "11px", fontWeight: "bold" }}
                                                                >
                                                                    {`${(percent * 100).toFixed(0)}%`}
                                                                </text>

                                                                {/* Line 2: The Raw Value (e.g., 75) */}
                                                                <text
                                                                    x={x}
                                                                    y={y + 8}
                                                                    fill="#333333"
                                                                    textAnchor="middle"
                                                                    dominantBaseline="central"
                                                                    style={{ fontSize: "10px", fontWeight: "normal" }}
                                                                >
                                                                   ({payload.value}) 
                                                                </text>
                                                            </g>
                                                        );
                                                    }}
                                                >
                                                    {pieData.map((entry, i) => (
                                                        <Cell key={`cell-${i}`} fill={getColor(entry.name)} />
                                                    ))}
                                                </Pie>
                                                {/* <Tooltip
                                                    formatter={(value) => [`${value}%`, 'Status']}
                                                    contentStyle={{
                                                        borderRadius: "8px",
                                                        border: "none",
                                                        boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                                                        backgroundColor: chartColors.tooltipBg,
                                                        color: chartColors.tooltipText,
                                                    }}
                                                /> */}
                                                {/* Removed the individual Legend here to avoid clutter */}
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </Box>
                                </Paper>
                            );
                        })}
                    </Box>
                </>
            ) : (
                <Typography align="center" sx={{ py: 5 }}>No Records Found</Typography>
            )}
        </MForm>
    );
    // return (
    //     <MForm title="Link Status Summary">
    //       {loading ? (
    //         <Box sx={{  display: 'flex', justifyContent: 'center', p: 3 }}>
    //           <CircularProgress />
    //         </Box>
    //       ) : snmpData.length > 0 ? (

    //         <Box 
    //           sx={{ 
    //             display: 'flex', 
    //             flexDirection: 'row', 
    //             flexWrap: 'wrap', 
    //             gap: 1, // This creates spacing between the cards
    //             width: '100%' 
    //           }}
    //         >



    //           {snmpData.map((item, index) => {
    //             const pieData = formatDataForRecharts(item);

    //             return (

    //               <Paper 
    //                 key={index}

    //                 sx={{ 
    //                   display: 'flex',
    //                   flexDirection: 'column',

    //                   minWidth: '249px', // Prevents them from getting too squished
    //                   p: 2,

    //                 }}
    //               >
    //                 <Typography variant="subtitle1" fontWeight="bold" noWrap>
    //                   {item.linkTypeName || item.name || `Device ${index + 1}`}
    //                 </Typography>

    //                 <Box className="w-full h-[220px] mt-2">
    //                   <ResponsiveContainer width="100%" height="100%">
    //                     <PieChart>
    //                       <Pie
    //                         data={pieData}
    //                         cx="50%"
    //                         cy="50%"
    //                         labelLine={false}
    //                         dataKey="value"
    //                         isAnimationActive={false}
    //                         label={({ cx, cy, midAngle, outerRadius, percent }) => {
    //                           const RADIAN = Math.PI / 180;
    //                           const radius = outerRadius * 0.55;
    //                           const x = cx + radius * Math.cos(-midAngle * RADIAN);
    //                           const y = cy + radius * Math.sin(-midAngle * RADIAN);
    //                           return (
    //                             <text
    //                               x={x}
    //                               y={y}
    //                               fill="#000000"
    //                               textAnchor="middle"
    //                               dominantBaseline="central"
    //                               style={{ fontSize: "11px", fontWeight: "bold" }}
    //                             >
    //                               {`${(percent * 100).toFixed(0)}%`}
    //                             </text>
    //                           );
    //                         }}
    //                       >
    //                         {pieData.map((entry, i) => (
    //                           <Cell key={`cell-${i}`} fill={getColor(entry.name)} />
    //                         ))}
    //                       </Pie>
    //                       <Tooltip 
    //                         formatter={(value) => [`${value}%`, 'Status']} 
    //                         contentStyle={{
    //                           borderRadius: "8px",
    //                           border: "none",
    //                           boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
    //                           backgroundColor: chartColors.tooltipBg,
    //                           color: chartColors.tooltipText,
    //                         }} 
    //                       />
    //                       <Legend 
    //                         verticalAlign="bottom" 
    //                         align="center" 
    //                         iconType="circle" 
    //                         wrapperStyle={{ fontSize: "10px", paddingTop: "10px" }} 
    //                       />
    //                     </PieChart>
    //                   </ResponsiveContainer>
    //                 </Box>
    //               </Paper>
    //             );
    //           })}
    //         </Box>
    //       ) : (
    //         <Typography align="center" sx={{ py: 5 }}>No Records Found</Typography>
    //       )}
    //     </MForm>
    //   );
}
export default SiteConfigLinkStatuSsummary; 