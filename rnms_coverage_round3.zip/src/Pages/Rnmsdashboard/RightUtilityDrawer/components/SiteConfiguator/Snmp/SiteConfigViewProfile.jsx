/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Snmp
   File Name                : SiteConfigViewProfile.jsx
   Author                   : Ankitha - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\Snmp\SiteConfigViewProfile.jsx
   Purpose                  : Provides form for view SNMP Profile.
   Created Date             : 09-04-2026
***********************************************************************************************/
import React from "react";
import { Box, Typography } from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";

const FieldWrapper = ({ label, children }) => (
  <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
    <Typography variant="body2" sx={{ mb: 0.5, fontSize: '16px' }}>
      {label}
    </Typography>
    {children}
  </Box>
);

const SiteConfigViewProfile = ({ data }) => {
  // 1. Capture raw version. Do NOT wrap in Number().
  const rawVersion = data?.version;
  
  // 2. Determine if it's V3 (Handles number 3 or string "3")
  const isVersion3 = String(rawVersion) === "3";

  const securityLevel = data?.securityLevel?.toString() || "1";

  const getLabel = (type, val) => {
    // If value is null or undefined, return empty string
    if (val === undefined || val === null) return "";

    const maps = {
      version: {
        "1": "1",
        "2": "2c",
        "2c": "2c",
        "3": "3"
      },
      security: {
        "1": "No Auth / No Privacy",
        "2": "Auth / No Privacy",
        "3": "Auth / Privacy",
      },
      auth: {
        "1": "MD5",
        "2": "SHA",
        "3": "SHA224",
        "4": "SHA256",
        "5": "SHA384",
        "6": "SHA512"
      },
      priv: {
        "1": "DES",
        "2": "AES128",
        "3": "AES192",
        "4": "AES256"
      },
    };

    // Convert current value to string to match map keys
    const key = String(val);

    // Check if the key exists in our map
    if (maps[type] && maps[type][key] !== undefined) {
      return maps[type][key];
    }

    // FALLBACK: If not in map, return the original value as a string 
    // This prevents NaN and shows exactly what the API sent
    return String(val);
  };

  return (
    <Box
      sx={{
        display: "grid",
        gridTemplateColumns: isVersion3 ? "repeat(2, 1fr)" : "1fr",
        gap: 3,
        p: 2,
        width: "100%",
        mb: 2
      }}
    >
      <FieldWrapper label="Profile Name">
        <MInput fullWidth disabled value={data?.snmpProfileName || ""} />
      </FieldWrapper>
      <FieldWrapper label="Port">
        <MInput fullWidth disabled value={data?.port || ""} />
      </FieldWrapper>
      <FieldWrapper label="No of Retries">
        <MInput fullWidth disabled value={data?.retries || ""} />
      </FieldWrapper>
      <FieldWrapper label="Timeout (Sec)">
        <MInput fullWidth disabled value={data?.timeout || ""} />
      </FieldWrapper>

      {/* VERSION FIELD */}
      <FieldWrapper label="Version">
        <MInput fullWidth disabled value={getLabel("version", rawVersion)} />
      </FieldWrapper>

      {isVersion3 && (
        <FieldWrapper label="Security Level">
          <MInput
            fullWidth
            disabled
            value={getLabel("security", securityLevel)}
            sx={{fontsize:"10px"}}
          />
        </FieldWrapper>
      )}

      {!isVersion3 ? (
        <>
          <FieldWrapper label="Read Community">
            <MInput fullWidth disabled value={data?.readCommunity || ""} />
          </FieldWrapper>
          <FieldWrapper label="Write Community">
            <MInput fullWidth disabled value={data?.writeCommunity || ""} />
          </FieldWrapper>
        </>
      ) : (
        <>
          <FieldWrapper label="USM User">
            <MInput
              fullWidth
              disabled
              value={data?.username || data?.userName || ""}
            />
          </FieldWrapper>
          <FieldWrapper label="Context Name">
            <MInput fullWidth disabled value={data?.contextName || ""} />
          </FieldWrapper>
        </>
      )}

      {isVersion3 && securityLevel !== "1" && (
        <>
          <FieldWrapper label="Auth Protocol">
            <MInput
              fullWidth
              disabled
              value={getLabel("auth", data?.authProtocol)}
            />
          </FieldWrapper>
          <FieldWrapper label="Auth Password">
            <MInput fullWidth disabled value={data?.authPassword || ""} />
          </FieldWrapper>
        </>
      )}

      {isVersion3 && securityLevel === "3" && (
        <>
          <FieldWrapper label="Priv Protocol">
            <MInput
              fullWidth
              disabled
              value={getLabel("priv", data?.privProtocol)}
            />
          </FieldWrapper>
          <FieldWrapper label="Private Password">
            <MInput fullWidth disabled value={data?.privPassword || ""} />
          </FieldWrapper>
        </>
      )}
    </Box>
  );
};

export default SiteConfigViewProfile;