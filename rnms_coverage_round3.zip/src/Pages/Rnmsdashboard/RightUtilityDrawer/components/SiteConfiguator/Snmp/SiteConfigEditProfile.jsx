/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Snmp
   File Name                : SiteConfigCreateProfile.jsx
   Author                   : Ankitha - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\Snmp\SiteConfigCreateProfile.jsx
   Purpose                  : Provides form for edit SNMP Profile.
   Created Date             : 09-04-2026
***********************************************************************************************/

import React, { useState } from "react";
import { useFormik } from "formik";
import {
  Box,
  Typography,
  CircularProgress,
  FormControl,
  InputAdornment,
  IconButton,
} from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import { UPDATE_SNMP_PROFILE_DETAILS } from "@/RestAPI/url/endpoint";
import { snmpValidationSchema } from "@/utility/FormValidation/YupSchema";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import MSelect from "@/components/Reusable/Select/MSelect";

const SiteConfigEditProfile = ({ refreshData, data, onSuccess, onClose,isGrandchildFullScreen }) => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [visibleFields, setVisibleFields] = useState({});

  const toggleVisibility = (fieldName) => {
    setVisibleFields((prev) => ({ ...prev, [fieldName]: !prev[fieldName] }));
  };

  const formik = useFormik({
    initialValues: {
      snmpProfileName: data?.snmpProfileName || "",
      port: data?.port || "161",
      retries: data?.retries || "",
      timeout: data?.timeout || "",
      // FIXED VERSION MAPPING: Ensure we map exactly what the Select expects
      version: (() => {
        const val = String(data?.version);
        if (val === "1") return 0;
        if (val === "2c") return 1;
        if (val === "3") return 3;
        return 0;
      })(),
      readCommunity: data?.readCommunity || "",
      writeCommunity: data?.writeCommunity || "",
      username: data?.username || "",
      contextName: data?.contextName || "",
      securityLevel: String(data?.securityLevel || "1"), // Force string to match MenuItem values
      authProtocol: String(data?.authProtocol || "1"),
      authPassword: data?.authPassword || "",
      privProtocol: String(data?.privProtocol || "1"),
      privPassword: data?.privPassword || "",
    },

    enableReinitialize: true,
    validationSchema: snmpValidationSchema,
    validateOnChange: true,
    validateOnBlur: true,
    
    onSubmit: async (values) => {
      setLoading(true);
      try {
        // 1. Base Payload
        // IMPORTANT: We pass values.version directly as a Number
        let payload = {
          snmpProfileId: data?.snmpProfileId || data?.id,
          snmpProfileName: String(values.snmpProfileName),
          port: String(values.port),
          retries: String(values.retries),
          timeout: String(values.timeout),
          // Pass the numeric value directly (0, 1, or 3)
          version: Number(values.version),
        };

        // 2. Logic for SNMP Version 3 (Numeric 3)
        if (Number(values.version) === 3) {
          payload = {
            ...payload,
            username: String(values.username),
            contextName: String(values.contextName),
            securityLevel: String(values.securityLevel),
          };

          if (values.securityLevel !== "1") {
            payload.authProtocol = String(values.authProtocol);
            payload.authPassword = String(values.authPassword);
          }

          if (values.securityLevel === "3") {
            payload.privProtocol = String(values.privProtocol);
            payload.privPassword = String(values.privPassword);
          }
        }
        // 3. Logic for SNMP Version 1 (0) or 2c (1)
        else {
          payload = {
            ...payload,
            readCommunity: String(values.readCommunity),
            writeCommunity: String(values.writeCommunity),
          };
        }

        // Debugging: Check your console to see if 'version' is a number in this object
        console.log("Sending Payload to API:", payload);

        const response = await TopologyAxios(UPDATE_SNMP_PROFILE_DETAILS, "post", payload);

        if (response.status === 200) {
          Toast("Success!", "Successfully updated SNMP Profile", "success");
          if (refreshData) refreshData();
          onSuccess();
          onClose();
        }
      } catch (err) {
        console.error("API Error Details:", err.response?.data || err.message);
        Toast("Error!", "Update failed", "error");
      } finally {
        setLoading(false);
      }
    },
  });

  const handleInputChange = (event, fieldName) => {
    const value = event.target.value;

    formik.setFieldValue(fieldName, value, true);
    formik.setFieldTouched(fieldName, true, false);
  
  };

  // Helper for visibility check
  const isVersion3 = Number(formik.values.version) === 3;

  // Mandatory field validation logic
  const isMandatoryValid =
  String(formik.values.snmpProfileName ?? "").trim() !== "" &&
  String(formik.values.port ?? "").trim() !== "" &&
  String(formik.values.retries ?? "").trim() !== "" &&
  String(formik.values.timeout ?? "").trim() !== "" &&
  !formik.errors.snmpProfileName &&
  !formik.errors.port &&
  !formik.errors.retries &&
  !formik.errors.timeout;

const isSaveDisabled =
  !isMandatoryValid ||
  !formik.isValid ||
  !formik.dirty ||
  loading;


  return (
    <Box
      component="form"
      onSubmit={formik.handleSubmit}
      sx={{
        display: "grid",
        // Use a consistent 2-column grid for V3 to prevent "jumping" 
        // and a 1-column grid for V1/V2.
        gridTemplateColumns: isVersion3 ? "repeat(2, 1fr)" : "1fr",
        gap: 2,
        p: 1
      }}
    >
      {/* Standard Fields */}
      <Box sx={{ display: "flex", flexDirection: "column" }}>
        <Typography sx={{ mb: 0.5 }}>Profile Name *</Typography>
        <MInput
          value={formik.values.snmpProfileName}
          onChange={(e) => handleInputChange(e, "snmpProfileName")}
          errorMessage={formik.touched.snmpProfileName && formik.errors.snmpProfileName}
        />
      </Box>

      <Box sx={{ display: "flex", flexDirection: "column" }}>
        <Typography sx={{ mb: 0.5 }}>Port *</Typography>
        <MInput
          value={formik.values.port}
          onChange={(e) => handleInputChange(e, "port")}
          errorMessage={formik.touched.port && formik.errors.port}
        />
      </Box>

      <Box sx={{ display: "flex", flexDirection: "column" }}>
        <Typography sx={{ mb: 0.5 }}>No of Retries *</Typography>
        <MInput
          value={formik.values.retries}
          onChange={(e) => handleInputChange(e, "retries")}
          errorMessage={formik.touched.retries && formik.errors.retries}
        />
      </Box>
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
  <Typography sx={{ mb: 0.5 }}>Timeout (Sec) *</Typography>
  <MInput
    value={formik.values.timeout}
    onChange={(e) => {
      const val = e.target.value;
      
      // This Regex allows:
      // 1. Empty string (so user can backspace)
      // 2. Only digits (0-9)
      if (val === "" || /^[0-9]*$/.test(val)) {
        handleInputChange(e, "timeout");
      }
    }}
    errorMessage={formik.touched.timeout && formik.errors.timeout}
  />
</Box>
      {/* <Box sx={{ display: "flex", flexDirection: "column" }}>
        <Typography sx={{ mb: 0.5 }}>Timeout (Sec) *</Typography>
        <MInput
          value={formik.values.timeout}
          onChange={(e) => handleInputChange(e, "timeout")}
          errorMessage={formik.touched.timeout && formik.errors.timeout}
        />
      </Box> */}

      {/* Version Selector */}
      <Box sx={{ display: "flex", flexDirection: "column" }}>
        <Typography sx={{ mb: 0.5 }}>Version *</Typography>
        <FormControl fullWidth size="small">
          <MSelect

            placeholder="Select version"
            // Transform your values into the object format MSelect expects
            options={[
              { label: "1", value: 0 },
              { label: "2c", value: 1 },
              { label: "3", value: 3 },
            ]}
            // This ensures the Select finds the correct option even though value is a number
            getOptionValue={(option) => option.value}
            getOptionLabel={(option) => option.label}

            value={formik.values.version}
            onChange={(selectedOption) => {
              // Since MSelect returns the whole object {label, value}, 
              // we extract the .value (the number) to save into Formik
              const val = selectedOption && typeof selectedOption === 'object'
                ? selectedOption.value
                : selectedOption;

              formik.setFieldValue("version", val);
            }}
          />
          {/* <Select

            value={formik.values.version} // No need for Number() fallback here if initialValues is solid
            onChange={(e) => formik.setFieldValue("version", e.target.value)}
          >
            <MenuItem value={0}>1</MenuItem>
            <MenuItem value={1}>2c</MenuItem>
            <MenuItem value={3}>3</MenuItem>
          </Select> */}
        </FormControl>
      </Box>

      {/* Conditional Logic: V1 / V2c */}
      {!isVersion3 && (
        <>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography sx={{ mb: 0.5 }}>Read Community *</Typography>
            <MInput
              type={visibleFields.readCommunity ? "text" : "password"}
              value={formik.values.readCommunity}
              onChange={(e) => handleInputChange(e, "readCommunity")}
              errorMessage={formik.touched.readCommunity && formik.errors.readCommunity}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => toggleVisibility("readCommunity")} edge="end">
                      {visibleFields.readCommunity ? <VisibilityIcon /> : <VisibilityOffIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography sx={{ mb: 0.5 }}>Write Community *</Typography>
            <MInput
              type={visibleFields.writeCommunity ? "text" : "password"}
              value={formik.values.writeCommunity}
              onChange={(e) => handleInputChange(e, "writeCommunity")}
              errorMessage={formik.touched.writeCommunity && formik.errors.writeCommunity}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => toggleVisibility("writeCommunity")} edge="end">
                      {visibleFields.writeCommunity ? <VisibilityIcon /> : <VisibilityOffIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>
        </>
      )}

      {/* Conditional Logic: V3 */}
      {isVersion3 && (
        <>
        <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography sx={{ mb: 0.5 }}>USM User *</Typography>
            <MInput
              value={formik.values.username}
              onChange={(e) => handleInputChange(e, "username")}
              errorMessage={formik.touched.username && formik.errors.username}
            />
          </Box>

          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography sx={{ mb: 0.5 }}>Context Name</Typography>
            <MInput
              value={formik.values.contextName}
              onChange={(e) => handleInputChange(e, "contextName")}
              errorMessage={formik.touched.contextName && formik.errors.contextName}
            />
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography sx={{ mb: 0.5 }}>Security Level *</Typography>
            <FormControl fullWidth size="small">
              {/* <Select
                value={formik.values.securityLevel}
                //sx={{fontSize:'12px'}}
                onChange={(e) => formik.setFieldValue("securityLevel", e.target.value)}
              >
                <MenuItem value="1">No Auth / No Privacy</MenuItem>
                <MenuItem value="2">Auth / No Privacy</MenuItem>
                <MenuItem value="3">Auth / Privacy</MenuItem>
              </Select> */}
              <MSelect
                placeholder="Select level"
                options={[
                  { label: "No Auth / No Privacy", value: "1" },
                  { label: "Auth / No Privacy", value: "2" },
                  { label: "Auth / Privacy", value: "3" },
                ]}
                value={formik.values.securityLevel}
                onChange={(option) => {
                  // This ensures Formik gets "1" instead of {label: "...", value: "1"}
                  const valueToSet = option && typeof option === 'object' ? option.value : option;
                  formik.setFieldValue("securityLevel", valueToSet);
                }}
                getOptionValue={(opt) => opt.value}
                getOptionLabel={(opt) => opt.label}
              />
            </FormControl>
          </Box>

          

          {/* Auth Fields (Level 2 & 3) */}
          {formik.values.securityLevel !== "1" && (
            <>
              <Box sx={{ display: "flex", flexDirection: "column" }}>
                <Typography sx={{ mb: 0.5 }}>Auth Protocol *</Typography>
                <FormControl fullWidth size="small">
                  {/* <Select
                    value={formik.values.authProtocol}
                    onChange={(e) => formik.setFieldValue("authProtocol", e.target.value)}
                  >
                    <MenuItem value="1">MD5</MenuItem>
                    <MenuItem value="2">SHA</MenuItem>
                  </Select> */}
                  <MSelect
                     placeholder="Select protocol"
                    options={[
                      { label: "MD5", value: "1" },
                      { label: "SHA", value: "2" },
                      { label: "SHA224", value: "3" },
                      { label: "SHA256", value: "4" },
                      { label: "SHA384", value: "5" },
                      { label: "SHA512", value: "6" }

                    ]}
                    
                    getOptionValue={(opt) => opt.value}
                    getOptionLabel={(opt) => opt.label}
                    value={formik.values.authProtocol}
                    onChange={(selectedOption) => {
                      // Extract the string value ("1" or "2") from the object
                      const val = selectedOption && typeof selectedOption === 'object'
                        ? selectedOption.value
                        : selectedOption;

                      formik.setFieldValue("authProtocol", val);
                    }}
                  />
                </FormControl>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "column" }}>
                <Typography sx={{ mb: 0.5 }}>Auth Password *</Typography>
                <MInput
                  type={visibleFields.authPassword ? "text" : "password"}
                  value={formik.values.authPassword}
                  onChange={(e) => handleInputChange(e, "authPassword")}
                  errorMessage={formik.touched.authPassword && formik.errors.authPassword}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => toggleVisibility("authPassword")} edge="end">
                          {visibleFields.authPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
            </>
          )}

          {/* Priv Fields (Level 3 Only) */}
          {formik.values.securityLevel === "3" && (
            <>
              <Box sx={{ display: "flex", flexDirection: "column" }}>
                <Typography sx={{ mb: 0.5 }}>Priv Protocol *</Typography>
                <FormControl fullWidth size="small">
                  {/* <Select
                    value={formik.values.privProtocol}
                    onChange={(e) => formik.setFieldValue("privProtocol", e.target.value)}
                  >
                    <MenuItem value="1">DES</MenuItem>
                    <MenuItem value="2">AES128</MenuItem>
                    <MenuItem value="3">AES192</MenuItem>
                    <MenuItem value="4">AES256</MenuItem>
                  </Select> */}
                  <MSelect
                     placeholder="Select protocol"
                    options={[
                      { label: "DES", value: "1" },
                      { label: "AES128", value: "2" },
                      { label: "AES192", value: "3" },
                      { label: "AES256", value: "4" },
                    ]}
                    getOptionValue={(opt) => opt.value}
                    getOptionLabel={(opt) => opt.label}
                    value={formik.values.privProtocol}
                    onChange={(selectedOption) => {
                      // Extract the string value ("1", "2", "3", or "4")
                      const val = selectedOption && typeof selectedOption === 'object'
                        ? selectedOption.value
                        : selectedOption;

                      formik.setFieldValue("privProtocol", val);
                    }}
                  />
                </FormControl>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "column" }}>
                <Typography sx={{ mb: 0.5 }}>Private Password *</Typography>
                <MInput
                  type={visibleFields.privPassword ? "text" : "password"}
                  value={formik.values.privPassword}
                  onChange={(e) => handleInputChange(e, "privPassword")}
                  errorMessage={formik.touched.privPassword && formik.errors.privPassword}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => toggleVisibility("privPassword")} edge="end">
                          {visibleFields.privPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
            </>
          )}
        </>
      )}

      {/* Footer Action */}
      <Box
        sx={{
          gridColumn: isVersion3 ? "1 / span 2" : "1",
          display: "flex",
          justifyContent: "flex-end",
          mt: 2,
        }}
      >
        <MButtonPrimary
          disabled={isSaveDisabled}
          onClick={() => setShowConfirm(true)}
        >
          {loading ? <CircularProgress size={20} color="inherit" /> : "Update"}
        </MButtonPrimary>
      </Box>

      <MDialog
        isInsideDrawer={true}
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to edit SNMP Profile?"
        onConfirm={() => { setShowConfirm(false); formik.handleSubmit(); }}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default SiteConfigEditProfile;
