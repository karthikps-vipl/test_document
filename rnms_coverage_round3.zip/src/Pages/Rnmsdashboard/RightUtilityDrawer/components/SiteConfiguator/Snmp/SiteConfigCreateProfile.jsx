/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Snmp
   File Name                : SiteConfigCreateProfile.jsx
   Author                   : Ankitha - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\Snmp\SiteConfigCreateProfile.jsx
   Purpose                  : Provides form for adding new SNMP Profile.
   Created Date             : 08-04-2026
***********************************************************************************************/
import React, { useState } from "react";
import { useFormik } from "formik";
import {
  Box,
  Typography,
  CircularProgress,
  FormControl,
  MenuItem,
  Select,
  InputAdornment,
  IconButton,
} from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import { SAVE_SNMP_PROFILE_DETAILS } from "@/RestAPI/url/endpoint";
import { validateInput, profileRegex } from "@/utility/FormValidation/Regex";
import { snmpValidationSchema } from "@/utility/FormValidation/YupSchema";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import MSelect from "@/components/Reusable/Select/MSelect";
const SiteConfigCreateProfile = ({ onSuccess, onClose ,isGrandchildFullScreen}) => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [visibleFields, setVisibleFields] = useState({});
  const toggleVisibility = (fieldName) => {
    setVisibleFields((prev) => ({
      ...prev, // This is crucial! It keeps the other fields as they were
      [fieldName]: !prev[fieldName],
    }));
  };
  const formik = useFormik({
    initialValues: {
      snmpProfileName: "",
      port: "161",
      retries: "1",
      timeout: "1",
      version: "",
      readCommunity: "",
      writeCommunity: "",
      username: "",
      contextName: "",
      securityLevel: "",
      authProtocol: "",
      authPassword: "",
      privProtocol: "",
      privPassword: "",
    },
    validationSchema: snmpValidationSchema,

    onSubmit: async (values) => {
      setLoading(true);
      try {
        // 1. Prepare the base payload with everything as Strings to match your requirement
        let payload = {
          snmpProfileName: String(values.snmpProfileName),
          port: String(values.port),
          retries: String(values.retries),
          timeout: String(values.timeout),
          version: String(values.version),
        };

        // 2. Logic for SNMP Version 3
        if (Number(values.version) === 3) {
          payload = {
            ...payload,
            username: String(values.username),
            contextName: String(values.contextName),
            securityLevel: String(values.securityLevel),
          };

          // If security level is NOT "1" (NoAuthNoPriv), add Auth fields
          if (values.securityLevel !== "1") {
            payload.authProtocol = String(values.authProtocol);
            payload.authPassword = String(values.authPassword);
          }

          // If security level is "3" (AuthPriv), add Priv fields
          if (values.securityLevel === "3") {
            payload.privProtocol = String(values.privProtocol);
            payload.privPassword = String(values.privPassword);
          }
        }
        // 3. Logic for SNMP Version 1 or 2
        else {
          payload = {
            ...payload,
            readCommunity: String(values.readCommunity),
            writeCommunity: String(values.writeCommunity),
          };
        }

        console.log("Final Payload:", payload); // Check your console to verify format

        const resp = await TopologyAxios(
          SAVE_SNMP_PROFILE_DETAILS,
          "post",
          payload
        );

        if (resp.status === 200) {
          Toast("Success!", "Successfully saved SNMP Profile", "success");
          onSuccess();
          onClose();
        }
      } catch (err) {
        Toast(
          "Error!",
          "An error occurred",
          "error"
        );
      } finally {
        setLoading(false);
      }
    },
  });
  const handleConfirmCreate = () => {
    setShowConfirm(false);
    formik.handleSubmit(); // This triggers the onSubmit above
  };
  const handleInputChange = (event, fieldName) => {
    formik.setFieldValue(fieldName, event.target.value);
    setTimeout(() => {
      formik.handleBlur({ target: { name: fieldName } });
    }, 0);
  };

  const isVersionSelected = formik.values.version !== "";
const isVersion3 = Number(formik.values.version) === 3;
  const isSaveDisabled = !formik.isValid || !formik.dirty || loading;
  return (
    <Box
      component="form"
      onSubmit={formik.handleSubmit}
      sx={{
        display: "grid",
        gridTemplateColumns: isVersion3 ? "1fr 1fr" : "1fr",
        p: 1,
        gap: 1
      }}
    >
      {/* Profile Name */}
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
        <Typography sx={{ mb: 0.5 }}>Profile Name *</Typography>
        <MInput
          value={formik.values.snmpProfileName}
          onChange={(e) => handleInputChange(e, "snmpProfileName")}
          onBlur={() => formik.setFieldTouched("snmpProfileName", true)}
          errorMessage={formik.touched.snmpProfileName && formik.errors.snmpProfileName}
        />
      </Box>

      {/* Port */}
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
        <Typography sx={{ mb: 0.5 }}>Port *</Typography>
        <MInput
          value={formik.values.port}
          onChange={(e) => {
            if (validateInput(e.target.value, profileRegex.numeric) !== undefined) {
              handleInputChange(e, "port");
            }
          }}
          errorMessage={formik.touched.port && formik.errors.port}
        />
      </Box>

      {/* Retries */}
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>No of Retries *</Typography>
        <MInput
          value={formik.values.retries}
          onChange={(e) => {
            if (validateInput(e.target.value, profileRegex.numeric) !== undefined) {
              handleInputChange(e, "retries");
            }
          }}
          errorMessage={formik.touched.retries && formik.errors.retries}
        />
      </Box>

      {/* Timeout */}
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Timeout (Sec) *</Typography>
        <MInput
          value={formik.values.timeout}
          onChange={(e) => {
            if (validateInput(e.target.value, profileRegex.numeric) !== undefined) {
              handleInputChange(e, "timeout");
            }
          }}
          errorMessage={formik.touched.timeout && formik.errors.timeout}
        />
      </Box>

      {/* Version Dropdown */}
      <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Version *</Typography>
        <FormControl fullWidth>
          <MSelect
            placeholder="Select version"
            options={[
              { label: "1", value: 0 },
              { label: "2c", value: 1 },
              { label: "3", value: 3 },
            ]}
            getOptionValue={(opt) => opt.value}
            getOptionLabel={(opt) => opt.label}
            value={formik.values.version}
            onChange={(selectedOption) => {
              const val = selectedOption && typeof selectedOption === 'object'
                ? selectedOption.value
                : selectedOption;
              formik.setFieldValue("version", val);
              setTimeout(() => formik.validateForm(), 0);
            }}
            style={{ borderRadius: "10px" }}
          />
        </FormControl>
      </Box>

      {/* Conditional Logic UI */}
      {isVersionSelected && !isVersion3 ? (

        <>
          <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
            <Typography sx={{ mb: 0.5, mt: 2 }}>Read Community *</Typography>
            <MInput
              type={visibleFields.readCommunity ? "text" : "password"}
              value={formik.values.readCommunity}
              onChange={(e) => handleInputChange(e, "readCommunity")}
              errorMessage={formik.touched.readCommunity && formik.errors.readCommunity}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => toggleVisibility("readCommunity")} edge="end">
                      {visibleFields.readCommunity ? <VisibilityIcon /> : <VisibilityOffIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
            <Typography sx={{ mb: 0.5 }}>Write Community *</Typography>
            <MInput
              type={visibleFields.writeCommunity ? "text" : "password"}
              value={formik.values.writeCommunity}
              onChange={(e) => handleInputChange(e, "writeCommunity")}
              errorMessage={formik.touched.writeCommunity && formik.errors.writeCommunity}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => toggleVisibility("writeCommunity")} edge="end">
                      {visibleFields.writeCommunity ? <VisibilityIcon /> : <VisibilityOffIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>
        </>
   ) : isVersion3 ? (
        <>
          {/* V3: Core Fields - Shown immediately when version 3 is selected */}
          <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
            <Typography sx={{ mb: 0.5 }}>USM User *</Typography>
            <MInput
              value={formik.values.username}
              onChange={(e) => handleInputChange(e, "username")}
              errorMessage={formik.touched.username && formik.errors.username}
            />
          </Box>

          <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
            <Typography sx={{ mb: 0.5 }}>Context Name</Typography>
            <MInput
              value={formik.values.contextName}
              onChange={(e) => handleInputChange(e, "contextName")}
              errorMessage={formik.touched.contextName && formik.errors.contextName}
            />
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
            <Typography sx={{ mb: 0.5 }}>Security Level *</Typography>
            <FormControl fullWidth>
              <MSelect
                placeholder="Select security level"
                options={[
                  { label: "No Auth / No Privacy", value: "1" },
                  { label: "Auth / No Privacy", value: "2" },
                  { label: "Auth / Privacy", value: "3" },
                ]}
                getOptionValue={(opt) => opt.value}
                getOptionLabel={(opt) => opt.label}
                value={formik.values.securityLevel}
                onChange={(selectedOption) => {
                  const val = selectedOption && typeof selectedOption === 'object'
                    ? selectedOption.value
                    : selectedOption;
                  formik.setFieldValue("securityLevel", val);
                }}
              />
            </FormControl>
          </Box>

          

          {/* V3: Auth Fields - ONLY show if a level is selected AND it is not "1" */}
          {formik.values.securityLevel !== "" && formik.values.securityLevel !== "1" && (
            <>
              <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
                <Typography sx={{ mb: 0.5 }}>Auth Protocol *</Typography>
                <FormControl fullWidth>
                  <Select
                    sx={{ borderRadius: "10px" }}
                    size="small"
                    value={formik.values.authProtocol}
                    onChange={(e) => formik.setFieldValue("authProtocol", e.target.value)}
                  >
                    <MenuItem value="1">MD5</MenuItem>
                    <MenuItem value="2">SHA</MenuItem>
                    <MenuItem value="3">SHA224</MenuItem>
                    <MenuItem value="4">SHA256</MenuItem>
                    <MenuItem value="5">SHA384</MenuItem>
                    <MenuItem value="6">SHA512</MenuItem>
                  </Select>
                </FormControl>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
                <Typography sx={{ mb: 0.5 }}>Auth Password *</Typography>
                <MInput
                  type={visibleFields.authPassword ? "text" : "password"}
                  value={formik.values.authPassword}
                  onChange={(e) => handleInputChange(e, "authPassword")}
                  errorMessage={formik.touched.authPassword && formik.errors.authPassword}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => toggleVisibility("authPassword")} edge="end">
                          {visibleFields.authPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
            </>
          )}

          {/* V3: Privacy Fields - ONLY show if security level is exactly "3" */}
          {formik.values.securityLevel === "3" && (
            <>
              <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
                <Typography sx={{ mb: 0.5 }}>Priv Protocol *</Typography>
                <FormControl fullWidth>
                  <Select
                    sx={{ borderRadius: '10px' }}
                    size="small"
                    value={formik.values.privProtocol}
                    onChange={(e) => formik.setFieldValue("privProtocol", e.target.value)}
                  >
                    <MenuItem value="1">DES</MenuItem>
                    <MenuItem value="2">AES128</MenuItem>
                    <MenuItem value="3">AES192</MenuItem>
                    <MenuItem value="4">AES256</MenuItem>
                  </Select>
                </FormControl>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
                <Typography sx={{ mb: 0.5 }}>Private Password *</Typography>
                <MInput
                  type={visibleFields.privPassword ? "text" : "password"}
                  value={formik.values.privPassword}
                  onChange={(e) => handleInputChange(e, "privPassword")}
                  errorMessage={formik.touched.privPassword && formik.errors.privPassword}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => toggleVisibility("privPassword")} edge="end">
                          {visibleFields.privPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
            </>
          )}
        </>
     ) : null}

      {/* Footer Button */}
      <Box
        sx={{
          gridColumn: isVersion3 ? "1 / span 2" : "1",
          display: "flex",
          justifyContent: "flex-end",
          mt: 2,
        }}
      >
        <MButtonPrimary
          onClick={() => setShowConfirm(true)}
          disabled={isSaveDisabled}
        >
          {loading ? <CircularProgress size={20} color="inherit" /> : "Save"}
        </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to create SNMP Profile?"
        onConfirm={handleConfirmCreate}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
  // return (
  //   <Box
  //     component="form"
  //     onSubmit={formik.handleSubmit}
  //     sx={{
  //       display: "grid",
  //       gridTemplateColumns: isVersion3 ? "1fr 1fr" : "1fr",

  //       p: 1,
  //       gap: 1

  //     }}
  //   >
  //     {/* Profile Name */}
  //     <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
  //       <Typography sx={{ mb: 0.5 }}>Profile Name *</Typography>
  //       {/* <MInput
  //         value={formik.values.snmpProfileName}
  //         onChange={(e) => {
  //           if (
  //             validateInput(e.target.value, profileRegex.name) !== undefined
  //           ) {
  //             handleInputChange(e, "snmpProfileName");
  //           }
  //         }}
  //         errorMessage={
  //           formik.touched.snmpProfileName && formik.errors.snmpProfileName
  //         }
  //       /> */}
  //       <MInput
  //         value={formik.values.snmpProfileName}
  //         // Always allow the update, even if it's "wrong" temporarily
  //         onChange={(e) => handleInputChange(e, "snmpProfileName")}
  //         // Show the error only after they leave the field or try to submit
  //         onBlur={() => formik.setFieldTouched("snmpProfileName", true)}
  //         errorMessage={formik.touched.snmpProfileName && formik.errors.snmpProfileName}
  //       />
  //     </Box>

  //     {/* Port */}
  //     <Box
  //       sx={{ display: "flex", flexDirection: "column", width: "100%", }}
  //     >
  //       <Typography sx={{ mb: 0.5 }}>Port *</Typography>
  //       <MInput
  //         value={formik.values.port}
  //         onChange={(e) => {
  //           if (
  //             validateInput(e.target.value, profileRegex.numeric) !== undefined
  //           ) {
  //             handleInputChange(e, "port");
  //           }
  //         }}
  //         errorMessage={formik.touched.port && formik.errors.port}
  //       />
  //     </Box>

  //     {/* Retries */}
  //     <Box
  //       sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}
  //     >
  //       <Typography sx={{ mb: 0.5 }}>No of Retries *</Typography>
  //       <MInput
  //         value={formik.values.retries}
  //         onChange={(e) => {
  //           if (
  //             validateInput(e.target.value, profileRegex.numeric) !== undefined
  //           ) {
  //             handleInputChange(e, "retries");
  //           }
  //         }}
  //         errorMessage={formik.touched.retries && formik.errors.retries}
  //       />
  //     </Box>

  //     {/* Timeout */}
  //     <Box
  //       sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}
  //     >
  //       <Typography sx={{ mb: 0.5 }}>Timeout (Sec) *</Typography>
  //       <MInput
  //         value={formik.values.timeout}
  //         onChange={(e) => {
  //           if (
  //             validateInput(e.target.value, profileRegex.numeric) !== undefined
  //           ) {
  //             handleInputChange(e, "timeout");
  //           }
  //         }}
  //         errorMessage={formik.touched.timeout && formik.errors.timeout}
  //       />
  //     </Box>

  //     {/* Version Dropdown */}
  //     <Box
  //       sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}
  //     >
  //       <Typography sx={{ mb: 0.5 }}>Version *</Typography>
  //       <FormControl fullWidth>
  //         <MSelect
          
  //           placeholder="Select version"
  //           options={[
  //             { label: "1", value: 0 },
  //             { label: "2c", value: 1 },
  //             { label: "3", value: 3 },
  //           ]}
  //           getOptionValue={(opt) => opt.value}
  //           getOptionLabel={(opt) => opt.label}
  //           value={formik.values.version}
  //           onChange={(selectedOption) => {
  //             // 1. Extract the number value from the object returned by MSelect
  //             const val = selectedOption && typeof selectedOption === 'object'
  //               ? selectedOption.value
  //               : selectedOption;

  //             // 2. Update Formik
  //             formik.setFieldValue("version", val);

  //             // 3. Replicate your manual validation trigger
  //             setTimeout(() => formik.validateForm(), 0);
  //           }}
  //           // If you want to pass the specific border radius from your original snippet
  //           style={{ borderRadius: "10px" }}
  //         />
  //         {/* <Select
  //           sx={{ borderRadius: "10px" }}
  //           size="small"
  //           value={formik.values.version}
  //           onChange={(e) => {
  //             formik.setFieldValue("version", e.target.value);
  //             setTimeout(() => formik.validateForm(), 0);
  //           }}
  //         >
  //           <MenuItem value={0}>1</MenuItem>
  //           <MenuItem value={1}>2c</MenuItem>
  //           <MenuItem value={3}>3</MenuItem>
  //         </Select> */}
  //       </FormControl>
  //     </Box>

  //     {/* Conditional Logic UI */}
  //     {!isVersion3 ? (
  //       <>
  //         <Box
  //           sx={{
  //             display: "flex",
  //             flexDirection: "column",
  //             width: "100%",

  //           }}
  //         >
  //           <Typography sx={{ mb: 0.5, mt: 2 }}>Read Community *</Typography>
  //           <MInput
  //             // 1. FIX: Use the state variable here instead of hardcoded "password"
  //             type={visibleFields.readCommunity ? "text" : "password"}
  //             value={formik.values.readCommunity}
  //             onChange={(e) => {
  //               const validatedValue = validateInput(
  //                 e.target.value,
  //                 profileRegex.community
  //               );
  //               console.log(validatedValue);
  //               handleInputChange(e, "readCommunity");

  //             }}
  //             errorMessage={
  //               formik.touched.readCommunity && formik.errors.readCommunity
  //             }
  //             InputProps={{
  //               endAdornment: (
  //                 <InputAdornment position="end">
  //                   <IconButton
  //                     onClick={() => toggleVisibility("readCommunity")}
  //                     edge="end"
  //                   >
  //                     {visibleFields.readCommunity ? (
  //                       <VisibilityIcon />
  //                     ) : (
  //                       <VisibilityOffIcon />
  //                     )}
  //                   </IconButton>
  //                 </InputAdornment>
  //               ),
  //             }}
  //           />
  //         </Box>

  //         <Box
  //           sx={{
  //             display: "flex",
  //             flexDirection: "column",
  //             width: "100%",
  //             mt: 2,
  //           }}
  //         >
  //           <Typography sx={{ mb: 0.5 }}>Write Community *</Typography>
  //           <MInput
  //             type={visibleFields.writeCommunity ? "text" : "password"}
  //             value={formik.values.writeCommunity}
  //             onChange={(e) => {
  //               if (
  //                 validateInput(e.target.value, profileRegex.community) !==
  //                 undefined
  //               ) {
  //                 handleInputChange(e, "writeCommunity");
  //               }
  //             }}
  //             errorMessage={
  //               formik.touched.writeCommunity && formik.errors.writeCommunity
  //             }
  //             InputProps={{
  //               endAdornment: (
  //                 <InputAdornment position="end">
  //                   <IconButton
  //                     onClick={() => toggleVisibility("writeCommunity")}
  //                     edge="end"
  //                   >
  //                     {visibleFields.writeCommunity ? (
  //                       <VisibilityIcon />
  //                     ) : (
  //                       <VisibilityOffIcon />
  //                     )}
  //                   </IconButton>
  //                 </InputAdornment>
  //               ),
  //             }}
  //           />
  //         </Box>
  //       </>
  //     ) : (
  //       <>
        
  //         <Box
  //           sx={{
  //             display: "flex",
  //             flexDirection: "column",
  //             width: "100%",
  //             mt: 2,
  //           }}
  //         >
  //           <Typography sx={{ mb: 0.5 }}>Security Level *</Typography>
  //           <FormControl fullWidth>
  //             <MSelect
             
  //               placeholder="Select security level"
  //               options={[
  //                 { label: "No Auth / No Privacy", value: "1" },
  //                 { label: "Auth / No Privacy", value: "2" },
  //                 { label: "Auth / Privacy", value: "3" },
  //               ]}
  //               getOptionValue={(opt) => opt.value}
  //               getOptionLabel={(opt) => opt.label}
  //               value={formik.values.securityLevel}
  //               onChange={(selectedOption) => {
  //                 // Extract the string value ("1", "2", or "3") from the selected object
  //                 const val = selectedOption && typeof selectedOption === 'object'
  //                   ? selectedOption.value
  //                   : selectedOption;

  //                 formik.setFieldValue("securityLevel", val);
  //               }}
  //               // Applying your specific styling
              
  //             />
  //             {/* <Select
  //               sx={{ borderRadius: "10px", fontSize: "12.5px" }}
  //               size="small"
  //               value={formik.values.securityLevel}
  //               onChange={(e) =>
  //                 formik.setFieldValue("securityLevel", e.target.value)
  //               }
  //             >
  //               <MenuItem value="1">No Auth / No Privacy</MenuItem>
  //               <MenuItem value="2">Auth / No Privacy</MenuItem>
  //               <MenuItem value="3">Auth / Privacy</MenuItem>
  //             </Select> */}
  //           </FormControl>
  //         </Box>
       
  //         <Box
  //           sx={{
  //             display: "flex",
  //             flexDirection: "column",
  //             width: "100%",
  //             mt: 2
  //           }}
  //         >
  //           <Typography sx={{ mb: 0.5 }}>Context Name</Typography>
  //           <MInput
  //             value={formik.values.contextName}
  //             onChange={(e) => {
  //               if (
  //                 validateInput(e.target.value, profileRegex.name) !== undefined
  //               ) {
  //                 handleInputChange(e, "contextName");
  //               }
  //             }}
  //             errorMessage={
  //               formik.touched.contextName && formik.errors.contextName
  //             }
  //           />
  //         </Box>
  //       </>
  //     )}

  //     {/* V3 Extra Fields */}
  //     {isVersion3 && formik.values.securityLevel !== "1" && (
  //       <>
  //         <Box
  //           sx={{
  //             display: "flex",
  //             flexDirection: "column",
  //             width: "100%",
  //             mt: 2

  //           }}
  //         >
  //           <Typography sx={{ mb: 0.5 }}>Auth Protocol *</Typography>
  //           <FormControl fullWidth>
  //             <Select
  //               sx={{ borderRadius: "10px" }}
  //               size="small"
  //               value={formik.values.authProtocol}
  //               onChange={(e) =>
  //                 formik.setFieldValue("authProtocol", e.target.value)
  //               }
  //             >
  //               <MenuItem value="1">MD5</MenuItem>
  //               <MenuItem value="2">SHA</MenuItem>
  //             </Select>
  //           </FormControl>
  //         </Box>
  //         <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
  //           <Typography sx={{ mb: 0.5 }}>Auth Password *</Typography>
  //           <MInput
  //             // UPDATED: Use the specific key from visibleFields object
  //             type={visibleFields.authPassword ? "text" : "password"}
  //             value={formik.values.authPassword}
  //             onChange={(e) => {
  //               if (validateInput(e.target.value, profileRegex.password) !== undefined) {
  //                 handleInputChange(e, "authPassword");
  //               }
  //             }}
  //             errorMessage={formik.touched.authPassword && formik.errors.authPassword}
  //             InputProps={{
  //               endAdornment: (
  //                 <InputAdornment position="end">
  //                   <IconButton
  //                     // UPDATED: Pass the specific field name
  //                     onClick={() => toggleVisibility("authPassword")}
  //                     edge="end"
  //                   >
  //                     {visibleFields.authPassword ? (
  //                       <VisibilityIcon />
  //                     ) : (
  //                       <VisibilityOffIcon />
  //                     )}
  //                   </IconButton>
  //                 </InputAdornment>
  //               ),
  //             }}
  //           />
  //         </Box>
  //       </>
  //     )}

  //     {isVersion3 && formik.values.securityLevel === "3" && (
  //       <>
  //         <Box
  //           sx={{
  //             display: "flex",
  //             flexDirection: "column",
  //             width: "100%",
  //             mt: 2

  //           }}
  //         >
  //           <Typography sx={{ mb: 0.5 }}>Priv Protocol *</Typography>
  //           <FormControl fullWidth>
  //             <Select
  //               sx={{ borderRadius: '10px' }}
  //               size="small"
  //               value={formik.values.privProtocol}
  //               onChange={(e) =>
  //                 formik.setFieldValue("privProtocol", e.target.value)
  //               }
  //             >
  //               <MenuItem value="1">DES</MenuItem>
  //               <MenuItem value="2">AES128</MenuItem>
  //               <MenuItem value="3">AES192</MenuItem>
  //               <MenuItem value="4">AES256</MenuItem>
  //             </Select>
  //           </FormControl>
  //         </Box>
  //         <Box sx={{ display: "flex", flexDirection: "column", width: "100%", mt: 2 }}>
  //           <Typography sx={{ mb: 0.5 }}>Private Password *</Typography>
  //           <MInput
  //             // UPDATED: Use the specific key from visibleFields object
  //             type={visibleFields.privPassword ? "text" : "password"}
  //             value={formik.values.privPassword}
  //             onChange={(e) => {
  //               if (validateInput(e.target.value, profileRegex.password) !== undefined) {
  //                 handleInputChange(e, "privPassword");
  //               }
  //             }}
  //             errorMessage={formik.touched.privPassword && formik.errors.privPassword}
  //             InputProps={{
  //               endAdornment: (
  //                 <InputAdornment position="end">
  //                   <IconButton
  //                     // UPDATED: Pass the specific field name
  //                     onClick={() => toggleVisibility("privPassword")}
  //                     edge="end"
  //                   >
  //                     {visibleFields.privPassword ? (
  //                       <VisibilityIcon />
  //                     ) : (
  //                       <VisibilityOffIcon />
  //                     )}
  //                   </IconButton>
  //                 </InputAdornment>
  //               ),
  //             }}
  //           />
  //         </Box>
  //       </>
  //     )}

  //     {/* Footer Button */}
  //     <Box
  //       sx={{
  //         gridColumn: isVersion3 ? "1 / span 2" : "1",
  //         display: "flex",
  //         justifyContent: "flex-end",
  //         mt: 2,
  //       }}
  //     >
  //       <MButtonPrimary
  //         onClick={() => setShowConfirm(true)} // Open dialog instead of submitting
  //         disabled={isSaveDisabled}
  //       >
  //         {loading ? <CircularProgress size={20} color="inherit" /> : "Save"}
  //       </MButtonPrimary>
  //     </Box>
  //     <MDialog
  //       open={showConfirm}
  //       variant="info"
  //       icon={confirmation_icon}
  //       title="Confirm Action"
  //       message="Are you sure you want to create SNMP Profile?"
  //       onConfirm={handleConfirmCreate}
  //       onClose={() => setShowConfirm(false)}
  //       mode="grandchild"
  //     />
  //   </Box>
  // );
};

export default SiteConfigCreateProfile;
