/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Snmp
   File Name                : SiteConfigSnmp.jsx
   Author                   : Ankitha - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\Snmp\SiteConfigSnmp.jsx
   Purpose                  : Manages the main interface for SNMP Configuration.
   Created Date             : 07-04-2026
***********************************************************************************************/

import MDialog from "@/components/Reusable/Dialog/MDialog";
import MTable from "@/components/Reusable/Table/MTable";
import { Box, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import {
  DELETE_SNMP_PROFILE_DETAILS,
  FETCH_SNMP_PROFILE_DETAILS,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";
import { AUTH_PROTOCOL_MAP, PRIV_PROTOCOL_MAP, SECURITY_LEVEL_MAP } from "@/lib/utils";

const SiteConfigSnmp = ({
  privilegeKey,
  handleAdd,
  refreshTrigger,
  handleView,
  handleEdit,
}) => {
  const [loading, setLoading] = useState(false);
  const [repTableData, setRepTableData] = useState([]);
  const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });
  const SNMP_VERSION_MAP = {
    0: "1",
    1: "2c",
    3: "3",
  };
  const columns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Profile Name", uid: "snmpProfileName", width: "140px" },
    { name: "Port", uid: "port", width: "60px" },
    { name: "No of Retries", uid: "retries", width: "120px" },
    { name: "Timeout (sec)", uid: "timeout", width: "120px" },
    {
      name: "Version",
      uid: "version",
      width: "80px",
    },
    { name: "Actions", uid: "actions" },
  ];
  const exportColumns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Profile Name", uid: "snmpProfileName", width: "140px" },
    { name: "Profile ID", uid: "snmpProfileId" },
    { name: "Port", uid: "port", width: "60px" },
    { name: "No of Retries", uid: "retries", width: "120px" },
    { name: "Timeout (sec)", uid: "timeout", width: "120px" },
    { name: "Version", uid: "version", width: "80px" },
    { name: "Username", uid: "username" },
    { name: "Security Level", uid: "securityLevel" },
    { name: "Context Name", uid: "contextName" },
    { name: "Auth Password", uid: "authPassword" },
    { name: "Auth Protocol", uid: "authProtocol" },
    { name: "Priv Password", uid: "privPassword" },
    { name: "Priv Protocol", uid: "privProtocol" },
    { name: "Read Community", uid: "readCommunity" },
    { name: "Write Community", uid: "writeCommunity" },
    { name: "IP Address", uid: "ipAddress" },
  ];
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await TopologyAxios(FETCH_SNMP_PROFILE_DETAILS, "get");
        const data = response?.data || [];
        const processedData = data.map((item, index) => ({
          ...item,
          sno: index + 1,
          version: SNMP_VERSION_MAP[item.version] || item.version,
        }));
        setRepTableData(processedData);
      } catch (error) {
        console.error("Error fetching Snmp Details:", error);
        Toast("Error!", "Failed to fetch Snmp Details", "error");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [refreshTrigger]);

  const handleDeleteRow = async (row) => {
    setLoading(true); // Using your existing loading state
    try {
      const response = await TopologyAxios(
        `${DELETE_SNMP_PROFILE_DETAILS}/${row.snmpProfileId}`,
        "post",
        ""
      );

      if (response?.data) {
        setRepTableData((prevData) =>
          prevData.filter((item) => item.snmpProfileId !== row.snmpProfileId)
        );
        Toast("Success!", "SNMP Profile  deleted Successfully.", "success");
      } else {
        Toast(
          "Error!",
          "Profile is assigned to a device and cannot be removed.",
          "error"
        );
      }
    } catch (error) {
      console.error("Network or Server error:", error);
      // const errorMessage =
      //   error?.response?.data?.message || "Failed to delete user.";
      Toast("Error!", "Failed to delete user.", "error");
    } finally {
      setLoading(false);
    }
  };
  const getExportData = (data) => {
    return data.map((item) => ({
      ...item,
      username: item.username || "-",
      securityLevel: SECURITY_LEVEL_MAP[item.securityLevel] || item.securityLevel || "-",
      contextName: item.contextName || "-",
      authPassword: item.authPassword || "-",
      authProtocol: AUTH_PROTOCOL_MAP[item.authProtocol] || item.authProtocol || "-",
      privPassword: item.privPassword || "-",
      privProtocol: PRIV_PROTOCOL_MAP[item.privProtocol] || item.privProtocol || "-",
      readCommunity: item.readCommunity || "-",
      writeCommunity: item.writeCommunity || "-",
      ipAddress: item.ipAddress || "-",
    }));
  };
  console.log("repTableDataSnmpcheck", repTableData);
  return (
    <Box  >
      {loading ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          //tableTitle="SNMP"
          columns={columns}
          tableData={repTableData}
          showPagination={true}
          hideAdd={false}
          handleDownloadPDF={() =>
            exportToPDF(
              "SNMP Report",
              exportColumns,
              getExportData(repTableData),
              "SNMP_Report"
            )
          }
          handleDownloadCSV={() =>
            exportToCSV(
              "SNMP_Export",
              exportColumns,
              getExportData(repTableData)
            )
          }
          showSearch={true}
          AddText="Create"
          handleAdd={(row) =>
            handleAdd({ ...row, mode: "CREATE", title: "Add SNMP Profile" })
          }
          handleEdit={(row) =>
            handleEdit({
              ...row,
              mode: "EDIT",
              title: `Edit Profile: ${row.snmpProfileName} `,
            })
          }
          handleDelete={(row) => {
            setRowToDelete({ visible: true, row: row });
          }}
          handleView={(row) =>
            handleView({
              ...row,
              // password: row.originalPassword,
              mode: "VIEW",
              title: `View Profile: ${row.snmpProfileName} `,
            })
          }
        />
      )}

      {rowToDelete.visible && (
        <MDialog
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          icon={Delete_Icon_}
          mode="child"
          message="Are you sure you want to delete snmp details?"
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null });
          }}
          onClose={() => setRowToDelete({ visible: false, row: null })}
        />
      )}
    </Box>
  );
};

export default SiteConfigSnmp;
