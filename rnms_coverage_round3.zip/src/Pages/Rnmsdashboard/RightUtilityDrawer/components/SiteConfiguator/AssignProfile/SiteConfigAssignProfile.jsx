/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Assign Profile
   File Name                : SiteConfigAssignProfile.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\AssignProfile\SiteConfigAssignProfile.jsx
   Purpose                  : Manages the assignment of profiles to specific sites.
   Created Date             : 22-04-2026
***********************************************************************************************/

import MDialog from "@/components/Reusable/Dialog/MDialog";
import MTable from "@/components/Reusable/Table/MTable";
import { Box, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import { InventoryAxios, TopologyAxios } from "@/RestAPI/api/axiosApicall";
import {
  ASSIGN_PROFILE_TO_RESOURCES,
  FETCH_RESOURCE_INFO_BY_SNMP_AND_SNMP_COMMUNICATION_TYPE,
  FETCH_SNMP_PROFILE_DETAILS,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";
import MMultiSelect from "@/components/Reusable/Select/MMultiSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MSelect from "@/components/Reusable/Select/MSelect";
import { AUTH_PROTOCOL_MAP, PRIV_PROTOCOL_MAP, SECURITY_LEVEL_MAP } from "@/lib/utils";

const SiteConfigAssignProfile = ({
  refreshTrigger,
  privilegeKey,
  onRefresh,
  isChildFullScreen
}) => {
  const [loading, setLoading] = useState(false);
  const [repTableData, setRepTableData] = useState([]);

  const [selectedDevices, setSelectedDevices] = useState([]);
  const [selectedProfiles, setSelectedProfiles] = useState([]);

  const [showConfirm, setShowConfirm] = useState(false);
  const [deviceOptions, setDeviceOptions] = useState([]);
  const [profileOptions, setProfileOptions] = useState([]);

  const columns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Device Name", uid: "resourceName" },
    { name: "IP Address", uid: "ipAddress", width: "140px" },
    { name: "SNMP Profile", uid: "snmpProfileName" },
  ];
  const exportColumns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Device Name", uid: "resourceName" },
    { name: "IP Address", uid: "ipAddress", width: "130px" },
    { name: "SNMP Profile", uid: "snmpProfileName" },
    { name: "SNMP Profile Id", uid: "snmpProfileId" },
    { name: "Username", uid: "username" },
    { name: "Version", uid: "version" },
    { name: "Port", uid: "port" },
    { name: "Security Level", uid: "securityLevel" },
    { name: "Context Name", uid: "contextName" },
    { name: "Retries", uid: "retries" },
    { name: "Timeout", uid: "timeout" },
    { name: "Auth Password", uid: "authPassword" },
    { name: "Auth Protocol", uid: "authProtocol" },
    { name: "Priv Password", uid: "privPassword" },
    { name: "Priv Protocol", uid: "privProtocol" },
    { name: "Read Community", uid: "readCommunity" },
    { name: "Write Community", uid: "writeCommunity" },
  ];
  const isSubmitDisabled =
    !selectedDevices ||
    selectedDevices.length === 0 ||
    !selectedProfiles ||
    selectedProfiles.length === 0;
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await InventoryAxios(
          FETCH_RESOURCE_INFO_BY_SNMP_AND_SNMP_COMMUNICATION_TYPE,
          "get"
        );
        const data = response?.data || [];

        const processedData = data.map((r, index) => ({
          ...r,
          sno: index + 1,
          ipAddress: r.resourceIp || "NA",
          snmpProfileName: r.tmSnmpProfile?.snmpProfileName || "NA",
          // Ensure resourceId is explicitly part of the processed object
          resourceId: r.resourceId,
          profileId: r.tmSnmpProfile?.snmpProfileId,
        }));

        setRepTableData(processedData);

        const deviceOptions = processedData.map((item) => ({
          label: item.resourceName, // What the user sees in the dropdown
          value: item.resourceId, // <--- CHANGE THIS from resourceName to resourceId
        }));
        setDeviceOptions(deviceOptions);
      } catch (error) {
        console.error("Error fetching Snmp Details:", error);
        Toast("Error!", "Failed to fetch Snmp Details", "error");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [refreshTrigger]);
  useEffect(() => {
    const fetchAllProfiles = async () => {
      try {
        const profileRes = await TopologyAxios(
          FETCH_SNMP_PROFILE_DETAILS,
          "get"
        );
        const allProfiles = profileRes?.data || [];

        const formattedProfiles = allProfiles.map((p) => ({
          label: p.snmpProfileName,
          value: p.snmpProfileId,
        }));

        setProfileOptions(formattedProfiles);
      } catch (error) {
        console.error("Error fetching Profile Master List:", error);
      }
    };
    fetchAllProfiles();
  }, []);

  const handleOpenDialog = () => {
    if (selectedDevices.length === 0 || selectedProfiles.length === 0) {
      Toast("Warning", "Please select both Device and Profile", "warning");
      return;
    }
    setShowConfirm(true);
  };
  const handleConfirmUpdate = async () => {
    const devicesArray = Array.isArray(selectedDevices)
      ? selectedDevices
      : [selectedDevices];
    const profilesArray = Array.isArray(selectedProfiles)
      ? selectedProfiles
      : [selectedProfiles];

    const validDevices = devicesArray.filter(
      (item) => item !== null && item !== undefined
    );
    const validProfiles = profilesArray.filter(
      (item) => item !== null && item !== undefined
    );

    const payload = {
      // Map the devices to get the ID
      resources: validDevices.map((item) => {
        if (typeof item === "object" && item !== null) {
          // If the select component returns the option object {label, value}
          // We want the 'value' which we set to resourceId in useEffect
          return item.value || item.resourceId;
        }
        // If the select component returns just the string/ID directly
        return item;
      }),

      // Get the Profile ID
      snmpProfile:
        typeof validProfiles[0] === "object"
          ? validProfiles[0].value || validProfiles[0].snmpProfileId
          : validProfiles[0],
    };

    console.log("Final Payload for API:", payload);

    try {
      setLoading(true);
      const response = await InventoryAxios(
        ASSIGN_PROFILE_TO_RESOURCES,
        "post",
        payload
      );

      if (response) {
        Toast("Success!", "Configuration updated successfully", "success");
        setShowConfirm(false);
        setSelectedDevices([]);
        setSelectedProfiles([]);
        // if (refreshTrigger) refreshTrigger();
        console.log("onRefresh received:", onRefresh);
        if (typeof onRefresh === "function") {
          onRefresh();
        } else {
          console.error("onRefresh is NOT a function! Check the Drawer props.");
        }
      }
    } catch (error) {
      console.error("Update error:", error);
      // const errorMsg =
      //   error?.response?.data?.message || "Failed to update configuration";
      Toast("Error!", "Failed to update configuration", "error");
    } finally {
      setLoading(false);
      setShowConfirm(false);
    }
  };
  console.log("repTableDataConsoleCheck", repTableData);
  const getExportData = (data) => {
    return data.map((item) => {
      const profile = item.tmSnmpProfile || {};
      return {
        ...item,
        username: profile.username || "-",
        version: profile.version ?? "-",
        port: profile.port || "-",
        securityLevel: SECURITY_LEVEL_MAP[profile.securityLevel] || profile.securityLevel || "-",
        contextName: profile.contextName || "-",
        retries: profile.retries || "-",
        timeout: profile.timeout || "-",
        authPassword: profile.authPassword || "-",
        authProtocol: AUTH_PROTOCOL_MAP[profile.authProtocol] || profile.authProtocol || "-",
        privPassword: profile.privPassword || "-",
        privProtocol: PRIV_PROTOCOL_MAP[profile.privProtocol] || profile.privProtocol || "-",
        readCommunity: profile.readCommunity || "-",
        writeCommunity: profile.writeCommunity || "-",
      };
    });
  };
  return (
    <Box >
      {loading && repTableData.length === 0 ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          // tableTitle="Devices Info"
          columns={columns}
          tableData={repTableData}
          showPagination={true}
          customDropdown={
            <MMultiSelect
            isCompact={true}
              
              options={deviceOptions}
              value={selectedDevices}
              onChange={setSelectedDevices}
              placeholder="Device"
            />
          }
          customDropdown1={
            <MSelect
              options={profileOptions}
              value={selectedProfiles}
              onChange={setSelectedProfiles}
              placeholder="Profile"
              style={{ width: "130px", height: "35px",mr:1 }}
            />
          }
          customButton={
            <MButtonPrimary
              onClick={handleOpenDialog}
              disabled={isSubmitDisabled}
            >
              Submit
            </MButtonPrimary>
          }
          handleDownloadPDF={() =>
            exportToPDF(
              "Assign Profile",
              exportColumns,
              getExportData(repTableData),
              "Assign_Profile"
            )
          }
          handleDownloadCSV={() =>
            exportToCSV(
              "AssignProfile_Export",
              exportColumns,
              getExportData(repTableData)
            )
          }
          showSearch={true}
        />
      )}
      <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to update the Assign Profile configuration?"
        onConfirm={handleConfirmUpdate}
        onClose={() => setShowConfirm(false)}
        mode="child"
        isChildFullScreen={isChildFullScreen}
        isSubmitting={loading}
      />
    </Box>
  );
};
export default SiteConfigAssignProfile;
