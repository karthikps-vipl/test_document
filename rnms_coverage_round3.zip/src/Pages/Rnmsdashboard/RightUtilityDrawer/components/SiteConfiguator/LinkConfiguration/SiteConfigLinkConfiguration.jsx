/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : LinkConfiguration
   File Name                : SiteConfigLinkConfiguration.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\LinkConfiguration\SiteConfigLinkConfiguration.jsx
   Purpose                  : Facilitates the linking of specific configurations to site assets.
   Created Date             : 16-04-2026
***********************************************************************************************/
  

import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { 
  Box, 
  Typography, 
  Radio, 
  RadioGroup, 
  FormControlLabel, 
  CircularProgress 
} from "@mui/material";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog"; // Import your custom Dialog
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import { 
  FETCH_PORT_INFO_DETAILS_BY_RESOURCE_ID, 
  UPDATE_LINK_CONFIGURATION_DETAILS, 
  FETCH_EXISTING_LINK_CONFIGURATION_DETAILS 
} from "@/RestAPI/url/endpoint";
import { setLinks, setLinksLoading } from "@/store/features/LinkStatus/linkSlice";
import Toast from "@/components/Reusable/Toast/Toast";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MForm from "@/components/Reusable/Form/MForm";

 
const SiteConfigLinkConfiguration = ({isChildFullScreen}) => {
    const dispatch = useDispatch();
    
    const { links: linkConfigs, loading: isGlobalLoading } = useSelector((state) => state.linkSlice);
    
    const [radioVal, setRadioVal] = useState(""); 
    const [loading, setLoading] = useState(false); 
    const [portSelection, setPortSelection] = useState(""); 
    const [portOptions, setPortOptions] = useState([]); 
    const [isFetchingPorts, setIsFetchingPorts] = useState(false); 
    const [openConfirm, setOpenConfirm] = useState(false); 
    const isAnyLoading = isGlobalLoading || isFetchingPorts || loading;
    useEffect(() => {
      const fetchInitialData = async () => {
        dispatch(setLinksLoading(true));
        try {
          const response = await TopologyAxios(FETCH_EXISTING_LINK_CONFIGURATION_DETAILS, "get");
          const data = response?.data || response || []; 
          dispatch(setLinks(data));
          if (data.length > 0) setRadioVal(data[0].linkId);
        } catch (error) {
          console.error("Error fetching initial links:", error);
        } finally {
          dispatch(setLinksLoading(false));
        }
      };
      fetchInitialData();
    }, [dispatch]);
  
    // useEffect(() => {
    //   if (!radioVal) return;
    //   const currentLink = linkConfigs.find(c => c.linkId === radioVal);
    //   const resourceId = currentLink?.linkResInfo?.resourceId;
    //   if (!resourceId) return;
      
    //   const fetchPorts = async () => {
    //     setIsFetchingPorts(true);
    //     try {
    //       const response = await TopologyAxios(`${FETCH_PORT_INFO_DETAILS_BY_RESOURCE_ID}/${resourceId}`, "get");
    //       const data = response?.data || response || [];
          
    //       const formatted = data.map((item) => ({
    //         label: item.ifdesc,
    //         value: `${item.ifdesc}:${item.ifindex}`,
    //       }));
    //       setPortOptions(formatted);
          
    //       // Set selection to current existing property
    //       setPortSelection(currentLink?.linkProperties || "");
    //     } catch (error) {
    //       console.error("Error fetching ports:", error);
    //     } finally {
    //       setIsFetchingPorts(false);
    //     }
    //   };
    //   fetchPorts();
    // }, [radioVal, linkConfigs]);
    useEffect(() => {
      if (!radioVal) return;
      const currentLink = linkConfigs.find(c => c.linkId === radioVal);
      const resourceId = currentLink?.linkResInfo?.resourceId;
      if (!resourceId) return;
    
      const fetchPorts = async () => {
        setIsFetchingPorts(true);
        try {
          const response = await TopologyAxios(`${FETCH_PORT_INFO_DETAILS_BY_RESOURCE_ID}/${resourceId}`, "get");
          const data = response?.data || response || [];
          const formatted = data.map((item) => ({
            label: item.ifdesc,
            value: `${item.ifdesc}:${item.ifindex}`,
          }));
          setPortOptions(formatted);
    
          // CHANGE HERE: Only update state if the value is actually different 
          // to prevent the "blinking" re-render loop
          const existingProp = currentLink?.linkProperties || "";
          setPortSelection((prev) => (prev !== existingProp ? existingProp : prev));
    
        } catch (error) {
          console.error("Error fetching ports:", error);
        } finally {
          setIsFetchingPorts(false);
        }
      };
      fetchPorts();
    }, [radioVal, linkConfigs]);
  
    // Logic to check if a port is already assigned to ANOTHER link
    const getIsPortDisabled = (optionValue) => {
      if (!optionValue || typeof optionValue !== 'string') return false;
      const optionIfDesc = optionValue.split(":")[0];
      
      return linkConfigs.some(link => 
        link.linkId !== radioVal && // Exclude the currently selected link
        typeof link.linkProperties === 'string' &&
        link.linkProperties.split(":")[0] === optionIfDesc
      );
    };
    const currentLinkData = linkConfigs.find(c => c.linkId === radioVal);
    // const isChanged = currentLinkData && 
    // portSelection !== undefined && 
    // portSelection !== null && 
    // portSelection !== "" && // Prevent enabling if selection is cleared
    // portSelection !== currentLinkData.linkProperties;
    // Improved isChanged logic
const isChanged = useMemo(() => {
  if (!currentLinkData || !portSelection) return false;
  // Check if the selected port string is different from what is currently in the Redux store/config
  return portSelection !== currentLinkData.linkProperties;
}, [currentLinkData, portSelection]);
  
    const executeUpdate = async () => {
      setOpenConfirm(false);
      setLoading(true);
      
      if (!currentLinkData) {
        setLoading(false);
        return;
      }
    
      try {
        const requestPayload = {
          linkId: currentLinkData.linkId,
          linkName: currentLinkData.linkName,
          linkColor: currentLinkData.linkColor,
          linkProperties: portSelection,
          linkterminalType: { id: currentLinkData.linkterminalType?.id || 9 },
          linkResInfo: { resourceId: currentLinkData.linkResInfo?.resourceId }
        };
    
        const response = await TopologyAxios(UPDATE_LINK_CONFIGURATION_DETAILS, "post", requestPayload);
        const isSuccess = response?.data?.status === "Success" || response?.status === "Success";
    
        if (isSuccess) {
          const updatedLinks = linkConfigs.map(l => 
            l.linkId === radioVal ? { ...l, linkProperties: portSelection } : l
          );
          dispatch(setLinks(updatedLinks));
          Toast("Success!", "Configuration updated successfully", "success");
        } else {
          Toast("Error!", "Configuration update failed", "error");
        }
      } catch (error) {
        console.error("Update Error:", error);
        alert("An error occurred while updating.");
      } finally {
        setLoading(false);
      }
    };
  
    const portDescription = typeof portSelection === 'string' ? portSelection.split(":")[0] : "";
    return (
      <MForm title="Router WAN Interface Configuration">
       
        <Box 
          className="grid grid-cols-1 md:grid-cols-[45%_55%] gap-6 items-start mt-1"
        >
       
          <Box sx={{ width: '100%' }}>
            <RadioGroup value={radioVal} onChange={(e) => setRadioVal(Number(e.target.value))}>
              {linkConfigs.map((config) => (
                <Box
                  key={config.linkId}
                  sx={{
                    border: '1px solid',
                    borderColor: radioVal === config.linkId ? '#14348D' : '#ddd',
                    mb: 1,
                    borderRadius: '10px',
                    px: 1,
                    // Prevents the radio box from shrinking weirdly
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  <FormControlLabel
                    value={config.linkId}
                    control={<Radio size="small" />}
                    label={config.linkName}
                    sx={{ width: '100%', m: 0 }} // Ensures label takes full width of the border box
                  />
                </Box>
              ))}
            </RadioGroup>
          </Box>
    
          {/* --- RIGHT PANEL (Form Details) --- */}
          <Box
            sx={{
              width: '100%',
              border: '1px solid #ddd',
              p: 3,
              borderRadius: '20px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              gap: 2,
              minHeight: '250px' // Ensures the box doesn't look "flat" on mobile
            }}
          >
            <Box>
              <Typography variant="body2" color="textSecondary" >
                Select Interface:
              </Typography>
            </Box>
    
            <MSelect
              value={portSelection}
              options={portOptions.map((opt) => ({
                ...opt,
                disabled: getIsPortDisabled(opt.value),
              }))}
              onChange={(option) => {
                const val = typeof option === 'object' ? option.value : option;
                setPortSelection(val || "");
              }}
              getOptionLabel={(opt) => opt.label}
              getOptionValue={(opt) => opt.value}
              disabled={isFetchingPorts || isGlobalLoading}
            />
    
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 1 }}>
              <MButtonPrimary
                onClick={() => setOpenConfirm(true)}
                loading={loading}
                disabled={!isChanged || isAnyLoading }
                fullWidth
              >
                Update
              </MButtonPrimary>
            </Box>
          </Box>
        </Box>
    
        {/* --- LOADING OVERLAY --- */}
        {isAnyLoading && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              bgcolor: 'rgba(255,255,255,0.7)',
              borderRadius: '15px',
              zIndex: 10, // Increased zIndex to ensure it's above everything
            }}
          >
            <CircularProgress size={40} style={{ color: "#14348D" }} />
          </Box>
        )}
    
        <MDialog
          open={openConfirm}
          icon={confirmation_icon}
          onClose={() => setOpenConfirm(false)}
          onConfirm={executeUpdate}
          title="Confirm Configuration"
          message={`Are you sure you want to assign the port ${portDescription} to ${currentLinkData?.linkName}?`}
          confirmText="Confirm "
          mode="child"
          isChildFullScreen={isChildFullScreen}
        />
      </MForm>
    );
    
  };
  
  export default SiteConfigLinkConfiguration;