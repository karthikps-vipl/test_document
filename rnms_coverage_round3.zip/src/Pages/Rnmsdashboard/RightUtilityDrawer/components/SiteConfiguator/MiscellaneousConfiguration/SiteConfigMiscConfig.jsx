/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : MiscellaneousConfiguration
   File Name                : SiteConfigMiscConfig.jsx
   Author                   : SURAJ - VIPL
   Package                  : D:\NMS_UI_NEW\src\Pages\Rnmsdashboard\RightUtilityDrawer\components\SiteConfiguator\MiscellaneousConfiguration\SiteConfigMiscConfig.jsx
   Purpose                  : Provides form for editing  MiscellaneousConfiguration.
   Created Date             : 21-04-2026
***********************************************************************************************/


import { Box, Typography, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Update } from "@mui/icons-material";
import { useFormik } from "formik";
import {
  UPDATE_MISC_CONFIGURATION_BASED_ON_ID,
  FETCH_ALL_MISC_CONFIGURATION,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog"; // Assuming you want the confirmation dialog
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import { generateDynamicSchema } from "@/utility/FormValidation/YupSchema";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";

const fieldsConfig = [
  { id: 1, label: "Location Difference", min: 0.001, max: 0.002 },
  { id: 4, label: "RTT-VSAT", min: 500, max: 1500 },
  { id: 5, label: "RTT-LOS", min: 600, max: 1600 },
  { id: 6, label: "RTT-OFC", min: 0, max: 10 },
  { id: 7, label: "VSAT NO OF HOPS", min: 3, max: 50 },
  { id: 8, label: "LOS NO OF HOPS", min: 3, max: 50 },
  { id: 9, label: "E1-OFC NO OF HOPS", min: 3, max: 50 },
];

const UPDATE_SUCCESS = "Changes saved successfully!";

const SiteConfigMiscConfig = ({isChildFullScreen}) => {
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [initialData, setInitialData] = useState({});

  const validationSchema = generateDynamicSchema(fieldsConfig)
  const formik = useFormik({
    enableReinitialize: true,
    validateOnMount: true,
    validateOnBlur: false,
    validateOnChange: true,
    initialValues: initialData,
    validationSchema: validationSchema,
    onSubmit: () => {
      setShowConfirm(true);
    },
  });

  const getData = async () => {
    try {
      setLoading(true);
      const res = await InventoryAxios(FETCH_ALL_MISC_CONFIGURATION, "get");
      if (res?.data) {
        let val = {};
        res.data.forEach((e) => {
          // Convert to string for MInput compatibility
          val[e.id] = e.value.toString();
        });
        setInitialData(val);
      }
    } catch (err) {
      console.error("Failed to fetch configurations", err);
      Toast("Error", "Failed to fetch configurations", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const handleConfirmUpdate = async () => {
    try {
      setIsSaving(true);
      setShowConfirm(false);

      // Identify which fields actually changed compared to initial data
      const updatePromises = fieldsConfig
        .filter((field) => {
          const currentValue = Number(formik.values[field.id]);
          const initialValue = Number(initialData[field.id]);
          return currentValue !== initialValue;
        })
        .map((field) => {
          const payload = {
            id: field.id,
            value: Number(formik.values[field.id]),
            min: field.min,
            max: field.max,
          };
          return InventoryAxios(
            UPDATE_MISC_CONFIGURATION_BASED_ON_ID,
            "post",
            payload
          );
        });

      if (updatePromises.length === 0) {
        Toast("Info", "No changes to save", "info");
        return;
      }


      
      await Promise.all(updatePromises);
      Toast("Success", UPDATE_SUCCESS, "success");

      // Update initialData so formik.dirty becomes false again
      setInitialData({ ...formik.values });
    } catch (err) {
      console.error("Failed to update configuration", err);
      Toast("Error", "Failed to update configuration", "error");
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
        <CircularProgress size={30} style={{ color: "#14348D" }} />
      </Box>
    );
  }
  if (Object.keys(initialData).length === 0) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
        <Typography textAlign="center">No miscellaneous configuration found</Typography>
      </Box>
    );
  }
  return (
    <MForm title="Miscellaneous Configuration">
      <Box className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center w-full">
        {fieldsConfig.map((field) => (
          <Box key={field.id}>
            <FormField
              label={`${field.label} *`}
              error={formik.touched[field.id] && Boolean(formik.errors[field.id])}
              errorMessage={formik.errors[field.id] ? formik.errors[field.id] : ""}
              name={field.id.toString()}
              value={formik.values[field.id] || ""}
              onBlur={formik.handleBlur}
              onChange={(e) => {
                const { name, value } = e.target;
                let cleanedValue = value.replace(/[^0-9.]/g, "");
                const parts = cleanedValue.split(".");
                if (parts.length > 2) {
                  cleanedValue = `${parts[0]}.${parts.slice(1).join("")}`;
                }
                formik.setFieldValue(name, cleanedValue);
              }}
            />
          </Box>
        ))}
      </Box>

      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          mt: 3,
          pt: 2,
        }}
      >
        <MButtonPrimary
          variant="contained"
          color="primary"
          startIcon={
            isSaving ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              <Update />
            )
          }
          disabled={!formik.isValid || !formik.dirty || isSaving}
          onClick={formik.handleSubmit}
          sx={{ px: 5 }}
        >
          {isSaving ? "Updating..." : "Update"}
        </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to update these configurations?"
        onConfirm={handleConfirmUpdate}
        onClose={() => setShowConfirm(false)}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </MForm>
  );
 
};

export default SiteConfigMiscConfig;
