/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Security
   File Name                : IPwhiteList.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Security\IPwhiteList.jsx
   Purpose                  : Displays IpWhitelist users ans allows usere to search in Table.
   Created Date             : 29-03-2026
***********************************************************************************************/


import MTable from "@/components/Reusable/Table/MTable";
 import React, { useEffect, useState } from "react";
import {InventoryAxios, SecurityAxios} from "@/RestAPI/api/axiosApicall"
import {DELETE_IP, FETCH_ALL_TERMINAL_TYPE_DETAILS, FETCH_GET_ALL_ALLOWED_IP, FETCH_GET_ALL_IP } from "@/RestAPI/url/endpoint"
import { Box, CircularProgress } from "@mui/material";
import { useSelector } from "react-redux";
import MSelect from "@/components/Reusable/Select/MSelect";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import Toast from "@/components/Reusable/Toast/Toast";
 
const IPwhiteList = ({
    privilegeKey,
    isChildFullScreen,
    handleAdd,
    handleDelete,
    refreshTrigger
}) => {
    const [ipData, setIPData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [terminalTypes, setTerminalTypes] = useState([]);
    const [selectedTerminalId, setSelectedTerminalId] = useState(null);
    const [rowToDelete, setRowToDelete] = useState({
        visible: false,
        row: null
    });

    const { isCnms } = useSelector(
        (state) => state.nodeDetails
    );

    const LOGIN_WITH_ATP = window.isRNMS_LOGIN_ATP;

    // 1. Load terminal types
    useEffect(() => {
        let active = true;

        const loadTerminals = async () => {
            try {
                const res = await InventoryAxios(
                    FETCH_ALL_TERMINAL_TYPE_DETAILS,
                    "get"
                );

                if (!active) return;

                const options = (res?.data || []).map((t) => ({
                    label: t.terminalTypeName,
                    value: t.id,
                    raw: t
                }));

                setTerminalTypes(options);

            } catch (error) {
                console.error("Error loading terminals:", error);
                if (active) {
                    Toast(
                        "Error!",
                        "Failed to load terminal types",
                        "error"
                    );
                }
            }
        };

        loadTerminals();

        return () => {
            active = false;
        };
    }, [refreshTrigger]);

    // 2. Select first terminal only when necessary
    useEffect(() => {
        if (!isCnms) {
            setSelectedTerminalId(null);
            return;
        }

        if (terminalTypes.length > 0) {
            setSelectedTerminalId((previousId) => {
                const stillExists = terminalTypes.some(
                    (item) => item.value === previousId
                );

                return stillExists
                    ? previousId
                    : terminalTypes[0].value;
            });
        }
    }, [isCnms, terminalTypes]);

    // 3. Common IP data processing
    const processIPData = (rawItems) => {
        return (rawItems || []).map((item, index) => ({
            ...item,
            sno: index + 1,
            ipaddress: item.ipAddress || item.ip,
            id: item.terminalTypeId,
            terminalTypeId: item.terminalTypeId
        }));
    };

    // 4. Fetch IP data
    useEffect(() => {
        let active = true;

        const fetchIPData = async () => {

            if (isCnms && !selectedTerminalId) {
                setIPData([]);
                setLoading(terminalTypes.length === 0);
                return;
            }

            setLoading(true);

            try {
                let rawItems = [];

                if (isCnms) {
                    const endpoint =
                        `${FETCH_GET_ALL_ALLOWED_IP}/${selectedTerminalId}`;

                    const response = await SecurityAxios(
                        endpoint,
                        "get"
                    );

                    rawItems = response?.data || [];

                } else {
                    const response = await SecurityAxios(
                        FETCH_GET_ALL_IP,
                        "get",
                        1
                    );

                    rawItems = response?.data || [];
                }

                if (!active) return;

                const processedData = processIPData(rawItems);

                console.log("IP API COUNT:", rawItems.length);
                console.log("IP PROCESSED DATA:", processedData);
                console.log(
                    "IP S.NO:",
                    processedData.map(item => item.sno)
                );

                setIPData(processedData);

            } catch (error) {
                console.error("Error fetching IP data:", error);

                if (active) {
                    Toast(
                        "Error!",
                        "Failed to load IP list",
                        "error"
                    );

                    setIPData([]);
                }

            } finally {
                if (active) {
                    setLoading(false);
                }
            }
        };

        if (!isCnms || selectedTerminalId) {
            fetchIPData();
        }

        return () => {
            active = false;
        };

    }, [
        isCnms,
        selectedTerminalId,
        refreshTrigger
    ]);

    // 5. Terminal dropdown change
    const handleTerminalChange = (newValue) => {
        const finalId =
            typeof newValue === "object" && newValue !== null
                ? newValue.value
                : newValue;

        if (!finalId || finalId === selectedTerminalId) return;

        setSelectedTerminalId(finalId);
    };

    // 6. Delete IP
    const handleDeleteRow = async (row) => {
        const terminalId =
            row.terminalTypeId || row.id;

        const ipAddress =
            row.ipaddress || row.ip;

        if (!ipAddress || !terminalId) {
            Toast(
                "Error!",
                "Invalid row data for deletion.",
                "error"
            );
            return;
        }

        const payload = {
            ipAddress,
            terminalTypeId: terminalId
        };

        try {
            await SecurityAxios(
                DELETE_IP,
                "post",
                payload
            );

            Toast(
                "Success!",
                "IP Address deleted successfully",
                "success"
            );

            setIPData((previousData) => {
                const updatedData = previousData.filter(
                    item => item.ipaddress !== ipAddress
                );

                return updatedData.map((item, index) => ({
                    ...item,
                    sno: index + 1
                }));
            });

            setRowToDelete({
                visible: false,
                row: null
            });

        } catch (error) {
            console.error("Error deleting IP:", error);

            Toast(
                "Error!",
                "Failed to delete IP Address",
                "error"
            );
        }
    };

    const shouldShowActions =
        isCnms || LOGIN_WITH_ATP === true;

    const shouldShowAdd =
        isCnms || LOGIN_WITH_ATP === true;

    const columns = [
        {
            name: "S. No",
            uid: "sno",
            width: "70px"
        },
        {
            name: "IP Address",
            uid: "ipaddress"
        },
        ...(shouldShowActions
            ? [{
                name: "Actions",
                uid: "actions",
                width: "100px",
                render: (rowData) => renderActionCell(rowData)
            }]
            : [])
    ];

    return (
        <Box>

            {isCnms && (
                <Box
                    sx={{
                        marginBottom: 2,
                        display: "flex",
                        flexDirection: "column",
                        width: "50%"
                    }}
                >
                    <MSelect
                        label="Terminal Type *"
                        options={terminalTypes}
                        value={selectedTerminalId}
                        onChange={handleTerminalChange}
                        multiple={false}
                        disabled={false}
                        helperText={
                            selectedTerminalId
                                ? "Select a terminal to view its allowed IPs"
                                : "Loading terminals..."
                        }
                    />
                </Box>
            )}

            {loading ? (
                <Box
                    sx={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        width: "100%",
                        height: "200px"
                    }}
                >
                    <CircularProgress />
                </Box>
            ) : (
                <MTable
                    privilegeKey={privilegeKey}
                    columns={columns}
                    tableData={ipData}
                    showPagination={true}
                    showSearch={true}
                    refreshTrigger={refreshTrigger}
                    hideAdd={!shouldShowAdd}
                    AddText="Add"

                    handleAdd={() => {
                        handleAdd({
                            mode: "CREATE",
                            title: "Add IP Address",
                            selectedTerminalId: isCnms
                                ? selectedTerminalId
                                : null
                        });
                    }}

                    handleDelete={(row) => {
                        setRowToDelete({
                            visible: true,
                            row
                        });
                    }}
                />
            )}

            {rowToDelete.visible && (
                <MDialog
                    open={rowToDelete.visible}
                    variant="error"
                    title="Confirm Action"
                    mode="child"
                    isChildFullScreen={isChildFullScreen}
                    message={`Are you sure you want to delete ${
                        rowToDelete.row?.ipaddress || "this IP"
                    }?`}
                    icon={Delete_Icon_}

                    onConfirm={() => {
                        handleDeleteRow(rowToDelete.row);
                    }}

                    onClose={() => {
                        setRowToDelete({
                            visible: false,
                            row: null
                        });
                    }}
                />
            )}

        </Box>
    );
};

export default IPwhiteList;
 