import React, { useState } from 'react';
import {
  Box,
  Radio,
  RadioGroup,
  FormControlLabel,
  Stack,
  Typography,
} from '@mui/material';
import MButtonPrimary from '@/components/Reusable/Button/MButtonPrimary';
import MInput from '@/components/Reusable/Input/MInput';
import { ADD_ALLOWED_IP } from '@/RestAPI/url/endpoint';
import question_mark from "@/assets/SVGIcons/question_mark.svg";
 
import { SecurityAxios } from '@/RestAPI/api/axiosApicall';
import MDialog from '@/components/Reusable/Dialog/MDialog';
import Toast from '@/components/Reusable/Toast/Toast';
import { useSelector } from 'react-redux';

const IPwhiteListAdd = ({
  data,
  selectedIp,
  onChangeSuccess,
  selectedTerminalId,
  onClose,
  onRefresh,
  isGrandchildFullScreen
}) => {

  const { siteDetails } = useSelector(
      (state) => state.nodeDetails
  );

  const terminalTypeId = siteDetails?.id;

  const finalTerminalId =
      selectedTerminalId ??
      data?.selectedTerminalId ??
      null;

  const [ip, setIp] = useState(selectedIp || "");
  const [ipType, setIpType] = useState("1");
  const [ipError, setIpError] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);
  const [saving, setSaving] = useState(false);

  // 1. Change IP version
  const handleTypeChange = (event) => {
      setIpType(event.target.value);
      setIp("");
      setIpError("");
  };

  // 2. Validate IP while typing
  const onChangeValues = (item, value) => {
      if (item !== "ip") return;

      let parsedValue = value;

      if (ipType === "1") {

          let cleaned = value.replace(/[^0-9.]/g, "");

          cleaned = cleaned.replace(/\.{2,}/g, ".");

          const parts = cleaned.split(".");

          if (parts.length > 4) return;

          for (let i = 0; i < parts.length; i++) {
              const part = parts[i];

              if (part === "") continue;

              const num = parseInt(part, 10);

              if (isNaN(num) || num > 255) return;

              if (
                  part.length > 1 &&
                  part.startsWith("0")
              ) {
                  return;
              }
          }

          parsedValue = cleaned;

      } else {
          parsedValue = value
              .toLowerCase()
              .replace(/[^0-9a-f:%]/g, "");
      }

      setIp(parsedValue);
      validateForm(parsedValue);
  };

  // 3. Validate complete IP
  const validateForm = (currentIp) => {

      if (!currentIp) {
          setIpError("IP Address cannot be empty");
          return;
      }

      if (ipType === "1") {

          const ipV4Regex =
              /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

          if (!ipV4Regex.test(currentIp)) {
              setIpError("Invalid IPv4 Address format");
              return;
          }

          setIpError("");

      } else {

          // Basic IPv6 validation
          const isValidIPv6 =
              /^(?=.*:)[0-9a-f:]{2,39}$/i.test(currentIp);

          if (!isValidIPv6) {
              setIpError("Invalid IPv6 Address format");
              return;
          }

          setIpError("");
      }
  };

  // 4. Open confirmation dialog
  const handleAddSubmit = (event) => {
      if (event) event.preventDefault();

      validateForm(ip);

      if (!ip || ipError) return;

      setShowConfirm(true);
  };

  // 5. Confirm and save
  const confirmAddition = async () => {

      if (!ip || saving) return;

      if (!finalTerminalId && !terminalTypeId) {
          Toast(
              "Error!",
              "Terminal Type ID is missing.",
              "error"
          );
          return;
      }

      setSaving(true);
      setShowConfirm(false);

      const payload = {
          ipAddress: ip,
          terminalTypeId:
              finalTerminalId || terminalTypeId
      };

      console.log("ADD IP PAYLOAD:", payload);

      try {

          const response = await SecurityAxios(
              ADD_ALLOWED_IP,
              "post",
              payload
          );

          console.log("ADD IP RESPONSE:", response);

          const apiStatus = response.data?.status;

          if (apiStatus === 1) {

              Toast(
                  "Success!",
                  response.data?.message ||
                  "IP Address added successfully!",
                  "success"
              );

              // Refresh parent table
              if (onRefresh) {
                  onRefresh();
              } else if (onChangeSuccess) {
                  onChangeSuccess();
              }

              setIp("");
              setIpError("");

              // Close Add component
              if (onClose) {
                  onClose();
              }

          } else {

              Toast(
                  "Error!",
                  response.data?.message ||
                  "Failed to save IP Address.",
                  "error"
              );
          }

      } catch (error) {

          console.error("Error saving IP:", error);

          Toast(
              "Error!",
              error?.response?.data?.message ||
              "Failed to save IP Address. Please try again.",
              "error"
          );

      } finally {
          setSaving(false);
      }
  };

  return (
      <Box
          sx={{
              display: "flex",
              flexDirection: "column",
              gap: 1,
              width: "100%"
          }}
      >

          <RadioGroup
              value={ipType}
              onChange={handleTypeChange}
              name="ipVersion"
          >
              <Stack direction="row" spacing={2}>

                  <FormControlLabel
                      value="1"
                      control={<Radio />}
                      label="IPv4"
                  />

                  <FormControlLabel
                      value="2"
                      control={<Radio />}
                      label="IPv6"
                  />

              </Stack>
          </RadioGroup>

          <Box
              sx={{
                  display: "flex",
                  pl: 2,
                  pr: 3,
                  flexDirection: "column",
                  gap: 1
              }}
          >

              <Typography sx={{ mb: 0.5 }}>
                  IP Address *
              </Typography>

              <MInput
                  fullWidth
                  value={ip}
                  onChange={(event) =>
                      onChangeValues(
                          "ip",
                          event.target.value
                      )
                  }
                  error={!!ipError}
                  helperText={ipError}
                  size="small"
                  placeholder={
                      ipType === "1"
                          ? "___.___.___.___"
                          : "e.g. 2001:0db8::1"
                  }
              />

          </Box>

          <Box
              sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  pr: 3,
                  mt: 2
              }}
          >

              <MButtonPrimary
                  variant="contained"
                  color="primary"
                  onClick={handleAddSubmit}
                  disabled={
                      !ip ||
                      !!ipError ||
                      saving
                  }
              >
                  Add
              </MButtonPrimary>

          </Box>

          <MDialog
              open={showConfirm}
              variant="warning"
              title="Confirm Action"
              icon={question_mark}
              message="Are you sure you want to add this IP Address?"

              onConfirm={confirmAddition}

              onClose={() =>
                  setShowConfirm(false)
              }

              mode="grandchild"
              isGrandchildFullScreen={
                  isGrandchildFullScreen
              }
          />

      </Box>
  );
};

export default IPwhiteListAdd;