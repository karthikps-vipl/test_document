/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Security
   File Name                : IPwhiteList.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Security\IPwhiteList.jsx
   Purpose                  : Displays IpWhitelist users ans allows usere to search in Table.
   Created Date             : 29-03-2026
***********************************************************************************************/


import MTable from "@/components/Reusable/Table/MTable";
 import React, { useEffect, useState } from "react";
import {InventoryAxios, SecurityAxios} from "@/RestAPI/api/axiosApicall"
import {FETCH_ALL_TERMINAL_TYPE_DETAILS, FETCH_GET_ALL_IP } from "@/RestAPI/url/endpoint"
import { Box, CircularProgress } from "@mui/material";
import { useSelector } from "react-redux";
import MSelect from "@/components/Reusable/Select/MSelect";
  
const IPwhiteList = ({ privilegeKey }) => {
    const [ipData, setIPData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [terminalTypes, setTerminalTypes] = useState([]);
    const [selectedTerminalId, setSelectedTerminalId] = useState(""); // Ensure this state exists

    const columns = [
        { name: "S. No ", uid: "sno", width: '70px' },
        { name: "IP Address", uid: "ipaddress" },
    ];

    const { isCnms } = useSelector((state) => state.nodeDetails);

    useEffect(() => {
        const load = async () => {
            try {
                const res = await InventoryAxios(FETCH_ALL_TERMINAL_TYPE_DETAILS, "get");
                console.log("Terminal Types Response:", res);
                
                setTerminalTypes(
                    (res?.data || []).map((t) => ({
                        label: t.terminalTypeName,
                        value: t.id,
                        raw: t,
                    }))
                );
            } catch (err) {
                Toast("Error!", `Error loading terminals`, "error");
            }
        };
        load();
    }, []);

    // Helper function to handle selection change
    const handleTerminalChange = (newValue) => {
        setSelectedTerminalId(newValue);
        // You can add logic here if you need to fetch specific IPs based on terminal type
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const { data } = await SecurityAxios(FETCH_GET_ALL_IP, "get", 1);
                
                const processedData = (data || []).map((item, index) => ({
                    sno: index + 1,
                    ipaddress: item.ipAddress,
                }));

                setIPData(processedData);
            } catch (error) {
                console.error("Error fetching IP data:", error);
                setIPData([]);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    return (
        <Box>
            {/* Render MSelect ONLY when isCnms is true */}
            {isCnms && (
                <Box sx={{ marginBottom: 2 ,display:"flex"  ,flexDirection:"column",width:"50%"}}>
                    <MSelect
                        label="Terminal Type *"
                        options={terminalTypes}
                        value={selectedTerminalId}
                        onChange={handleTerminalChange}
                        multiple={false}
                    />
                </Box>
            )}

            {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%' }}>
                    <CircularProgress />
                </Box>
            ) : (
                <MTable
                    privilegeKey={privilegeKey}
                    columns={columns}
                    tableData={ipData}
                    showPagination={true}
                    showSearch={true}
                />
            )}
        </Box>
    );
};

export default IPwhiteList;

 