/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Security
   File Name                : SecuritySettings.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Security\SecuritySettings.jsx
   Purpose                  : Displays SecuritySettings  details in disabled form.
   Created Date             : 31-03-2026
***********************************************************************************************/

import React, { useEffect, useState } from "react";
import { SecurityAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_SECURITY_SETTINGS,
  FETCH_SECURITY_SETTINGS_WITH_AUTH,
  UPDATE_SECURITY_SETTINGS,
} from "@/RestAPI/url/endpoint";
import {
  Box,
  CircularProgress,
  IconButton,
  Typography,
  InputAdornment,
} from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { useSelector } from "react-redux";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { encryptData } from "@/utility/encryptLogin";
import Toast from "@/components/Reusable/Toast/Toast";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";

// const passwordComplexityRegex =
//     /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%&()*+=\-_.$])[A-Za-z\d!@#$%&()*+=\-_.$]{8,16}$/;

const validatePassword = (val) => {
  if (!val) {
    return "Password is required";
  }
  if (val.includes(" ")) {
    return "Spaces are not allowed";
  }
  if (val.length < 8 || val.length > 16) {
    return "Password should be between 8-16 characters.";
  }

  // Instead of lookaheads with .* (which causes backtracking),
  // we use simple character class tests.

  // 1. Check for lowercase
  if (!/[a-z]/.test(val)) {
    return "Password should contain atleast 1 lowercase character.";
  }

  // 2. Check for uppercase
  if (!/[A-Z]/.test(val)) {
    return "Password should contain atleast 1 uppercase character.";
  }

  // 3. Check for digit
  if (!/\d/.test(val)) {
    return "Password should contain atleast 1 number.";
  }

  // 4. Check for special character
  // Removed the lookahead (?=.*...) and just tested the set directly
  // if (!/[!@#$%&()*+=\-_.$]/.test(val)) {
  //     return "Password should contain atleast 1 special character.";
  // }
  if (!/[!@#$%&()*+=._$-]/.test(val)) {
    return "Password should contain atleast 1 special character.";
  }

  return "";
};

const Securitysettings = ({ isChildFullScreen, onSuccess }) => {
  const [securityData, setSecurityData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isCnms, setIsCnms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  // ... other states
  // const [isConfirmOpen, setIsConfirmOpen] = useState(false); // Add this line
  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tempPasswordInput, setTempPasswordInput] = useState("");
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState("");
  const [modalShowPassword, setModalShowPassword] = useState(false);
  const [dialogType, setDialogType] = useState(null);
  // Error state
  const [errors, setErrors] = useState({});

  // Derived State
  const nodeDetails = useSelector((state) => state.nodeDetails || {});

  const reduxIsCnms = nodeDetails?.isCnms;

  const finalIsCnms = reduxIsCnms ?? isCnms ?? false;

  const userName = useSelector(
    (state) => state.userSlice.userDetails.data.userName
  );

  const fetchData = async () => {
    try {
      setLoading(true); // Show loader while re-fetching
      const endpoint = FETCH_SECURITY_SETTINGS;
      const method = "get";

      const { data } = await SecurityAxios(endpoint, method, 1);

      if (data) {
        setSecurityData(data);
        if (
          data.isCnms === true ||
          data.defaultPassword !== undefined ||
          data.defaultpassword !== undefined
        ) {
          setIsCnms(true);
        } else {
          setIsCnms(false);
        }
        setErrors({});
        setHasChanges(false);
      } else {
        setSecurityData(null);
        setIsCnms(false);
        setErrors({});
        setHasChanges(false);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFieldChange = (field, value) => {
    setSecurityData((prev) => {
      // If we are changing the password, update BOTH keys to avoid "ghost" data
      if (field === "defaultPassword") {
        return {
          ...prev,
          defaultPassword: value,
          defaultpassword: value, // Sync both keys immediately
        };
      }

      return {
        ...prev,
        [field]: value,
      };
    });

    setHasChanges(true);
    setHasChanges(true);

    let errorMsg = "";

    if (field === "defaultPassword") {
      errorMsg = validatePassword(value);
    } else if (field === "passwordRecoveryEmail") {
      // SECURE EMAIL REGEX
      const emailRegex =
        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

      if (!value || value.trim() === "") {
        errorMsg = "Password Recovery Email is required";
      } else if (!emailRegex.test(value)) {
        errorMsg = "Enter a valid Email";
      } else {
        const emailLength = value.length;
        if (emailLength < 5 || emailLength > 48) {
          errorMsg = "Email must be between 5 and 48 characters";
        }
      }
    } else {
      // ... rest of your fieldConfig logic remains the same
      const fieldConfig = {
        passwordExpiryDays: { min: 30, max: 90, name: "Password Expiry Days" },
        blockExpiryInHours: { min: 10, max: 60, name: "Blocked Duration" },
        noOfPasswordRetries: { min: 3, max: 10, name: "No of retries" },
        sessionTimeout: { min: 1, max: 48, name: "Session timeout" },
        oldPasswordmatch: { min: 3, max: 5, name: "Old password matches" },
        showPasswordExpiryAlartSecurity: {
          min: 0,
          max: 999,
          name: "Show Password Expiry Alert",
        },
        maxSessionCount: { min: 1, max: 9, name: "Max Session Count" },
      };

      const config = fieldConfig[field];
      if (config) {
        if (value === "" || value === null || value === undefined) {
          errorMsg = `${config.name} is required`;
        } else {
          const num = Number(value);
          if (isNaN(num)) {
            errorMsg = `${config.name} must be a number`;
          } else if (num < config.min || num > config.max) {
            errorMsg = `${config.name} should be between ${config.min}-${config.max}.`;
          }
        }
      }
    }

    setErrors((prev) => ({
      ...prev,
      [field]: errorMsg,
    }));
  };

  const toggleVisibility = (fieldName) => {
    if (fieldName !== "defaultPassword") {
      return;
    }

    if (showPassword) {
      setShowPassword(false);
      return;
    }

    setTempPasswordInput("");
    setModalError("");
    setModalShowPassword(false);
    setIsModalOpen(true);
  };

  const handleVerifyPasswordInModal = async () => {
    const validationError = validatePassword(tempPasswordInput);

    if (validationError) {
      setModalError(validationError);

      Toast("Validation Error", validationError, "error");

      return;
    }

    setModalLoading(true);
    setModalError("");

    try {
      const payload = {
        password: encryptData(tempPasswordInput),
        userName: encryptData(userName),
      };

      const response = await SecurityAxios(
        FETCH_SECURITY_SETTINGS_WITH_AUTH,
        "post",
        payload
      );

      const isSuccess =
        response.status === 200 || response.data?.success === true;

      if (isSuccess) {
        const dbData = response.data?.data;

        if (!dbData) {
          Toast("Error", response?.data?.message, "error");

          return;
        }

        let revealedPassword = "";

        if (dbData.defaultpassword) {
          revealedPassword = dbData.defaultpassword;
        } else if (dbData.defaultPassword) {
          revealedPassword = dbData.defaultPassword;
        }

        if (revealedPassword && revealedPassword.trim() !== "") {
          setSecurityData((prev) => ({
            ...prev,
            defaultPassword: revealedPassword,
            defaultpassword: revealedPassword,
          }));

          setIsModalOpen(false);
          setTempPasswordInput("");
          setModalError("");
          setModalShowPassword(false);
          setShowPassword(true);

          setHasChanges(false);

          setErrors((prev) => ({
            ...prev,
            defaultPassword: "",
          }));

          Toast(
            "Success",
            "Identity Verified. Default Password Revealed.",
            "success"
          );
        } else {
          setModalError("Password field was empty in the response.");

          Toast("Error", "Password not found in response.", "error");
        }
      } else {
        setModalError("Incorrect password. Please try again.");

        Toast("Error", "Verification Failed", "error");
      }
    } catch (error) {
      console.error("Verification Error:", error);

      if (error.message) {
        Toast("Error", `Server Error: ${error.message}`, "error");
      } else {
        Toast("Error", "Network or Server Error", "error");
      }
    } finally {
      setModalLoading(false);
    }
  };

  const handleCloseModal = () => {
    if (modalLoading) return;
    setIsModalOpen(false);
    setTempPasswordInput("");
    setModalError("");
    setModalShowPassword(false);
    // If you want to sync with dialogType:
    setDialogType(null);
  };

  // This function now only opens the confirmation dialog
  const handleSubmit = () => {
    if (!hasChanges) {
      Toast("Info", "No changes detected to save.", "info");
      return;
    }

    const hasErrors = Object.values(errors).some((error) => error !== "");
    if (hasErrors) {
      Toast(
        "Validation Error",
        "Please fix validation errors before saving.",
        "error"
      );
      return;
    }

    // Instead of calling API, show confirmation
    setDialogType("confirm");
  };

  // const handleCloseDialog = () => {
  //     setDialogType(null);
  // };

  // This function performs the actual API call
  const handleConfirmUpdate = async () => {
    // 1. Immediately clear the dialog type to signal the UI to close
    setDialogType(null);

    setLoading(true);

    try {
      const currentDefaultPass =
        securityData.defaultPassword || securityData.defaultpassword || "";

      const payload = {
        blockExpiryInHours: securityData.blockExpiryInHours,
        defaultpassword: currentDefaultPass
          ? encryptData(currentDefaultPass)
          : null,
        id: securityData.id || 1,
        maxSessionCount: securityData.maxSessionCount,
        noOfPasswordRetries: securityData.noOfPasswordRetries,
        oldPasswordmatch: securityData.oldPasswordmatch,
        passwordExpiryDays: securityData.passwordExpiryDays,
        passwordRecoveryEmail: securityData.passwordRecoveryEmail,
        sessionTimeout: securityData.sessionTimeout,
        showPasswordExpiryAlartSecurity:
          securityData.showPasswordExpiryAlartSecurity,
      };

      await SecurityAxios(UPDATE_SECURITY_SETTINGS, "post", payload);

      setHasChanges(false);
      Toast("Success", "Security Settings Updated Successfully!", "success");

      setShowPassword(false);
      await fetchData();
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("Error saving data:", error);
      Toast("Error", "Failed to save Security  settings.", "error");
      // Note: If you want the dialog to stay open on error so the user can try again,
      // you would move 'setDialogType(null)' to the try block only.
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "50vh",
        }}
      >
        <CircularProgress size={32} color="inherit" />
      </Box>
    );
  }

  if (!securityData || Object.keys(securityData).length === 0) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          p: 5,
        }}
      >
        <Typography textAlign="center">No security settings found</Typography>
      </Box>
    );
  }

  const {
    blockExpiryInHours,
    maxSessionCount,
    noOfPasswordRetries,
    oldPasswordmatch,
    passwordExpiryDays,
    sessionTimeout,
    showPasswordExpiryAlartSecurity,
    passwordRecoveryEmail,
  } = securityData;

  if (!finalIsCnms) {
    return (
      <MForm title="Security Settings">
        <Box className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          <FormField
            label="Password Expiry (Days)"
            value={passwordExpiryDays}
            required
            disabled
          />

          <FormField
            label="User Block Duration(Min)"
            value={blockExpiryInHours}
            required
            disabled
          />

          <FormField
            label="Login Retries"
            value={noOfPasswordRetries}
            required
            disabled
          />

          <FormField
            label="Session Timeout (Hrs)"
            value={sessionTimeout}
            required
            disabled
          />

          <FormField
            label="Old Password Matches"
            value={oldPasswordmatch}
            required
            disabled
          />

          <FormField
            label="Show Password Expiry Alert (Days)"
            value={showPasswordExpiryAlartSecurity}
            required
            disabled
          />

          <FormField
            label="Max Session Count"
            value={maxSessionCount}
            required
            disabled
          />
        </Box>
      </MForm>
    );
  }

//   const currentDefaultPassword =
//     securityData?.defaultpassword || securityData?.defaultPassword || "";

  return (
    <>
      <MForm title="Security Settings">
        <Box className="grid grid-cols-2 md:grid-cols-3 gap-6 items-start p-1">
          {/* DEFAULT PASSWORD */}

          {/* DEFAULT PASSWORD */}
          <FormField
            label="Default Password"
            required
            // CHANGE THIS LINE:
            // Do NOT use the 'currentDefaultPassword' variable here.
            // Use the state directly so the UI updates as you type.
            value={securityData.defaultPassword || ""}
            type={showPassword ? "text" : "password"}
            // CHANGE THIS:
            // Ensure it is NOT disabled, otherwise you can't type.

            onChange={(e) =>
              handleFieldChange(
                "defaultPassword", // This updates securityData.defaultPassword
                e.target.value
              )
            }
            error={Boolean(errors.defaultPassword)}
            errorMessage={errors.defaultPassword || ""}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => toggleVisibility("defaultPassword")}
                    disabled={modalLoading}
                  >
                    {showPassword ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />

          {/* PASSWORD EXPIRY */}

          <FormField
            label="Password Expiry (Days)"
            value={passwordExpiryDays}
            onChange={(e) =>
              handleFieldChange("passwordExpiryDays", e.target.value)
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.passwordExpiryDays)}
            errorMessage={errors.passwordExpiryDays || ""}
            required
            min={30}
            max={90}
            disabled={false}
          />

          {/* BLOCK DURATION */}

          <FormField
            label="User Block Duration(Min)"
            value={blockExpiryInHours}
            onChange={(e) =>
              handleFieldChange("blockExpiryInHours", e.target.value)
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.blockExpiryInHours)}
            errorMessage={errors.blockExpiryInHours || ""}
            required
            min={10}
            max={60}
            disabled={false}
          />

          {/* LOGIN RETRIES */}

          <FormField
            label="Login Retries"
            value={noOfPasswordRetries}
            onChange={(e) =>
              handleFieldChange("noOfPasswordRetries", e.target.value)
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.noOfPasswordRetries)}
            errorMessage={errors.noOfPasswordRetries || ""}
            required
            min={3}
            max={10}
            disabled={false}
          />

          {/* SESSION TIMEOUT */}

          <FormField
            label="Session Timeout (Hrs)"
            value={sessionTimeout}
            onChange={(e) =>
              handleFieldChange("sessionTimeout", e.target.value)
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.sessionTimeout)}
            errorMessage={errors.sessionTimeout || ""}
            required
            min={1}
            max={48}
            disabled={false}
          />

          {/* OLD PASSWORD MATCHES */}

          <FormField
            label="Old Password Matches"
            value={oldPasswordmatch}
            onChange={(e) =>
              handleFieldChange("oldPasswordmatch", e.target.value)
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.oldPasswordmatch)}
            errorMessage={errors.oldPasswordmatch || ""}
            required
            min={3}
            max={5}
            disabled={false}
          />

          {/* PASSWORD EXPIRY ALERT */}

          <FormField
            label="Show Password Expiry Alert (Days)"
            value={showPasswordExpiryAlartSecurity}
            onChange={(e) =>
              handleFieldChange(
                "showPasswordExpiryAlartSecurity",
                e.target.value
              )
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.showPasswordExpiryAlartSecurity)}
            errorMessage={errors.showPasswordExpiryAlartSecurity || ""}
            required
            min={0}
            max={999}
            disabled={false}
          />

          {/* MAX SESSION COUNT */}

          <FormField
            label="Max Session Count"
            value={maxSessionCount}
            onChange={(e) =>
              handleFieldChange("maxSessionCount", e.target.value)
            }
            onKeyDown={(e) => {
              if (
                !/[0-9]/.test(e.key) &&
                e.key !== "Backspace" &&
                e.key !== "Delete"
              ) {
                e.preventDefault();
              }
            }}
            error={Boolean(errors.maxSessionCount)}
            errorMessage={errors.maxSessionCount || ""}
            required
            min={1}
            max={9}
            disabled={false}
          />

          {/* PASSWORD RECOVERY EMAIL */}

          <FormField
            label="Password Recovery Email"
            value={passwordRecoveryEmail}
            minLength={5}
            maxLength={48}
            onChange={(e) =>
              handleFieldChange("passwordRecoveryEmail", e.target.value)
            }
            error={Boolean(errors.passwordRecoveryEmail)}
            errorMessage={errors.passwordRecoveryEmail || ""}
            required
            type="email"
            disabled={false}
          />
        </Box>

        {/* SAVE BUTTON */}

        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            mt: 3,
          }}
        >
          <MButtonPrimary
            disabled={
              !hasChanges || loading || Object.values(errors).some((err) => err)
            }
            onClick={handleSubmit}
          >
            {loading ? "Saving..." : "Update"}
          </MButtonPrimary>
        </Box>
      </MForm>
      {/* SINGLE CONFIRMATION DIALOG */}
      {dialogType === "confirm" && (
        <MDialog
          open={dialogType === "confirm"}
          variant="info"
          icon={confirmation_icon}
          title="Confirm Action"
          message="Are you sure you want to update the Security Settings?"
          onConfirm={handleConfirmUpdate}
          onClose={handleCloseModal}
          // These are the props you wanted to add:
          mode="child"
          isChildFullScreen={isChildFullScreen}
        />
      )}
      {/* PASSWORD VERIFICATION MODAL */}

      <MDialog
        icon={confirmation_icon}
        open={isModalOpen}
        onClose={handleCloseModal}
        onConfirm={handleVerifyPasswordInModal}
        title="Verify Password"
        message={
          <span>
            Enter password for <strong>'{userName}'</strong>
          </span>
        }
        confirmText="Confirm"
        cancelText="Cancel"
        mode="child"
        isChildFullScreen={isChildFullScreen}
        confirmDisabled={
          modalLoading ||
          !tempPasswordInput ||
          !!validatePassword(tempPasswordInput)
        }
        isSubmitting={modalLoading}
      >
        <Box sx={{ mt: 2 }}>
          <MInput
            fullWidth
            label="Password"
            placeholder="Enter Password"
            type={modalShowPassword ? "text" : "password"}
            value={tempPasswordInput}
            disabled={modalLoading}
            onChange={(e) => {
              const value = e.target.value;

              if (value.includes(" ")) {
                return;
              }

              if (value.length <= 16) {
                setTempPasswordInput(value);

                setModalError(validatePassword(value));
              }
            }}
            errorMessage={modalError}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => setModalShowPassword((prev) => !prev)}
                    edge="end"
                    disabled={modalLoading}
                  >
                    {modalShowPassword ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </Box>
      </MDialog>
    </>
  );
};

export default Securitysettings;
