import React, { useState, useEffect } from "react";
import { Box, Checkbox, CircularProgress, useTheme } from "@mui/material";
import { FaultAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MTable from "@/components/Reusable/Table/MTable";
import MAlarmSelect from "../../../../../components/Reusable/Select/MAlarmSelect";

import {
  FETCH_ALL_RESOURCE_MASTER_TYPE_DETAILS,
  GET_ALL_ALARM_TYPE,
} from "@/RestAPI/url/endpoint";
import {
  exportToPDF,
  exportToCSV,
} from "@/components/Reusable/Pdf/downloadPdf";
import { severityConfig } from "@/lib/utils";

const AlarmConfiguration = () => {
  const [deviceOptions, setDeviceOptions] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [repTableData, setRepTableData] = useState([]);
  const [loadingTable, setLoadingTable] = useState(false);
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';
  // 1. Updated Columns to match the merged data structure
  const columns = [
    { name: "S. No", uid: "sln", width: "100px" },
    { name: "Alarm Name", uid: "alarmName" },
    { name: "Description", uid: "alarmDescription", width: "220px" },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      width: "120px",
      filterOptions: Object.keys(severityConfig).map((key) => {
        const numericKey = Number(key);
        return {
          label: severityConfig[key].label,
          value: numericKey, // This will correctly result in -1, 0, 1, or 2
          gradient: severityConfig[key].gradient,
        };
      }),
    },
    {
      name: "Process at RNMS",
      uid: "isLocalProcessing",
      width: "170px",
      filterType: "dropdown", // Added filter type
      filterOptions: [
        // Added filter options
        { label: "Yes", value: true },
        { label: "No", value: false },
      ],
      render: (value) => <Checkbox checked={Boolean(value)} disabled />,
    },
    {
      name: "Forward to CNMS",
      uid: "isForwardHigherNms",
      filterType: "dropdown", // Added filter type
      filterOptions: [
        // Added filter options
        { label: "Yes", value: true },
        { label: "No", value: false },
      ],
      render: (value) => <Checkbox checked={Boolean(value)} disabled />,
    },
  ];

  // 2. Fetch Device List
  useEffect(() => {
    const fetchDevices = async () => {
      try {
        const response = await InventoryAxios(
          FETCH_ALL_RESOURCE_MASTER_TYPE_DETAILS,
          "get"
        );

        // Convert object {"0": {...}} to Array and flatten for easy access
        const deviceList = Object.values(response.data).map((item) => ({
          label: item.resourceNickName || item.resourceTypeName,
          value: item.resourceTypeId,
          // Flattening nested fields so the MTable/Select can access them easily
          resourceNickName: item.resourceNickName,
          resourceTypeName: item.resourceTypeName,
          make: item.make,
          terminalNickname: item.terminalId?.terminalNickname || "",
          status: item.data?.status,
          ...item,
        }));
        setDeviceOptions(deviceList);
      } catch (error) {
        console.error("Error fetching devices:", error);
      }
    };
    fetchDevices();
  }, []);

  // 3. Fetch Alarm Data and MERGE
  useEffect(() => {
    const fetchAlarmDetails = async () => {
      if (!selectedDevice || !selectedDevice.resourceTypeId) {
        setRepTableData([]);
        return;
      }

      setLoadingTable(true);
      try {
        const response = await FaultAxios(
          `${GET_ALL_ALARM_TYPE}/${selectedDevice.resourceTypeId}`,
          "get"
        );

        // response.data is an object: {"0": {...}, "1": {...}}
        // We need to turn it into an array
        const alarmObjects = Object.values(response.data);
        console.log("repTableData", alarmObjects);

        // MAP: Merge every alarm with the selected device info
        const mergedRows = alarmObjects.map((alarm, index) => {
          return {
            // Alarm properties
            sln: index + 1,
            alarmName: alarm.alarmName,
            alarmDescription: alarm.alarmDescription,
            alarmTypeId: alarm.alarmTypeId,
            severity: alarm.severity,
            isLocalProcessing: alarm.isLocalProcessing,
            isForwardHigherNms: alarm.isForwardHigherNms,
          };
        });

        setRepTableData(mergedRows);
      } catch (error) {
        console.error("Error fetching alarm details:", error);
        setRepTableData([]);
      } finally {
        setLoadingTable(false);
      }
    };

    fetchAlarmDetails();
  }, [selectedDevice]);

  return (
    <Box>
      <Box  >
        {loadingTable ? (
          <Box className="flex justify-center p-10">
            <CircularProgress size={30} />
          </Box>
        ) : (
          <MTable
            tableTitle="Alarm Configuration"
            columns={columns}
            tableData={repTableData}
            showPagination={true}
            customDropdown={
              <MAlarmSelect
                // label="Select Device"
                options={deviceOptions}
                value={selectedDevice ? selectedDevice.resourceTypeId : ""}
                onChange={(val) => {
                  const selectedObj = deviceOptions.find(
                    (opt) => opt.value === val
                  );
                  setSelectedDevice(selectedObj || null);
                }}
                multiple={false} // Explicitly single select
                style={{ width: "200px", height: "40px" }}
            isDark={isDark}

              />
            }
            handleDownloadPDF={() =>
              exportToPDF(
                "Alarm Configuration",
                columns,
                repTableData,
                "Alarm_Configuration"
              )
            }
            handleDownloadCSV={() =>
              exportToCSV("Alarm_Configuration", columns, repTableData)
            }
            showSearch={true}
          />
        )}
      </Box>
    </Box>
  );
};

export default AlarmConfiguration;
