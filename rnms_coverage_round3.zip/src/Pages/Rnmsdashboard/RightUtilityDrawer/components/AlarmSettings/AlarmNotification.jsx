import React, { useEffect, useState, useMemo } from "react";
import { Box, CircularProgress, MenuItem, Select } from "@mui/material";
import MTable from "@/components/Reusable/Table/MTable";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Confirmation_icon from "@/assets/SVGIcons/Alert.svg";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_ALL_ALARM_NOTIFICATION,
  UPDATE_ALL_ALARM_NOTIFICATION_SETTINGS,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { Update } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { setAlarmNotificationSettings } from "@/store/features/Fault/alarmSlice";

const AUDIO_FILE_CHOICES = ["MAJOR.wav", "MINOR.wav", "WARNING.wav"];

const AlarmNotification = ({ privilegeKey, isChildFullScreen}) => {

  const [alarmFetchedData, setAlarmFetchedData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [originalData, setOriginalData] = useState([]);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [audioOptions] = useState(AUDIO_FILE_CHOICES);
const dispatch = useDispatch();
  const [dialogConfig, setDialogConfig] = useState({
    isOpen: false,
    title: "",
    message: "",
    variant: "info",
    onConfirm: () => {},
  });

  const openDialog = ({ title, message, variant = "info", onConfirm }) => {
    setDialogConfig({ isOpen: true, title, message, variant, onConfirm });
  };

  const closeDialog = () => {
    setDialogConfig((prev) => ({ ...prev, isOpen: false }));
  };

  // ---------------- FETCH DATA ----------------
  const fetchAlarmDetails = async () => {
    try {
      setLoading(true);
      const response = await FaultAxios(GET_ALL_ALARM_NOTIFICATION, "get");
      const rawData = Array.isArray(response.data)
        ? response.data
        : Object.values(response.data || {});

      const formattedData = rawData.map((item, index) => ({
        sln: index + 1,
        id: item?.id,
        severity: item?.severity,
        audioFileName: item?.audioFileName,
        isMute: item?.isMute,
        isPopup: item?.isPopup,
      }));

      setAlarmFetchedData(formattedData);
      setOriginalData(formattedData);
      
      const notificationSettings = {};

      formattedData.forEach((item) => {
        notificationSettings[item.severity] = {
          audioFileName: item.audioFileName,
          isMute: item.isMute,
          isPopup: item.isPopup,
        };
      });
  
      dispatch(
        setAlarmNotificationSettings(notificationSettings)
      );
    } catch (error) {
      console.error("Error fetching alarm details:", error);
      Toast("Error", "Failed to load alarm settings", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlarmDetails();
  }, []);

  // ---------------- ROW SELECT ----------------
  const handleRowSelect = (id, checked) => {
    const stringId = String(id); // Force to string
    const updated = new Set(selectedRows);
    if (checked) {
      updated.add(stringId);
    } else {
      updated.delete(stringId);
    }
    setSelectedRows(updated);
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      // Force all IDs to strings when selecting all
      const allIds = new Set(alarmFetchedData.map((row) => String(row.id)));
      setSelectedRows(allIds);
    } else {
      setSelectedRows(new Set());
    }
  };

  // ---------------- LOGIC HANDLERS ----------------
  const handleSwitchChange = (id, field, value) => {
    setAlarmFetchedData((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: value } : row))
    );
  };

  const handleAudioChange = (id, newValue) => {
    const alreadyUsed = alarmFetchedData.some(
      (row) => row.id !== id && row.audioFileName === newValue
    );

    if (alreadyUsed) {
      openDialog({
        title: "Duplicate Selection",
        message: `Audio file "${newValue}" is already selected for another severity. Do you still want to continue?`,
        variant: "error",
        onConfirm: () => {
          setAlarmFetchedData((prev) =>
            prev.map((row) =>
              row.id === id ? { ...row, audioFileName: newValue } : row
            )
          );
          closeDialog();
        },
      });
    } else {
      setAlarmFetchedData((prev) =>
        prev.map((row) =>
          row.id === id ? { ...row, audioFileName: newValue } : row
        )
      );
    }
  };

  // const handleUpdate = async () => {
  //   // const payload = alarmFetchedData.filter((row) => selectedRows.has(row.id));
  //   const payload = alarmFetchedData.filter((row) =>
  //     selectedRows.has(String(row.id))
  //   );
  //   if (payload.length === 0) {
  //     openDialog({
  //       title: "Selection Required",
  //       message: "Please select at least one row to update",
  //       variant: "info",
  //       onConfirm: closeDialog,
  //     });
  //     return;
  //   }

  //   try {
  //     setLoading(true);
  //     await FaultAxios(UPDATE_ALL_ALARM_NOTIFICATION_SETTINGS, "post", payload);
  //     const notificationSettings = {};

  //     payload.forEach((item) => {
  //       notificationSettings[item.severity] = {
  //         audioFileName: item.audioFileName,
  //         isMute: item.isMute,
  //         isPopup: item.isPopup,
  //       };
  //     });
  
  //     dispatch(
  //       setAlarmNotificationSettings(notificationSettings)
  //     );
  //     await fetchAlarmDetails();
  //     Toast("Success", "Settings updated successfully", "success");
  //     setSelectedRows(new Set());
  //   } catch (e) {
  //     Toast("Error", "Update failed.", "error");
  //     console.error(e);
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const handleUpdate = async () => {
    const payload = alarmFetchedData.filter((row) =>
      selectedRows.has(String(row.id))
    );
  
    if (payload.length === 0) {
      openDialog({
        title: "Selection Required",
        message: "Please select at least one row to update",
        variant: "info",
        onConfirm: closeDialog,
      });
      return;
    }
  
    try {
      setLoading(true);
  
      await FaultAxios(
        UPDATE_ALL_ALARM_NOTIFICATION_SETTINGS,
        "post",
        payload
      );
  
      // fetchAlarmDetails() will update Redux settings
      await fetchAlarmDetails();
  
      Toast(
        "Success",
        "Settings updated successfully",
        "success"
      );
  
      setSelectedRows(new Set());
  
    } catch (e) {
      Toast("Error", "Update failed.", "error");
      console.error(e);
    } finally {
      setLoading(false);
    }
  };
  
  const isDirty = useMemo(() => {
    return JSON.stringify(alarmFetchedData) !== JSON.stringify(originalData);
  }, [alarmFetchedData, originalData]);

  // ---------------- COLUMNS DEFINITION ----------------
  const columns = [
    { name: "S. No", uid: "sln", width: "70px" },
    { name: "Severity", uid: "severity", width: "120px" },
    {
      name: "Audio File Name",
      uid: "audioFileName",
      render: (value, row) => (
        <Select
          size="small"
          value={value || ""}
          // Crucial: Disable if the row is not selected in the MTable
          disabled={!selectedRows.has(String(row.id))}
          onChange={(e) => handleAudioChange(row.id, e.target.value)}
          sx={{
            width: "100%",
            minWidth: 160,
            backgroundColor: "transparent",
            "& .MuiOutlinedInput-notchedOutline": { border: "none" },
            "&:hover .MuiOutlinedInput-notchedOutline": { border: "none" },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              border: "none",
            },
            "& .MuiSelect-select": {
              paddingLeft: 0,
              paddingRight: "24px",
              display: "flex",
              alignItems: "center",
              height: "1.5em",
            },
          }}
        >
          {audioOptions.map((option) => (
            <MenuItem key={option} value={option}>
              {option}
            </MenuItem>
          ))}
        </Select>
      ),
    },
    {
      name: "Mute",
      uid: "isMute",
      width: "120px",
      render: (value, row) => (
        <CustomSwitch
          checked={!!value}
          disabled={!selectedRows.has(String(row.id))}
          onChange={(e) =>
            handleSwitchChange(row.id, "isMute", e.target.checked)
          }
        />
      ),
    },
    {
      name: "Popup",
      uid: "isPopup",
      width: "120px",
      render: (value, row) => (
        <CustomSwitch
          checked={!!value}
          disabled={!selectedRows.has(String(row.id))}
          onChange={(e) =>
            handleSwitchChange(row.id, "isPopup", e.target.checked)
          }
        />
      ),
    },
  ];

  return (
    <Box>
      <Box  >
        <MTable
          privilegeKey={privilegeKey}
          columns={columns}
          tableData={alarmFetchedData}
          showPagination={true}
          showSearch={true}
          enableRowSelection={true}
          selectedRowsNew={selectedRows}
          onRowSelect={handleRowSelect}
          onSelectAll={handleSelectAll}
          rowIdKey="id"
        />

        <Box sx={{ m: 1, display: "flex", justifyContent: "flex-end", gap: 2 }}>
          <MButtonPrimary
            variant="contained"
            color="primary"
            sx={{ borderRadius: "8px", px: 4 }}
            onClick={handleUpdate}
            disabled={!isDirty || loading}
            startIcon={
              loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            {loading ? "Updating..." : "Update"}
          </MButtonPrimary>
        </Box>
      </Box>

      <MDialog
        open={dialogConfig.isOpen}
        variant={dialogConfig.variant}
        icon={Confirmation_icon}
        title={dialogConfig.title}
        message={dialogConfig.message}
        onConfirm={dialogConfig.onConfirm}
        onClose={closeDialog}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </Box>
  );
};

export default AlarmNotification;
