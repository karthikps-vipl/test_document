import React, { useEffect, useState, useMemo } from "react";
import {
  Box,
  Typography,
  CircularProgress,
  FormControlLabel,
  Checkbox,
  useTheme,
} from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { InfoCircleOutlined } from "@ant-design/icons";
import { Update } from "@mui/icons-material";
import { useFormik } from "formik";
import Toast from "@/components/Reusable/Toast/Toast";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { generateDynamicSchema } from "@/utility/FormValidation/YupSchema";
import confirmation_icon from "@/assets/SVGIcons/Alert.svg";
import {
  GET_DEFAULT_POLL_INTERVAL,
  UPDATE_DEFAULT_POLL_INTERVAL,
} from "@/RestAPI/url/endpoint";
import { miscRegexNumeric } from "@/utility/FormValidation/Regex";

const AlarmPollingInterval = () => {
  const theme=useTheme()
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [apiConstraints, setApiConstraints] = useState({
    min: 0,
    max: 100,
    defaultVal: 0,
  });

  const [initialData, setInitialData] = useState({
    pollingInterval: "",
    isDefault: false,
  });

  const fieldsConfig = useMemo(
    () => [
      {
        id: "pollingInterval",
        label: "Polling Interval (Seconds)",
        min: apiConstraints.min,
        max: apiConstraints.max,
      },
    ],
    [apiConstraints]
  );

  const validationSchema = useMemo(
    () => generateDynamicSchema(fieldsConfig),
    [fieldsConfig]
  );

  const formik = useFormik({
    enableReinitialize: true,
    initialValues: initialData,
    validationSchema: validationSchema,
    onSubmit: (values) => {
      if (values.isDefault) {
        setShowConfirm(true);
      } else {
        handleConfirmUpdate();
      }
    },
  });

  const getData = async () => {
    try {
      setLoading(true);
      const res = await FaultAxios(GET_DEFAULT_POLL_INTERVAL, "get");
      if (res?.data) {
        const {
          pollingInterval,
          defaultInterval,
          minPollingInterval,
          maxPollingInterval,
        } = res.data;

        // Store constraints for validation and checkbox behavior
        setApiConstraints({
          min: minPollingInterval,
          max: maxPollingInterval,
          defaultVal: defaultInterval,
        });

        setInitialData({
          pollingInterval: pollingInterval.toString(),
          isDefault: pollingInterval === defaultInterval,
        });
      }
    } catch (err) {
      console.error("Failed to fetch polling config", err);
      Toast("Error", "Failed to fetch configuration", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const handleCheckboxChange = (event) => {
    const isChecked = event.target.checked;
    formik.setFieldValue("isDefault", isChecked);

    if (isChecked) {
      formik.setFieldValue(
        "pollingInterval",
        apiConstraints.defaultVal.toString()
      );
    }
  };

  const handleConfirmUpdate = async () => {
    try {
      setIsSaving(true);
      setShowConfirm(false);
      const payload = {
        pollingInterval: Number(formik.values.pollingInterval),
      };
      const res = await FaultAxios(
        UPDATE_DEFAULT_POLL_INTERVAL,
        "post",
        payload
      );
      if (res?.data) {
        Toast("Success", "Polling interval updated successfully!", "success");
        setInitialData({
          pollingInterval: res.data.pollingInterval.toString(),
          isDefault: res.data.pollingInterval === res.data.defaultInterval,
        });
      }
    } catch (err) {
      console.error("Failed to update polling configuration", err);
      Toast("Error", "Failed to update configuration", "error");
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
        <CircularProgress size={30} style={{ color: "#14348D" }} />
      </Box>
    );
  }
  if (!initialData.pollingInterval && initialData.pollingInterval !== 0) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
        <Typography textAlign="center">No polling configuration found</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Box
        sx={{
          border: "2px solid #eee",
          borderRadius: "20px",
          display: "flex",
          flexDirection: "column",
          gap: 3,
          alignItems: "start",
          justifyContent: "start",
          padding: 2,
        }}
      >
        {/* Info Section */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: theme.palette.background.headerBg,
            borderRadius: "11px",
            padding: "6px 40px",
            
          }}
        >
          <InfoCircleOutlined
            style={{ fontSize: "16px", paddingRight: "8px" }}
          />
          <Typography
            variant="body2"
            sx={{
              fontFamily: "Montserrat",
              fontWeight: "400",
            
              textAlign: "center",
            }}
          >
            This configuration is not applicable for Remote Modem and NETCAP.
          </Typography>
        </Box>

        {/* Form Section */}
        <Box sx={{ width: "100%" }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              ml:3
            }}
          >
            <Box>
              <Typography variant="body2" sx={{ fontWeight: 500, mb: 0.5 }}>
                Interval (Sec) *
              </Typography>
              <MInput
                fullWidth
                name="pollingInterval"
                value={formik.values.pollingInterval}
                disabled={formik.values.isDefault}
                onChange={(e) => {
                  if (miscRegexNumeric.numericInput.test(e.target.value)) {
                    formik.handleChange(e);
                  }
                }}
                onBlur={formik.handleBlur}
                error={formik.touched.pollingInterval && Boolean(formik.errors.pollingInterval)}
                errorMessage={formik.errors.pollingInterval}
              />
            </Box>

            <FormControlLabel
              control={
                <Checkbox
                  name="isDefault"
                  checked={formik.values.isDefault}
                  onChange={handleCheckboxChange}
                  color="primary"
                />
              }
              label={
                <Typography variant="body2">
                  Reset to Default Interval
                </Typography>
              }
            />

            <Box sx={{ display: "flex", mt: 1 }}>
              <MButtonPrimary
                variant="contained"
                color="primary"
                startIcon={
                  isSaving ? (
                    <CircularProgress size={20} color="inherit" />
                  ) : (
                    <Update />
                  )
                }
                disabled={!formik.isValid || !formik.dirty || isSaving}
                onClick={formik.handleSubmit}
                sx={{ px: 5 }}
              >
                {isSaving ? "Updating..." : "Update"}
              </MButtonPrimary>
            </Box>
          </Box>
        </Box>
      </Box>

      <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="This reset is not applicable for Remote Modem and NETCAP"
        onConfirm={handleConfirmUpdate}
        onClose={() => setShowConfirm(false)}
      />
    </Box>
  );
};

export default AlarmPollingInterval;
