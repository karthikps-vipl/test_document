import ThermometerWidget from "./thermometer/ThermometerWidget";
import GaugeWidget from "./gauge/GaugeWidget";
import FanWidget from "./fan/FanWidget";

export const WidgetRegistry = {
  thermometer: ThermometerWidget,
  gauge: GaugeWidget,
  fan: FanWidget,
};
