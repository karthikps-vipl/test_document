import React from "react";
import {
  Box,
  Button,
  Grid,
  IconButton,
  Typography,
  useTheme,
} from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";
import VerticalTableWidget from "./VerticalTable/VerticalTableWidget";
import FanWidget from "./fan/FanWidget";
import GaugeWidget from "./gauge/GaugeWidget";
import { PowerSupplyWidget } from "./PowerSupply/PowerSupplyWidget";
import { VoltageGaugeWidget } from "./Voltage/VoltageGaugeWidget";
import TitleWidget from "./title/TitleWidget";
import RemoteDevice from "./remoteDevice/RemoteDevice";
import switch_chassis from "@/assets/PortStatus/port.svg";
import ImageWidget from "./image/ImageWidget";
import {
  KeyboardArrowDownOutlined,
  KeyboardArrowUp,
} from "@mui/icons-material";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MTextAreaAntD from "@/components/Reusable/Texarea/MTextArea";
import CircularDialGauge from "./dgSet/CircularDialGauge";

const image = {
  "24SwithchChassis": switch_chassis,
};

const IMAGE_OPTIONS = [
  {
    label: "24SwithchChassis",
    value: "24SwithchChassis",
  },
];
const getNumberRegex = (step) => {
  const stepValue = Number(step);

  // Decimal step
  if (!Number.isInteger(stepValue)) {
    return /^-?\d+(\.\d+)?$/;
  }

  // Integer step
  return /^-?\d*$/;
};

export const validateFieldValue = (value, item) => {
  const rawValue = String(value ?? "").trim();

  /*
   * ============================================
   * REQUIRED
   * ============================================
   */
  if (!rawValue) {
    return "This field is required";
  }

  /*
   * ============================================
   * NUMBER
   * ============================================
   */
  if (item?.inpType === "number") {
    const min =
      item?.min !== undefined && item?.min !== ""
        ? Number(item.min)
        : undefined;

    const max =
      item?.max !== undefined && item?.max !== ""
        ? Number(item.max)
        : undefined;

    const step =
      item?.step !== undefined && item?.step !== ""
        ? Number(item.step)
        : undefined;

    /*
     * Invalid number format
     */
    const regex = getNumberRegex(step);

    if (!regex.test(rawValue)) {
      return "Please enter a valid number";
    }

    const numericValue = Number(rawValue);

    if (!Number.isFinite(numericValue)) {
      return "Please enter a valid number";
    }

    /*
     * ============================================
     * MIN
     * ============================================
     */
    if (min !== undefined && numericValue < min) {
      return `Value must be at least ${min}`;
    }

    /*
     * ============================================
     * MAX
     * ============================================
     */
    if (max !== undefined && numericValue > max) {
      return `Value must not exceed ${max}`;
    }

    /*
     * ============================================
     * STEP
     * ============================================
     *
     * Example:
     *
     * min = 0
     * step = 0.5
     *
     * Valid:
     * 0
     * 0.5
     * 1
     * 1.5
     * 2
     *
     * Invalid:
     * 0.2
     * 0.7
     * 1.3
     */
    if (step !== undefined && step > 0) {
      const base = min !== undefined ? min : 0;

      const difference = numericValue - base;
      const quotient = difference / step;

      const isValidStep = Math.abs(quotient - Math.round(quotient)) < 1e-9;

      if (!isValidStep) {
        return `Value must increase in steps of ${step}`;
      }
    }

    return "";
  }

  /*
   * ============================================
   * TEXT REGEX
   * ============================================
   */
  if (item?.regex) {
    try {
      const regex =
        item.regex instanceof RegExp ? item.regex : new RegExp(item.regex);

      if (!regex.test(rawValue)) {
        return "Invalid format";
      }
    } catch (error) {
      console.error("Invalid regex configuration:", item.regex);

      return "Invalid validation configuration";
    }
  }

  return "";
};

export const WIDGET_REGISTRY = {
  // static: {
  //   label: "Static",
  //   defaultWidth: 36,
  //   defaultHeight: 25,
  //   // backgroundColor:'#E4EBFF',
  //   // borderColor: "#b3cbff",

  //   fields: [
  //     {
  //       id: "gridTitle",
  //       label: "Grid Title",
  //       type: "text",
  //       placeholder: "e.g. System Info",
  //     },
  //     {
  //       id: "numColumns",
  //       label: "No of Columns",
  //       type: "text",
  //       placeholder: "e.g. 1, 2, or 3",
  //     },
  //     {
  //       id: "commonLabel",
  //       label: "Common Label",
  //       type: "text",
  //       placeholder: "e.g. Meta information",
  //     },
  //   ],
  //   renderCanvas: (widget, handleInputValueChange, widgetIdx) => {
  //     const theme = useTheme();
  //     const headerBg = theme.palette.custom?.snmp?.modalbg || "#E4EBFF";
  //     const headerText =
  //       theme.palette.custom?.snmp?.snmmptitle || theme.palette.primary.main;
  //     const contentBg = theme.palette.custom.snmp.contentbg || "#F6F8FF";
  //     return (
  //       <Box sx={{ height: "100%" }}>
  //         <Box
  //           sx={{
  //             backgroundColor: headerBg,
  //           }}
  //         >
  //           <Typography
  //             sx={{
  //               color: headerText,
  //               p: 1,
  //               fontSize: "14px",
  //               fontWeight: "bold",
  //               textAlign: "center",
  //             }}
  //           >
  //             {widget.tableTitle || "Static Form Group Block"}
  //           </Typography>
  //         </Box>

  //         <Box
  //           sx={{
  //             p: 2,
  //             overflowY: "auto",
  //             height: "calc(100% - 45px)",
  //             display: "flex",
  //             flexWrap: "wrap",
  //             // display: "grid",
  //             // gridTemplateColumns: `repeat(${
  //             //   parseInt(widget.cols, 10) || 3
  //             // }, minmax(0, 1fr))`,
  //             gap: "20px",
  //             backgroundColor: contentBg,
  //           }}
  //           // className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start "
  //         >
  //           {widget.data?.map((inputItem, dataIdx) => {
  //             const match = inputItem?.name?.match(/\((.*?)\)/) || [];
  //             return (
  //               <Box key={dataIdx}>
  //                 <Typography
  //                   sx={{
  //                     mb: 0.3,
  //                     fontSize: "13px",
  //                     fontWeight: 500,
  //                   }}
  //                 >
  //                   {inputItem.name}
  //                 </Typography>
  //                 {/* <TextArea
  //                  autoSize={{ minRows: 1, maxRows: 3 }}
  //                 style={{resize: 'none',}}
  //                   fullWidth
  //                   value={inputItem.currentValue || ""}
  //                   // placeholder={inputItem.oid}
  //                   showUnit={true}
  //                   unit={match[1]}
  //                   onChange={(e) =>
  //                     handleInputValueChange(widgetIdx, dataIdx, e.target.value)
  //                   }
  //                 /> */}
  //                 <MTextAreaAntD
  //                   autoSize={{ minRows: 1, maxRows: 3 }}
  //                   value={inputItem.currentValue || ""}
  //                   showUnit={true}
  //                   unit={match[1]} // This will now show up inside the AntD TextArea
  //                   onChange={(e) =>
  //                     handleInputValueChange(widgetIdx, dataIdx, e.target.value)
  //                   }
  //                   // You can pass any other Ant Design TextArea props here
  //                 />
  //               </Box>
  //             );
  //           })}
  //         </Box>
  //       </Box>
  //     );
  //   },
  // },
  static: {
    label: "Static",
    defaultWidth: 36,
    defaultHeight: 25,
    // backgroundColor: '#E4EBFF',
    // borderColor: "#b3cbff",

    fields: [
      {
        id: "gridTitle",
        label: "Grid Title",
        type: "text",
        placeholder: "e.g. System Info",
      },
      {
        id: "numColumns",
        label: "No of Columns",
        type: "text",
        placeholder: "e.g. 1, 2, or 3",
      },
      {
        id: "commonLabel",
        label: "Common Label",
        type: "text",
        placeholder: "e.g. Meta information",
      },
    ],

    renderCanvas: (widget, handleInputValueChange, widgetIdx) => {
      const theme = useTheme();

      const headerBg = theme.palette.custom?.snmp?.modalbg || "#E4EBFF";

      const headerText =
        theme.palette.custom?.snmp?.snmmptitle || theme.palette.primary.main;

      const contentBg = theme.palette.custom?.snmp?.contentbg || "#F6F8FF";

      const data = widget.data || [];

      const hasLatitude = data.some((item) =>
        /^latitude\s*\(/i.test(item?.name?.trim() || "")
      );

      const hasLongitude = data.some((item) =>
        /^longitude\s*\(/i.test(item?.name?.trim() || "")
      );

      const hasLatLong = hasLatitude && hasLongitude;

      const getName = (item) => item?.name?.trim()?.toLowerCase() || "";

      const getOid = (item) => item?.oid?.trim() || "";

      const getOidParts = (oid) => {
        return oid.replace(/^\./, "").split(".").map(Number);
      };

      const getLastOidNumber = (item) => {
        const oid = getOid(item);

        if (!oid) return null;

        const parts = getOidParts(oid);

        if (!parts.length) return null;

        if (parts[parts.length - 1] === 0) {
          parts.pop();
        }

        return parts.length ? parts[parts.length - 1] : null;
      };

      let latitudeFields = [];
      let longitudeFields = [];
      let remainingFields = [];

      if (hasLatLong) {
        const latitudeDeg = data.findIndex((item) =>
          /^latitude\s*\(\s*deg\s*\)/i.test(item?.name?.trim() || "")
        );

        const latitudeMin = data.findIndex((item) =>
          /^latitude\s*\(\s*min\s*\)/i.test(item?.name?.trim() || "")
        );

        const latitudeSec = data.findIndex((item) =>
          /^latitude\s*\(\s*sec\s*\)/i.test(item?.name?.trim() || "")
        );

        let latitudeDirection = -1;

        if (latitudeSec !== -1) {
          const secLastNumber = getLastOidNumber(data[latitudeSec]);

          latitudeDirection = data.findIndex((item) => {
            const name = getName(item);

            const lastNumber = getLastOidNumber(item);

            return name === "direction" && lastNumber === secLastNumber + 1;
          });
        }

        const longitudeDeg = data.findIndex((item) =>
          /^longitude\s*\(\s*deg\s*\)/i.test(item?.name?.trim() || "")
        );

        const longitudeMin = data.findIndex((item) =>
          /^longitude\s*\(\s*min\s*\)/i.test(item?.name?.trim() || "")
        );

        const longitudeSec = data.findIndex((item) =>
          /^longitude\s*\(\s*sec\s*\)/i.test(item?.name?.trim() || "")
        );

        let longitudeDirection = -1;

        if (longitudeSec !== -1) {
          const secLastNumber = getLastOidNumber(data[longitudeSec]);

          longitudeDirection = data.findIndex((item) => {
            const name = getName(item);

            const lastNumber = getLastOidNumber(item);

            return name === "direction" && lastNumber === secLastNumber + 1;
          });
        }

        const latitudeIndexes = [
          latitudeDeg,
          latitudeMin,
          latitudeSec,
          latitudeDirection,
        ].filter((index) => index !== -1);

        latitudeFields = latitudeIndexes.map((index) => ({
          item: data[index],
          index,
        }));
        const longitudeIndexes = [
          longitudeDeg,
          longitudeMin,
          longitudeSec,
          longitudeDirection,
        ].filter((index) => index !== -1);

        longitudeFields = longitudeIndexes.map((index) => ({
          item: data[index],
          index,
        }));

        const usedIndexes = new Set([...latitudeIndexes, ...longitudeIndexes]);

        remainingFields = data
          .map((item, index) => ({
            item,
            index,
          }))
          .filter(({ index }) => !usedIndexes.has(index));
      }

      const renderInputField = (inputItem, dataIdx, sx = {}) => {
        // const match = inputItem?.name?.match(/\((.*?)\)/) || [];
        const name = inputItem?.name || "";
        const openParenIndex = name.indexOf("(");
        const closeParenIndex = name.indexOf(")", openParenIndex + 1);
        
        const unit =
          openParenIndex !== -1 && closeParenIndex !== -1
            ? name.slice(openParenIndex + 1, closeParenIndex)
            : "";
        return (
          <Box
            key={dataIdx}
            sx={{
              ...sx,
            }}
          >
            <Typography
              sx={{
                mb: 0.3,
                fontSize: "13px",
                fontWeight: 500,
              }}
            >
              {inputItem.name}
            </Typography>

            <MTextAreaAntD
              autoSize={{
                minRows: 1,
                maxRows: 3,
              }}
              value={inputItem.currentValue || ""}
              showUnit={true}
              unit={unit}
              onChange={(e) =>
                handleInputValueChange(widgetIdx, dataIdx, e.target.value)
              }
            />
          </Box>
        );
      };

      return (
        <Box sx={{ height: "100%" }}>
          {/* HEADER */}

          <Box
            sx={{
              backgroundColor: headerBg,
            }}
          >
            <Typography
              sx={{
                color: headerText,
                p: 1,
                fontSize: "14px",
                fontWeight: "bold",
                textAlign: "center",
              }}
            >
              {widget.tableTitle || "Static Form Group Block"}
            </Typography>
          </Box>

          <Box
            sx={{
              p: 2,
              overflowY: "auto",
              height: "calc(100% - 45px)",
              backgroundColor: contentBg,

              ...(hasLatLong
                ? {
                    display: "flex",
                    flexDirection: "column",
                    gap: "20px",
                  }
                : {
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "20px",
                  }),
            }}
          >
            {hasLatLong ? (
              <>
                {latitudeFields.length > 0 && (
                  <Box
                    sx={{
                      display: "flex",
                      width: "100%",
                      gap: "20px",
                      alignItems: "flex-start",
                    }}
                  >
                    {latitudeFields.map(({ item, index }) =>
                      renderInputField(item, index, {
                        flex: 1,
                        minWidth: 0,
                      })
                    )}
                  </Box>
                )}

                {longitudeFields.length > 0 && (
                  <Box
                    sx={{
                      display: "flex",
                      width: "100%",
                      gap: "20px",
                      alignItems: "flex-start",
                    }}
                  >
                    {longitudeFields.map(({ item, index }) =>
                      renderInputField(item, index, {
                        flex: 1,
                        minWidth: 0,
                      })
                    )}
                  </Box>
                )}

                {remainingFields.length > 0 && (
                  <Box
                    sx={{
                      display: "flex",
                      width: "100%",
                      gap: "20px",
                      alignItems: "flex-start",
                    }}
                  >
                    {remainingFields.map(({ item, index }) =>
                      renderInputField(item, index, {
                        flex: 0.24,
                        minWidth: 0,
                      })
                    )}
                  </Box>
                )}
              </>
            ) : (
              widget.data?.map((inputItem, dataIdx) =>
                renderInputField(inputItem, dataIdx)
              )
            )}
          </Box>
        </Box>
      );
    },
  },
  table: {
    label: "Vertical Table",
    defaultWidth: 36, // Takes full horizontal canvas width row
    defaultHeight: 14, // Lower row footprint since rows run horizontally
    // backgroundColor: "#ffffff",
    // borderColor: "#14348D",

    fields: [
      {
        id: "gridTitle",
        label: "Table Component Title *",
        type: "text",
        placeholder: "e.g., Active Status Parameters / Log Overview",
      },
    ],

    renderCanvas: (
      widget,
      handleInputValueChange,
      widgetIdx,
      hdsgfjhdgsf,
      dummy,
      resourceId,
      liveData
    ) => {
      console.log(liveData, "liveDataasaffghfgjkjhkjhk");
      // const theme = useTheme();
      const data = widget?.data;
      const table = liveData?.table;

      const rawApiResponse = { data, table };

      const tableId = widget.tableId;

      const dynamicColumns = [
        {
          uid: "sno",
          name: "S.No",
          width: "60px",
        },
        ...data.map((item) => ({
          uid: item.oid, // Use OID directly as unique column identifier key
          name: item.name || item.displayName,
          width: "180px", // Default width
        })),
      ];

      return (
        <VerticalTableWidget
          tableTitle={widget.tableTitle || "Parameter Overview Canvas"}
          rawApiResponse={rawApiResponse}
          widget={widget}
          tableId={tableId}
          dynamicColumns={dynamicColumns}
        />
      );
    },
  },
  thermometer: {
    label: "Thermometer",
    defaultWidth: 12,
    defaultHeight: 18,
    // backgroundColor: "#ffffff",
    // borderColor: "#e0e0e0",
    fields: [
      { id: "gridTitle", label: "Thermometer Component Title *", type: "text" },
      {
        id: "thermometerNameOid",
        label: "Target Name Selection Field *",
        type: "excelDropdown",
      },
      {
        id: "thermometerStateOid",
        label: "Target Status State Field *",
        type: "excelDropdown",
      },
      {
        id: "thermometerValueOid",
        label: "Target Value Metric Field *",
        type: "excelDropdown",
      },
    ],
    renderCanvas: (widget, handleInputValueChange, widgetIdx) => {
      const theme = useTheme();
      const rawMetrics = widget.data || [];
      const nameData = rawMetrics[0] || {};
      const stateData = rawMetrics[1] || {};
      const valueData = rawMetrics[2] || {};

      const rawCurrentValue = parseFloat(valueData.currentValue);
      const activeTemperatureValue = !isNaN(rawCurrentValue)
        ? rawCurrentValue
        : 68;
      const activeStateDisplay = stateData.currentValue ?? "Normal Operation";
      const targetDisplayName = nameData.name || "Temperature Sensor";

      const mercuryFillPercentage = Math.min(
        Math.max((activeTemperatureValue / 100) * 100, 5),
        100
      );

      return (
        <div
          style={{
            padding: "16px",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "space-between",
            boxSizing: "border-box",
            fontFamily: "sans-serif",
            backgroundColor: theme.palette.background.paper,
            color: theme.palette.text.primary,
          }}
        >
          <div style={{ textAlign: "center", width: "100%" }}>
            <h4
              style={{
                margin: "0 0 4px 0",
                color: theme.palette.text.TitleTextcolor,
                fontSize: "14px",
                fontWeight: "600",
              }}
            >
              {widget.tableTitle || "Core Temp Sensor"}
            </h4>
            <span
              style={{
                fontSize: "11px",
                color: theme.palette.text.TitleTextcolor,
              }}
            >
              Tag: {targetDisplayName}
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <div
              style={{
                width: "24px",
                height: "150px",
                // background: "#f1f1f1",
                borderRadius: "20px 20px 0 0",
                border: "2px solid #ccc",
                position: "relative",
                display: "flex",
                flexDirection: "column",
                justifyContent: "flex-end",
                alignItems: "center",
              }}
            >
              <div
                style={{
                  width: "14px",
                  height: `${mercuryFillPercentage}%`,
                  background:
                    "linear-gradient(to right, #e53935, #ff1744, #b71c1c)",
                  borderRadius: "10px 10px 0 0",
                }}
              />
              <div
                style={{
                  width: "42px",
                  height: "42px",
                  background:
                    "radial-gradient(circle at 30% 30%, #ff1744, #d32f2f, #7f0000)",
                  borderRadius: "50%",
                  position: "absolute",
                  bottom: "-30px",
                  border: "2px solid #ccc",
                  zIndex: "2",
                }}
              />
            </div>
            <div>
              <span
                style={{
                  fontSize: "32px",
                  fontWeight: "bold",
                  color: theme.palette.text.TitleTextcolor,
                }}
              >
                {activeTemperatureValue}°C
              </span>
              <div
                style={{
                  marginTop: "6px",
                  padding: "3px 8px",
                  borderRadius: "12px",
                  fontSize: "11px",
                  fontWeight: "600",
                  color: "#fff",
                  backgroundColor:
                    activeTemperatureValue > 50 ? "#d32f2f" : "#2e7d32",
                }}
              >
                {activeStateDisplay}
              </div>
            </div>
          </div>
          {/* <span style={{ fontSize: "10px", color: "#888" }}>
            Value OID Ref: {valueData.oid || "Unmapped"}
          </span> */}
        </div>
      );
    },
  },
  needelGauge: {
    label: "Needle Gauge",
    defaultWidth: 36,
    defaultHeight: 22,
    //backgroundColor: "#ffffff",
    borderColor: "#e0e0e0",
    fields: [
      { id: "gridTitle", label: "Gauge Component Title *", type: "text" },
      {
        id: "gaugeRangePreset",
        label: "Select Target Arc Range Scale *",
        type: "presetDropdown",
        options: [
          { label: "0 to 180", value: "0-180" },
          { label: "0 to 90", value: "0-90" },
          { label: "-x to +x (Custom Symmetric Bounds)", value: "dynamic" },
        ],
      },
      {
        id: "conditionalEdit",
        label: "conditional edit",
        type: "switchBtn",
      },
    ],
    renderCanvas: (widget) => {
      const metricsData = widget.data || [];
      // const theme = useTheme();

      return (
        <GaugeWidget
          tableTitle={widget.tableTitle || "Dashboard Speedometer"}
          metricsData={metricsData}
          rangePreset={widget.rangePreset}
          customRangeX={widget.customRangeX}
        />
      );
    },
  },
  fan: {
    label: "Fan",
    defaultWidth: 36,
    defaultHeight: 16,
    //backgroundColor: "#ffffff",
    borderColor: "#e0e0e0",
    fields: [
      { id: "gridTitle", label: "Fan Panel Section Title *", type: "text" },
      {
        id: "fanNameOid",
        label: "Target Name Selection Field *",
        type: "excelDropdown",
      },
      {
        id: "fanStateOid",
        label: "Target Status State Field *",
        type: "excelDropdown",
      },
    ],
    renderCanvas: (widget) => {
      const dropdownMetrics = widget.data || [];
      // const theme = useTheme();

      // Extract the independent selected profile items from the drop-downs
      const nameProfileItem = dropdownMetrics[0] || {};
      const stateProfileItem = dropdownMetrics[1] || {};

      return (
        <FanWidget
          tableTitle={widget.tableTitle || "Exhaust Ventilation System"}
          targetName={nameProfileItem.name}
          stateValue={stateProfileItem.currentValue}
          stateOid={stateProfileItem.oid}
        />
      );
    },
  },
  voltageGauge: {
    label: "Voltage Gauge",
    defaultWidth: 14,
    defaultHeight: 18,
    //backgroundColor: "#ffffff",
    borderColor: "#e0e0e0",
    fields: [
      { id: "gridTitle", label: "Voltage Component Title *", type: "text" },
      {
        id: "voltageNameOid",
        label: "Target Name Selection Field *",
        type: "excelDropdown",
      },
      {
        id: "voltageStateOid",
        label: "Target Status State Field *",
        type: "excelDropdown",
      },
      {
        id: "voltageValueOid",
        label: "Target Value Metric Field *",
        type: "excelDropdown",
      },
    ],
    renderCanvas: (widget, handleInputValueChange, widgetIdx) => {
      const rawMetrics = widget.data || [];
      const nameData = rawMetrics[0] || {};
      const stateData = rawMetrics[1] || {};
      const valueData = rawMetrics[2] || {};
      // const theme = useTheme();

      return (
        <VoltageGaugeWidget
          tableTitle={widget.gridTitle || "Main Line Grid Bus"}
          targetDisplayName={nameData.name || "Voltage Node"}
          stateValue={stateData.currentValue ?? "Operational"}
          voltageValue={valueData.currentValue ?? 325}
          valueOid={valueData.oid}
        />
      );
    },
  },
  powerSupply: {
    label: "Power Supply Status",
    defaultWidth: 12,
    defaultHeight: 18,
    //backgroundColor: "#ffffff",
    borderColor: "#e0e0e0",
    fields: [
      { id: "gridTitle", label: "Power Component Title *", type: "text" },
      {
        id: "powerNameOid",
        label: "Target Name Selection Field *",
        type: "excelDropdown",
      },
      {
        id: "powerStateOid",
        label: "Target Status State Field *",
        type: "excelDropdown",
      },
      {
        id: "powerValueOid",
        label: "Target Power Flag Field *",
        type: "excelDropdown",
      },
    ],
    renderCanvas: (widget, handleInputValueChange, widgetIdx) => {
      // const theme = useTheme();
      const rawMetrics = widget.data || [];
      const nameData = rawMetrics[0] || {};
      const stateData = rawMetrics[1] || {};
      const valueData = rawMetrics[2] || {};

      return (
        <PowerSupplyWidget
          tableTitle={widget.gridTitle || "NA"}
          targetDisplayName={nameData.name || "NA"}
          stateValue={stateData.currentValue ?? "NA"}
          activeValue={valueData.currentValue ?? 0}
          valueOid={valueData.oid}
        />
      );
    },
  },
  scale: {
    label: "Scale",
    defaultWidth: 8,
    defaultHeight: 18,
    // backgroundColor: "#ffffff",
    borderColor: "#b3cbff",

    fields: [
      {
        id: "gridTitle",
        label: "Scale Title *",
        type: "text",
        placeholder: "e.g. Temperature",
      },
      {
        id: "scaleValueOid",
        label: "Scale Value Parameter *",
        type: "excelDropdown",
      },
      {
        id: "minVal",
        label: "Minimum Boundary Value *",
        type: "text",
        placeholder: "e.g. -100",
      },
      {
        id: "maxVal",
        label: "Maximum Boundary Value *",
        type: "text",
        placeholder: "e.g. 100",
      },
    ],

    renderCanvas: (widget) => {
      const theme = useTheme();
      const metric = widget.data?.[0] || {};

      const min = Number(widget.range?.min ?? widget.minVal ?? -100);

      const max = Number(widget.range?.max ?? widget.maxVal ?? 100);

      const current = Number(metric.currentValue ?? 0);

      const percentage = Math.min(
        Math.max(((current - min) / (max - min)) * 100, 0),
        100
      );

      return (
        <Box
          sx={{
            height: "100%",
            width: "100%",
            p: 2,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "space-between",
            boxSizing: "border-box",
          }}
        >
          {/* TITLE */}
          <Box textAlign="center">
            <Typography
              sx={{
                color: theme.palette.custom.snmp.snmmptitle,
                fontSize: "14px",
                fontWeight: 700,
              }}
            >
              {widget.tableTitle || "Scale"}
            </Typography>

            <Typography
              sx={{
                fontSize: "11px",
                //color: "#666",
              }}
            >
              {metric.name || "Metric"}
            </Typography>
          </Box>

          {/* SCALE BODY */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 3,
              flex: 1,
              justifyContent: "center",
            }}
          >
            {/* Vertical Transparent Thermometer */}
            <Box
              sx={{
                height: "160px",
                width: "26px",
                borderRadius: "20px",
                border: "2px solid #bdbdbd",
                //background: "#f5f5f5",
                position: "relative",
                overflow: "hidden",
                display: "flex",
                alignItems: "flex-end",
              }}
            >
              <Box
                sx={{
                  width: "100%",
                  height: `${percentage}%`,
                  background: "linear-gradient(to top,#1565c0,#42a5f5)",
                  transition: "height .3s ease",
                }}
              />
            </Box>

            {/* Value Section */}
            <Box>
              <Typography
                sx={{
                  fontSize: "32px",
                  fontWeight: 700,
                  color: "#333",
                }}
              >
                {current}
              </Typography>

              <Typography
                sx={{
                  fontSize: "12px",
                  //color: "#777",
                }}
              >
                Range
              </Typography>

              <Typography
                sx={{
                  fontSize: "12px",
                  fontWeight: 600,
                }}
              >
                {min} → {max}
              </Typography>
            </Box>
          </Box>
        </Box>
      );
    },
  },
  titleWidget: {
    label: "Title Widget",
    defaultWidth: 12,
    defaultHeight: 18,
    // backgroundColor: "#ffffff",
    borderColor: "#e0e0e0",

    // Core declarative custom configuration parameters input block setup
    fields: [
      {
        id: "titleWidget",
        label: "Enter title",
        type: "text",
        placeholder: "title",
      },
    ],

    renderCanvas: (widget) => {
      // const theme = useTheme();
      // Pull down real-time data or look into configured dynamic input values
      // Falls back safely to placeholder evaluation variables if unpopulated
      return (
        <TitleWidget
          content={
            widget.titleWidget ||
            widget.gridTitle ||
            widget.tableTitle ||
            "Title"
          }
          // content={widget}
        />
      );
    },
  },
  image: {
    label: "Image",
    defaultWidth: 12,
    defaultHeight: 18,
    fields: [
      {
        id: "gridTitle",
        label: "Grid Title",
        type: "text",
        placeholder: "e.g. System Info",
      },

      {
        id: "images",
        label: "Images *",
        type: "presetDropdown",
        options: IMAGE_OPTIONS,
      },
      {
        id: "series",
        label: "Series",
        type: "switchBtn",
      },
      {
        id: "height",
        label: "Height",
        type: "text",
      },
      {
        id: "width",
        label: "Width",
        type: "text",
      },
      {
        id: "name",
        label: "Name",
        type: "excelDropdown",
      },
      {
        id: "admin",
        label: "Admin",
        type: "excelDropdown",
      },
      {
        id: "oprtation",
        label: "Operation",
        type: "excelDropdown",
      },
      {
        id: "description",
        label: "Description",
        type: "excelDropdown",
      },
    ],

    renderCanvas: (
      widget,
      handleInputValueChange,
      childIdx,
      handleSaveConfigurationWidget,
      dialogType,
      resourceId,
      liveData
    ) => {
      console.log(liveData, "in dfdfdf widgetwidget");
      // const theme = useTheme();
      return (
        <ImageWidget
          mapForDisplay={widget?.mapForDisplay}
          title={widget?.tableTitle}
          imgSrc={image[widget.image] || image["24SwithchChassis"]}
          width={widget.width}
          height={widget.height}
          resourceId={resourceId}
          tableId={widget.tableId}
          liveData={liveData}
        />
      );
    },
  },
  remoteDevice: {
    label: "Remote device",
    defaultWidth: 12,
    defaultHeight: 18,
    fields: [
      {
        id: "gridTitle",
        label: "Grid Title",
        type: "text",
        placeholder: "e.g. System Info",
      },
      {
        id: "showVehicleHeading",
        label: "Vehicle Heading:",
        type: "remoteDeviceSwitch",
      },
      {
        id: "remoteDevicesIsEditable",
        label: "Editable:",
        type: "remoteDeviceEditSwitch",
      },
    ],

    renderCanvas: (widget) => {
      console.log(widget, "remoteDevice");
      // const theme = useTheme();
      return (
        <RemoteDevice
          selectedOids={widget.data}
          title={widget.tableTitle}
          showVehicleHeading={widget?.showVehicleHeading}
          isEditable={widget?.isEditable}
        />
      );
    },
  },

  // Configuration Devices..

  editable: {
    label: "Editable Textfield Grid",
    defaultWidth: 36,
    defaultHeight: 14,
    borderColor: "#14348D",

    fields: [
      {
        id: "gridTitle",
        label: "Grid Component Title *",
        type: "text",
        placeholder: "e.g., Target Controller Inputs",
      },
      {
        id: "columns",
        label: "No of Grid Columns *",
        type: "text",
        placeholder: "e.g., 2",
      },
      {
        id: "commonLabel",
        label: "Common Label Suffix",
        type: "text",
        placeholder: "e.g., Unit Adjuster",
      },
      {
        id: "oidDynamicSection",
        type: "dynamicOidConfig",
      },
    ],

    renderCanvas: (
      widget,
      handleInputValueChange,
      widgetIdx,
      handleSaveConfigurationWidget,
      dialogType,
      dummy,
      liveData,
      saving,
      validationErrors,
      setValidationErrors
    ) => {
      const theme = useTheme();

      const selectedMetrics = widget.data || [];
      const hybridSections = widget.hybrid || [];
      const oidConfigs = widget.oidConfigs || {};
      const commonLabel = widget.commonLabel || "";

      const totalColumns = parseInt(widget.cols || widget.columns, 10) || 3;

      return (
        <Box
          sx={{
            height: "100%",
            width: "100%",
            display: "flex",
            flexDirection: "column",
            boxSizing: "border-box",
            backgroundColor: theme.palette.background.paper,
            overflow: "hidden",
          }}
        >
          {/* HEADER */}
          <Box
            sx={{
              px: 2,
              py: 1.5,
              borderBottom: "1px solid #e0e0e0",
              flexShrink: 0,
            }}
          >
            <Typography
              sx={{
                color: theme.palette.custom?.snmp?.inputtitle,
                fontSize: "14px",
                fontWeight: 600,
              }}
            >
              {widget.tableTitle || "Parameter Controls Grid"}
            </Typography>
          </Box>

          {/* CONTENT */}
          <Box
            sx={{
              flex: 1,
              overflowY: "auto",
              p: 2,
            }}
          >
            {/* =====================================================
                1. NUMBER / TEXT INPUTS
            ====================================================== */}
            {selectedMetrics.length > 0 && (
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: `repeat(${totalColumns}, minmax(0, 1fr))`,
                  gap: 2,
                  width: "100%",
                }}
              >
                {selectedMetrics.map((item, index) => {
                  const oidName = item.name || `OID_${item.oid}`;
                  const oidKey = item.oid || `idx_${index}`;

                  const config = oidConfigs[oidName] || {
                    type: "text",
                  };

                  const isNumberMode =
                    item.inpType === "number" || config.type === "number";

                  const minLimit =
                    item.min !== undefined && item.min !== ""
                      ? parseFloat(item.min)
                      : undefined;

                  const maxLimit =
                    item.max !== undefined && item.max !== ""
                      ? parseFloat(item.max)
                      : undefined;

                  // const stepValue =
                  //   item.step !== undefined && item.step !== ""
                  //     ? parseFloat(item.step)
                  //     : 1;
                  const stepValue =
                    item.step !== undefined && item.step !== ""
                      ? Number(item.step)
                      : undefined;
                  // const currentStoredValue = widget[`val_${oidKey}`];

                  // const finalInputValue =
                  //   currentStoredValue !== undefined &&
                  //   currentStoredValue !== null
                  //     ? currentStoredValue
                  //     : item.currentValue ?? "";
                  const finalInputValue = item.currentValue ?? "";
                  return (
                    <Box
                      key={oidKey}
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "4px",
                        width: "100%",
                      }}
                    >
                      <Typography
                        component="label"
                        sx={{
                          fontSize: "12px",
                          fontWeight: 600,
                          color: theme.palette.custom?.snmp?.inputtitle,
                        }}
                      >
                        {oidName}

                        {commonLabel ? ` [${commonLabel}]` : ""}
                      </Typography>

                      <Box
                        sx={{
                          display: "flex",
                          width: "100%",
                          alignItems: "stretch",
                        }}
                      >
                        {/* <MInput
  fullWidth
  type="text"
  placeholder={
    isNumberMode
      ? `Range: ${minLimit ?? "any"} - ${maxLimit ?? "any"}`
      : "Enter text..."
  }
  value={finalInputValue}
  inputProps={{
    min: minLimit,
    max: maxLimit,
    step: stepValue,
    inputMode: isNumberMode ? "decimal" : "text",
  }}
  error={Boolean(validationErrors?.[oidKey])}
  onKeyDown={(e) => {
    if (!isNumberMode) {
      return;
    }

    const allowedKeys = [
      "Backspace",
      "Delete",
      "Tab",
      "Escape",
      "Enter",
      "ArrowLeft",
      "ArrowRight",
      "ArrowUp",
      "ArrowDown",
      "Home",
      "End",
    ];

    if (allowedKeys.includes(e.key)) {
      return;
    }

    if (
      e.ctrlKey ||
      e.metaKey
    ) {
      return;
    }


    if (/[0-9]/.test(e.key)) {
      return;
    }

    if (
      e.key === "." &&
      stepValue !== undefined &&
      !Number.isInteger(Number(stepValue))
    ) {

      if (String(finalInputValue).includes(".")) {
        e.preventDefault();
      }

      return;
    }

    if (e.key === "-") {
      if (
        String(finalInputValue).length > 0 ||
        (minLimit !== undefined && minLimit >= 0)
      ) {
        e.preventDefault();
      }

      return;
    }

    e.preventDefault();
  }}
  onPaste={(e) => {
    if (!isNumberMode) {
      return;
    }

    const pastedText = e.clipboardData.getData("text");

    const regex = getNumberRegex(stepValue);

    if (!regex.test(pastedText)) {
      e.preventDefault();
      return;
    }

    const pastedNumber = Number(pastedText);

    if (Number.isNaN(pastedNumber)) {
      e.preventDefault();
      return;
    }

    if (
      minLimit !== undefined &&
      pastedNumber < minLimit
    ) {
      e.preventDefault();
      return;
    }

    if (
      maxLimit !== undefined &&
      pastedNumber > maxLimit
    ) {
      e.preventDefault();
      return;
    }
  }}
  onChange={(e) => {
    const updatedValue = e.target.value;


    if (isNumberMode) {
      const regex = getNumberRegex(stepValue);

      if (!regex.test(updatedValue)) {
        return;
      }
    }

    const error = validateFieldValue(
      updatedValue,
      item
    );

    setValidationErrors((prev) => ({
      ...prev,
      [oidKey]: error,
    }));

    handleInputValueChange(
      widgetIdx,
      oidKey,
      updatedValue
    );
  }}
  onBlur={(e) => {
    const value = e.target.value;

    const error = validateFieldValue(
      value,
      item
    );

    setValidationErrors((prev) => ({
      ...prev,
      [oidKey]: error,
    }));
  }}
/> */}
                        <MInput
                          fullWidth
                          type="text"
                          placeholder={
                            isNumberMode
                              ? `Range: ${minLimit ?? "any"} - ${
                                  maxLimit ?? "any"
                                }`
                              : "Enter text..."
                          }
                          value={finalInputValue}
                          inputProps={{
                            inputMode: isNumberMode ? "decimal" : "text",
                          }}
                          error={Boolean(validationErrors?.[oidKey])}
                          onChange={(e) => {
                            const updatedValue = e.target.value;

                            /*
                             * Only validate numeric format while typing.
                             */
                            if (isNumberMode) {
                              const regex = getNumberRegex(stepValue);

                              if (!regex.test(updatedValue)) {
                                return;
                              }
                            }

                            /*
                             * Full validation
                             */
                            const error = validateFieldValue(
                              updatedValue,
                              item
                            );

                            setValidationErrors((prev) => ({
                              ...prev,
                              [oidKey]: error,
                            }));

                            /*
                             * Keep local edited value
                             */
                            handleInputValueChange(
                              widgetIdx,
                              oidKey,
                              updatedValue
                            );
                          }}
                          onBlur={(e) => {
                            const value = e.target.value;

                            const error = validateFieldValue(value, item);

                            setValidationErrors((prev) => ({
                              ...prev,
                              [oidKey]: error,
                            }));
                          }}
                        />
                        {/* {validationErrors?.[oidKey] && (
                          <Typography
                            sx={{
                              color: "#d32f2f",
                              fontSize: "11px",
                              mt: 0.5,
                              lineHeight: 1.3,
                            }}
                          >
                            {validationErrors[oidKey]}
                          </Typography>
                        )} */}

                        {isNumberMode && (
                          <Box
                            sx={{
                              width: 30,
                              height: 40,
                              ml: 0.5,
                              mt: 0.5,
                              display: "flex",
                              flexDirection: "column",
                              justifyContent: "center",
                              alignItems: "center",
                              border: "1px solid #d0d7de",
                              borderRadius: "6px",
                            }}
                          >
                            <IconButton
                              size="small"
                              sx={{ p: 0 }}
                              disabled={
                                maxLimit !== undefined &&
                                Number(
                                  finalInputValue !== ""
                                    ? finalInputValue
                                    : minLimit ?? 0
                                ) +
                                  (stepValue ?? 1) >
                                  maxLimit
                              }
                              onClick={() => {
                                const currentValue =
                                  finalInputValue !== ""
                                    ? Number(finalInputValue)
                                    : minLimit ?? 0;

                                const step = stepValue ?? 1;

                                const next = currentValue + step;

                                if (
                                  maxLimit === undefined ||
                                  next <= maxLimit
                                ) {
                                  const nextValue = String(next);

                                  handleInputValueChange(
                                    widgetIdx,
                                    oidKey,
                                    nextValue
                                  );

                                  setValidationErrors((prev) => ({
                                    ...prev,
                                    [oidKey]: validateFieldValue(
                                      nextValue,
                                      item
                                    ),
                                  }));
                                }
                              }}
                            >
                              <KeyboardArrowUp fontSize="small" />
                            </IconButton>

                            <IconButton
                              size="small"
                              sx={{ p: 0 }}
                              disabled={
                                minLimit !== undefined &&
                                Number(
                                  finalInputValue !== ""
                                    ? finalInputValue
                                    : minLimit ?? 0
                                ) -
                                  (stepValue ?? 1) <
                                  minLimit
                              }
                              onClick={() => {
                                const currentValue =
                                  finalInputValue !== ""
                                    ? Number(finalInputValue)
                                    : minLimit ?? 0;

                                const step = stepValue ?? 1;

                                const next = currentValue - step;

                                if (
                                  minLimit === undefined ||
                                  next >= minLimit
                                ) {
                                  const nextValue = String(next);

                                  handleInputValueChange(
                                    widgetIdx,
                                    oidKey,
                                    nextValue
                                  );

                                  setValidationErrors((prev) => ({
                                    ...prev,
                                    [oidKey]: validateFieldValue(
                                      nextValue,
                                      item
                                    ),
                                  }));
                                }
                              }}
                            >
                              <KeyboardArrowDownOutlined fontSize="small" />
                            </IconButton>
                          </Box>
                        )}
                      </Box>
                      {validationErrors?.[oidKey] && (
                        <Typography
                          sx={{
                            color: "#d32f2f",
                            fontSize: "11px",
                            lineHeight: 1.1,
                          }}
                        >
                          {validationErrors[oidKey]}
                        </Typography>
                      )}
                    </Box>
                  );
                })}
              </Box>
            )}

            {hybridSections.map((hybridItem, hybridIdx) => {
              const hybridCols = parseInt(hybridItem.cols, 10) || totalColumns;

              const selectMap = hybridItem.selectWidgetMap || {};

              return (
                <Box
                  key={hybridIdx}
                  sx={{
                    mt: selectedMetrics.length ? 2 : 0,
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: `repeat(${hybridCols}, minmax(0, 1fr))`,
                      gap: "16px",
                      width: "100%",
                    }}
                  >
                    {hybridItem.data?.map((selectField, fieldIdx) => {
                      const rawOptions = selectMap[selectField.oid] || {};

                      const formattedOptions = Object.entries(rawOptions).map(
                        ([key, label]) => ({
                          label: String(label).trim(),
                          value: String(key).trim(),
                        })
                      );

                      const oidKey = selectField.oid || `hybrid_${fieldIdx}`;

                      const resolvedVal = String(
                        selectField.currentValue ?? ""
                      ).trim();

                      return (
                        <Box key={oidKey}>
                          <MAlarmSelect
                            label={selectField.name || selectField.displayName}
                            options={formattedOptions}
                            value={resolvedVal}
                            error={Boolean(validationErrors?.[oidKey])}
                            onChange={(val) => {
                              const selectedValue = String(val ?? "").trim();

                              const isValidOption = formattedOptions.some(
                                (option) =>
                                  String(option.value).trim() === selectedValue
                              );

                              const error = !selectedValue
                                ? "Please select a value"
                                : !isValidOption
                                ? "Invalid selection"
                                : "";

                              setValidationErrors((prev) => ({
                                ...prev,
                                [oidKey]: error,
                              }));

                              if (!error) {
                                handleInputValueChange(
                                  widgetIdx,
                                  oidKey,
                                  selectedValue
                                );
                              }
                            }}
                            multiple={false}
                          />

                          {validationErrors?.[oidKey] && (
                            <Typography
                              sx={{
                                color: "#d32f2f",
                                fontSize: "11px",
                                mt: 0.5,
                                lineHeight: 1.3,
                              }}
                            >
                              {validationErrors[oidKey]}
                            </Typography>
                          )}
                        </Box>
                      );
                    })}
                  </Box>
                </Box>
              );
            })}
          </Box>

          {/* =====================================================
              3. SAVE
          ====================================================== */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              p: 2,
              borderTop: "1px solid #e0e0e0",
              flexShrink: 0,
            }}
          >
            <Button
              disabled={saving}
              variant="contained"
              sx={{
                backgroundColor: "#14348D",
                textTransform: "none",
                borderRadius: "6px",
                px: 3,
              }}
              onClick={() => handleSaveConfigurationWidget(widget)}
            >
              {saving ? "Saving..." : "Save"}
            </Button>
          </Box>
        </Box>
      );
    },
  },
  editableSelect: {
    label: "Editable Select",
    defaultWidth: 36,
    defaultHeight: 25,
    borderColor: "#b3cbff",
    fields: [
      {
        id: "gridTitle",
        label: "Grid Title",
        type: "text",
        placeholder: "e.g. Controls Dropdown",
      },
      {
        id: "numColumns",
        label: "No of Columns",
        type: "text",
        placeholder: "e.g. 1, 2, or 3",
      },
    ],
    renderCanvas: (
      widget,
      handleInputValueChange,
      widgetIdx,
      handleSaveConfigurationWidget,
      dialogType,
      dummy,
      liveData,
      saving,
      validationErrors,
      setValidationErrors
    ) => {
      // GUARD: If this editableSelect is already nested inside an editable widget's hybrid array,
      // do not render it as a separate standalone block to avoid duplication.
      if (widget.isHybridChild) {
        return null;
      }

      return (
        <Box
          sx={{
            height: "100%",
            pt: 1,
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* Header */}
          <Box sx={{ backgroundColor: "#E4EBFF" }}>
            <Typography
              sx={{
                color: "#14348D",
                p: 1,
                fontSize: "14px",
                fontWeight: "bold",
                textAlign: "center",
              }}
            >
              {widget.tableTitle || widget.gridTitle || "Select Dropdown Group"}
            </Typography>
          </Box>

          {/* Main Content Area */}
          <Box
            sx={{
              position: "relative",
              flexGrow: 1,
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {/* Scrollable Grid */}
            <Box
              sx={{
                p: 2,
                overflowY: "auto",
                flexGrow: 1,
                display: "grid",
                gridTemplateColumns: `repeat(${
                  parseInt(widget.cols || widget.numColumns, 10) || 3
                }, minmax(0, 1fr))`,
                gap: "16px",
              }}
            >
              {widget.data?.map((inputItem, dataIdx) => {
                const rawOptionsMap =
                  widget.selectWidgetMap?.[inputItem.oid] || {};
                const formattedOptions = Object.entries(rawOptionsMap).map(
                  ([key, displayLabel]) => ({
                    label: String(displayLabel),
                    value: String(key),
                  })
                );

                const oidKey = inputItem.oid || `idx_${dataIdx}`;
                const resolvedValue = String(
                  inputItem.currentValue ?? ""
                ).trim();

                return (
                  <Box key={oidKey}>
                    <MAlarmSelect
                      label={inputItem.name || inputItem.displayName}
                      options={formattedOptions}
                      value={resolvedValue}
                      error={Boolean(validationErrors?.[oidKey])}
                      onChange={(val) => {
                        const selectedValue = String(val ?? "").trim();

                        /*
                         * Selected value MUST exist in the dropdown options.
                         */
                        const isValidOption = formattedOptions.some(
                          (option) =>
                            String(option.value).trim() === selectedValue
                        );

                        const error = !selectedValue
                          ? "Please select a value"
                          : !isValidOption
                          ? "Invalid selection"
                          : "";

                        setValidationErrors((prev) => ({
                          ...prev,
                          [oidKey]: error,
                        }));

                        if (!error) {
                          handleInputValueChange(
                            widgetIdx,
                            oidKey,
                            selectedValue
                          );
                        }
                      }}
                      multiple={false}
                    />

                    {validationErrors?.[oidKey] && (
                      <Typography
                        sx={{
                          color: "#d32f2f",
                          fontSize: "11px",
                          mt: 0.5,
                          lineHeight: 1.3,
                        }}
                      >
                        {validationErrors[oidKey]}
                      </Typography>
                    )}
                  </Box>
                );
              })}
            </Box>

            {/* Bottom Button Container */}
            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                p: 2,
                borderTop: "1px solid #e0e0e0",
              }}
            >
              <Button
                variant="contained"
                disabled={saving}
                sx={{
                  backgroundColor: "#14348D",
                  textTransform: "none",
                  borderRadius: "6px",
                  padding: "8px 24px",
                  fontSize: "13px",
                }}
                onClick={(e) => handleSaveConfigurationWidget(widget)}
              >
                {saving ? "Saving..." : "Save"}
              </Button>
            </Box>
          </Box>
        </Box>
      );
    },
  },

  circularDialGauge: {
    label: "Circular Dial Gauge",
    defaultWidth: 12,
    defaultHeight: 12,
    fields: [
      {
        id: "gridTitle",
        label: "Gauge Title *",
        type: "text",
        placeholder: "e.g., Engine Speed",
      },
      {
        id: "minVal",
        label: "Minimum Value *",
        type: "number",
        defaultValue: 0,
      },
      {
        id: "maxVal",
        label: "Maximum Value *",
        type: "number",
        defaultValue: 100,
      },
      {
        id: "unit",
        label: "Unit",
        type: "text",
        placeholder: "e.g., RPM, V, Hrs",
      },
    ],
    renderCanvas: (widget) => {
      return <CircularDialGauge widget={widget} innerRange={8} />;
    },
  },
};

export const AVAILABLE_WIDGETS = Object.keys(WIDGET_REGISTRY).map((key) => ({
  label: WIDGET_REGISTRY[key].label,
  value: key,
}));
