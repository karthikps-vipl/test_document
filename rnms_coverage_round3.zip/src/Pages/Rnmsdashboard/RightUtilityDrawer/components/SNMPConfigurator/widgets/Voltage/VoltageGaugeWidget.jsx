 
import { useTheme } from "@mui/material";
import React from "react";

export const VoltageGaugeWidget = ({
  tableTitle,
  targetDisplayName,
  stateValue,
  voltageValue,
  valueOid,
}) => {
  const numericVoltage = parseFloat(voltageValue);
  const displayVoltage = !isNaN(numericVoltage) ? numericVoltage : 0;

  // Speedometer mapping logic: 0V to 500V maps across 180 degrees (-90 to +90 deg)
  const maxVoltageRange = 500;
  const percentage = Math.min(Math.max(displayVoltage / maxVoltageRange, 0), 1);
  const needleRotationAngle = -90 + percentage * 180;
const theme=useTheme()
  return (
    <div
      style={{
        padding: "16px",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        boxSizing: "border-box",
        fontFamily: "sans-serif",
        backgroundColor: theme.palette.background.paper, 
        color: theme.palette.text.primary,
        //border:theme.palette.custom.snmp.border
        // backgroundColor: "#ffffff",
      }}
    >
      <div style={{ textAlign: "center", width: "100%" }}>
        <h4
          style={{
            margin: "0 0 4px 0",
            color: theme.palette.custom.snmp.snmmptitle,
            fontSize: "14px",
            fontWeight: "600",
          }}
        >
          {tableTitle}
        </h4>
        <span style={{ fontSize: "11px", color: theme.palette.custom.snmp.inputtitle,}}>
          Tag: {targetDisplayName}
        </span>
      </div>

      {/* Expanded Speedometer Container (Height & Width scaled up) */}
      <div
        style={{
          position: "relative",
          width: "220px",
          height: "150px",
          display: "flex",
          justifyContent: "center",
        }}
      >
        <svg width="220" height="150" viewBox="0 0 220 150">
          {/* ZONE 1: GREEN ARC (Normal Operating Zone: 0V - 250V) - Thickness increased to 22 */}
          <path
            d="M 25 120 A 85 85 0 0 1 110 35"
            fill="none"
            stroke="#22c55e"
            strokeWidth="22"
          />

          {/* ZONE 2: YELLOW ARC (Cautionary Boundary: 250V - 350V) - Thickness increased to 22 */}
          <path
            d="M 110 35 A 85 85 0 0 1 155.3 51.5"
            fill="none"
            stroke="#eab308"
            strokeWidth="22"
          />

          {/* ZONE 3: ORANGE ARC (Elevated Hazard State: 350V - 430V) - Thickness increased to 22 */}
          <path
            d="M 155.3 51.5 A 85 85 0 0 1 184.9 77.5"
            fill="none"
            stroke="#f97316"
            strokeWidth="22"
          />

          {/* ZONE 4: RED ARC (Danger / Critical Boundary: 430V - 500V) - Thickness increased to 22 */}
          <path
            d="M 184.9 77.5 A 85 85 0 0 1 195 120"
            fill="none"
            stroke="#ef4444"
            strokeWidth="22"
          />

          {/* INNER WHITE HIGHLIGHT BOUNDARY SEPARATOR PIPELINE */}
          <path
            d="M 35 120 A 74 74 0 0 1 185 120"
            fill="none"
            stroke="#ffffff"
            strokeWidth="2"
          />

          {/* VOLTAGE BOUNDARY REFERENCE LABELS */}
          <text
            x="14"
            y="132"
            fill="#64748b"
            fontSize="10"
            fontWeight="700"
            textAnchor="middle"
          >
            0V
          </text>
          <text
            x="110"
            y="22"
            fill="#64748b"
            fontSize="10"
            fontWeight="700"
            textAnchor="middle"
          >
            250V
          </text>
          <text
            x="206"
            y="132"
            fill="#64748b"
            fontSize="10"
            fontWeight="700"
            textAnchor="middle"
          >
            500V
          </text>

          {/* NEEDLE CENTER CAP ANCHOR BASE */}
          <circle cx="110" cy="120" r="12" fill="#1e293b" />
          <circle cx="110" cy="120" r="5" fill="#94a3b8" />

          {/* RESPONSIVE INSTRUMENT DIAL NEEDLE */}
          <line
            x1="110"
            y1="120"
            x2="110"
            y2="42"
            stroke="#0f172a"
            strokeWidth="4"
            strokeLinecap="round"
            transform={`rotate(${needleRotationAngle} 110 120)`}
            style={{
              transition: "transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)",
            }}
          />
          {/* High-visibility center accent needle marker split */}
          <line
            x1="110"
            y1="65"
            x2="110"
            y2="44"
            stroke="#ef4444"
            strokeWidth="1.5"
            strokeLinecap="round"
            transform={`rotate(${needleRotationAngle} 110 120)`}
            style={{
              transition: "transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)",
            }}
          />
        </svg>

        {/* Shifter Layer: Moved directly below the center anchor pin to stop overwriting */}
        <div
          style={{
            position: "absolute",
            top: "124px",
            textAlign: "center",
            width: "100%",
          }}
        >
          <span
            style={{
              fontSize: "24px",
              fontWeight: "800",
              color:  theme.palette.custom.snmp.snmmptitle,
              letterSpacing: "-0.5px",
            }}
          >
            {displayVoltage}
            <span
              style={{
                fontSize: "15px",
                fontWeight: "600",
                marginLeft: "2px",
                color:  theme.palette.custom.snmp.snmmptitle,
              }}
            >
              V
            </span>
          </span>
        </div>
      </div>

      {/* System Parameter Mode Condition Pill */}
      <div style={{ textAlign: "center", marginTop: "16px" }}>
        <div
          style={{
            padding: "4px 18px",
            borderRadius: "20px",
            fontSize: "11px",
            fontWeight: "700",
            //color: "#ffffff",
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            backgroundColor:
              displayVoltage >= 430
                ? "#ef4444"
                : displayVoltage >= 350
                ? "#f97316"
                : displayVoltage >= 250
                ? "#eab308"
                : displayVoltage >= 50
                ? "#22c55e"
                : "#64748b",
          }}
        >
          {stateValue}
        </div>
        {/* <div
          style={{
            fontSize: "10px",
            color: "#94a3b8",
            marginTop: "6px",
            fontWeight: "500",
          }}
        >
          Ref OID: {valueOid || "Unmapped"}
        </div> */}
      </div>
    </div>
  );
};

// rpm , v,hrs