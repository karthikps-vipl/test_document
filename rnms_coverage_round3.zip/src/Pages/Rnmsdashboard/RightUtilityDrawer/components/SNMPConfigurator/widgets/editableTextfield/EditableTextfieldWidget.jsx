import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
} from "@mui/material";

import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const EditableTextfieldWidget = ({ tableTitle, fields = [], onSave }) => {
  const [values, setValues] = useState({});

  useEffect(() => {
    const initial = {};

    fields.forEach((item) => {
      initial[item.oid] = item.currentValue || "";
    });

    setValues(initial);
  }, [fields]);

  const updateValue = (oid, value) => {
    setValues((prev) => ({
      ...prev,
      [oid]: value,
    }));
  };

  const handleStepper = (field, operation) => {
    const min = Number(field.min ?? 0);
    const max = Number(field.max ?? 999999);
    const step = Number(field.step ?? 1);

    let current = Number(values[field.oid] || 0);

    if (operation === "inc") {
      current += step;
    } else {
      current -= step;
    }

    if (current < min) current = min;
    if (current > max) current = max;

    updateValue(field.oid, current.toString());
  };

  const handleSave = () => {
    const payload = fields.map((item) => ({
      oid: item.oid,
      value: values[item.oid] ?? "",
    }));

    if (onSave) {
      onSave(payload);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        height: "100%",
        p: 2,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Typography
        sx={{
          fontWeight: 700,
          color: "#14348D",
          mb: 2,
          textAlign: "center",
        }}
      >
        {tableTitle}
      </Typography>

      <Box
        sx={{
          flex: 1,
          display: "grid",
          gridTemplateColumns: "repeat(2,1fr)",
          gap: 2,
          overflow: "auto",
        }}
      >
        {fields.map((field) => (
          <Box key={field.oid}>
            <Typography
              sx={{
                fontSize: 13,
                mb: 0.5,
                fontWeight: 600,
              }}
            >
              {field.name}
            </Typography>

            {field.inpType === "text" && (
              <MInput
                fullWidth
                value={values[field.oid] || ""}
                onChange={(e) => updateValue(field.oid, e.target.value)}
              />
            )}

            {field.inpType === "number" && (
              <>
                {!field.useStepper ? (
                  <MInput
                    fullWidth
                    type="number"
                    inputProps={{
                      min: field.min,
                      max: field.max,
                    }}
                    value={values[field.oid] || ""}
                    onChange={(e) => {
                      const val = Number(e.target.value);

                      if (
                        e.target.value === "" ||
                        (val >= Number(field.min) && val <= Number(field.max))
                      ) {
                        updateValue(field.oid, e.target.value);
                      }
                    }}
                  />
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <Button
                      variant="outlined"
                      onClick={() => handleStepper(field, "dec")}
                    >
                      -
                    </Button>

                    <MInput
                      value={values[field.oid] || ""}
                      onChange={(e) => updateValue(field.oid, e.target.value)}
                    />

                    <Button
                      variant="outlined"
                      onClick={() => handleStepper(field, "inc")}
                    >
                      +
                    </Button>
                  </Box>
                )}

                <Typography
                  sx={{
                    fontSize: 11,
                    color: "#777",
                    mt: 0.5,
                  }}
                >
                  Min : {field.min} &nbsp;&nbsp; Max : {field.max}
                </Typography>
              </>
            )}
          </Box>
        ))}
      </Box>

      <Box
        sx={{
          mt: 2,
          display: "flex",
          justifyContent: "flex-end",
        }}
      >
        <MButtonPrimary onClick={handleSave}>Save</MButtonPrimary>
      </Box>
    </Paper>
  );
};

export default EditableTextfieldWidget;
