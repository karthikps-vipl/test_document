import { useTheme } from "@mui/material";
import React from "react";

export default function GaugeWidget({
  tableTitle,
  metricsData = [], // Safely maps your selected OID arrays
  rangePreset,
  customRangeX,
}) {
  console.log(customRangeX, "metricsDatametricsData");

  // Ensure we fallback safely if tableTitle isn't entered
  // const componentTitle = tableTitle || "Live Metrics Gauge Panel";

  const theme = useTheme();
  return (
    <div
      style={{
        // padding: "20px",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        boxSizing: "border-box",
        // fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
        // backgroundColor: "transparent",
        backgroundColor: theme.palette.background.paper,
      }}
    >
      {/* 1. Component Section Header */}
      {/* <div
        style={{
          textAlign: "left",
          width: "100%",
          marginBottom: "20px",
          borderBottom: "1px solid #e2e8f0",
          paddingBottom: "10px",

        }}
      >
        <h4
          style={{
            margin: "0",
            color: "#0f172a",
            fontSize: "16px",
            fontWeight: "700",
            letterSpacing: "-0.025em",
          }}
        >
          {componentTitle}
        </h4>
      </div> */}

      {/* 2. Responsive Flex Grid Container (Aligns 5 OIDs Side-by-Side) */}
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          flexWrap: "wrap",
          gap: "16px",
          justifyContent: "center", // Left-aligned sequence
          alignItems: "center", // Equal card heights
          width: "100%",
        }}
      >
        {/* Fallback View if no OIDs are selected yet */}
        {metricsData.length === 0 && (
          <div
            style={{
              padding: "30px",
              color: "#64748b",
              fontSize: "13px",
              fontStyle: "italic",
              textAlign: "center",
              width: "100%",
            }}
          >
            No OIDs configured. Please select target metrics in the
            configuration settings.
          </div>
        )}

        {/* Dynamic Data Array Mapping */}
        {metricsData.map((metricItem, index) => {
          console.log("metricItemmetricItem", metricItem)
          // Parse dynamic streaming value safely
          const rawNum = parseFloat(metricItem.currentValue);
          const liveValue = !isNaN(rawNum) ? rawNum : 0;
          const labelSource =
             metricItem.name || metricItem.displayName || `Metric ${index + 1}`;
          // const namePrefix = labelSource.slice(0, 3).toUpperCase();
          // Compute Bounds Based on your Registry dropdown choice
          let minBound = 0;
          let maxBound = 90;

          if (rangePreset === "0-180") {
            maxBound = 180;
          } else if (rangePreset === "0-90") {
            maxBound = 90;
          } else if (rangePreset === "dynamic") {
            const boundaryX = Math.abs(parseFloat(customRangeX)) || 150;

            minBound = -boundaryX;
            maxBound = boundaryX;
          }

          // Prevent Division by Zero ($NaN$ Shield)
          const rangeSpan = maxBound - minBound || 1;

          // Compute Tick Step Intervals
          let stepSize = 10;
          if (rangePreset === "0-180") {
            stepSize = 20;
          } else if (rangePreset === "dynamic") {
            stepSize = Math.ceil(rangeSpan / 10);
          } else if (rangePreset === "0-90") {
            stepSize = 10;
          }

          // Anti-Hang Safeguard for Loops
          if (stepSize <= 0 || isNaN(stepSize)) {
            stepSize = 10;
          }

          const ticks = [];
          for (let v = minBound; v <= maxBound; v += stepSize) {
            ticks.push(v);
          }
          if (ticks.length === 0 || ticks[ticks.length - 1] !== maxBound) {
            ticks.push(maxBound);
          }

          // Clamp reading to maximum arc radius boundaries
          const clampedValue = Math.min(
            Math.max(liveValue, minBound),
            maxBound
          );
          const percentage = (clampedValue - minBound) / rangeSpan;

          // Calculate dial orientation degrees (-90deg is flat left, +90deg is flat right)
          const needleAngle = -90 + percentage * 180;

          // SVG Viewport Dimensions
          const svgW = 240;
          const svgH = 140;
          const cx = svgW / 2;
          const cy = svgH - 15;

          return (
            <div
              key={metricItem.oid || index}
              style={{
                // backgroundColor: "#ffffff",
                // border: "1px solid #e2e8f0",
                borderRadius: "12px",
                padding: "14px",
                // flex: "1 1 calc(20% - 13px)", // Perfect formula for even 5-column cross distribution
                width: "100%",
                minWidth: "200px", // Prevents extreme clipping on smaller viewports
                maxWidth: "350px", // Retains elegant layout proportions
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                // boxShadow:
                //   "0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05)",
                boxSizing: "border-box",
              }}
            >
              {/* OID Meta Metadata Display Labels */}
              <span
                style={{
                  fontSize: "12px",
                  color: "#334155",
                  fontWeight: "700",
                  textAlign: "center",
                  display: "block",
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  width: "100%",
                }}
                title={metricItem.name || `Metric ${index + 1}`}
              >
                {metricItem.name || `Metric ${index + 1}`}
              </span>

              <svg
                width="100%"
                height="180"
                viewBox={`0 0 ${svgW} ${svgH}`}
                style={{ overflow: "visible" }}
              >
                {/* Outer Base Track Arc */}
                <path
                  d={`M ${cx - 90} ${cy} A 90 90 0 0 1 ${cx + 90} ${cy}`}
                  fill="none"
                  stroke="#f1f5f9"
                  strokeWidth="10"
                  strokeLinecap="round"
                />

                {/* Active Colored Fill Accent Arc */}
                <path
                  d={`M ${cx - 90} ${cy} A 90 90 0 0 1 ${cx + 90} ${cy}`}
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="6"
                  strokeDasharray={`${percentage * 282.7} 282.7`}
                  strokeLinecap="round"
                  opacity="0.85"
                />

                {/* Inner Reference Guide Ring */}
                <path
                  d={`M ${cx - 74} ${cy} A 74 74 0 0 1 ${cx + 74} ${cy}`}
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="1"
                  strokeDasharray="4,4"
                />

                {/* Ticks & Metric Number Mapping Markers */}
                {ticks.map((tickVal, tIdx) => {
                  const fraction = tIdx / (ticks.length - 1 || 1);
                  const angleDeg = -90 + fraction * 180;
                  const angleRad = (angleDeg * Math.PI) / 180;

                  const xOuter = cx + Math.sin(angleRad) * 85;
                  const yOuter = cy - Math.cos(angleRad) * 85;
                  const xInner = cx + Math.sin(angleRad) * 78;
                  const yInner = cy - Math.cos(angleRad) * 78;

                  const xText = cx + Math.sin(angleRad) * 62;
                  const yText = cy - Math.cos(angleRad) * 62;

                  return (
                    <g key={tIdx}>
                      <line
                        x1={xOuter}
                        y1={yOuter}
                        x2={xInner}
                        y2={yInner}
                        stroke="#64748b"
                        strokeWidth="1.5"
                      />
                      <text
                        x={xText}
                        y={yText}
                        textAnchor="middle"
                        dominantBaseline="central"
                        fill="#475569"
                        fontSize="9"
                        fontWeight="600"
                      >
                        {Math.round(tickVal)}
                      </text>
                    </g>
                  );
                })}

                {/* Center Core Cap Node */}
                <circle cx={cx} cy={cy} r="12" fill="#1e293b" />
                <circle cx={cx} cy={cy} r="5" fill="#94a3b8" />

                {/* Dynamic Rotation Core Needle */}
                <g transform={`rotate(${needleAngle}, ${cx}, ${cy})`}>
                  <polygon
                    points={`${cx - 2.5},${cy} ${cx + 2.5},${cy} ${cx},${
                      cy - 94
                    }`}
                    fill="#ef4444"
                  />
                  <circle cx={cx} cy={cy} r="4" fill="#ef4444" />
                </g>
              </svg>

              {/* Digital Readout Matrix HUD */}
              <div
                style={{
                  // backgroundColor: "#0f172a",
                  padding: "4px 12px",
                  borderRadius: "6px",
                  marginTop: "6px",
                  width: "77%",
                  textAlign: "center",
                  border: "1px solid #334155",
                }}
              >
                <span
                  style={{
                    fontSize: "14px",
                    fontWeight: "700",
                    color: "#10b981",
                    fontFamily: "ui-monospace, SFMono-Regular, monospace",
                  }}
                >
                  {labelSource} = {liveValue.toFixed(2)}°
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
