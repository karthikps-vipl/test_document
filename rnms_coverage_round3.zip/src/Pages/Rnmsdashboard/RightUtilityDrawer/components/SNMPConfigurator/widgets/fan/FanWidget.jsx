import { useTheme } from "@mui/material";

export default function FanWidget({
  tableTitle,
  targetName,
  stateValue,
  stateOid,
}) {
  // Determine active running status safely from the assigned state OID cell values
  const isActive =
    stateValue !== undefined &&
    stateValue !== "0" &&
    String(stateValue).toLowerCase() !== "off" &&
    String(stateValue).toLowerCase() !== "fault";

  const activeLabelString = isActive ? "ON / VENTILATING" : "STANDBY / OFF";
  const statusColor = isActive ? "#10B981" : "#64748B";
const theme=useTheme()
  return (
    <div
      style={{
        padding: "20px",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        boxSizing: "border-box",
        fontFamily: "system-ui, -apple-system, sans-serif",
      }}
    >
      <style>{`
        @keyframes exhaust-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>

      {/* Heading */}
      <div
        style={{
          textAlign: "left",
          width: "100%",
          marginBottom: "20px",
          borderBottom: "1px solid #f1f5f9",
          paddingBottom: "10px",
        }}
      >
        <h4
          style={{
            margin: "0",
            color: theme.palette.custom.snmp.snmmptitle,
            fontSize: "16px",
            fontWeight: "700",
          }}
        >
          {tableTitle}
        </h4>
      </div>

      {/* Centered Single Fan Core */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          flex: 1,
          width: "100%",
        }}
      >
        <div
          style={{
            // backgroundColor: "#f1f5f9",
            border: "1px solid #cbd5e1",
            borderRadius: "14px",
            padding: "24px",
            width: "220px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            boxShadow:
              "inset 0 1px 2px rgba(255,255,255,0.8), 0 4px 6px -1px rgba(0,0,0,0.05)",
            boxSizing: "border-box",
          }}
        >
          {/* Label Header */}
          <div
            style={{ textAlign: "center", width: "100%", marginBottom: "14px" }}
          >
            <span
              style={{
                fontSize: "13px",
                color: theme.palette.custom.snmp.snmmptitle,
                fontWeight: "700",
                display: "block",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                overflow: "hidden",
              }}
            >
              {targetName || "Unassigned Fan Unit"}
            </span>
            {/* <span
              style={{
                fontSize: "10px",
                color: "#64748B",
                fontFamily: "monospace",
                display: "block",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                overflow: "hidden",
              }}
            >
              State Ref: {stateOid || "Unmapped"}
            </span> */}
          </div>

          {/* SVG Exit Fan */}
          <svg
            width="120"
            height="120"
            viewBox="0 0 100 100"
            style={{ overflow: "visible" }}
          >
            {/* Housing Frame */}
            <rect
              x="2"
              y="2"
              width="96"
              height="96"
              rx="6"
              fill="#E2E8F0"
              stroke="#94A3B8"
              strokeWidth="2.5"
            />
            <circle cx="9" cy="9" r="2.5" fill="#94A3B8" />
            <circle cx="91" cy="9" r="2.5" fill="#94A3B8" />
            <circle cx="9" cy="91" r="2.5" fill="#94A3B8" />
            <circle cx="91" cy="91" r="2.5" fill="#94A3B8" />
            <circle
              cx="50"
              cy="50"
              r="41"
              fill="#0F172A"
              stroke="#64748B"
              strokeWidth="1.5"
            />

            {/* Clean 3-Blade Rotatable Assembly */}
            <g
              style={{
                transformOrigin: "50px 50px",
                animation: isActive
                  ? "exhaust-spin 0.8s linear infinite"
                  : "none",
                transition: "transform 1s ease-out",
              }}
            >
              {/* Center Hub */}
              <circle
                cx="50"
                cy="50"
                r="10"
                fill="#475569"
                stroke="#1E293B"
                strokeWidth="1"
              />

              {/* Blade 1 (Top / 0 degrees) */}
              <path
                d="M46 50 C44 22, 56 22, 54 50 Z"
                fill="#CBD5E1"
                stroke="#1E293B"
                strokeWidth="0.75"
              />

              {/* Blade 2 (Bottom Right / 120 degrees) */}
              <g transform="rotate(120 50 50)">
                <path
                  d="M46 50 C44 22, 56 22, 54 50 Z"
                  fill="#CBD5E1"
                  stroke="#1E293B"
                  strokeWidth="0.75"
                />
              </g>

              {/* Blade 3 (Bottom Left / 240 degrees) */}
              <g transform="rotate(240 50 50)">
                <path
                  d="M46 50 C44 22, 56 22, 54 50 Z"
                  fill="#CBD5E1"
                  stroke="#1E293B"
                  strokeWidth="0.75"
                />
              </g>

              {/* Center Cap pin */}
              <circle cx="50" cy="50" r="4" fill="#94A3B8" />
            </g>
          </svg>

          {/* Badge Status Row */}
          <div style={{ marginTop: "16px" }}>
            <div
              style={{
                backgroundColor: isActive ? "#DCFCE7" : "#E2E8F0",
                padding: "4px 12px",
                borderRadius: "6px",
                border: `1px solid ${isActive ? "#BBF7D0" : "#CBD5E1"}`,
              }}
            >
              <span
                style={{
                  fontSize: "10px",
                  fontFamily: "monospace",
                  fontWeight: "800",
                  color: statusColor,
                  letterSpacing: "0.5px",
                }}
              >
                {activeLabelString}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
