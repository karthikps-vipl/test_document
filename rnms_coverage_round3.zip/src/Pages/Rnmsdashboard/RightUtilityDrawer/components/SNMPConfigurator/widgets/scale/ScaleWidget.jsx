import React from "react";
export const ScaleWidget = ({
  tableTitle,
  minBound,
  maxBound,
  currentStreamValue,
}) => {
  console.log(minBound, maxBound, currentStreamValue, "lklkj");

  const min = !isNaN(parseFloat(minBound)) ? parseFloat(minBound) : 0;
  const max = !isNaN(parseFloat(maxBound)) ? parseFloat(maxBound) : 100;

  // Real-time value fallbacks safely to midpoint if empty
  const rawValue = !isNaN(parseFloat(currentStreamValue))
    ? parseFloat(currentStreamValue)
    : (min + max) / 2;
  const clampedValue = Math.min(Math.max(rawValue, min), max);

  const range = max - min;
  let tickInterval = 10;

  if (range <= 10) tickInterval = 1;
  else if (range <= 25) tickInterval = 5;
  else if (range <= 60) tickInterval = 10;
  else if (range <= 150) tickInterval = 20;
  else tickInterval = 50;

  const ticks = [];
  let currentTick = Math.ceil(min / tickInterval) * tickInterval;
  if (currentTick < min) currentTick += tickInterval;

  while (currentTick <= max) {
    ticks.push(currentTick);
    currentTick += tickInterval;
  }

  const fillPercentage = range > 0 ? ((clampedValue - min) / range) * 100 : 0;

  // Precision tracking frame coordinates for sleek vertical thermometer-style layout
  const scaleTopY = 15;
  const scaleBottomY = 135;
  const scaleHeight = scaleBottomY - scaleTopY;
  const fillHeight = (fillPercentage / 100) * scaleHeight;
  const fillTopY = scaleBottomY - fillHeight;

  return (
    <div
      style={{
        padding: "16px",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        boxSizing: "border-box",
        fontFamily: "sans-serif",
        backgroundColor: "#ffffff",
      }}
    >
      {/* Title Header Block */}
      <div style={{ textAlign: "center", width: "100%" }}>
        <h4
          style={{
            margin: "0 0 2px 0",
            color: "#14348D",
            fontSize: "14px",
            fontWeight: "600",
          }}
        >
          {tableTitle}
        </h4>
        <span style={{ fontSize: "11px", color: "#64748b" }}>
          Range Scale: {min} to {max}
        </span>
      </div>

      {/* Vertical Gauge Board Framework */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          width: "100%",
          height: "160px",
        }}
      >
        <svg
          width="200"
          height="160"
          viewBox="0 0 200 160"
          style={{ overflow: "visible" }}
        >
          <defs>
            {/* Glossy Glass Tube Layer Shading */}
            <linearGradient
              id="capillaryGlass"
              x1="0%"
              y1="0%"
              x2="100%"
              y2="0%"
            >
              <stop offset="0%" stopColor="#94a3b8" stopOpacity="0.6" />
              <stop offset="25%" stopColor="#f8fafc" stopOpacity="0.2" />
              <stop offset="50%" stopColor="#ffffff" stopOpacity="0.7" />
              <stop offset="85%" stopColor="#cbd5e1" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#475569" stopOpacity="0.8" />
            </linearGradient>

            {/* High-visibility Precision Indicator Mercury/Fluorescent Red Liquid */}
            <linearGradient id="mercuryFluid" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#dc2626" />
              <stop offset="40%" stopColor="#ef4444" />
              <stop offset="70%" stopColor="#f87171" />
              <stop offset="100%" stopColor="#b91c1c" />
            </linearGradient>
          </defs>

          {/* BACKPLATE: Industrial metal instrument scale plate background */}
          <rect
            x="35"
            y={scaleTopY - 5}
            width="130"
            height={scaleHeight + 14}
            fill="#f1f5f9"
            stroke="#cbd5e1"
            strokeWidth="1.5"
            rx="4"
          />

          {/* BACKGROUND TUBE SLOT: Dark groove channel behind fluid for contrast */}
          <rect
            x="95"
            y={scaleTopY}
            width="10"
            height={scaleHeight}
            fill="#e2e8f0"
            rx="1"
          />

          {/* DYNAMIC METRIC FLUID FILL */}
          {fillHeight > 0 && (
            <rect
              x="95"
              y={fillTopY}
              width="10"
              height={fillHeight}
              fill="url(#mercuryFluid)"
              rx="1"
              style={{ transition: "all 0.5s cubic-bezier(0.4, 0, 0.2, 1)" }}
            />
          )}

          {/* GLASS FOREGROUND CAPILLARY: Glass shell layered directly on top */}
          <rect
            x="94"
            y={scaleTopY - 2}
            width="12"
            height={scaleHeight + 4}
            fill="url(#capillaryGlass)"
            stroke="#64748b"
            strokeWidth="0.8"
            rx="2"
          />

          {/* PRECISION GRADUATION TICK MARKS & METRIC VALUES */}
          {ticks.map((tickVal) => {
            const tickPercent = range > 0 ? (tickVal - min) / range : 0;
            const tickY = scaleBottomY - tickPercent * scaleHeight;

            return (
              <g key={tickVal}>
                {/* Right side tick marker lines */}
                <line
                  x1="110"
                  y1={tickY}
                  x2="122"
                  y2={tickY}
                  stroke="#334155"
                  strokeWidth="1.5"
                />

                {/* Left side secondary tracking line mirrors */}
                <line
                  x1="78"
                  y1={tickY}
                  x2="90"
                  y2={tickY}
                  stroke="#334155"
                  strokeWidth="1.5"
                />

                {/* Sub-division technical micro ticks */}
                <line
                  x1="110"
                  y1={tickY - scaleHeight / ticks.length / 2}
                  x2="116"
                  y2={tickY - scaleHeight / ticks.length / 2}
                  stroke="#94a3b8"
                  strokeWidth="1"
                />

                {/* Technical dynamic scale numeric characters */}
                <text
                  x="129"
                  y={tickY + 3.5}
                  fill="#1e293b"
                  fontSize="11"
                  fontWeight="700"
                  fontFamily="monospace, sans-serif"
                >
                  {String(tickVal).padStart(2, "0")}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Floating Value Output Panel */}
      <div style={{ textAlign: "center", width: "100%", marginTop: "4px" }}>
        <div
          style={{
            display: "inline-block",
            padding: "3px 14px",
            backgroundColor: "#fef2f2",
            borderRadius: "4px",
            border: "1px solid #fee2e2",
          }}
        >
          <span
            style={{
              fontSize: "20px",
              fontWeight: "800",
              color: "#dc2626",
              fontFamily: "monospace",
            }}
          >
            {clampedValue.toFixed(1)}
          </span>
        </div>
        <span
          style={{
            fontSize: "11px",
            color: "#64748b",
            display: "block",
            marginTop: "4px",
            fontWeight: "500",
          }}
        >
          Current Scale Reading
        </span>
      </div>
    </div>
  );
};
