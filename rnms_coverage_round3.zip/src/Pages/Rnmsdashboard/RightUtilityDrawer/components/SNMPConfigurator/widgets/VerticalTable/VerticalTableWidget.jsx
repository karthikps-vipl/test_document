import MTable from "@/components/Reusable/Table/MTable";
import { useTheme } from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";

const VerticalTableWidget = ({
  tableTitle,
  rawApiResponse,
  widget,
  tableId,
  dynamicColumns
}) => {
  // const [isMaximized, setIsMaximized] = useState(false);

  // const toggleMaximize = () => setIsMaximized((prev) => !prev);

  // const [columns, setColumns] = useState([]);
  const [tableData, setTableData] = useState([]);

  const fillTable = useCallback(() => {
    if (!rawApiResponse?.data || !rawApiResponse?.table) return;

    // 1. Build dynamic columns list from the 'data' array
    // Adding S.No as the first column automatically
   

    // 2. Build the concatenated table key dynamically using OIDs from 'data' array
    // Creates string like: ".1.3.6.1.2.1.2.2.1.2_.1.3.6.1.2.1.2.2.1.3_..._"
    const dynamicTableKey = tableId

    // 3. Extract matching array from table object
    const rawRows = rawApiResponse.table[dynamicTableKey] || [];

    // 4. Map rows dynamically using the OID keys directly
    const rowData = rawRows.map((row, index) => {
      const mappedRow = {
        id: index + 1,
        sno: index + 1,
      };

      // Populate each column field based on its OID key
      rawApiResponse.data.forEach((item) => {
        mappedRow[item.oid] = row[item.oid] || "NA";
      });

      return mappedRow;
    });

    // setColumns(dynamicColumns);
    setTableData(rowData);
  }, [rawApiResponse]);

  useEffect(() => {
    fillTable();
  }, [fillTable]);
  const theme = useTheme();
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        
        overflowX: "auto", // Enables horizontal scrolling for dynamic headers
        overflowY: "auto",
        boxSizing: "border-box",
        backgroundColor: theme.palette.background.paper, 
        color: theme.palette.text.primary,
        // border:theme.palette.custom.snmp.border
      }}
    >
      <MTable
        columns={dynamicColumns}
        tableData={tableData}
        tableTitle={tableTitle}
        showPagination={true} // Only 1 structured row data summary layout line
        showSearch={true}
        VisibleContent={null}
        showVisibleContent={true}
        enableColumnSearch={true}
        // showMaximazed={true}
        // isMaximized={isMaximized}
        // toggleMaximize={toggleMaximize}
        showSelect={false}
        // onRowClick={onRowSelectClick}
        // handleDownloadPDF={() =>
        //   alert(`Exporting localized matrix data report for: ${tableTitle}`)
        // }
        typeHeight="configuration"
      />
    </div>
  );
};

export default VerticalTableWidget;
