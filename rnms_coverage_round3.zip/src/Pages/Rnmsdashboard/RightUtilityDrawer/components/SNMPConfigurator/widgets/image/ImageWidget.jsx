// import { Box, useTheme } from "@mui/material";
// import React from "react";
// import { usePortStatusPolling } from "./usePortStatusPolling";

// import "./chasis.css";
// import Port from "./Port";

// const layoutConfig = {
//   portWidth: "40px", // Width of each port container in the grid
//   portGap: "20px", // Gap between grid items
// };

// const ImageWidget = ({
//   title,
//   imgSrc,
//   width,
//   height,
//   mapForDisplay,
//   resourceId,
//   tableId,
//   liveData,
// }) => {
//   const liveStatuses = usePortStatusPolling(
//     resourceId,
//     mapForDisplay,
//     tableId,
//     liveData
//   );
// const theme=useTheme()
//   // 2. Extract actual port names from API-normalized data
//   const portNames = Object.keys(liveStatuses);

//   const oddPorts = portNames.filter((_, index) => index % 2 === 0);
//   const evenPorts = portNames.filter((_, index) => index % 2 === 1);

//   const finalPorts = [...oddPorts, ...evenPorts];

//   console.log(liveStatuses, "finalPorts");

//   const portsPerRow1 = Math.ceil(portNames.length / 2);

//   const gridStyle = {
//     "--ports-per-row": portsPerRow1,
//     "--port-width": layoutConfig.portWidth,
//     "--port-gap": layoutConfig.portGap,
//     "--container-width": `calc(
//         (${layoutConfig.portWidth} * ${portsPerRow1}) +
//         (${layoutConfig.portGap} * ${portsPerRow1 - 1}) +
//         40px
//       )`,
//   };

//   const LinkLegends = [
//     {
//       label: "Up",
//       color: "#08fd72",
//     },
//     {
//       label: "Down",
//       color: "#ef4747",
//     },
//     {
//       label: "Operational down",
//       color: "#fbc02d",
//     },
//     {
//       label: "Unknown",
//       color: "grey",
//     },
//   ];

//   return (
//     <Box>
//       <Box className="rounded-[8px] h-[100%] overflow-scroll bg-[#F6F9FF] ">
//         <Box className=" bg-[#E4EBFF]  p-2 text-center " sx={{color:theme.palette.custom.snmp.snmplegend}}>{title}</Box>

//         <div
//           className="dynamic-chassis-wrapper"
//           style={gridStyle}
//           data-testid="dynamic-chassis-wrapper"
//         >
//           {/* Background Image Container */}
//           <div className="chassis-background">
//             <img src={imgSrc} alt="chassis" />
//           </div>

//           {/* Dynamic Ports Overlay */}
//           <div className="ports-overlay">
//             {finalPorts.map((portName, index) => {
//               const portData = liveStatuses[portName];

//               const row = Math.floor(index / portsPerRow1);

//               // Determine label side: even rows = 'top', odd rows = 'bottom'
//               const labelSide = row % 2 === 0 ? "top" : "bottom";

//               return (
//                 <Port
//                   key={portName}
//                   id={portName}
//                   portIndex={index + 1}
//                   portDesc={portName}
//                   status={portData?.status}
//                   utilization={portData?.utilization}
//                   speed={portData?.speed}
//                   mac={portData?.mac}
//                   type={portData?.type}
//                   labelSide={labelSide}
//                 />
//               );
//             })}
//           </div>
//         </div>
//         <div
//           style={{
//             display: "flex",
//             marginTop: "55px",
//             gap: "10px",
//             justifyContent: "center",

//           }}
//         >
//           {LinkLegends.map((item) => (
//             <div className="link-type-legend-container" key={item.label}  >
//               <div
//                 style={{
//                   width: "10px",
//                   height: "10px",
//                   borderRadius: "50%",
//                   backgroundColor: `${item.color}`,

//                 }}
//               ></div>
//               <p style={{ fontSize: "16px" ,color:theme.palette.custom.snmp.snmplegend}}  >{item.label}</p>
//             </div>
//           ))}
//         </div>
//       </Box>
//     </Box>
//   );
// };

// export default ImageWidget;





import { Box, useTheme } from "@mui/material";
import React from "react";
import { usePortStatusPolling } from "./usePortStatusPolling";

import "./chasis.css";
import Port from "./Port";
import { useSelector } from "react-redux";

const layoutConfig = {
  portWidth: "40px",
  portGap: "20px",
};

const ImageWidget = ({
  title,
  imgSrc,
  width,
  height,
  mapForDisplay,
  resourceId,
  tableId,
  liveData,
}) => {
  const liveStatuses = usePortStatusPolling(
    resourceId,
    mapForDisplay,
    tableId,
    liveData
  );

  const theme = useTheme();

  const portNames = Object.keys(liveStatuses);

  // Redux fullscreen/maximized state
  const isMaximized = useSelector(
    (state) => state.inventory?.isTableMaximized ?? false
  );

  const standardPortNames = portNames.filter(
    (name) => !name.startsWith("TenGigabitEthernet")
  );

  const tenGigPorts = portNames.filter((name) =>
    name.startsWith("TenGigabitEthernet")
  );

  const oddPorts = standardPortNames.filter((_, index) => index % 2 === 0);
  const evenPorts = standardPortNames.filter((_, index) => index % 2 === 1);
  const finalStandardPorts = [...oddPorts, ...evenPorts];

  const portsPerRow1 = Math.ceil(standardPortNames.length / 2);

  const gridStyle = {
    "--ports-per-row": portsPerRow1,
    "--port-width": layoutConfig.portWidth,
    "--port-gap": layoutConfig.portGap,
  };

  const LinkLegends = [
    { label: "Up", color: "#08fd72" },
    { label: "Down", color: "#ef4747" },
    { label: "Operational down", color: "#fbc02d" },
    { label: "Unknown", color: "grey" },
  ];

  return (
    <Box>
      <Box className="rounded-[8px] h-[100%] overflow-scroll bg-[#F6F9FF]">
        <Box
          className="bg-[#E4EBFF] p-2 text-center"
          sx={{ color: theme.palette.custom.snmp.snmplegend }}
        >
          {title}
        </Box>

        <div
          className="dynamic-chassis-wrapper"
          style={gridStyle}
          data-testid="dynamic-chassis-wrapper"
        >
          {/* Background Image */}
          <div className="chassis-background">
            <img src={imgSrc} alt="chassis" />
          </div>

          {/* Standard Ports */}
          <div className="ports-overlay">
            {finalStandardPorts.map((portName, index) => {
              const portData = liveStatuses[portName];

              const row = Math.floor(index / portsPerRow1);
              const labelSide = row % 2 === 0 ? "top" : "bottom";

              return (
                <Port
                  key={portName}
                  id={portName}
                  portIndex={index + 1}
                  portDesc={portName}
                  status={portData?.status}
                  utilization={portData?.utilization}
                  speed={portData?.speed}
                  mac={portData?.mac}
                  type={portData?.type}
                  labelSide={labelSide}
                />
              );
            })}
          </div>

          {/* TenGigabit Ports */}
          {/* {tenGigPorts.length > 0 && (
            <div
              className={`tengig-ports-overlay ${
                isMaximized
                  ? "tengig-ports-maximized"
                  : "tengig-ports-normal"
              }`}
            >
              {tenGigPorts.map((portName, index) => {
                const portData = liveStatuses[portName];

                return (
                  <Port
                    key={portName}
                    id={portName}
                    portIndex={index + 1}
                    portDesc={portName}
                    status={portData?.status}
                    utilization={portData?.utilization}
                    speed={portData?.speed}
                    mac={portData?.mac}
                    type={portData?.type}
                    labelSide="bottom"
                    portType="tenGig"
                  />
                );
              })}
            </div>
          )} */}
          {tenGigPorts.length > 0 && (
  <div
    className={`tengig-ports-overlay ${
      isMaximized
        ? "tengig-ports-maximized"
        : "tengig-ports-normal"
    }`}
  >
    {tenGigPorts.map((portName, index) => {
      const portData = liveStatuses[portName];

      return (
        <Port
          key={portName}
          id={portName}
          portIndex={index + 1}
          portDesc={portName}
          status={portData?.status}
          utilization={portData?.utilization}
          speed={portData?.speed}
          mac={portData?.mac}
          type={portData?.type}
          labelSide="bottom"
          portType="tenGig"
        />
      );
    })}
  </div>
)}
        </div>

        {/* Legends */}
        <div
          style={{
            display: "flex",
            marginTop: "55px",
            gap: "10px",
            justifyContent: "center",
          }}
        >
          {LinkLegends.map((item) => (
            <div className="link-type-legend-container" key={item.label}>
              <div
                style={{
                  width: "10px",
                  height: "10px",
                  borderRadius: "50%",
                  backgroundColor: item.color,
                }}
              />

              <p
                style={{
                  fontSize: "16px",
                  color: theme.palette.custom.snmp.snmplegend,
                }}
              >
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </Box>
    </Box>
  );
};

export default ImageWidget;