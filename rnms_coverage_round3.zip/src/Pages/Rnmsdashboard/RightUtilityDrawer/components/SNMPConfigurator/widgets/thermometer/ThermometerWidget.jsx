import React from "react";
import BaseWidget from "../core/BaseWidget";
import { Box, Typography } from "@mui/material";

const ThermometerWidget = ({ value = 0, config = {}, name }) => {
  const min = config.min ?? 0;
  const max = config.max ?? 100;

  const percent = Math.min(
    100,
    Math.max(0, ((value - min) / (max - min)) * 100)
  );

  return (
    <BaseWidget title={name || "Thermometer"}>
      <Box
        sx={{
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* OUTER TUBE */}
        <Box
          sx={{
            width: 20,
            height: "100%",
            borderRadius: 10,
            border: "2px solid #ccc",
            position: "relative",
            overflow: "hidden",
            background: "#f5f5f5",
          }}
        >
          {/* FILL */}
          <Box
            sx={{
              position: "absolute",
              bottom: 0,
              width: "100%",
              height: `${percent}%`,
              background: "linear-gradient(to top, red, orange, green)",
              transition: "height 0.3s ease",
            }}
          />
        </Box>

        {/* VALUE */}
        <Typography sx={{ ml: 2, fontWeight: 600 }}>{value}°</Typography>
      </Box>
    </BaseWidget>
  );
};

export default ThermometerWidget;
