import React from "react";
import { Box, Typography } from "@mui/material";

const BaseWidget = ({ title, children }) => {
  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        borderRadius: 2,
        background: "#fff",
        boxShadow: "0 2px 10px rgba(0,0,0,0.08)",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* HEADER */}
      <Box
        sx={{
          px: 1.5,
          py: 1,
          borderBottom: "1px solid #eee",
          background: "#fafafa",
        }}
      >
        <Typography sx={{ fontSize: 13, fontWeight: 600 }}>{title}</Typography>
      </Box>

      {/* BODY */}
      <Box sx={{ flex: 1, p: 1 }}>{children}</Box>
    </Box>
  );
};

export default BaseWidget;
