import MInput from "@/components/Reusable/Input/MInput";
import { Box, Button, Typography, useTheme } from "@mui/material";
import React from "react";

const RemoteDevice = ({
  selectedOids,
  title,
  showVehicleHeading,
  isEditable,
}) => {
  const theme=useTheme()
  return (
    <Box className="rounded-[8px] h-[100%] overflow-y-scroll  ">
      <Box className=" bg-[#E4EBFF]  p-2 text-center " sx={{color:theme.palette.custom.snmp.snmplegend}}>{title}</Box>

      <Box className=" ">
        {selectedOids.map((item) => (
          <Box
            sx={{
              padding: "5px",
              display: "flex",
              gap: "5px",
              flexDirection: "column",
              borderBottom: "2px solid #e0e0e0",
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: "5px",
              }}
            >
              <Box sx={{ fontWeight: "bold" }}>Latitude</Box>
              <Box
                sx={{
                  display: "flex",
                  gap: "5px",
                  flexWrap: "wrap",
                  alignItems: "flex-end",
                }}
              >
                <Box>
                  <Typography>Degree</Typography>
                  <MInput unit="Deg" showUnit={true} />
                </Box>
                <Box>
                  <Typography>Minute</Typography>
                  <MInput unit="Min" showUnit={true} />
                </Box>
                <Box>
                  <Typography>Second</Typography>
                  <MInput unit="Sec" showUnit={true} />
                </Box>

                <MInput />
              </Box>
            </Box>
            <Box>
              <Box sx={{ fontWeight: "bold" }}>Longititude</Box>
              <Box
                sx={{
                  display: "flex",
                  gap: "5px",
                  flexWrap: "wrap",
                  alignItems: "flex-end",
                }}
              >
                <Box>
                  <Typography>Degree</Typography>
                  <MInput unit="Deg" showUnit={true} />
                </Box>
                <Box>
                  <Typography>Minute</Typography>
                  <MInput unit="Min" showUnit={true} />
                </Box>
                <Box>
                  <Typography>Second</Typography>
                  <MInput unit="Sec" showUnit={true} />
                </Box>
                <MInput />
              </Box>
            </Box>
            <Box>
              <Box sx={{ fontWeight: "bold" }}>Altittude (Mtr)*</Box>
              <Typography>Mtr</Typography>
              <Box>
                <Box
                  sx={{
                    display: "flex",
                    gap: "5px",
                    flexWrap: "wrap",
                    alignItems: "center",
                  }}
                >
                  <MInput unit="Mtr" showUnit={true} />
                  {isEditable && (
                    <Button variant="outlined"  sx={{border:theme.palette.custom.border,color:"text.TitleTextcolor",borderRadius:'10px'}}>Load</Button>
                  )}
                </Box>
              </Box>
            </Box>

            {showVehicleHeading && (
              <Box>
                <Typography>Vehicle heading </Typography>{" "}
                <MInput unit="Mtr" showUnit={true} />
              </Box>
            )}
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default RemoteDevice;
