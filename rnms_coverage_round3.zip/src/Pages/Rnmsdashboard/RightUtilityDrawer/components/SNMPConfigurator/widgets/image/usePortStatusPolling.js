import { useState, useEffect } from "react";
import Toast from "@/components/Reusable/Toast/Toast";

const createDummyPorts = (numPorts = 24) => {
  const dummyPorts = {};
  for (let i = 1; i <= numPorts; i++) {
    const portName = `Port${i}`;
    dummyPorts[portName] = {
      type: "ethernet",
      adminStatus: "unknown",
      status: "unknown",
      operStatus: "loading",
      utilization: null,
      speed: null,
    };
  }
  return dummyPorts;
};

/**
 * Normalizes raw liveData table response into port statuses.
 */
const normalizePortData = (apiData, OID_MAP, config, tableId) => {
  try {
    const tableKeys = apiData?.table || {};
    if (Object.keys(tableKeys).length === 0) return {};

    const portTableKey = tableKeys[tableId];
    if (!portTableKey) return {};

    const portsArray = portTableKey;

    const descriptionOid = OID_MAP?.description;
    const nameOid = OID_MAP?.name;
    const adminOid = OID_MAP?.admin;
    const operOid = OID_MAP?.operation;

    const normalized = {};
    portsArray.forEach((port) => {
      const portName = port[nameOid];
      const type = port[descriptionOid];

      const rawAdmin = port[adminOid];
      const rawOper = port[operOid];

      const adminStatus =
        typeof rawAdmin === "string" ? rawAdmin.toLowerCase().trim() : "";
      const operStatus =
        typeof rawOper === "string" ? rawOper.toLowerCase().trim() : "";

      const dynamicRegex = config
        ? new RegExp(config.portDescriptionMatchingString, "i")
        : /.*/;

      // const dynamicRegex = new RegExp(
      //   config.portDescriptionMatchingString,
      //   "i"
      // );

      // console.log(dynamicRegex, "hgdfhgdhgfhdgf");

      if (
        portName &&
        portName.match(dynamicRegex) &&
        portName !== "GigabitEthernet0/0" &&
        type === "Ethernet"
      ) {
        let finalStatus = "unknown";

        if (adminStatus === "up" && operStatus === "up") {
          finalStatus = "up";
        } else if (adminStatus === "up" && operStatus === "down") {
          finalStatus = "operational-down";
        } else if (
          adminStatus === "down" &&
          (operStatus === "up" || operStatus === "down")
        ) {
          finalStatus = "down";
        }

        normalized[portName] = {
          type,
          adminStatus,
          operStatus,
          status: finalStatus,
        };
      }
    });

    return normalized;
  } catch (error) {
    console.error("Failed to normalize port status:", error);
    return {};
  }
};

/**
 * Custom hook that solely consumes and normalizes liveData passed as a prop, with no internal polling.
 */
export const usePortStatusPolling = (deviceId, OID_MAP, tableId, liveData) => {
  const [portStatuses, setPortStatuses] = useState(createDummyPorts(24));
  const [config, setConfig] = useState(null);

  const getPortDescriptionMatchingRegex = async () => {
    try {
      const res = await fetch("/config.json");
      const data = await res.json();
      setConfig(data);
    } catch (error) {
      console.error("Error fetching config:", error);
      Toast("Failure!", "Error fetching Regex.", "error");
    }
  };

  useEffect(() => {
    getPortDescriptionMatchingRegex();
  }, []);

  // Update statuses whenever liveData or config changes
  useEffect(() => {
    if (liveData && config) {
      const normalized = normalizePortData(liveData, OID_MAP, config, tableId);
      if (Object.keys(normalized).length > 0) {
        setPortStatuses(normalized);
      }
    }
  }, [liveData, config, OID_MAP, tableId]);

  return portStatuses;
};
