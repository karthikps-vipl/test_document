export const WIDGET_TYPES = {
  // --- Numerical Sensors & Gauges ---
  THERMOMETER: "thermometer",
  GAUGE: "gauge",
  DIGITAL_NUMBER: "digital_number",
  PROGRESS_BAR: "progress_bar",
  DASH_RADIAL: "dash_radial",

  // --- Status Indicators & Active Controls ---
  FAN: "fan",
  STATUS_LED: "status_led",
  TOGGLE_SWITCH: "toggle_switch",
  ALARM_BANNER: "alarm_banner",

  // --- Text Elements ---
  STATIC_TEXT: "static_text",
  HEADER_BLOCK: "header_block",
  DATA_LABEL: "data_label",

  // --- Charts & Analytical Components ---
  LINE_CHART: "line_chart",
  BAR_CHART: "bar_chart",
  SPARKLINE: "sparkline",

  // --- Data Dense Structures ---
  DATA_TABLE: "data_table",
  ALARM_LOG: "alarm_log",
};

// UI dropdown translation mapping
export const WIDGET_LABELS = {
  [WIDGET_TYPES.THERMOMETER]: "Thermometer Sensor",
  [WIDGET_TYPES.GAUGE]: "Dial Pointer Gauge",
  [WIDGET_TYPES.DIGITAL_NUMBER]: "Large Digital Readout",
  [WIDGET_TYPES.PROGRESS_BAR]: "Horizontal Fill Bar",
  [WIDGET_TYPES.DASH_RADIAL]: "Radial Percentage Circle",
  [WIDGET_TYPES.FAN]: "Animated Cooling Fan",
  [WIDGET_TYPES.STATUS_LED]: "RGB Status LED Indicator",
  [WIDGET_TYPES.TOGGLE_SWITCH]: "Control Toggle Switch",
  [WIDGET_TYPES.ALARM_BANNER]: "Active Emergency Banner",
  [WIDGET_TYPES.STATIC_TEXT]: "Plain Text Paragraph",
  [WIDGET_TYPES.HEADER_BLOCK]: "Section Title Header",
  [WIDGET_TYPES.DATA_LABEL]: "Inline OID Data Label",
  [WIDGET_TYPES.LINE_CHART]: "Realtime Line Graph Trend",
  [WIDGET_TYPES.BAR_CHART]: "Historical Bar Comparison",
  [WIDGET_TYPES.SPARKLINE]: "Compact Mini Line Trend",
  [WIDGET_TYPES.DATA_TABLE]: "Structured Spreadsheet Grid",
  [WIDGET_TYPES.ALARM_LOG]: "Fault Notification Log",
};
