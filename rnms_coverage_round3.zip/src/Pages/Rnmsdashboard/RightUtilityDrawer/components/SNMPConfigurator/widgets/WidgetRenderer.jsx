import React from "react";
import { WIDGET_REGISTRY } from "./WidgetRegistry23";

const WidgetRenderer = ({ type, config, value, name }) => {
  console.log("typesdrf",type);
  
  const Component = WIDGET_REGISTRY[type];

  if (!Component) {
    return <div>Unknown Widget: {type}</div>;
  }

  return <Component config={config} value={value} name={name} />;
};

export default WidgetRenderer;
