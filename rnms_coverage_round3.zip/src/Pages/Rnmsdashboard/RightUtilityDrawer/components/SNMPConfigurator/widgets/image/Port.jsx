// import React from "react";
// import "./port.css";
// import down from "@/assets/PortStatus/Admin Down.svg";
// import op_down from "@/assets/PortStatus/Down.svg";
// import up from "@/assets/PortStatus/Up.svg";
// import unknown from "@/assets/PortStatus/Not Configured.svg";

// const PORT_STATUS_META_CHASSIS = {
//   up: {
//     label: "Up",
//     color: "#8fd3a8",
//     icon: up,
//   },
//   down: {
//     label: "Down",
//     color: "#ffff00",
//     icon: down,
//   },
//   "operational-down": {
//     label: "Down",
//     color: "#ffff00",
//     icon: op_down,
//   },
//   unknown: {
//     label: "Unknown",
//     color: "#9ea7b3",
//     icon: unknown,
//   },
// };

// const Port = ({
//   id,
//   status,
//   utilization,
//   speed,
//   portIndex,
//   portDesc,
//   showPortLabel = true,
//   labelSide,
// }) => {
//   // Normalize status string → CSS class
//   console.log(status, "statusdgdfgfdg");

//   const labelClassName = `port-label-chassis-${labelSide}`;

//   return (
//     <div
//       className="port-container"
//       // title={tooltipText}
//       data-testid={`port-${id}`}
//     >
//       {showPortLabel && (
//         <span className={`port-label-chassis ${labelClassName}`}>
//           {portDesc}
//         </span>
//       )}
//       {/* <div className={`port-led ${statusClassName}`}></div> */}
//       <img
//         src={PORT_STATUS_META_CHASSIS[status].icon}
//         style={{
//           transform: labelSide === "bottom" ? "rotate(180deg)" : "none",
//         }}
//       />
//     </div>
//   );
// };

// export default Port;


import React from "react";
import "./port.css";

import down from "@/assets/PortStatus/Admin Down.svg";
import op_down from "@/assets/PortStatus/Down.svg";
import up from "@/assets/PortStatus/Up.svg";
import unknown from "@/assets/PortStatus/Not Configured.svg";

const PORT_STATUS_META_CHASSIS = {
  up: {
    label: "Up",
    color: "#8fd3a8",
    icon: up,
  },
  down: {
    label: "Down",
    color: "#ffff00",
    icon: down,
  },
  "operational-down": {
    label: "Down",
    color: "#ffff00",
    icon: op_down,
  },
  unknown: {
    label: "Unknown",
    color: "#9ea7b3",
    icon: unknown,
  },
};

const Port = ({
  id,
  status,
  utilization,
  speed,
  portIndex,
  portDesc,
  showPortLabel = true,
  labelSide,
  portType = "standard",
}) => {
  const portMeta =
    PORT_STATUS_META_CHASSIS[status] ||
    PORT_STATUS_META_CHASSIS.unknown;

  const labelClassName = `port-label-chassis-${labelSide}`;

  return (
    <div
      className={`port-container ${
        portType === "tenGig" ? "ten-gig-port" : "standard-port"
      }`}
      data-testid={`port-${id}`}
    >
      {showPortLabel && (
        <span
          className={`port-label-chassis ${labelClassName} ${
            portType === "tenGig" ? "ten-gig-label" : ""
          }`}
        >
          {portDesc}
        </span>
      )}

<img
  src={portMeta.icon}
  alt={portMeta.label}
  className="port-status-icon"
  style={{
    transform: labelSide === "bottom" ? "rotate(180deg)" : "none",
  }}
/>
    </div>
  );
};

export default Port;