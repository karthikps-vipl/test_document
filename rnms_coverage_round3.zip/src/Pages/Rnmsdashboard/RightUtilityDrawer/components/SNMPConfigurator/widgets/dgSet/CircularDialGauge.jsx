// import React from "react";
// import { Box, Typography } from "@mui/material";

// const CircularDialGauge = ({ widget }) => {
//   const title = widget?.gridTitle || "Gauge";
//   const min = widget?.minVal ?? 0;
//   const max = widget?.maxVal ?? 100;
//   const unit = widget?.unit || "";

//   // Extract current value dynamically from widget data
//   const currentValue =
//     widget?.data?.[2]?.currentValue ?? widget?.data?.[0]?.currentValue ?? min;

//   // Clamp and calculate percentage (0 to 1)
//   const clampedValue = Math.min(Math.max(currentValue, min), max);
//   const percentage = (clampedValue - min) / (max - min || 1);

//   // 1. Brighter, vibrant color coding logic
//   const getGaugeColor = (pct) => {
//     if (pct < 0.4) return "#2e7d32"; // Brighter Green (Low)
//     if (pct < 0.8) return "#fbc02d"; // Brighter Amber/Orange (Normal)
//     return "#d32f2f"; // Brighter Red (High)
//   };
//   const activeColor = getGaugeColor(percentage);

//   // 2. Generate 5 tick marks & scale labels along the speedometer arc
//   const tickCount = 5;
//   const ticks = Array.from({ length: tickCount }, (_, i) => {
//     const val = min + (i / (tickCount - 1)) * (max - min);
//     return Number.isInteger(val) ? val : val.toFixed(1);
//   });

//   // SVG Geometry Constants for a 180-degree semi-circular gauge
//   const size = 180;
//   const cx = size / 2;
//   const cy = 90;
//   const r = 70;

//   // Needle rotation calculation (-90deg to 90deg)
//   const rotationAngle = percentage * 180 - 90;

//   return (
//     <Box
//       sx={{
//         p: 2,
//         height: "100%",
//         display: "flex",
//         flexDirection: "column",
//         alignItems: "center",
//         justifyContent: "space-between",
//         backgroundColor: "#fff",
//         borderRadius: 2,
//       }}
//     >
//       <Typography sx={{ fontSize: "14px", fontWeight: 600, color: "#333" }}>
//         {title}
//       </Typography>

//       {/* SVG Speedometer Graphic */}
//       <Box
//         sx={{
//           width: `${size}px`,
//           height: "105px",
//           position: "relative",
//           mt: 1,
//         }}
//       >
//         <svg width={size} height="105" style={{ overflow: "visible" }}>
//           {/* Background Track Arc */}
//           <path
//             d="M 20 90 A 70 70 0 0 1 160 90"
//             fill="none"
//             stroke="#e0e0e0"
//             strokeWidth="12"
//             strokeLinecap="round"
//           />

//           {/* Active Progress Arc (Dynamic Length & Color) */}
//           <path
//             d="M 20 90 A 70 70 0 0 1 160 90"
//             fill="none"
//             stroke={activeColor}
//             strokeWidth="12"
//             strokeLinecap="round"
//             strokeDasharray={Math.PI * r}
//             strokeDashoffset={Math.PI * r * (1 - percentage)}
//             style={{
//               transition:
//                 "stroke-dashoffset 0.5s ease-in-out, stroke 0.3s ease-in-out",
//             }}
//           />

//           {/* Radial Tick Labels */}
//           {ticks.map((tick, index) => {
//             const angle = (index / (tickCount - 1)) * Math.PI - Math.PI; // -PI to 0
//             const labelRadius = r + 18;
//             const x = cx + labelRadius * Math.cos(angle);
//             const y = cy + labelRadius * Math.sin(angle);

//             return (
//               <text
//                 key={index}
//                 x={x}
//                 y={y}
//                 fill="#555"
//                 fontSize="9"
//                 fontWeight="600"
//                 textAnchor="middle"
//                 dominantBaseline="central"
//               >
//                 {tick}
//               </text>
//             );
//           })}

//           {/* Needle Pivoting Group */}
//           <g
//             transform={`rotate(${rotationAngle}, ${cx}, ${cy})`}
//             style={{ transition: "transform 0.5s ease-in-out" }}
//           >
//             <polygon
//               points={`${cx},${cy - 65} ${cx - 3},${cy} ${cx + 3},${cy}`}
//               fill="#212121"
//             />
//           </g>

//           {/* Center Pivot Cap */}
//           <circle cx={cx} cy={cy} r="7" fill="#212121" />
//         </svg>
//       </Box>

//       {/* Current Value Display */}
//       <Box sx={{ textAlign: "center", mt: 0.5 }}>
//         <Typography
//           sx={{ fontSize: "18px", fontWeight: "bold", color: "#1976d2" }}
//         >
//           {widget?.dgSet ? widget?.displayValue : `${currentValue} ${unit}`}
//         </Typography>
//       </Box>
//     </Box>
//   );
// };

// export default CircularDialGauge;

//------------------ WORKING ONE -----------------//
// import React from "react";
// import { Box, Typography } from "@mui/material";

// const CircularDialGauge = ({ widget }) => {
//   const title = widget?.gridTitle || "Gauge";
//   const min = widget?.minVal ?? 0;
//   const max = widget?.maxVal ?? 100;
//   const unit = widget?.unit || "";

//   // Extract current value dynamically from widget data
//   const currentValue =
//     widget?.data?.[2]?.currentValue ?? widget?.data?.[0]?.currentValue ?? min;

//   // Clamp and calculate percentage (0 to 1)
//   const clampedValue = Math.min(Math.max(currentValue, min), max);
//   const percentage = (clampedValue - min) / (max - min || 1);

//   // Brighter, vibrant color coding logic
//   const getGaugeColor = (pct) => {
//     if (pct < 0.4) return "#2e7d32"; // Green (Low)
//     if (pct < 0.8) return "#fbc02d"; // Amber/Orange (Normal)
//     return "#d32f2f"; // Red (High)
//   };
//   const activeColor = getGaugeColor(percentage);

//   // SVG Geometry Constants for a 180-degree semi-circular gauge
//   const size = 180;
//   const cx = size / 2;
//   const cy = 90;
//   const r = 70;

//   // Configuration for Ticks
//   const majorTickCount = 7; // Number of labeled ticks (keeps text readable)
//   const minorTicksPerInterval = 2; // Minor ticks between each major tick
//   const totalIntervals = majorTickCount - 1;
//   const totalMinorTicks = totalIntervals * (minorTicksPerInterval + 1);

//   // Generate Major Ticks & Labels
//   const majorTicks = Array.from({ length: majorTickCount }, (_, i) => {
//     const val = min + (i / totalIntervals) * (max - min);
//     return {
//       value: Number.isInteger(val) ? val : val.toFixed(1),
//       ratio: i / totalIntervals,
//     };
//   });

//   // Generate Minor Ticks Array
//   const minorTicks = Array.from({ length: totalMinorTicks + 1 }, (_, i) => {
//     return i / totalMinorTicks;
//   });

//   // Needle rotation calculation (-90deg to 90deg)
//   const rotationAngle = percentage * 180 - 90;

//   return (
//     <Box
//       sx={{
//         p: 2,
//         height: "100%",
//         display: "flex",
//         flexDirection: "column",
//         alignItems: "center",
//         justifyContent: "space-between",
//         backgroundColor: "#fff",
//         borderRadius: 2,
//       }}
//     >
//       <Typography sx={{ fontSize: "14px", fontWeight: 600, color: "#333" }}>
//         {title}
//       </Typography>

//       {/* SVG Speedometer Graphic */}
//       <Box
//         sx={{
//           width: `${size}px`,
//           height: "115px",
//           position: "relative",
//           mt: 1,
//         }}
//       >
//         <svg width={size} height="115" style={{ overflow: "visible" }}>
//           {/* Background Track Arc */}
//           <path
//             d="M 20 90 A 70 70 0 0 1 160 90"
//             fill="none"
//             stroke="#e0e0e0"
//             strokeWidth="12"
//             strokeLinecap="round"
//           />

//           {/* Active Progress Arc */}
//           <path
//             d="M 20 90 A 70 70 0 0 1 160 90"
//             fill="none"
//             stroke={activeColor}
//             strokeWidth="12"
//             strokeLinecap="round"
//             strokeDasharray={Math.PI * r}
//             strokeDashoffset={Math.PI * r * (1 - percentage)}
//             style={{
//               transition:
//                 "stroke-dashoffset 0.5s ease-in-out, stroke 0.3s ease-in-out",
//             }}
//           />

//           {/* Minor Ticks */}
//           {minorTicks.map((ratio, index) => {
//             const angle = ratio * Math.PI - Math.PI; // -PI to 0
//             const innerR = r - 8;
//             const outerR = r - 4;
//             const x1 = cx + innerR * Math.cos(angle);
//             const y1 = cy + innerR * Math.sin(angle);
//             const x2 = cx + outerR * Math.cos(angle);
//             const y2 = cy + outerR * Math.sin(angle);

//             return (
//               <line
//                 key={`minor-${index}`}
//                 x1={x1}
//                 y1={y1}
//                 x2={x2}
//                 y2={y2}
//                 stroke="#b0b0b0"
//                 strokeWidth="1.5"
//               />
//             );
//           })}

//           {/* Radial Major Tick Labels */}
//           {majorTicks.map((tick, index) => {
//             const angle = tick.ratio * Math.PI - Math.PI;
//             const labelRadius = r + 20;
//             const x = cx + labelRadius * Math.cos(angle);
//             const y = cy + labelRadius * Math.sin(angle);

//             return (
//               <text
//                 key={`major-${index}`}
//                 x={x}
//                 y={y}
//                 fill="#555"
//                 fontSize="8.5"
//                 fontWeight="600"
//                 textAnchor="middle"
//                 dominantBaseline="central"
//               >
//                 {tick.value}
//               </text>
//             );
//           })}

//           {/* Needle Pivoting Group */}
//           <g
//             transform={`rotate(${rotationAngle}, ${cx}, ${cy})`}
//             style={{ transition: "transform 0.5s ease-in-out" }}
//           >
//             <polygon
//               points={`${cx},${cy - 65} ${cx - 3},${cy} ${cx + 3},${cy}`}
//               fill="#212121"
//             />
//           </g>

//           {/* Center Pivot Cap */}
//           <circle cx={cx} cy={cy} r="7" fill="#212121" />
//         </svg>
//       </Box>

//       {/* Current Value Display */}
//       <Box sx={{ textAlign: "center", mt: 0.5 }}>
//         <Typography
//           sx={{ fontSize: "18px", fontWeight: "bold", color: "#1976d2" }}
//         >
//           {widget?.dgSet ? widget?.displayValue : `${currentValue} ${unit}`}
//         </Typography>
//       </Box>
//     </Box>
//   );
// };

// export default CircularDialGauge;

// ----------------------------------------------------------------------------

import React from "react";
import { Box, Typography, useTheme } from "@mui/material";

const CircularDialGauge = ({ widget }) => {
  const theme = useTheme();
  const title = widget?.gridTitle || "Gauge";
  const min = widget?.minVal ?? 0;
  const max = widget?.maxVal ?? 100;
  const unit = widget?.unit || "";
  const innerRange = widget?.innerRange || "";

  const currentName = widget?.gridTitle || "NA"
  // Extract current value dynamically from widget data (Functionality Preserved)
  const currentValue =
    widget?.data?.[2]?.currentValue ?? widget?.data?.[0]?.currentValue ?? min;

  // Clamp and calculate percentage (0 to 1)
  const clampedValue = Math.min(Math.max(currentValue, min), max);
  const rangeSpan = max - min || 1;
  const percentage = (clampedValue - min) / rangeSpan;

  // Needle rotation calculation (-90deg to 90deg)
  const needleAngle = -90 + percentage * 180;

  // Compute Tick Step Intervals dynamically based on min/max
  let stepSize = Math.ceil(rangeSpan / innerRange);
  if (stepSize <= 0 || isNaN(stepSize)) {
    stepSize = 10;
  }

  const ticks = [];
  for (let v = min; v <= max; v += stepSize) {
    ticks.push(v);
  }
  if (ticks.length === 0 || ticks[ticks.length - 1] !== max) {
    ticks.push(max);
  }

  // SVG Viewport Dimensions matching NeedleGauge Style
  const svgW = 240;
  const svgH = 140;
  const cx = svgW / 2;
  const cy = svgH - 15;

  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: theme.palette.background.paper,
        // border: "1px solid #e2e8f0",
        borderRadius: "12px",
        padding: "12px",
        // boxShadow:
        //   "0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px -1px rgba(0, 0, 0, 0.05)",
        boxSizing: "border-box",
        width: "100%",
        maxWidth: "350px",
        minWidth: "200px",
        margin: "0 auto",
      }}
    >
      {/* Gauge Header Title */}
      <Typography
        sx={{
          fontSize: "12px",
          color: "#334155",
          fontWeight: 700,
          textAlign: "center",
          display: "block",
          whiteSpace: "nowrap",
          textOverflow: "ellipsis",
          overflow: "hidden",
          width: "100%",
          mb: 1,
        }}
        title={title}
      >
        {title}
      </Typography>

      {/* Modern Speedometer SVG Graphic */}
      <svg
        width="100%"
        height="180"
        viewBox={`0 0 ${svgW} ${svgH}`}
        style={{ overflow: "visible" }}
      >
        {/* Outer Base Track Arc */}
        <path
          d={`M ${cx - 90} ${cy} A 90 90 0 0 1 ${cx + 90} ${cy}`}
          fill="none"
          stroke="#f1f5f9"
          strokeWidth="10"
          strokeLinecap="round"
        />

        {/* Active Colored Fill Accent Arc */}
        <path
          d={`M ${cx - 90} ${cy} A 90 90 0 0 1 ${cx + 90} ${cy}`}
          fill="none"
          stroke="#3b82f6"
          strokeWidth="6"
          strokeDasharray={`${percentage * 282.7} 282.7`}
          strokeLinecap="round"
          opacity="0.85"
        />

        {/* Inner Reference Guide Ring */}
        <path
          d={`M ${cx - 74} ${cy} A 74 74 0 0 1 ${cx + 74} ${cy}`}
          fill="none"
          stroke="#e2e8f0"
          strokeWidth="1"
          strokeDasharray="4,4"
        />

        {/* Ticks & Number Mapping Markers */}
        {ticks.map((tickVal, tIdx) => {
          const fraction = tIdx / (ticks.length - 1 || 1);
          const angleDeg = -90 + fraction * 180;
          const angleRad = (angleDeg * Math.PI) / 180;

          const xOuter = cx + Math.sin(angleRad) * 85;
          const yOuter = cy - Math.cos(angleRad) * 85;
          const xInner = cx + Math.sin(angleRad) * 78;
          const yInner = cy - Math.cos(angleRad) * 78;

          const xText = cx + Math.sin(angleRad) * 62;
          const yText = cy - Math.cos(angleRad) * 62;

          return (
            <g key={tIdx}>
              <line
                x1={xOuter}
                y1={yOuter}
                x2={xInner}
                y2={yInner}
                stroke="#64748b"
                strokeWidth="1.5"
              />
              <text
                x={xText}
                y={yText}
                textAnchor="middle"
                dominantBaseline="central"
                fill="#475569"
                fontSize="9"
                fontWeight="600"
              >
                {Math.round(tickVal)}
              </text>
            </g>
          );
        })}

        {/* Center Core Cap Nodes */}
        <circle cx={cx} cy={cy} r="12" fill="#1e293b" />
        <circle cx={cx} cy={cy} r="5" fill="#94a3b8" />

        {/* Dynamic Rotation Core Needle */}
        <g transform={`rotate(${needleAngle}, ${cx}, ${cy})`}>
          <polygon
            points={`${cx - 2.5},${cy} ${cx + 2.5},${cy} ${cx},${cy - 94}`}
            fill="#ef4444"
          />
          <circle cx={cx} cy={cy} r="4" fill="#ef4444" />
        </g>
      </svg>

      {/* Digital Readout Matrix HUD */}
      <Box
        sx={{
          padding: "4px 12px",
          borderRadius: "6px",
          marginTop: "6px",
          width: "77%",
          textAlign: "center",
          border: "1px solid #334155",
        }}
      >
        <Typography
          component="span"
          sx={{
            fontSize: "14px",
            fontWeight: "700",
            color: "#10b981",
            fontFamily: "ui-monospace, SFMono-Regular, monospace",
          }}
        >
          {widget?.dgSet ? widget?.displayValue : `${currentName}(${unit}) = ${currentValue}`}
        </Typography>
      </Box>
    </Box>
  );
};

export default CircularDialGauge;
