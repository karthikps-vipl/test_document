import React from "react";

const TitleWidget = ({ content }) => {
  return (
    <div
      style={{
        display: "flex",
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div>{content}</div>
    </div>
  );
};

export default TitleWidget;
