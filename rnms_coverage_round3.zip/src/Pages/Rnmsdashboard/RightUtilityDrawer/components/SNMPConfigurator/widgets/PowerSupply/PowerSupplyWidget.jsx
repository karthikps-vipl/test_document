import { useTheme } from "@mui/material";
import React from "react";

export const PowerSupplyWidget = ({
  tableTitle,
  targetDisplayName,
  stateValue,
  activeValue,
  valueOid,
}) => {
  // Coerce system status to truthy boolean values
  const isPowerOn =
    String(activeValue).toLowerCase() === "true" ||
    parseFloat(activeValue) === 1 ||
    String(activeValue).toLowerCase() === "on";
const theme=useTheme()
  return (
    <div
      style={{
        padding: "16px",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        boxSizing: "border-box",
        fontFamily: "sans-serif",
        //backgroundColor: "#ffffff",
        backgroundColor: theme.palette.background.paper, 
      }}
    >
      <div style={{ textAlign: "center", width: "100%" }}>
        <h4
          style={{
            margin: "0 0 4px 0",
            color: theme.palette.custom.snmp.snmmptitle,
            fontSize: "14px",
            fontWeight: "600",
          }}
        >
          {targetDisplayName}
        </h4>
        {/* <span style={{ fontSize: "11px", color: "#666" }}>
          Tag: {targetDisplayName}
        </span> */}
      </div>

      {/* Industrial SVG Power Button Status Node */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          margin: "12px 0",
        }}
      >
        <svg width="80" height="80" viewBox="0 0 100 100">
          {/* Status Background Glow Ring */}
          <circle
            cx="50"
            cy="50"
            r="40"
            fill={!isPowerOn ? "#f0fdf4" : "#fef2f2"}
            stroke={!isPowerOn ? "#bbf7d0" : "#fecaca"}
            strokeWidth="2"
          />
          {/* Outer SVG Segmented Power Arc Loop */}
          <path
            d="M 32.5 32.5 A 25 25 0 1 0 67.5 32.5"
            fill="none"
            stroke={!isPowerOn ? "#22c55e" : "#ef4444"}
            strokeWidth="8"
            strokeLinecap="round"
            style={{ transition: "stroke 0.3s ease" }}
          />
          {/* Centered Power Line Pin Element */}
          <line
            x1="50"
            y1="15"
            x2="50"
            y2="45"
            stroke={!isPowerOn ? "#22c55e" : "#ef4444"}
            strokeWidth="8"
            strokeLinecap="round"
            style={{ transition: "stroke 0.3s ease" }}
          />
        </svg>
      </div>

      <div style={{ textAlign: "center", width: "100%" }}>
        <span
          style={{
            fontSize: "18px",
            fontWeight: "bold",
            color: !isPowerOn ? "#22c55e" : "#ef4444",
          }}
        >
          SYSTEM {!isPowerOn ? "ACTIVE" : "OFFLINE"}
        </span>
        <div
          style={{
            marginTop: "6px",
            padding: "3px 8px",
            borderRadius: "12px",
            fontSize: "11px",
            fontWeight: "600",
            color: "#fff",
            backgroundColor: !isPowerOn ? "#16a34a" : "#dc2626",
          }}
        >
          {stateValue}
        </div>

      </div>
    </div>
  );
};
