import React, { useEffect, useRef, useState } from "react";
import { Box, Typography, Grid, useTheme } from "@mui/material";

import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";

import ExcelConfigBuilder from "./ExcelConfigBuilder";
import { InventoryAxios, ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_TERMINAL_TYPE_DETAILS,
  FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL,
  GET_LAYOUT_FOR_DEVICE,
  GET_STATUS_BY_DEVICE_AND_TAB,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";

const STEP = {
  SELECT: "SELECT",
  EXCEL: "EXCEL",
};

const SNMPDashboard = () => {
    const theme = useTheme();
    const isDark = theme.palette.mode === 'dark';
  const [terminalTypes, setTerminalTypes] = useState([]);
  const [devices, setDevices] = useState([]);
  const [dialogTypes] = useState([
    { label: "Status", value: "STATUS" },
    { label: "Configuration", value: "CONFIGURATION" },
  ]);

  const [selectedTerminalId, setSelectedTerminalId] = useState("");
  const [selectedDeviceId, setSelectedDeviceId] = useState("");
  const [selectedDialog, setSelectedDialog] = useState("");

  const [layoutData, setLayoutData] = useState(null);
  const [step, setStep] = useState(STEP.SELECT);
  const [showTabs, setShowTabs] = useState(false);
  const [tabCount, setTabCount] = useState("");
  const [tabs, setTabs] = useState([]);

  const [liveStatusData, setLiveStatusData] = useState(null);
  const [activeTabIdx, setActiveTabIdx] = useState(0);
  const pollingIntervalRef = useRef(null);
  console.log(
    activeTabIdx,
    "activeTabIdactiveTabIdactiveTabIdactiveTabIdactiveTabIdactiveTabId"
  );

  const lastKnownStatusRef = useRef(null);
  const selectedTerminal = terminalTypes.find(
    (x) => x.value === selectedTerminalId
  );
  const selectedDevice = devices.find((x) => x.value === selectedDeviceId);

  console.log("yyyselectedDevice", selectedDevice);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await InventoryAxios(
          FETCH_ALL_TERMINAL_TYPE_DETAILS,
          "get"
        );
        setTerminalTypes(
          (res?.data || []).map((t) => ({
            label: t.terminalTypeName,
            value: t.id,
            raw: t,
          }))
        );
      } catch (err) {
        Toast("Error!", `Error loading terminals`, "error");
      }
    };
    load();
  }, []);
  useEffect(() => {
    // Clean up any existing intervals immediately
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }

    const deviceType =
      selectedDevice?.raw?.resourceTypeName || selectedDevice?.raw?.resourceId;
    const isStatusMode = selectedDialog === "STATUS";

    // Only run polling loop if we are in EXCEL view, a device is active, and Dialog Type is "STATUS"
    if (step === STEP.EXCEL && deviceType && isStatusMode) {
      const fetchLiveSNMPMetrics = async () => {
        try {
          const modeId = 1; // 1 -> Status Window Mode
          // Match endpoint structure: /ConfigurationMgmt/deviceStatus/getStatusByDeviceAndTab/{deviceType}/{mode}/{tabId}
          const url = `${GET_STATUS_BY_DEVICE_AND_TAB}/${deviceType}/${modeId}/${activeTabIdx}`;

          // Using ConfigurationAxios for status fetching updates
          const res = await ConfigurationAxios(url, "get");
          if (res?.data) {
            const currentStatus = res.data.status; // This is 1 or 0

            // --- LOGIC TO SHOW TOAST ONLY ON CHANGE ---
            // Check if the status is different from the last time we checked
            if (currentStatus !== lastKnownStatusRef.current) {
              if (currentStatus === 1) {
                Toast("Success", "Device is discovered", "success");
              } else {
                Toast("Information", "Device is not discovered", "warning");
              }
              // Update the ref so the next poll knows the status has changed
              lastKnownStatusRef.current = currentStatus;
            }
            // ------------------------------------------

            setLiveStatusData(res.data);
          }
        } catch (err) {
          Toast("Error!", `SNMP live stream poll failed`, "error");
        }
      };

      // Fire an immediate execution on tab switch or initialization
      fetchLiveSNMPMetrics();

      // Set up the recurring 10s tracking cycle
      pollingIntervalRef.current = setInterval(fetchLiveSNMPMetrics, 10000);
    } else {
      setLiveStatusData(null);
      lastKnownStatusRef.current = null;
    }

    // Clean up interval thread when leaving component/changing steps
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [step, selectedDevice, selectedDialog, activeTabIdx]);
  const handleTerminalChange = async (value) => {
    setSelectedTerminalId(value);
    setSelectedDeviceId("");
    setDevices([]);
    setLayoutData(null);
    setShowTabs(false);

    try {
      const res = await InventoryAxios(
        `${FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL}/${value}`,
        "get"
      );
      setDevices(
        (res?.data || []).map((d) => ({
          label: d.resourceName,
          value: d.resourceId,
          raw: d,
        }))
      );
    } catch (err) {
      console.error("Error loading devices:", err);
    }
  };

  const handleDeviceChange = async (value) => {
    setSelectedDeviceId(value);
    const device = devices.find((d) => d.value === value);
    if (!device) return;

    const deviceType = device.raw.resourceTypeName || device.raw.resourceId;

    try {
      const res = await ConfigurationAxios(
        `${GET_LAYOUT_FOR_DEVICE}/${deviceType}`,
        "get"
      );
      const rootData = res?.data?.data;

      if (rootData && rootData.layout) {
        setLayoutData(rootData);
        setShowTabs(false);
      } else {
        setLayoutData(null);
        setShowTabs(true);
      }
      // if (rootData && rootData.layout) {
      //   setLayoutData(rootData);

      //   const parsedLayout =
      //     typeof rootData.layout === "string"
      //       ? JSON.parse(rootData.layout)
      //       : rootData.layout;

      //   const selectedSection =
      //     selectedDialog === "CONFIGURATION"
      //       ? parsedLayout.configuration
      //       : parsedLayout.status;

      //   if (!selectedSection || selectedSection.length === 0) {
      //     setTabs([
      //       {
      //         name:
      //           selectedDialog === "CONFIGURATION" ? "Configuration" : "Status",
      //       },
      //     ]);

      //     setShowTabs(true);
      //   } else {
      //     setShowTabs(false);
      //   }
      // } else {
      //   setLayoutData(null);

      //   setTabs([
      //     {
      //       name:
      //         selectedDialog === "CONFIGURATION" ? "Configuration" : "Status",
      //     },
      //   ]);

      //   setShowTabs(true);
      // }
    } catch (err) {
      Toast("Error!", `Layout fetch failed`, "error");
      setLayoutData(null);
      setShowTabs(true);
    }
  };

  const handleTabCountChange = (value) => {
    const count = Number(value?.target ? value.target.value : value);
    setTabCount(count);
    setTabs(Array.from({ length: count }, () => ({ name: "" })));
  };

  const handleTabNameChange = (index, value) => {
    const updated = [...tabs];
    updated[index].name = value?.target ? value.target.value : value;
    setTabs(updated);
  };

  const moveToExcel = () => {
    if (showTabs && tabs.length === 0) return;
    setStep(STEP.EXCEL);
  };

  return (
    <Box
      sx={{
        border: "1px solid #ddd",
        borderRadius: 3,
        p: 2,
        //background: "#fafafa",
      }}
    >
      {step === STEP.SELECT && (
        <>
          <Grid
            container
            spacing={3}
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))",
            }}
          >
            <MAlarmSelect
              label="Terminal Type"
              options={terminalTypes}
              value={selectedTerminalId}
              onChange={handleTerminalChange}
              multiple={false}
              isDark={isDark}
            />
            <MAlarmSelect
              label="Dialog Type"
              options={dialogTypes}
              value={selectedDialog}
              onChange={setSelectedDialog}
              multiple={false}
              isDark={isDark}
            />
            <MAlarmSelect
              label="Device"
              options={devices}
              value={selectedDeviceId}
              onChange={handleDeviceChange}
              multiple={false}
              isDark={isDark}
            />
          </Grid>

          {showTabs && (
            <Box sx={{ mt: 2, p: 1, 
            //background: "#fff", 
            borderRadius: 2 }}>
              <Typography fontWeight={600} mb={1}>
                No Layout Found - Create Tabs
              </Typography>
              <MInput
                type="number"
                value={tabCount}
                onChange={handleTabCountChange}
                placeholder="Number of Tabs"
              />
              <Grid container spacing={2} mt={1}>
                {tabs.map((t, i) => (
                  <Grid item xs={12} md={4} key={i}>
                    <MInput
                      value={t.name}
                      placeholder={`Tab ${i + 1}`}
                      onChange={(e) => handleTabNameChange(i, e)}
                    />
                  </Grid>
                ))}
              </Grid>
            </Box>
          )}

          <Box sx={{ mt: 2, display: "flex", justifyContent: "flex-end" }}>
            <MButtonPrimary disabled={!selectedDeviceId} onClick={moveToExcel}>
              NEXT
            </MButtonPrimary>
          </Box>
        </>
      )}

      {step === STEP.EXCEL && (
        <ExcelConfigBuilder
          selectedDevice={selectedDevice?.raw}
          selectedTerminal={selectedTerminal?.raw}
          tabs={tabs}
          layoutData={layoutData}
          dialogType={selectedDialog}
          isStatusView={selectedDialog === "STATUS"}
          liveStatusData={liveStatusData}
          activeTabIdx={activeTabIdx}
          setActiveTabIdx={setActiveTabIdx}
          onBack={() => setStep(STEP.SELECT)}
          onLayoutSaved={(savedLayout) => {
            setLayoutData(savedLayout);
          }}
        />
      )}
    </Box>
  );
};

export default SNMPDashboard;
