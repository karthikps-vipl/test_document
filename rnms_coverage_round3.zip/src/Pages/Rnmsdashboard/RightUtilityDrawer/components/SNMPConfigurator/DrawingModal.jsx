import React from "react";
import MModal from "@/components/Reusable/Modal/MModal";
import { Box, Typography } from "@mui/material";

const DrawingModal = ({ open, onClose, payload }) => {
  return (
    <MModal open={open} handleClose={onClose} fullWidth enableFullScreen>
      <Box sx={{ height: "80vh" }}>
        <Typography variant="h6">Drawing Canvas</Typography>

        <pre style={{ fontSize: "12px" }}>
          {JSON.stringify(payload, null, 2)}
        </pre>
      </Box>
    </MModal>
  );
};

export default DrawingModal;
