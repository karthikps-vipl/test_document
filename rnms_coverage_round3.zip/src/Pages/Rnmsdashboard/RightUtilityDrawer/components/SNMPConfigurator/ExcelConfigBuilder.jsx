import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Typography,
  Button,
  Grid,
  Card,
  IconButton,
  Tooltip,
  Tabs,
  Tab,
  Switch,
  useTheme,
} from "@mui/material";
import GridLayout from "react-grid-layout";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import Chip from "@mui/material/Chip";
import * as XLSX from "xlsx";

import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MInput from "@/components/Reusable/Input/MInput";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { WIDGET_REGISTRY, AVAILABLE_WIDGETS } from "./widgets/WidgetRegistry23";
import WidgetRenderer from "../../../RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRenderer";
import {
  FETCH_OID_MAPPING,
  SAVE_DEVICE_LAYOUT,
  UPDATE_DEVICE_LAYOUT,
} from "@/RestAPI/url/endpoint";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import deletes from "@/assets/SVGIcons/delete.svg";
import Edit_Icon from "@/assets/SVGIcons/Edit_Icon.svg";
import Toast from "@/components/Reusable/Toast/Toast";
import { ChevronLeftIcon, ChevronRightIcon } from "lucide-react";
import MModal from "@/components/Reusable/Modal/MModal";
import { EditDocument } from "@mui/icons-material";

const ExcelConfigBuilder = ({
  selectedDevice,
  selectedTerminal,
  tabs = [],
  layoutData = null,
  dialogType,
  onBack,
  liveStatusData,
  onLayoutSaved,
  setActiveTabId,
  activeTabIdx,
  setActiveTabIdx,
}) => {
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';
  const [parsedOids, setParsedOids] = useState([]);
  const [currentSelectedOids, setCurrentSelectedOids] = useState([]);
  const [currentSelectedWidgetType, setCurrentSelectedWidgetType] =
  useState("");
  // const [activeTabIdx, setActiveTabIdx] = useState(0);
  
  const [layoutId, setLayoutId] = useState(null);
  const [isUpdateMode, setIsUpdateMode] = useState(false);
  
  const [availableTabsList, setAvailableTabsList] = useState([]);
  const [tabbedWidgetsData, setTabbedWidgetsData] = useState({});
  
  console.log("tabbedWidgetsData", tabbedWidgetsData);
  
  // Queue state for holding widgets before committing them all to the layout canvas
  const [widgetQueue, setWidgetQueue] = useState([]);
  
  const [widgetMetaFields, setWidgetMetaFields] = useState({
    gridTitle: "",
    numColumns: "3",
    commonLabel: "",
  });
  const [dialogMode, setDialogMode] = useState(""); // editOid | editTitle
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingWidgetKey, setEditingWidgetKey] = useState(null);
  const [selectedWidgetKey, setSelectedWidgetKey] = useState("");
  const [selectedOidIndex, setSelectedOidIndex] = useState(null);
  
  const [editedName, setEditedName] = useState("");
  const [editedOid, setEditedOid] = useState("");
  
  const [editedTitle, setEditedTitle] = useState("");
  
  const [isEditingTabName, setIsEditingTabName] = useState(false);
  const [editedTabName, setEditedTabName] = useState("");
  
  const activeTabName =
  availableTabsList[activeTabIdx]?.name || `Tab ${activeTabIdx + 1}`;
  const currentWidgetsCollection =
  tabbedWidgetsData[activeTabIdx]?.widgets || [];
  
  const currentCanvasNodes = tabbedWidgetsData[activeTabIdx]?.layout || [];
  
  // const safeLayout = currentCanvasNodes.map((item) => ({
  //   ...item,
  //   y: Math.min(item.y, 100),
  //   h: Math.min(item.h, 50),
  // }));

  const canvasRef = useRef(null);
  const [canvasWidth, setCanvasWidth] = useState(1200);
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const observer = new ResizeObserver((entries) => {
      for (let entry of entries) {
        setCanvasWidth(entry.contentRect.width);
      }
    });
    
    observer.observe(canvasRef.current);
    
    return () => observer.disconnect();
  }, []);
  
  const scrollContainerRef = useRef(null);
  
  const handleScroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = 311; // Card width (295) + gap (16)
      scrollContainerRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };
  useEffect(() => {
    if (layoutData?.layout) {
      setIsUpdateMode(true);
      
      if (layoutData.layoutId) {
        setLayoutId(layoutData.layoutId);
      }
      
      hydrateIncomingSchema(layoutData);
      
      return;
    }
    
    if (!layoutData && tabs?.length) {
      setIsUpdateMode(false);
      setLayoutId(null);
      
      const initialTabs = tabs.map((t) => ({
        name: t.name,
      }));
      
      setAvailableTabsList(initialTabs);
      
      const emptyTabs = {};
      
      initialTabs.forEach((tab, index) => {
        emptyTabs[index] = {
          widgets: [],
          layout: [],
          oids: {
            table: {},
            static: [],
          },
        };
      });
      
      setTabbedWidgetsData(emptyTabs);
      
      setActiveTabIdx(0);
    }
  }, [layoutData, dialogType]);
  
  const hydrateIncomingSchema = async (rawLayoutPayload) => {
    try {
      // 1. Safely extract the master layout container
      const parsed =
      typeof rawLayoutPayload?.layout === "string"
      ? JSON.parse(rawLayoutPayload.layout)
      : rawLayoutPayload?.layout || { configuration: [], status: [] };
      
      // 2. TARGET THE SPECIFIC SECTION INDEPENDENTLY 🎯
      const selectedSection =
      dialogType === "CONFIGURATION"
      ? parsed.configuration || []
      : parsed.status || [];
      
      if (!selectedSection || selectedSection.length === 0) {
        setAvailableTabsList([]);
        setTabbedWidgetsData({});
        return; // Stop execution here so it shows the clean creation screens
      }
      
      // 3. Otherwise, if data DOES exist for this side, build the canvas tabs smoothly
      const tabsFromServer = selectedSection.map((tab) => ({
        name:
        tab.name ||
        (dialogType === "CONFIGURATION" ? "Configuration" : "Status"),
      }));
      
      const widgetState = {};
      selectedSection.forEach((tab, index) => {
        widgetState[index] = {
          widgets: tab.widget || [],
          layout: (tab.layout || []).map((node, index) => {
            const widget = tab.widget?.[index];
            console.log(node, "jnjnjnjnggggd");
            
            return {
              i: node.i || `${widget?.type}-${index}`,
              
              x: Number(node.x),
              
              y: Number(node.y),
              
              w: Number(node.w),
              
              h: Number(node.h),
              
              moved: false,
              
              static: false,
            };
          }),
          oids: tab.oids || { table: {}, static: [] },
        };
      });
      
      setAvailableTabsList(tabsFromServer);
      setTabbedWidgetsData(widgetState);
      
      // --- Keep your FETCH_OID_MAPPING loops below here completely untouched ---
      const allStaticOids = [];
      Object.values(widgetState).forEach((tab) => {
        (tab.oids?.static || []).forEach((oid) => {
          if (!allStaticOids.includes(oid)) {
            allStaticOids.push(oid);
          }
        });
      });
      
      if (allStaticOids.length) {
        const response = await ConfigurationAxios(
          FETCH_OID_MAPPING,
          "post",
          allStaticOids
        );
        const apiResponseArray = response?.data || response || [];
        
        setTabbedWidgetsData((prevStates) => {
          const updatedStates = { ...prevStates };
          Object.keys(updatedStates).forEach((tabIdx) => {
            updatedStates[tabIdx].widgets = updatedStates[tabIdx].widgets.map(
              (widget) => {
                if (widget.type === "editableSelect") {
                  const extractedMap = {};
                  widget.data?.forEach((field) => {
                    const match = Array.isArray(apiResponseArray)
                    ? apiResponseArray.find(
                      (item) => item.oidName === field.oid
                    )
                    : null;
                    if (match && match.operator_map) {
                      extractedMap[field.oid] = parseOperatorMap(
                        match.operator_map
                      );
                    }
                  });
                  return { ...widget, selectWidgetMap: extractedMap };
                }
                return widget;
              }
            );
          });
          return updatedStates;
        });
      }
    } catch (error) {
      Toast("Error", `Layout hydration failed`, "error");
    }
  };
  /* --- EXCEL READER --- */
  
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const workbook = XLSX.read(evt.target.result, { type: "binary" });
      const sheet = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheet];
      const rawRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      
      const formatted = rawRows
      .map((row) => {
        const nameField = row[0] ? String(row[0]).trim() : "";
        const oidField = row[1] ? String(row[1]).trim() : "";
        
        return {
          label:
          nameField && oidField
          ? `${nameField} (${oidField})`
          : nameField || oidField,
          value: oidField,
          rawName: nameField,
        };
      })
      .filter((x) => {
        if (!x.value || x.value === "") return false;
        const isOID = /\d/.test(x.value);
        return isOID;
      });
      
      setParsedOids(formatted);
      console.log("Parsed OIDs:", formatted);
    };
    reader.readAsBinaryString(file);
  };
  const handleAddTab = () => {
    const newIdx = availableTabsList.length;
    const nextTabObj = { name: `Tab ${newIdx + 1}` };
    
    setAvailableTabsList((prev) => [...prev, nextTabObj]);
    setTabbedWidgetsData((prev) => ({
      ...prev,
      [newIdx]: {
        widgets: [],
        layout: [],
        oids: { table: {}, static: [] },
      },
    }));
    setActiveTabIdx(newIdx);
  };

  const handleStartRenameTab = () => {
    setEditedTabName(activeTabName);
    setIsEditingTabName(true);
  };

  const handleSaveTabName = () => {
    if (!editedTabName.trim()) return;
    setAvailableTabsList((prev) => {
      const copy = [...prev];
      copy[activeTabIdx] = {
        ...copy[activeTabIdx],
        name: editedTabName.trim(),
      };
      return copy;
    });
    setIsEditingTabName(false);
  };

  const handleDeleteTab = () => {
    if (availableTabsList.length <= 1) {
      // alert("At least one tab must remain active inside the layout workspace.");
      Toast(
        "Information",
        "At least one tab must remain active inside the layout workspace.",
        "info"
      );
      return;
    }
    if (
      !window.confirm(
        `Are you sure you want to drop "${activeTabName}"? This clears its custom elements layout context.`
      )
    )
      return;

    const nextTabsList = availableTabsList.filter(
      (_, idx) => idx !== activeTabIdx
    );

    const nextWidgetsState = {};
    let cursor = 0;
    availableTabsList.forEach((_, idx) => {
      if (idx !== activeTabIdx) {
        nextWidgetsState[cursor] = tabbedWidgetsData[idx] || {
          widgets: [],
          layout: [],
          oids: { table: {}, static: [] },
        };
        cursor++;
      }
    });

    setAvailableTabsList(nextTabsList);
    setTabbedWidgetsData(nextWidgetsState);
    setActiveTabIdx((prev) =>
      prev >= nextTabsList.length ? nextTabsList.length - 1 : prev
    );
  };

  const handleMetaFieldChange = (fieldId, value) => {
    setWidgetMetaFields((prev) => ({ ...prev, [fieldId]: value }));
  };

  /* --- DYNAMIC GENERATOR OBJECT HELPER --- */
  const buildWidgetObject = ({ isQueue }) => {
    const widgetTemplate = WIDGET_REGISTRY[currentSelectedWidgetType];
    let compositeDataArray = [];

    if (currentSelectedWidgetType === "thermometer") {
      console.log(widgetQueue, "widgetQueueasasas");

      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          name: match?.rawName || "Metric",
        };
      });

      const mapForDisplay = {
        name: widgetMetaFields.thermometerNameOid,

        value: widgetMetaFields.thermometerValueOid,
        state: widgetMetaFields.thermometerStateOid,
      };

      return {
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "Thermometer widget",
        data: compositeDataArray,
        mapForDisplay,
        resourceId: "",
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),
        cols: String(widgetMetaFields.numColumns || "3"),
        commonLabel: widgetMetaFields.commonLabel,

        _defaultWidth: widgetTemplate?.defaultWidth || 16,
        _defaultHeight: widgetTemplate?.defaultHeight || 16,
        _selectedOids: [...currentSelectedOids],
      };
    } else if (currentSelectedWidgetType === "needelGauge") {
      console.log(oidSettings, "skjdhfkjshdfjk");

      console.log(currentSelectedOids, "currentSelectedOids");

      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);

        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          name: match?.rawName || "Metric",
          ...(!isQueue &&
            widgetQueue.length > 0 && {
              hybrid: widgetQueue,
            }),

          ...(!!widgetMetaFields?.conditionalEdit &&
            oidSettings[oidVal]?.type === "number" && {
              inpType: oidSettings[oidVal].type,
              min: oidSettings[oidVal].min,
              max: oidSettings[oidVal].max,
            }),
          ...(!!widgetMetaFields?.conditionalEdit &&
            oidSettings[oidVal]?.type === "text" && {
              inpType: oidSettings[oidVal].type,
            }),
        };
      });

      console.log(widgetMetaFields, "asasdffdtvbvb");
      let isDynamic = widgetMetaFields.gaugeRangePreset === "dynamic";

      let displayFactor;
      let conditionalEdit = !!widgetMetaFields.conditionalEdit;
      if (isDynamic) {
        let customValue = widgetMetaFields.customRangeX;

        if (customValue != 0) {
          displayFactor = parseFloat(customValue) / 180;
        }
      }

      return {
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "System Parameter Gauge",
        data: compositeDataArray,
        resourceId: "",
        // Inject needle properties cleanly into the tracking structure object state records
        ...(isDynamic
          ? {
              displayFactor: displayFactor,
              conditionalEdit: conditionalEdit,
            }
          : { gaugeType: widgetMetaFields.gaugeRangePreset }),
        cols: String(widgetMetaFields.numColumns || "3"),
        rangePreset: widgetMetaFields.gaugeRangePreset,
        commonLabel: widgetMetaFields.commonLabel,
        customRangeX: widgetMetaFields.customRangeX,

        _defaultWidth: widgetTemplate?.defaultWidth || 16,
        // _defaultHeight: widgetTemplate?.defaultHeight || 16,
        _selectedOids: [...currentSelectedOids],
      };
    } else if (currentSelectedWidgetType === "fan") {
      // Route the 2 specific selection points assigned within the builder interface

      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          name: match?.rawName || "Metric",
        };
      });

      const mapForDisplay = {
        name: widgetMetaFields?.fanNameOid,

        value: "",
        state: widgetMetaFields?.fanStateOid,
      };

      return {
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "Fan widget",
        mapForDisplay,
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),
        data: compositeDataArray,
        resourceId: selectedDevice?.resourceId,
        cols: String(widgetMetaFields.numColumns || "3"),
        commonLabel: widgetMetaFields.commonLabel,
        _defaultWidth: widgetTemplate?.defaultWidth || 12,
        // _defaultHeight: widgetTemplate?.defaultHeight || 18,
        _selectedOids: [...currentSelectedOids],
      };
    } else if (currentSelectedWidgetType === "editable") {
      const targetKeys = currentSelectedOids || [];

      compositeDataArray = targetKeys.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);

        return {
          displayName: `${match?.rawName || "Field Parameter"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          name: match?.rawName || `OID_${oidVal}`,
          currentValue: match?.currentValue ?? null,
        };
      });

      return {
        type: currentSelectedWidgetType,

        tableTitle: widgetMetaFields.gridTitle || "Parameter Controls Grid",

        data: compositeDataArray,
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),

        resourceId: "",

        columns: widgetMetaFields.columns || "1",

        commonLabel: widgetMetaFields.commonLabel || "",

        oidConfigs: widgetMetaFields.oidConfigs || {},

        _defaultWidth: widgetTemplate?.defaultWidth || 36,

        _defaultHeight: widgetTemplate?.defaultHeight || 14,

        _selectedOids: [...currentSelectedOids],
      };
    } else if (currentSelectedWidgetType === "voltageGauge") {
      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          name: match?.rawName || "Metric",
        };
      });

      const mapForDisplay = {
        name: widgetMetaFields.voltageNameOid,

        state: widgetMetaFields.voltageStateOid,
        value: widgetMetaFields.voltageValueOid,
      };

      return {
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "Voltage Gauge widget",
        mapForDisplay,
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),
        data: compositeDataArray,
        resourceId: selectedDevice?.resourceId,
        cols: String(widgetMetaFields.numColumns || "3"),
        commonLabel: widgetMetaFields.commonLabel,
        _defaultWidth: widgetTemplate?.defaultWidth || 12,
        // _defaultHeight: widgetTemplate?.defaultHeight || 18,
        _selectedOids: [...currentSelectedOids],
      };
    }
    // 👇 POWER SUPPLY STATUS BUILDER PATHWAY ADDITION 👇
    else if (currentSelectedWidgetType === "powerSupply") {
      const targetKeys = [
        widgetMetaFields.powerNameOid,
        widgetMetaFields.powerStateOid,
        widgetMetaFields.powerValueOid,
      ];
      compositeDataArray = targetKeys.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Power Metric"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          ...(!isQueue &&
            widgetQueue.length > 0 && {
              hybrid: widgetQueue,
            }),
          name: match?.rawName || "Metric",
          currentValue: match?.currentValue ?? null,
        };
      });
    } else if (currentSelectedWidgetType === "scale") {
      const valueOid = widgetMetaFields.scaleValueOid;

      const match = parsedOids.find((item) => item.value === valueOid);

      compositeDataArray = [
        {
          displayName: `${match?.rawName || "Scale Value"} ${valueOid}`,

          oid: valueOid || "N/A",

          name: match?.rawName || "Scale Value",
        },
      ];

      return {
        type: "scale",

        tableTitle: widgetMetaFields.gridTitle || "Scale",

        data: compositeDataArray,

        resourceId: "",
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),

        range: {
          min: widgetMetaFields.minVal || "-100",

          max: widgetMetaFields.maxVal || "100",
        },

        cols: String(widgetMetaFields.numColumns || "3"),

        commonLabel: widgetMetaFields.commonLabel || "",

        _defaultWidth: widgetTemplate?.defaultWidth || 8,

        _defaultHeight: widgetTemplate?.defaultHeight || 18,

        _selectedOids: valueOid ? [valueOid] : [],
      };
    } else if (currentSelectedWidgetType === "titleWidget") {
      console.log(widgetMetaFields, "widgetMetaFieldstitleWidget");

      compositeDataArray = [
        {
          titleWidgetContent: widgetMetaFields.titleWidget,
        },
      ];
    } else if (currentSelectedWidgetType === "remoteDevice") {
      const showVehicleHeading = widgetMetaFields.showVehicleHeading;
      const isEditable = widgetMetaFields.remoteDevicesIsEditable;
      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal}`,
          oid: oidVal,
          name: match?.rawName || "Metric",
        };
      });

      return {
        showVehicleHeading: showVehicleHeading,
        isEditable: isEditable,
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "Widget",
        data: compositeDataArray,
        resourceId: "",
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),
        cols: String(widgetMetaFields.numColumns || "3"),
        commonLabel: widgetMetaFields.commonLabel,
        _defaultWidth: widgetTemplate?.defaultWidth || 12,
        _defaultHeight: widgetTemplate?.defaultHeight || 18,
        _selectedOids: [...currentSelectedOids],
      };
    } else if (currentSelectedWidgetType === "image") {
      const image = widgetMetaFields.images;
      const width = widgetMetaFields.width;
      const height = widgetMetaFields.height;
      const nameOid = widgetMetaFields.name;
      const adminOid = widgetMetaFields.admin;
      const operationOid = widgetMetaFields.oprtation;
      const descriptionOid = widgetMetaFields.description;
      const series = widgetMetaFields.series;
      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal}`,
          oid: oidVal,
          name: match?.rawName || "Metric",
        };
      });

      const mapForDisplay = {
        name: nameOid,
        admin: adminOid,
        operation: operationOid,
        description: descriptionOid,
      };

      return {
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "Image widget",
        image,
        mapForDisplay,
        width,
        height,
        // nameOid,
        // adminOid,
        // operationOid,
        // descriptionOid,
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),
        series,
        data: compositeDataArray,
        resourceId: selectedDevice?.resourceId,
        cols: String(widgetMetaFields.numColumns || "3"),
        commonLabel: widgetMetaFields.commonLabel,
        _defaultWidth: widgetTemplate?.defaultWidth || 12,
        // _defaultHeight: widgetTemplate?.defaultHeight || 18,
        _selectedOids: [...currentSelectedOids],
      };
    } else if (currentSelectedWidgetType === "editableSelect") {
      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Field"} ${oidVal || ""}`,
          oid: oidVal || "N/A",
          name: match?.rawName || `OID_${oidVal}`,
          currentValue: match?.currentValue ?? "",
        };
      });

      return {
        type: currentSelectedWidgetType,
        tableTitle: widgetMetaFields.gridTitle || "Select Controls Grid",
        data: compositeDataArray,
        resourceId: "",
        ...(!isQueue &&
          widgetQueue.length > 0 && {
            hybrid: widgetQueue,
          }),
        cols: widgetMetaFields.numColumns || "1", // Maps straight into standard parseInt(widget.cols) layout calculations
        commonLabel: widgetMetaFields.commonLabel || "",
        selectWidgetMap: {}, // This map container gets filled inside your async handlers below
        _defaultWidth: widgetTemplate?.defaultWidth || 36,
        _defaultHeight: widgetTemplate?.defaultHeight || 25,
        _selectedOids: [...currentSelectedOids],
      };
    } else {
      // Standard mapping fallback for your original verticalTable widget
      compositeDataArray = currentSelectedOids.map((oidVal) => {
        const match = parsedOids.find((o) => o.value === oidVal);
        return {
          displayName: `${match?.rawName || "Metric"} ${oidVal}`,
          oid: oidVal,
          name: match?.rawName || "Metric",
        };
      });
    }

    return {
      type: currentSelectedWidgetType,
      tableTitle: widgetMetaFields.gridTitle || "Widget",
      data: compositeDataArray,
      ...(!isQueue &&
        widgetQueue.length > 0 && {
          hybrid: widgetQueue,
        }),
      resourceId: selectedDevice?.resourceId,
      cols: String(widgetMetaFields.numColumns || "3"),
      commonLabel: widgetMetaFields.commonLabel,
      _defaultWidth: widgetTemplate?.defaultWidth || 12,
      // _defaultHeight: widgetTemplate?.defaultHeight || 18,
      _selectedOids: [...currentSelectedOids],
    };
  };
  const parseOperatorMap = (operatorMapStr) => {
    if (!operatorMapStr) return {};
    const map = {};
    // Splits "1:ON,0:OFF" by commas into ["1:ON", "0:OFF"]
    operatorMapStr.split(",").forEach((pair) => {
      const [key, value] = pair.split(":");
      if (key !== undefined && value !== undefined) {
        map[key.trim()] = value.trim();
      }
    });
    return map;
  };

  const clearConfigFields = () => {
    setCurrentSelectedOids([]);
    setCurrentSelectedWidgetType("");
    setWidgetMetaFields({
      gridTitle: "",
      numColumns: "3",
      commonLabel: "",
      minVal: "",
      maxVal: "",
      scaleValueOid: "",
    });
  };
  const getWidgetHeight = (item) => {
    if (!item?.type) return 6;

    // Static widgets should auto fit based on fields
    if (item.type === "static") {
      const fieldCount = item.data?.length || 1;

      const columns = Number(item.cols) || 3;

      const rows = Math.ceil(fieldCount / columns);

      return Math.min(Math.max(rows * 2, 6), 12);
    }

    if (item.type === "hybrid") {
      return item.children.length * 8;
    }

    const compactWidgets = ["editable", "staticForm", "configForm"];

    if (compactWidgets.includes(item.type)) {
      return 4;
    }

    return (
      item._defaultHeight || WIDGET_REGISTRY[item.type]?.defaultHeight || 6
    );
  };

  /* --- CANVAS LAYOUT POSITIONING REUSABLE ACTION --- */
  const pushItemsToCanvas = (itemsArray) => {
    setTabbedWidgetsData((prev) => {
      const currentTabState = prev[activeTabIdx] || {
        widgets: [],
        layout: [],
        oids: { table: {}, static: [] },
      };

      let currentWidgets = [...currentTabState.widgets];
      let currentLayout = [...currentTabState.layout];
      let currentStaticOids = [...(currentTabState.oids?.static || [])];

      itemsArray.forEach((item, idx) => {
        const uniqueId = `${item.type}-${Date.now()}-${idx}`;
        const {
          _defaultWidth,
          // _defaultHeight,
          _selectedOids,
          ...cleanWidgetConfig
        } = item;

        // const dynamicY = currentLayout.reduce(
        //   (max, node) => Math.max(max, node.y + node.h),
        //   0
        // );

        const colWidth = 12;
        const x = (currentWidgets.length * colWidth) % 36;
        const y = Math.floor((currentWidgets.length * colWidth) / 36) * 6;

        const newLayoutNode = {
          i: uniqueId,
          x,
          y,
          w: Math.min(Math.round(_defaultWidth / (canvasWidth / 36)), 36),
          h: getWidgetHeight(item), // ✅ IMPORTANT FIX
          moved: false,
          static: false,
        };
        currentWidgets.push({
          ...cleanWidgetConfig,
          _defaultHeight: getWidgetHeight(item),
          _defaultWidth: _defaultWidth,
        });
        currentLayout.push(newLayoutNode);
        currentStaticOids = [
          ...new Set([...currentStaticOids, ..._selectedOids]),
        ];
      });

      return {
        ...prev,
        [activeTabIdx]: {
          widgets: currentWidgets,
          layout: currentLayout,
          oids: { ...currentTabState.oids, static: currentStaticOids },
        },
      };
    });
  };

  const handleAddDirectlyToCanvas = async () => {
    if (currentSelectedOids.length === 0 || !currentSelectedWidgetType) return;

    let directWidget = buildWidgetObject({ isQueue: false });

    if (currentSelectedWidgetType === "editableSelect") {
      const targetOids = directWidget._selectedOids;
      try {
        const response = await ConfigurationAxios(
          FETCH_OID_MAPPING,
          "post",
          targetOids
        );
        const apiResponseArray = response?.data || response || [];

        const extractedMap = {};
        if (Array.isArray(apiResponseArray)) {
          apiResponseArray.forEach((item) => {
            if (item.operation === "map" && item.operator_map) {
              // Convert "1:ON,0:OFF" -> {"1": "ON", "0": "OFF"}
              extractedMap[item.oidName] = parseOperatorMap(item.operator_map);
            }
          });
        }

        directWidget.selectWidgetMap = extractedMap;
      } catch (error) {
        console.error(
          "Failed to map array response options to selectWidgetMap:",
          error
        );
      }
    }

    pushItemsToCanvas([directWidget]);
    clearConfigFields();
    setWidgetQueue([]);
  };

  const handleAddToGridQueue = async () => {
    if (currentSelectedOids.length === 0 || !currentSelectedWidgetType) return;

    let queuedWidget = buildWidgetObject({ isQueue: true });

    if (currentSelectedWidgetType === "editableSelect") {
      const targetOids = queuedWidget._selectedOids;
      try {
        const response = await ConfigurationAxios(
          FETCH_OID_MAPPING,
          "post",
          targetOids
        );
        const apiResponseArray = response?.data || response || [];

        const extractedMap = {};
        if (Array.isArray(apiResponseArray)) {
          apiResponseArray.forEach((item) => {
            if (item.operation === "map" && item.operator_map) {
              extractedMap[item.oidName] = parseOperatorMap(item.operator_map);
            }
          });
        }

        queuedWidget.selectWidgetMap = extractedMap;
      } catch (error) {
        console.error(
          "Failed to map array response options to selectWidgetMap in queue:",
          error
        );
      }
    }

    setWidgetQueue((prev) => [...prev, queuedWidget]);
    clearConfigFields();
  };

  /* --- FLUSH ALL BUFFER ELEMENTS --- */
  const handleFlushQueueToLayout = () => {
    if (widgetQueue.length === 0) return;
    const groupedWidget = {
      type: "hybrid",

      tableTitle: "Grouped Widgets",

      children: [...widgetQueue],

      _defaultWidth: 36,

      _defaultHeight: widgetQueue.length * 8,

      _selectedOids: widgetQueue.flatMap((item) => item._selectedOids || []),
    };

    pushItemsToCanvas([groupedWidget]);

    setWidgetQueue([]);
  };

  /* --- EDIT QUEUED ITEM --- */
  const handleEditQueuedItem = (queueIndex) => {
    const itemToEdit = widgetQueue[queueIndex];
    setCurrentSelectedWidgetType(itemToEdit.type);
    setCurrentSelectedOids(itemToEdit._selectedOids);
    setWidgetMetaFields({
      gridTitle: itemToEdit.tableTitle,
      numColumns: itemToEdit.cols,
      commonLabel: itemToEdit.commonLabel,
    });
    handleDeleteQueuedItem(queueIndex);
  };

  const handleDeleteQueuedItem = (queueIndex) => {
    setWidgetQueue((prev) => prev.filter((_, idx) => idx !== queueIndex));
  };

  // const handleInputValueChange = (widgetIdx, dataIdx, val) => {
  //   setTabbedWidgetsData((prev) => {
  //     const activeTabState = {
  //       ...prev[activeTabIdx],
  //     };

  //     const widget = activeTabState.widgets[widgetIdx];

  //     if (!widget) return prev;

  //     if (typeof dataIdx === "string" && dataIdx.startsWith("val_")) {
  //       widget[dataIdx] = val;
  //     } else if (widget.data?.[dataIdx]) {
  //       widget.data[dataIdx].currentValue = val;
  //     }

  //     return {
  //       ...prev,
  //       [activeTabIdx]: activeTabState,
  //     };
  //   });
  // };

  const handleEditableSelectChange = (
    parentWidgetIdx,
    hybridIdx,
    dataIdx,
    val
  ) => {
    setTabbedWidgetsData((prev) => {
      const activeTabState = {
        ...prev[activeTabIdx],
        widgets: [...(prev[activeTabIdx]?.widgets || [])],
      };

      const parentWidget = activeTabState.widgets[parentWidgetIdx];

      if (!parentWidget) return prev;

      const hybrid = parentWidget.hybrid?.[hybridIdx];

      if (!hybrid) return prev;

      const updatedHybrid = {
        ...hybrid,
      };

      if (typeof dataIdx === "string" && dataIdx.startsWith("val_")) {
        updatedHybrid[dataIdx] = val;
      } else if (updatedHybrid.data?.[dataIdx]) {
        updatedHybrid.data = [...updatedHybrid.data];

        updatedHybrid.data[dataIdx] = {
          ...updatedHybrid.data[dataIdx],
          currentValue: val,
        };
      }

      const updatedHybridArray = [...parentWidget.hybrid];

      updatedHybridArray[hybridIdx] = updatedHybrid;

      activeTabState.widgets[parentWidgetIdx] = {
        ...parentWidget,
        hybrid: updatedHybridArray,
      };

      return {
        ...prev,
        [activeTabIdx]: activeTabState,
      };
    });
  };

  const handleInputValueChange = (
    widgetIdx,
    dataIdx,
    val,
    targetWidget = null
  ) => {
    setTabbedWidgetsData((prev) => {
      const activeTabState = {
        ...prev[activeTabIdx],
        widgets: [...(prev[activeTabIdx]?.widgets || [])],
      };

      const widget = targetWidget
        ? targetWidget
        : activeTabState.widgets[widgetIdx];

      if (!widget) return prev;

      const updatedWidget = {
        ...widget,
      };

      if (typeof dataIdx === "string" && dataIdx.startsWith("val_")) {
        updatedWidget[dataIdx] = val;
      } else if (updatedWidget.data?.[dataIdx]) {
        updatedWidget.data = [...updatedWidget.data];

        updatedWidget.data[dataIdx] = {
          ...updatedWidget.data[dataIdx],
          currentValue: val,
        };
      }

      // If this is a top-level widget
      if (!targetWidget) {
        activeTabState.widgets[widgetIdx] = updatedWidget;
      }

      return {
        ...prev,
        [activeTabIdx]: activeTabState,
      };
    });
  };

  const handleLayoutChange = (newLayout) => {
    setTabbedWidgetsData((prev) => {
      if (!prev[activeTabIdx]) return prev;
      const activeTabState = { ...prev[activeTabIdx] };
      activeTabState.layout = newLayout.map((l, idx) => ({
        i: l.i || `static-${idx}`,
        x: l.x,
        y: Math.min(l.y, 100),
        w: l.w,
        h: Math.min(l.h, 50),
        moved: l.moved || false,
        static: false,
      }));
      return { ...prev, [activeTabIdx]: activeTabState };
    });
  };

  const handleDeleteWidgetNode = (targetId, index) => {
    setTabbedWidgetsData((prev) => {
      const activeTabState = { ...prev[activeTabIdx] };
      activeTabState.widgets = activeTabState.widgets.filter(
        (_, idx) => idx !== index
      );
      activeTabState.layout = activeTabState.layout.filter(
        (l) => l.i !== targetId
      );
      return { ...prev, [activeTabIdx]: activeTabState };
    });
  };
  const handleEditWidgetNode = (widgetIdx) => {
    const widget = tabbedWidgetsData?.[activeTabIdx]?.widgets?.[widgetIdx];

    if (!widget) return;

    const widgetType = widget.type;

    // Existing OIDs
    const dataOids = (widget.data || [])
      .map((item) => item?.oid)
      .filter(Boolean)
      .map(String);

    setCurrentSelectedWidgetType(widgetType);
    setCurrentSelectedOids(dataOids);

    // Common widget title
    const meta = {
      ...widget,
      gridTitle: widget.tableTitle || widget.gridTitle || "",
      numColumns: widget.numColumns || widget.cols || "3",
      commonLabel: widget.commonLabel || "",
    };
    Object.keys(widget).forEach((key) => {
      if (
        key !== "data" &&
        key !== "_selectedOids" &&
        key !== "hybrid"
      ) {
        meta[key] = widget[key];
      }
    });

    if (widgetType === "thermometer") {
      meta.thermometerNameOid = widget.mapForDisplay?.name || dataOids[0] || "";

      meta.thermometerStateOid =
        widget.mapForDisplay?.state || dataOids[1] || "";

      meta.thermometerValueOid =
        widget.mapForDisplay?.value || dataOids[2] || "";
    }

    if (widgetType === "fan") {
      meta.fanNameOid = widget.mapForDisplay?.name || dataOids[0] || "";

      meta.fanStateOid = widget.mapForDisplay?.state || dataOids[1] || "";
    }

    if (widgetType === "voltageGauge") {
      meta.voltageNameOid = widget.mapForDisplay?.name || dataOids[0] || "";

      meta.voltageStateOid = widget.mapForDisplay?.state || dataOids[1] || "";

      meta.voltageValueOid = widget.mapForDisplay?.value || dataOids[2] || "";
    }

    if (widgetType === "powerSupply") {
      meta.powerNameOid = widget.mapForDisplay?.name || dataOids[0] || "";

      meta.powerStateOid = widget.mapForDisplay?.state || dataOids[1] || "";

      meta.powerValueOid = widget.mapForDisplay?.value || dataOids[2] || "";
    }

    setWidgetMetaFields(meta);

    setEditingWidgetKey(`${activeTabIdx}-${widgetIdx}`);

    setDialogMode("editWidget");
    setDialogOpen(true);
  };

  const handleEditOid = () => {
    if (!selectedWidget) return;

    const [tabIndex, widgetIndex] = selectedWidgetKey.split("-");

    console.log("bgt", tabIndex, widgetIndex);

    setTabbedWidgetsData((prev) => {
      const updated = { ...prev };

      console.log("DSVFSupdated", updated);

      const tab = { ...updated[tabIndex] };

      const widgets = [...tab.widgets];

      const widget = {
        ...widgets[widgetIndex],
      };

      const data = [...widget.data];

      const target = {
        ...data[selectedOidIndex],
      };

      console.log("displaytarget", target);

      const oldOid = target.oid;

      if (editedName.trim()) {
        target.name = editedName.trim();
      }

      if (editedOid.trim()) {
        target.oid = editedOid.trim();
      }

      // target.displayName = editedName.trim() + editedOid.trim();
      // Join with a single space, then trim
      target.displayName = (editedName + " " + editedOid).trim();

      data[selectedOidIndex] = target;

      widget.data = data;

      widgets[widgetIndex] = widget;

      tab.widgets = widgets;

      if (editedOid.trim()) {
        tab.oids.static = tab.oids.static.map((oid) =>
          oid === oldOid ? editedOid.trim() : oid
        );
      }

      updated[tabIndex] = tab;

      return updated;
    });

    Toast("Success", "OID updated successfully", "success");

    setDialogOpen(false);
  };
  const handleSaveEditedWidget = () => {
    if (!editingWidgetKey) return;

    const [tabIndex, widgetIndex] = String(editingWidgetKey).split("-");

    const tabIdx = Number(tabIndex);
    const widgetIdx = Number(widgetIndex);

    setTabbedWidgetsData((prev) => {
      const updated = { ...prev };

      const tab = {
        ...updated[tabIdx],
      };

      const widgets = [...(tab.widgets || [])];
      const layout = [...(tab.layout || [])];

      const oldWidget = widgets[widgetIdx];

      if (!oldWidget) return prev;

      const widgetType = currentSelectedWidgetType;

      let newOids = [];

      if (widgetType === "thermometer") {
        newOids = [
          widgetMetaFields.thermometerNameOid,
          widgetMetaFields.thermometerStateOid,
          widgetMetaFields.thermometerValueOid,
        ].filter(Boolean);
      } else if (widgetType === "fan") {
        newOids = [
          widgetMetaFields.fanNameOid,
          widgetMetaFields.fanStateOid,
        ].filter(Boolean);
      } else if (widgetType === "voltageGauge") {
        newOids = [
          widgetMetaFields.voltageNameOid,
          widgetMetaFields.voltageStateOid,
          widgetMetaFields.voltageValueOid,
        ].filter(Boolean);
      } else if (widgetType === "powerSupply") {
        newOids = [
          widgetMetaFields.powerNameOid,
          widgetMetaFields.powerStateOid,
          widgetMetaFields.powerValueOid,
        ].filter(Boolean);
      } else {
        // Static / Table / Editable / etc.
        newOids = [...currentSelectedOids];
      }

      const oldDataMap = new Map(
        (oldWidget.data || []).map((item) => [String(item?.oid), item])
      );

      const newData = newOids.map((oidVal) => {
        const oid = String(oidVal);

        const existingItem = oldDataMap.get(oid);

        if (existingItem) {
          return existingItem;
        }

        const match = parsedOids.find((item) => String(item.value) === oid);

        return {
          displayName: `${match?.rawName || "Metric"} ${oid}`,
          oid,
          name: match?.rawName || "Metric",
          currentValue: null,
        };
      });

      let mapForDisplay = oldWidget.mapForDisplay || {};

      if (widgetType === "thermometer") {
        mapForDisplay = {
          name: widgetMetaFields.thermometerNameOid,
          state: widgetMetaFields.thermometerStateOid,
          value: widgetMetaFields.thermometerValueOid,
        };
      } else if (widgetType === "fan") {
        mapForDisplay = {
          name: widgetMetaFields.fanNameOid,
          value: "",
          state: widgetMetaFields.fanStateOid,
        };
      } else if (widgetType === "voltageGauge") {
        mapForDisplay = {
          name: widgetMetaFields.voltageNameOid,
          state: widgetMetaFields.voltageStateOid,
          value: widgetMetaFields.voltageValueOid,
        };
      } else if (widgetType === "powerSupply") {
        mapForDisplay = {
          name: widgetMetaFields.powerNameOid,
          state: widgetMetaFields.powerStateOid,
          value: widgetMetaFields.powerValueOid,
        };
      }



      const updatedWidget = {
        ...oldWidget,

        type: widgetType,

        tableTitle:
          widgetMetaFields.gridTitle || oldWidget.tableTitle || "Widget",

        data: newData,

        mapForDisplay,

        cols: String(widgetMetaFields.numColumns || oldWidget.cols || "3"),

        commonLabel:
          widgetMetaFields.commonLabel ?? oldWidget.commonLabel ?? "",

        _selectedOids: [...newOids],
      };

      if (widgetType === "voltageGauge" || widgetType === "powerSupply") {
        updatedWidget.gridTitle =
          widgetMetaFields.gridTitle ||
          oldWidget.gridTitle ||
          oldWidget.tableTitle ||
          "";
      }

      widgets[widgetIdx] = updatedWidget;

      if (layout[widgetIdx]) {
        layout[widgetIdx] = {
          ...layout[widgetIdx],
          h: getWidgetHeight(updatedWidget),
        };
      }

      updated[tabIdx] = {
        ...tab,
        widgets,
        layout,
      };

      return updated;
    });

    setDialogOpen(false);
    setDialogMode("");
    setEditingWidgetKey(null);

    Toast("Success", "Widget updated successfully", "success");
  };

  const handleEditTitle = () => {
    if (!selectedWidgetKey) return;

    const [tabIndex, widgetIndex] = selectedWidgetKey.split("-");

    setTabbedWidgetsData((prev) => {
      const updated = { ...prev };
      const tab = { ...updated[tabIndex] };
      const widgets = [...tab.widgets];

      // Safely deep copy and update the title
      widgets[widgetIndex] = {
        ...widgets[widgetIndex],
        tableTitle: editedTitle.trim(),
      };

      tab.widgets = widgets;
      updated[tabIndex] = tab;

      return updated;
    });

    Toast("Success", "Title updated successfully", "success");
    setDialogOpen(false);
  };

  const handleSaveLayoutToServer = async () => {
    let existingLayout = { configuration: [], status: [] };

    const aggregatedStatusStructure = availableTabsList.map((tab, idx) => {
      const tabState = tabbedWidgetsData[idx] || {
        widgets: [],
        layout: [],
        oids: {
          table: {},
          static: [],
        },
      };

      const newTab = {
        oids: { table: {}, static: [] },
      };

      const tabularTypes = [
        "table",
        "gridLayout",
        "fan",
        "thermometer",
        "voltageGauge",
        "image",
        "powerSupply",
      ];

      // Helper function to process a single widget and update both oids and tableId
      const processWidgetOids = (widget) => {
        if (tabularTypes.includes(widget?.type)) {
          if (widget?.data && widget.data.length > 0) {
            let sumOfoid = "";
            let arrOfoid = [];

            widget.data.forEach((data) => {
              sumOfoid += String(data.oid) + "_";
              arrOfoid.push(data.oid);
            });

            // Explicitly attach tableId to the widget reference
            widget.tableId = sumOfoid;
            newTab.oids.table[sumOfoid] = arrOfoid;
          }
        } else {
          widget?.data?.forEach((data) => {
            if (data && data.oid && !newTab.oids.static.includes(data.oid)) {
              newTab.oids.static.push(data.oid);
            }
          });
        }
      };

      // Process widgets including hybrid structures and mutate them so tableId is preserved
      const processedWidgets = (tabState.widgets || []).map((widgettype) => {
        // Clone or mutate a shallow copy so we can attach tableId and sanitize data safely
        const clonedWidget = { ...widgettype };

        if (clonedWidget.hybrid && Array.isArray(clonedWidget.hybrid)) {
          clonedWidget.hybrid = clonedWidget.hybrid.map((hybridWidget) => {
            const clonedHybrid = { ...hybridWidget };
            processWidgetOids(clonedHybrid);
            return {
              ...clonedHybrid,
              data: (clonedHybrid.data || []).map(
                ({ currentValue, ...rest }) => rest
              ),
            };
          });
        }

        processWidgetOids(clonedWidget);

        // Sanitize data (remove currentValue) while keeping the newly generated tableId
        clonedWidget.data = (clonedWidget.data || []).map(
          ({ currentValue, ...rest }) => rest
        );

        return clonedWidget;
      });

      return {
        name:
          tab.name ||
          (dialogType === "CONFIGURATION" ? "Configuration" : "Status"),
        widget: processedWidgets,
        oids: newTab.oids,
        layout: tabState.layout || [],
      };
    });

    try {
      if (layoutData?.layout) {
        existingLayout =
          typeof layoutData.layout === "string"
            ? JSON.parse(layoutData.layout)
            : layoutData.layout;
      }
    } catch (e) {
      console.error("Layout parse failed", e);
    }

    const finalLayout = {
      configuration:
        dialogType === "CONFIGURATION"
          ? aggregatedStatusStructure
          : existingLayout.configuration || [],

      status:
        dialogType === "STATUS"
          ? aggregatedStatusStructure
          : existingLayout.status || [],
    };
    const finalPostPayload = {
      layoutId: layoutId || 10,
      // resourceTypeName: selectedDevice?.resourceName?.trim() || "Router",
      resourceTypeName:
        selectedDevice?.imResourceType?.resourceTypeName?.trim() || "NA",
      terminalType: {
        id: selectedTerminal?.id || 9,
      },
      layout: JSON.stringify(finalLayout),
    };

    console.log(
      "Payload Being Sent",
      JSON.parse(JSON.stringify(finalPostPayload))
    );

    const targetUrl = isUpdateMode ? UPDATE_DEVICE_LAYOUT : SAVE_DEVICE_LAYOUT;
    console.log(finalPostPayload, "klkljfdrrerdf");

    try {
      const saveResponse = await ConfigurationAxios(
        targetUrl,
        "post",
        finalPostPayload
      );

      const completeOidList = Object.values(tabbedWidgetsData).reduce(
        (acc, tabState) => {
          const staticOids = tabState?.oids?.static || [];
          staticOids.forEach((oid) => {
            if (!acc.includes(oid)) acc.push(oid);
          });

          return acc;
        },
        []
      );

      if (completeOidList.length > 0) {
        await ConfigurationAxios(FETCH_OID_MAPPING, "post", completeOidList);
      }

      Toast(
        "Success",
        isUpdateMode
          ? "Layout Updated Successfully"
          : "Layout Saved Successfully",
        "success"
      );

      if (!isUpdateMode) {
        setIsUpdateMode(true);
      }
    } catch (err) {
      Toast("Error", `Save failed`, "error");
    }
  };
  // const handleSaveConfigurationWidget = (widget) => {
  //   // alert("sdfsdf");
  //   try {
  //     let payload = [];

  //     // Editable Textfield
  //     if (widget.type === "editable") {
  //       payload = (widget.data || []).map((item) => ({
  //         oid: item.oid,
  //         value: widget[`val_${item.oid}`] ?? "",
  //       }));
  //     }

  //     // Editable Select
  //     if (widget.type === "editableSelect") {
  //       payload = (widget.data || []).map((item) => ({
  //         oid: item.oid,
  //         value: item.currentValue,
  //       }));
  //     }

  //     console.log("SNMP Payload", payload);

  //     const response = ConfigurationAxios(
  //       `${SAVE_SNMP_DATA_FOR_DEVICE}/${selectedDevice?.resourceId}/0`,
  //       "post",
  //       payload
  //     );

  //     Toast(
  //       response?.message || "Configuration updated successfully",
  //       response?.message || "Configuration updated successfully",
  //       response?.status === 1 ? "success" : "error"
  //     );
  //   } catch (err) {
  //     Toast("Error", "Failed to update configuration", "error");

  //     console.error(err);
  //   }
  // };

  // function handleSaveConfigurationWidget() {
  //   alert("sdjfjdsk")
  // }

  const handleSaveConfigurationWidget = async (widget) => {
    try {
      let payload = [];

      const widgetType = widget?.type?.trim();

      // ==========================================
      // EDITABLE + EDITABLE SELECT
      // ==========================================
      if (widgetType === "editable") {
        // 1. Normal editable inputs
        const editablePayload = (widget.data || []).map((item) => ({
          oid: item.oid,
          value: widget[`val_${item.oid}`] ?? item.currentValue ?? "",
        }));

        // 2. Hybrid editableSelect inputs
        const editableSelectPayload = (widget.hybrid || [])
          .filter((hybrid) => hybrid?.type?.trim() === "editableSelect")
          .flatMap((hybrid) =>
            (hybrid.data || []).map((item) => ({
              oid: item.oid,
              value: hybrid[`val_${item.oid}`] ?? item.currentValue ?? "",
            }))
          );

        // 3. Combine both
        payload = [...editablePayload, ...editableSelectPayload];
      }

      console.log("SNMP Payload", payload);

      // const response = await ConfigurationAxios(
      //   `${SAVE_SNMP_DATA_FOR_DEVICE}/${selectedDevice?.resourceId}/0`,
      //   "post",
      //   payload
      // );

      // Toast(
      //   response?.message || "Configuration updated successfully",
      //   response?.message || "Configuration updated successfully",
      //   response?.status === 1 ? "success" : "error"
      // );
    } catch (err) {
      Toast("Error", "Failed to update configuration", "error");

      console.error(err);
    }
  };

  const dropdownTabOptions = availableTabsList.map((tab, idx) => ({
    label: tab.name || `Tab ${idx + 1}`,
    value: idx,
  }));

  const widgetOptions = [];

  Object.entries(tabbedWidgetsData).forEach(([tabIndex, tab]) => {
    (tab.widgets || []).forEach((widget, widgetIndex) => {
      widgetOptions.push({
        label: widget.tableTitle || `Widget ${widgetIndex + 1}`,
        value: `${tabIndex}-${widgetIndex}`,
      });
    });
  });
  const selectedWidget =
    selectedWidgetKey !== ""
      ? (() => {
          const [tabIndex, widgetIndex] = selectedWidgetKey.split("-");

          return tabbedWidgetsData?.[tabIndex]?.widgets?.[widgetIndex];
        })()
      : null;

  const oidOptions =
    selectedWidget?.data?.map((item, idx) => ({
      // Concatenates Name & OID so it displays beautifully in your dropdown menu
      label: `${item.name} (${item.oid})`,
      value: String(idx), // Keep numeric index as your underlying selection value reference
    })) || [];
  const applyLiveDataToWidgets = (liveData) => {
    if (!liveData) return;

    const staticMap = liveData?.static || {};
    const tableMap = liveData?.table || {};

    // flatten table values into oid → value map
    const tableFlatMap = {};

    Object.values(tableMap || {}).forEach((rows) => {
      rows.forEach((row) => {
        Object.entries(row).forEach(([oid, value]) => {
          tableFlatMap[oid] = value;
        });
      });
    });

    const mergedMap = { ...staticMap, ...tableFlatMap };

    setTabbedWidgetsData((prev) => {
      const updated = { ...prev };
      const tabState = updated[activeTabIdx];

      if (!tabState) return prev;

      const newWidgets = tabState.widgets.map((w) => {
        const newData = (w.data || []).map((d) => {
          const liveValue = mergedMap[d.oid];
          return {
            ...d,
            currentValue: liveValue !== undefined ? liveValue : d.currentValue,
          };
        });

        return {
          ...w,
          data: newData,
        };
      });

      updated[activeTabIdx] = {
        ...tabState,
        widgets: newWidgets,
      };

      return updated;
    });
  };

  useEffect(() => {
    // 1. Handle Title Mode
    if (dialogMode === "editTitle" && selectedWidget) {
      setEditedTitle(selectedWidget.tableTitle || "");
    }

    // 2. Handle OID Mode
    if (dialogMode === "editOid" && selectedWidget) {
      const targetData = selectedWidget.data?.[selectedOidIndex];

      if (targetData) {
        setEditedName(targetData.name || "");
        setEditedOid(targetData.oid || "");
      } else {
        // Reset if no OID is selected
        setEditedName("");
        setEditedOid("");
      }
    }
  }, [selectedWidgetKey, selectedOidIndex, dialogMode, selectedWidget]);

  useEffect(() => {
    if (liveStatusData?.data) {
      applyLiveDataToWidgets(liveStatusData.data);
    }
  }, [liveStatusData, activeTabIdx]);

  const handleDownloadExcel = () => {
    try {
      const rows = [];

      Object.values(tabbedWidgetsData).forEach((tabState) => {
        tabState.widgets?.forEach((widget) => {
          if (widget.type === "hybrid") {
            widget.children?.forEach((child) => {
              extractWidgetExcelRows(child, rows);
            });
          } else {
            extractWidgetExcelRows(widget, rows);
          }
        });
      });

      if (rows.length === 0) {
        Toast("Info", "No widgets available for export", "info");

        return;
      }

      const worksheet = XLSX.utils.json_to_sheet(rows);

      const workbook = XLSX.utils.book_new();

      XLSX.utils.book_append_sheet(workbook, worksheet, "Widget Configuration");

      XLSX.writeFile(
        workbook,
        `${selectedDevice?.resourceName || "Device"}_${dialogType}_Widgets.xlsx`
      );
    } catch (error) {
      console.error("Excel download failed", error);

      Toast("Error", "Failed to download Excel", "error");
    }
  };
  const extractWidgetExcelRows = (widget, rows) => {
    const widgetType = widget.type || "";

    const widgetTitle = widget.tableTitle || "";

    const data = widget.data || [];

    data.forEach((item, index) => {
      rows.push({
        Name: item.name || "",

        OID: item.oid || "",
        // show only for first row of widget
        "Widget Type": index === 0 ? widgetType : "",

        // show only for first row of widget
        "Widget Title": index === 0 ? widgetTitle : "",
      });
    });
    // console.log("Name And Oid", data)
  };

  const [oidSettings, setOidSettings] = useState({});

  const handleSettingChange = (oid, key, value) => {
    setOidSettings((prev) => ({
      ...prev,
      [oid]: {
        ...prev[oid],
        [key]: value,
      },
    }));
  };

  // Helper to get current settings or default to text
  const getSettings = (oid) => oidSettings?.[oid] || {};
  const usedOids = new Set();
  currentWidgetsCollection.forEach((widget) => {
    if (widget.data && Array.isArray(widget.data)) {
      widget.data.forEach((d) => {
        const oidVal = typeof d === "string" ? d : d.oid || d.value;
        if (oidVal) usedOids.add(oidVal);
      });
    }
    if (widget.children && Array.isArray(widget.children)) {
      widget.children.forEach((child) => {
        if (child.data && Array.isArray(child.data)) {
          child.data.forEach((d) => {
            const oidVal = typeof d === "string" ? d : d.oid || d.value;
            if (oidVal) usedOids.add(oidVal);
          });
        }
      });
    }
  });

  // 2. Create processed options from parsedOids that mark used ones as disabled
  // const processedParsedOids = parsedOids.map((opt) => ({
  //   ...opt,
  //   disabled: usedOids.has(opt.value),
  // }));
  const editingWidgetCurrentOids = (() => {
    if (!editingWidgetKey) return [];

    const [tabIndex, widgetIndex] = String(editingWidgetKey).split("-");

    return (
      tabbedWidgetsData?.[Number(tabIndex)]?.widgets?.[
        Number(widgetIndex)
      ]?.data
        ?.map((item) => String(item?.oid))
        .filter(Boolean) || []
    );
  })();
  const currentWidgetForEdit = (() => {
    if (!editingWidgetKey) return null;

    const [tabIndex, widgetIndex] = String(editingWidgetKey).split("-");

    return (
      tabbedWidgetsData?.[Number(tabIndex)]?.widgets?.[Number(widgetIndex)] ||
      null
    );
  })();

  const widgetOidsForEdit = (() => {
    if (!currentWidgetForEdit) return [];

    return (currentWidgetForEdit.data || [])
      .map((item) => {
        if (typeof item === "string") {
          return {
            label: item,
            value: item,
            rawName: item,
          };
        }

        return {
          label:
            item?.displayName ||
            `${item?.name || "Metric"} (${item?.oid || ""})`,
          value: String(item?.oid || ""),
          rawName: item?.name || "Metric",
        };
      })
      .filter((item) => item.value);
  })();

  const effectiveParsedOids =
    parsedOids.length > 0 ? parsedOids : widgetOidsForEdit;
  const processedParsedOids = effectiveParsedOids.map((opt) => ({
    ...opt,
    disabled:
      usedOids.has(opt.value) &&
      !editingWidgetCurrentOids.includes(String(opt.value)),
  }));
  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        //bgcolor: "#ffffff",
        overflow: "hidden",
      }}
    >
      {/* HEADER CONTROL ROW */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 2,
          p: 1,
          border: "2px solid #e0e0e0",
          borderRadius: "8px",
          //bgcolor: "#fafafa",
          gap: 2,
        }}
      >
        <Box>
          <Typography
            sx={{
              color: "text.TitleTextcolor",
              p: 0,
            }}
          >
            Manage Tabs : {selectedDevice?.resourceName}
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            minWidth: "350px",
            justifyContent: "flex-end",
          }}
        >
          {isEditingTabName ? (
            <Box
              sx={{
                display: "flex",
                gap: 1,
                alignItems: "center",
                //bgcolor: "#fff",
                p: 1,
                borderRadius: "6px",
                border: "1px solid #ccc",
              }}
            >
              <MInput
                size="small"
                value={editedTabName}
                onChange={(e) => setEditedTabName(e.target.value)}
                placeholder="Rename target..."
              />
              <Button
                size="small"
                variant="contained"
                sx={{ bgcolor: "#14348D", borderRadius: "5px" }}
                onClick={handleSaveTabName}
              >
                Save
              </Button>
              <Button
                size="small"
                variant="outlined"
                sx={{
                  border: theme.palette.custom.border,
                  color: "text.TitleTextcolor",
                  borderRadius: "5px",
                }}
                onClick={() => setIsEditingTabName(false)}
              >
                Cancel
              </Button>
            </Box>
          ) : (
            <>
              <Box sx={{ width: "180px" }}>
                <MAlarmSelect
                  label=""
                  options={dropdownTabOptions}
                  value={activeTabIdx}
                  onChange={(val) => setActiveTabIdx(Number(val))}
                  multiple={false}
                  isDark={isDark}
                />
              </Box>
              <Box sx={{ display: "flex", gap: 0.5 }}>
                <Tooltip title="Create a New Layout Tab">
                  <Button
                    onClick={handleAddTab}
                    variant="outlined"
                    sx={{
                      border: theme.palette.custom.border,
                      color: "text.TitleTextcolor",
                      borderRadius: "10px",
                      textTransform: "none",
                    }}
                  >
                    Add tab
                  </Button>
                </Tooltip>
                <Tooltip title="Rename Chosen Tab">
                  <IconButton onClick={handleStartRenameTab} sx={{ p: 0 }}>
                    <img
                      src={Edit_Icon}
                      style={{
                        width: "30px",
                        height: "30px",
                        objectFit: "contain",
                      }}
                      alt="edit"
                    />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Delete Active Selected Tab">
                  <IconButton
                    color="error"
                    onClick={handleDeleteTab}
                    sx={{ p: 0 }}
                  >
                    <img
                      src={deletes}
                      style={{
                        width: "30px",
                        height: "30px",
                        objectFit: "contain",
                      }}
                      alt="delete"
                    />
                  </IconButton>
                </Tooltip>
              </Box>
            </>
          )}
        </Box>
      </Box>

      {/* PARAMETER SELECTION PANELS */}
      <Card
        sx={{
          // p: 2,
          // mb: 3,
          border: "2px solid #e0e0e0",
          boxShadow: "none",
          //bgcolor: "#fcfcfc",
        }}
      >
        <Box sx={{ borderBottom: "2px solid #e0e0e0" }}>
          <Typography
            sx={{ color: theme.palette.custom.snmp.snmmptitle, p: 2 }}
          >
            Add Data: <strong>{activeTabName}</strong>
          </Typography>
        </Box>

        <Box
          sx={{
            // maxWidth: "450px",
            p: 2,
          }}
          className="flex justify-between"
        >
          <Box className="flex gap-2 items-center">
            <Typography sx={{ fontWeight: 500, mb: 0.5, fontSize: "14px" }}>
              Upload File *
            </Typography>
            <MInput
              type="file"
              fullWidth
              inputProps={{ accept: ".xlsx,.xls" }}
              onChange={handleFileUpload}
              sx={{
                backgroundColor: "#e4ebff",
                // Target the root of the input to change the cursor for the whole box
                "& .MuiOutlinedInput-root": {
                  cursor: "pointer",
                },
                // Target the actual input element to ensure the cursor changes when hovering the text area
                "& .MuiInputBase-input": {
                  cursor: "pointer",
                },
              }}
            />
          </Box>
          <Box sx={{ pl: 4 }}>
            {" "}
            <MButtonPrimary
              variant="contained"
              color="primary"
              sx={{ color: "#14348D", borderColor: "#14348D" }}
              onClick={handleDownloadExcel}
            >
              Download Excel
            </MButtonPrimary>
          </Box>
        </Box>

        {parsedOids.length > 0 && (
          <Box sx={{ p: 2 }}>
            <Grid
              container
              spacing={2}
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
                gap: 2,
                width: "100%",
                mb: 1,
              }}
            >
              <Grid item xs={12} md={6}>
                <MAlarmSelect
                  label="Widget *"
                  options={AVAILABLE_WIDGETS}
                  value={currentSelectedWidgetType}
                  onChange={setCurrentSelectedWidgetType}
                  multiple={false}
                  isDark={isDark}
                />
              </Grid>
              {/* <Grid item xs={12} md={6}>
                <MAlarmSelect
                  label="Select Parameter *"
                  options={parsedOids}
                  value={currentSelectedOids}
                  onChange={setCurrentSelectedOids}
                  multiple={true}
                />
              </Grid> */}
              <Grid item xs={12} md={6}>
                <MAlarmSelect
                  label="Select Parameter *"
                  options={processedParsedOids} // <-- USE PROCESSED OPTIONS HERE
                  value={currentSelectedOids}
                  onChange={setCurrentSelectedOids}
                  multiple={true}
                  isDark={isDark}
                />
              </Grid>
              {currentSelectedWidgetType &&
                WIDGET_REGISTRY[currentSelectedWidgetType]?.fields?.map(
                  (field) => (
                    <React.Fragment key={field.id}>
                      <Grid item xs={12} md={4}>
                        <Box sx={{ display: "flex", flexDirection: "column" }}>
                          {field.type !== "remoteDeviceSwitch" &&
                            field.type !== "remoteDeviceEditSwitch" && (
                              <Typography
                                sx={{
                                  mb: 0.5,
                                  fontSize: "13px",
                                  fontWeight: 500,
                                  color: theme.palette.custom.snmp.inputtitle,
                                }}
                              >
                                {field.label}
                              </Typography>
                            )}

                          {/* RENDER COMPONENT A: Standard text string value inputs */}
                          {field.type === "text" && (
                            <MInput
                              fullWidth
                              placeholder={field.placeholder}
                              value={widgetMetaFields[field.id] || ""}
                              onChange={(e) =>
                                handleMetaFieldChange(field.id, e.target.value)
                              }
                            />
                          )}

                          {/* RENDER COMPONENT B: Standard Preset Dropdowns for layout rules boundaries */}
                          {field.type === "presetDropdown" && (
                            <MAlarmSelect
                              label=""
                              options={field.options}
                              value={widgetMetaFields[field.id] || ""}
                              onChange={(selectedVal) => {
                                handleMetaFieldChange(field.id, selectedVal);
                              }}
                              multiple={false}
                              isDark={isDark}
                            />
                          )}

                          {/* RENDER COMPONENT C: Context Filtering Multi-Select Dropdowns */}
                          {field.type === "excelDropdown" && (
                            <MAlarmSelect
                              label=""
                              options={parsedOids.filter((item) =>
                                currentSelectedOids.includes(item.value)
                              )}
                              value={widgetMetaFields[field.id] || ""}
                              onChange={(selectedVal) =>
                                handleMetaFieldChange(field.id, selectedVal)
                              }
                              multiple={false}
                              isDark={isDark}
                            />
                          )}
                          {field.type === "switchBtn" && (
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                              {/* <Typography>{field.label}</Typography> */}
                              <Switch
                                checked={widgetMetaFields[field.id] || false}
                                onChange={() =>
                                  handleMetaFieldChange(
                                    field.id,
                                    !widgetMetaFields[field.id]
                                  )
                                }
                              />
                            </Box>
                          )}
                          {field.type === "dynamicOidConfig" && (
                            <Grid item xs={12}>
                              <Box
                                sx={{
                                  display: "flex",
                                  flexDirection: "column",
                                  flexWrap: "wrap",
                                  gap: 2,
                                  mt: 1,
                                  mb: 2,
                                }}
                              >
                                {/* Loop through each OID multi-selected from your primary Excel picker layer */}
                                {(currentSelectedOids || []).map((oidVal) => {
                                  const match = parsedOids.find(
                                    (o) => o.value === oidVal
                                  );
                                  const oidName =
                                    match?.rawName || `OID_${oidVal}`;

                                  // Fetch existing configs or fallback safely
                                  const currentConfigs =
                                    widgetMetaFields.oidConfigs || {};
                                  const config = currentConfigs[oidName] || {
                                    type: "text",
                                    useStepper: false,
                                  };

                                  const updateOidRule = (ruleKey, value) => {
                                    handleMetaFieldChange("oidConfigs", {
                                      ...currentConfigs,
                                      [oidName]: {
                                        ...config,
                                        [ruleKey]: value,
                                      },
                                    });
                                  };

                                  return (
                                    <Box
                                      key={oidVal}
                                      sx={{
                                        p: 2,
                                        border: "1px solid #d6e4ff",
                                        borderRadius: 2,
                                        //background: "#fff",
                                        boxShadow: "0 2px 8px rgba(0,0,0,.05)",
                                        display: "flex",
                                        flexDirection: "column",
                                        gap: 2,
                                      }}
                                    >
                                      {/* Top Row: Variable Label Tag vs Type Selector Dropdown */}
                                      <Box
                                        sx={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          alignItems: "center",
                                          gap: 2,
                                        }}
                                      >
                                        <Box>
                                          <Typography
                                            sx={{
                                              fontSize: 14,
                                              fontWeight: 600,
                                              color:
                                                theme.palette.custom.snmp
                                                  .snmmptitle,
                                            }}
                                          >
                                            {oidName}
                                          </Typography>

                                          <Typography
                                            sx={{
                                              fontSize: 11,
                                              color:
                                                theme.palette.custom.snmp
                                                  .snmmptitle,
                                            }}
                                          >
                                            {oidVal}
                                          </Typography>
                                        </Box>

                                        <Box sx={{ width: 170 }}>
                                          <MAlarmSelect
                                            label=""
                                            options={[
                                              {
                                                label: "Text",
                                                value: "text",
                                              },
                                              {
                                                label: "Number",
                                                value: "number",
                                              },
                                            ]}
                                            value={config.type}
                                            onChange={(v) =>
                                              updateOidRule("type", v)
                                            }
                                            multiple={false}
                                            isDark={isDark}
                                          />
                                        </Box>
                                      </Box>

                                      {/* Numeric Parameters Layout: Min, Max, and Stepper configurations */}
                                      {config.type === "number" && (
                                        <Box
                                          sx={{
                                            display: "flex",
                                            flexDirection: "column",
                                            gap: 1.5,
                                            pl: 1.5,
                                            borderLeft: "2px solid #cbd5e1",
                                          }}
                                        >
                                          <Box sx={{ display: "flex", gap: 2 }}>
                                            <Box sx={{ flex: 1 }}>
                                              <Typography
                                                sx={{
                                                  fontSize: "11px",
                                                  color: "#475569",
                                                  mb: 0.5,
                                                }}
                                              >
                                                Min Bound Value
                                              </Typography>
                                              <MInput
                                                placeholder="e.g. 1"
                                                type="number"
                                                fullWidth
                                                value={config.min || ""}
                                                onChange={(e) =>
                                                  updateOidRule(
                                                    "min",
                                                    e.target.value
                                                  )
                                                }
                                              />
                                            </Box>
                                            <Box sx={{ flex: 1 }}>
                                              <Typography
                                                sx={{
                                                  fontSize: "11px",
                                                  color: "#475569",
                                                  mb: 0.5,
                                                }}
                                              >
                                                Max Bound Value
                                              </Typography>
                                              <MInput
                                                placeholder="e.g. 20"
                                                type="number"
                                                fullWidth
                                                value={config.max || ""}
                                                onChange={(e) =>
                                                  updateOidRule(
                                                    "max",
                                                    e.target.value
                                                  )
                                                }
                                              />
                                            </Box>
                                          </Box>

                                          {/* Checkbox trigger layout for the custom Stepper increments */}
                                          <label
                                            style={{
                                              display: "flex",
                                              alignItems: "center",
                                              gap: "8px",
                                              cursor: "pointer",
                                              fontSize: "12px",
                                              color: "#334155",
                                              fontWeight: "500",
                                            }}
                                          >
                                            <input
                                              type="checkbox"
                                              checked={
                                                config.useStepper || false
                                              }
                                              onChange={(e) =>
                                                updateOidRule(
                                                  "useStepper",
                                                  e.target.checked
                                                )
                                              }
                                            />
                                            Enable Custom Value Stepper Control
                                          </label>

                                          {config.useStepper && (
                                            <Box sx={{ width: "48%" }}>
                                              <Typography
                                                sx={{
                                                  fontSize: "11px",
                                                  color: "#475569",
                                                  mb: 0.5,
                                                }}
                                              >
                                                Step Size (Interval)
                                              </Typography>
                                              <MInput
                                                placeholder="e.g. 2"
                                                type="number"
                                                fullWidth
                                                value={config.step || ""}
                                                onChange={(e) =>
                                                  updateOidRule(
                                                    "step",
                                                    e.target.value
                                                  )
                                                }
                                              />
                                            </Box>
                                          )}
                                        </Box>
                                      )}
                                    </Box>
                                  );
                                })}
                              </Box>
                            </Grid>
                          )}
                          {field.type === "remoteDeviceSwitch" && (
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                              <Typography>{field.label}</Typography>
                              <Switch
                                checked={widgetMetaFields[field.id] || false}
                                onChange={() =>
                                  handleMetaFieldChange(
                                    field.id,
                                    !widgetMetaFields[field.id]
                                  )
                                }
                              />
                            </Box>
                          )}
                          {field.type === "remoteDeviceEditSwitch" && (
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                              <Typography>{field.label}</Typography>
                              <Switch
                                checked={widgetMetaFields[field.id] || false}
                                onChange={() =>
                                  handleMetaFieldChange(
                                    field.id,
                                    !widgetMetaFields[field.id]
                                  )
                                }
                              />
                            </Box>
                          )}
                        </Box>
                      </Grid>

                      {/* CONDITIONAL EXTRA INPUT FIELD INJECTION: Unhides the custom bound value textbox whenever -x to +x is active */}
                      {field.id === "gaugeRangePreset" &&
                        widgetMetaFields["gaugeRangePreset"] === "dynamic" && (
                          <Grid item xs={12} md={4}>
                            <Box sx={{ mb: 1 }}>
                              <Typography
                                sx={{
                                  mb: 0.5,
                                  fontSize: "13px",
                                  fontWeight: 600,
                                  color: "#d32f2f",
                                }}
                              >
                                Enter Symmetric Absolute Bound Limit Value (X) *
                              </Typography>
                              <MInput
                                fullWidth
                                type="number"
                                placeholder="e.g., 150 (Evaluates from -150 to +150)"
                                value={widgetMetaFields["customRangeX"] || ""}
                                onChange={(e) =>
                                  handleMetaFieldChange(
                                    "customRangeX",
                                    e.target.value
                                  )
                                }
                              />
                            </Box>
                          </Grid>
                        )}
                    </React.Fragment>
                  )
                )}

              {/* 2. Map through the OIDs to create the inputs dynamically */}
              {currentSelectedWidgetType === "needelGauge" &&
                widgetMetaFields.conditionalEdit &&
                currentSelectedOids.map((oidVal) => {
                  // This replicates your logic to find the name
                  const match = parsedOids.find((o) => o.value === oidVal);
                  const displayName = `${match?.rawName || "Metric"}`;
                  const settings = getSettings(oidVal);

                  return (
                    <div
                      key={oidVal}
                      style={{
                        border: "1px solid #ddd",
                        padding: "15px",
                        marginBottom: "15px",
                        borderRadius: "8px",
                        backgroundColor: "#f9f9f9",
                      }}
                    >
                      <div style={{ fontWeight: "bold", marginBottom: "10px" }}>
                        {displayName}
                      </div>

                      {/* SELECT INPUT TYPE */}
                      <div style={{ marginBottom: "10px" }}>
                        {/* <label
                          style={{ marginRight: "10px", fontSize: "14px" }}
                        >
                          Input Mode:
                        </label>
                        <select
                          value={settings.type}
                          onChange={(e) =>
                            handleSettingChange(oidVal, "type", e.target.value)
                          }
                        >
                          <option value="454545454">Text Input</option>
                          <option value="number">Number Input (Gauge)</option>
                        </select> */}

                        <MAlarmSelect
                          value={settings.type || ""}
                          onChange={(newVal) =>
                            handleSettingChange(oidVal, "type", newVal)
                          }
                          label={"Select input type *"}
                          options={[
                            { value: "number", label: "number" },
                            { value: "text", label: "text" },
                          ]}
                          multiple={false}
                          isDark={isDark}
                        />
                      </div>

                      {/* CONDITIONAL INPUTS: Only show if type is 'number' */}
                      {settings.type === "number" && (
                        <div
                          style={{
                            display: "flex",
                            gap: "10px",
                            marginBottom: "10px",
                            padding: "10px",
                            background: "#fff",
                            borderRadius: "4px",
                            border: "1px dashed #ccc",
                          }}
                        >
                          <div style={{ flex: 1 }}>
                            <label
                              style={{ display: "block", fontSize: "11px" }}
                            >
                              MIN
                            </label>
                            <input
                              type="number"
                              style={{ width: "100%" }}
                              value={settings.min ?? ""}
                              onChange={(e) =>
                                handleSettingChange(
                                  oidVal,
                                  "min",
                                  parseFloat(e.target.value)
                                )
                              }
                            />
                          </div>
                          <div style={{ flex: 1 }}>
                            <label
                              style={{ display: "block", fontSize: "11px" }}
                            >
                              MAX
                            </label>
                            <input
                              type="number"
                              style={{ width: "100%" }}
                              value={settings.max ?? ""}
                              onChange={(e) =>
                                handleSettingChange(
                                  oidVal,
                                  "max",
                                  parseFloat(e.target.value)
                                )
                              }
                            />
                          </div>
                          <div style={{ flex: 1 }}>
                            <label
                              style={{ display: "block", fontSize: "11px" }}
                            >
                              STEP
                            </label>
                            <input
                              type="number"
                              style={{ width: "100%" }}
                              value={settings.step ?? ""}
                              onChange={(e) =>
                                handleSettingChange(
                                  oidVal,
                                  "step",
                                  parseFloat(e.target.value)
                                )
                              }
                            />
                          </div>
                        </div>
                      )}

                      {/* THE ACTUAL DATA INPUT (The value the gauge will use) */}
                      {/* <div>
                        <label style={{ display: "block", fontSize: "11px" }}>
                          VALUE
                        </label>
                        <input
                          type={settings.type}
                          min={settings.min}
                          max={settings.max}
                          step={settings.step}
                          style={{ width: "100%", padding: "5px" }}
                          placeholder={`Enter ${settings.type}...`}
                          value={settings.value || ""}
                          onChange={(e) =>
                            handleSettingChange(oidVal, "value", e.target.value)
                          }
                        />
                      </div> */}
                    </div>
                  );
                })}
            </Grid>
          </Box>
        )}
        <Grid
          item
          xs={12}
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            m: 1,
          }}
        >
          {/* LEFT SIDE */}
          <Box sx={{ display: "flex", gap: 1 }}>
            <MButtonSecondary
              onClick={() => {
                setDialogMode("editOid");
                setDialogOpen(true);
              }}
              style={{
                color: theme.palette.custom.snmp.snmmptitle,
                fontWeight: 600,
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <EditDocument fontSize="small" />
                Edit OID
              </Box>
            </MButtonSecondary>

            <MButtonSecondary
              onClick={() => {
                setDialogMode("editTitle");
                setDialogOpen(true);
              }}
              style={{
                color: theme.palette.custom.snmp.snmmptitle,
                fontWeight: 600,
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <EditDocument fontSize="small" />
                Edit Title
              </Box>
            </MButtonSecondary>
          </Box>

          {/* RIGHT SIDE */}
          <Box sx={{ display: "flex", gap: 1.5 }}>
            <Button
              variant="outlined"
              sx={{
                border: theme.palette.custom.border,
                color: "text.TitleTextcolor",
                borderRadius: "10px",
                textTransform: "none",
              }}
              disabled={
                currentSelectedOids.length === 0 || !currentSelectedWidgetType
              }
              onClick={handleAddDirectlyToCanvas}
              //startIcon={<InputIcon />}
            >
              Add to Layout
            </Button>

            <MButtonPrimary
              variant="contained"
              disabled={
                currentSelectedOids.length === 0 || !currentSelectedWidgetType
              }
              onClick={handleAddToGridQueue}
            >
              Add to Grid
            </MButtonPrimary>
          </Box>
        </Grid>
      </Card>

      {widgetQueue.length > 0 && (
        <Box
          sx={{
            mb: 4,
            p: 2.5,
            //bgcolor: "#ffffff", // Pure white container
            borderRadius: "12px",
            border: "1px solid #e5e7eb", // Soft light gray border
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.03)",
          }}
        >
          {/* Header Section */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 2,
              pb: 1.5,
              borderBottom: "1px solid #f3f4f6",
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: 700,
                  color: theme.palette.custom.snmp.snmmptitle,
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  letterSpacing: "-0.01em",
                }}
              >
                Grid Queue
              </Typography>

              {/* Modern Pill Item Indicator */}
              <Typography
                variant="caption"
                sx={{
                  //bgcolor: "#f3f4f6",
                  color: "#4b5563",
                  px: 1.2,
                  py: 0.4,
                  borderRadius: "20px",
                  fontSize: "11px",
                  fontWeight: 600,
                  border: "1px solid #e5e7eb",
                  letterSpacing: "0.05em",
                }}
              >
                {widgetQueue.length}{" "}
                {widgetQueue.length === 1 ? "ITEM" : "ITEMS"} STACKED
              </Typography>
            </Box>

            {/* Controls: Pagination Controls + Action Button */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              {/* Horizontal Pagination Buttons */}
              {widgetQueue.length > 1 && (
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5,
                    //bgcolor: "#f9fafb",
                    p: 0.5,
                    borderRadius: "8px",
                    border: "1px solid #e5e7eb",
                  }}
                >
                  <IconButton
                    size="small"
                    onClick={() => handleScroll("left")}
                    sx={{ color: "#4b5563", "&:hover": { bgcolor: "#eaeaea" } }}
                  >
                    <ChevronLeftIcon fontSize="small" />
                  </IconButton>
                  <Typography
                    sx={{
                      fontSize: "11px",
                      fontWeight: 600,
                      color: "#6b7280",
                      px: 0.5,
                    }}
                  >
                    NAVIGATE
                  </Typography>
                  <IconButton
                    size="small"
                    onClick={() => handleScroll("right")}
                    sx={{ color: "#4b5563", "&:hover": { bgcolor: "#eaeaea" } }}
                  >
                    <ChevronRightIcon fontSize="small" />
                  </IconButton>
                </Box>
              )}

              <MButtonPrimary
                variant="contained"
                size="small"
                startIcon={<PlayArrowIcon />}
                onClick={handleFlushQueueToLayout}
                sx={{
                  //bgcolor: "#14348D", // Dark button for premium stark contrast
                  color: "#ffffff",
                  fontWeight: 600,
                  px: 2,
                  py: 0.6,
                  borderRadius: "6px",
                  textTransform: "none",
                  fontSize: "13px",
                  "&:hover": {
                    bgcolor: "#1f2937",
                  },
                }}
              >
                Add to Layout
              </MButtonPrimary>
            </Box>
          </Box>

          {/* Horizontal Scrollable Row */}
          <Box
            ref={scrollContainerRef}
            sx={{
              display: "flex",
              gap: 2,
              overflowX: "auto",
              pb: 1.5,
              pt: 0.5,
              scrollBehavior: "smooth",
              "::-webkit-scrollbar": { height: "6px" },
              "::-webkit-scrollbar-track": { bgcolor: "transparent" },
              "::-webkit-scrollbar-thumb": {
                bgcolor: "#d1d5db",
                borderRadius: "10px",
                "&:hover": { bgcolor: "#9ca3af" },
              },
            }}
          >
            {widgetQueue.map((item, idx) => (
              <Card
                key={idx}
                sx={{
                  minWidth: "295px",
                  maxWidth: "295px",
                  p: 2,
                  //bgcolor: "#f9fafb", // Subtle gray background card to stand out against white
                  border: "1px solid #e5e7eb",
                  borderRadius: "10px",
                  position: "relative",
                  boxShadow: "none",
                  transition: "all 0.2s ease-in-out",
                  "&:hover": {
                    borderColor: "#9ca3af",
                    //bgcolor: "#ffffff",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.04)",
                  },
                }}
              >
                {/* Action Buttons */}
                <Box
                  sx={{
                    position: "absolute",
                    top: 8,
                    right: 8,
                    display: "flex",
                    gap: 0.5,
                    bgcolor: "rgba(255, 255, 255, 0.9)",
                    backdropFilter: "blur(4px)",
                    borderRadius: "6px",
                    p: 0.2,
                    boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
                  }}
                >
                  <IconButton
                    size="small"
                    onClick={() => handleEditQueuedItem(idx)}
                    sx={{ color: "#6b7280", "&:hover": { color: "#111827" } }}
                  >
                    <EditIcon fontSize="small" />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDeleteQueuedItem(idx)}
                    sx={{ color: "#dc2626", "&:hover": { color: "#b91c1c" } }}
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>

                {/* Details */}
                <Box sx={{ pr: 6 }}>
                  <Typography
                    variant="caption"
                    sx={{
                      fontWeight: 600,
                      color: theme.palette.custom.snmp.snmmptitle,
                      display: "block",
                      textTransform: "uppercase",
                      letterSpacing: "0.05em",
                      fontSize: "10px",
                    }}
                  >
                    Type •{" "}
                    <span
                      style={{ color: theme.palette.custom.snmp.snmmptitle }}
                    >
                      {item.type}
                    </span>
                  </Typography>

                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 600,
                      color: theme.palette.custom.snmp.snmmptitle,
                      mt: 0.5,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {item.tableTitle || "Untitled Grid"}
                  </Typography>
                </Box>

                {/* Metadata Badges */}
                <Box
                  sx={{ mt: 1.5, display: "flex", gap: 1, flexWrap: "wrap" }}
                >
                  <Chip
                    label={`Cols: ${item.cols}`}
                    size="small"
                    sx={{
                      height: "20px",
                      fontSize: "11px",
                      color: theme.palette.custom.snmp.snmmptitle,
                      //bgcolor: "#ffffff",
                      border: "1px solid #e5e7eb",
                    }}
                  />
                  <Chip
                    label={`OIDs: ${item.data.length}`}
                    size="small"
                    sx={{
                      height: "20px",
                      fontSize: "11px",
                      color: theme.palette.custom.snmp.snmmptitle,
                      //bgcolor: "#ecfdf5", // Mint background accent
                      border: "1px solid #d1fae5",
                    }}
                  />
                </Box>

                {/* Item Content Nested List */}
                <Box
                  sx={{
                    mt: 1.5,
                    maxHeight: "64px",
                    overflowY: "auto",
                    //bgcolor: "#ffffff",
                    p: 1,
                    borderRadius: "6px",
                    border: "1px solid #e5e7eb",
                    "::-webkit-scrollbar": { width: "4px" },
                    "::-webkit-scrollbar-thumb": {
                      bgcolor: "#e5e7eb",
                      borderRadius: "4px",
                    },
                  }}
                >
                  {item.data.map((o, oIdx) => (
                    <Typography
                      key={oIdx}
                      variant="caption"
                      display="block"
                      sx={{
                        color: theme.palette.custom.snmp.snmmptitle,
                        fontSize: "11px",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        mb: 0.5,
                        "&:last-child": { mb: 0 },
                      }}
                    >
                      • {o.name}
                    </Typography>
                  ))}
                </Box>
              </Card>
            ))}
          </Box>
        </Box>
      )}
      {/* LOWER CANVAS LAYOUT TABS SYSTEM */}
      <Box
        sx={{
          borderBottom: 1,
          borderColor: "divider",
          mt: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Tabs
          value={activeTabIdx}
          onChange={(_, newVal) => {
            setActiveTabIdx(newVal);

            setActiveTabId(newVal);
          }}
          variant="scrollable"
          scrollButtons="auto"
          textColor="primary"
          indicatorColor="primary"
          sx={{
            "& .MuiTab-root": {
              fontWeight: 600,
              fontSize: "14px",
              textTransform: "none",
            },
            "& .Mui-selected": { color: "#14348D !important" },
            "& .MuiTabs-indicator": { bgcolor: "#14348D" },
          }}
        >
          {availableTabsList.map((tab, idx) => (
            <Tab key={idx} label={tab.name || `Tab ${idx + 1}`} />
          ))}
        </Tabs>
      </Box>

      <Box
        ref={canvasRef}
        sx={{
          flex: 1,
          minHeight: "450px", // Give it a stable starting min-height
          maxHeight: "80vh", // Prevents infinite expansion page scrolls
          overflow: "auto",
          //bgcolor: "#ffffff",
          border: "2px dashed #ccc",
          borderRadius: "0 0 8px 8px",
          p: 2,
          borderTop: "none",
        }}
      >
        {currentWidgetsCollection.length === 0 ? (
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "450px",
            }}
          >
            <Typography color="textSecondary" sx={{ fontStyle: "italic" }}>
              Workspace view canvas is empty. Use "Direct to Layout" or push
              elements from the queue layer buffer.
            </Typography>
          </Box>
        ) : (
          <GridLayout
            className="layout"
            gridConfig={{
              // cols: Math.round(canvasWidth / 2), // ~2px resolution
              rowHeight: 10,

              cols: 36,
            }}
            // rowHeight={1}
            width={canvasWidth}
            layout={currentCanvasNodes}
            onLayoutChange={handleLayoutChange}
            isDraggable
            isResizable
            compactType={"vertical"}
            preventCollision={true}
          >
            {currentWidgetsCollection.map((widget, widgetIdx) => {
              const theme = useTheme();
              const registryItem = WIDGET_REGISTRY[widget.type];

              const boxBgColor =
                widget.backgroundColor ||
                registryItem?.backgroundColor ||
                theme.palette.background.paper;

              const boxBorderColor =
                widget.borderColor ||
                registryItem?.borderColor ||
                theme.palette.divider;

              const layoutNode = currentCanvasNodes[widgetIdx] || {
                i: `static-${widgetIdx}`,
              };
              console.log("eeeevvvwidget", widget);

              return (
                <div
                  key={layoutNode.i}
                  style={{
                    background: boxBgColor,
                    borderRadius: "8px",
                    border: `1px solid ${boxBorderColor}`,
                    position: "relative",
                    height: "100%",
                    width: "100%",
                    boxSizing: "border-box",
                    overflow: "visible",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                  }}
                >
                  <div
                    style={{
                      background: boxBgColor,
                      borderRadius: "8px",
                      border: `1px solid ${boxBorderColor}`,
                      position: "relative",
                      height: "100%",
                      width: "100%",
                      display: "flex",
                      flexDirection: "column",
                      overflow: "hidden",
                      boxSizing: "border-box",
                    }}
                  >
                    {/* <IconButton
                      size="small"
                      onClick={() =>
                        handleDeleteWidgetNode(layoutNode.i, widgetIdx)
                      }
                      sx={{
                        position: "absolute",
                        top: 6,
                        right: 6,
                        zIndex: 100,
                        color: "#d32f2f",
                      }}
                    >
                      <DeleteIcon fontSize="small" />
                    </IconButton> */}
                    <Box
                      sx={{
                        position: "absolute",
                        top: 14,
                        right: 14,
                        zIndex: 100,
                        display: "flex",
                        gap: 1,
                        borderRadius: "6px",
                        p: 0.25,
                      }}
                    >
                      {/* EDIT */}
                      <Tooltip title="Edit Widget">
                        <IconButton
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditWidgetNode(widgetIdx);
                          }}
                          sx={{
                            backgroundColor: "rgba(255,255,255,0.90)",

                            color: "#14348D",
                            p: 0.5,
                          }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>

                      {/* DELETE */}
                      <Tooltip title="Delete Widget">
                        <IconButton
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteWidgetNode(layoutNode.i, widgetIdx);
                          }}
                          sx={{
                            backgroundColor: "rgba(255,255,255,0.90)",

                            color: "#d32f2f",
                            p: 0.5,
                          }}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>

                    {/* Main Wrapper Box inside the grid item */}
                    <Box
                      sx={{
                        p: 1.5,
                        height: "100%",
                        display: "flex",
                        flex: 1,
                        flexDirection: "column",
                        overflow: "hidden",
                      }}
                    >
                      {widget.type === "hybrid" ? (
                        <Box
                          sx={{
                            height: "100%",
                            width: "100%",
                            display: "flex",
                            flexDirection: "column",
                            gap: 1,
                            overflowY: "auto",
                          }}
                        >
                          {widget.children.map((childWidget, childIndex) => {
                            const childRegistry =
                              WIDGET_REGISTRY[childWidget.type];

                            return (
                              <Box
                                key={childIndex}
                                sx={{
                                  width: "100%",
                                }}
                              >
                                {childRegistry ? (
                                  childRegistry.renderCanvas(
                                    childWidget,
                                    handleInputValueChange,
                                    childIndex,
                                    handleSaveConfigurationWidget,
                                    dialogType,
                                    selectedDevice?.resourceId
                                  )
                                ) : (
                                  <WidgetRenderer
                                    type={childWidget.type}
                                    value={
                                      childWidget.type === "table"
                                        ? childWidget.data
                                        : childWidget.data?.[0]?.currentValue ||
                                          0
                                    }
                                    name={
                                      childWidget.tableTitle ||
                                      childWidget.data?.[0]?.name ||
                                      "Widget"
                                    }
                                  />
                                )}
                              </Box>
                            );
                          })}
                        </Box>
                      ) :
                       registryItem ? (
                        <Box
                          sx={{
                            height: "100%",
                            width: "100%",
                            display: "flex",
                            flexDirection: "column",
                            gap: 1,
                            overflowY: "auto",
                          }}
                        >
                          {registryItem && (
                            <Box
                              sx={{
                                height: "100%",
                                width: "100%",
                                overflow: "auto",
                              }}
                            >
                              {registryItem.renderCanvas(
                                widget,
                                handleInputValueChange,
                                widgetIdx,
                                handleSaveConfigurationWidget,
                                dialogType,
                                selectedDevice?.resourceId
                              )}
                            </Box>
                          )}
                          {/* {widget?.hybrid?.map((childWidget, childIndex) => {
                            const childRegistry =
                              WIDGET_REGISTRY[childWidget?.type];

                            return (
                              <Box
                                key={childIndex}
                                sx={{
                                  width: "100%",
                                }}
                              >
                                {childRegistry ? (
                                  childRegistry.renderCanvas(
                                    childWidget,
                                    handleInputValueChange,
                                    childIndex,
                                    handleSaveConfigurationWidget,
                                    dialogType,
                                    selectedDevice?.resourceId
                                  )
                                ) : (
                                  <WidgetRenderer
                                    type={childWidget.type}
                                    value={
                                      childWidget.type === "table"
                                        ? childWidget.data
                                        : childWidget.data?.[0]?.currentValue ||
                                          0
                                    }
                                    name={
                                      childWidget.tableTitle ||
                                      childWidget.data?.[0]?.name ||
                                      "Widget"
                                    }
                                  />
                                )}
                              </Box>
                            );
                          })} */}

                          {/* {widget?.hybrid?.map((childWidget, childIndex) => {
                            const childRegistry =
                              WIDGET_REGISTRY[childWidget?.type?.trim()];

                            return (
                              <Box
                                key={`${
                                  childWidget?.uid || childWidget?.type
                                }-${childIndex}`}
                                sx={{
                                  width: "100%",
                                }}
                              >
                                {childRegistry ? (
                                  childRegistry.renderCanvas(
                                    childWidget,
                                    (ignoredWidgetIdx, dataIdx, val) =>
                                      handleEditableSelectChange(
                                        widgetIdx,
                                        childIndex,
                                        dataIdx,
                                        val
                                      ),
                                    childIndex,
                                    handleSaveConfigurationWidget,
                                    dialogType,
                                    selectedDevice?.resourceId
                                  )
                                ) : (
                                  <WidgetRenderer
                                    widget={childWidget}
                                    widgetIndex={childIndex}
                                    node={{
                                      resourceId: selectedDevice?.resourceId,
                                    }}
                                  />
                                )}
                              </Box>
                            );
                          })} */}
                        </Box>
                      ) : (
                        <Box
                          sx={{
                            height: "100%",
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center",
                            overflow: "hidden",
                          }}
                        >
                          <Typography
                            variant="caption"
                            color="textSecondary"
                            display="block"
                            sx={{ textTransform: "uppercase" }}
                          >
                            {widget.type}
                          </Typography>

                          <Box sx={{ overflow: "auto", flex: 1 }}>
                            <WidgetRenderer
                              type={widget.type}
                              value={
                                widget.type === "table"
                                  ? widget.data
                                  : widget.data?.[0]?.currentValue || 0
                              }
                              name={
                                widget.tableTitle ||
                                widget.data?.[0]?.name ||
                                "Static Field Group"
                              }
                            />
                          </Box>
                        </Box>
                      )}
                    </Box>
                  </div>
                </div>
              );
            })}
          </GridLayout>
        )}
      </Box>
      {/* FOOTER SAVE BAR */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          gap: 1.5,
          p: 2,
          borderTop: "1px solid #eee",
        }}
      >
        <Button
          variant="outlined"
          sx={{
            border: theme.palette.custom.border,
            color: "text.TitleTextcolor",
            borderRadius: "5px",
            textTransform: "none",
          }}
          onClick={onBack}
        >
          Back
        </Button>
        <Button
          variant="contained"
          startIcon={<SaveIcon />}
          sx={{ bgcolor: "#14348D", textTransform: "none" }}
          onClick={handleSaveLayoutToServer}
        >
          {isUpdateMode ? "Update Layout" : "Save Layout"}
        </Button>
      </Box>
      <MModal
        open={dialogOpen}
        // title={dialogMode === "editOid" ? "Edit OID" : "Edit Title"}
        title={
          dialogMode === "editWidget"
            ? "Edit Widget"
            : dialogMode === "editOid"
            ? "Edit OID"
            : "Edit Title"
        }
        handleClose={() => setDialogOpen(false)}
        confirmText="Save"
        customWidth="700px"
        enableFullScreen
      >
        {/* Main Grid Wrapper */}
        <Box className="grid grid-cols-2 gap-x-6 gap-y-4">
          {/* Grid Selector: Takes full width (span 2) so inputs underneath look balanced */}
          <Box>
            <Typography
              sx={{
                textAlign: "left",
                fontFamily: "Montserrat",
                fontWeight: "500",
              }}
            >
              Select Grid
            </Typography>
            <MAlarmSelect
              options={widgetOptions}
              value={selectedWidgetKey}
              onChange={(val) => setSelectedWidgetKey(val)}
              multiple={false}
              isDark={isDark}
            />
          </Box>
          {dialogMode === "editWidget" && (
            <>
              {WIDGET_REGISTRY[currentSelectedWidgetType]?.fields?.map(
                (field) => {
                  const fieldValue = widgetMetaFields[field.id] ?? "";

                  return (
                    <Box
                      key={field.id}
                      sx={{
                        gridColumn:
                          field.type === "dynamicOidConfig" ? "span 2" : "auto",
                      }}
                    >
                      {/* LABEL */}
                      {field.label && (
                        <Typography
                          sx={{
                            textAlign: "left",
                            fontWeight: 500,
                            mb: 0.5,
                          }}
                        >
                          {field.label}
                        </Typography>
                      )}

                      {/* TEXT */}
                      {field.type === "text" && (
                        <MInput
                          fullWidth
                          placeholder={field.placeholder}
                          value={fieldValue}
                          onChange={(e) =>
                            handleMetaFieldChange(field.id, e.target.value)
                          }
                        />
                      )}

                      {/* PRESET DROPDOWN */}
                      {field.type === "presetDropdown" && (
                        <MAlarmSelect
                          label=""
                          options={field.options || []}
                          value={fieldValue}
                          onChange={(value) =>
                            handleMetaFieldChange(field.id, value)
                          }
                          multiple={false}
                          isDark={isDark}
                        />
                      )}

                      {/* OID DROPDOWN */}
                      {field.type === "excelDropdown" && (
                        <MAlarmSelect
                          label=""
                          options={effectiveParsedOids}
                          value={fieldValue}
                          onChange={(value) =>
                            handleMetaFieldChange(field.id, value)
                          }
                          multiple={false}
                          isDark={isDark}
                        />
                      )}

                      {/* SWITCH */}
                      {field.type === "switchBtn" && (
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                          }}
                        >
                          <Switch
                            checked={Boolean(fieldValue)}
                            onChange={() =>
                              handleMetaFieldChange(field.id, !fieldValue)
                            }
                          />
                        </Box>
                      )}

                      {/* REMOTE DEVICE SWITCH */}
                      {field.type === "remoteDeviceSwitch" && (
                        <Switch
                          checked={Boolean(fieldValue)}
                          onChange={() =>
                            handleMetaFieldChange(field.id, !fieldValue)
                          }
                        />
                      )}

                      {/* REMOTE DEVICE EDIT SWITCH */}
                      {field.type === "remoteDeviceEditSwitch" && (
                        <Switch
                          checked={Boolean(fieldValue)}
                          onChange={() =>
                            handleMetaFieldChange(field.id, !fieldValue)
                          }
                        />
                      )}

                      {/* DYNAMIC OID CONFIG */}
                      {field.type === "dynamicOidConfig" && (
                        <Box
                          sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 2,
                            mt: 1,
                          }}
                        >
                          {(currentSelectedOids || []).map((oidVal) => {
                            const match = effectiveParsedOids.find(
                              (o) => String(o.value) === String(oidVal)
                            );

                            const oidName = match?.rawName || `OID_${oidVal}`;

                            const currentConfigs =
                              widgetMetaFields.oidConfigs || {};

                            const config = currentConfigs[oidName] || {
                              type: "text",
                              useStepper: false,
                            };

                            const updateOidRule = (ruleKey, value) => {
                              handleMetaFieldChange("oidConfigs", {
                                ...currentConfigs,
                                [oidName]: {
                                  ...config,
                                  [ruleKey]: value,
                                },
                              });
                            };

                            return (
                              <Box
                                key={oidVal}
                                sx={{
                                  p: 2,
                                  border: "1px solid #d6e4ff",
                                  borderRadius: 2,
                                }}
                              >
                                <Typography
                                  sx={{
                                    fontWeight: 600,
                                    mb: 1,
                                  }}
                                >
                                  {oidName}
                                </Typography>

                                <MAlarmSelect
                                  label="Input Type"
                                  options={[
                                    {
                                      label: "Text",
                                      value: "text",
                                    },
                                    {
                                      label: "Number",
                                      value: "number",
                                    },
                                  ]}
                                  value={config.type}
                                  onChange={(value) =>
                                    updateOidRule("type", value)
                                  }
                                  multiple={false}
                                  isDark={isDark}
                                />
                              </Box>
                            );
                          })}
                        </Box>
                      )}
                    </Box>
                  );
                }
              )}

              {/* STATIC / TABLE PARAMETER SELECTION */}
              {[
                "thermometer",
                "fan",
                "voltageGauge",
                "powerSupply",
                "needelGauge",
                "scale",
                "image",
                "remoteDevice",
                "titleWidget",
              ].includes(currentSelectedWidgetType) && (
                <Box sx={{ gridColumn: "span 2" }}>
                  <Typography
                    sx={{
                      fontWeight: 500,
                      mb: 0.5,
                    }}
                  >
                    Parameters / Columns
                  </Typography>

                  <MAlarmSelect
                    label=""
                    options={processedParsedOids}
                    value={currentSelectedOids}
                    onChange={(values) =>
                      setCurrentSelectedOids(
                        Array.isArray(values) ? values.map(String) : []
                      )
                    }
                    multiple={true}
                    isDark={isDark}
                  />
                </Box>
              )}

              {/* STATIC / EDITABLE / SELECT COLUMN COUNT */}
              {["static", "editable", "editableSelect"].includes(
                currentSelectedWidgetType
              ) && (
                <Box>
                  <Typography
                    sx={{
                      fontWeight: 500,
                      mb: 0.5,
                    }}
                  >
                    Parameters / Columns
                  </Typography>

                  <MAlarmSelect
                    label=""
                    options={processedParsedOids}
                    value={currentSelectedOids}
                    onChange={(values) =>
                      setCurrentSelectedOids(
                        Array.isArray(values) ? values.map(String) : []
                      )
                    }
                    multiple={true}
                    isDark={isDark}
                  />
                </Box>
              )}
            </>
          )}
          {currentSelectedWidgetType === "needelGauge" &&
            widgetMetaFields.gaugeRangePreset === "dynamic" && (
              <Box>
                <Typography
                  sx={{
                    fontWeight: 500,
                    mb: 0.5,
                  }}
                >
                  Custom Range
                </Typography>

                <MInput
                  type="number"
                  value={widgetMetaFields.customRangeX || ""}
                  onChange={(e) =>
                    handleMetaFieldChange("customRangeX", e.target.value)
                  }
                  fullWidth
                />
              </Box>
            )}
          {dialogMode === "editOid" && (
            <>
              {/* OID Selector: Takes full width because of the details layout */}
              <Box>
                <Typography
                  sx={{
                    textAlign: "left",
                    fontFamily: "Montserrat",
                    fontWeight: "500",
                  }}
                >
                  Select OID
                </Typography>
                <MAlarmSelect
                  options={oidOptions}
                  // Ensuring it defaults to empty string if undefined so select retains binding control
                  value={
                    selectedOidIndex !== null && selectedOidIndex !== undefined
                      ? selectedOidIndex
                      : ""
                  }
                  onChange={(val) => setSelectedOidIndex(val)}
                  multiple={false}
                  isDark={isDark}
                />
              </Box>

              {/* New Name Input Wrapper: Takes 1 Column */}
              <Box sx={{ width: "100%" }}>
                <Typography
                  sx={{
                    textAlign: "left",
                    fontFamily: "Montserrat",
                    fontWeight: "500",
                  }}
                >
                  New Name
                </Typography>
                <MInput
                  placeholder="Enter new name"
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  // Ensures the underlying input stretches inside its Box boundary
                />
              </Box>

              {/* New OID Input Wrapper: Takes 1 Column */}
              <Box sx={{ width: "100%" }}>
                <Typography
                  sx={{
                    textAlign: "left",
                    fontFamily: "Montserrat",
                    fontWeight: "500",
                  }}
                >
                  New OID
                </Typography>
                <MInput
                  placeholder="Enter new OID"
                  value={editedOid}
                  onChange={(e) => setEditedOid(e.target.value)}
                />
              </Box>
            </>
          )}

          {dialogMode === "editTitle" && (
            /* New Title Input Wrapper: Spans across both columns to be completely full width */
            <Box>
              <Typography
                sx={{
                  textAlign: "left",
                  fontFamily: "Montserrat",
                  fontWeight: "500",
                }}
              >
                New Title
              </Typography>
              <MInput
                placeholder="Enter new title"
                value={editedTitle}
                onChange={(e) => setEditedTitle(e.target.value)}
                fullWidth
              />
            </Box>
          )}
        </Box>

        {/* Action Buttons */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 2,
            mt: 5,
          }}
        >
          <MButtonSecondary onClick={() => setDialogOpen(false)}>
            Cancel
          </MButtonSecondary>
          <MButtonPrimary
            onClick={() => {
              if (dialogMode === "editWidget") {
                handleSaveEditedWidget();
              } else if (dialogMode === "editOid") {
                handleEditOid();
              } else {
                handleEditTitle();
              }
            }}
          >
            Save
          </MButtonPrimary>
        </Box>
      </MModal>
    </Box>
  );
};

export default ExcelConfigBuilder;
