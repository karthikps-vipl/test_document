/***********************************************************************************************
  Project                  : IAF-NMS
  SubSystem                : Configuration Manual Backup
  File Name                : ConfigManualBackup.js
  Author                   : ANKITHA - VIPL
  Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\ManualBackup\ConfigManualBackup.jsx
  Purpose                  :  Manual backup for device in configuration.
  Created Date             : 29-04-2026
***********************************************************************************************/

import React, { useEffect, useState } from "react";
import { Box, CircularProgress,Typography, useTheme } from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MSelect from "@/components/Reusable/Select/MSelect";
import TextArea from "antd/es/input/TextArea";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import { FIND_ALL_BACKUP_UPLOAD_TYPE_DEVICE, SINGLE_DEVICE_BACKUP } from "@/RestAPI/url/endpoint";
import { ConfigurationAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";

const formatBackupDate = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  // This returns exactly: YYYY-MM-DD HH:mm:ss
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

const ConfigManualBackup = ({isChildFullScreen}) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resources, setResources] = useState([]);
  const theme = useTheme()
  // Form States
  const [selectedResourceId, setSelectedResourceId] = useState("");
  const [fileName, setFileName] = useState("");
  const [description, setDescription] = useState("");

  // Validation States
  const [fileNameErr, setFileNameErr] = useState("");
  const [descError, setDescError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await InventoryAxios(FIND_ALL_BACKUP_UPLOAD_TYPE_DEVICE, "get");
        const data = response?.data?.map((item) => ({
          id: item.resourceId,
          value: item,
          label: item.resourceName,
        })) || [];
        setResources(data);
      } catch (error) {
        Toast("Warning!", "No devices available for backup", "warning");
        console.error(error)
      }
    };
    fetchData();
  }, []);
  const handleResourceSelect = (item) => {
    // item is the object returned by the find logic in MSelect
    if (!item) return;

    // IMPORTANT: Ensure this matches the ID type (string vs number)
    const resId = item.id || item.value?.resourceId;
    const resName = item.label || item.value?.resourceName;

    setSelectedResourceId(resId);

    // Result: Router_Backup_DT_2026-05-25T11-01-43
    // This replaces all colons (:) AND all spaces ( ) with a dash (-)
    const autoName = `${resName}_Backup_DT_${formatBackupDate(new Date())}`;

    setFileName(autoName);
    setFileNameErr("");
  };

  const validateDescription = (e) => {
    let value = e.target.value;

    // 1. Hard limit
    if (value.length > 255) {
      value = value.slice(0, 255);
    }


    value = value.replace(/[^a-zA-Z\d\._\-\s,]/g, "");

    // Second, forcefully strip any non-letters from the first two positions
    // This prevents "A1" or "1A" or "12"
    const firstTwo = value.slice(0, 1);
    if (/[^a-zA-Z]/.test(firstTwo)) {
      // If there's a non-letter in the first two chars, we must clean it.
      // We re-run the string through a filter that only allows letters for the first 2 slots
      const part1 = value.slice(0, 1).replace(/[^a-zA-Z]/g, "");
      const part2 = value.slice(2);
      value = part1 + part2;
    }

    // 3. Update the state
    setDescription(value);

    // 4. Validation Logic (The Error Message)
    if (value.length === 0) {
      setDescError("");
    } else if (value.length <= 2) {
      setDescError("Need more than 2 Characters");
    } else {
      const firstTwoAreLetters = /^[a-zA-Z]{1}/.test(value);
      if (!firstTwoAreLetters) {
        setDescError("Must start with 1 letters");
      } else {
        setDescError("");
      }
    }
  };
  const handleSave = async () => {
    setShowConfirm(false);
    if (!selectedResourceId || fileNameErr || descError || !description || fileName.length < 3) {
      Toast("Error!", "Please fix validation errors before proceeding.", "error");
      return;
    }

    setLoading(true);
    const payload = {
      description: description,
      fileName: fileName,
      resourceInfo: {
        resourceId: selectedResourceId,
      },
    };
    try {
      const response = await ConfigurationAxios(SINGLE_DEVICE_BACKUP, "post", payload);
    
      if (response?.status === 200 && response?.data?.status === 1) {
        Toast("Success!", "Backup taken successfully.", "success");
        // Reset form
        setDescription("");
        setFileName("");
        setSelectedResourceId("");
      } 
      else if (response?.status === 200 && response?.data?.status === 0) {
        Toast("Warning!", response?.data?.message, "warning");
      } 
      else {
        Toast("Error!", "Backup Failed!", "error");
      }
    } catch (error) {
      Toast("Error!", "Backup Failed! Check server logs.", "error");
      console.error(error);
    } finally {
      setLoading(false);
    }};
  //   try {
  //     const response = await ConfigurationAxios(SINGLE_DEVICE_BACKUP, "post", payload);
  //     // Status check logic from old code
  //     if (response?.data?.status === 1 || response?.status === 200) {
  //       Toast("Success!","Backup taken successfully.", "success");
  //       // Reset form
  //       setDescription("");
  //       setFileName("");
  //       setSelectedResourceId("");
  //     } else {
  //       Toast("Error!","Backup Failed!", "error");
  //     }
  //   } catch (error) {
  //     Toast("Error!", "Backup Failed! Check server logs.", "error");
  //     console.error(error)
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // Button disabled logic from old code's isValid
  const isFormInvalid = !selectedResourceId || !description || !!descError || !!fileNameErr || fileName.length < 3;
  if (!resources || resources.length === 0) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
        <Typography textAlign="center">No devices available for backup</Typography>
      </Box>
    );
  }
 
  return (
    <MForm title="Manual Backup">
      {/* 
         We use a single Column layout inside MForm. 
         Note: MForm has p: 3, so we use ml: 3 to align content with your previous design 
      */}
      <Box sx={{
        display: 'flex', flexDirection: 'column', width: '75%',
      }}>

        {/* Device Selection */}
        <Typography sx={{ fontFamily: "Montserrat", fontWeight: 500, mb: 0.5 }}>Device Name *</Typography>
        <MSelect
          options={resources}
          value={selectedResourceId} // The state containing the ID
          getOptionValue={(option) => option.id} // Tell it to use 'id' as the comparison key
          onChange={handleResourceSelect}
          placeholder="Select a device"
        />


        {/* 2. File Name Input */}
        <Box sx={{ mt: 2 }}>
          <FormField
            label="File Name "
            required={true}
            value={fileName}
            placeholder="Must be 3-50 characters"
            errorMessage={fileNameErr}
            onChange={(e) => {
              const val = e.target.value;
              setFileName(val);
              setFileNameErr(val.length < 3 ? "Must be length of 3 - 50 characters" : "");
            }}
          />
        </Box>

        {/* 3. Task Description (Custom TextArea) */}
        <Box sx={{ mt: 2 }}>
          <Typography sx={{ fontFamily: "Montserrat", fontWeight: 500, mb: 0.5 }}>
            Task Description *
          </Typography>
          <TextArea
            rows={4}
            value={description}
            placeholder="Must be 3-255 characters"
            onChange={validateDescription}
            // Add a custom class so we can target the placeholder in CSS
            className={theme.palette.mode === 'dark' ? "dark-ant-textarea" : ""}
            style={{
              borderColor: descError ? '#ff4d4f' : '#d9d9d9',
              fontFamily: "Montserrat",
              resize: 'none',
              width: '100%',
              // Set background and text color
              background: theme.palette.mode === 'dark' ? "#121212" : "#ffffff",
              color: theme.palette.mode === 'dark' ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
            }}
          />
          <Typography
            variant="caption"
            sx={{ color: descError ? "#e75656" : "textSecondary", display: 'block', mt: 0.5 }}
          >
            {descError ? descError : `${description.length}/255`}
          </Typography>
        </Box>

        {/* 4. Action Button */}
        <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-start" }}>
          <MButtonPrimary
            disabled={loading || isFormInvalid}
            onClick={() => setShowConfirm(true)}
          >
            {loading ? <CircularProgress size={24} color="inherit" /> : "Backup"}
          </MButtonPrimary>
        </Box>
      </Box>

      <MDialog
        open={showConfirm}
        mode="child"
        isChildFullScreen={isChildFullScreen}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Action"
        message={`Are you sure you want to take a backup for ${fileName}?`}
        onConfirm={handleSave}
        onClose={() => setShowConfirm(false)}
      />
    </MForm>
  );
};

export default ConfigManualBackup;