/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DeviceLoginManagement
   File Name                : DeviceAddLoginMgmt.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\DeviceLoginManagement\ConfigAddDeviceLogin.jsx
   Purpose                  : Provides form for adding new device login credentials.
   Created Date             : 22-04-2026
***********************************************************************************************/
import React, { useEffect, useState } from "react";
import { Box, IconButton, InputAdornment, Typography } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { ConfigurationAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_RESOURCE_INFO_BY_SNMP_AND_SOAP_COMMUNICATION_TYPE,
  SAVE_ROUTER_CONSOLE_DETAILS,
} from "@/RestAPI/url/endpoint";
import { usernameRegex,  } from "@/utility/FormValidation/Regex";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import {
  UsernameValidator,
  PasswordValidatorAdd
} from "@/utility/FormValidation/YupSchema";
import MSelect from "@/components/Reusable/Select/MSelect";
import { encryptData } from "@/utility/encryptLogin";
import MDialog from "@/components/Reusable/Dialog/MDialog";

const ConfigAddDeviceLogin = ({ data, mode, onClose, onSuccess,isGrandchildFullScreen }) => {
  // const { repDetails, siteDetails } = useSelector((state) => state.nodeDetails);
  // const dispatch = useDispatch();
  // const [repTableData, setRepTableData] = useState(
  //   repDetails?.resRepDetails || []
  // );
  const [resources, setResources] = useState([]);
  const [selectedResourceId, setSelectedResourceId] = useState("");
  const [selectedResource, setSelectedResource] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [visibleFields, setVisibleFields] = useState({});
  const toggleVisibility = (fieldName) => {
    setVisibleFields((prev) => ({
      ...prev, // This is crucial! It keeps the other fields as they were
      [fieldName]: !prev[fieldName],
    }));
  };
  const InitialData = {
    resourceId: "",
    userName: "",
    password: "",
  };

  const schema = Yup.object({
    resourceId: Yup.string().required("Please select a device"),
    userName: UsernameValidator,
    password: PasswordValidatorAdd,
  });

  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    onSubmit: async (values) => { },
  });

  const handleInputChange = (event, fieldName) => {
    let value = event.target.value;
    formik.setFieldValue(fieldName, value);
    setTimeout(() => {
      formik.handleBlur({ target: { name: fieldName } });
    }, 0);
  };

  // const isAddDisabled = !formik.values.userName || !formik.values.password;
  // !!(formik.errors.userName || formik.errors.password);
  const isAddDisabled =
    !formik.values.userName ||
    !formik.values.password ||
    !!(formik.errors.userName || formik.errors.password);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await InventoryAxios(
          FETCH_RESOURCE_INFO_BY_SNMP_AND_SOAP_COMMUNICATION_TYPE,
          "get"
        );
        const data = response?.data.map((item) => ({
          id: item.resourceId,
          value: item,
          label: item.resourceName,
        }));
        setResources(data);

        // TEST: Manually force a value into Formik to see if Save works
        if (data.length > 0) {
          formik.setFieldValue("resourceId", data[0].value.resourceId);
        }
      } catch (error) {
        console.error(error);
      }
    };
    fetchData();
  }, []);

  const handleResourceSelect = (option) => {
    setShowConfirm(false);

    // If option is just a string (the ID), handle that
    if (typeof option === "string") {
      const id = option;
      const foundResource = resources.find((r) => r.value.resourceId === id);

      setSelectedResourceId(id);
      setSelectedResource(foundResource ? foundResource.value : null);
      formik.setFieldValue("resourceId", id);
    }
    // If option is the object { value, label, resourceId }
    else if (option && option.resourceId) {
      setSelectedResourceId(option.resourceId);
      setSelectedResource(option);
      formik.setFieldValue("resourceId", option.resourceId);
    }
    // If option is the object { value: { resourceId: ... } } (common in some MUI wrappers)
    else if (option && option.value && option.value.resourceId) {
      setSelectedResourceId(option.value.resourceId);
      setSelectedResource(option);
      formik.setFieldValue("resourceId", option.value.resourceId);
    } else {
      // Reset
      setSelectedResource(null);
      setSelectedResourceId("");
      formik.setFieldValue("resourceId", "");
    }
  };
  const handleSave = async () => {
    // Validate the form
    const errors = await formik.validateForm();

    if (Object.keys(errors).length > 0) {
      formik.setTouched({
        resourceId: true,
        userName: true,
        password: true,
      });
      return; // Stop here if there are errors
    }

    // If valid, ONLY show the confirm dialog.
    // DO NOT call ConfigurationAxios here.
    setShowConfirm(true);
  };
  // Add this function inside your component
  const handleConfirmSubmit = async () => {
    // Close the dialog first
    setShowConfirm(false);

    const resourceId = selectedResourceId;
    const resourceName = resources.find(
      (r) => r.value.resourceId === resourceId
    )?.value.resourceName;

    const payload = {
      username: encryptData(formik.values.userName),
      password: encryptData(formik.values.password),
      resourceInfo: {
        resourceId: resourceId,
        resourceName: resourceName,
      },
    };

    try {
      const response = await ConfigurationAxios(
        SAVE_ROUTER_CONSOLE_DETAILS,
        "post",
        payload
      );

      if (response.status === 200 || response.status === 201) {
        Toast("Success!", "Details saved successfully!", "success");
        onSuccess();
        onClose();
      } else {
        Toast(
          "Error!",
          "Failed to save details.",
          "error"
        );
      }
    } catch (error) {
      console.error("Error saving details:", error);
      Toast("Error!", "Failed to save details. Please try again.", "error");
    }
  };

  return (
    <Box
      component="form"
      onSubmit={formik.handleSubmit}
      className="flex flex-col gap-5 "
      sx={{ ml: 3, mr: 5 }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",

          width: "100%",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",

            mt: 2,
          }}
        >
          <Typography sx={{ mb: 0.5 }}>Device Name *</Typography>
          <MSelect
            options={resources}
            placeholder="Select Device Name"
            value={selectedResource}
            onChange={(value) => handleResourceSelect(value)}
            error={
              formik.touched.resourceId && Boolean(formik.errors.resourceId)
            }
            errorMessage={formik.touched.resourceId && formik.errors.resourceId}
          />
        </Box>
      </Box>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Typography
          sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}
        >
          User Name *
        </Typography>
        <MInput
          fullWidth
          placeholder="Enter a Username"
          size="small"
          value={formik.values.userName}
          onChange={(e) => {
            const data = usernameRegex(e.target.value);
            if (data !== undefined) {
              handleInputChange(e, "userName");
            }
          }}
          errorMessage={formik.touched.userName && formik.errors.userName}
        />
      </Box>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Typography
          sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}
        >
          Password *
        </Typography>
        <MInput
  fullWidth
  placeholder="Enter a Password"
  size="small"
  // Use the visibility state to switch type
  type={visibleFields.password ? "text" : "password"}
  // Use Formik's internal value directly
  value={formik.values.password} 
  onChange={(e) => {
    const val = e.target.value;
    // 1. Prevent spaces
    if (val.includes(" ")) return;
    
    // 2. Enforce Max 32 characters
    if (val.length <= 32) {
      // Use setFieldValue explicitly to ensure Formik's state updates
      formik.setFieldValue("password", val);
    }
  }}
  onBlur={() => formik.setFieldTouched("password", true)}
  errorMessage={
    (formik.touched.password || formik.values.password.length > 0) && formik.errors.password
  }
  InputProps={{
    endAdornment: (
      <InputAdornment position="end">
        <IconButton 
          onClick={() => toggleVisibility("password")} 
          edge="end"
          onMouseDown={(e) => e.preventDefault()} // Keeps focus
        >
          {visibleFields.password ? <VisibilityIcon /> : <VisibilityOffIcon />}
        </IconButton>
      </InputAdornment>
    ),
  }}
/>
      </Box>

      <Box
        sx={{
          float: "right",
          display: "flex",
          mt: 3,
          gap: "7%",
          justifyContent: "flex-end",
        }}
      >
        <MButtonPrimary onClick={handleSave} disabled={isAddDisabled}>
          Add
        </MButtonPrimary>
      </Box>
      <MDialog
        open={showConfirm}
        variant="warning" // or "error" depending on your theme
        title="Confirm Action"
        icon={question_mark} // Replace with a question/warning icon if you have one
        message="Are you sure you want to add this Device login Details?"
        onConfirm={handleConfirmSubmit}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};
export default ConfigAddDeviceLogin;
