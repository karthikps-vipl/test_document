/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DeviceLoginManagement
   File Name                : DeviceViewLoginMgmt.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\DeviceLoginManagement\ConfigViewDeviceLogin.jsx
   Purpose                  : Provides form for viewing device login credentials.
   Created Date             : 28-04-2026
***********************************************************************************************/

import React, { useState } from "react";
import { Box, Typography, CircularProgress, InputAdornment, IconButton } from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_ROUTER_CONSOLE_DETAILS_BY_ID_AUTH } from "@/RestAPI/url/endpoint";
import { encryptData } from "@/utility/encryptLogin";
import { useSelector } from "react-redux";
import { Visibility, VisibilityOff } from "@mui/icons-material";

const ConfigViewRepDetails = ({ data }) => {
  const userName = useSelector((state) => state.userSlice.userDetails.data.userName);
  const [verifyPassword, setVerifyPassword] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // New states for validation
  const [errorMsg, setErrorMsg] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  
  const [viewedInfoFromDb, setViewedInfoFromDb] = useState({
    resourceName: "",
    userName: null,
    password: "",
  });

  // Your provided Validation Logic
  const passwordComplexityRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d!@#$%&()*+=\-_.$]*$/;

  const validatePassword = (val) => {
    if (!val) return "Password is required";
    if (val.includes(" ")) return "Spaces are not allowed";
    if (val.length < 8) return "Password must be at least 8 characters long";
    if (val.length > 32) return "Password cannot exceed 32 characters";
    if (!passwordComplexityRegex.test(val)) {
      return "Must contain Uppercase, Lowercase, a Number, and allowed special characters";
    }
    return ""; // No error
  };

  const handleInputChange = (e) => {
    const val = e.target.value;
    
    // Prevent spaces immediately
    if (val.includes(" ")) return;

    // Limit length
    if (val.length <= 32) {
      setVerifyPassword(val);
      // Real-time validation feedback
      setErrorMsg(validatePassword(val));
    }
  };

  const handleVerify = async () => {
    // 1. Run validation before API call
    const validationError = validatePassword(verifyPassword);
    if (validationError) {
      setErrorMsg(validationError);
      Toast("Error", validationError, "error");
      return;
    }

    setLoading(true);
    setErrorMsg(""); // Clear errors on new attempt

    try {
      const payload = {
        password: encryptData(verifyPassword),
        userName: encryptData(userName),
      };
      const response = await ConfigurationAxios(
        `${FETCH_ROUTER_CONSOLE_DETAILS_BY_ID_AUTH}/${data.id}`,
        "post",
        payload
      );

      if (response.status === 200 || response.data?.success) {
        const dbData = response.data?.data;
        if (dbData) {
          setViewedInfoFromDb({
            resourceName: dbData.resourceInfo?.resourceName || "N/A",
            userName: dbData.username || "N/A",
            password: dbData.password || "N/A",
          });
          setIsVerified(true);
          Toast("Success", "Access Granted", "success");
        } else {
          Toast("Error", "Incorrect Password", "error");
        }
      } else {
        Toast("Error", "Incorrect Password", "error");
      }
    } catch (error) {
      console.error("Verification Error:", error);
      Toast("Error", "Verification failed. Please try again.", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ ml: 3, mr: 5 }}>
      {!isVerified ? (
        <Box className="flex flex-col mt-2">
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            Password *
          </Typography>
          
          <MInput
            fullWidth
            type={showPassword ? "text" : "password"}
            placeholder="Enter Password"
            label="Verification Password"
            value={verifyPassword}
            disabled={loading}
            onChange={handleInputChange}
            // Pass the validation error to your MInput component
            errorMessage={errorMsg} 
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => setShowPassword(!showPassword)}
                    edge="end"
                    disabled={loading}
                  >
                    {showPassword ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />

<Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
            <MButtonPrimary
              onClick={handleVerify}
              fullWidth
              // Disable button if loading, password is empty, OR if there is a validation error
              disabled={loading || !verifyPassword || !!errorMsg}
            >
              {loading ? <CircularProgress size={24} color="inherit" /> : "Confirm"}
            </MButtonPrimary>
          </Box>
        </Box>
 

 
      ) : (
        /* This part only renders once setIsVerified(true) is called after successful data fetch */
        <Box sx={{ display: "flex", flexDirection: "column", mr: 8, width: "100%" }}>
          <Box sx={{ display: "flex", flexDirection: "column", mr: 2, width: "100%", mt: 2 }}>
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>Device Name</Typography>
            <MInput
              fullWidth
              placeholder="Device Name"
              size="small"
              value={viewedInfoFromDb.resourceName}
              disabled // Usually, viewed details should be read-only
              errorMessage={null}
            />
          </Box>

          <Box sx={{ display: "flex", flexDirection: "column", mr: 8, width: "100%", mt: 2 }}>
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>User Name</Typography>
            <MInput
              fullWidth
              placeholder="Username"
              size="small"
              value={viewedInfoFromDb.userName}
              disabled
              errorMessage={null}
            />
          </Box>

          <Box sx={{ display: "flex", flexDirection: "column", mr: 8, width: "100%", mt: 2 }}>
            <Typography sx={{ textAlign: "left", fontFamily: "Montserrat" }}>Password</Typography>
            <MInput
              fullWidth
              placeholder="Password"
              size="small"
              value={viewedInfoFromDb.password}
              disabled
              errorMessage={null}
            />
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default ConfigViewRepDetails;