/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DeviceLoginManagement
   File Name                : DeviceEditLoginMgmt.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\DeviceLoginManagement\ConfigAddDeviceLogin.jsx
   Purpose                  : Provides form for editing  device login credentials.
   Created Date             : 24-04-2026
***********************************************************************************************/
import React, { useState } from "react";
import { Box, IconButton, InputAdornment, Typography } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  // FETCH_RESOURCE_INFO_BY_SNMP_AND_SOAP_COMMUNICATION_TYPE,
  UPDATE_ROUTER_CONSOLE_DETAILS, // Make sure this is imported from your endpoints
} from "@/RestAPI/url/endpoint";
import { usernameRegex, } from "@/utility/FormValidation/Regex";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import {
  UsernameValidator,
  PasswordValidatorAdd,
} from "@/utility/FormValidation/YupSchema";
import { encryptData } from "@/utility/encryptLogin";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import question_mark from "@/assets/SVGIcons/question_mark.svg"

const ConfigEditDeviceLogin = ({ data, onClose, onSuccess ,isGrandchildFullScreen}) => {
  const [loading, setLoading] = useState(false);
  // const [resources, setResources] = useState([]);
  const [showPassword, setShowPassword] = useState(false); // Toggle state
  const [showConfirm, setShowConfirm] = useState(false);
  const schema = Yup.object({
    userName: UsernameValidator,
    password: PasswordValidatorAdd,
  });

  const formik = useFormik({
    initialValues: {
      userName: data?.username || "",
      password: data?.password || "",
    },
    validationSchema: schema,
    enableReinitialize: true,
    onSubmit: () => handleUpdate(),
  });
  // Check if any field has actually been changed from the original data
  // This checks if the User Name changed OR if the Password changed
  const isAnyFieldChanged =
    formik.values.userName !== (data?.username || "") ||
    formik.values.password !== (data?.password || "");

  // Fetch Devices for the dropdown
  // useEffect(() => {
  //   const fetchResources = async () => {
  //     try {
  //       const response = await InventoryAxios(FETCH_RESOURCE_INFO_BY_SNMP_AND_SOAP_COMMUNICATION_TYPE, "get", 1);

  //       const formatted = response?.data?.map((item) => ({
  //         id: item.resourceId,
  //         value: item,
  //         label: item.resourceName,
  //       })) || [];
  //       setResources(formatted);
  //     } catch (error) {
  //       Toast("Error!", "Failed to fetch device list", "error");
  //       console.error(error)
  //     }
  //   };
  //   fetchResources();
  // }, []);

  const handleUpdate = async () => {
    const rowId = data?.id;

    if (!rowId) {
      Toast("Error!", "Record ID is missing. Cannot update.", "error");
      return;
    }

    const payload = {
      id: rowId, // Passing the ID here
      username: encryptData(formik.values.userName),
      password: encryptData(formik.values.password),
      resourceInfo: {
        resourceId: data?.resourceId,
        resourceName: data?.resourceName,
      },
    };

    setLoading(true);
    try {
      const response = await ConfigurationAxios(
        UPDATE_ROUTER_CONSOLE_DETAILS,
        "post",
        payload
      );
      if (response.status === 200 || response.data?.status === 1) {
        Toast("Success!", "Details updated successfully!", "success");
        onSuccess();
        onClose();
        console.log(response, "response");
      } else {
        Toast("Error!","Update failed", "error");
      }
    } catch (error) {
      Toast("Error!", "Failed to update details.", "error");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  const handleConfirmSubmit = () => {
    setShowConfirm(false);
    formik.handleSubmit(); // This triggers the onSubmit defined in useFormik
  };


  return (
    <Box sx={{ display: "flex", flexDirection: "column", ml: 3 }}>
      {/* Device Selection */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          mr: 5,

          mt: 2,
        }}
      >
        <Typography sx={{ mb: 0.5 }}>Device Name*</Typography>
        <MInput value={data?.resourceName} disabled readOnly={true} />
      </Box>

      {/* Username */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          mr: 5,

          mt: 2,
        }}
      >
        <Typography sx={{ mb: 0.5 }}>User Name*</Typography>
        <MInput
          fullWidth
          value={formik.values.userName}
          onChange={(e) => {
            if (usernameRegex(e.target.value) !== undefined) {
              formik.setFieldValue("userName", e.target.value);
            }
          }}
          errorMessage={formik.touched.userName && formik.errors.userName}
        />
      </Box>

      <Box
  sx={{
    display: "flex",
    flexDirection: "column",
    mr: 5,
    mt: 2,
  }}
>
  <Typography sx={{ mb: 0.5 }}>Password*</Typography>
  <MInput
    fullWidth
    size="small"
    type={showPassword ? "text" : "password"}
    value={formik.values.password}
    onChange={(e) => {
      const val = e.target.value;

      // 1. Rule: No blank space allowed
      if (val.includes(" ")) return;

      // 2. Rule: Max 32 characters
      if (val.length <= 32) {
        // We update the value directly. 
        // This allows 'invalid' characters to be typed so Yup can show the error message.
        formik.setFieldValue("password", val);
      }
    }}
    // 3. Rule: Trigger error message when user clicks out of the box
    onBlur={() => formik.setFieldTouched("password", true)}
    
    // This will now work because formik.values.password is actually changing
    errorMessage={formik.errors.password && formik.errors.password}
    
    InputProps={{
      endAdornment: (
        <InputAdornment position="end">
          <IconButton
            onClick={() => setShowPassword(!showPassword)}
            edge="end"
          >
            {showPassword ? <Visibility /> : <VisibilityOff />}
          </IconButton>
        </InputAdornment>
      ),
    }}
  />
</Box>

      <Box sx={{ display: "flex", mt: 3, justifyContent: "flex-end", mr: 5 }}>
        <MButtonPrimary
           onClick={() => setShowConfirm(true)} 
          disabled={loading || !isAnyFieldChanged || !formik.isValid}
        >
          {loading ? "Updating..." : "Update"}
        </MButtonPrimary>
      </Box>
      <MDialog
        open={showConfirm}
        variant="warning"
        title="Confirm Action"
        icon={question_mark} // Ensure question_mark is imported
        message="Are you sure you want to update the device login credentials?"
        onConfirm={handleConfirmSubmit}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
    
  );
};

export default ConfigEditDeviceLogin;
