/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DeviceLoginManagement
   File Name                : DeviceLoginMgmt.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\DeviceLoginManagement\ConfigDeviceLoginMgmt.jsx
   Purpose                  : Manages the main interface for device login credentials.
   Created Date             : 19-04-2026
***********************************************************************************************/

import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useState } from "react";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  DELETE_ROUTER_CONSOLE_DETAILS,
  FETCH_ALL_ROUTER_CONSOLE_DETAILS,
} from "@/RestAPI/url/endpoint";
import { Box } from "@mui/material";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useSelector } from "react-redux";

const DeviceLoginMgmt = ({
  privilegeKey,
  handleAdd,
  handleEdit,
  handleView,
  refreshTrigger,
  isChildFullScreen
}) => {
  const userName = useSelector(
    (state) => state.userSlice.userDetails.data.userName
  );

  const [repDetails, setRepDetails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });
  const pseudoPassword = "**********";
  const columns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "Device Name", uid: "resourceName", width: "260px" },
    { name: "User Name", uid: "username", width: "150px" },
    { name: "Password", uid: "password", width: "140px" },
    { name: "Actions", uid: "actions" },
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await ConfigurationAxios(
          FETCH_ALL_ROUTER_CONSOLE_DETAILS,
          "get"
        );
        const data = response?.data?.data;
        console.log(data, " adadsds");

        if (data && Array.isArray(data)) {
          const processedData = data.map((item, index) => {
            const rawPassword = item?.password ?? "";

            return {
              sno: index + 1,
              resourceName: item?.resourceInfo?.resourceName ?? "N/A",
              username: item?.username ?? "N/A",
              password: pseudoPassword,
              originalPassword: rawPassword,
              actions: item.actions,
              id: item.id || index,
              resourceId: item?.resourceInfo?.resourceId,
            };
          });

          setRepDetails(processedData);
        } else {
          setRepDetails([]);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setRepDetails([]);
        Toast("Error!", "Failed to fetch device details", "error");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [refreshTrigger]);
  

  const handleDeleteRow = async (row) => {
    console.log(row, "fdfdfdfdf");

    setRepDetails((prevData) => prevData.filter((item) => item.id !== row.id));

    try {
      await ConfigurationAxios(
        `${DELETE_ROUTER_CONSOLE_DETAILS}/${row.id}`,
        "post",
        ""
      );
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Box >
      {loading ? (
        <Box className="flex justify-center p-10">
          {/* <CircularProgress size={30} /> */}
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          columns={columns}
          tableData={repDetails}
          showPagination={true}
          hideAdd={false}
          // Handle Add
          handleAdd={() =>
            handleAdd({ mode: "CREATE", title: "Add  Login Details" })
          }
          // Handle Edit - Pass originalPassword instead of the asterisks
          handleEdit={(row) =>
            handleEdit({
              ...row,
              password: row.originalPassword,
              mode: "EDIT",
              title: "Update Login Details",
            })
          }
          handleDelete={(row) => {
            setRowToDelete({ visible: true, row: row });
          }}
          handleView={(row) =>
            handleView({
              ...row,

              //password: row.originalPassword,
              mode: "VIEW",
              title: "Enter " + userName + " password",
            })
          }
          // Export Logic - Use current state

          handleDownloadPDF={() =>
            exportToPDF(
              "Device Login Report",
              columns,
              repDetails,
              "Device_Login_Report"
            )
          }
          handleDownloadCSV={() =>
            exportToCSV("Device_Login_Export", columns, repDetails)
          }
          showSearch={true}
          AddText="Add"
        />
      )}

      {rowToDelete.visible && (
        <MDialog
          open={rowToDelete.visible}
          variant="error"
          title="Confirm Action"
          mode="child"
          isChildFullScreen={isChildFullScreen}
          message={`Are you sure you want to delete ${rowToDelete.row.username}  login detail?`}
          icon={Delete_Icon_}
          onConfirm={() => {
            handleDeleteRow(rowToDelete.row);
            setRowToDelete({ visible: false, row: null });
            Toast("Success!", "Successfully deleted row", "success");
          }}
          onClose={() => setRowToDelete({ visible: false, row: null })}
        />
      )}
    </Box>
  );
};

export default DeviceLoginMgmt;
