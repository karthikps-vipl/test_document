/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Location
   File Name                : ConfigLocation.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\Location\ConfigLocation.jsx
   Purpose                  : Renders the "Modify Site Details" form, capturing terminal-specific 
                               information including Site Number, Name, Unit Name, and 
                               geospatial coordinates (Latitude/Longitude).
   Created Date             : 11-04-2026
***********************************************************************************************/
import React, { useEffect, useState } from "react";
import { Box, Typography, Button, CircularProgress, Divider } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";

// Custom Components
 import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { NODE_DETAILS, UPDATE_LOCATION_API } from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import { SitenameRegex ,SiteNicknameRegex} from "@/utility/FormValidation/Regex";
import {
 
   
  LongitudeValidator,
  LatitudeValidator,
  SitenameValidator,
  SiteNicknameValidator,
} from "@/utility/FormValidation/YupSchema";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { useDispatch } from 'react-redux';
import { setRepDetails } from '@/store/features/nodeDetailsSlice'; // Adjust the path to your actual slice file
import FormField from "@/components/Reusable/Form/FormField";
import MForm from "@/components/Reusable/Form/MForm";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
const ConfigLocation = ({isChildFullScreen}) => {
  const dispatch = useDispatch(); 
  const [loading, setLoading] = useState(true);
  const [rnmsData, setRnmsData] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
 // In your component state definition:
   const terminalNickname = useSelector(
    (state) => state.nodeDetails.siteDetails?.terminalTypeName
  );

  const formik = useFormik({
    // 1. enableReinitialize ensures dirty state resets correctly after API data loads
    enableReinitialize: true,
    initialValues: {
      siteNumber: rnmsData?.remoteNumber || "",
      siteName: rnmsData?.siteName || "",
      unitName: rnmsData?.siteNickName || "",
      longitude: rnmsData?.longitude || "",
      latitude: rnmsData?.latitude || "",
      terminalTypeName: rnmsData?.imTerminalType?.terminalTypeName || "N/A",
    },
    validationSchema: Yup.object({
      siteName: SitenameValidator,
      unitName:SiteNicknameValidator ,
      longitude: LongitudeValidator,
      latitude: LatitudeValidator,
    }),
    onSubmit: async (values) => {
      try {
        const payload = {
          ...rnmsData,
          remoteNumber: values.siteNumber,
          siteName: values.siteName,
          siteNickName: values.unitName,
          longitude: values.longitude,
          latitude: values.latitude,
        };
        const res = await InventoryAxios(UPDATE_LOCATION_API, "post", payload);
        if (res.status === 200) {
          Toast("Success", "Site details updated successfully", "success");
          // Re-fetch or update local state to reset the 'dirty' status after success
          setRnmsData(payload);
          dispatch(setRepDetails(payload));
        }
      } catch (error) {
        console.error("error", error);
        Toast("Error", "Update failed", "error");
      } finally {
        setShowConfirm(false);
      }
    },
  });

  // Fetch Existing Data from API on Mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await InventoryAxios(NODE_DETAILS, "get");
        if (response?.data) {
          setRnmsData(response.data);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);
  const handleConfirmUpdate = () => {
    formik.handleSubmit(); // This triggers the formik onSubmit logic
  };

  const handleInputChange = (event, fieldName) => {
    let value = event.target.value;
    formik.setFieldValue(fieldName, value);
    // Helps validation trigger immediately
    setTimeout(() => {
      formik.setFieldTouched(fieldName, true);
    }, 0);
  };

  if (loading)
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "50vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
    if (!rnmsData || Object.keys(rnmsData).length === 0) {
      return (
        <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
          <Typography textAlign="center">No site details found</Typography>
        </Box>
      );
    }

return (
  <MForm title="Modify Site Details">
  {/* --- Section 1: Site Details Grid --- */}
  <Box
    // grid-cols-1: stack on mobile
    // md:grid-cols-2: 2 columns on desktop
    className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start"
  >
    <FormField
      label="Terminal"
      disabled={true}
      value={terminalNickname}
    />
    <FormField
      label="Site Number"
      required={true}
      disabled={true}
      value={formik.values.siteNumber}
      errorMessage={formik.touched.siteNumber && formik.errors.siteNumber}
    />
    <FormField
      label="Site Name"
      required={true}
      inputProps={{ maxLength: 25 }}
      value={formik.values.siteName}
      placeholder="Enter Site Name"
      onChange={(e) => {
        if (SitenameRegex(e.target.value) !== undefined)
          handleInputChange(e, "siteName");
      }}
      errorMessage={formik.touched.siteName && formik.errors.siteName}
    />
    <FormField
      label="Unit Name"
      value={formik.values.unitName}
      placeholder="Enter Unit Name"
      onChange={(e) => {
        if (SiteNicknameRegex(e.target.value) !== undefined)
          handleInputChange(e, "unitName");
      }}
      errorMessage={formik.touched.unitName && formik.errors.unitName}
    />
  </Box>

  {/* --- SECTION DIVIDER --- */}
  {/* Removed the 100vw hack. Just use standard padding/margin. */}
  <Box sx={{ my: 4,mx:-3 }}>
    <Divider sx={{ borderBottomWidth: '2px', borderColor: '#eee' }} />
  </Box>

  {/* --- Section 2: Site Location Details --- */}
  <Box>
    <Typography 
      sx={{ 
        fontWeight: "300", 
        fontSize: 16, 
        color: (theme) => theme.palette.custom.table.headerText, 
        mb: 2,
        fontFamily: "Montserrat" 
      }}
    >
      Site Location Details
    </Typography>
    
    <Box
      // Responsive grid: 1 column on mobile, 2 on desktop
      className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start"
    >
      <FormField
        label="Longitude (Dec)"
        required={true}
        name="longitude"
        placeholder="XXX.XXXX"
        value={formik.values.longitude}
        onChange={(e) => {
          const val = e.target.value;
          if (val === "" || (val.length <= 15 && /^\d*(?:\.\d*)?$/.test(val))) {
            formik.setFieldValue("longitude", val);
          }
        }}
        onBlur={() => formik.setFieldTouched("longitude", true)}
        errorMessage={formik.touched.longitude && formik.errors.longitude}
      />
      <FormField
        label="Latitude (Dec)"
        required={true}
        name="latitude"
        placeholder="XX.XXXX"
        inputMode="decimal"
        value={formik.values.latitude}
        onChange={(e) => {
          const val = e.target.value;
          if (val === "" || (val.length <= 15 && /^-?\d*(?:\.\d*)?$/.test(val))) {
            formik.setFieldValue("latitude", val);
          }
        }}
        onBlur={() => formik.setFieldTouched("latitude", true)}
        errorMessage={formik.touched.latitude && formik.errors.latitude}
      />
    </Box>
  </Box>

  {/* --- Action Section --- */}
  <Box sx={{ display: "flex", justifyContent: "end", mt: 4 }}>
    <MButtonPrimary
      variant="contained"
      onClick={() => setShowConfirm(true)}
      disabled={!formik.dirty || !formik.isValid || formik.isSubmitting}
      sx={{
        backgroundColor: "#14348D",
        borderRadius: "10px",
        textTransform: "none",
        px: 4, // Added padding for better button look
        "&:hover": { backgroundColor: "#0e2566" },
        "&.Mui-disabled": {
          backgroundColor: "#ccc",
          color: "#666",
        },
      }}
    >
      {formik.isSubmitting ? "Updating..." : "Update"}
    </MButtonPrimary>
  </Box>

  <MDialog
    open={showConfirm}
    variant="info"
    icon={confirmation_icon}
    title="Confirm Action"
    mode="child"
    isChildFullScreen={isChildFullScreen}
    message="Are you sure you want to update the Site Details?"
    onConfirm={handleConfirmUpdate}
    onClose={() => setShowConfirm(false)}
  />
</MForm>
   
);
};

export default ConfigLocation;