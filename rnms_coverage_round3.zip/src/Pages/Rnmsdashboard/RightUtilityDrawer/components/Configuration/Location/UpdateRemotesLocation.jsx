import React, { useEffect, useState } from "react";
import { Box, CircularProgress, Typography } from "@mui/material";
import { Update } from "@mui/icons-material";
import { useSelector, useDispatch } from "react-redux";

import MInput from "@/components/Reusable/Input/MInput";
import MSelect from "@/components/Reusable/Select/MSelect";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_SITE_DETAILS_BY_ID,
  UPDATE_SITE_LATLONG_DETAILS,
} from "@/RestAPI/url/cnmsEndPoint";
import Toast from "@/components/Reusable/Toast/Toast";
import { setSiteLocationUpdate } from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import {
  validateLatitude,
  validateLongitude,
  sanitizeLatitude,
  sanitizeLongitude,
} from "@/utility/FormValidation/LatLongValidation";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";

const UPDATE_SUCCESS = "RNMS Location updated Successfully";

const UpdateRemotesLocation = ({ isChildFullScreen }) => {
  const dispatch = useDispatch();

  const allTerminalTypes = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails
  );

  const allSites = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails
  );

  const [terminalType, setTerminalType] = useState(null);
  const [siteId, setSiteId] = useState(null);

  const [sites, setSites] = useState([]);

  const [siteName, setSiteName] = useState("");
  const [nickName, setNickName] = useState("");

  const [originalLatitude, setOriginalLatitude] = useState("");
  const [originalLongitude, setOriginalLongitude] = useState("");

  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");

  const [errors, setErrors] = useState({
    latitude: "",
    longitude: "",
  });

  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    if (!terminalType || !Array.isArray(allSites)) {
      setSites([]);
      return;
    }

    const terminalName = terminalType.terminalTypeName;

    const filteredSites = allSites.filter(
      (site) => site.imTerminalType?.terminalTypeName === terminalName
    );

    setSites(filteredSites);
  }, [terminalType, allSites]);

  const handleTerminalChange = (selectedTerminal) => {
    setTerminalType(selectedTerminal);

    setSiteId(null);

    setSiteName("");
    setNickName("");

    setLatitude("");
    setLongitude("");

    setOriginalLatitude("");
    setOriginalLongitude("");

    setErrors({
      latitude: "",
      longitude: "",
    });
  };

  const handleSiteChange = async (selectedSite) => {
    setSiteId(selectedSite);

    setLatitude("");
    setLongitude("");

    setOriginalLatitude("");
    setOriginalLongitude("");

    setErrors({
      latitude: "",
      longitude: "",
    });

    if (!selectedSite?.siteId) {
      setSiteName("");
      setNickName("");
      return;
    }

    // Immediately load values from selected site
    const selectedLatitude = selectedSite.latitude ?? "";
    const selectedLongitude = selectedSite.longitude ?? "";

    setSiteName(selectedSite.siteName ?? "");
    setNickName(selectedSite.siteNickName ?? selectedSite.nickName ?? "");

    setLatitude(String(selectedLatitude));
    setLongitude(String(selectedLongitude));

    setOriginalLatitude(String(selectedLatitude));
    setOriginalLongitude(String(selectedLongitude));

    try {
      setLoading(true);

      const url = FETCH_SITE_DETAILS_BY_ID + "/" + selectedSite.siteId;
      const response = await InventoryAxios(url, "get");

      if (response.data) {
        const fetchedLatitude = response.data.latitude ?? "";
        const fetchedLongitude = response.data.longitude ?? "";

        setSiteName(response.data.siteName ?? "");
        setNickName(response.data.siteNickName ?? response.data.nickName ?? "");

        setLatitude(String(fetchedLatitude));
        setLongitude(String(fetchedLongitude));

        setOriginalLatitude(String(fetchedLatitude));
        setOriginalLongitude(String(fetchedLongitude));
      }
    } catch (error) {
      console.error("Error fetching site details:", error);

      Toast("", error?.message || "Failed to fetch site details", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleLatitudeChange = (event) => {
    const value = event.target.value;

    const sanitizedValue = sanitizeLatitude(value);

    // Invalid input/range
    if (sanitizedValue === null) {
      return;
    }

    setLatitude(sanitizedValue);

    setErrors((prev) => ({
      ...prev,
      latitude:
        sanitizedValue === ""
          ? "Latitude is required"
          : validateLatitude(sanitizedValue),
    }));
  };

  const handleLongitudeChange = (event) => {
    const value = event.target.value;

    const sanitizedValue = sanitizeLongitude(value);

    // Invalid input/range
    if (sanitizedValue === null) {
      return;
    }

    setLongitude(sanitizedValue);

    setErrors((prev) => ({
      ...prev,
      longitude:
        sanitizedValue === ""
          ? "Longitude is required"
          : validateLongitude(sanitizedValue),
    }));
  };

  const hasLocationChanged =
    latitude !== originalLatitude || longitude !== originalLongitude;

  const canUpdate =
    !!siteId &&
    hasLocationChanged &&
    latitude !== "" &&
    longitude !== "" &&
    !errors.latitude &&
    !errors.longitude;

  const handleSubmit = async (event) => {
    event.preventDefault();

    const latitudeError = validateLatitude(latitude);
    const longitudeError = validateLongitude(longitude);

    setErrors({
      latitude: latitudeError,
      longitude: longitudeError,
    });

    if (!siteId) {
      Toast("", "Please select a Site ID", "error");
      return;
    }

    if (latitudeError || longitudeError) {
      return;
    }

    if (!hasLocationChanged) {
      return;
    }

    try {
      setIsSubmitting(true);

      const rnmsData = {
        ...(siteId || {}),
        siteId: siteId.siteId,
        siteName,
        siteNickName: nickName,
        latitude,
        longitude,
      };

      const res = await InventoryAxios(
        UPDATE_SITE_LATLONG_DETAILS,
        "post",
        rnmsData
      );

      if (res && res.status === 200) {
        dispatch(setSiteLocationUpdate(res?.data));

        // New values become the original values
        setOriginalLatitude(latitude);
        setOriginalLongitude(longitude);
        Toast("", "Location updated successfully", "success");
      } else {
        Toast("", "Failed to update location", "error");
      }
    } catch (error) {
      console.error("Error updating location:", error);
      Toast("", "Something went wrong", "error");
    } finally {
      setIsSubmitting(false);
      setOpenDialog(false);
    }
  };

  /*
   * Do not show CNMS in Terminal dropdown,
   * same as the old implementation.
   */
  const terminalOptions = (allTerminalTypes || [])
    .filter((terminal) => terminal.terminalTypeName !== "CNMS")
    .map((terminal) => ({
      ...terminal,

      value: terminal.terminalTypeName,
      label: terminal.terminalTypeName,
    }));

  const siteOptions = (sites || []).map((site) => ({
    ...site,
    value: site.siteId,
    label: site.siteId,
  }));

  return (
    <Box>
      <Box
        // component="form"
        // onSubmit={handleSubmit}
        sx={{
          width: "100%",
          //   border: "1px solid",
          borderColor: "divider",

          padding: "20px",
          marginBottom: "16px",
          border: "2px solid #eee",
          borderRadius: "10px",
        }}
      >
        {/* Terminal + Site */}
        <Box
          sx={{
            display: "flex",
            gap: "10px",
            width: "100%", // Ensure the row takes full width
            justifyContent: "space-between", // Optional: pushes items to edges
          }}
        >
          <MSelect
            label="Terminal*"
            placeholder="Select Terminal"
            options={terminalOptions}
            value={terminalType}
            getOptionLabel={(option) => option.terminalTypeName}
            getOptionValue={(option) => option.terminalTypeName}
            onChange={handleTerminalChange}
            sx={{
              flex: 1, // Takes available space
              minWidth: "300px", // Minimum width
              maxWidth: "350px", // Maximum width (adjust as needed)
            }}
          />

          <MSelect
            label="Site ID*"
            placeholder={
              terminalType ? "Select Site ID" : "Select Terminal first"
            }
            options={siteOptions}
            value={siteId}
            disabled={!terminalType}
            getOptionLabel={(option) => option.siteId}
            getOptionValue={(option) => option.siteId}
            onChange={handleSiteChange}
            sx={{
              flex: 1,
              minWidth: "300px",
              maxWidth: "350px",
            }}
          />
        </Box>

        {/* Location */}
        <Box
          sx={{
            display: "flex",
            gap: "10px",
            marginTop: "10px",
            width: "100%", // Ensure the row takes full width
          }}
        >
          {/* Longitude */}
          <Box sx={{ flex: 1 }}>
            <Typography>Longitude (Dec)</Typography>
            <MInput
              label="Longitude (Dec)"
              value={longitude}
              onChange={handleLongitudeChange}
              error={!!errors.longitude}
              errorMessage={errors.longitude}
              disabled={!siteId}
              sx={{ width: "100%" }} // Force full width of the parent Box
            />
          </Box>

          {/* Latitude */}
          <Box sx={{ flex: 1 }}>
            <Typography>Latitude (Dec)</Typography>
            <MInput
              label="Latitude (Dec)"
              value={latitude}
              onChange={handleLatitudeChange}
              error={!!errors.latitude}
              errorMessage={errors.latitude}
              disabled={!siteId}
              fullWidth
              sx={{ width: "100%" }} // Force full width of the parent Box
            />
          </Box>
        </Box>

        {/* Loading */}
        {loading && (
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              padding: "10px",
            }}
          >
            <CircularProgress size={22} />
          </Box>
        )}

        {/* Update button */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: "20px",
          }}
        >
          {/* {isCnms && privilegesSet?.has?.("configuration_update_location") && ( */}
          <MButtonPrimary
            onClick={() => setOpenDialog(true)}
            variant="contained"
            color="primary"
            startIcon={
              isSubmitting ? (
                <CircularProgress size={20} sx={{ color: "white" }} />
              ) : (
                <Update />
              )
            }
            disabled={!canUpdate || isSubmitting}
          >
            Update
          </MButtonPrimary>
          {/* )} */}
        </Box>

        <MDialog
          open={openDialog}
          onClose={() => setOpenDialog(false)}
          title={"Location update"}
          onConfirm={(e) => handleSubmit(e)}
          message={`Are you sure want to update the Location of site ${siteId?.siteId}`}
          icon={confirmIcon}
          mode="child"
          isChildFullScreen={isChildFullScreen}
        />
      </Box>
    </Box>
  );
};

export default UpdateRemotesLocation;
