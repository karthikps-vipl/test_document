import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Grid,
  useTheme,
} from "@mui/material";
import { TimePicker } from "antd";
import dayjs from "dayjs";

// Reusable Components
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MSelect from "@/components/Reusable/Select/MSelect";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import TextArea from "antd/es/input/TextArea";

// Icons and APIs
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import { UPDATE_SCHEDULER_TASKS } from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";

const ConfigEditScheduleBackup = ({ data, onClose, onSuccess ,isGrandchildFullScreen}) => {
  // UI State
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [descError, setDescError] = useState("");
  const [remainingChar, setRemainingChar] = useState("255 characters remaining");
  const theme = useTheme();
  // Form State
  const [formData, setFormData] = useState({
    id: null,
    taskName: "",
    resourceId: "",
    description: "",
    frequency: "Daily",
    scheduleTime: dayjs(),
    selectedDay: 1,
    selectedDate: 1,
    selectedMonth: 1,
  });

  // Helper to format [HH, mm, ss] array from API to Dayjs object
  const formatTimeForPicker = (timeArray) => {
    const now = dayjs();
    if (Array.isArray(timeArray) && timeArray.length >= 2) {
      return now.hour(timeArray[0]).minute(timeArray[1]).second(timeArray[2] || 0);
    }
    return now;
  };
  const validateDescription = (e) => {
    const value = e.target.value;
    const MAX_LENGTH = 255;

    // 1. PREVENT typing a digit as the first character
    // If the very first character is a digit, we exit the function immediately
    // and do not call setFormData, so the number never appears in the input.
    if (/^\d/.test(value)) {
      setDescError("Description cannot start with a number");
      return;
    }

    // 2. If it's not a starting digit, proceed to update the state
    setFormData((prev) => ({
      ...prev,
      description: value,
    }));

    setRemainingChar(`${value.length}/${MAX_LENGTH}`);

    // 3. Validation Logic for Errors
    if (value.length > MAX_LENGTH) {
      setDescError("Exceeded Maximum Limit");
    } else if (value.trim().length > 0 && value.trim().length <= 2) {
      setDescError("Need more than 2 Characters");
    } else {
      setDescError("");
    }
  };
  // Pre-populate state from the 'data' prop
  useEffect(() => {
    if (data) {
      const freqMap = {
        0: "One Time",
        1: "Daily",
        3: "Quarterly",
        7: "Weekly",
        15: "Fortnightly",
        30: "Monthly",
        365: "Yearly"
      };
      setFormData({
        id: data.id,
        taskName: data.taskName || "N/A",
        resourceId: data.resourceInfo?.resourceId || "",
        description: data.taskDescription || "",
        frequency: freqMap[data.taskTriggerType] || "Daily",
        scheduleTime: data.cronJobInfo
          ? formatTimeForPicker(data.cronJobInfo.taskTriggerTime)
          : dayjs(),
        selectedDay: data.cronJobInfo?.dayOfTheWeek || 1,
        selectedDate: data.cronJobInfo?.dayOfTheMonth || 1,
        selectedMonth: data.cronJobInfo?.monthOfTheYear || 1,
      });
    }
  }, [data]);

  // Options
  const dateOptions = Array.from({ length: 31 }, (_, i) => ({ label: i + 1, value: i + 1 }));

  const monthOptions = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ].map((m, i) => ({ label: m, value: i + 1 }));

  const handleUpdateSubmit = async () => {
    setShowConfirm(false);
    setLoading(true);

    const freqToType = {
      "One Time": 0,
      "Daily": 1,
      "Weekly": 7,
      "Fortnightly": 15, // ADDED
      "Monthly": 30,
      "Quarterly": 3,    // ADDED
      "Yearly": 365
    };
    const payload = {
      id: formData.id,
      taskName: formData.taskName,
      taskDescription: formData.description,
      taskTriggerType: freqToType[formData.frequency],
      cronJobInfo: {
        taskTriggerTime: formData.scheduleTime.format("HH:mm:ss"),

        // Logic: Only send day if Weekly, else 0
        dayOfTheWeek: formData.frequency === "Weekly" ? formData.selectedDay : 0,

        // Logic: Only send date if Monthly/Yearly, else 0
        dayOfTheMonth: (formData.frequency === "Monthly" || formData.frequency === "Yearly") ? formData.selectedDate : 0,

        // Logic: Only send month if Yearly, else 0
        monthOfTheYear: formData.frequency === "Yearly" ? formData.selectedMonth : 0,
      },
    };
    console.log("resposneeeeeee", payload)

    try {
      const response = await ConfigurationAxios(UPDATE_SCHEDULER_TASKS, "post", payload);
      if (response?.status === 200 || response?.data?.success) {
        Toast("Success!", "Backup schedule updated.", "success");
        onSuccess();
        onClose();
      } else {
        Toast("Error!", "Failed to update schedule.", "error");
      }
    } catch (error) {
      Toast("Error!", "Server Error.", "error");
      console.error(error)
    } finally {
      setLoading(false);
    }
  };

  const isNextDisabled = () => {
    if (activeStep === 0) return formData.description.trim().length < 3;
    return false;
  };

  return (
    <Box sx={{ mt: 2, ml: 2 }}>


      <Stepper activeStep={activeStep} sx={{ mb: 2 }}>
        {["Task ", "Create", "Trigger"].map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {/* Main Content Area (The Box with the Border) */}
      <Box
        sx={{
          minHeight: "280px",
          border: "2px solid #eee",
          p: 1.5,
          borderRadius: "10px",

        }}
      >
        <Grid container justifyContent="left">
          {/* STEP 0: Task Details */}
          {activeStep === 0 && (
            <Grid item xs={12} md={8} sx={{ width: "100%", display: 'flex', flexDirection: 'column' }}>
              <Typography sx={{ mb: 1, }}>Device Name *</Typography>
              <MInput
                fullWidth
                value={formData.taskName}
                disabled={true}
                sx={{ width: "100%", }}
              />


              <Typography sx={{ mt: 3, mb: 1 }}>
                Description *
              </Typography>

              <TextArea
                rows={5}
                value={formData.description}
                // CHANGE THIS LINE BELOW:
                onChange={validateDescription}
                placeholder="Min 3 characters"

                maxLength={255}
                className={theme.palette.mode === 'dark' ? "dark-ant-textarea" : ""}
                style={{
                  resize: "none",
                  borderColor: descError ? '#ff4d4f' : '#d9d9d9',
                  fontFamily: "Montserrat",

                  width: '100%',
                  // Set background and text color
                  background: theme.palette.mode === 'dark' ? "#333333" : "#ffffff",
                  color: theme.palette.mode === 'dark' ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
                }}
              />

              {/* Don't forget to display the error message somewhere! */}
              {descError && <span style={{ color: '#e75656', fontSize: '12px' }}>{descError}</span>}

              {/* And display the character counter */}
              <div style={{ textAlign: 'left', fontSize: '12px' }}>
                {remainingChar}
              </div>
            </Grid>
          )}

          {/* STEP 1: Frequency */}
          {activeStep === 1 && (
            <Grid item xs={12} md={6}>
              <Typography sx={{ mb: 2, fontWeight: 500 }}>Frequency *</Typography>
              <RadioGroup
                value={formData.frequency}
                onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
              >
                {["Daily", "Weekly", "Fortnightly", "Monthly", "Quarterly", "Yearly"].map((item) => (<FormControlLabel
                  key={item}
                  value={item}
                  control={<Radio size="small" />}
                  label={item}
                />
                ))}
              </RadioGroup>
            </Grid>
          )}

          {/* STEP 2: Time & Date Settings */}
          {activeStep === 2 && (
            <Grid item xs={12} md={8} sx={{ width: "100%" }}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <Box>
                  <Typography sx={{ mb: 1 }}>Time *</Typography>
                  <TimePicker
                    value={formData.scheduleTime}
                    onChange={(time) => setFormData({ ...formData, scheduleTime: time })}
                    format="HH:mm:ss"
                    style={{
                      width: "100%", height: 45, background: theme.palette.mode === 'dark' ? "#333333" : "#ffffff",
                      color: theme.palette.mode === 'dark' ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
                    }}
                    allowClear={false}
                    getPopupContainer={(trigger) => trigger.parentElement}
                  />
                </Box>
                <Box>

                </Box>
                {["Fortnightly", "Quarterly"].includes(formData.frequency) && (
                  <Box sx={{ p: 1,  borderRadius: 1, border: '1px solid #eee' }}>
                    <Typography variant="body2" color="text.secondary">
                      {formData.frequency === "Fortnightly"
                        ? "This will take a database backup on the 1st and 15th of every month at "
                        : "This will take a database backup once every 3 months at "}
                      {formData.scheduleTime?.format("HH:mm:ss")}
                    </Typography>
                  </Box>
                )}
                {(formData.frequency === "Monthly" || formData.frequency === "Yearly") && (
                  <MSelect
                    label="Select Date *"
                    options={dateOptions}
                    value={formData.selectedDate}
                    onChange={(val) => setFormData({ ...formData, selectedDate: val.value })}
                  />
                )}

                {formData.frequency === "Yearly" && (
                  <MSelect
                    label="Select Month *"
                    options={monthOptions}
                    value={formData.selectedMonth}
                    onChange={(val) => setFormData({ ...formData, selectedMonth: val.value })}
                  />
                )}
              </Box>
            </Grid>
          )}
        </Grid>

        {/* Navigation Buttons (Inside the bordered box) */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 2,
            pt: 3,
            mt: 2,
          }}
        >
          {activeStep > 0 && (
            <MButtonSecondary
              variant="outlined"
              sx={{
                color: "#14348D",
                borderRadius: "10px",
                textTransform: "none",
                fontFamily: "Montserrat",
                border: "1px solid #14348D",
                px: 4,
                width: { xs: "100%", sm: "30%" },
              }}
              onClick={() => setActiveStep(activeStep - 1)}
            >
              Previous
            </MButtonSecondary>
          )}

          {activeStep < 2 ? (
            <MButtonPrimary
              disabled={isNextDisabled()}
              onClick={() => setActiveStep(activeStep + 1)}
            >
              Next
            </MButtonPrimary>
          ) : (
            <MButtonPrimary
              onClick={() => setShowConfirm(true)}
              disabled={loading}
            >
              Update
            </MButtonPrimary>
          )}
        </Box>
      </Box>

      <MDialog
        isInsideDrawer={true}
        open={showConfirm}
        variant="info"
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}

        icon={Confirmation_icon}
        title="Confirm Update"
        message={`Update this ${formData.frequency} schedule?`}
        onConfirm={handleUpdateSubmit}
        onClose={() => setShowConfirm(false)}
      />
    </Box>
  );
};

export default ConfigEditScheduleBackup;