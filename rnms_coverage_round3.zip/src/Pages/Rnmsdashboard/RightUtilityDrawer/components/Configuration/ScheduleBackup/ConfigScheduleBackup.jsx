import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useMemo, useState } from "react";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { DELETE_SCHEDULER_TASKS, GET_TASK_TRIGGER_TYPE_ENUM, VIEW_ALL_SCHEDULER_TASKS } from "@/RestAPI/url/endpoint";
import { Box, CircularProgress } from "@mui/material";
import { exportToCSV, exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import Delete_Icon_ from '@/assets/SVGIcons/Delete_Icon_.svg';
import MModal from "@/components/Reusable/Modal/MModal";
import ConfigViewScheduleBackup from "./ConfigViewScheduleBackup";


const ConfigScheduleBackup = ({ isChildFullScreen,privilegeKey, handleAdd, handleEdit, handleView, refreshTrigger }) => {
    const [scheduleDetails, setScheduleDetails] = useState([]);
    const [loading, setLoading] = useState(true);
    const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedViewRow, setSelectedViewRow] = useState(null);
    const [triggerLookup, setTriggerLookup] = useState({});
 
    // --- FIX: Define columns inside the component to access triggerLookup ---
    const columns = useMemo(() => [
        { name: "S. No ", uid: "sno", width: "75px" },
        { name: "Task Name", uid: "taskName", width: "150px" },
        {
            name: "Task Frequency",
            uid: "taskTriggerTypeDisplay", // Change this from taskTriggerType to taskTriggerTypeDisplay
            filterType: "dropdown",
            width: '190px',
            filterOptions: Object.entries(triggerLookup)
                .filter(([key, label]) => key !== "0")
                .map(([key, label]) => ({
                    label: label,
                    value: key // The filter value will still be the number (e.g. "365")
                }))
        },
        { name: "Task Trigger Info", uid: "taskTriggerInfo", width: "180px" },
        { name: "Last Execution Time", uid: "taskTriggerTime", width: "220px" },
        { name: "Actions", uid: "actions" },
    ], [triggerLookup]); // Re-calculate columns whenever lookup changes

    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const enumRes = await ConfigurationAxios(GET_TASK_TRIGGER_TYPE_ENUM, "get");
                const enumData = enumRes?.data || {};
                setTriggerLookup(enumData);
                console.log("aaaaaa",enumData)

                const response = await ConfigurationAxios(VIEW_ALL_SCHEDULER_TASKS, "get");
                const data = response?.data || [];
                
                if (data && Array.isArray(data)) {
                    const processedData = data.map((item, index) => {
                        const rawTriggerType = String(item?.taskTriggerType); // Ensure it's a string for lookup
                        
                        // Get the label from the enumData using the raw number
                        // If the number is "365", this becomes "YEARLY"
                        const triggerLabel = enumData[rawTriggerType] || rawTriggerType;
                    
                        return {
                            sno: index + 1,
                            taskName: item?.taskName ?? 'N/A',
                            taskDescription: item?.taskDescription ?? 'N/A',
                            
                            // 1. Keep the RAW value for the filter to work correctly
                            taskTriggerType: rawTriggerType, 
                            
                            // 2. Create a NEW key specifically for the text display
                            taskTriggerTypeDisplay: triggerLabel, 
                            
                            taskTriggerInfo: item?.taskTriggerInfo ?? 'N/A',
                            taskTriggerTime: item?.lastRunTime ?? 'N/A',
                            actions: item.actions,
                            id: item.id || index,
                            resourceId: item?.resourceInfo?.resourceId
                        };
                    });
                    setScheduleDetails(processedData);
                }
            } catch (error) {
                console.error("Error fetching backup Details:", error);
                Toast("Error!", "Failed to fetch Backup Details", "error");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [refreshTrigger]);

    const handleDeleteRow = async (row) => {
        setScheduleDetails((prevData) => prevData.filter((item) => item.id !== row.id));
        try {
            await ConfigurationAxios(`${DELETE_SCHEDULER_TASKS}/${row.id}`, "post");
        } catch (error) {
            console.error(error);
        }
    };

    const onHandleViewClick = (row) => {
        // We pass the whole row so the child can access row.id
        setSelectedViewRow(row); 
        setIsModalOpen(true);
    };
    const handleCloseModal = () => {
        setIsModalOpen(false);
      };
    return (
        <Box sx={{ width: "100%",   }}>
            {loading ? (
                <Box className="flex justify-center p-10">
                    <CircularProgress size={30} />
                </Box>
            ) : (
                <MTable
                    privilegeKey={privilegeKey}
                    columns={columns}
                    tableData={scheduleDetails}
                    showPagination={true}
                    hideAdd={false}
                    handleAdd={() => handleAdd({ mode: 'CREATE', title: "Schedule Config Backup" })}
                    handleEdit={(row) => handleEdit({
                        ...row,
                        password: row.originalPassword,
                        mode: 'EDIT', title: "Edit Backup Schedule"
                    })}
                    handleDelete={(row) => {
                        setRowToDelete({ visible: true, row: row });
                    }}
                    // CHANGED: Call local modal logic instead of parent drawer logic
                    handleView={onHandleViewClick} 
                    handleDownloadPDF={() => exportToPDF("Schedule Backup Report", columns, scheduleDetails, "Schedule_Backup_Report")}
                    handleDownloadCSV={() => exportToCSV("Schedule_Backup_Export", columns, scheduleDetails)}
                    showSearch={true}
                    AddText="Add"
                />
            )}

            {/* MODAL FOR VIEWING DETAILS */}
            {isModalOpen && selectedViewRow && (
                <MModal
                    open={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    title="View Task Details"
                    handleClose={handleCloseModal}
                     enableFullScreen
                >
                    <Box sx={{ border: '2px solid #eee',borderRadius:'10px' }}>
                        {/* FIX 1: Pass id and onClose to the child */}
                        <ConfigViewScheduleBackup 
                            id={selectedViewRow.id} 
                            onClose={() => setIsModalOpen(false)} 
                        />
                    </Box>
                </MModal>
            )}
            {/* DELETE CONFIRMATION DIALOG */}
            {rowToDelete.visible && (
                <MDialog
                    open={rowToDelete.visible}
                    variant="error"
                    title="Confirm Action"
                    mode="child"
                    isChildFullScreen={isChildFullScreen}
                    message={`Are you sure you want to delete ${rowToDelete.row?.taskName || 'this record'}?`}
                    icon={Delete_Icon_}
                    onConfirm={() => {
                        handleDeleteRow(rowToDelete.row);
                        setRowToDelete({ visible: false, row: null });
                        Toast("Success!", "Successfully deleted row", "success");
                    }}
                    onClose={() => setRowToDelete({ visible: false, row: null })}
                />
            )}
        </Box>
    );
};

export default ConfigScheduleBackup;
 