

import React, { useEffect, useState, useCallback } from "react";
import {
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Grid,
  useTheme,

} from "@mui/material";
import { TimePicker } from "antd";
import dayjs from "dayjs";

// Reusable Components
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MSelect from "@/components/Reusable/Select/MSelect";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import TextArea from "antd/es/input/TextArea";

// Icons and APIs
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import {
  FIND_ALL_BACKUP_UPLOAD_TYPE_DEVICE,
  SCHEDULE_BACKUP,

  UPDATE_SCHEDULER_TASKS,
} from "@/RestAPI/url/endpoint";
import { ConfigurationAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";

const ConfigAddScheduleBackup = ({ editData, refresh, onClose, onSuccess ,isGrandchildFullScreen}) => {
  // UI State
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [mode, setMode] = useState("CREATE");
  const [resources, setResources] = useState([]);
  const [descError, setDescError] = useState("");
  const [remainingChar, setRemainingChar] = useState("255 characters remaining");

  // Form State
  const [formData, setFormData] = useState({
    id: null,
    selectedDevice: "",
    taskName: "",
    description: "",
    frequency: "Daily",
    scheduleTime: dayjs(),
    selectedDay: 1,
    selectedDate: 1,
    selectedMonth: 1,
  });


  const formatTimeForPicker = (timeArray) => {
    const now = dayjs();
    if (Array.isArray(timeArray) && timeArray.length >= 2) {
      return now.hour(timeArray[0]).minute(timeArray[1]).second(timeArray[2] || 0);
    }
    return now;
  };
  const validateDescription = (e) => {
    const value = e.target.value;
    const MAX_LENGTH = 255;


    if (/^\d/.test(value)) {
      setDescError("Description cannot start with a number");
      return;
    }


    setFormData((prev) => ({
      ...prev,
      description: value,
    }));

    setRemainingChar(`${value.length}/${MAX_LENGTH}`);

    // 3. Validation Logic for Errors
    if (value.length > MAX_LENGTH) {
      setDescError("Exceeded Maximum Limit");
    } else if (value.trim().length > 0 && value.trim().length <= 2) {
      setDescError("Need more than 2 Characters");
    } else {
      setDescError("");
    }
  };

  const populateEditData = useCallback((e) => {
    const freqMap = { 1: "Daily", 7: "Weekly", 30: "Monthly", 365: "Yearly" };

    setFormData({
      id: e.id,
      // FIX: Store only the value (resourceId) so MSelect can match it
      selectedDevice: e.resourceInfo?.resourceId || "",
      taskName: e.taskName || "",
      description: e.taskDescription || "",
      frequency: freqMap[e.taskTriggerType] || "Daily",
      scheduleTime: e.cronJobInfo ? formatTimeForPicker(e.cronJobInfo.taskTriggerTime) : dayjs(),
      selectedDay: e.cronJobInfo?.dayOfTheWeek || 1,
      selectedDate: e.cronJobInfo?.dayOfTheMonth || 1,
      selectedMonth: e.cronJobInfo?.monthOfTheYear || 1,
    });
  }, []);

  useEffect(() => {
    const fetchDevices = async () => {
      try {
        const response = await InventoryAxios(FIND_ALL_BACKUP_UPLOAD_TYPE_DEVICE, "get");
        const data = response?.data?.map((item) => ({
          id: item.resourceId,
          value: item,
          label: item.resourceName,
        })) || [];
        setResources(data);
      } catch (error) {
        console.error("Error fetching devices", error);
      }
    };

    fetchDevices();

    if (editData) {
      setMode("EDIT");
      populateEditData(editData);
    }
  }, [editData, populateEditData]);

  

  // Dropdown Options
  const dateOptions = Array.from({ length: 31 }, (_, i) => ({ label: i + 1, value: i + 1 }));
  const daysOptions = [
    { label: "Monday", value: 1 }, { label: "Tuesday", value: 2 },
    { label: "Wednesday", value: 3 }, { label: "Thursday", value: 4 },
    { label: "Friday", value: 5 }, { label: "Saturday", value: 6 },
    { label: "Sunday", value: 7 }
  ];
  const monthOptions = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ].map((m, i) => ({ label: m, value: i + 1 }));
  const handleFinalSubmit = async () => {
    setShowConfirm(false);
    setLoading(true);
  
    // Updated Mapping to include Fortnightly and Quarterly
    const freqToType = { 
      "One Time": 0, 
      "Daily": 1, 
      "Weekly": 7, 
      "Fortnightly": 15, // ADDED
      "Monthly": 30, 
      "Quarterly": 3,    // ADDED
      "Yearly": 365 
    };
  
    const deviceName = formData.selectedDevice?.label || "";
  
    const payload = {
      id: mode === "EDIT" ? formData.id : undefined,
      // Ensure we use the actual ID from the resource object if available
      resourceInfo: { resourceId: formData.selectedDevice?.value?.resourceId },
      taskName: deviceName || formData.taskName,
      taskDescription: formData.description,
      taskTriggerType: freqToType[formData.frequency],
      
      cronJobInfo: {
        taskTriggerTime: formData.scheduleTime.format("HH:mm:ss"),
        
         dayOfTheWeek: formData.frequency === "Weekly" ? formData.selectedDay : 0,
        
         dayOfTheMonth: (formData.frequency === "Monthly" || formData.frequency === "Yearly") ? formData.selectedDate : 0,
        
         monthOfTheYear: formData.frequency === "Yearly" ? formData.selectedMonth : 0,
      },
    };
  
    console.log("Payload:", payload);
  
    try {
      const endpoint = mode === "CREATE" ? SCHEDULE_BACKUP : UPDATE_SCHEDULER_TASKS;
      const response = await ConfigurationAxios(endpoint, "post", payload);
  
      if (response?.status === 200 || response?.data?.success) {
        Toast("Success!", `Schedule ${mode === "CREATE" ? "created" : "updated"} successfully.`, "success");
        onSuccess();
        onClose();
      } else {
        Toast("Error!", "Failed to process schedule.", "error");
      }
    } catch (error) {
      Toast("Error!", "Server Error.", "error");
    } finally {
      setLoading(false);
    }
  };
  
  // const handleFinalSubmit = async () => {
  //   setShowConfirm(false);
  //   setLoading(true);
  //   const freqToType = { 
  //     "One Time": 0, 
  //     "Daily": 1, 
  //     "Weekly": 7, 
  //     "Fortnightly": 15, // ADDED
  //     "Monthly": 30, 
  //     "Quarterly": 3,    // ADDED
  //     "Yearly": 365 
  //   };
  //   // const freqToType = { "One Time": 0, "Daily": 1, "Weekly": 7, "Monthly": 30, "Yearly": 365 };
  //   const deviceName = formData.selectedDevice?.label || "";

  //   const payload = {
  //     id: mode === "EDIT" ? formData.id : undefined,
  //     //resourceInfo: { resourceId: formData.selectedDevice }, 
  //     //taskName: deviceName || formData.taskName, 
  //     resourceInfo: { resourceId: formData.selectedDevice?.value?.resourceId },
  //     taskName: deviceName || formData.taskName,
  //     taskDescription: formData.description,
  //     taskTriggerType: freqToType[formData.frequency],
  //     cronJobInfo: {
  //       taskTriggerTime: formData.scheduleTime.format("HH:mm:ss"),
  //       dayOfTheWeek: formData.frequency === "Weekly" ? formData.selectedDay : 0,
  //       dayOfTheMonth: (formData.frequency === "Monthly" || formData.frequency === "Yearly") ? formData.selectedDate : 0,
  //       monthOfTheYear: formData.frequency === "Yearly" ? formData.selectedMonth : 0,
  //     },
  //   };
  //   console.log(payload, "payload")
  //   try {
  //     const endpoint = mode === "CREATE" ? SCHEDULE_BACKUP : UPDATE_SCHEDULER_TASKS;
  //     const response = await ConfigurationAxios(endpoint, "post", payload);
  //     console.log(response, "payload")

  //     if (response?.status === 200 || response?.data?.success) {
  //       Toast("Success!", `Schedule ${mode === "CREATE" ? "created" : "updated"} successfully.`, "success");
  //       onSuccess();
  //       onClose();
  //     } else {
  //       Toast("Error!", "Failed to process schedule.", "error");
  //     }
  //   } catch (error) {
  //     Toast("Error!", "Server Error.", "error");
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const checkIsNextDisabled = () => {
    if (activeStep === 0) {
      // Step 1: Must have Device selected AND Description >= 3 chars
      const hasDevice = !!formData.selectedDevice;
      const hasValidDesc = formData.description && formData.description.trim().length >= 3;
      return !(hasDevice && hasValidDesc);
    }
    if (activeStep === 1) {
      // Step 2: Must have Frequency selected
      return !formData.frequency;
    }
    return false;
  };
  const theme = useTheme()
  return (
    <Box sx={{ p: 1, borderRadius: "10px", }}>



      <Stepper activeStep={activeStep} sx={{ mt: 2, mb: 2 }}>
        {["Task", "Create", "Trigger"].map((label) => (
          <Step key={label}><StepLabel>{label}</StepLabel></Step>
        ))}
      </Stepper>

      {/* Main Content Area */}
      <Box sx={{ minHeight: "280px", border: '2px solid #eee', p: 1.5, borderRadius: '10px' }}>
        <Grid container justifyContent="left">

          {/* STEP 0: Task Details */}
          {activeStep === 0 && (
            <Grid item xs={12} md={6} sx={{ width: '100%' }}>
              <Typography sx={{ mb: 1, }}>Device Name *</Typography>
              <MSelect
                options={resources}
                value={formData.selectedDevice}
                onChange={(val) => setFormData({ ...formData, selectedDevice: val })}
                placeholder="Select Device"
              />


              <Typography sx={{ mt: 2, mb: 0.5 }}>Task Description *</Typography>
              <TextArea
                rows={5}
                value={formData.description}
                onChange={validateDescription}
                placeholder="Min 2 characters"
                className={theme.palette.mode === 'dark' ? "dark-ant-textarea" : ""}
                style={{
                  resize: "none",
                  borderColor: descError ? '#ff4d4f' : '#d9d9d9',
                  fontFamily: "Montserrat",

                  width: '100%',
                  // Set background and text color
                  background: theme.palette.mode === 'dark' ? "#333333" : "#ffffff",
                  color: theme.palette.mode === 'dark' ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
                }}
                maxLength={255}
              />
              <Typography variant="caption" sx={{ color: descError ? "#e75656" : "textSecondary" }}>
                {descError || remainingChar}
              </Typography>
            </Grid>
          )}

          {/* STEP 1: Frequency */}
          {activeStep === 1 && (
            <Grid item xs={12} md={6}>
              <Typography sx={{ mb: 2, }}>Trigger Type *</Typography>
              <RadioGroup
                value={formData.frequency}
                onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
              >
                {["Daily",
                  "Weekly",
                  "Fortnightly",
                  "Monthly",
                  "Quarterly",
                  "Yearly",].map((item) => (
                  <FormControlLabel
                    key={item}
                    value={item}
                    control={<Radio size="small" />}
                    label={item}
                  />
                ))}
              </RadioGroup>
            </Grid>
          )}

{activeStep === 2 && (
  <Grid item xs={12} md={6} sx={{ width: '100%' }}>
    <Box sx={{ display: "flex", flexDirection: "column", gap: 2, width: "100%" }}>
      
      {/* Time Picker */}
      <Box>
        <Typography sx={{ mb: 1 }}>Time *</Typography>
        <TimePicker
          value={formData.scheduleTime}
          onChange={(time) => setFormData({ ...formData, scheduleTime: time })}
          format="HH:mm:ss"
          style={{ width: "100%", height: 50, borderRadius: '10px' }}
          allowClear={false}
          getPopupContainer={(trigger) => trigger.parentElement}
        />
      </Box>

      {/* Conditional Dropdowns */}
      {/* Weekly Day Selector */}
      {formData.frequency === "Weekly" && (
        <Box>
          <MSelect
            options={daysOptions}
            value={formData.selectedDay}
            onChange={(val) => setFormData({ ...formData, selectedDay: val.value })}
            label="Select Day *"
          />
        </Box>
      )}

      {/* Monthly/Yearly Date Selector */}
      {(formData.frequency === "Monthly" || formData.frequency === "Yearly") && (
        <Box>
          <MSelect
            options={dateOptions}
            value={formData.selectedDate}
            onChange={(val) => setFormData({ ...formData, selectedDate: val.value })}
            label="Select Date *"
          />
        </Box>
      )}

      {/* Yearly Month Selector */}
      {formData.frequency === "Yearly" && (
        <Box>
          <MSelect
            options={monthOptions}
            value={formData.selectedMonth}
            onChange={(val) => setFormData({ ...formData, selectedMonth: val.value })}
            label="Select Month *"
          />
        </Box>
      )}

      {/* --- NEW: Descriptive Text for Special Frequencies --- */}
      {/* This mimics the logic from DBPreviousupAdd */}
      {["Fortnightly", "Quarterly"].includes(formData.frequency) && (
        <Box sx={{ p: 1,  borderRadius: 1 }}>
          <Typography variant="body2" color="text.secondary">
            {formData.frequency === "Fortnightly" 
              ? "This will take a database backup on the 1st and 15th of every month at " 
              : "This will take a database backup once every 3 months at "}
            {formData.scheduleTime?.format("HH:mm:ss")}
          </Typography>
        </Box>
      )}

    </Box>
  </Grid>
          )}
        </Grid>
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end", // This pushes everything to the right
            gap: 2,


            pt: 3
          }}
        >
          {/* SHOW PREVIOUS ONLY IF NOT ON FIRST STEP */}
          {activeStep > 0 && (
            <MButtonSecondary
              variant="outlined"
              sx={{
                 
                borderRadius: "10px",
                textTransform: "none",
                fontFamily: "Montserrat",
                border: "1px solid #14348D",
                px: 4,
                width: { xs: "100%", sm: "30%" },
              }}
              onClick={() => setActiveStep(activeStep - 1)}
            >
              Previous
            </MButtonSecondary >
          )}

          {/* SHOW NEXT ONLY IF NOT ON THE LAST STEP (Step 2) */}
          {activeStep < 2 && (
            <MButtonPrimary
              disabled={checkIsNextDisabled()}
              onClick={() => setActiveStep(activeStep + 1)}
              sx={{ mb: 10 }}
            >
              Next
            </MButtonPrimary>
          )}

          {activeStep === 2 && (
            <MButtonPrimary
              onClick={() => setShowConfirm(true)}
              disabled={loading}
            >
              {mode === "CREATE" ? "Schedule" : "Update"}
            </MButtonPrimary>
          )}
        </Box>
      </Box>

      {/* Footer Navigation */}


      <MDialog
        isInsideDrawer={true}
        open={showConfirm}
        variant="info"
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
        icon={Confirmation_icon}
        title="Confirm Action"
        message={`Schedule ${formData.frequency} backup at ${formData.scheduleTime?.format("HH:mm:ss")}?`}
        onConfirm={handleFinalSubmit}
        onClose={() => setShowConfirm(false)}
      />
    </Box>
  );

};

export default ConfigAddScheduleBackup;