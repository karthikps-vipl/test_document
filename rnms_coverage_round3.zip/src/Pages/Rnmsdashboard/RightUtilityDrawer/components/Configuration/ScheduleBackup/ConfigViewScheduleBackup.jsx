
import React, { useEffect, useState } from "react";

import {
  Box,
  CircularProgress,
} from "@mui/material";

// Reusable Components
import Toast from "@/components/Reusable/Toast/Toast";

// Icons and APIs
import { FETCH_SCHEDULED_TASK_EXECUTION_BY_ID, GET_EXECUTION_STATUS_ENUM } from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import MTable from "@/components/Reusable/Table/MTable";
import { exportToCSV, exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";

const ConfigViewScheduleBackup = ({ id }) => {
  const [scheduleDetails, setScheduleDetails] = useState([]);
  const [loading, setLoading] = useState(true);
  // const [statusLookup, setStatusLookup] = useState({});

  const columns = [
    { name: "S.No.", uid: "sno" },
    { name: "Task Name", uid: "taskName" },
    { name: "Device Name", uid: "deviceName" },
    { name: "Task Execution Time", uid: "executionEndTime" },
    { name: "Execution Status", uid: "executionStatus" },
    { name: "Remarks", uid: "remarks" },
  ];

  useEffect(() => {
    // 1. Define the helper function INSIDE or OUTSIDE the component
    const formatDateCustom = (dateString) => {
      if (!dateString) return '--';
      const date = new Date(dateString);
      
      // Check if date is valid
      if (isNaN(date.getTime())) return '--';
  
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
  
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };
  
    const fetchData = async () => {
      if (!id) return;
      try {
        setLoading(true);
        
        // 2. Fetch Enums
        const enumRes = await ConfigurationAxios(GET_EXECUTION_STATUS_ENUM, "get");
        const enumData = enumRes?.data || {};
        // setStatusLookup(enumData);
  
        // 3. Fetch Details
        const endpoint = `${FETCH_SCHEDULED_TASK_EXECUTION_BY_ID}/${id}`;
        const response = await ConfigurationAxios(endpoint, "get");
        
        const rawData = response?.data || response;
        const dataArray = Array.isArray(rawData) ? rawData : [rawData];
  
        const processedData = dataArray.map((r, index) => {
          const statusKey = String(r.executionStatus);
          const formattedStatus = enumData[statusKey] || statusKey || '--';
  
          return {
            sno: index + 1,
            id: r.id,
            taskName: r.configSchedulerTask?.taskName || r.taskName || '--',
            deviceName: r.configSchedulerTask?.resourceInfo?.resourceName || '--',
            // 4. USE THE CUSTOM FORMATTER HERE
            executionEndTime: formatDateCustom(r.executionEndTime),
            executionStatus: formattedStatus,
            remarks: r.configSchedulerTask?.taskDescription	|| '--',
          };
        });
  
        setScheduleDetails(processedData);
      } catch (error) {
        console.error("Error in Fetching Task Execution:", error);
        Toast("Error!", "Failed to fetch Task Details", "error");
      } finally {
        setLoading(false);
      }
    };
  
    fetchData();
  }, [id,  ]); // Added statusLookup to re-run mapping once enums arrive
  return (
    <Box>
     

      {loading ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <MTable
          tableTitle="View Schedule Backup History"
          columns={columns}
          tableData={scheduleDetails}
          showPagination={true}
          hideAdd={true}
          showSearch={true}
          handleDownloadPDF={() => exportToPDF("Schedule View Backup Report", columns, scheduleDetails, "Schedule_View_Backup_Report")}
          handleDownloadCSV={() => exportToCSV("Schedule_View_Backup_Export", columns, scheduleDetails)}
        />
      )}
    </Box>
  );
};

export default ConfigViewScheduleBackup;