/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Repdetails
   File Name                : ConfigAddRepDetails.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\RepDetails\ConfigAddRepDetails.jsx
   Purpose                  : Provides the user interface and form logic for adding new 
                               configuration repository details within the application.
   Created Date             : 07-04-2026
***********************************************************************************************/
import React, { useState } from "react";
import { Box, Select, Typography, FormControl, MenuItem } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { SAVE_REMOTE_REP_DETAIL } from "@/RestAPI/url/endpoint";
import { validateInput, personnelRegex } from "@/utility/FormValidation/Regex";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import question_mark from "@/assets/SVGIcons/question_mark.svg"
import {

  personnelNameValidation,
  rankValidation,
  primaryMobileValidation,
  afcelPhoneValidation,
  ipPhoneValidation,
  alternateMobileValidation,
  emailValidation,
  unitValidation,
} from "@/utility/FormValidation/YupSchema";
import { useSelector } from "react-redux";
import MDialog from "@/components/Reusable/Dialog/MDialog";


const ConfigAddRepDetails = ({ row, mode, onClose, onSuccess, siteId, isGrandchildFullScreen }) => {
  // const [loading, setLoading] = useState(false);
  const { repDetails } = useSelector((state) => state.nodeDetails);
  
  // 1. Try to get from the prop passed by parent
  const passedSiteId = siteId || row?.siteId;

  // 2. If still missing, we have a critical error in the parent flow.
  //    We fallback to repDetails.id, but we log a warning.
  const targetSiteId = passedSiteId || repDetails?.id;

  console.log("DEBUG Child: passedSiteId =", passedSiteId, ", row?.siteId =", row?.siteId, ", Final target =", targetSiteId);

  const [showConfirm, setShowConfirm] = useState(false);
  const handleSucess = async () => {

    // setLoading(true);
    const payload2 = {



      personnelName: formik.values.personalName,
      personnel: formik.values.rank,
      unit: formik.values.unit,
      primaryCivilMobile: formik.values.primaryCivilMobile,
      afcelPhone: formik.values.afcelPhone || undefined,
      ipPhone: formik.values.ipPhone || undefined,
      altCivilMobile: formik.values.altCivilMobile || undefined,
      email: formik.values.email,
      // siteId: repDetails.id
      siteId: targetSiteId

    }
    console.log("payload", payload2)
    try {
      const resp = await InventoryAxios(SAVE_REMOTE_REP_DETAIL, "post", payload2);

      if (resp.status == 200 && resp.data) {


        Toast("Success!", "Successfully saved rep details", "success");
        onSuccess();
        formik.resetForm();
        onClose();
      } else {

        Toast("Notice", "Unexpected response format", "info");

      }
    } catch (error) {
      Toast("Error", "An unexpected error occurred", "error");
    }
    //  finally {
    //   setLoading(false);
    // }



  };
  const InitialData = {


    personalName: "",
    rank: "",
    unit: "",
    primaryCivilMobile: "",
    afcelPhone: "",
    ipPhone: "",
    altCivilMobile: "",
    email: "",
  };

  const schema = Yup.object({


    personalName: personnelNameValidation,
    rank: rankValidation,
    unit: unitValidation,
    primaryCivilMobile: primaryMobileValidation,
    afcel: afcelPhoneValidation,
    ipPhone: ipPhoneValidation,
    altCivilMobile: alternateMobileValidation,
    email: emailValidation,
  });

  const formik = useFormik({
    initialValues: InitialData,
    validationSchema: schema,
    onSubmit: async (values) => {
      handleSucess();
    },
  });

  const handleInputChange = (event, fieldName) => {
    let value = event.target.value;
    formik.setFieldValue(fieldName, value);
    setTimeout(() => {
      formik.handleBlur({ target: { name: fieldName } });
    }, 0);
  };


  const handleConfirmSubmit = () => {
    setShowConfirm(false);
    formik.handleSubmit(); // This triggers the actual Formik submission
  };


  const isMandatoryValid =
    formik.values.personalName &&
    formik.values.rank &&
    formik.values.unit &&
    formik.values.primaryCivilMobile &&
    !formik.errors.personalName &&
    !formik.errors.rank &&
    !formik.errors.unit &&
    !formik.errors.primaryCivilMobile;


  const hasNonMandatoryErrors =
    !!formik.errors.afcelPhone ||
    !!formik.errors.ipPhone ||
    !!formik.errors.altCivilMobile ||
    !!formik.errors.email;


  const isAddDisabled = !isMandatoryValid || hasNonMandatoryErrors;



  return (
    <Box component="form" onSubmit={formik.handleSubmit} className="flex flex-col gap-5">


      <Box sx={{
        display: "flex",
        flexDirection: "column",
        ml: 3, mr: 5,

      }}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",




          }}
        >
          <Typography sx={{ mb: 0.5 }}>Personal Name * </Typography>
          <MInput
            label={"Personnel Name"}
            value={formik.values.personalName}
            placeholder={"Enter personnel name"}

            onChange={(e) => {
              const value = e.target.value;
              if (value.length <= 50 && validateInput(value, personnelRegex.name) !== undefined) {
                handleInputChange(e, "personalName");
              }
            }}

            errorMessage={
              formik.touched.personalName && formik.errors.personalName
            }
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ mb: 0.5 }}>Rank *</Typography>
          <FormControl fullWidth>
            <Select
              placeholder="select device"
              id="rank-select"
              size="small"
              value={formik.values.rank}
              onChange={(e) => handleInputChange(e, "rank")}
              sx={{
                borderRadius: '10px',
                "& .MuiSelect-select": {
                  fontFamily: "Montserrat",
                },
              }}
            >
              <MenuItem value={"AIR CMDE"}>AIR CMDE</MenuItem>
              <MenuItem value={"GP CAPT"}>GP CAPT</MenuItem>
              <MenuItem value={"WG CDR"}>WG CDR</MenuItem>
              <MenuItem value={"SQN LDR"}>SQN LDR</MenuItem>
              <MenuItem value={"FLT LT"}>FLT LT</MenuItem>
              <MenuItem value={"FG OFFR"}>FG OFFR</MenuItem>
              <MenuItem value={"MWO"}>MWO</MenuItem>
              <MenuItem value={"WO"}>WO</MenuItem>
              <MenuItem value={"JWO"}>JWO</MenuItem>
              <MenuItem value={"SGT"}>SGT</MenuItem>
              <MenuItem value={"CPL"}>CPL</MenuItem>
              <MenuItem value={"LAC"}>LAC</MenuItem>
              <MenuItem value={"AC"}>AC</MenuItem>
              <MenuItem value={"AGV"}>AGV</MenuItem>
            </Select>
          </FormControl>
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            Unit *
          </Typography>
          <MInput
            label={"Unit"}
            value={formik.values.unit}
            placeholder={"Enter unit"}
            onChange={(e) => {
              const value = e.target.value;
              if (value.length <= 20) {
                handleInputChange(e, "unit");
              }
            }} errorMessage={formik.touched.unit && formik.errors.unit}
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            Primary Civil Mobile *
          </Typography>
          <MInput
            label={"Primary Civil Mobile"}
            value={formik.values.primaryCivilMobile}
            placeholder={"6-9xxxxxxxxx"}
            onChange={(e) => {
              if (
                validateInput(
                  e.target.value,
                  personnelRegex.primaryMobile
                ) !== undefined
              ) {
                handleInputChange(e, "primaryCivilMobile");
              }
            }}
            errorMessage={
              formik.touched.primaryCivilMobile &&
              formik.errors.primaryCivilMobile
            }
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            AFCEL Phone
          </Typography>
          <MInput
            label={"AFCEL Phone"}
            value={formik.values.afcelPhone}
            placeholder={"1-9xxxxxxx"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.landline) !==
                undefined
              ) {
                handleInputChange(e, "afcelPhone");
              }
            }}
            errorMessage={
              formik.touched.afcelPhone && formik.errors.afcelPhone
            }
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            IP Phone
          </Typography>
          <MInput
            label={"IP Phone"}
            value={formik.values.ipPhone}
            placeholder={"1-9xxxxxxx"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.landline) !==
                undefined
              ) {
                handleInputChange(e, "ipPhone");
              }
            }}
            errorMessage={formik.touched.ipPhone && formik.errors.ipPhone}
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            Alternative Civil Phone No.
          </Typography>
          <MInput
            label={"Alternate Civil Mobile No."}
            value={formik.values.altCivilMobile}
            placeholder={"5-9xxxxxxxxx"}
            onChange={(e) => {
              if (
                validateInput(e.target.value, personnelRegex.altMobile) !==
                undefined
              ) {
                handleInputChange(e, "altCivilMobile");
              }
            }}
            errorMessage={
              formik.touched.altCivilMobile && formik.errors.altCivilMobile
            }
          />
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",


            mt: 2,
          }}
        >
          <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
            Email
          </Typography>
          <MInput
            label={"Email"}
            value={formik.values.email}
            placeholder={"example@domain.com"}
            onChange={(e) => handleInputChange(e, "email")}
            errorMessage={formik.touched.email && formik.errors.email}
          />
        </Box>

        <Box sx={{ float: "right", display: "flex", mt: 3, justifyContent: 'flex-end' }}>
          <MButtonPrimary onClick={() => setShowConfirm(true)} disabled={isAddDisabled}  >
            Add
          </MButtonPrimary>


        </Box>

      </Box>
      <MDialog
        open={showConfirm}
        variant="warning" // or "error" depending on your theme
        title="Confirm Action"
        icon={question_mark} // Replace with a question/warning icon if you have one
        message="Are you sure you want to add this representative Details?"
        onConfirm={handleConfirmSubmit}
        onClose={() => setShowConfirm(false)}

        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};
export default ConfigAddRepDetails;