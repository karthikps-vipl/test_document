 /***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Repdetails
   File Name                : ConfigEditRepDetails.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\RepDetails\ConfigEditRepDetails.jsx
   Purpose                  : Provides the user interface and form logic for editing 
                              configuration repository details within the application.
   Created Date             : 08-04-2026
***********************************************************************************************/
import React, { useState } from "react";
import {
  Box,
  Typography,
  FormControl,
  Select,
  MenuItem,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  personnelNameValidation,
  rankValidation,
  unitValidation,
  primaryMobileValidation,
  afcelPhoneValidation,
  ipPhoneValidation,
  alternateMobileValidation,
  emailValidation,
} from "@/utility/FormValidation/YupSchema";
import {
  personnelRegex,
  validateInput,
} from "@/utility/FormValidation/Regex";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";
import { MODIFY_REMOTE_REP_DETAIL } from "@/RestAPI/url/endpoint";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import question_mark from "@/assets/SVGIcons/question_mark.svg"
const ConfigEditRemoteRep = ({ data, onClose, onSuccess, onRefresh ,isGrandchildFullScreen}) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  
 

  const formik = useFormik({
      initialValues: {
          siteId: data?.siteId || "",
          personalName: data?.personnelName || "",
          rank: data?.personnel || "",
          unit: data?.unit || "",
          primaryCivilMobile: data?.primaryCivilMobile || "",
          afcelPhone: data?.afcel || "",
          ipPhone: data?.ipPhone || "",
          alternateCivilMobile: data?.alternateCivilMobile || "",
          email: data?.email || "",
          repId:data?.repId || "",
      },
      validationSchema: Yup.object({
          siteId: Yup.string().required("Site ID is required"),
          personalName: personnelNameValidation,
          rank: rankValidation,
          unit: unitValidation,
          primaryCivilMobile: primaryMobileValidation,
          afcelPhone: afcelPhoneValidation,
          ipPhone: ipPhoneValidation,
          alternateCivilMobile: alternateMobileValidation,
          email: emailValidation,
      }),
      enableReinitialize: true,
      validateOnMount: true,
      onSubmit: async (values) => {
          setLoading(true);
          try {
              // 1. Prepare Payload exactly as your API expects
              const payload = {
                  siteId: values.siteId.trim(),
                  personnelName: values.personalName.trim(), // Ensure trim here
                  personnel: values.rank, // Do not trim rank if it's a specific code like "WG CDR"
                  unit: values.unit.trim(),
                  
                  // Map formik keys to API keys carefully
                  primaryCivilMobile: values.primaryCivilMobile || null,
                  afcel: values.afcelPhone || null,
                  ipPhone: values.ipPhone || null,
                  
                  alternateCivilMobile: values.alternateCivilMobile || null, 
                  
                  email: values.email || "",
                  repId: values.repId || "",
              };

              console.log("Payload being sent:", payload);

              const response = await InventoryAxios(MODIFY_REMOTE_REP_DETAIL, "post", payload);

              if (response.status === 200) {
                  Toast("Success!", "Representative details updated", "success");
                  
                  // 2. CRITICAL FIX: Close the dialog first
                  onClose();
                  
                  // 3. Trigger the parent refresh AFTER closing the modal
                  // This ensures the parent re-fetches the data from the server
                  if (onRefresh) {
                      onRefresh(); 
                  } else if (onSuccess) {
                      // Fallback if onRefresh isn't passed, try calling onSuccess
                      onSuccess();
                  }

              } else {
                  Toast("Error!", "Failed to update representative details.", "error");
              }
          } catch (error) {
              console.error("Error updating Rep Details:", error);
              Toast("Error!", "Failed to update representative details.", "error");
          } finally {
              setLoading(false);
          }
      },
  });

  const handleInputChange = (fieldName, value) => {
      formik.setFieldValue(fieldName, value);
      formik.setFieldTouched(fieldName, true, false);
  };

  const handleConfirmSubmit = () => {
      setShowConfirm(false);
      formik.handleSubmit();
  };

  // Validation Logic
  const isMandatoryValid =
      formik.values.siteId &&
      formik.values.personalName &&
      formik.values.rank &&
      formik.values.unit &&
      formik.values.primaryCivilMobile &&
      !formik.errors.siteId &&
      !formik.errors.personalName &&
      !formik.errors.rank &&
      !formik.errors.unit &&
      !formik.errors.primaryCivilMobile;

  const hasNonMandatoryErrors =
      !!formik.errors.afcelPhone ||
      !!formik.errors.ipPhone ||
      !!formik.errors.altCivilMobile ||
      !!formik.errors.email;

  const isAddDisabled = !isMandatoryValid || hasNonMandatoryErrors;

  return (
      <Box
          component="form"
          onSubmit={formik.handleSubmit}
          className="flex flex-col gap-5"
      >
          <Box sx={{ display: "flex", flexDirection: "column", ml: 3, mr: 5 }}>

{/*             
              <Box sx={{ display: "flex", flexDirection: "column" }}>
                  <Typography sx={{ mb: 0.5 }}>Terminal Type *</Typography>
                  <FormControl fullWidth>
                      <MInput
                          value={selectedTerminal}
                          disabled={true}
                      />
                  </FormControl>
              </Box> */}

              {/* Site ID Selector (Dynamic) */}
              {/* <Box sx={{ display: "flex", flexDirection: "column",   }}>
                  <Typography sx={{ mb: 0.5 }}>Site ID *</Typography>
                  <MInput
                      value={formik.values.siteId}
                      disabled={true}
                  />
                  {formik.touched.siteId && formik.errors.siteId && (
                      <Typography sx={{ color: "#d32f2f", fontSize: "12px", mt: 0.5 }}>
                          {formik.errors.siteId}
                      </Typography>
                  )}
              </Box> */}

              {/* Personal Name */}
              <Box sx={{ display: "flex", flexDirection: "column",   }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      Personnel Name *
                  </Typography>
                  <MInput
                      label="Personnel Name"
                      value={formik.values.personalName}
                      placeholder="Enter personnel name"
                      onChange={(e) => {
                          if (validateInput(e.target.value, personnelRegex.name) !== undefined) {
                              handleInputChange("personalName", e.target.value);
                          }
                      }}
                      errorMessage={formik.touched.personalName && formik.errors.personalName}
                  />
              </Box>

              {/* Rank */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ mb: 0.5 }}>Rank *</Typography>
                  <FormControl fullWidth>
                      <Select
                          id="rank-select"
                          size="small"
                          value={formik.values.rank}
                          onChange={(e) => handleInputChange("rank", e.target.value)}
                          sx={{ borderRadius: "10px" }}
                      >
                          <MenuItem value="AIR CMDE">AIR CMDE</MenuItem>
                          <MenuItem value="GP CAPT">GP CAPT</MenuItem>
                          <MenuItem value="WG CDR">WG CDR</MenuItem>
                          <MenuItem value="SQN LDR">SQN LDR</MenuItem>
                          <MenuItem value="FLT LT">FLT LT</MenuItem>
                          <MenuItem value="FG OFFR">FG OFFR</MenuItem>
                          <MenuItem value="MWO">MWO</MenuItem>
                          <MenuItem value="WO">WO</MenuItem>
                          <MenuItem value="JWO">JWO</MenuItem>
                          <MenuItem value="SGT">SGT</MenuItem>
                          <MenuItem value="CPL">CPL</MenuItem>
                          <MenuItem value="LAC">LAC</MenuItem>
                          <MenuItem value="AC">AC</MenuItem>
                          <MenuItem value="AGV">AGV</MenuItem>
                      </Select>
                      {formik.touched.rank && formik.errors.rank && (
                          <Typography sx={{ color: "#d32f2f", fontSize: "12px", mt: 0.5 }}>
                              {formik.errors.rank}
                          </Typography>
                      )}
                  </FormControl>
              </Box>

              {/* Unit */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      Unit *
                  </Typography>
                  <MInput
                      label="Unit"
                      value={formik.values.unit}
                      placeholder="Enter unit"
                      onChange={(e) => handleInputChange("unit", e.target.value)}
                      errorMessage={formik.touched.unit && formik.errors.unit}
                  />
              </Box>

              {/* Primary Civil Mobile */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      Primary Civil Mobile *
                  </Typography>
                  <MInput
                      label="Primary Civil Mobile"
                      value={formik.values.primaryCivilMobile}
                      placeholder="6-9xxxxxxxxx"
                      onChange={(e) => {
                          if (validateInput(e.target.value, personnelRegex.primaryMobile) !== undefined) {
                              handleInputChange("primaryCivilMobile", e.target.value);
                          }
                      }}
                      errorMessage={formik.touched.primaryCivilMobile && formik.errors.primaryCivilMobile}
                  />
              </Box>

              {/* AFCEL Phone */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      AFCEL Phone
                  </Typography>
                  <MInput
                      label="AFCEL Phone"
                      value={formik.values.afcelPhone}
                      placeholder="1-9xxxxxxx"
                      onChange={(e) => {
                          if (validateInput(e.target.value, personnelRegex.landline) !== undefined) {
                              handleInputChange("afcelPhone", e.target.value);
                          }
                      }}
                      errorMessage={formik.touched.afcelPhone && formik.errors.afcelPhone}
                  />
              </Box>

              {/* IP Phone */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      IP Phone
                  </Typography>
                  <MInput
                      label="IP Phone"
                      value={formik.values.ipPhone}
                      placeholder="1-9xxxxxxx"
                      onChange={(e) => {
                          if (validateInput(e.target.value, personnelRegex.landline) !== undefined) {
                              handleInputChange("ipPhone", e.target.value);
                          }
                      }}
                      errorMessage={formik.touched.ipPhone && formik.errors.ipPhone}
                  />
              </Box>

              {/* Alternate Civil Mobile */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      Alternative Civil Mobile No.
                  </Typography>
                  <MInput
                      label="Alternate Civil Mobile No."
                      value={formik.values.alternateCivilMobile}
                      placeholder="5-9xxxxxxxxx"
                      onChange={(e) => {
                          if (validateInput(e.target.value, personnelRegex.altMobile) !== undefined) {
                              handleInputChange("alternateCivilMobile", e.target.value);
                          }
                      }}
                      errorMessage={formik.touched.alternateCivilMobile && formik.errors.alternateCivilMobile}
                  />
              </Box>

              {/* Email */}
              <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
                  <Typography sx={{ textAlign: "left", fontFamily: "Montserrat", mb: 0.5 }}>
                      Email
                  </Typography>
                  <MInput
                      label="Email"
                      value={formik.values.email}
                      placeholder="example@domain.com"
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      errorMessage={formik.touched.email && formik.errors.email}
                  />
              </Box>

              {/* Action Button */}
              <Box
                  sx={{
                      float: "right",
                      display: "flex",
                      mt: 3,
                      justifyContent: "flex-end",
                  }}
              >
                  <MButtonPrimary
                      type="button"
                      onClick={() => setShowConfirm(true)}
                      disabled={isAddDisabled || loading}
                  >
                      {loading ? "Updating..." : "Update"}
                  </MButtonPrimary>
              </Box>
          </Box>

          {/* Confirmation Dialog */}
          <MDialog
              open={showConfirm}
              variant="warning"
              title="Confirm Action"
              icon={question_mark}
              message="Are you sure you want to update this representative?"
              onConfirm={handleConfirmSubmit}
              onClose={() => setShowConfirm(false)}
              mode="grandchild"
              isGrandchildFullScreen={isGrandchildFullScreen}
          />
      </Box>
  );
};

export default ConfigEditRemoteRep;

// const ConfigEditRepDetails = ({  data, onClose, onSuccess }) => {
//   const [loading, setLoading] = useState(false);
//   const { repDetails } = useSelector((state) => state.nodeDetails);
//   const [showConfirm, setShowConfirm] = useState(false);

//   const formik = useFormik({
//     initialValues: {
//       personnelName: data?.personnelName || "",
//       rank: data?.personnel || "",
//       unit: data?.unit || "",
//       primaryCivilMobile: data?.primaryCivilMobile || "",
//       afcelPhone: data?.afcel || "",
//       ipPhone: data?.ipPhone || "",
//       altCivilMobile: data?.alternateCivilMobile || "",
//       email: data?.email || "",
//     },
//     validationSchema: Yup.object({
//       personnelName: personnelNameValidation,
//       rank: rankValidation,
//       unit: unitValidation,
//       primaryCivilMobile: primaryMobileValidation,
//       afcelPhone: afcelPhoneValidation,
//       ipPhone: ipPhoneValidation,
//       altCivilMobile: alternateMobileValidation,
//       email: emailValidation,
//     }),
//     enableReinitialize: true,
//     validateOnMount: true, // Forces validation check as soon as data loads
//     onSubmit: async (values) => {
//       setLoading(true);
//       try {
//         const payload = {
//           siteId: repDetails?.id,
//           repId: data?.repId,
//           personnelName: values.personnelName,
//           personnel: values.rank,
//           unit: values.unit,
//           primaryCivilMobile: values.primaryCivilMobile,
//           afcel: values.afcelPhone || null,
//           ipPhone: values.ipPhone || null,
//           alternateCivilMobile: values.altCivilMobile || null,
//           email: values.email || "",
//         };

//         const response = await InventoryAxios(MODIFY_REMOTE_REP_DETAIL, "post", payload);

//         if (response.status === 200) {
//           Toast("Success!", "Representative details updated", "success");
//           onSuccess();
//           onClose();
//         } else {
//           Toast("Error!", "Failed to update representative details.", "error");
//         }
//       } catch (error) {
//         console.error("Error updating Rep Details:", error);
//         Toast("Error!", "Failed to update representative details.", "error");
//       } finally {
//         setLoading(false);
//       }
//     },
//   });

//   // Simplified handler: Formik handles the validation state internally
//   const handleInputChange = (fieldName, value) => {
//     formik.setFieldValue(fieldName, value);
//     formik.setFieldTouched(fieldName, true, false);
//   };

//   if (loading && !formik.values.personnelName) {
//     return (
//       <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
//         <CircularProgress size={24} />
//         <Typography sx={{ ml: 2 }}>Loading Details...</Typography>
//       </Box>
//     );
//   }

//   const handleConfirmSubmit = () => {
//     setShowConfirm(false);
//     formik.handleSubmit(); // This triggers the actual Formik submission
//   };
//   return (
//     <Box>
//       <Box sx={{ display: "grid", gap: "15px", mt: 2,ml:3,mr:5 }}>
//         {/* Personnel Name */}
//         <Box sx={{ display: "flex", flexDirection: "column",  }}>
//           <Typography sx={{ mb:0.5, fontFamily: "Montserrat", fontWeight: 500 }}>
//             Personnel Name *
//           </Typography>
//           <MInput
//             value={formik.values.personnelName}
//             placeholder={"Enter Name"}
//             helperText={remainingText(formik.values.personnelName.length, 50)}
//             onChange={(e) => {
//               if (validateInput(e.target.value, personnelRegex.name) !== undefined) {
//                 handleInputChange("personnelName", e.target.value);
//               }
//             }}
//             errorMessage={formik.touched.personnelName && formik.errors.personnelName}
//           />
//         </Box>

//         {/* Rank */}
//         <Box sx={{ display: "flex", flexDirection: "column",  }}>
//           <Typography sx={{ mb:0.5, fontFamily: "Montserrat", fontWeight: 500 }}>
//             Rank *
//           </Typography>
//           <FormControl fullWidth error={formik.touched.rank && Boolean(formik.errors.rank)}>
//             <Select
//               size="small"
//               value={formik.values.rank}
//               onChange={(e) => handleInputChange("rank", e.target.value)}
//               displayEmpty
//               sx={{borderRadius:'10px'}}
//             >
//               <MenuItem value="" disabled>Select Rank</MenuItem>
//               {["AIR CMDE", "GP CAPT", "WG CDR", "SQN LDR", "FLT LT", "FG OFFR", "MWO", "WO", "JWO", "SGT", "CPL", "LAC", "AC", "AGV"].map((rank) => (
//                 <MenuItem key={rank} value={rank}>{rank}</MenuItem>
//               ))}
//             </Select>
//             {formik.touched.rank && <FormHelperText>{formik.errors.rank}</FormHelperText>}
//           </FormControl>
//         </Box>

//         {/* Unit */}
//         <Box sx={{ display: "flex", flexDirection: "column",  }}>
//           <Typography sx={{ mb:0.5, fontFamily: "Montserrat", fontWeight: 500 }}>
//             Unit *
//           </Typography>
//           <MInput
//             value={formik.values.unit}
//             placeholder={"Enter Unit"}
//             onChange={(e) => handleInputChange("unit", e.target.value)}
//             errorMessage={formik.touched.unit && formik.errors.unit}
//           />
//         </Box>

//         {/* Primary Mobile */}
//         <Box sx={{ display: "flex", flexDirection: "column",  }}>
//           <Typography sx={{ mb:0.5, fontFamily: "Montserrat", fontWeight: 500 }}>
//             Primary Civil Mobile *
//           </Typography>
//           <MInput
//             value={formik.values.primaryCivilMobile}
//             placeholder={"10 digit mobile number"}
//             onChange={(e) => {
//               if (/^[0-9]*$/.test(e.target.value) && e.target.value.length <= 10) {
//                 handleInputChange("primaryCivilMobile", e.target.value);
//               }
//             }}
//             errorMessage={formik.touched.primaryCivilMobile && formik.errors.primaryCivilMobile}
//           />
//         </Box>

  
      

//         <Box sx={{ display: "flex", flexDirection: "column",  }}>

//               <Typography sx={{ mb:0.5, fontFamily: "Montserrat" }}>AFCEL Phone</Typography>
//               <MInput
//                 value={formik.values.afcelPhone}
//                 onChange={(e) => /^[0-9]*$/.test(e.target.value) && e.target.value.length <= 8 && handleInputChange("afcelPhone", e.target.value)}
//                 errorMessage={formik.touched.afcelPhone && formik.errors.afcelPhone}
//               />
//            </Box>
//            <Box sx={{ display: "flex", flexDirection: "column",  }}>
//               <Typography sx={{ mb:0.5, fontFamily: "Montserrat" }}>IP Phone</Typography>
//               <MInput
//                 value={formik.values.ipPhone}
//                 onChange={(e) => /^[0-9]*$/.test(e.target.value) && e.target.value.length <= 8 && handleInputChange("ipPhone", e.target.value)}
//                 errorMessage={formik.touched.ipPhone && formik.errors.ipPhone}
//               />
//            </Box>
//            <Box sx={{ display: "flex", flexDirection: "column",  }}>
//           <Typography sx={{ mb:0.5, fontFamily: "Montserrat", fontWeight: 500 }}>
//             Email
//           </Typography>
//           <MInput
//             value={formik.values.email}
//             placeholder={"example@domain.com"}
//             onChange={(e) => handleInputChange("email", e.target.value)}
//             errorMessage={formik.touched.email && formik.errors.email}
//           />
//         </Box>
//         </Box>
      

//        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 4 ,mr:6}}>
//         <MButtonPrimary
//           onClick={() => setShowConfirm(true)} 
//            disabled={!formik.isValid || !formik.dirty || loading}
//         >
//           {loading ? "Updating..." : "Update"}
//         </MButtonPrimary>
//       </Box>
//       <MDialog
//               open={showConfirm}
//               variant="warning" // or "error" depending on your theme
//               title="Confirm Action"
//               icon={question_mark} // Replace with a question/warning icon if you have one
//               message="Are you sure you want to add this representative?"
//               onConfirm={handleConfirmSubmit}
//               onClose={() => setShowConfirm(false)}
//               mode="grandchild"
//             />
//     </Box>
//   );
// };

// export default ConfigEditRepDetails;
 