/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : RepDetails
   File Name                : ConfigRepDetails.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\RepDetails\ConfigRepDetails.jsx
   Purpose                  : Renders the detailed configuration repository information within 
                               the Right Utility Drawer, primarily containing the main data 
                               tables for viewing, deleteing  and managing repository details.
   Created Date             : 17-03-2026
***********************************************************************************************/
import MTable from "@/components/Reusable/Table/MTable";
import React, { useEffect, useState } from "react";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { DELETE_REMOTE_REP_DETAILS, FETCH_REMOTE_REP_DETAILS } from "@/RestAPI/url/endpoint";
import { Box, CircularProgress, Typography } from "@mui/material";
import { exportToCSV, exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";

import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useSelector } from "react-redux";
 

const ConfigRepDetails = ({
    privilegeKey,
    handleAdd,
    handleEdit,
    handleView,
    refreshTrigger,
    row,
    isChildFullScreen
}) => {
    const [loading, setLoading] = useState(false);
    const [repTableData, setRepTableData] = useState([]);
    const [rowToDelete, setRowToDelete] = useState({
        visible: false,
        row: null,
    });

    const cnmsState = useSelector((state) => state.cnmsConfig);
    const { isCnms } = useSelector((state) => state.nodeDetails);

    const siteTitleMap = {
        CNMS_001: "Mount Abu",
        CNMS_002: "Kasuli",
    };

    const siteOrder = ["CNMS_001", "CNMS_002"];

    const columns = [
        { name: "S. No ", uid: "sno", width: "60px" },
        { name: "Name", uid: "personnelName", width: "80px" }, // Increased slightly for better fit
        { name: "Rank", uid: "personnel", width: "80px" },
        { name: "Unit", uid: "unit", width: "80px" },
        { name: "IP Phone", uid: "ipPhone", width: "80px" },
        { name: "AFCEL", uid: "afcel", width: "80px" },
        { name: "Primary Mobile", uid: "primaryCivilMobile", width: "100px" },
        { name: "Email", uid: "email", width: "120px" },
        { name: "Actions", uid: "actions", sortable: false, cellClassName: "sticky-actions", headerClassName: "sticky-actions", width: "100px" },
    ];

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const response = await InventoryAxios(FETCH_REMOTE_REP_DETAILS, "get", {});
                const data = response?.data || [];
                let processedData = [];

                if (isCnms) {
                    const groupedData = { CNMS_001: [], CNMS_002: [] };
                    data.forEach((item) => {
                        if (groupedData[item.siteId]) {
                            groupedData[item.siteId].push(item);
                        }
                    });

                    processedData = siteOrder
                        .map((siteId) => ({
                            siteId,
                            data: groupedData[siteId].map((item, index) => ({ ...item, sno: index + 1 })),
                        }))
                        .filter((group) => group.data.length > 0);
                } else {
                    processedData = data.map((item, index) => ({ ...item, sno: index + 1 }));
                }

                setRepTableData(processedData);
            } catch (error) {
                console.error("Error fetching Rep Details:", error);
                Toast("Error!", "Failed to fetch Rep Details", "error");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [refreshTrigger, isCnms]);

    const handleDeleteRow = async (row) => {
        if (!row) return;
        const targetSiteId = isCnms ? row.siteId : cnmsState?.siteId || row.siteId;

        if (!targetSiteId) {
            console.error("Unable to determine site ID:", row);
            Toast("Error!", "Cannot determine site for deletion.", "error");
            return;
        }

        const payload = {
            siteId: targetSiteId,
            repId: row.repId,
            personnelName: row.personnelName,
            personnel: row.personnel,
            unit: row.unit,
            ipPhone: row.ipPhone || null,
            afcel: row.afcel || null,
            primaryCivilMobile: row.primaryCivilMobile || null,
            alternateCivilMobile: row.alternateCivilMobile || null,
            email: row.email || "",
        };

        try {
            await InventoryAxios(DELETE_REMOTE_REP_DETAILS, "post", payload);

            setRepTableData((prevData) => {
                if (isCnms) {
                    return prevData
                        .map((group) => {
                            if (group.siteId !== targetSiteId) return group;
                            return {
                                ...group,
                                data: group.data
                                    .filter((item) => item.repId !== row.repId)
                                    .map((item, index) => ({ ...item, sno: index + 1 })),
                            };
                        })
                        .filter((group) => group.data.length > 0);
                }
                return prevData
                    .filter((item) => item.repId !== row.repId)
                    .map((item, index) => ({ ...item, sno: index + 1 }));
            });

            Toast("Success!", "Successfully deleted representative", "success");
            setRowToDelete({ visible: false, row: null });
        } catch (error) {
            console.error("Delete API Error:", error);
            Toast("Error!", "Failed to delete representative", "error");
        }
    };

    // --- FIX FOR HEIGHT & SCROLLING ---
    // We set a large max-height to prevent overflow, but allow it to grow.
    // If MTable supports 'height: auto', use that. Otherwise, this CSS approach works best.
    const tableContainerStyle = {
        width: "100%",
        overflowX: "hidden", // Prevents horizontal scroll
        overflowY: "auto",  // Allows vertical scroll if screen is small
        minHeight: "200px",  // Minimum height for empty state
    };

    const renderTableBody = () => {
        if (isCnms) {
            return repTableData.map((group) => {
                const currentSiteTitle = siteTitleMap[group.siteId] || `Site: ${group.siteId}`;
                const isAddDisabled = group.data.length >= 5;
                const isDeleteDisabled = group.data.length <= 1;

                return (
                    <Box key={group.siteId} sx={{ p: 1, borderBottom: "1px solid #eee" }}>
                        <Box sx={{   fontWeight: "bold", color: "text.primary" }}>
                        
                        </Box>
                        <MTable
                            typeHeight="configuration"
                            configHeight="auto" // CRITICAL: Let the table determine its own height
                            privilegeKey={privilegeKey}
                            columns={columns}
                            tableData={group.data}
                            showPagination={false}
                            addDisable={isAddDisabled}
                            deleteDisable={isDeleteDisabled}
                            hideAdd={false}
                            siteId={group.siteId}
                            tableTitle={currentSiteTitle}
                            handleAdd={() =>
                                handleAdd({
                                    mode: "CREATE",
                                    siteId: group.siteId,
                                    title: `Add Representative for ${currentSiteTitle}`,
                                })
                            }
                            handleEdit={(row) =>
                                handleEdit({
                                    ...row,
                                    siteId: group.siteId,
                                    mode: "EDIT",
                                    setRepTableData: setRepTableData,
                                    title: `Edit Representative: ${row.personnelName || "RECORD"}`,
                                })
                            }
                            handleDelete={(row) => {
                                const currentGroup = repTableData.find((g) => g.siteId === row.siteId);
                                if (!currentGroup || currentGroup.data.length <= 1) {
                                    Toast("Action Denied", "At least one representative must remain.", "error");
                                    return;
                                }
                                setRowToDelete({ visible: true, row: { ...row, siteId: group.siteId } });
                            }}
                            handleDownloadPDF={() =>
                                exportToPDF(`Rep Details Report (${currentSiteTitle})`, columns, group.data, `Rep_Details_${group.siteId}`)
                            }
                            handleDownloadCSV={() =>
                                exportToCSV(`Rep_Details_${group.siteId}`, columns, group.data)
                            }
                            showSearch={true}
                            AddText="Add"
                            // Optional: Ensure column widths don't force horizontal scroll
                            fixedColumnWidth={false} 
                        />
                        <Typography sx={{ p: 1, color: "#e75656", fontSize: "12px", mt: 0.5 }}>
                            Note : Maximum 5 Rep's can be added for this site.
                        </Typography>
                    </Box>
                );
            });
        } else {
            const isAddButtonDisabled = repTableData.length >= 5;
            const isDeleteButtonDisabled = repTableData.length <= 1;

            return (
                <MTable
                    typeHeight="configuration"
                    configHeight="auto" // CRITICAL: Let the table determine its own height
                    privilegeKey={privilegeKey}
                    columns={columns}
                    tableData={repTableData}
                    showPagination={false}
                    addDisable={isAddButtonDisabled}
                    deleteDisable={isDeleteButtonDisabled}
                    hideAdd={false}
                    handleAdd={() =>
                        handleAdd({ mode: "CREATE", title: "Add Representative" })
                    }
                    handleEdit={(row) =>
                        handleEdit({
                            ...row,
                            mode: "EDIT",
                            setRepTableData: setRepTableData,
                            title: `Edit Representative: ${row.personnelName || row.fullName || "RECORD"}`,
                        })
                    }
                    handleDelete={(row) => {
                        if (repTableData.length <= 1) {
                            Toast("Action Denied", "At least one representative must remain.", "error");
                            return;
                        }
                        setRowToDelete({ visible: true, row });
                    }}
                    handleDownloadPDF={() =>
                        exportToPDF("Rep Details Report", columns, repTableData, "Rep_Details_Report")
                    }
                    handleDownloadCSV={() =>
                        exportToCSV("Rep_Details_Export", columns, repTableData)
                    }
                    showSearch={true}
                    AddText="Add"
                    fixedColumnWidth={false}
                />
            );
        }
    };

    return (
        <Box sx={{ width: "100%", overflowX: "hidden", p: 2 }}>
            {loading ? (
                <Box className="flex justify-center p-10" sx={{ minHeight: "200px" }}>
                    <CircularProgress size={30} />
                </Box>
            ) : (
                <Box sx={tableContainerStyle}>
                    {renderTableBody()}
                </Box>
            )}

            {/* Confirmation Dialog */}
            {rowToDelete.visible && (
                <MDialog
                    open={rowToDelete.visible}
                    variant="error"
                    title="Confirm Action"
                    icon={Delete_Icon_}
                    mode="child"
                    isChildFullScreen={isChildFullScreen}
                    message={`Are you sure you want to delete ${rowToDelete.row?.personnelName || "this record"}?`}
                    onConfirm={() => handleDeleteRow(rowToDelete.row)}
                    onClose={() => setRowToDelete({ visible: false, row: null })}
                />
            )}
        </Box>
    );
};

export default ConfigRepDetails;

