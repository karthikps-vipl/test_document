 /***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : NetworkAccelerator
   File Name                : ConfigNetworkAccelerator.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Configuration\NetworkAccelerator\ConfigNetworkAccelerator.jsx
   Purpose                  : Handles updating Network Accelerator device API tokens.
   Created Date             : 23-04-2026
***********************************************************************************************/


import React, { useState, useEffect } from 'react';
import { Box, Typography, CircularProgress } from '@mui/material';
import MDialog from '@/components/Reusable/Dialog/MDialog';
import { ConfigurationAxios, InventoryAxios } from '@/RestAPI/api/axiosApicall';
import {
  FETCH_NETWORK_ACCELERATOR_DETAILS_OF_TERMINAL_TYPE,
  GET_NET_CONFIG_API_TOKEN_FOR_GIVEN_RESID,
  UPDATE_NET_CONFIG_API_TOKEN_FOR_GIVEN_RESID
} from '@/RestAPI/url/endpoint';
import MButtonPrimary from '@/components/Reusable/Button/MButtonPrimary';
import Toast from '@/components/Reusable/Toast/Toast';
import MSelect from '@/components/Reusable/Select/MSelect';
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MForm from '@/components/Reusable/Form/MForm';
import FormField from '@/components/Reusable/Form/FormField';

const ConfigNetworkAccelerator = ({isChildFullScreen}) => {
  const [resources, setResources] = useState([]);
  const [selectedOption, setSelectedOption] = useState(null);
  const [selectedResourceId, setSelectedResourceId] = useState('');
  const [apiToken, setApiToken] = useState('');
  const [originalToken, setOriginalToken] = useState(''); 
  const [loading, setLoading] = useState(true);
  const [fetchingToken, setFetchingToken] = useState(false);  
  const [showConfirm, setShowConfirm] = useState(false);
  
  // NEW: Error state for the input field
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await InventoryAxios(FETCH_NETWORK_ACCELERATOR_DETAILS_OF_TERMINAL_TYPE, "get", 1);
        const data = response?.data.map((item) => ({
          id: item.resourceId,
          value: item,  
          label: item.resourceName
        }));
        setResources(data);
      } catch (error) {
        console.error('Error fetching resource names:', error);
        Toast("Error!", "Failed to fetch device list", "error");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleResourceSelect = async (option) => {
    setErrorMsg(""); // Clear errors when selecting a new device
    setSelectedOption(option); 
    const resId = option.value.resourceId;
    setSelectedResourceId(resId);
    
    if (!resId) {
      setApiToken("");
      setOriginalToken("");
      return;
    }

    setFetchingToken(true);
    try {
       const response = await ConfigurationAxios(
        GET_NET_CONFIG_API_TOKEN_FOR_GIVEN_RESID, 
        'post', 
        { resourceId: resId }
      );
      const tokenData = response?.data;
      if (tokenData && tokenData.apiToken) {
        setApiToken(tokenData.apiToken);
        setOriginalToken(tokenData.apiToken); 
      } else {
        setApiToken("");
        setOriginalToken("");
      }
    } catch (error) {
      console.error('Error fetching API token:', error);
      setApiToken("");
      setOriginalToken("");
    } finally {
      setFetchingToken(false);
    }
  };

  const handleTokenChange = (e) => {
    const val = e.target.value;
    setApiToken(val);
    
    // Validate immediately as they type/delete
    if (val.trim() === "") {
      setErrorMsg("API Token cannot be empty");
    } else {
      setErrorMsg(""); // Clear error if they start typing again
    }
  };

  const validateToken = () => {
    if (!apiToken || apiToken.trim() === "") {
      setErrorMsg("API Token cannot be empty");
      return false;
    }
    
    const alphaNumericRegex = /^[a-zA-Z0-9]+$/;
    if (!alphaNumericRegex.test(apiToken)) {
      setErrorMsg("API Token must be Alphanumeric (no special characters)");
      return false;
    }
    
    setErrorMsg(""); // Clear error if validation passes
    return true;
  };

  const handleUpdate = async () => {
    // Run validation before proceeding to Dialog or API
    if (!validateToken()) return;

    try {
      const payload = {
        resourceId: selectedResourceId,
        apiToken: apiToken,
      };
      const response = await ConfigurationAxios(
        UPDATE_NET_CONFIG_API_TOKEN_FOR_GIVEN_RESID,
        'post',
        payload
      );
     
      if (response.data?.status === 1 || response.status === 200) {
        setOriginalToken(apiToken); 
        setShowConfirm(false);
        Toast("Success!", "Network Accelerator token updated successfully", "success");
      }
    } catch (error) {
      console.error('Error updating resource:', error);
      Toast("Error!", "Failed to update configuration", "error");
    }
  };

  // Button logic: Disable if no device selected OR if value is same as original
  const isUpdateDisabled = !selectedResourceId || apiToken === originalToken;
  return (
    <MForm title="Network Accelerator Configuration">
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress size={30} style={{ color: "#14348D" }} />
        </Box>
      ) : resources.length === 0 ? (
        <Typography textAlign="center" sx={{ py: 4 }}>
          No devices found
        </Typography>
      ) : (
        <>
         
          <Box className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
            
            {/* Device Select Section */}
            <Box>
              <Typography sx={{ fontFamily: "Montserrat", mb: 0.5 }}>
                Device
              </Typography>
              <MSelect
                options={resources}
                value={selectedOption}
                onChange={(option) => handleResourceSelect(option)}
                placeholder="Select Device"
              />
            </Box>
  
            {/* API Token Section */}
            <Box>
              <FormField
                label="Api Token"
                disabled={fetchingToken}
                error={errorMsg.length > 0}
                errorMessage={errorMsg}
                placeholder="Enter Api Token"
                value={apiToken}
                onChange={handleTokenChange}
              />
            </Box>
          </Box>
  
          {/* Action Section */}
          <Box sx={{ display: "flex", justifyContent: "end", mt: 4 }}>
            <MButtonPrimary
              onClick={() => {
                if (validateToken()) {
                  setShowConfirm(true);
                }
              }}
              disabled={isUpdateDisabled}
            >
              Update
            </MButtonPrimary>
          </Box>
        </>
      )}
  
      <MDialog
        open={showConfirm}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to update the Network Accelerator token?"
        onConfirm={handleUpdate}
        onClose={() => setShowConfirm(false)}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </MForm>
  );
   
};

export default ConfigNetworkAccelerator;