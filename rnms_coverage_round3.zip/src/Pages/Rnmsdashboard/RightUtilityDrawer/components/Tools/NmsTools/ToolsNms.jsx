
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Box, Tabs, Tab, Typography, FormControl,
  RadioGroup, FormControlLabel, Radio, CircularProgress,
} from "@mui/material";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";

// --- Import Mask Components from Utils Folder ---
 
// --- API Service and State Pipeline Hooks ---
import { ARP_TOOL_FIND_IP, PING_TOOLS, TRACE_TOOL, } from "@/RestAPI/url/endpoint";
import { clearPingData, setPingData } from "@/store/features/Ping/pingSlice";

// --- Terminal Panel View Sub-Modules ---
import PingOutputView from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/NmsTools/PingOutputView";
import ArpOutputView from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/NmsTools/ArpOutputView";
import TraceRouteOutputView from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/NmsTools/TraceRouteOutputView";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";

const ToolsNms = ({ selectedIp }) => {
  const dispatch = useDispatch();
  const [activeTab, setActiveTab] = useState(0);
   const { isCnms } = useSelector((state) => state.nodeDetails);

  const [ip, setIp] = useState(selectedIp || "");
  const [ipType, setIpType] = useState("1");
  const [noOfRequests, setNoOfRequests] = useState("3");
  const [timeout, setTimeoutValue] = useState("1");
  const [maxHops, setMaxHops] = useState("30");
  const allowedTabs = isCnms ? [0, 2] : [0, 1, 2];

  const [maxHopsError, setMaxHopsError] = useState("");
  const [ipError, setIpError] = useState("");
  const [requestError, setRequestError] = useState("");
  const [timeoutError, setTimeoutError] = useState("");

  const [loading, setLoading] = useState(false);
  const [reqIp, setReqIp] = useState("");

  const { pingData } = useSelector((state) => state.ping);

  useEffect(() => {
    setIp("");
    setIpError("");
    setReqIp("");
    setRequestError("");
    setTimeoutError("");
    setMaxHopsError("");
  }, [activeTab]);

  console.log("1. Requested IP (local state):", reqIp);
  console.log("2. PingData from Redux:", pingData);

  const isCorrectIp =
    pingData &&
    (pingData.ip === reqIp || pingData.ipAddress === reqIp);

  console.log("Current PingData from Redux:", pingData);
  console.log("Comparing:", pingData?.ipAddress, "with", reqIp);
  console.log("3. Is Correct IP?:", isCorrectIp);

  const getConsoleOutput = () => {
    if (!isCorrectIp || !pingData) return "";

    const incomingType =
      pingData?.toolType?.toUpperCase().trim() || "";

    const tabToTypeMap = {
      0: "PING",
      1: "ARP",
      2: "TRACEROUTE",
    };

    const currentTabType = tabToTypeMap[activeTab];

    if (
      incomingType !== "" &&
      incomingType !== currentTabType
    ) {
      return "";
    }

    if (activeTab === 0) return pingData.pingOutput || "";
    if (activeTab === 1) return pingData.arpOutput || "";
    if (activeTab === 2) return pingData.traceOutput || "";

    return "";
  };

  const currentConsoleResponse = getConsoleOutput();
  const status = isCorrectIp
    ? pingData?.isReachable
    : "none";

  useEffect(() => {
    if (isCorrectIp && currentConsoleResponse) {
      setLoading(false);
    }
  }, [currentConsoleResponse, isCorrectIp]);

  const MIN_REQUESTS = 1;
  const MAX_REQUESTS = 10;

  const MIN_TIMEOUT = 1;
  const MAX_TIMEOUT = 5;

  const MIN_HOPS = 1;
  const MAX_HOPS = 30;

  const isValidIPv4 = (value) => {
    if (!value) return false;

    const parts = value.split(".");

    if (parts.length !== 4) return false;

    return parts.every((part) => {
      if (part === "") return false;
      if (!/^\d{1,3}$/.test(part)) return false;

      const num = Number(part);

      return num >= 0 && num <= 255;
    });
  };

  const onChangeValues = (item, value) => {
    if (item === "ip") {
      if (ipType === "1") {
        let cleaned = value.replace(/[^0-9.]/g, "").slice(0, 15);
        cleaned = cleaned.replace(/\.{2,}/g, ".");

        const segments = cleaned.split(".");

        if (segments.length > 4) {
          setIpError("IP address cannot have more than 4 segments");
          return;
        }

        const validatedSegments = segments.map((seg) => {
          if (seg === "") return "";
          if (seg.length > 3) seg = seg.slice(0, 3);
          if (Number(seg) > 255) {
            seg = seg.slice(0, -1);
          }
          return seg;
        });

        let reconstructed = validatedSegments.join(".");
        if (cleaned.endsWith(".") && segments.length <= 4 && !reconstructed.endsWith(".")) {
          reconstructed += ".";
        }

        setIp(reconstructed);

        if (reconstructed === "") {
          setIpError("Field is required");
          return;
        }

        let hasError = false;
        let errorMessage = "";

        const finalParts = reconstructed.split(".");
        for (const part of finalParts) {
          if (part === "" || Number(part) > 255) {
            hasError = true;
            errorMessage = "Invalid IP Address ";
            break;
          }
        }

        if (hasError) {
          setIpError(errorMessage);
        } else {
          setIpError("");
        }
      } else {
        const parsedValue = value
          .toLowerCase()
          .replace(/[^0-9a-f:%]/g, "");

        setIp(parsedValue);
        if (parsedValue === "") {
          setIpError("Field is required");
        } else {
          setIpError("");
        }
      }

      return;
    }

    if (item === "noOfRequests") {
      if (value === "") {
        setNoOfRequests("");
        setRequestError("Field is required");
        return;
      }

      const digitsOnly = value.replace(/\D/g, "").slice(0, 2);
      setNoOfRequests(digitsOnly);

      if (digitsOnly === "") {
        setRequestError("Field is required");
        return;
      }

      const num = Number(digitsOnly);
      if (num < MIN_REQUESTS || num > MAX_REQUESTS) {
        setRequestError("Number of requests must be between 1 and 10");
      } else {
        setRequestError("");
      }
      return;
    }

    if (item === "timeout") {
      if (value === "") {
        setTimeoutValue("");
        setTimeoutError("Field is required");
        return;
      }

      const digitsOnly = value.replace(/\D/g, "").slice(0, 1);
      setTimeoutValue(digitsOnly);

      if (digitsOnly === "") {
        setTimeoutError("Field is required");
        return;
      }

      const num = Number(digitsOnly);
      if (num < MIN_TIMEOUT || num > MAX_TIMEOUT) {
        setTimeoutError("Timeout must be between 1 and 5 seconds");
      } else {
        setTimeoutError("");
      }
      return;
    }

    if (item === "maxHops") {
      if (value === "") {
        setMaxHops("");
        setMaxHopsError("Field is required");
        return;
      }

      const digitsOnly = value.replace(/\D/g, "").slice(0, 2);
      setMaxHops(digitsOnly);

      if (digitsOnly === "") {
        setMaxHopsError("Field is required");
        return;
      }

      const num = Number(digitsOnly);
      if (num < MIN_HOPS || num > MAX_HOPS) {
        setMaxHopsError("Max hops must be between 1 and 30");
      } else {
        setMaxHopsError("");
      }
      return;
    }
  };

  const validIPv4 =
    ipType === "1"
      ? isValidIPv4(ip)
      : ip.trim().length > 0;

  const validRequests =
    activeTab !== 0 ||
    (Number(noOfRequests) >= MIN_REQUESTS &&
      Number(noOfRequests) <= MAX_REQUESTS);

  const validTimeout =
    (activeTab !== 0 && activeTab !== 2) ||
    (Number(timeout) >= MIN_TIMEOUT &&
      Number(timeout) <= MAX_TIMEOUT);

  const validHops =
    activeTab !== 2 ||
    (Number(maxHops) >= MIN_HOPS &&
      Number(maxHops) <= MAX_HOPS);

  const isExecuteDisabled =
    loading ||
    !validIPv4 ||
    !validRequests ||
    !validTimeout ||
    !validHops ||
    !!ipError ||
    !!requestError ||
    !!timeoutError ||
    !!maxHopsError ||
    !ip.trim() ||
    (activeTab === 0 && (!noOfRequests || !timeout)) ||
    (activeTab === 2 && (!maxHops || !timeout));
 
  const onClickExecuteDiagnostic = async () => {
    // 1. Basic Field Validation
    if (!ip.trim()) {
      setIpError("Field is required");
      return;
    }

    // 2. Conditional Validation based on Active Tab
    if (activeTab === 0) {
      if (!noOfRequests) {
        setRequestError("Field is required");
        return;
      }
      if (!timeout) {
        setTimeoutError("Field is required");
        return;
      }
    }

    if (activeTab === 2) {
      if (!maxHops) {
        setMaxHopsError("Field is required");
        return;
      }
      if (!timeout) {
        setTimeoutError("Field is required");
        return;
      }
    }

    // 3. IP Format Validation
    const validIp =
      ipType === "1"
        ? isValidIPv4(ip)
        : ip.trim().length > 0;

    if (!validIp) {
      setIpError(
        ipType === "1"
          ? "Enter a valid IPv4 address (segments 0-255)"
          : "Enter a valid IPv6 address"
      );
      return;
    }

    // 4. Range Validations (Requests/Timeout/Hops)
    const validRequests =
      activeTab === 0 &&
      Number(noOfRequests) >= MIN_REQUESTS &&
      Number(noOfRequests) <= MAX_REQUESTS;

    const validTimeout =
      (activeTab === 0 || activeTab === 2) &&
      Number(timeout) >= MIN_TIMEOUT &&
      Number(timeout) <= MAX_TIMEOUT;

    const validHops =
      activeTab === 2 &&
      Number(maxHops) >= MIN_HOPS &&
      Number(maxHops) <= MAX_HOPS;

    if (activeTab === 0) {
      if (!validRequests) {
        setRequestError("Number of requests must be between 1 and 10");
        return;
      }
      if (!validTimeout) {
        setTimeoutError("Timeout must be between 1 and 5 seconds");
        return;
      }
    }

    if (activeTab === 2) {
      if (!validHops) {
        setMaxHopsError("Max hops must be between 1 and 30");
        return;
      }
      if (!validTimeout) {
        setTimeoutError("Timeout must be between 1 and 5 seconds");
        return;
      }
    }

    // // 5. CNMS Security Check: Prevent ARP if isCnms is true
    // if (activeTab === 1 && isCnms) {
    //   Toast("Error!", "ARP tool is not available in CNMS mode", "error");
    //   return;
    // }

    // 6. Prepare Execution
    setLoading(true);
    setReqIp(ip);
    dispatch(clearPingData());

    let targetEndpoint = PING_TOOLS;
    let payload = {};

    if (activeTab === 0) {
      targetEndpoint = PING_TOOLS;
      payload = {
        ip,
        timeOutInSecs: timeout,
        numOfReq: noOfRequests,
        toolType: "PING",
      };
    } else if (activeTab === 1) {
      targetEndpoint = ARP_TOOL_FIND_IP;
      payload = {
        ip,
      };
    } else if (activeTab === 2) {
      targetEndpoint = TRACE_TOOL;
      payload = {
        ip,
        timeOutInSecs: timeout,
        numOfHops: maxHops,
        toolType: "TRACEROUTE",
      };
    }

    // 7. API Call and Response Handling
    try {
      const response = await FaultAxios(
        targetEndpoint,
        "post",
        payload
      );

      console.log("Full Response:", response);

      if (response.data) {
        let extractedString = "";

        if (typeof response.data === "string") {
          extractedString = response.data;
        } else if (typeof response.data === "object") {
          if (activeTab === 0) {
            extractedString = response.data.pingOutput || "";
          } else if (activeTab === 1) {
            extractedString = response.data.arpOutput || "";
          } else if (activeTab === 2) {
            extractedString =
              response.data.data ||
              response.data.traceOutput ||
              "";
          }

          if (!extractedString && response.data.data) {
            extractedString = response.data.data;
          }
        }

        // Reachability logic helper
        const checkReachability = (data, text) => {
          if (text && typeof text === "string") {
            const lowerText = text.toLowerCase();
            const failureKeywords = [
              "timed out",
              "unreachable",
              "request timed out",
              "destination host unreachable",
              "failed",
            ];
            const successKeywords = ["reply from", "ttl=", "replied"];

            const hasFailure = failureKeywords.some((keyword) =>
              lowerText.includes(keyword)
            );

            if (hasFailure) return false;

            const hasSuccess = successKeywords.some((keyword) =>
              lowerText.includes(keyword)
            );

            return hasSuccess;
          }

          if (typeof data === "object" && data !== null) {
            return data.status === true || data.status === "success";
          }

          return false;
        };

        // 8. Format data for Redux Store
        const formattedData = {
          ip,
          pingOutput: activeTab === 0 ? extractedString : "",
          arpOutput: activeTab === 1 ? extractedString : "",
          traceOutput: activeTab === 2 ? extractedString : "",
          isReachable: checkReachability(response.data, extractedString),
          toolType:
            activeTab === 0
              ? "PING"
              : activeTab === 1
              ? "ARP"
              : "TRACEROUTE",
        };

        dispatch(setPingData(formattedData));

        Toast("Success!", "Operation completed.", "success");
        setLoading(false);
      } else {
        Toast("Error!", "Empty response from server", "error");
        setLoading(false);
      }
    } catch (error) {
      console.error("Execution Error:", error);
      setLoading(false);
      setReqIp("");
      Toast("Error!", "Failed to execute toolkit operation", "error");
    }
  };
  console.log(
    "Console Response Content:",
    currentConsoleResponse
  );

  const handleClear = () => {
    dispatch(clearPingData());
  };


  return (
    <Box
      sx={{
        width: "100%",
        border: "2px solid #eee",
        mt: 2,
        borderRadius: "10px",
      }}
    >
      <Box
        sx={{
          borderBottom: 1,
          borderColor: "divider",
          ml: 1,
        }}
      >
        <Tabs
          value={isCnms && activeTab === 2 ? 1 : activeTab}
          onChange={(e, val) => {
            const selectedToolIndex =
              isCnms && val === 1 ? 2 : val;

            setActiveTab(selectedToolIndex);
          }}
        >
          <Tab label="Ping" />
          {!isCnms && <Tab label="ARP" />}
          <Tab label="Trace Route" />
        </Tabs>

      </Box>

      <Box
        sx={{
          p: 2,
          ml: 2,
        }}
      >
        <Typography
          sx={{
            color: "text.TitleTextcolor",
          }}
        >
          Parameters
        </Typography>

        <FormControl
          component="fieldset"
          sx={{ mb: 2 }}
        >
          <RadioGroup
            row
            value={ipType}
            onChange={(e) => {
              setIpType(e.target.value);
              onChangeValues("ip", "");
            }}
          >
            <FormControlLabel
              value="1"
              control={<Radio />}
              label="IP V4"
            />

            <FormControlLabel
              value="2"
              control={<Radio />}
              label="IP V6"
            />
          </RadioGroup>
        </FormControl>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns:
              activeTab === 0 ||
              activeTab === 2
                ? "2fr 2fr 2fr 1fr"
                : "4fr 1fr",
            gap: "20px",
            width: "100%",
            pb: 2,
            alignItems: "start",
          }}
        >
          <Box>
            <Typography sx={{ mb: 0.5, fontSize: "14px" }}>
              IP Address *
            </Typography>
            <MInput
              value={ip}
              onChange={(e) =>
                onChangeValues("ip", e.target.value)
              }
              error={!!ipError}
              helperText={ipError}
              size="small"
              fullWidth
             placeholder={ipType === "1" ? "___.___.___.___" : "Enter IPv6 address"}
              inputProps={{
                maxLength: ipType === "1" ? 15 : 25,
              }}
            />

          </Box>

          {activeTab === 0 && (
            <>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography sx={{ mb: 0.5, fontSize: "14px" }}>
                  No of Requests *
                </Typography>

                <MInput
                  value={noOfRequests}
                  onChange={(e) =>
                    onChangeValues("noOfRequests", e.target.value)
                  }
                  error={!!requestError}
                  helperText={requestError}
                  size="small"
                  fullWidth
                  inputProps={{
                    maxLength: 2,
                  }}
                />
              </Box>

              <Box>
                <Typography sx={{ mb: 0.5, fontSize: "14px" }}>
                  Timeout (Sec) *
                </Typography>

                <MInput
                  value={timeout}
                  onChange={(e) =>
                    onChangeValues("timeout", e.target.value)
                  }
                  error={!!timeoutError}
                  helperText={timeoutError}
                  size="small"
                  fullWidth
                  inputProps={{
                    maxLength: 1,
                  }}
                />
              </Box>
            </>
          )}

          {activeTab === 2 && (
            <>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography sx={{ mb: 0.5, fontSize: "14px" }}>
                  Max Hops *
                </Typography>

                <MInput
                  value={maxHops}
                  onChange={(e) =>
                    onChangeValues("maxHops", e.target.value)
                  }
                  error={!!maxHopsError}
                  helperText={maxHopsError}
                  size="small"
                  fullWidth
                  inputProps={{
                    maxLength: 2,
                  }}
                />
              </Box>

              <Box>
                <Typography sx={{ mb: 0.5, fontSize: "14px" }}>
                  Timeout (Sec) *
                </Typography>

                <MInput
                  value={timeout}
                  onChange={(e) =>
                    onChangeValues(
                      "timeout",
                      e.target.value
                    )
                  }
                  error={!!timeoutError}
                  helperText={timeoutError}
                  size="small"
                  fullWidth
                  inputProps={{
                    maxLength: 1,
                  }}
                />
              </Box>
            </>
          )}

          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mt: 3,
              justifyContent: "flex-end",
            }}
          >
            <MButtonPrimary
              onClick={
                onClickExecuteDiagnostic
              }
              disabled={isExecuteDisabled}
              fullWidth
            >
              {loading ? (
                <CircularProgress
                  size={24}
                  color="inherit"
                />
              ) : (
                activeTab === 0
                  ? "Ping"
                  : activeTab === 1
                  ? "Find"
                  : "Trace"
              )}
            </MButtonPrimary>
          </Box>
        </Box>
      </Box>

      <Box
        sx={{
          border: "1px solid #eee",
          mb: 1,
        }}
      />

      <Box>
        <Typography
          sx={{
            mb: 1,
            pl: 3,
            color: "text.TitleTextcolor",
          }}
        >
          Output
        </Typography>

        {activeTab === 0 && (
          <PingOutputView
            isCorrectIp={isCorrectIp}
            output={currentConsoleResponse}
            status={status}
          />
        )}

        {activeTab === 1 && (
          <ArpOutputView
            output={currentConsoleResponse}
          />
        )}

        {activeTab === 2 && (
          <TraceRouteOutputView
            output={currentConsoleResponse}
          />
        )}

        <Box
          sx={{
            mb: 1,
            mt: 1,
            display: "flex",
            justifyContent: "flex-end",
            mr: 2,
          }}
        >
          <MButtonPrimary
            variant="outlined"
            color="inherit"
            onClick={handleClear}
            disabled={
              !currentConsoleResponse &&
              !loading
            }
          >
            Clear
          </MButtonPrimary>
        </Box>
      </Box>
    </Box>
  );



};

export default ToolsNms;
 