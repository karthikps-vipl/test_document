import React from "react";
import { Box, TextField, ThemeProvider, createTheme } from "@mui/material";

const blackConsoleTheme = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          backgroundColor: "#000000",
          "& .MuiOutlinedInput-input": { color: "#ffff", fontFamily: "Courier New" }
        }
      }
    }
  }
});

const ArpOutputView = ({ output,  }) => {
    console.log("aaaaaaaaaaaaaaaa",output)
  return (
    <Box>
      <ThemeProvider theme={blackConsoleTheme}>
 <TextField
  multiline
  fullWidth
  // Use standard value prop
  value={output || ""} 
  // Ensure it shows the placeholder when empty
  InputLabelProps={{ shrink: true }}
  placeholder={output }
  slotProps={{
    input: {
      readOnly: true,
    },
  }}
  maxRows={8}
  minRows={8}
  variant="outlined"
/>  
 
           </ThemeProvider>
    </Box>
  );
};

export default ArpOutputView;
