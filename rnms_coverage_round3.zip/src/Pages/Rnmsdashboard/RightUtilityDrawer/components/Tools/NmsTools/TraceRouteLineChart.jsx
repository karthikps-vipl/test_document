 import { useTheme } from "@mui/material";
import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Label,
} from "recharts";

// 1. CustomTooltip is correctly moved outside
export const CustomTooltip = ({ active, payload, data }) => {
  if (active && payload && payload.length) {
    const currentHop = Number(payload[0].payload.hop);
    const hopInfo = data.find((e) => Number(e.hop) === currentHop);

    return (
      <div
        style={{
          backgroundColor: "#fff",
          padding: "10px",
          border: "1px solid #ccc",
          fontSize: "12px",
          boxShadow: "2px 2px 5px rgba(0,0,0,0.1)",
        }}
      >
        <div>Hop: {currentHop}</div>
        <div>
          Address: {hopInfo?.address || "N/A"}{" "}
          {hopInfo?.ip ? `(${hopInfo.ip})` : ""}
        </div>
        <div>RTT(ms): {payload[0].value}</div>
      </div>
    );
  }
  return null;
};

const RenderCustomizedLabel = (props) => {
  const { x, y, index, data } = props; // 'data' comes from the parent call below
  const hopInfo = data[index];

  if (!hopInfo?.ip) return null;

  return (
    <text x={x} y={y} dy={-10} textAnchor="middle" fill="#666">
      {hopInfo.ip}
    </text>
  );
};

const TraceRouteLineChart = ({ title, data }) => {
  const renderLabel = useMemo(
    () => (props) => <RenderCustomizedLabel {...props} data={data} />,
    [data]
  );
const theme=useTheme();
const isdark = theme.palette.mode='dark'
  return (
    <div
      style={{ height: "100%", width: "100%", padding: 0, background: isdark?"#fff":"" }}
    >
      <h3 style={{ textAlign: "center", fontFamily: "sans-serif" }}>{title}</h3>
      <ResponsiveContainer width="100%" height="90%">
        <LineChart
          data={data}
          margin={{ top: 30, right: 30, left: 20, bottom: 20 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="hop" tickFormatter={(val) => val}>
            <Label value="Hops" offset={-10} position="insideBottom" />
          </XAxis>
          <YAxis>
            <Label
              value="Avg RTT (ms)"
              angle={-90}
              position="insideLeft"
              style={{ textAnchor: "middle",color:isdark?"#ffffff":"#000000" }}
            />
          </YAxis>

          {/* Pass data to tooltip */}
          <Tooltip content={<CustomTooltip data={data} />} />

          <Line
            type="monotone"
            dataKey="avgRTT"
            stroke="#8884d8"
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
            label={renderLabel}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default React.memo(TraceRouteLineChart);
