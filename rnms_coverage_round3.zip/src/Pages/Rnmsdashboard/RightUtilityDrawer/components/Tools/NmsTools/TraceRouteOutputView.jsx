import React from "react";
import { Box, TextField, ThemeProvider, createTheme } from "@mui/material";

const blackConsoleTheme = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          backgroundColor: "#000000",
          "& .MuiOutlinedInput-input": { color: "#FFFF", fontFamily: "Courier New" }
        }
      }
    }
  }
});

const TraceRouteOutputView = ({ output }) => {
  return (
    <Box>
      <ThemeProvider theme={blackConsoleTheme}>
 <TextField
  multiline
  fullWidth
  // Use standard value prop
  value={output||""} 
  // Ensure it shows the placeholder when empty
  InputLabelProps={{ shrink: true }}
  placeholder={output}
  slotProps={{
    input: {
      readOnly: true,
    },
  }}
  maxRows={8}
  minRows={8}
  variant="outlined"
/>      </ThemeProvider>
    </Box>
  );
};

export default TraceRouteOutputView;
// import React, { useMemo } from "react";
// import { Box, TextField, ThemeProvider, createTheme } from "@mui/material";
// import TraceRouteLineChart from "./TraceRouteLineChart"; // Make sure path is correct

// const blackConsoleTheme = createTheme({
//   components: {
//     MuiOutlinedInput: {
//       styleOverrides: {
//         root: {
//           backgroundColor: "#000000",
//           "& .MuiOutlinedInput-input": { color: "#FFFF", fontFamily: "Courier New" }
//         }
//       }
//     }
//   }
// });

// /**
//  * PARSING LOGIC:
//  * This converts the raw text from your console into the format:
//  * [{ hop: '1', avgRTT: 10, ip: '192.168.1.1', address: '...' }]
//  */
// const parseTraceTextToData = (text) => {
//   if (!text) return [];
  
//   const lines = text.split('\n');
//   const dataPoints = [];

//   lines.forEach((line) => {
//     // Regex: Looks for a number (hop) followed by something containing "ms" (rtt) 
//     // and an IP address pattern
//     const hopMatch = line.match(/^\s*(\d+)/); // Finds the first number (hop)
//     // const rttMatch = line.match(/(\d+\.?\d*)\s*ms/i); // Finds the number before "ms"
//     const safeRttRegex = /\b(\d+(?:\.\d+)?)\s*ms\b/i;
//     const rttMatch = line.match(safeRttRegex);
//     const ipMatch = line.match(/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/); // Finds the IP


//     if (hopMatch && rttMatch) {
//       dataPoints.push({
//         hop: hopMatch[1],
//         avgRTT: parseFloat(rttMatch[1]),
//         rtt: parseFloat(rttMatch[1]), // Highcharts needs this
//         ip: ipMatch ? ipMatch[1] : "Unknown",
//         address: ipMatch ? ipMatch[1] : "Unknown",
//       });
//     }
//   });

//   return dataPoints;
// };

// const TraceRouteOutputView = ({ output }) => {
//   // useMemo ensures we only re-parse when the text changes
//   const parsedData = useMemo(() => parseTraceTextToData(output), [output]);
// console.log(parsedData,"parsedData");

//   return (
//     <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
//        <Box>
//         <ThemeProvider theme={blackConsoleTheme}>
//           <TextField
//             multiline
//             fullWidth
//             value={output || ""}
//             InputLabelProps={{ shrink: true }}
//             //placeholder="Waiting for traceroute data..."
//             slotProps={{
//               input: {
//                 readOnly: true,
//               },
//             }}
//             maxRows={10}
//             minRows={8}
//             variant="outlined"
//           />
//         </ThemeProvider>
//       </Box>
      
//       {/* 1. THE GRAPH SECTION: Only shows if data was successfully parsed */}
//       {parsedData.length > 0 && (
//         <Box sx={{ 
//           border: '1px solid #eee', 
//           borderRadius: '8px', 
//           p: 1, 
//           backgroundColor: 'background.paper',
//           height: '300px', // Essential: Highcharts needs a height
//           width: '100%'
//         }}>
//           <TraceRouteLineChart title="Latency per Hop (ms)" data={parsedData}   />
//         </Box>
//       )}

//       {/* 2. THE TEXT CONSOLE SECTION */}
     
//     </Box>
//   );
// };

// export default TraceRouteOutputView;