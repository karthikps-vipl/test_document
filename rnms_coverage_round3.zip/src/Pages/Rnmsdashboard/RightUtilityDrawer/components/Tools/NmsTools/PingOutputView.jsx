import React from "react";
import { Box, Typography, TextField, ThemeProvider, createTheme } from "@mui/material";

const blackConsoleTheme = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          backgroundColor: "#000000",
          "& .MuiOutlinedInput-input": { color: "#ffff", fontFamily: "Courier New" }
        }
    }
}
}
});

const PingOutputView = ({ isCorrectIp, output, status }) => {
    
    console.log("aaaaaaaaaaaaaaaa",output);
  return (
    
    <Box>
      <ThemeProvider theme={blackConsoleTheme}>
      <TextField
  multiline
  fullWidth
  // Use standard value prop
  value={output} 
  // Ensure it shows the placeholder when empty
  InputLabelProps={{ shrink: true }}
  placeholder={output }
  slotProps={{
    input: {
      readOnly: true,
    },
  }}
  maxRows={8}
  minRows={8}
  variant="outlined"
/>        {isCorrectIp && output && (
          <Box sx={{ mt: 1.5, display: "flex", alignItems: "center", gap: 1,border:'' }}>
            <Typography variant="body2" sx={{   }}>Ping Status:</Typography>
            <span style={{
              backgroundColor: status === true ? "#c2ffe2" : status === false ? "#ffe2e2" : "#ffe3d0",
              color: status === true ? "#25b670" : status === false ? "#d75961" : "#ed6c02", padding: "3px 10px", borderRadius: "14px", fontSize: "0.80rem",  
            }}>
              {status === true ? "Sucess" : status === false ? "Failed" : "Pending..."}
            </span>
          </Box>
        )}
      </ThemeProvider>
    </Box>
  );
};

export default PingOutputView;