/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : MiscPollInterval
   File Name                : MiscellaneousPollingInterval.jsx
   Author                   : SURAJ - VIPL
   Package                  : src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/MiscPollInterval/MiscellaneousPollingInterval.jsx
   Purpose                  : The purpose is to show Miscellaneous Polling Interval in IAF-NMS. 
   Created Date             : 08-04-2026
 *******************************************************************************************/
import {
  Box,
  Typography,
  CircularProgress,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import React, { useEffect, useState, useCallback } from "react";
import { miscRegex } from "@/utility/FormValidation/Regex";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog"; // Assuming this is the path
import Confirmation_icon from "@/assets/SVGIcons/Alert.svg";
import {
  FETCH_ALL_POLLING_INTERVAL,
  UPDATE_POLLING_INTERVAL,
} from "@/RestAPI/url/endpoint";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";

const UPDATE_SUCCESS = "Changes saved successfully!";

const MiscellaneousPollingInterval = ({isChildFullScreen}) => {
  const [configData, setConfigData] = useState([]);
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [helperTexts, setHelperTexts] = useState({});
  const [modifiedIds, setModifiedIds] = useState(new Set());
  const [isSaving, setIsSaving] = useState(false);
  const [isResetMode, setIsResetMode] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  // --- NEW STATE FOR YOUR CUSTOM DIALOG ---
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const getData = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await InventoryAxios(FETCH_ALL_POLLING_INTERVAL, "get");
      if (res?.data) {
        const apiData = [...res.data].sort((a, b) => a.id - b.id);
        setConfigData(apiData);
        let val = {};
        let err = {};
        let help = {};
        apiData.forEach((e) => {
          val[e.id] = e.pollingInterval;
          err[e.id] = false;
          help[e.id] = "";
        });
        setValues(val);
        setErrors(err);
        setHelperTexts(help);
        setModifiedIds(new Set());
      }
    } catch (err) {
      console.error("Failed to fetch the data", err);
      Toast("Error", "Failed to fetch the data", "error");
    } finally {
      setIsLoading(false); // Stop loading regardless of success/fail
    }
  }, []);

  useEffect(() => {
    getData();
  }, [getData]);

  // --- MODIFIED: Trigger Dialog instead of immediate reset ---
  const handleResetToggle = (e) => {
    const checked = e.target.checked;
    if (checked) {
      setShowResetConfirm(true); // Open your custom MDialog
    } else {
      setIsResetMode(false); // Just uncheck if they uncheck the box
    }
  };

  // --- NEW: The logic that runs ONLY when user clicks "Confirm" in MDialog ---
  const handleConfirmReset = () => {
    const defaultVals = {};
    const newModifiedIds = new Set();
    const cleanErrors = {};
    const cleanHelpers = {};

    configData.forEach((field) => {
      defaultVals[field.id] = field.defaultValue;
      newModifiedIds.add(field.id);
      cleanErrors[field.id] = false;
      cleanHelpers[field.id] = "";
    });

    setValues(defaultVals);
    setModifiedIds(newModifiedIds);
    setErrors(cleanErrors);
    setHelperTexts(cleanHelpers);
    setIsResetMode(true);
    setShowResetConfirm(false); // Close Dialog

    Toast(
      "Info",
      "Values reset to default. Click 'Update' to save changes.",
      "info"
    );
  };

  const validate = (id, value, min, max) => {
    if (
      value === undefined ||
      value === null ||
      value.toString().trim() === ""
    ) {
      updateError(id, true, `Required (${min}-${max})`);
      return true;
    }
    if (!miscRegex.numeric.test(value)) {
      updateError(id, true, `Invalid format. Only numbers allowed`);
      return true;
    }
    const num = Number(value);
    if (num < min || num > max) {
      updateError(id, true, `Must be between ${min} - ${max}`);
      return true;
    } else {
      updateError(id, false, "");
      return false;
    }
  };

  const updateError = (id, err, msg) => {
    setErrors((prev) => ({ ...prev, [id]: err }));
    setHelperTexts((prev) => ({ ...prev, [id]: msg }));
  };

  // const handleChange = (id, value, min, max) => {
  //   if (value === "" || /^[0-9]*\.?[0-9]*$/.test(value)) {
  //     setValues((prev) => ({ ...prev, [id]: value }));
  //     setModifiedIds((prev) => new Set(prev).add(id));
  //     validate(id, value, min, max);
  //   }
  // };
  const handleChange = (id, value, min, max) => {
    // Fix ReDoS: Linear evaluation pattern
    if (value === "" || /^\d*(?:\.\d*)?$/.test(value)) {
      setValues((prev) => ({ ...prev, [id]: value }));
      setModifiedIds((prev) => new Set(prev).add(id));
      validate(id, value, min, max);
    }
  };
  const handleSubmit = async () => {
    if (modifiedIds.size === 0) {
      Toast("Info", "No changes to save", "info");
      return;
    }
    let hasError = false;
    const payloadArray = [];
    modifiedIds.forEach((id) => {
      const field = configData.find((f) => f.id === id);
      if (field) {
        const isInvalid = validate(id, values[id], field.min, field.max);
        if (isInvalid) {
          hasError = true;
        } else {
          payloadArray.push({
            id: id,
            pollingInterval: Number(values[id]),
          });
        }
      }
    });
    if (hasError) {
      Toast("Error", "Please fix the errors before saving", "error");
      return;
    }
    setIsSaving(true);
    try {
      await InventoryAxios(UPDATE_POLLING_INTERVAL, "post", payloadArray);
      Toast("Success", UPDATE_SUCCESS, "success");
      setIsResetMode(false);
      await getData();
    } catch (err) {
      console.error("Failed to update configuration", err);
      Toast("Error", "Failed to update configuration", "error");
    } finally {
      setIsSaving(false);
    }
  };

  const hasAnyErrors = Object.values(errors).some((err) => err === true);
  const isSaveDisabled = modifiedIds.size === 0 || hasAnyErrors || isSaving;

  return (
    <MForm title="Miscellaneous Polling Interval">
      <Box sx={{ position: "relative" }}>
        {isLoading && (
          <Box
            sx={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "rgba(255, 255, 255, 0.7)",
              zIndex: 10,
              borderRadius: "10px",
            }}
          >
            <CircularProgress size={40} />
            <Typography sx={{ mt: 1, color: "#14348D", fontWeight: 500 }}>
              Loading data...
            </Typography>
          </Box>
        )}
  
        {/* Grid Container */}
        <Box className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2 items-center">
          {configData.map((field) => (
            <FormField
              key={field.id}
              label={field.label}
              required={true}
              disabled={isLoading}
              error={errors[field.id]}
              // If the field type is select, use MSelect as per your instruction, 
              // otherwise use the standard input props
              {...(field.type === 'select' 
                ? { 
                    select: true, 
                    value: values[field.id] ?? "", 
                    onChange: (e) => handleChange(field.id, e.target.value, field.min, field.max),
                    SelectProps: { native: false } 
                  } 
                : { 
                    value: values[field.id] ?? "", 
                    onChange: (e) => handleChange(field.id, e.target.value, field.min, field.max),
                    helperText: helperTexts[field.id]
                  }
              )}
            />
          ))}
        </Box>
  
        {/* Reset Checkbox */}
        <Box sx={{ display: "flex", justifyContent: "flex-start", mt: 1 }}>
          <FormControlLabel
            control={
              <Checkbox
                checked={isResetMode}
                onChange={handleResetToggle}
                color="primary"
                disabled={isLoading}
              />
            }
            label={<Typography>Reset to Default</Typography>}
          />
        </Box>
  
        <MDialog
          open={showResetConfirm}
          variant="info"
          icon={Confirmation_icon}
          title="Reset"
          message="Are you sure you want to reset all polling intervals to their default values?"
          onConfirm={handleConfirmReset}
          onClose={() => {
            setShowResetConfirm(false);
            setIsResetMode(false);
          }}
          mode="child"
          isChildFullScreen={isChildFullScreen}
        />
  
        {/* Action Buttons */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 2,
            pt: 2,
          }}
        >
          <MButtonPrimary
            variant="contained"
            color="primary"
            startIcon={isSaving && <CircularProgress size={20} color="inherit" />}
            disabled={isSaveDisabled}
            onClick={handleSubmit}
            sx={{ px: 5 }}
          >
            {isSaving ? "Updating..." : "Update"}
          </MButtonPrimary>
        </Box>
      </Box>
    </MForm>
  );
};

export default MiscellaneousPollingInterval;
