/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DeviceThresholdSetting
   File Name                : ToolsThresholdUpdate.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Tools\DeviceThresholdSetting\ToolsThresholdUpdate.jsx
   Purpose                  : The purpose is to show Threshold settings in IAF-NMS. 
   Created Date             : 08-04-2026
 *******************************************************************************************/
import React, { useEffect, useState, useMemo } from "react";
import {
  Box,
  Typography,
  Radio,
  RadioGroup,
  FormControlLabel,
  CircularProgress,
} from "@mui/material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_DEVICE_SETTING_BASED_ON_TERMINAL_TYPE,
  UPDATE_DEVICE_SETTINGS,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import { createDynamicSchema } from "@/utility/FormValidation/YupSchema";
import { miscRegexNumeric } from "@/utility/FormValidation/Regex";
import { useSelector } from "react-redux";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";

const ThresholdUpdate = () => {
  const { siteDetails } = useSelector((state) => state.nodeDetails);
  const terminalId = siteDetails.id; //fetching terminalId from the siteDetails via redux
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [deviceSettings, setDeviceSettings] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [helperTexts, setHelperTexts] = useState({});
  const [modifiedFields, setModifiedFields] = useState(new Set());

  // Generate Schema dynamically whenever settings or selection changes
  const validationSchema = useMemo(() => {
    const device = deviceSettings.find((d) => d.id === selectedDeviceId);
    return device ? createDynamicSchema(device.deviceData) : null;
  }, [deviceSettings, selectedDeviceId]);

  useEffect(() => {
    fetchDeviceSettings();
  }, [terminalId]);

  const fetchDeviceSettings = async () => {
    try {
      const res = await ConfigurationAxios(
        `${FETCH_ALL_DEVICE_SETTING_BASED_ON_TERMINAL_TYPE}/${terminalId}`,
        "get"
      );
      if (res.data?.length) {
        setDeviceSettings(res.data);
        setSelectedDeviceId(res.data[0].id);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to fetch device settings");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const device = deviceSettings.find((d) => d.id === selectedDeviceId);
    if (device?.deviceData) {
      const initialValues = {};
      const initialErrors = {};
      const initialHelpers = {};
      device.deviceData.forEach((field) => {
        initialValues[field.label] = field.value;
        initialErrors[field.label] = false;
        initialHelpers[field.label] = "";
      });
      setValues(initialValues);
      setErrors(initialErrors);
      setHelperTexts(initialHelpers);
      setModifiedFields(new Set());
    }
  }, [selectedDeviceId, deviceSettings]);

  const currentDeviceData =
    deviceSettings.find((d) => d.id === selectedDeviceId)?.deviceData || [];
  const currentDeviceResource = deviceSettings.find(
    (d) => d.id === selectedDeviceId
  );

  // Updated Change Handler using Regex
  const handleChange = (label, value, fieldConfig) => {
    const dataType = fieldConfig.dataType || fieldConfig.type;
    const isNumeric = dataType === "Number" || dataType === "numeric";

    if (isNumeric) {
      // Block character input that doesn't match our numeric regex
      if (value !== "" && !miscRegexNumeric.numericInput.test(value)) {
        return;
      }
    }

    setValues((prev) => ({ ...prev, [label]: value }));
    setModifiedFields((prev) => new Set(prev).add(label));

    // Immediate field-level validation
    validateField(label, value);
  };

  // Field-level validation using Yup's validateAt
  const validateField = async (label, value) => {
    if (!validationSchema) return;

    try {
      // We validate just this field against the schema
      await validationSchema.validateAt(label, { ...values, [label]: value });
      setErrors((prev) => ({ ...prev, [label]: false }));
      setHelperTexts((prev) => ({ ...prev, [label]: "" }));
    } catch (err) {
      setErrors((prev) => ({ ...prev, [label]: true }));
      setHelperTexts((prev) => ({ ...prev, [label]: err.message }));
    }
  };

  const handleSubmit = async () => {
    if (modifiedFields.size === 0) {
      Toast("Info", "No changes to save", "info");
      return;
    }

    if (!validationSchema) return;

    try {
      // Final full-form validation
      await validationSchema.validate(values, { abortEarly: false });

      setIsSaving(true);
      const payload = {};
      currentDeviceData.forEach((field) => {
        const val = values[field.label];
        const isNum = field.type === "numeric" || field.dataType === "Number";
        payload[field.label] = isNum ? Number(val) : val;
      });

      const res = await ConfigurationAxios(
        `${UPDATE_DEVICE_SETTINGS}/${terminalId}/${currentDeviceResource.resourceType.resourceTypeId}`,
        "post",
        payload
      );

      if (res.data === true || res.status === 200) {
        Toast("Success", "Device settings updated successfully", "success");
        setModifiedFields(new Set());
      } else {
        throw new Error();
      }
    } catch (err) {
      if (err.name === "ValidationError") {
        // Handle Yup Validation Errors
        const newErrors = {};
        const newHelpers = {};
        err.inner.forEach((e) => {
          newErrors[e.path] = true;
          newHelpers[e.path] = e.message;
        });
        setErrors(newErrors);
        setHelperTexts(newHelpers);
        Toast("Error", "Please fix errors before saving", "error");
      } else {
        console.error(err);
        Toast("Error", "Failed to update device settings", "error");
      }
    } finally {
      setIsSaving(false);
    }
  };

  if (loading)
    return (
      <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
        <CircularProgress size={32} color="inherit" />
      </Box>
    );
  if (error) return <Typography color="error">{error}</Typography>;
  if (!deviceSettings.length)
    return <Typography textAlign="center">No device settings found</Typography>;

  const hasAnyErrors = Object.values(errors).some((err) => err === true);
  const isSaveDisabled = modifiedFields.size === 0 || hasAnyErrors || isSaving;
  return (
    <MForm title="Device Threshold Settings">
      <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
        <Box
          className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start w-full"
        >
          {/* 1. Device Selection (Left Column) */}
          <Box className="w-full">
            <RadioGroup
              value={selectedDeviceId}
              onChange={(e) => setSelectedDeviceId(Number(e.target.value))}
            >
              {deviceSettings.map((device) => (
                <Box
                  key={device.id}
                  sx={{
                    border: "1px solid #eee",
                    borderRadius: "10px",
                    mb: 1,
                    px: 2,
                    py: 0.5,
                  }}
                >
                  <FormControlLabel
                    value={device.id}
                    control={<Radio size="small" />}
                    label={device.resourceType.resourceTypeName}
                  />
                </Box>
              ))}
            </RadioGroup>
          </Box>
  
          {/* 2. Dynamic Fields (Right Column) */}
          <Box 
            sx={{ 
              border: "1px solid #eee", 
              p: 2, 
              borderRadius: "15px", 
              width: "100%" 
            }}
          >
            {currentDeviceData.map((field, idx) => (
              <FormField
                key={idx}
                label={field.label}
                required={true}
                error={errors[field.label]}
                value={values[field.label] ?? ""}
                onChange={(e) => handleChange(field.label, e.target.value, field)}
                helperText={helperTexts[field.label]}
              />
            ))}
  
            {/* Action Button */}
            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                mt: 3,
              }}
            >
              <MButtonPrimary
                variant="contained"
                onClick={handleSubmit}
                disabled={isSaveDisabled}
                startIcon={
                  isSaving && <CircularProgress size={20} color="inherit" />
                }
                sx={{ px: 5 }}
              >
                {isSaving ? "Updating..." : "Update"}
              </MButtonPrimary>
            </Box>
          </Box>
        </Box>
      </Box>
    </MForm>
  );
  // return (
  //   <Box         sx={{
  //     border: "2px solid #eee",
   
  //     p: 2,
  //     borderRadius: "10px",
  //      width: "100%",mt:2
  //   }}>
  //     <Typography sx={{ color: "#14348D", mb: 1 }}>
  //       Device Threshold Settings
  //     </Typography>

  //     <Box sx={{ mb: 3, ml: -2, mr: -2, border: "1px solid #eee" }} />
  //     <Box
  //       className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2 items-start w-full"
  //       sx={{
  //         // border: "2px solid #eee",
        
  //         // p: 2,
  //         // borderRadius: "10px",
  //          width: "100%", 
  //       }}
  //     >
  //       <Box className="w-full">
  //         <RadioGroup
  //           value={selectedDeviceId}
  //           onChange={(e) => setSelectedDeviceId(Number(e.target.value))}
  //         >
  //           {deviceSettings.map((device) => (
  //             <Box
  //               key={device.id}
  //               className="border border-gray-300 mb-2 rounded-lg px-2"
  //             >
  //               <FormControlLabel
  //                 value={device.id}
  //                 control={<Radio size="small" />}
  //                 label={device.resourceType.resourceTypeName}
  //               />
  //             </Box>
  //           ))}
  //         </RadioGroup>
  //       </Box>
  //       <Box className="grid grid-cols-1 gap-2 border border-gray-300 p-3 rounded-xl w-full">
  //         {currentDeviceData.map((field, idx) => (
  //           <Box key={idx}>
  //             <Box
  //               sx={{
  //                 display: "flex",
  //                 flexDirection: "column",
  //                 mr: 8,
  //                  width: "100%",mt:2
  //               }}
  //             >
  //               <Typography   fontWeight={500} mb={0.5}>
  //                 {field.label}
  //                 {/* Field type and Range */}
  //                 {/* {field.type === "numeric" || field.dataType === "Number"
  //               ? `(${field.minValue} to ${field.maxValue})`
  //               : ""} */}
  //               </Typography>
  //               <MInput
  //                 fullWidth
  //                 name={field.label}
  //                 value={values[field.label] ?? ""}
  //                 error={errors[field.label]}
  //                 helperText={helperTexts[field.label]}
  //                 onChange={(e) =>
  //                   handleChange(field.label, e.target.value, field)
  //                 }
  //               />
  //             </Box>
  //           </Box>
  //         ))}
  //         <Box className="flex justify-end mt-4 pt-2   border-gray-100">
  //           <MButtonPrimary
  //             variant="contained"
  //             onClick={handleSubmit}
  //             disabled={isSaveDisabled}
  //             startIcon={
  //               isSaving && <CircularProgress size={20} color="inherit" />
  //             }
  //             sx={{ px: 5 }}
  //           >
  //             {isSaving ? "Updating..." : "Update"}
  //           </MButtonPrimary>
  //         </Box>
  //       </Box>
  //     </Box>
  //   </Box>
  // );
};

export default ThresholdUpdate;
