 
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { Box, CircularProgress,  } from "@mui/material";
import React, { useState, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { Timeout, NoOfRequests } from '@/utility/FormValidation/YupSchema';
import { GET_PING_SETTINGS, UPDATE_PING_SETTINGS } from "@/RestAPI/url/endpoint";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg"
import FormField from "@/components/Reusable/Form/FormField";
import MForm from "@/components/Reusable/Form/MForm";
const ToolsPingSettings = ({isChildFullScreen}) => {
    const [resourceId, setResourceId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isUpdating, setIsUpdating] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);

    const [apiData, setApiData] = useState({
        requestCount: '',
        timeout: '',
    });

    const formik = useFormik({
        enableReinitialize: true, 
        validateOnMount: true, 
        initialValues: apiData,
        validationSchema: Yup.object({
            requestCount: NoOfRequests,
            timeout: Timeout,
        }),
        onSubmit: (values) => {
            setShowConfirm(true);
        },
    });

    useEffect(() => {
        fetchInitialData();
    }, []);

    const fetchInitialData = async () => {
        try {
            setLoading(true);
            const response = await FaultAxios(GET_PING_SETTINGS, 'get');
            if (response.data) {
                const { timeOut, requestCount: reqCount, id } = response.data;
                setResourceId(id);
                
                setApiData({
                    requestCount: reqCount.toString(),
                    timeout: timeOut.toString(),
                });

                 
                setTimeout(() => {
                    formik.setFieldTouched('requestCount', true);
                    formik.setFieldTouched('timeout', true);
                }, 100);
            }
        } catch (error) {
            console.error("Error fetching ping settings:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleConfirmUpdate = async () => {
        try {
            setIsUpdating(true);
            const payload = {
                id: resourceId,
                timeOut: Number(formik.values.timeout),
                requestCount: Number(formik.values.requestCount),
            };
            const response = await FaultAxios(UPDATE_PING_SETTINGS, 'post', payload);
            
            if (response.data?.status === 1 || response.status === 200) {
                setShowConfirm(false);
                Toast("Success!", "Ping Settings updated successfully", "success");
                
                setApiData({
                    requestCount: formik.values.requestCount,
                    timeout: formik.values.timeout,
                });
            }
        } catch (error) {
            console.error('Error updating settings:', error);
            Toast("Error!", "Failed to update Ping Settings", "error");
        } finally {
            setIsUpdating(false);
        }
    };

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                <CircularProgress size={30} style={{ color: "#14348D" }} />
            </Box>
        );
    }

  return (
    <MForm title="Ping Settings">
    <Box className="grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-4 items-end">
    <Box  >
          <FormField
            label="Number of Requests *"
            name="requestCount"
            size="small"
            fullWidth
            placeholder="Must be within 1 - 10"
            value={formik.values.requestCount}
            error={formik.touched.requestCount && Boolean(formik.errors.requestCount)}
            errorMessage={formik.touched.requestCount && formik.errors.requestCount ? formik.errors.requestCount : ""}
            onChange={(e) => {
              const val = e.target.value;
              if (val === '' || /^[0-9\b]+$/.test(val)) {
                formik.handleChange(e);
              }
            }}
            onBlur={formik.handleBlur}
          />
        </Box>

        <Box  >
          <FormField
            label="Timeout(Sec) *"
            name="timeout"
            size="small"
            fullWidth
            placeholder="Must be with in 1 - 3"
            value={formik.values.timeout}
            error={formik.touched.timeout && Boolean(formik.errors.timeout)}
            errorMessage={formik.touched.timeout && formik.errors.timeout ? formik.errors.timeout : ""}
            onChange={(e) => {
              const val = e.target.value;
              if (val === '' || /^[0-9\b]+$/.test(val)) {
                formik.handleChange(e);
              }
            }}
            onBlur={formik.handleBlur}
          />
        </Box>

        <MButtonPrimary
        disabled={!formik.isValid || !formik.dirty || isUpdating}
        onClick={formik.handleSubmit}
        sx={{ width: { xs: '100%', md: 'auto' } }} // Full width on mobile, auto on desktop
      >
        {isUpdating ? "Updating..." : "Update"}
      </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to update the Ping Settings?"
        onConfirm={handleConfirmUpdate}
        onClose={() => setShowConfirm(false)}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </MForm>
  );

  
};

export default ToolsPingSettings;
