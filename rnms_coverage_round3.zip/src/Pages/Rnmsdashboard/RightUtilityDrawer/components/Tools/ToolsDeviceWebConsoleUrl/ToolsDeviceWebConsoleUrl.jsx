import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MInput from "@/components/Reusable/Input/MInput";
import MSelect from "@/components/Reusable/Select/MSelect";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_MASTER_TYPES_BASED_ON_WEB_CONFIG_FOR_GIVEN_TERMINAL_ID,
  SAVE_RESOURCE_MASTER_DATA_CONFIGURATION,
} from "@/RestAPI/url/endpoint";
import {
  Box,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MForm from "@/components/Reusable/Form/MForm";

const ToolsDeviceWebConsoleUrl = ({isChildFullScreen}) => {
  const [loading, setLoading] = useState(false);
  const [resources, setResources] = useState([]);
  const [selectedResource, setSelectedResource] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  // Add this to your existing useState declarations
  const [isDirty, setIsDirty] = useState(false);

  const [isWebReadOnly, setIsWebReadOnly] = useState(false);
  const [resourceBool, setResourceBool] = useState({
    configured: false,
    status: false,
    telnet: false,
    ssh: false,
    web: false,
    syslog: false,
    webUrl: "",
    backUp: false,
    upload: false,
  });

  const [webUrlParts, setWebUrlParts] = useState({
    header: "http://",
    endpoint: "",
  });

  const { siteDetails } = useSelector((state) => state.nodeDetails);
  const terminalId = siteDetails?.id;

  const isAlphaOnly = (val) => /^[a-zA-Z0-9/._-]*$/.test(val);

  const interfaceOptions = [
    { id: "http://", label: "http://" },
    { id: "https://", label: "https://" },
  ];

  useEffect(() => {
    const fetchData = async () => {
      if (!terminalId) return;
      try {
        const response = await InventoryAxios(
          `${FETCH_MASTER_TYPES_BASED_ON_WEB_CONFIG_FOR_GIVEN_TERMINAL_ID}/${terminalId}`,
          "get"
        );
        const filterdata = response?.data.filter((item,index,self)=>
        index === self.findIndex(obj => obj.resourceTypeName === item.resourceTypeName)
        );
        const data = filterdata.map((item, index) => ({
          id: `${item.resourceTypeId}-${index}`,
          value: item,
          label: item.resourceNickName,
        }));
        setResources(data);
      } catch (error) {
        Toast("Error!", "Failed to fetch device list", "error");
        console.error(error);
      }
    };
    fetchData();
  }, [terminalId]);

  const handleResourceSelect = (option) => {
    if (option) {
      setSelectedResource(option);
      const config = option.value?.data || {};
    
      // If config.web is true, we lock the checkbox so user can't uncheck it via UI
      // If you want the user to be able to toggle it, remove this logic
      const isWebEnabledByApi = !!config.web;
      setIsWebReadOnly(isWebEnabledByApi);

      setResourceBool({
        ...config,
        web: config.web || false,
      });

      // Parse URL parts
      if (config.webUrl && config.webUrl.includes("deviceIpAddress")) {
        const parts = config.webUrl.split("deviceIpAddress");
        setWebUrlParts({
          header: parts[0] || "http://",
          endpoint: parts[1] || "",
        });
      } else {
        setWebUrlParts({ header: "http://", endpoint: "" });
      }
    } else {
      setSelectedResource(null);
      setIsWebReadOnly(false);
      setResourceBool({ configured: false, web: false });
    }
  };

  const handleHeaderChange = (val) => {
    setIsDirty(true);
    setWebUrlParts((prev) => ({ ...prev, header: val }));
    setResourceBool((prev) => ({
      ...prev,
      webUrl: `${val}deviceIpAddress${webUrlParts.endpoint}`,
    }));
  };

  const handleEndpointChange = (val) => {
    if (isAlphaOnly(val)) {
      setIsDirty(true);
      setWebUrlParts((prev) => ({ ...prev, endpoint: val }));
      setResourceBool((prev) => ({
        ...prev,
        webUrl: `${webUrlParts.header}deviceIpAddress${val}`,
      }));
    }
  };

  const handleCheckboxChange = (checked) => {
    // If it's read-only, we don't allow the change
    if (isWebReadOnly) return;
    setIsDirty(true);
    setResourceBool((prev) => ({ ...prev, web: checked }));
  };

  const handleUpdateClick = () => {
    if (!selectedResource) return;
    setShowConfirm(true); // This triggers the dialog
  };

  const handleConfirmUpdate = async () => {
    setShowConfirm(false);
    try {
      setLoading(true);
      const resourceTypeId = selectedResource.value.resourceTypeId;
      const payload = { ...resourceBool, configured: true };
      const response = await InventoryAxios(
        `${SAVE_RESOURCE_MASTER_DATA_CONFIGURATION}/${resourceTypeId}`,
        "post",
        payload
      );
      if (response) {
        Toast("Success!", "Configuration updated successfully", "success");
      }
    } catch (error) {
      Toast("Error!", "Failed to update configuration", "error");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  // Update this line near the bottom of your component
  const isButtonDisabled = loading || !selectedResource || !isDirty;
  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (resources.length === 0 && !loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
        <Typography color="text.secondary">No device types found.</Typography>
      </Box>
    );
  }
return (
  <MForm title="Device Web Console URL">
    <Box sx={{ position: "relative" }}>
      <Box sx={{ display: "flex", width: "100%", flexDirection: "column", gap: 2 }}>
        {/* 1. Device Selection */}
        <Box sx={{ width: "50%" }}>
          <Typography sx={{ mb: 0.5 }}>Device Type</Typography>
          <MSelect
            options={resources}
            value={selectedResource}
            getOptionLabel={(opt) => opt.label}
            getOptionValue={(opt) => opt.id}
            onChange={handleResourceSelect}
            placeholder="Select Device"
          />
        </Box>

        {/* 2. Cross Launch Checkbox */}
        <Box sx={{ display: "flex", justifyContent: "flex-start" }}>
          <FormControlLabel
            control={
              <Checkbox
                color="primary"
                checked={resourceBool.web}
                disabled={!selectedResource || isWebReadOnly}
                onChange={(e) => handleCheckboxChange(e.target.checked)}
              />
            }
            label={
              <Typography
                sx={{
                  color: !selectedResource || isWebReadOnly ? "text.disabled" : "text.primary",
                  fontWeight: !selectedResource ? 400 : "medium",
                }}
              >
                Cross Launch
              </Typography>
            }
          />
        </Box>

        {resourceBool.web && (
          <Box sx={{ borderRadius: "6px" }}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                gap: 1,
                alignItems: "flex-end",
              }}
            >
              <Typography sx={{ mb: 1 }}>URL :</Typography>
              <Box sx={{ flex: 1 }}>
                <MSelect
                  options={interfaceOptions}
                  value={webUrlParts.header}
                  getOptionLabel={(opt) => opt.label}
                  getOptionValue={(opt) => opt.id}
                  onChange={(val) => handleHeaderChange(val)}
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <MInput readOnly={true} value="deviceIpAddress" />
              </Box>
              <Box sx={{ flex: 1 }}>
                <MInput
                  placeholder="/path/to/resource"
                  value={webUrlParts.endpoint}
                  onChange={(e) => handleEndpointChange(e.target.value)}
                />
              </Box>
              <Box>
                <MButtonPrimary
                  onClick={handleUpdateClick}
                  disabled={isButtonDisabled}
                  sx={{ height: "40px" }}
                >
                  {loading ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : (
                    "Update"
                  )}
                </MButtonPrimary>
              </Box>
            </Box>
          </Box>
        )}
      </Box>

      {/* Confirmation Dialog */}
      <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to update the Site Details?"
        onConfirm={handleConfirmUpdate}
        onClose={() => setShowConfirm(false)}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </Box>
  </MForm>
);
 
};

export default ToolsDeviceWebConsoleUrl;
