
import React, { useEffect, useState } from 'react';
import {
    Box,
    Typography,
    Radio,
    Switch,
    FormControl,
    RadioGroup,
    FormControlLabel,
    CircularProgress
} from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup'; // Keep this if you need Yup.object()
import MButtonPrimary from '@/components/Reusable/Button/MButtonPrimary';
import MSelect from '@/components/Reusable/Select/MSelect';
import {
    FETCH_ALL_SERIAL_DEVICE_COMM_CONFIGURATION_DATA,
    GET_COM_PORTLIST,
    MODIFY_SERIAL_DEVICE_CONFIGURATION_DATA
} from '@/RestAPI/url/endpoint';
import { TopologyAxios } from '@/RestAPI/api/axiosApicall';

// 1. Import the specific validators from your file
import { BaudRate, DataRate, StopBits } from '@/utility/FormValidation/YupSchema';
import Toast from '@/components/Reusable/Toast/Toast';
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg"
import MDialog from '@/components/Reusable/Dialog/MDialog';
import MForm from '@/components/Reusable/Form/MForm';
import FormField from '@/components/Reusable/Form/FormField';

/* ---------------- COMPONENT ---------------- */
const ToolsSerialPortConfig = () => {
    const [devices, setDevices] = useState([]);
    const [portOptions, setPortOptions] = useState([]);
    const [loading, setLoading] = useState(false);
    const [originalDeviceData, setOriginalDeviceData] = useState(null);
    const [showConfirm, setShowConfirm] = useState(false);


    // 2. Define the schema using the imported validators
    const validationSchema = Yup.object({
        datarate: DataRate,
        baudrate: BaudRate,
        stopbits: StopBits,
        portname: Yup.string().required("Port is required"),
        parity: Yup.number().required("Parity is required"),
        flowcontrol: Yup.string().required("Flow control is required")
    });
    useEffect(() => {
        const fetchDevices = async () => {
            try {
                setLoading(true);
                // Replace with your actual GET URL
                const response = await TopologyAxios(FETCH_ALL_SERIAL_DEVICE_COMM_CONFIGURATION_DATA, "get");
                const data = response.data;

                // IMPORTANT: Save the WHOLE object here
                setOriginalDeviceData(data);

                // 3. Populate Formik with the values needed for the UI
                formik.setValues({
                    id: data.id || "",
                    portname: data.portname || "",
                    baudrate: data.baudrate || "",
                    datarate: data.datarate || "",
                    stopbits: data.stopbits || "",
                    parity: data.parity || "",
                    flowcontrol: data.flowcontrol === 1 ? "rtc" : "none", // Map 1 to "rtc" for the dropdown
                    rtsstate: data.rtsstate || false,
                    dtrstate: data.dtrstate || false
                });
            } catch (err) {
                console.error("Failed to load initial data", err);
            } finally {
                setLoading(false);
            }
        };

        fetchDevices();
    }, []);
    /* ---------------- FORMIK ---------------- */
    const formik = useFormik({
        initialValues: {
            id: "",
            baudrate: "",
            datarate: "",
            portname: "",
            stopbits: "",
            parity: "",
            flowcontrol: "",
            dtrstate: false,
            rtsstate: false
        },
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            setLoading(true);
            try {
                const deviceToUpdate = originalDeviceData.find(device => device.id === Number(values.id));

                if (!deviceToUpdate) {
                    throw new Error("Device not found in original data");
                }

                const fullPayload = {
                    ...deviceToUpdate
                };

                fullPayload.id = Number(values.id);
                fullPayload.portname = String(values.portname);
                fullPayload.baudrate = Number(values.baudrate);
                fullPayload.datarate = Number(values.datarate);
                fullPayload.stopbits = Number(values.stopbits);
                fullPayload.parity = Number(values.parity);
                fullPayload.flowcontrol = values.flowcontrol === "rtc" ? 1 : 2;
                fullPayload.rtsstate = Boolean(values.rtsstate);
                fullPayload.dtrstate = Boolean(values.dtrstate);

                console.log("SENDING ONLY THE TARGET OBJECT:", fullPayload);
                await TopologyAxios(MODIFY_SERIAL_DEVICE_CONFIGURATION_DATA, "post", fullPayload);
                Toast("Success!", "Successfully saved serial port configuration", "success");
            } catch (err) {
                console.error("API Error:", err.response?.data || err.message);
            } finally {
                setLoading(false);
                setShowConfirm(false);
            }
        }
    });

    const isDisabled = !formik.values.id;


    useEffect(() => {
        const fetchDevices = async () => {
            try {
                const res = await TopologyAxios(
                    FETCH_ALL_SERIAL_DEVICE_COMM_CONFIGURATION_DATA,
                    "get",
                    1
                );

                if (Array.isArray(res?.data)) {
                    setDevices(res.data);
                }
            } catch (err) {
                console.error(err);
            }
        };

        fetchDevices();
    }, []);

    /* ---------------- FETCH PORTS ---------------- */

    useEffect(() => {
        const fetchPorts = async () => {
            try {
                const res = await TopologyAxios(GET_COM_PORTLIST, "get");

                if (Array.isArray(res?.data)) {
                    setPortOptions(
                        res.data.map(p => ({ label: p, value: p }))
                    );
                }
            } catch (err) {
                console.error(err);
            }
        };

        fetchPorts();
    }, []);

    /* ---------------- DEVICE SELECT ---------------- */

    const handleDeviceSelect = (option) => {
        const device = devices.find(
            d => String(d.id) === String(option?.value)
        );

        if (!device) return;

        formik.setValues({
            id: device.id,
            baudrate: device.baudrate ?? "",
            datarate: device.datarate ?? "",
            portname: device.portname ?? "",
            stopbits: device.stopbits ?? "",
            parity: device.parity ?? "",
            flowcontrol: device.flowcontrol === 1 ? "rtc" : "dtr",
            dtrstate: Boolean(device.dtrstate),
            rtsstate: Boolean(device.rtsstate)
        });
    };

    /* ---------------- HELPERS ---------------- */

    const handleInputChange = (e, field) => {
        formik.setFieldValue(field, e.target.value);
    };

    const showError = (field) =>
        formik.touched[field] && formik.errors[field]
            ? formik.errors[field]
            : "";

    /* ---------------- OPTIONS ---------------- */

    const deviceOptions = devices.map(d => ({
        label:
            d.imResourceInfo?.resourceName ||
            d.imResourceInfo?.resourceDesc ||
            "Unknown Device",
        value: d.id
    }));
    const handleConfirmUpdate = () => {
        formik.handleSubmit();
    };
    /* ---------------- UI ---------------- */
    const handleOpenConfirm = () => {
        // Only open if form is valid and dirty
        if (formik.isValid && formik.dirty) {
            setShowConfirm(true);
        } else {
            // If not valid/dirty, try to submit to trigger validation errors
            formik.handleSubmit();
        }
    };
    if (loading) {
        return (
            <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
                <CircularProgress />
            </Box>
        );
    }
    
    if (devices.length === 0) {
        return (
            <Box sx={{ display: "flex", justifyContent: "center", p: 5 }}>
                <Typography color="text.secondary">No serial devices found.</Typography>
            </Box>
        );
    }
return (
    <MForm title="Serial Port Configuration">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                    <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>Device List</Typography>
                    <MSelect
                        options={deviceOptions}
                        value={formik.values.id}
                        onChange={handleDeviceSelect}
                        placeholder="Select Device List"
                    />
                </Box>
                {/* DATA RATE */}
                <Box sx={{ flex: 1 }}>
                    <FormField
                        label="Data Rate "
                        required
                        disabled={isDisabled}
                        value={formik.values.datarate}
                        placeholder="Data Rate"
                        error={showError("datarate")}
                        onChange={(e) => {
                            e.target.value = e.target.value.replace(/\D/g, '');
                            handleInputChange(e, "datarate");
                        }}
                        onBlur={() => formik.setFieldTouched("datarate", true)}
                        inputProps={{
                            pattern: '[0-9]*',
                            inputMode: 'numeric'
                        }}
                    />
                </Box>
            </Box>

            {/* PORT */}
            <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                    <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>Port Name</Typography>
                    <MSelect
                        placeholder="Select Port Name"
                        options={portOptions}
                        value={formik.values.portname}
                        disabled={isDisabled}
                        onChange={(opt) =>
                            formik.setFieldValue("portname", opt.value)
                        }
                    />
                </Box>
                {/* STOP BITS */}
                <Box sx={{ flex: 1 }}>
                    <FormField
                        label="Stop Bits "
                        required
                        disabled={isDisabled}
                        value={formik.values.stopbits}
                        placeholder="Stop Bits"
                        error={showError("stopbits")}
                        onChange={(e) => {
                            e.target.value = e.target.value.replace(/\D/g, '');
                            handleInputChange(e, "stopbits");
                        }}
                        onBlur={() => formik.setFieldTouched("stopbits", true)}
                        inputProps={{
                            pattern: '[0-9]*',
                            inputMode: 'numeric'
                        }}
                    />
                </Box>
            </Box>

            {/* PARITY */}
            <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                    <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>Parity *</Typography>
                    <MSelect
                        placeholder="Parity"
                        options={[
                            { label: "None", value: 0 },
                            { label: "Even", value: 1 },
                            { label: "Odd", value: 2 }
                        ]}
                        value={formik.values.parity}
                        disabled={isDisabled}
                        onChange={(opt) =>
                            formik.setFieldValue("parity", opt.value)
                        }
                    />
                </Box>
                <Box sx={{ flex: 1 }}>
                    <FormField
                        label="Baud Rate "
                        required
                        disabled={isDisabled}
                        value={formik.values.baudrate}
                        placeholder="Baud Rate"
                        error={showError("baudrate")}
                        onChange={(e) => {
                            e.target.value = e.target.value.replace(/\D/g, '');
                            handleInputChange(e, "baudrate");
                        }}
                        onBlur={() => formik.setFieldTouched("baudrate", true)}
                        inputProps={{
                            pattern: '[0-9]*',
                            inputMode: 'numeric'
                        }}
                    />
                </Box>
            </Box>

            {/* FLOW CONTROL */}
            <Box sx={{ display: 'flex', flexDirection: 'row', gap: 3, width: '100%', alignItems: 'center' }}>
                <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>Flow Control:</Typography>
                <Box sx={{ flex: 1 }}>
                    <FormControl>
                        <RadioGroup
                            row
                            value={formik.values.flowcontrol}
                            onChange={(e) =>
                                formik.setFieldValue(
                                    "flowcontrol",
                                    e.target.value
                                )
                            }
                        >
                            <FormControlLabel
                                value="rtc"
                                control={<Radio disabled={isDisabled} />}
                                label="RTC/TCS"
                            />
                            <FormControlLabel
                                value="dtr"
                                control={<Radio disabled={isDisabled} />}
                                label="DTR/DCS"
                            />
                        </RadioGroup>
                    </FormControl>
                </Box>
                {/* SWITCHES */}
                <Box sx={{ flex: 1.5, display: 'flex', gap: 2, alignItems: 'center' }}>
                    <Typography variant="body2" sx={{ fontFamily: "Montserrat" }}>RTS State</Typography>
                    <Switch
                        checked={formik.values.rtsstate}
                        disabled={isDisabled}
                        onChange={(e) =>
                            formik.setFieldValue("rtsstate", e.target.checked)
                        }
                    />
                    <Switch
                        checked={formik.values.dtrstate}
                        disabled={isDisabled}
                        onChange={(e) =>
                            formik.setFieldValue("dtrstate", e.target.checked)
                        }
                    />
                </Box>
            </Box>

            {/* SAVE */}
            <Box mt={0} display="flex" justifyContent="flex-end">
                <MButtonPrimary onClick={handleOpenConfirm} disabled={!formik.dirty || !formik.isValid || formik.isSubmitting}>
                    {loading ? (
                        <CircularProgress size={20} color="inherit" />
                    ) : (
                        "Save"
                    )}
                </MButtonPrimary>
            </Box>
        </Box>

        <MDialog
            open={showConfirm}
            variant="info"
            icon={confirmation_icon}
            title="Confirm Action"
            message="Are you sure you want to update the device web console url?"
            onConfirm={handleConfirmUpdate}
            onClose={() => setShowConfirm(false)}
            mode='child'
        />
    </MForm>
);
 
 
};

export default ToolsSerialPortConfig;