import MTable from "@/components/Reusable/Table/MTable";
import { Box } from "@mui/material";
import React from "react";
import { useSelector } from "react-redux";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";

const LastDiscoverdIp = ({ privilegeKey }) => {
  const resources = useSelector((state) => state.inventory.resources);
  const columns = [
    { name: "S. No", uid: "sno", width: "70px" },
    { name: "Name", uid: "resourceName", width: "250px" },
    { name: "IP Address", uid: "resourceIp", width: "120px" },
    { name: "Firmware", uid: "firmwareVersion", width: "120px" },
    { name: "Serial No", uid: "resourceSerialno", width: "120px" },
    { name: "Time", uid: "timestamp", width: "170px" },
    { name: "Mode", uid: "discoveryMode", width: "100px" },
    { name: "Status Message", uid: "discoveredstatusMessage" },
    { name: "Status", uid: "status", width: "90px" },
  ];
  const formattedData =
    resources?.length > 0
      ? resources.map((item) => {
          const newItem = { ...item };

          // Handle N/A
          columns.forEach((col) => {
            const key = col.uid;
            if (
              newItem[key] === undefined ||
              newItem[key] === null ||
              newItem[key] === ""
            ) {
              newItem[key] = "N/A";
            }
          });

          // Handle Status Colors (for the UI)
          if (newItem.status === "Success") {
            newItem.status = <span style={{ color: "green" }}>Success</span>;
          } else if (newItem.status === "Failed") {
            newItem.status = <span style={{ color: "#e75656" }}>Failed</span>;
          }

          return newItem;
        })
      : [];
  const cleanExportData = resources?.map((item) => {
    const cleanItem = { ...item };
    columns.forEach((col) => {
      const key = col.uid;
      if (
        cleanItem[key] === undefined ||
        cleanItem[key] === null ||
        cleanItem[key] === ""
      ) {
        cleanItem[key] = "N/A";
      }
    });
    // Ensure status is just the text "Success" or "Failed" for the file
    if (cleanItem.status === "Success") cleanItem.status = "Success";
    if (cleanItem.status === "Failed") cleanItem.status = "Failed";
    return cleanItem;
  });

  return (
    <Box  >

      <MTable
        privilegeKey={privilegeKey}
        // tableTitle="Last Discoverd Status"
        columns={columns}
        tableData={formattedData}
        showPagination={true}
        showSearch={true}
        handleDownloadPDF={() =>
          exportToPDF(
            "Last Discovered ip Report",
            columns,
            cleanExportData,
            "Last_Discovered_ip_Report"
          )
        }
        handleDownloadCSV={() =>
          exportToCSV("Last_Discovered_ip_Export", columns, cleanExportData)
        }
      />
    </Box>
  );
};

export default LastDiscoverdIp;
