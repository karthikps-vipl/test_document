import MDialog from "@/components/Reusable/Dialog/MDialog";
import MTable from "@/components/Reusable/Table/MTable";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_FOREIGN_IP_DETAIL_URL,
  REMOVE_FOREIGN_IP_URL,
} from "@/RestAPI/url/endpoint";
import { Box, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  exportToCSV,
  exportToPDF,
} from "@/components/Reusable/Pdf/downloadPdf";

const ForiegnIp = ({
  refreshTrigger,
  privilegeKey,
 
  onRefresh,isChildFullScreen
}) => {
  const [loading, setLoading] = useState(false);
  const [removing, setRemoving] = useState(false); // Track if delete API is running
  const [foriegnIp, setforiegnIp] = useState([]);
  const [selectedRowsNew, setSelectedRowsNew] = useState(new Set());
  const [showConfirm, setShowConfirm] = useState(false);

  const columns = [
    { name: "S. No ", uid: "sno", width: "70px" },
    { name: "IP Address", uid: "ipAddress", width: "150px" },
    { name: "Type", uid: "type" },
  ];

  useEffect(() => {
    const fetchForiegnIP = async () => {
      setLoading(true);
      try {
        const response = await TopologyAxios(
          FETCH_ALL_FOREIGN_IP_DETAIL_URL,
          "get"
        );
        const foriegnIpData = response?.data || [];
       
        const processedData = foriegnIpData.map((r, index) => {
          const ensureString = (val, fallback) => {
            if (val === null || val === undefined) return fallback;
            if (typeof val === "object")
              return val.ipAddress || val.name || val.value;
            return val;
          };

          return {
            ...r,
            id: r.id || r.ipAddress || index,
            sno: index + 1,
            ipAddress: ensureString(r.ipAddress, "NA"),
            type: ensureString(r.type?.resourceTypeName, "Unknown"),
          };
        });

        setforiegnIp(processedData);
      } catch (error) {
        console.error("Foriegn IP Fetch Error:", error);
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchForiegnIP();
  }, [refreshTrigger]);

  // STEP 1: Triggered by the "Remove Ip" button in MTable
  const handleOpenConfirmDialog = () => {
    if (selectedRowsNew.size === 0) return;
    setShowConfirm(true);
  };

  // STEP 2: Triggered by the "Confirm" button inside MDialog

  const handleConfirmRemove = async () => {
    setShowConfirm(false);
    try {
      setRemoving(true);  
      const payload = Array.from(selectedRowsNew);
      const response = await TopologyAxios(
        REMOVE_FOREIGN_IP_URL,
        "post",
        payload
      );

      if (response) {
        Toast("Success!", "Foreign IP removed successfully", "success");
        if (typeof onRefresh === "function") {
          onRefresh();
        } else {
          console.error("onRefresh is NOT a function! Check the Drawer props.");
        }
        
        setSelectedRowsNew(new Set());

        
      }
    } catch (error) {
      Toast("Error!", "Failed to remove Foreign IP", "error");
      console.error(error)
    } finally {
      setRemoving(false); 
    }
  };

  const handleRowSelect = (id, isSelected) => {
    const newSelection = new Set(selectedRowsNew);
    if (isSelected) {
      newSelection.add(String(id));
    } else {
      newSelection.delete(String(id));
    }
    setSelectedRowsNew(newSelection);
  };

  const handleSelectAll = (isSelected) => {
    if (isSelected) {
      const allIds = foriegnIp.map((item) => String(item.id));
      setSelectedRowsNew(new Set(allIds));
    } else {
      setSelectedRowsNew(new Set());
    }
  };

  return (
    <Box  >
      {loading ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <MTable
          privilegeKey={privilegeKey}
          //tableTitle="Foriegn IP"
          columns={columns}
          tableData={foriegnIp}
          showPagination={true}
          enableRowSelection={true}
          selectedRowsNew={selectedRowsNew}
          onRowSelect={handleRowSelect}
          onSelectAll={handleSelectAll}
          rowIdKey="id"
          showRemove={true}
          removeText="Remove IP"
          showSearch={true}
          handleDownloadPDF={() =>
            exportToPDF(
              "Foriegn IP Report",
              columns,
              foriegnIp,
              "foriegnIp_Details_Report"
            )
          }
          handleDownloadCSV={() =>
            exportToCSV("Foriegn_IP_Details_Export", columns, foriegnIp)
          }
          // NEW PROPS FOR MTable (Ensure your MTable component uses these)
          onRemoveClick={handleOpenConfirmDialog}
          // Disable button if nothing is selected OR if an API call is already in progress
          isRemoveDisabled={selectedRowsNew.size === 0 || removing}
          refreshTrigger={refreshTrigger}
        />
      )}
      <MDialog
        open={showConfirm}
        variant="error"
        title="Confirm Removal"
        icon={question_mark}
        message={`Are you sure you want to remove ${selectedRowsNew.size} selected IP(s)?`}
        onConfirm={handleConfirmRemove}
        onClose={() => setShowConfirm(false)}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
    </Box>
  );
};

export default ForiegnIp;
