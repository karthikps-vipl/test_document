
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MInput from "@/components/Reusable/Input/MInput";
import { Box, CircularProgress, Typography } from "@mui/material";

import React, { useEffect, useState } from "react";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MSelect from "@/components/Reusable/Select/MSelect";
import {
  DO_SNMP_GET,
  FETCH_RESOURCE_INFO_BY_RESOURCE_TYPE_ID,
  FETCH_RESOURCE_MASTER_TYPE_DETAILS_BY_PROTOTYPE_ID,
  UPDATE_ENTERPRISE_OID_OF_RESMASTERTYPE_BY_RESOURCE_ID_URL,
  UPDATE_SYS_OID_OF_RESMASTERTYPE_BY_RESOURCE_ID_URL
} from "@/RestAPI/url/endpoint";
import { ConfigurationAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import { getIpMaskedValueAndPosition } from "@/lib/utils";

const DiscoveryOIDCheck = () => {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedResourceInfoId, setSelectedResourceInfoId] = useState("");
  const [selectedResourceType, setSelectedResourceType] = useState("");
  const [resourceInfos, setResourceInfos] = useState([]);
  // const [snmpResponse, setSnmpResponse] = useState(""); // Holds the result of the SNMP Get
  const [ip, setIp] = useState("");
  const [ipError, setIpError] = useState("");
  const [getDisabled, setGetDisabled] = useState(true); // Control GET button state
  const [showConfirm, setShowConfirm] = useState(false);

  // Core configuration data state
  const [sysOidValue, setSysOidValue] = useState("");
  const [enterpriseOid, setEnterpriseOid] = useState("");
  // const [enterpriseOidResponse, setEnterpriseOidResponse] = useState("");
  // const [sysOidResponse, setSysOidResponse] = useState("");
  // Add this near your other states
  // const [isEditingValue, setIsEditingValue] = useState(false);
  // Track selected profile object to build dynamic payloads
  const [selectedSnmpProfileObj, setSelectedSnmpProfileObj] = useState(null);
  const [inputValue, setInputValue] = useState("");   // The value currently in the input box
  // --- FIRST EFFECT: Loads the Resource Types ---
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await InventoryAxios(
          FETCH_RESOURCE_MASTER_TYPE_DETAILS_BY_PROTOTYPE_ID,
          "get"
        );

        const rawData = response?.data || [];
        const mappedData = rawData.map((item) => ({
          id: item.resourceTypeId,
          value: item,
          label: item.resourceTypeName,
          enterpriseOid: item.enterpriseOid || "",
          sysOidValue: item.sysOidValue || "",
        }));

        setResources(mappedData);
      } catch (error) {
        console.error("Error fetching resource types:", error);
        Toast("Error!", "Failed to fetch resource types", "error");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // --- SECOND EFFECT: Fetch SNMP profiles based on selected resource type ---
  useEffect(() => {
    const fetchSecondDropdown = async () => {
      if (!selectedResourceType) {
        setResourceInfos([]);
        return;
      }

      try {
        setLoading(true);
        const url = `${FETCH_RESOURCE_INFO_BY_RESOURCE_TYPE_ID}/${selectedResourceType}`;
        const response = await InventoryAxios(url, "get");
        const rawData = response?.data?.data || response?.data || [];

        // Deduplicate profiles similar to the old implementation's removeDuplicateSnmpProfiles
        const uniqueProfilesSet = new Set();
        const mappedData = [];

        rawData.forEach((item, index) => {
          const profile = item?.tmSnmpProfile;
          if (profile) {
            const stringified = JSON.stringify(profile);
            if (!uniqueProfilesSet.has(stringified)) {
              uniqueProfilesSet.add(stringified);
              mappedData.push({
                id: `${profile.snmpProfileId}-${index}`,
                label: profile.snmpProfileName || "No Name Found",
                value: item // Keeps original item containing profile definitions
              });
            }
          }
        });

        setResourceInfos(mappedData);
      } catch (error) {
        console.error("API Error:", error);
        setResourceInfos([]);
        Toast("Error!", "Failed to load device list", "error");
      } finally {
        setLoading(false);
      }
    };

    fetchSecondDropdown();
  }, [selectedResourceType]);

  const handleChange = (option) => {
    if (option) {
      setSelectedResourceType(option.id);
      setEnterpriseOid(option.enterpriseOid || "");
      setSysOidValue(option.sysOidValue || "");
      // Clear downstream selections & data fields
      setSelectedResourceInfoId("");
      setSelectedSnmpProfileObj(null);
      // setEnterpriseOidResponse("");
      // setSysOidResponse("");

      setInputValue(option.sysOidValue || "");

    } else {
      setSelectedResourceType("");
      setEnterpriseOid("");
      setSysOidValue("");
      setInputValue("");
    }
  };

  const handleResourceSelect = (option) => {
    if (option) {
      setSelectedResourceInfoId(option.id);
      const rawItem = option.value;

      // Map entire profile configs dynamically from selection
      if (rawItem?.tmSnmpProfile) {
        setSelectedSnmpProfileObj(rawItem.tmSnmpProfile);
      }

      const oid = rawItem?.imResourceType?.enterpriseOid || "";
      const val = rawItem?.imResourceType?.sysOidValue || "";

      setEnterpriseOid(oid);
      setSysOidValue(val);
      setInputValue(val);
    } else {
      setSelectedResourceInfoId("");
      setSelectedSnmpProfileObj(null);
      setEnterpriseOid("");
      setSysOidValue("");
    }
  };

  // const formatIP = (value) => {
  //   let digits = value.replace(/\D/g, "");
  //   digits = digits.substring(0, 12);

  //   let parts = [];
  //   for (let i = 0; i < digits.length; i += 3) {
  //     let part = digits.substring(i, i + 3);
  //     let num = parseInt(part, 10);
  //     if (num > 255) {
  //       part = "255";
  //     }
  //     parts.push(part);
  //   }
  //   return parts.join(".");
  // };

  const validateForm = (currentIp) => {
    // const ipV4Regx = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
// sonar
    const ipV4Regx = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

    if (currentIp === "") {
      setIpError("Should not be empty");
      setGetDisabled(true);
    } else if (!ipV4Regx.test(currentIp)) {
      setIpError("Invalid IP Address format");
      setGetDisabled(true);
    } else {
      setIpError("");
      setGetDisabled(false); // Enable buttons when IP validation passes
    }
  };
  const handleIpInputChange = (e) => {
    const value = e.target.value;
    const selectionStart = e.target.selectionStart;

    // Use your utility to get the masked value and the correct cursor position
    const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
      value,
      selectionStart,
      ip
    );

    // Update the state
    setIp(maskedValue);

    // Run validation so error messages show/hide in real-time
    validateForm(maskedValue);

    // Fix the cursor position so it doesn't jump to the end
    requestAnimationFrame(() => {
      const safePosition = Math.min(newCursorPosition, maskedValue.length);
      e.target.setSelectionRange(safePosition, safePosition);
    });
  };
  // const onChangeValues = (item, value) => {
  //   if (item === "ip") {
  //     const maskedValue = formatIP(value);
  //     setIp(maskedValue);
  //     validateForm(maskedValue);
  //   }
  // };

  const handleManualChange = (field, value) => {
    if (field === "enterpriseOid") {
      setEnterpriseOid(value);
    } else if (field === "sysOidValue") {
      setSysOidValue(value);
    }
  };

  const handleGetSnmp = async (type) => {
    if (!selectedSnmpProfileObj || !ip) {
      Toast("Warning", "Please select profile and enter IP", "warning");
      return;
    }
    setLoading(true);
    try {
      const oidToTest = type === 1 ? sysOidValue : enterpriseOid;

      // Dynamic profile v
      // lues fetched straight out of your state configuration
      const payload = {
        authPassword: selectedSnmpProfileObj.authPassword || null,
        authProtocol: selectedSnmpProfileObj.authProtocol || null,
        contextName: selectedSnmpProfileObj.contextName || null,
        ipAddress: ip,
        port: selectedSnmpProfileObj.port || 161,
        privPassword: selectedSnmpProfileObj.privPassword || null,
        privProtocol: selectedSnmpProfileObj.privProtocol || null,
        readCommunity: selectedSnmpProfileObj.readCommunity || "public",
        retries: selectedSnmpProfileObj.retries || 1,
        securityLevel: selectedSnmpProfileObj.securityLevel || null,
        snmpProfileId: selectedSnmpProfileObj.snmpProfileId,
        snmpProfileName: selectedSnmpProfileObj.snmpProfileName || "",
        timeout: selectedSnmpProfileObj.timeout || 3,
        username: selectedSnmpProfileObj.username || null,
        version: selectedSnmpProfileObj.version || 1,
        writeCommunity: selectedSnmpProfileObj.writeCommunity || null
      };

      const res = await ConfigurationAxios(
        `${DO_SNMP_GET}/${ip}/${oidToTest}`,
        "post",
        payload
      );
      const result = res?.data || "No SNMP Response";
      setInputValue(result);
      // if (type === 1) {
      //   setSysOidResponse(res?.data || "No Response");
      // } else {
      //   setEnterpriseOidResponse(res?.data || "No Response");
      // }
      Toast("Success", "SNMP Get completed successfully", "success");
    } catch (err) {
      console.error("SNMP Error Details:", err.response?.data || err.message);
      Toast("Error", "SNMP Get Failed", "error");
      // setSnmpResponse("Error fetching value"); // <--- Show error in the box
      // setIsEditingValue(true);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    setShowConfirm(false);
    setLoading(true);

    if (!selectedResourceType) {
      Toast("Warning", "Please select a Device Type first", "warning");
      setLoading(false); // Don't forget to turn off loading
      return;
    }

    try {
      // 1. Determine which OID we are actually updating 
      // If enterpriseOid is empty, it means we are likely targeting the SysOid
      const isEnterprise = enterpriseOid !== "";

      // IMPORTANT: Use the actual OID from state, not the 'inputValue'
      const currentOidToSave = isEnterprise ? enterpriseOid : sysOidValue;

      const baseUrl = isEnterprise
        ? UPDATE_ENTERPRISE_OID_OF_RESMASTERTYPE_BY_RESOURCE_ID_URL
        : UPDATE_SYS_OID_OF_RESMASTERTYPE_BY_RESOURCE_ID_URL;

      // 2. Construct the URL
      // We use 'inputValue' for the third parameter because that is the NEW value to save
      const url = `${baseUrl}/${encodeURIComponent(currentOidToSave)}/${encodeURIComponent(selectedResourceType)}/${encodeURIComponent(inputValue)}`;

      const res = await InventoryAxios(url, "get"); // Note: Check if your API should be 'get' or 'post' based on your backend

      if (res?.data) {
        Toast("Success", "OID updated successfully", "success");

        // 3. Sync local state so the input boxes show the new value
        if (isEnterprise) {
          setEnterpriseOid(inputValue);
        } else {
          setSysOidValue(inputValue);
        }
      }
    } catch (err) {
      console.error("Update Error:", err);
      Toast("Error", "Update failed", "error");
    } finally {
      setLoading(false);
    }
  };


  return (
    <Box sx={{ border: "2px solid #eee", p: 2, borderRadius: "10px" }}>
      <Typography sx={{ minWidth: "100px", color: "text.TitleTextcolor", ml: 2 }}>
        Discovery OID Check
      </Typography>
      <Box sx={{ borderBottom: "2px solid #eee", ml: -2, mr: -2, mt: 2 }} />

      <Box className="grid grid-cols-1 md:grid-cols-2 mt-4 ml-3 gap-4 mb-2 items-center w-full">
        {/* Row 1, Col 1: Device Select */}
        <Box sx={{ display: "flex", flexDirection: "column", width: "95%", }}>
          <Typography sx={{ mb: 0.5 }}>Select Device Type</Typography>
          <MSelect
            options={resources}
            placeholder="select device"
            getOptionValue={(option) => option.id}
            value={selectedResourceType}
            onChange={handleChange}
          />
        </Box>

        {/* Row 1, Col 2: SNMP Profile Select */}
        <Box sx={{ display: "flex", flexDirection: "column", width: "95%" }}>
          <Typography sx={{ mb: 0.5 }}>SNMP Profile</Typography>
          <MSelect
            options={resourceInfos}
            placeholder="select profile"
            getOptionValue={(option) => option.id}
            value={selectedResourceInfoId}
            onChange={(option) => handleResourceSelect(option)}
          />
        </Box>

        {/* Row 1, Col 3: IP Input */}
        <Box sx={{ display: "flex", flexDirection: "column", width: "95%" }}>
      <Typography sx={{ mb: 0.5 }}>IP Address</Typography>
      <MInput
        fullWidth
        value={ip}
        error={ipError.length > 0}
        helperText={ipError}
        // IMPORTANT: Pass the event 'e' directly to our new handler
        onChange={handleIpInputChange} 
        inputProps={{ maxLength: 15 }}
        placeholder="___.___.___.___"
        InputLabelProps={{ shrink: true }}
      />
    </Box>


        {/* Row 2, Col 1: Enterprise OID Entry */}
        <Box sx={{ display: "flex", flexDirection: "column", width: "95%" }}>
          <Typography sx={{ mb: 0.5 }}>Enter OID</Typography>
          <MInput
            fullWidth
            value={enterpriseOid}
            onChange={(e) => handleManualChange("enterpriseOid", e.target.value)}
            placeholder="Enter OID"
          />
        </Box>


        <Box sx={{ display: "flex", flexDirection: "column", width: "95%" }}>
          <Typography sx={{ mb: 0.5 }}>Value</Typography>
          <MInput
            fullWidth
            value={inputValue} // Use ONLY the inputValue state here
            onChange={(e) => {
              setInputValue(e.target.value);
            }}
            placeholder="Value"
          />
        </Box>

        {/* Row 2, Col 3: Get Activation Button */}
        <Box sx={{ mt: 3 }}>
          <MButtonPrimary
            onClick={() => handleGetSnmp(2)}
            disabled={getDisabled || !enterpriseOid || !selectedResourceInfoId || loading}
          >
            Get {loading && <CircularProgress size={16} sx={{ ml: 1 }} />}
          </MButtonPrimary>
        </Box>
      </Box>

      {/* Action Buttons Row */}
      <Box sx={{ display: "flex", justifyContent: "flex-start", gap: 2, mt: 3, pt: 2 }}>
        <MButtonPrimary
          variant="contained"
          color="primary"
          disabled={loading || !selectedResourceType}
          onClick={() => setShowConfirm(true)}
          sx={{ px: 5 }}
        >
          {loading ? "Updating..." : "Update"}
        </MButtonPrimary>
      </Box>
      <MDialog

        open={showConfirm}
        variant="info"
        mode="child"
        
        icon={Confirmation_icon}
        title="Confirm Action"
        message="Do you want to update discovery OID?"
        onConfirm={handleUpdate}
        onClose={() => setShowConfirm(false)}
      />
    </Box>
  );
};

export default DiscoveryOIDCheck;
