import React, {
  useState,
  useMemo,
  useCallback,
  useRef,
  useEffect,
} from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  Box,
  Typography,
  IconButton,
  CircularProgress,
  useTheme,
} from "@mui/material";
import { Tabs } from "antd";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
// --- REUSABLE COMPONENTS ---
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Toast from "@/components/Reusable/Toast/Toast";

// --- CORE UTILITIES & API CALLS ---
import { isValidIpV4 } from "@/utility/FormValidation/YupSchema";
import { getIpMaskedValueAndPosition } from "@/lib/utils";
import {
  FETCH_ALL_RESOURCE_INFO,
  PERFORM_CNMS_DEVICE_DISCOVERY,
} from "@/RestAPI/url/endpoint";
import { InventoryAxios, TopologyAxios } from "@/RestAPI/api/axiosApicall";
import IpDeviceDiscoveryReportModal from "./IpDeviceDiscoveryReportModal";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { updateDiscoveredDeviceStatus } from "@/store/features/Topology/topologyNodesslice";
import { updateDiscoveredDeviceStatusFabric } from "@/store/features/Inventory/inventorySlice";
import DiscoveryProgressOverlay from "../DeviceDiscovery/DiscoveryProgressOverlay";
import {
  resetDiscoveryProgress,
  setDiscoveryProgress,
} from "@/store/features/Cnms/CnmsDiscovery/siteDiscoverySlice";

// Helper function to safely extract clean text out of masks
const cleanIp = (maskedIp) => {
  if (!maskedIp) return "";
  const cleaned = maskedIp.replace(/[^0-9.]/g, "");
  return cleaned.replace(/\.$/, "");
};

// ==========================================
// 1. MEMOIZED SUB-COMPONENTS (PERFORMANCE)
// ==========================================
const DeviceCard = React.memo(({ dev, ipValue, onIpChange, error }) => {
  return (
    <Grid item xs={12} sm={6} md={4}>
      <Box
        sx={{
          p: 0,
          // border: "1px solid #ddd",
          borderRadius: "8px",
          transition: "all 0.2s",
          width: "100%",
          // backgroundColor: "#fafafa",
          // "&:hover": { borderColor: "#14348D", bgcolor: "#fff" },
        }}
      >
        <Typography
          variant="body2"
          sx={{ fontWeight: 500, mb: 0.5, color: "text.tabcolor" }}
        >
          {dev.resourceName}
        </Typography>
        <MInput
          fullWidth
          placeholder="___.___.___.___"
          value={ipValue}
          onChange={onIpChange}
          error={error}
          errorMessage={error ? "Invalid IPv4 Address" : ""}
        />
      </Box>
    </Grid>
  );
});

// ==========================================
// 2. MAIN HOST LAYER COMPONENT
// ==========================================
const IpDeviceDiscovery = ({ isChildFullScreen }) => {
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const segments = useSelector((state) => state.inventory?.segments) || [];
  const resourcesObj = useSelector((state) => state.inventory?.resources) || {};

  const resourcesArray = useMemo(
    () => Object.values(resourcesObj),
    [resourcesObj]
  );

  // Core Functional States
  const [selectedSegmentId, setSelectedSegmentId] = useState(null);
  const [ipAddresses, setIpAddresses] = useState({});
  const [ipErrors, setIpErrors] = useState({});
  const [discoveryResults, setDiscoveryResults] = useState([]);
  const tabsRef = useRef(null);

  const dispatch = useDispatch();

  // Loader state hooks
  const [isFetchingInitialData, setIsFetchingInitialData] = useState(true);
  const [loading, setLoading] = useState(false);
  // ... other states
  const [isModalOpen, setIsModalOpen] = useState(false);

  //   const [isProgressOpen, setIsProgressOpen] = useState(false);
  // const [activeStep, setActiveStep] = useState(0);
  const discoveryProgress = useSelector(
    (state) => state?.siteDiscovery?.discoveryProgress
  );

  const [showStepper, setShowStepper] = useState(false);
  // Add this state for the confirmation dialog
  const [dialogConfig, setDialogConfig] = useState({
    visible: false,
    message: "",
  });

  // Monitor loading initialization of baseline system resources
  useEffect(() => {
    if (segments.length > 0) {
      if (!selectedSegmentId) {
        setSelectedSegmentId(segments[0].segmentId);
      }
      setIsFetchingInitialData(false);
    }
  }, [segments, selectedSegmentId]);

  // // Setup initial IP entries derived from Redux Store caches
  // useEffect(() => {
  //   const initialIps = {};
  //   resourcesArray.forEach((res) => {
  //     if (res.resourceIp) {
  //       initialIps[res.resourceId] = res.resourceIp;
  //     }
  //   });
  //   setIpAddresses(initialIps);
  // }, [resourcesArray]);

  useEffect(() => {
    setIpAddresses((prev) => {
      const next = { ...prev };

      resourcesArray.forEach((res) => {
        const resourceId = res.resourceId;

        // Only initialize from Redux if the user has not
        // already started editing this resource.
        if (res.resourceIp && next[resourceId] === undefined) {
          next[resourceId] = res.resourceIp;
        }
      });

      return next;
    });
  }, [resourcesArray]);

  const scrollTabs = (direction) => {
    if (tabsRef.current) {
      const scrollAmount = 200;
      tabsRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  //   const filteredDevices = useMemo(() => {
  //     if (!selectedSegmentId) return [];
  //     return resourcesArray.filter(
  //       (res) => res.imSegmentInfo?.segmentId === selectedSegmentId
  //     );
  //   }, [selectedSegmentId, resourcesArray]);
  // console.log("filteredDevices", filteredDevices)

  const filteredDevices = useMemo(() => {
    if (!selectedSegmentId) return [];

    return resourcesArray
      .filter((res) => res.imSegmentInfo?.segmentId === selectedSegmentId)
      .filter(
        (res) => res.imResourceType?.imResourceStateInfo?.resourceStateId === 1
      );
  }, [selectedSegmentId, resourcesArray]);
  console.log("filteredDevices", filteredDevices);

  // const handleIpChange = useCallback((resourceId, e) => {
  //   const { value } = e.target;
  //   const selectionStart = e.target.selectionStart;
  //   const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
  //     value,
  //     selectionStart
  //   );

  //   setIpAddresses((prev) => ({ ...prev, [resourceId]: maskedValue }));

  //   const cleaned = cleanIp(maskedValue);
  //   const isInvalid = maskedValue !== "" && !isValidIpV4(cleaned);
  //   setIpErrors((prev) => ({ ...prev, [resourceId]: isInvalid }));

  //   requestAnimationFrame(() => {
  //     e.target.setSelectionRange(newCursorPosition, newCursorPosition);
  //   });
  // }, []);
  const handleIpChange = useCallback(
    (resourceId, e) => {
      const { value } = e.target;
      const selectionStart = e.target.selectionStart;

      // 1. CRITICAL: Ensure we grab the current value from state safely
      // If it doesn't exist, use an empty string.
      const previousValue = ipAddresses[resourceId] || "";

      // 2. Run the logic
      const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
        value,
        selectionStart,
        previousValue
      );

      // 3. Update state only if the value actually changed
      // If the user types "258", maskedValue will equal previousValue,
      // so this block won't trigger, and the input stays as "25"
      if (maskedValue !== previousValue) {
        setIpAddresses((prev) => ({
          ...prev,
          [resourceId]: maskedValue,
        }));

        const cleaned = cleanIp(maskedValue);
        const isInvalid = maskedValue !== "" && !isValidIpV4(cleaned);
        setIpErrors((prev) => ({
          ...prev,
          [resourceId]: isInvalid,
        }));
      }

      // 4. Restore cursor
      requestAnimationFrame(() => {
        if (e.target) {
          e.target.setSelectionRange(newCursorPosition, newCursorPosition);
        }
      });
    },
    [ipAddresses, setIpAddresses, setIpErrors]
  ); // Must include ipAddresses here!
  const handleTriggerDiscovery = () => {
    // Check for errors before even showing the confirmation
    const hasErrors = Object.values(ipErrors).some((err) => err === true);

    if (hasErrors) {
      Toast(
        "Error",
        "Please fix invalid IP addresses before proceeding.",
        "error"
      );
      return;
    }

    // Instead of running the API, we open the confirmation dialog
    setDialogConfig({
      visible: true,
      message: "Are you sure you want to discovery?",
    });
  };

  // const handleConfirmDiscovery = async () => {
  //   // Close dialog immediately so user doesn't click twice
  //   setDialogConfig((prev) => ({ ...prev, visible: false }));

  //   setLoading(true);
  //   try {
  //     // 1. Pristine Baseline Fetch Call
  //     const fetchRes = await InventoryAxios(FETCH_ALL_RESOURCE_INFO, "get");
  //     let masterResourceList = [];

  //     if (Array.isArray(fetchRes)) {
  //       masterResourceList = fetchRes;
  //     } else if (fetchRes?.data) {
  //       masterResourceList = Array.isArray(fetchRes.data) ? fetchRes.data : [];
  //     }

  //     if (masterResourceList.length === 0) {
  // Toast(
  //   "Error",
  //   "Something went wrong fetching baseline records!",
  //   "error"
  // );
  //       return;
  //     }
  //     const finalPayload = masterResourceList
  //     .filter((device) => device.imResourceType?.imResourceStateInfo?.resourceStateId === 1)
  //     .map((device) =>
  //       ipAddresses[device.resourceId]
  //         ? (cleanIp(ipAddresses[device.resourceId])
  //             ? { ...device, resourceIp: cleanIp(ipAddresses[device.resourceId]), discoveryMode: "MANUAL" }
  //             : device)
  //         : device
  //     );

  //     // 3. Post to discovery service
  //     const response = await TopologyAxios(
  //       PERFORM_CNMS_DEVICE_DISCOVERY,
  //       "post",
  //       finalPayload
  //     );

  //     dispatch(updateDiscoveredDeviceStatus(response?.data));
  //     dispatch(updateDiscoveredDeviceStatusFabric(response?.data));

  //     if (response && response.data) {
  //       let processedData = [];
  //       if (Array.isArray(response.data)) {
  //         processedData = response.data;
  //       } else if (
  //         typeof response.data === "object" &&
  //         response.data !== null
  //       ) {
  //         processedData = Object.values(response.data);
  //       }

  //       const formattedData = processedData.map((item, index) => ({
  //         ...item,
  //         sno: index + 1,
  //         resourceName: item.resourceName || "NA",
  //         resourceIp: item.resourceIp || "NA",
  //         macAddress: item.macAddress || "NA",
  //         segmentName: item.imSegmentInfo?.segmentName || "N/A",
  //         resourceTypeName: item.imResourceType?.resourceTypeName || "N/A",
  //         discoveredstatusMessage: item.discoveredstatusMessage || "",
  //         status: (
  //           <Typography
  //             variant="body2"
  //             sx={{
  //               fontWeight: "600",
  //               color: item.status === "Success" ? "#2e7d32" : "#d32f2f",
  //             }}
  //           >
  //             {item.status || "Unknown"}
  //           </Typography>
  //         ),
  //       }));
  //       // status: item.status,
  //       // }))

  //       setDiscoveryResults(formattedData);
  //       console.log("formattedDataIpDeviceDiscovery", formattedData);
  //       Toast("Success", "Device discovery successful!", "success");
  //       setIsModalOpen(true);
  //     }
  //   } catch (error) {
  //     console.error("Discovery Engine Error:", error);
  //     Toast(
  //       "Error",
  //       "An execution error popped up running the discovery pipeline.",
  //       "error"
  //     );
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  // const handleConfirmDiscovery = async () => {
  //   // Close confirmation dialog immediately
  //   setDialogConfig({
  //     visible: false,
  //     message: "",
  //   });

  //   setLoading(true);
  //   setIsProgressOpen(true);
  //   setActiveStep(1);

  //   try {
  //     // Small delay so the "Fetch Active IPs" step is visible
  //     await new Promise((resolve) => setTimeout(resolve, 1200));

  //     // ==========================================
  //     // STEP 1 -> FETCH ACTIVE IPs
  //     // ==========================================
  //     setActiveStep(2);

  //     const fetchRes = await InventoryAxios(
  //       FETCH_ALL_RESOURCE_INFO,
  //       "get"
  //     );

  //     let masterResourceList = [];

  //     if (Array.isArray(fetchRes)) {
  //       masterResourceList = fetchRes;
  //     } else if (fetchRes?.data) {
  //       masterResourceList = Array.isArray(fetchRes.data)
  //         ? fetchRes.data
  //         : [];
  //     }

  //     if (masterResourceList.length === 0) {
  //       // throw new Error("Something went wrong fetching baseline records!");
  //       Toast(
  //         "Error",
  //         "Something went wrong fetching baseline records!",
  //         "error"
  //       );
  //     }

  //     // ==========================================
  //     // STEP 2 -> PREPARE DISCOVERY PAYLOAD
  //     // ==========================================
  //     const finalPayload = masterResourceList
  //       .filter(
  //         (device) =>
  //           device.imResourceType?.imResourceStateInfo
  //             ?.resourceStateId === 1
  //       )
  //       .map((device) => {
  //         const userIp = ipAddresses[device.resourceId];
  //         const cleanedIp = cleanIp(userIp);

  //         if (cleanedIp) {
  //           return {
  //             ...device,
  //             resourceIp: cleanedIp,
  //             discoveryMode: "MANUAL",
  //           };
  //         }

  //         return device;
  //       });

  //     // ==========================================
  //     // STEP 3 -> DISCOVERY
  //     // ==========================================
  //     const response = await TopologyAxios(
  //       PERFORM_CNMS_DEVICE_DISCOVERY,
  //       "post",
  //       finalPayload
  //     );

  //     if (!response?.data) {
  //       Toast(
  //         "Error",
  //         "Discovery API returned no response",
  //         "error"
  //       );
  //     }

  //     dispatch(updateDiscoveredDeviceStatus(response.data));
  //     dispatch(updateDiscoveredDeviceStatusFabric(response.data));

  //     // ==========================================
  //     // PROCESS RESPONSE
  //     // ==========================================
  //     let processedData = [];

  //     if (Array.isArray(response.data)) {
  //       processedData = response.data;
  //     } else if (
  //       typeof response.data === "object" &&
  //       response.data !== null
  //     ) {
  //       processedData = Object.values(response.data);
  //     }

  //     const formattedData = processedData.map((item, index) => ({
  //       ...item,
  //       sno: index + 1,
  //       resourceName: item.resourceName || "NA",
  //       resourceIp: item.resourceIp || "NA",
  //       macAddress: item.macAddress || "NA",
  //       segmentName: item.imSegmentInfo?.segmentName || "N/A",
  //       resourceTypeName:
  //         item.imResourceType?.resourceTypeName || "N/A",
  //       discoveredstatusMessage:
  //         item.discoveredstatusMessage || "",
  //       status: (
  //         <Typography
  //           variant="body2"
  //           sx={{
  //             fontWeight: "600",
  //             color:
  //               item.status === "Success"
  //                 ? "#2e7d32"
  //                 : "#d32f2f",
  //           }}
  //         >
  //           {item.status || "Unknown"}
  //         </Typography>
  //       ),
  //     }));

  //     setDiscoveryResults(formattedData);

  //     // ==========================================
  //     // STEP 4 -> COMPLETE
  //     // ==========================================
  //     setActiveStep(3);

  //     // Let user see "Complete" before opening report
  //     await new Promise((resolve) => setTimeout(resolve, 800));

  //     setIsProgressOpen(false);
  //     setIsModalOpen(true);

  //     Toast(
  //       "Success",
  //       "Device discovery successful!",
  //       "success"
  //     );
  //   } catch (error) {
  //     console.error("Discovery Engine Error:", error);

  //     setActiveStep(0);
  //     setIsProgressOpen(false);

  //     Toast(
  //       "Error",
  //       error?.message ||
  //         "An execution error popped up running the discovery pipeline.",
  //       "error"
  //     );
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const handleConfirmDiscovery = async () => {
    setShowStepper(true);
    setDialogConfig({
      visible: false,
      message: "",
    });

    setLoading(true);

    dispatch(
      setDiscoveryProgress({
        activeStep: 0,
        message: "Starting Device Discovery...",
        percentage: 0,
        isRunning: true,
        socketStage: 0,
      })
    );

    try {
      const fetchRes = await InventoryAxios(FETCH_ALL_RESOURCE_INFO, "get");

      let masterResourceList = [];

      if (Array.isArray(fetchRes)) {
        masterResourceList = fetchRes;
      } else if (fetchRes?.data) {
        masterResourceList = Array.isArray(fetchRes.data) ? fetchRes.data : [];
      }

      if (masterResourceList.length === 0) {
        Toast(
          "Error",
          "Something went wrong fetching baseline records!",
          "error"
        );
      }

      const finalPayload = masterResourceList
        .filter(
          (device) =>
            device.imResourceType?.imResourceStateInfo?.resourceStateId === 1
        )
        .map((device) => {
          const userIp = ipAddresses[device.resourceId];
          const cleanedIp = cleanIp(userIp);

          if (cleanedIp) {
            return {
              ...device,
              resourceIp: cleanedIp,
              discoveryMode: "MANUAL",
            };
          }

          return device;
        });

      const response = await TopologyAxios(
        PERFORM_CNMS_DEVICE_DISCOVERY,
        "post",
        finalPayload
      );

      if (!response?.data) {
        Toast("Error", "Discovery API returned no response", "error");
      }

      dispatch(updateDiscoveredDeviceStatus(response.data));
      dispatch(updateDiscoveredDeviceStatusFabric(response.data));

      let processedData = [];

      if (Array.isArray(response.data)) {
        processedData = response.data;
      } else if (typeof response.data === "object" && response.data !== null) {
        processedData = Object.values(response.data);
      }

      const formattedData = processedData.map((item, index) => ({
        ...item,
        sno: index + 1,
        resourceName: item.resourceName || "NA",
        resourceIp: item.resourceIp || "NA",
        macAddress: item.macAddress || "NA",
        segmentName: item.imSegmentInfo?.segmentName || "N/A",
        resourceTypeName: item.imResourceType?.resourceTypeName || "N/A",
        discoveredstatusMessage: item.discoveredstatusMessage || "",
        // status: (
        //   <Typography
        //     variant="body2"
        //     sx={{
        //       fontWeight: "600",
        //       color: item.status === "Success" ? "#2e7d32" : "#d32f2f",
        //     }}
        //   >
        //     {item.status || "Unknown"}
        //   </Typography>
        // ),
        statusDisplay: (
          <Typography
            variant="body2"
            sx={{
              fontWeight: 600,
              color: item.status === "Success" ? "#2e7d32" : "#d32f2f",
            }}
          >
            {item.status || "Unknown"}
          </Typography>
        ),

        // For PDF/Excel export
        statusText: item.status,
      }));

      setDiscoveryResults(formattedData);

      setIsModalOpen(true);

      setShowStepper(false);
      Toast("Success", "Device discovery successful!", "success");
      // dispatch(resetDiscoveryProgress());
    } catch (error) {
      console.error("Discovery Engine Error:", error);

      dispatch(resetDiscoveryProgress());

      Toast(
        "Error",
        error?.message ||
          "An execution error popped up running the discovery pipeline.",
        "error"
      );
    } finally {
      setLoading(false);
    }
  };
  const tabItems = useMemo(() => {
    return segments.map((seg) => ({
      key: seg.segmentId.toString(),
      label: seg.segmentName,
    }));
  }, [segments]);

  const tableColumns = [
    { name: "S No", uid: "sno" },
    { name: "Device Name", uid: "resourceName", key: "resourceName" },
    { name: "Segment", uid: "segmentName", key: "segmentName" },
    { name: "IP Address", uid: "resourceIp", key: "resourceIp" },
    { name: "MAC Address", uid: "macAddress", key: "macAddress" },
    {
      name: "Status Message",
      uid: "discoveredstatusMessage",
      key: "discoveredstatusMessage",
    },
    { name: "Discovery Status", uid: "statusDisplay", key: "statusText" },
  ];

  // Screen Loader while loading tabs/segments
  if (isFetchingInitialData) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "300px",
          gap: 2,
        }}
      >
        <CircularProgress sx={{ color: "#14348D" }} />
        <Typography variant="body2" color="textSecondary">
          Loading Discovery Segments...
        </Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        border: "2px solid #eee",

        p: 3,
        borderRadius: "10px",
        bgcolor: "background.paper",
        position: "relative",
        // maxHeight: "80vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Progress Mask for Form Posting Processes */}
      {/* {loading && (
        <Box
          sx={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            bgcolor: "rgba(255,255,255,0.7)",
            zIndex: 100,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <CircularProgress sx={{ color: "#14348D" }} />
        </Box>
      )} */}
      {/* <Typography sx={{ minWidth: "100px", color: "#14348D", fontWeight: 600 }}>
        IP Device Discovery
      </Typography> */}
      {/* <Box sx={{ borderBottom: "2px solid #eee", mb: 2 }} /> */}

      {/* Tabs Control Layer */}
      <Box
        sx={{
          mb: 3,
          width: "100%",
          // position: "relative",
          display: "flex",
          alignItems: "center",
          borderBottom: "2px solid #eee",
          position: "sticky", // 2. MAKE STICKY
          top: 0, // 3. STICK TO TOP
          zIndex: 1000,
          bgcolor: "background.paper",
        }}
      >
        <IconButton
          size="small"
          onClick={() => scrollTabs("left")}
          sx={{
            position: "absolute",
            left: -10,
            bottom: 13,
            zIndex: 10,
            bgcolor: "#E9EFFF",
            color: "#14348D",
            boxShadow: 3,
            "&:hover": { bgcolor: "#f0f0f0" },
          }}
        >
          <ChevronLeft fontSize="small" />
        </IconButton>
        <Box
          ref={tabsRef}
          sx={{
            width: "100%",
            overflowX: "auto",
            overflowY: "hidden",
            display: "block",
            msOverflowStyle: "none",
            scrollbarWidth: "none",
            "&::-webkit-scrollbar": { display: "none" },
          }}
        >
          <Tabs
            activeKey={selectedSegmentId?.toString() || ""}
            onChange={(key) => setSelectedSegmentId(parseInt(key))}
            items={tabItems}
            type="line"
            className="custom-tabs"
            style={{ width: "max-content", minWidth: "100%" }}
          />
        </Box>
        <IconButton
          size="small"
          onClick={() => scrollTabs("right")}
          sx={{
            position: "absolute",
            right: -10,
            bottom: 13,
            zIndex: 10,
            bgcolor: "#E9EFFF",
            color: "#14348D",
            boxShadow: 3,
            "&:hover": { bgcolor: "#f0f0f0" },
          }}
        >
          <ChevronRight fontSize="small" />
        </IconButton>
        <style>{`
   .custom-tabs .ant-tabs-nav::before { 
            border-bottom: 1px solid ${isDark ? "#333" : "#eee"} !important; 
        }


  .custom-tabs .ant-tabs-tab { 
            padding: 0px 25px !important; 
            color: ${isDark ? "#94a3b8" : "#000000"}; 
            transition: all 0.3s;
        }

    .custom-tabs .ant-tabs-tab-active {
        border-bottom: 2px solid #14348d !important; /* The blue border */
    }

    .custom-tabs .ant-tabs-tab-active .ant-tabs-tab-btn { 
        color: ${isDark ? "##14348d" : "#14348d"} !important; 
        font-weight: 600 !important; 
    }

    .custom-tabs .ant-tabs-ink-bar { 
        background-color: #14348D !important; 
        height: 2px !important; 
    }
`}</style>
      </Box>

      {/* Form Grid Blocks */}
      {selectedSegmentId ? (
        <Box>
          <Grid
            container
            spacing={2}
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
              gap: 2,
              width: "100%",
              mb: 1,
            }}
          >
            {filteredDevices.length > 0 ? (
              filteredDevices.map((dev) => (
                <DeviceCard
                  key={dev.resourceId}
                  dev={dev}
                  ipValue={ipAddresses[dev.resourceId] || ""}
                  onIpChange={(e) => handleIpChange(dev.resourceId, e)}
                  error={ipErrors[dev.resourceId]}
                />
              ))
            ) : (
              <Grid item xs={12}>
                <Typography color="textSecondary" sx={{ fontStyle: "italic" }}>
                  No devices found in this segment.
                </Typography>
              </Grid>
            )}
          </Grid>

          <Box
            sx={{ mt: 4, display: "flex", justifyContent: "flex-end", gap: 2 }}
          >
            <MButtonPrimary
              variant="contained"
              disabled={loading}
              onClick={handleTriggerDiscovery}
              sx={{ px: 4 }}
            >
              {loading ? "Processing..." : "Perform Discovery"}
            </MButtonPrimary>
          </Box>
        </Box>
      ) : (
        <Box sx={{ textAlign: "center", py: 4 }}>
          <Typography color="textSecondary">
            Please select a segment from the tabs above to view devices.
          </Typography>
        </Box>
      )}
      {/* --- CONFIRMATION DIALOG --- */}
      <MDialog
        open={dialogConfig.visible}
        icon={confirmation_icon} // Or your imported confirmation_icon
        onClose={() => setDialogConfig({ visible: false, message: "" })}
        title="Confirmation"
        message={dialogConfig.message}
        confirmText="Yes, Proceed"
        onConfirm={handleConfirmDiscovery} // <--- This triggers the API
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />
      <DiscoveryProgressOverlay
        isOpen={showStepper}
        activeStep={discoveryProgress.activeStep}
        loading={loading}
        message={discoveryProgress.message}
        isChildFullScreen={isChildFullScreen}

      />
      {/* --- INTEGRATED MANIFEST DIALOG --- */}
      <IpDeviceDiscoveryReportModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        discoveryResults={discoveryResults}
        tableColumns={tableColumns}
      />
    </Box>
  );
};

export default IpDeviceDiscovery;
