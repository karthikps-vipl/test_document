import {
  Box
} from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal"; // Adjust path
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MTable from "@/components/Reusable/Table/MTable";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";

const IpDeviceDiscoveryReportModal = ({
  isOpen,
  onClose,
  discoveryResults,
  tableColumns,
}) => {
  return (
    <MModal
      open={isOpen}
      title="Device Discovery Status"
      handleClose={onClose}
      fullWidth
      customWidth="85%"
      enableFullScreen
    >
      <Box sx={{ p: 1, display: "flex", flexDirection: "column", gap: 3 }}>
        {/* Results Table */}
        <Box  >
          <MTable
            tableTitle="IP Device Discovery Report"
            columns={tableColumns}
            tableData={discoveryResults}
            showPagination={true}
            showSearch={true}
            enableRowSelection={false}
            rowIdKey="resourceId"
            handleDownloadPDF={() =>
              exportToPDF(
                "IP Device Discovery Report",
                tableColumns,
                discoveryResults,
                "IP_Device_Discovery_Report"
              )
            }
          />
        </Box>

        <Box sx={{ display: "flex", justifyContent: "flex-end", pt: 1 }}>
          <MButtonPrimary onClick={onClose}>Close</MButtonPrimary>
        </Box>
      </Box>
    </MModal>
  );
};

export default IpDeviceDiscoveryReportModal;
