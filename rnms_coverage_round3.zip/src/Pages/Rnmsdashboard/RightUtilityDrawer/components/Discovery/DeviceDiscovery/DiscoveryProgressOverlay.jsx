import React from "react";
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Typography,
  CircularProgress,
} from "@mui/material";
import MDialog from "@/components/Reusable/Dialog/MDialog";

const DiscoveryProgressOverlay = ({ isOpen, activeStep, loading, message, isChildFullScreen }) => {
  const steps = ["Start", "Fetch Active IPs", "Discovery", "Complete"];
  const brandBlue = "#14348D";
  const connectorColor = "#14348D"; // Set your desired line color here

  return (
    <MDialog
      open={isOpen}
      showButtons={false} // This now works with the change above!
      title=""
      message=""
      mode="child"
      isChildFullScreen={isChildFullScreen}
      glass={true}
      PaperProps={{
        style: {
          backgroundColor: "transparent",
          backdropFilter: "blur(20px)",
          boxShadow: "0 8px 32px 0 rgba(20, 52, 141, 0.15)",
          borderRadius: "16px",
          padding: "32px",
          maxWidth: "750px",
          width: "100%",
        },
      }}
      sx={{
        "& .MuiBackdrop-root": {
          backgroundColor: "rgba(0, 0, 0, 0.25)",
          backdropFilter: "blur(0.5px)",
        },
      }}
    >
      <Box>
        {message && (
          <Typography
            sx={{
              textAlign: "center",
              color: brandBlue,
              fontWeight: 600,
              mb: 2,
            }}
          >
            {message}
          </Typography>
        )}
        <Stepper
          activeStep={activeStep}
          alternativeLabel
          sx={{
            // 1. Icon colors (Blue)
            "& .MuiStepIcon-root.Mui-active": {
              color: brandBlue,
            },
            "& .MuiStepIcon-root.Mui-completed": {
              color: brandBlue,
            },

            // 2. Connecting Line colors (Black)
            // Note: For alternativeLabel, we use borderTopColor
            "& .MuiStepConnector-root": {
              "& .MuiStepConnector-line": {
                borderTopColor: connectorColor,
                borderTopWidth: "2px", // Makes the line slightly thicker/more visible
              },
            },

            // This ensures the line turns blue ONLY when the step is active
            // (Optional: if you want the line to stay black even when active, remove this block)
            "& .MuiStepConnector-root.Mui-active .MuiStepConnector-line": {
              borderTopColor: connectorColor,
            },

            // 3. Text colors
            "& .MuiStepLabel-label.Mui-active": {
              color: brandBlue,
              fontWeight: "bold",
            },
            "& .MuiStepLabel-label.Mui-completed": {
              color: brandBlue,
            },
          }}
        >
          {steps.map((label, idx) => (
            <Step key={label}>
              <StepLabel
                optional={
                  loading && activeStep === idx ? (
                    <Typography
                      variant="caption"
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: 0.5,
                        mt: 0.5,
                        color: brandBlue,
                      }}
                    >
                      Processing{" "}
                      <CircularProgress size={8} sx={{ color: brandBlue }} />
                    </Typography>
                  ) : null
                }
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
    </MDialog>
  );
};

export default DiscoveryProgressOverlay;
