import React, { useState, useMemo } from "react";
import {
  Box,
  Typography,
  Radio,
  RadioGroup,
  FormControlLabel,
  Divider,
} from "@mui/material";
import { PlayArrow } from "@mui/icons-material";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import { InventoryAxios, TopologyAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_PORT_INFO_DETAILS,
  FETCH_ALL_RESOURCE_INFO,
  PERFORM_DISCOVERY,
} from "@/RestAPI/url/endpoint";
import { ipToLong, isValidIpV4 } from "@/utility/FormValidation/YupSchema";
import DiscoveryProgressOverlay from "./DiscoveryProgressOverlay";
import DiscoveryReportModal from "./DiscoveryReportModal";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import { getIpMaskedValueAndPosition } from "@/lib/utils";
import { useDispatch, useSelector } from "react-redux";
import {
  updateDiscoveredDeviceStatus,
} from "@/store/features/Topology/topologyNodesslice";
import MForm from "@/components/Reusable/Form/MForm";
import FormField from "@/components/Reusable/Form/FormField";
import {
  updateDiscoveredDeviceStatusFabric,
  updateResourceIp,
} from "@/store/features/Inventory/inventorySlice";
import {
  resetDiscoveryProgress,
  setDiscoveryProgress,
} from "@/store/features/Cnms/CnmsDiscovery/siteDiscoverySlice";

const DeviceDiscovery = ({ isChildFullScreen }) => {
  const [discoveryType, setDiscoveryType] = useState("4");
  // const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const discoveryProgress = useSelector(
    (state) => state?.siteDiscovery?.discoveryProgress
  );
  // Store full response to feed downstream components
  const [apiRawResponse, setApiRawResponse] = useState(null);
  const [reportData, setReportData] = useState([]);
  const [showStepper, setShowStepper] = useState(false);

  // const [isProgressOpen, setIsProgressOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [dialogConfig, setDialogConfig] = useState({
    visible: false,
    message: "",
  });

  console.log("apiRawResponse", apiRawResponse?.lstResourceInfoBeanDsrvystatus);

  const [formData, setFormData] = useState({
    startIp: "",
    endIp: "",
    individualIp: "",
  });

  const cleanIp = (maskedIp) => {
    if (!maskedIp) return "";
    return maskedIp.replace(/[^0-9.]/g, "").replace(/\.$/, "");
  };

  // --- OPTIMIZED LIVE VALIDATION LOGIC ---
  const cleanedStartIp = useMemo(
    () => cleanIp(formData.startIp),
    [formData.startIp]
  );
  const cleanedEndIp = useMemo(() => cleanIp(formData.endIp), [formData.endIp]);
  const cleanedIndividualIp = useMemo(
    () => cleanIp(formData.individualIp),
    [formData.individualIp]
  );

  // Specific format validity flags
  const isStartIpValid = useMemo(
    () => formData.startIp === "" || isValidIpV4(cleanedStartIp),
    [formData.startIp, cleanedStartIp]
  );
  const isEndIpValid = useMemo(
    () => formData.endIp === "" || isValidIpV4(cleanedEndIp),
    [formData.endIp, cleanedEndIp]
  );
  const isIndividualIpValid = useMemo(
    () => formData.individualIp === "" || isValidIpV4(cleanedIndividualIp),
    [formData.individualIp, cleanedIndividualIp]
  );

  // Logical range validation: Only calculate if both strings are valid formats
  const isRangeLogicallyInvalid = useMemo(() => {
    if (discoveryType === "3" && cleanedStartIp && cleanedEndIp) {
      if (isValidIpV4(cleanedStartIp) && isValidIpV4(cleanedEndIp)) {
        return ipToLong(cleanedStartIp) > ipToLong(cleanedEndIp);
      }
    }
    return false;
  }, [cleanedStartIp, cleanedEndIp, discoveryType]);

  // const handleIpInputChange = (e) => {
  //   const { name, value } = e.target;
  //   const selectionStart = e.target.selectionStart;

  //   const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
  //     value,
  //     selectionStart
  //   );

  //   setFormData((prev) => ({ ...prev, [name]: maskedValue }));

  //   requestAnimationFrame(() => {
  //     e.target.setSelectionRange(newCursorPosition, newCursorPosition);
  //   });
  // };
  const handleIpInputChange = (e) => {
    const { name, value } = e.target;
    const selectionStart = e.target.selectionStart;

    // Get the current value from state to use as a fallback
    const previousValue = formData[name] || "";

    const { maskedValue, newCursorPosition } = getIpMaskedValueAndPosition(
      value,
      selectionStart,
      previousValue
    );

    // Update the state with the valid (or reverted) value
    setFormData((prev) => ({ ...prev, [name]: maskedValue }));

    // Handle cursor positioning
    requestAnimationFrame(() => {
      const safePosition = Math.min(newCursorPosition, maskedValue.length);
      e.target.setSelectionRange(safePosition, safePosition);
    });
  };
  const handleRadioChange = (e) => {
    setDiscoveryType(e.target.value);
    setFormData({ startIp: "", endIp: "", individualIp: "" });
    setReportData([]);
    setApiRawResponse(null);
    dispatch(resetDiscoveryProgress());
  };

  const validateForm = () => {
    return (
      (discoveryType === "3" &&
        formData.startIp !== "" &&
        formData.endIp !== "" &&
        isValidIpV4(cleanedStartIp) &&
        isValidIpV4(cleanedEndIp) &&
        !isRangeLogicallyInvalid) ||
      (discoveryType === "4" &&
        formData.individualIp !== "" &&
        isValidIpV4(cleanedIndividualIp)) ||
      discoveryType === "5"
    );
  };

  // const executeDiscovery = async (payload) => {
  //   setLoading(true);
  //   setIsProgressOpen(true);
  //   setActiveStep(1);
  //   try {
  //     await new Promise((resolve) => setTimeout(resolve, 1200));
  //     setActiveStep(2);

  //     const response = await TopologyAxios(PERFORM_DISCOVERY, "post", payload);

  //     if (response?.data) {
  //       // The array comes from this property
  //       const statusUpdates = response?.data?.lstResourceInfoBeanDsrvystatus;

  //       console.log("Updating devices with:", statusUpdates);

  //       setApiRawResponse(response.data);

  //       // Check if it's an array before dispatching
  //       if (Array.isArray(statusUpdates)) {
  //         dispatch(updateResourceIp(statusUpdates))
  //         dispatch(updateDiscoveredDeviceStatus(statusUpdates));
  //         dispatch(updateDiscoveredDeviceStatusFabric(statusUpdates));
  //       } else if (statusUpdates && typeof statusUpdates === "object") {
  //         // Fallback if API returns a single object instead of array
  //         dispatch(updateResourceIp(statusUpdates))
  //         dispatch(updateDiscoveredDeviceStatus([statusUpdates]));
  //         dispatch(updateDiscoveredDeviceStatusFabric([statusUpdates]));
  //       }

  //       setReportData(statusUpdates || []);

  //       await Promise.all([
  //         InventoryAxios(FETCH_ALL_RESOURCE_INFO, "get"),
  //         TopologyAxios(FETCH_ALL_PORT_INFO_DETAILS, "get"),
  //       ]);

  //       setActiveStep(3);
  //       await new Promise((resolve) => setTimeout(resolve, 800));
  //       setIsProgressOpen(false);
  //       setIsReportOpen(true);
  //       Toast(
  //         "Success",
  //         "Device Discovery query finished processing",
  //         "success"
  //       );
  //     } else {
  //       throw new Error("No payload parsed natively");
  //     }
  //   } catch (error) {
  //     setActiveStep(0);
  //     setIsProgressOpen(false);
  //     Toast("Error", "Failed to run Device Discovery process.", "error");
  //     console.error(error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const executeDiscovery = async (payload) => {
    setLoading(true);
    setShowStepper(true);
    dispatch(
      setDiscoveryProgress({
        activeStep: 0,
        message: "Starting Device Discovery...",
        percentage: 0,
        isRunning: true,
        socketStage: 0,
      })
    );

    try {
      const response = await TopologyAxios(PERFORM_DISCOVERY, "post", payload);

      if (response?.data) {
        const statusUpdates = response?.data?.lstResourceInfoBeanDsrvystatus;

        console.log("Updating devices with:", statusUpdates);

        setApiRawResponse(response.data);

        if (Array.isArray(statusUpdates)) {
          dispatch(updateResourceIp(statusUpdates));
          dispatch(updateDiscoveredDeviceStatus(statusUpdates));
          dispatch(updateDiscoveredDeviceStatusFabric(statusUpdates));
        } else if (statusUpdates && typeof statusUpdates === "object") {
          dispatch(updateResourceIp(statusUpdates));
          dispatch(updateDiscoveredDeviceStatus([statusUpdates]));
          dispatch(updateDiscoveredDeviceStatusFabric([statusUpdates]));
        }

        setReportData(statusUpdates || []);

        await Promise.all([
          InventoryAxios(FETCH_ALL_RESOURCE_INFO, "get"),
          TopologyAxios(FETCH_ALL_PORT_INFO_DETAILS, "get"),
        ]);

        // Do NOT update progress here.
        // WebSocket stage 3 controls completion.

        setShowStepper(false);
        setIsReportOpen(true);
        Toast(
          "Success",
          "Device Discovery query finished processing",
          "success"
        );
      } else {
        throw new Error("No payload parsed natively");
      }
    } catch (error) {
      dispatch(resetDiscoveryProgress());

      Toast("Error", "Failed to run Device Discovery process.", "error");

      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  const handleDiscoverClick = () => {
    if (validateForm()) {
      setDialogConfig({
        visible: true,
        message: "Are you sure you want to Perform Discovery?",
      });
    }
  };

  const handleConfirmDiscovery = () => {
    setDialogConfig({ visible: false, message: "" });
    let payload = { discoveryType: Number(discoveryType) };
    if (discoveryType === "3") {
      payload.startIp = cleanedStartIp;
      payload.endIp = cleanedEndIp;
    } else if (discoveryType === "4") {
      payload.ipAddress = cleanedIndividualIp;
    }
    executeDiscovery(payload);
  };

  return (
    <MForm title="Device Discovery">
      <RadioGroup value={discoveryType} onChange={handleRadioChange}>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
          {/* RANGE OPTION */}
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              gap: 2,
              alignItems: "flex-start",
            }}
          >
            <Box
              sx={{
                minWidth: { md: "200px" },
                display: "flex",
                alignItems: "center",
              }}
            >
              <FormControlLabel
                value="3"
                control={<Radio color="primary" size="small" />}
                label={<Typography sx={{ fontWeight: 500 }}>Range</Typography>}
              />
            </Box>
            <Box sx={{ flex: 1, display: "flex", gap: 2, width: "100%" }}>
              <FormField
                label="Starting IP"
                disabled={discoveryType !== "3"}
                error={!isStartIpValid}
                value={formData.startIp}
                placeholder="___.___.___.___"
                onChange={handleIpInputChange}
                name="startIp"
              />
              <FormField
                label="Ending IP"
                disabled={discoveryType !== "3"}
                error={!isEndIpValid || isRangeLogicallyInvalid}
                value={formData.endIp}
                placeholder="___.___.___.___"
                onChange={handleIpInputChange}
                name="endIp"
                errorMessage={
                  !isEndIpValid
                    ? "Invalid IPv4 Address"
                    : isRangeLogicallyInvalid
                    ? "Ending IP must be higher than or equal to Starting IP"
                    : ""
                }
              />
            </Box>
          </Box>

          <Box sx={{ mx: -4, width: "calc(100% + 68px)" }}>
            <Divider sx={{ borderBottomWidth: "2px", borderColor: "#eee" }} />
          </Box>

          {/* INDIVIDUAL IP OPTION */}
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              gap: 2,
              alignItems: "flex-start",
            }}
          >
            <Box
              sx={{
                minWidth: { md: "200px" },
                display: "flex",
                alignItems: "center",
              }}
            >
              <FormControlLabel
                value="4"
                control={<Radio color="primary" size="small" />}
                label={
                  <Typography sx={{ fontWeight: 500 }}>
                    Individual IP
                  </Typography>
                }
              />
            </Box>
            <Box sx={{ flex: 1, width: "100%" }}>
              <FormField
                label="IP Address"
                disabled={discoveryType !== "4"}
                error={!isIndividualIpValid}
                value={formData.individualIp}
                placeholder="___.___.___.___"
                onChange={handleIpInputChange}
                name="individualIp"
                errorMessage={
                  !isIndividualIpValid ? "Invalid IPv4 Address" : ""
                }
              />
            </Box>
          </Box>

          <Box sx={{ mx: -4, width: "calc(100% + 68px)" }}>
            <Divider sx={{ borderBottomWidth: "2px", borderColor: "#eee" }} />
          </Box>
          {/* SERIAL DEVICE OPTION */}
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              gap: 2,
              alignItems: "center",
            }}
          >
            <Box
              sx={{
                minWidth: { md: "200px" },
                display: "flex",
                alignItems: "center",
              }}
            >
              <FormControlLabel
                value="5"
                control={<Radio color="primary" size="small" />}
                label={
                  <Typography sx={{ fontWeight: 500 }}>
                    Serial Device
                  </Typography>
                }
              />
            </Box>
          </Box>
        </Box>
      </RadioGroup>

      {/* ACTION BUTTON */}
      <Box sx={{ display: "flex", justifyContent: "flex-start", mt: 4 }}>
        <MButtonPrimary
          variant="contained"
          color="primary"
          startIcon={<PlayArrow />}
          disabled={!validateForm() || loading}
          onClick={handleDiscoverClick}
          sx={{ px: 5 }}
        >
          Discover
        </MButtonPrimary>
      </Box>

      <MDialog
        open={dialogConfig.visible}
        icon={confirmation_icon}
        onClose={() => setDialogConfig({ visible: false, message: "" })}
        title="Confirmation"
        message={dialogConfig.message}
        confirmText="Yes"
        onConfirm={handleConfirmDiscovery}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />

      <DiscoveryProgressOverlay
        isOpen={showStepper}
        activeStep={discoveryProgress.activeStep}
        loading={loading}
        message={discoveryProgress.message}
        isChildFullScreen={isChildFullScreen}
      />

      <DiscoveryReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        reportData={reportData}
        setReportData={setReportData}
        apiRawResponse={apiRawResponse}

      />
    </MForm>
  );
};

export default DeviceDiscovery;
