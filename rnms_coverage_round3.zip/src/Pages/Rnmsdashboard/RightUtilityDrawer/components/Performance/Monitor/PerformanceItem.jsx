/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Monitor
   File Name                : PerformanceAddThreshold.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Performance\Monitor\PerformanceItem.jsx
   Purpose                  : Provides the layout to edit  performance Monitor.
   Created Date             : 24-03-2026
***********************************************************************************************/
import React, { useState, useEffect } from "react";
import { Box, Typography, Switch, IconButton } from "@mui/material";
import { KeyboardArrowUp, KeyboardArrowDown } from "@mui/icons-material";
import MInput from "@/components/Reusable/Input/MInput";
import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";
import {
  MODIFY_PERPARAM_MONITORING_STATUS,
  MODIFY_PERPARAM_MONITORING_TIME_INTERVAL,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MDialog from "@/components/Reusable/Dialog/MDialog";

const LIMIT = { min: 60, max: 300 };
const PerformanceItem = ({ isChildFullScreen,data, deviceId, onRefresh }) => {
  const [groupName, info] = data;
  const [isMonitored, setIsMonitored] = useState(info.monitored);
  const [interval, setInterval] = useState(info.time);
  const [loading, setLoading] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);  
  // 1. State to control the Dialog visibility
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    setIsMonitored(info.monitored);
    setInterval(info.time);
  }, [info]);

  const hasChanged = isMonitored !== info.monitored || interval !== info.time;
  const isInvalid = interval < LIMIT.min || interval > LIMIT.max;

  //  const handleOpenConfirm = () => {
  //   setShowConfirm(true);
  // };

   const executeUpdate = async (type) => {
    setLoading(true);
    const payload = {
      id: info.id,
      timeInterval: interval,
      defaultPollingStatus: info.defaultPollingStatus,
      resourceInfoBean: { resourceId: deviceId },
      perfGroupInfoBean: { groupId: info.groupId },
      moniter: isMonitored,
    };

    try {
      if (type === 'status') {
         await PerformanceAxios(MODIFY_PERPARAM_MONITORING_STATUS, "post", payload);
      } else {
         await PerformanceAxios(MODIFY_PERPARAM_MONITORING_TIME_INTERVAL, "post", payload);
      }
      
      Toast("Success", "Updated successfully", "success");
      onRefresh();
    } catch (error) {
       if (type === 'status') setIsMonitored(info.monitored);
      
      Toast("Error", "Update failed", "error");
      console.error(error);
    } finally {
      setLoading(false);
      setShowConfirm(false);
      setPendingAction(null);
    }
  };
  const handleUpdateIntervalClick = () => {
    setPendingAction('interval');
    setShowConfirm(true);
  };
  const handleToggleChange = (e) => {
    const newValue = e.target.checked;
 
    setPendingAction('status');
    setShowConfirm(true);
    
 
    setIsMonitored(newValue); 
  };
  return (
    <>
       <MDialog
        open={showConfirm}
        variant="info"
        icon={confirmation_icon}
        title="Confirm Action"
        message={
          pendingAction === 'status' 
            ? "Are you sure you want to change the monitoring status?" 
            : "Are you sure you want to update the time interval?"
        }
        onConfirm={() => executeUpdate(pendingAction)}
        onClose={() => {
            setShowConfirm(false);
            setPendingAction(null);
            setIsMonitored(info.monitored);  
        }}
        mode="child"
        isChildFullScreen={isChildFullScreen}
      />

       <Box
        sx={{ border: "2px solid #eee", borderRadius: "12px" }}
        p={2}
        className="grid grid-rows-2 gap-2"
      >
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Typography variant="body2" sx={{   color: (theme) => theme.palette.custom.table.headerText, fontWeight: "600" }}>
            {groupName}
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Typography sx={{  color: (theme) => theme.palette.custom.table.headerText, fontSize: "14px", fontWeight: "500" }}>
              Monitoring
            </Typography>
            <Switch
              size="small"
              checked={isMonitored}
              onChange={handleToggleChange} 
              color="success"
            />
          </Box>
        </Box>

        <Box className="flex space-between" sx={{ alignItems: "center" }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Box sx={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
              <MInput
                value={interval}
                disabled={!isMonitored}
                error={isInvalid}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!isNaN(val)) setInterval(val);
                  else if (e.target.value === "") setInterval(0);
                }}
                placeholder="60-300"
                sx={{
                  "& input": { textAlign: "center", height: 15 },
                  borderRadius: "12%",
                }}
              />
              {isInvalid && (
                <Typography variant="caption" sx={{ color: "error.main", fontSize: "10px", position: "absolute", top: "100%", whiteSpace: "nowrap" }}>
                  {interval < LIMIT.min ? "Min 60s" : "Max 300s"}
                </Typography>
              )}
            </Box>
            
            <Box sx={{ display: "flex", flexDirection: "column", height: 0 ,  alignItems: "center",
           justifyContent: "center",}}>
              <IconButton size="small" onClick={() => setInterval((prev) => prev + 1)} disabled={!isMonitored || interval >= LIMIT.max} sx={{ p: 0,   color: (theme) => theme.palette.custom.table.headerText, }}>
                <KeyboardArrowUp />
              </IconButton>
              <IconButton size="small" onClick={() => setInterval((prev) => prev - 1)} disabled={!isMonitored || interval <= LIMIT.min} sx={{ p: 0,   color: (theme) => theme.palette.custom.table.headerText, }}>
                <KeyboardArrowDown />
              </IconButton>
            </Box>
          </Box>

          <MButtonPrimary
            fullWidth
            variant="contained"
            size="small"
            onClick={handleUpdateIntervalClick} 
            disabled={!hasChanged || isInvalid || loading}
            sx={{
              width: "auto",
              textTransform: "none",
              borderRadius: "8px",
              backgroundColor: "#14348D",
              "&:hover": { backgroundColor: "#0e2566" },
            }}
          >
            {loading ? "Saving..." : "Update"}
          </MButtonPrimary>
        </Box>
      </Box>
    </>
  );
};
 

export default PerformanceItem;
