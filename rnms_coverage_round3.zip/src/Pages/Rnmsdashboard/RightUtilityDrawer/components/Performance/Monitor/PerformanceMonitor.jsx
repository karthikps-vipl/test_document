/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Monitor
   File Name                : PerformanceAddThreshold.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Performance\Monitor\PerformanceItem.jsx
   Purpose                  : Monitors Performance thresholds and allows to edit and updates .
   Created Date             : 08-04-2026
***********************************************************************************************/

import React, { useState, useEffect, useCallback } from "react";
import {
  Box,
  Tabs,
  Tab,
  Grid,
  CircularProgress,
} from "@mui/material";
import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_ALL_PERFORMANCE_PARAM_MONITORING_DETAILS } from "@/RestAPI/url/endpoint";
import PerformanceItem from "./PerformanceItem"; // Import the child

const PerformanceMonitor = () => {
  const [tabValue, setTabValue] = useState(0);
  const [perfData, setPerfData] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchPerfData = useCallback(async () => {
    try {
      const res = await PerformanceAxios(
        FETCH_ALL_PERFORMANCE_PARAM_MONITORING_DETAILS,
        "get"
      );
      if (res?.data) {
        const rawData = res.data;
        const deviceIds = [
          ...new Set(rawData.map((p) => p.resourceInfoBean.resourceId)),
        ];

        const formatted = deviceIds.map((id) => {
          const deviceName = rawData.find(
            (p) => p.resourceInfoBean.resourceId === id
          ).resourceInfoBean.resourceName;
          const infoItems = rawData
            .filter((p) => p.resourceInfoBean.resourceId === id)
            .map((p) => [
              p.perfGroupInfoBean.groupName,
              {
                id: p.id,
                groupId: p.perfGroupInfoBean.groupId,
                defaultPollingStatus: p.defaultPollingStatus,
                time: p.timeInterval,
                monitored: p.moniter,
              },
            ]);
          return { deviceId: id, name: deviceName, info: infoItems };
        });

        setPerfData(formatted);
      }
    } catch (error) {
      console.error("Error loading PM data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPerfData();
  }, [fetchPerfData]);

  if (loading)
    return <CircularProgress sx={{ display: "block", m: "50px auto" }} />;
  if (perfData.length === 0) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", p: 5, color: "text.secondary" }}>
        No performance monitoring data found
      </Box>
    );
  }
  return (
    <Box
      sx={{
        width: "100%",
        border: "2px solid #eee",
        borderRadius: "20px",
        
      }}
    >
      <Tabs
        value={tabValue}
        onChange={(_, val) => setTabValue(val)}
        variant="scrollable"
        scrollButtons="auto"
        sx={{ml:2, "& .MuiTab-root": { textTransform: "none" } ,borderBottom:'2px solid #eee',}}
      >
        {perfData.map((device, idx) => (
          <Tab key={idx} label={device.name} />
        ))}
      </Tabs>

      {/* <Box className="grid grid-cols-3 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-3 gap-1 w-full " p={1}> */}
      <Box
        className="grid gap-1 w-full 
           grid-cols-3 
           max-[1720px]:grid-cols-2 
           max-[1240px]:grid-cols-1 
        "
        p={3}
      >
        {perfData[tabValue]?.info.map((itemData, index) => (
          <Grid item key={index} xs={12} sm={6} md={4}>
            <PerformanceItem
              data={itemData}
              deviceId={perfData[tabValue].deviceId}
              onRefresh={fetchPerfData}
            />
          </Grid>
        ))}
      </Box>
    </Box>
  );
};

export default PerformanceMonitor;
