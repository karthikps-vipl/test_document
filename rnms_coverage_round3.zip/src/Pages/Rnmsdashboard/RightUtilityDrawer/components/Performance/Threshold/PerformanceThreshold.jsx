/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Threshold
   File Name                : PerformanceThreshold.js
   Author                   : ANKITHA - VIPL
   Package                  : D:\NMS_UI_NEW\src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Performance\Threshold\PerformanceThreshold.jsx
   Purpose                  : Manages the performance threshold table and row deletion.
   Created Date             : 30-03-2026
***********************************************************************************************/
import MTable from "@/components/Reusable/Table/MTable";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { PerformanceAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_ALL_THRESHOLD_INFO, DELETE_THRESHOLD_INFO } from "@/RestAPI/url/endpoint"; // Ensure DELETE_THRESHOLD_INFO is imported
import { Box, CircularProgress } from "@mui/material";
 import MDialog from "@/components/Reusable/Dialog/MDialog";
import Toast from "@/components/Reusable/Toast/Toast";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
 
 

const severityConfig = {
    "MAJOR": {
        label: "Major",
        dotGradient: "linear-gradient(135deg, #ffced2 0%, #d75961 100%)"
    },
    "MINOR": {
        label: "Minor",
        dotGradient: "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)"
    },
    "WARNING": {
        label: "Warning",
        dotGradient: "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)"
    },
   
};

const PerformanceThreshold = ({isChildFullScreen, privilegeKey, handleAdd, handleEdit, handleView, refreshTrigger,  }) => {
    const [loading, setLoading] = useState(true);
    const [rowToDelete, setRowToDelete] = useState({ visible: false, row: null });
    const [repTableData, setRepTableData] = useState([]);

    console.log("severityConfig",severityConfig);
    

    // 1. MEMOIZE COLUMNS: This is the most important fix to stop the table from re-mounting
    const columns = useMemo(() => [
        { name: "S. No ", uid: "sno", width: '70px' },
        { name: "Device Name", uid: "resourceName" },
        { name: "Parameter Name", uid: "paramName" },
        { name: "Threshold Comparator", uid: "thresholdComp" },
        { name: "Threshold value", uid: "thrValPrimary" },
        {
            name: "Fault Severity",
            uid: "faultSeverityString",
            width: '130px',
            render: (value) => {
                console.log("value",value)
                const sevConfig = severityConfig[value?.toUpperCase()];
                if (!sevConfig) return value;


                return (
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span
                            style={{
                                width: 12,
                                height: 12,
                                borderRadius: "50%",
                                display: "inline-block",
                                background: sevConfig.dotGradient,
                                flexShrink: 0
                            }}
                        />
                        <span>{value}</span>
                    </div>
                );
            },
        },
        { name: "Actions", uid: "actions" },
    ], []);

    const fetchData = useCallback(async () => {
        // We don't want to set loading(true) if we already have data, 
        // because that causes the table to disappear (the "blink").
        // Only set loading true if it's the very first fetch.
        const isInitialLoad = repTableData.length === 0;
        if (isInitialLoad) setLoading(true);

        try {
            const response = await PerformanceAxios(FETCH_ALL_THRESHOLD_INFO, "get", 1);
            let data = response?.data || [];
            
            // Sort data
            data.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

            const processedData = data.map((Value, index) => ({
                sno: index + 1,
                id: Value.id,
                resourceName: Value?.resourceInfoBean?.resourceName,
                paramName: Value?.perfParamInfoBean?.paramName,
                thresholdComp: Value.thresholdComp,
                thrValPrimary: Value.thrValPrimary,
                faultSeverityString: Value?.faultSeverityString,
                actions: Value.actions,
                resourceInfoBean: Value.resourceInfoBean,
                perfParamInfoBean: Value.perfParamInfoBean,
            }));

            setRepTableData(processedData);
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            setLoading(false);
        }
    }, []); // Dependency on length to detect initial load

    useEffect(() => {
        fetchData();
    }, [refreshTrigger, fetchData]);

    const handleDeleteRow = async (row) => {
        try {
            const res = await PerformanceAxios(`${DELETE_THRESHOLD_INFO}/${row.id}`, "get");
            if (res) {
                setRepTableData((prevData) =>
                    prevData.filter((item) => item.id !== row.id)
                );
                Toast("Success!", "Threshold deleted successfully", "success");
            }
        } catch (error) {
            console.error("Delete failed:", error);
            Toast("Error", "Failed to delete the record", "error");
        }
    };

    // Memoize event handlers to prevent MTable re-renders
    const onHandleAdd = useCallback((row) => handleAdd({ ...row, mode: 'CREATE', title: "Threshold Configuration" }), [handleAdd]);
    const onHandleEdit = useCallback((row) => handleEdit({ ...row, mode: 'EDIT', title: "Modify threshold info details " }), [handleEdit]);
    const onDeleteClick = useCallback((row) => {
        setRowToDelete({ visible: true, row: row });
    }, []);

    return (
        <Box sx={{ position: 'relative' }}>
            
            {/* 2. OVERLAY LOADING: Instead of {loading ? <Spinner/> : <Table/>}, 
                we show the table ALWAYS, and just put a spinner on top. 
                This stops the screen from flickering/blinking. */}
            {loading && (
                <Box sx={{
                    position: 'absolute',
                    top: 0, left: 0, right: 0, bottom: 0,
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    //backgroundColor: 'rgba(255, 255, 255, 0.5)',
                    zIndex: 10,
                    borderRadius: '10px'
                }}>
                    <CircularProgress size={40} />
                </Box>
            )}

            <MTable
                privilegeKey={privilegeKey}
                columns={columns}
                tableData={repTableData}
                showPagination={true}
                hideAdd={false}
                handleDownloadPDF={() => exportToPDF("Threshold Report", columns, repTableData, "Threshold_Report")}
                handleDownloadCSV={() => exportToCSV("Threshold_Export", columns, repTableData)}
                showSearch={true}
                AddText="Add"
                handleAdd={onHandleAdd}
                handleEdit={onHandleEdit}
                handleDelete={onDeleteClick}
                severityConfig={severityConfig} 
            />

            <MDialog
                open={rowToDelete.visible}
                icon={Delete_Icon_}
                variant="error"
                title="Confirm Action"
                confirmText="Yes"
                mode="child"
                isChildFullScreen={isChildFullScreen}
                message="Are you sure you want to delete this threshold?"
                onConfirm={() => {
                    handleDeleteRow(rowToDelete.row);
                    setRowToDelete({ visible: false, row: null });
                }}
                onClose={() => setRowToDelete({ visible: false, row: null })}
            />
        </Box>
    );
};

export default PerformanceThreshold;