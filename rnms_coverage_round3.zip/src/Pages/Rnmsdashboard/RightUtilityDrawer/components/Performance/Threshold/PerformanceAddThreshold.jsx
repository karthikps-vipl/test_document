/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Threshold
   File Name                : PerformanceAddThreshold.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Performance\Threshold\PerformanceAddThreshold.jsx
   Purpose                  : Provides the form to add new performance thresholds.
   Created Date             : 08-03-2026
***********************************************************************************************/

import React, { useEffect, useState } from "react";
import { Box, Typography, CircularProgress } from "@mui/material";
import { useFormik } from "formik";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import {
  FaultAxios,
  InventoryAxios,
  PerformanceAxios,
} from "@/RestAPI/api/axiosApicall";
import {
  FETCH_PERF_PARAM_OF_RESOURCE_TYPE,
  FETCH_RESOURCE_MASTER_TYPE_DETAILS_BY_PROTOTYPE_ID,
  GET_SEVERITY_KEY_VALUE_PAIR,
  FIND_DISCOVERD_RES_BY_DEVICE_TYPE_ID,
  SAVE_THRESHOLD_DATA,
} from "@/RestAPI/url/endpoint";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import { ThresholdSchema } from "@/utility/FormValidation/YupSchema";

// --- IMPORT THE SCHEMA HERE ---

const PerformanceAddThreshold = ({ onClose, onSuccess,onRefresh ,isGrandchildFullScreen}) => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // Dropdown Data States
  const [masterTypes, setMasterTypes] = useState([]);
  const [deviceList, setDeviceList] = useState([]);
  const [perfParams, setPerfParams] = useState([]);
  const [severityOptions, setSeverityOptions] = useState([]);

  // --- FORMIK INITIALIZATION ---
  const formik = useFormik({
    initialValues: {
      resourceMasterType: "",
      resourceId: "",
      paramId: "",
      thresholdComp: "",
      thresholdValue: "",
      faultSeverity: "",
    },
    validationSchema: ThresholdSchema, // Using the imported schema
    onSubmit: (values) => handleSave(values),
  });

  // Load Dropdown Data
  useEffect(() => {
    InventoryAxios(
      FETCH_RESOURCE_MASTER_TYPE_DETAILS_BY_PROTOTYPE_ID,
      "get"
    ).then((res) => setMasterTypes(res.data || []));
    FaultAxios(GET_SEVERITY_KEY_VALUE_PAIR, "get").then((res) =>
      setSeverityOptions(
        Object.entries(res.data || {}).map(([v, l]) => ({ label: l, value: v }))
      )
    );
  }, []);

  // Cascading Logic
  useEffect(() => {
    if (formik.values.resourceMasterType) {
      InventoryAxios(
        `${FIND_DISCOVERD_RES_BY_DEVICE_TYPE_ID}/${formik.values.resourceMasterType}`,
        "get"
      ).then((res) =>
        setDeviceList(res.data?.filter((d) => d.isDiscovered) || [])
      );
      PerformanceAxios(
        `${FETCH_PERF_PARAM_OF_RESOURCE_TYPE}/${formik.values.resourceMasterType}`,
        "get"
      ).then((res) => setPerfParams(res.data || []));
    } else {
      setDeviceList([]);
    }
  }, [formik.values.resourceMasterType]);

  // --- HANDLERS ---
  const handleSave = async (values) => {
    setLoading(true);
    const payload = {
      resourceInfoBean: { resourceId: values.resourceId },
      perfParamInfoBean: { paramId: Number(values.paramId) },
      faultSeverity: String(values.faultSeverity),
      thresholdComp: Number(values.thresholdComp),
      thrValPrimary: String(values.thresholdValue),
    };
  
    try {
      const res = await PerformanceAxios(SAVE_THRESHOLD_DATA, "post", payload);
      // Check if res exists and specifically handle success based on your API structure
      if (res) {
        Toast("Success", "Threshold saved!", "success");
        onSuccess?.();
        onRefresh?.();   
        onClose?.();
      }
    } catch (error) {
      // --- ERROR HANDLING LOGIC ---
      // 1. Try to get message from error.response.data (Standard Axios error pattern)
      // 2. Try to get message from error.message (Generic JS error)
      // 3. Fallback to "Save failed"
      const errorMessage = 
        error?.res?.data?.message || // Common pattern: { message: "Error text" }
        error?.res?.data?.error ||   // Common pattern: { error: "Error text" }
        error?.message ||                 // Generic: "Request failed with status 400"
        "Save failed";
  
      Toast("Error", "Save failed", "error");
      console.error("Full Error Object:", error);
    } finally {
      setLoading(false);
      setShowConfirm(false);
    }
  };
  const triggerConfirm = () => {
    formik.validateForm().then((errors) => {
      formik.setTouched({
        resourceMasterType: true,
        resourceId: true,
        paramId: true,
        thresholdComp: true,
        thresholdValue: true,
        faultSeverity: true,
      });
      if (Object.keys(errors).length === 0) {
        setShowConfirm(true);
      } else {
        Toast("Error", "Please fill all mandatory fields", "error");
      }
    });
  };

  return (
    <Box className="flex flex-col gap-2   " sx={{ ml: 3, mr: 5 }}>
      {/* Device Type */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Device Type *</Typography>
        <MSelect
          placeholder="Select Device Type"
          options={masterTypes.map((t) => ({
            label: t.resourceTypeName,
            value: t.resourceTypeId,
          }))}
          value={formik.values.resourceMasterType}
          errorMessage={
            formik.touched.resourceMasterType &&
            formik.errors.resourceMasterType
          }
          onChange={(v) => {
            formik.setFieldValue("resourceMasterType", v.value);
            formik.setFieldValue("resourceId", "");
            formik.setFieldValue("paramId", "");
          }}
        />
      </Box>

      {/* Device Name */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Device Name *</Typography>
        <MSelect
          placeholder="Select Device Name"
          options={deviceList.map((d) => ({
            label: d.resourceName,
            value: d.resourceId,
          }))}
          value={formik.values.resourceId}
          errorMessage={formik.touched.resourceId && formik.errors.resourceId}
          onChange={(v) => formik.setFieldValue("resourceId", v.value)}
        />
      </Box>

      {/* Parameter */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Parameter *</Typography>
        <MSelect
          placeholder="Select Parameter"
          options={perfParams.map((p) => ({
            label: p.paramName,
            value: p.paramId,
          }))}
          value={formik.values.paramId}
          errorMessage={formik.touched.paramId && formik.errors.paramId}
          onChange={(v) => formik.setFieldValue("paramId", v.value)}
        />
      </Box>

      {/* Comparator */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Comparator *</Typography>
        <MSelect
          placeholder="Select Comparator "
          options={[
            { label: "Equal", value: 0 },
            { label: "Greater Than", value: 1 },
            { label: "Greater Than Equal", value: 2 },
            { label: "Less Than", value: 3 },
            { label: "Less Than Equal", value: 4 },
          ]}
          value={formik.values.thresholdComp}
          errorMessage={
            formik.touched.thresholdComp && formik.errors.thresholdComp
          }
          onChange={(v) => formik.setFieldValue("thresholdComp", v.value)}
        />
      </Box>

      {/* Value */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
  <Typography sx={{ mb: 0.5 }}>Value *</Typography>
  <MInput
    placeholder="Enter numeric value"
    value={formik.values.thresholdValue}
    errorMessage={
      formik.touched.thresholdValue && formik.errors.thresholdValue
    }
    onChange={(e) => {
      const val = e.target.value;
      
      // 1. Allow empty string (so user can delete everything)
      // 2. Allow only digits (0-9) using your regex
      // Note: \b is for word boundary, for digits we just use [0-9]
      if (val === '' || /^[0-9]+$/.test(val)) {
        formik.setFieldValue("thresholdValue", val);
      }
    }}
  />
</Box>

      {/* Severity */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5 }}>Severity *</Typography>
        <MSelect
          placeholder="Select Severity "
          options={severityOptions}
          value={formik.values.faultSeverity}
          errorMessage={
            formik.touched.faultSeverity && formik.errors.faultSeverity
          }
          onChange={(v) => formik.setFieldValue("faultSeverity", v.value)}
        />
      </Box>

      {/* Actions */}
      <Box className="flex justify-end mt-4">
        <MButtonPrimary
          onClick={triggerConfirm}
          disabled={!formik.isValid || !formik.dirty || loading}
        >
          {loading ? <CircularProgress size={20} color="inherit" /> : "Save"}
        </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfirm}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to save this new threshold?"
        onConfirm={() => formik.handleSubmit()}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default PerformanceAddThreshold;
