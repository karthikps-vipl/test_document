/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Threshold
   File Name                : PerformanceEditThreshold.js
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\components\Performance\Threshold\PerformanceEditThreshold.jsx
   Purpose                  : Provides the form to edit performance thresholds.
   Created Date             : 04-03-2026
***********************************************************************************************/

import React, { useEffect, useState } from "react";
import { Box, Typography, CircularProgress } from "@mui/material";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { FaultAxios, PerformanceAxios } from "@/RestAPI/api/axiosApicall";
import { 
    GET_SEVERITY_KEY_VALUE_PAIR, 
    MODIFY_THRESHOLD_DATA 
} from "@/RestAPI/url/endpoint";
import MDialog from "@/components/Reusable/Dialog/MDialog"; // Adjust path as needed
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";

const PerformanceEditThreshold = ({ onClose, onSuccess, data,isGrandchildFullScreen }) => {
    const [loading, setLoading] = useState(false);
    const [severityOptions, setSeverityOptions] = useState([]);
    const [showConfirm, setShowConfirm] = useState(false);
    const originalValues = React.useRef({
        thresholdComp: data?.thresholdComp || "",
        thresholdValue: data?.thrValPrimary !== undefined ? String(data.thrValPrimary) : "",
        faultSeverity: data?.faultSeverityString || ""
    });

    console.log("Incoming Data Prop:", data);
    // 1. Keep the data as Strings/Objects as the old code did
    const [formData, setFormData] = useState({
        id: data?.id || "",
        // Accessing based on the JSON you just provided:
        resourceId: data?.resourceInfoBean?.resourceId || "", 
        resourceName: data?.resourceInfoBean?.resourceName || data?.resourceName || "",
        paramId: data?.perfParamInfoBean?.paramId || "",
        paramName: data?.perfParamInfoBean?.paramName || data?.paramName || "",
        thresholdComp: data?.thresholdComp || "",
        thresholdValue: data?.thrValPrimary !== undefined ? String(data.thrValPrimary) : "",
        // The JSON shows faultSeverity is a number (1), but you might want the string
        faultSeverity: data?.faultSeverityString || ""
    });

    useEffect(() => {
        FaultAxios(GET_SEVERITY_KEY_VALUE_PAIR, "get").then(res => {
            const options = Object.entries(res.data || {}).map(([v, l]) => ({ 
                label: l, 
                value: String(v) 
            }));
            setSeverityOptions(options);

            if (formData.faultSeverity) {
                const matchByLabel = options.find(opt => opt.label === formData.faultSeverity);
                const matchByValue = options.find(opt => opt.value === formData.faultSeverity);
                
                if (matchByLabel && !matchByValue) {
                    setFormData(prev => ({ ...prev, faultSeverity: matchByLabel.value }));
                }
            }
        }).catch(err => console.error("Error fetching severity:", err));
    }, []);

 
    const handleConfirmUpdate = async () => {
        // 1. Map the formData to the exact key structure required by the API
        const payload = {
            id: Number(formData.id), // Ensure ID is a number
            resourceInfoBean: {
                resourceId: formData.resourceId
            },
            perfParamInfoBean: {
                paramId: Number(formData.paramId) // API expects a number
            },
            faultSeverity: formData.faultSeverity, // Keep as string "1" per your example
            thresholdComp: formData.thresholdComp, // "GREATER_THAN_OR_EQUAL"
            thrValPrimary: formData.thresholdValue // API uses this key name instead of thresholdValue
        };
    
        // Log this so you can verify it in the Browser Console before it sends
        console.log("Payload being sent:", payload);
    
        try {
            setLoading(true);
            
            // 2. Send the correctly structured payload
            const response = await PerformanceAxios(MODIFY_THRESHOLD_DATA, "post", payload);
    
            if (response?.data) {
                Toast("Success!", "Threshold updated successfully", "success");
                setShowConfirm(false);
            
                if (onSuccess) {
                    // IMPORTANT: Pass the payload back so the parent knows what changed!
                    onSuccess(payload); 
                }
                onClose();
    
             
            } else {
                Toast("Error!", "Submission Failed", "error");
            }
        } catch (error) {
            console.error("Update Error:", error);
            // Try to catch the specific error message from the backend
            // const errorMsg = error?.response?.data?.detail || error?.response?.data?.message || "Invalid request content";
            Toast("Error!", "Invalid request content", "error");
        } finally {
            setLoading(false);
        }
    };
    const triggerUpdate = () => {
        // Optional: Add validation before showing dialog
        if (!formData.resourceId || !formData.paramId) {
            Toast("Error", "Missing critical ID information", "error");
            return;
        }
        setShowConfirm(true);
    };

    // 3. Updated Options to use Strings as values to match old logic
    const comparatorOptions = [
        { label: "Equal", value: "EQUAL" },
        { label: "Greater Than", value: "GREATER_THAN" },
        { label: "Greater Than Equal", value: "GREATER_THAN_OR_EQUAL" },
        { label: "Less Than", value: "LESS_THAN" },
        { label: "Less Than Equal", value: "LESS_THAN_OR_EQUAL" }
    ];
        // Calculate if anything has changed compared to the Ref
        const isChanged = 
        formData.thresholdComp !== originalValues.current.thresholdComp ||
        String(formData.thresholdValue) !== originalValues.current.thresholdValue ||
        formData.faultSeverity !== originalValues.current.faultSeverity;
    
    return (
        <Box className="flex flex-col  " sx={{ml:3,mr:5}}>
             <Box sx={{ display: 'flex', flexDirection: 'column', height:70,mt:2 }}>

            <Typography sx={{mb:0.5}} color="gray">Device Name</Typography>
            <MInput value={formData.resourceName} disabled />
            
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', height:70,mt:2 }}>

            <Typography sx={{mb:0.5}}  color="gray">Parameter</Typography>
            <MInput value={formData.paramName} disabled />
 </Box>
 <Box sx={{ display: 'flex', flexDirection: 'column', height:70,mt:2 }}>
 <Typography sx={{mb:0.5}}>Comparator</Typography>
            <MSelect
                placeholder="Select comparator"
                options={comparatorOptions}
                value={formData.thresholdComp}
                onChange={(v) => setFormData({ ...formData, thresholdComp: v.value })} 
            />
 </Box>
         
 <Box sx={{ display: 'flex', flexDirection: 'column', mt:2 }}>

            <Typography sx={{mb:0.5}} >Value</Typography>
            <MInput 
              placeholder="Select value"
                type="number"
                value={formData.thresholdValue}
                onChange={(e) => setFormData({ ...formData, thresholdValue: e.target.value })} 
            />
</Box>
<Box sx={{ display: 'flex', flexDirection: 'column', height:70,mt:2 }}>

            <Typography sx={{mb:0.5}}>Severity</Typography>
            <MSelect 
              placeholder="Select Severity"
                options={severityOptions} 
                value={formData.faultSeverity}
                onChange={(v) => setFormData({ ...formData, faultSeverity: v.value })} 
            />
</Box>
            <Box className="flex justify-end mt-4">
            <MButtonPrimary 
    onClick={triggerUpdate} // Change from handleUpdate to triggerUpdate
    disabled={loading || !isChanged} 
>
    {loading ? <CircularProgress size={20} color="inherit" /> : "Update"}
</MButtonPrimary>
            </Box>
            <MDialog
    open={showConfirm}
    variant="info"
    icon={Confirmation_icon}
    title="Confirm Update"
    mode="grandchild"
    isGrandchildFullScreen={isGrandchildFullScreen}

    message="Are you sure you want to update this threshold?"
    onConfirm={handleConfirmUpdate} // Calls the API logic
    onClose={() => setShowConfirm(false)}
    
/>
        </Box>
    );
};

export default PerformanceEditThreshold;