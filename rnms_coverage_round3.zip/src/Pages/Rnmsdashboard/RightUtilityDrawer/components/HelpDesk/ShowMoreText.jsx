
import React, { useState } from "react";
import { Box, Typography } from "@mui/material";
import { ChatBubble } from "./ChatBubble"; // Adjust path to where your ChatBubble is

const MAX_TEXT_LENGTH = 50;

const ShowMoreText = ({ element, ticketStatusIdMapping, side = "left" }) => {
  const [showText, setShowText] = useState(false);

  if (!element || !element.hdTicketStatus) return null;

  const renderLimitedText = (text, length) => {
    if (!text) return "";
    if (text.length > length && !showText) {
      return text.slice(0, length) + "...";
    }
    return text;
  };

  const getStatusColor = (id) => {
    const colors = {
      1: "#ff7290",
      2: "#f39c11",
      3: "#ff7f50",
      4: "#00c0ef",
      5: "#00a65a",
    };
    // If id is "6" or "reopen", it falls into this default:
    return colors[id] || "#db32bc"; 
};
  const dateFormat = (dateString) => {
    if (!dateString) return "";
    
    const date = new Date(dateString);
  
     if (isNaN(date.getTime())) return "";
  
     const day = date.getDate().toString().padStart(2, '0');
    
    // 'en-GB' uses day-month-year. 'lowercase' via options or manual transform.
    const month = date.toLocaleString('en-GB', { month: 'short' }).toLowerCase();
    
    const year = date.getFullYear();
    
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
  
    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
  };
  return (
 <Box  >   
<ChatBubble side={side} >
      <Box>
      
        <Typography
          variant="subtitle2"
          sx={{
            fontWeight: "bold",
            color: getStatusColor(element.hdTicketStatus.id),
            // If side is right (user), we might want to adjust text color 
            // so it doesn't clash with primary background
            ...(side === "right" && { color: "inherit" }), 
          }}
        >
          {ticketStatusIdMapping[element.hdTicketStatus.id] || "Unknown Status"}
        </Typography>

       
       

        {/* Statement */}
        <Typography 
          variant="body2" 
          sx={{ 
            color: side === "right" ? "inherit" : "text.primary",
            whiteSpace: "pre-wrap" 
          }}
        >
          {renderLimitedText(element.statement, MAX_TEXT_LENGTH)}
        </Typography>

        {/* Show More/Less Toggle (Cleaned up duplicate logic) */}
        {element.statement?.length > MAX_TEXT_LENGTH && (
          <Typography
            variant="caption"
            sx={{
              display: "block",
              fontWeight: "bold",
              cursor: "pointer",
              fontSize: "0.75rem",
              marginTop: "4px",
              textAlign: side === "right" ? "left" : "right", // Align toggle opposite to bubble side
              color: side === "right" ? "rgba(255,255,255,0.8)" : "primary.main",
            }}
            onClick={() => setShowText(!showText)}
          >
            {showText ? "show less" : "show more"}
          </Typography>
        )}
      </Box>
      
    </ChatBubble>
    <Box sx={{display:'flex',justifyContent: "flex-end"}}>
    <Typography variant="caption" color="textSecondary"sx={{ mb: 0.5 ,mr:7}}>
 {element.date ? dateFormat(element.date) : ""}  
</Typography>
    </Box>
  
  </Box>
    
    
  );
};

export default ShowMoreText;