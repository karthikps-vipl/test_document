
import React, { useMemo } from "react";
import {

  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Label
} from "recharts"; // Change this import string if using a custom wrapper / Tailwind setup
import { exportSingleChartWithTable } from "@/components/Reusable/Pdf/downloadPdf";
//import { exportSingleChartWithTable } from "./exportUtils";
import { Box, useTheme } from "@mui/material";
import download from "@/assets/SVGIcons/download.svg"

const HelpDeskChart = ({ tableData = [] }) => {

  // 1. Calculations for Pie Chart Data Array
  const pieData = useMemo(() => {
    if (!tableData.length) return [];
    const totals = { Major: 0, Minor: 0, Warning: 0 };

    tableData.forEach((item) => {
      const val = item.priority?.toUpperCase();
      if (val === "MAJOR") totals.Major += 1;
      else if (val === "MINOR") totals.Minor += 1;
      else if (val === "WARNING") totals.Warning += 1;
    });

    return Object.keys(totals)
      .map((key) => ({ name: key, value: totals[key] }))
      .filter((item) => item.value > 0);
  }, [tableData]);

  // 2. Calculations for Bar Chart Data Array
  const statusData = useMemo(() => {
    if (!tableData.length) return [];
    const statusCounts = tableData.reduce((acc, item) => {
      const status = item.status || "Unknown";
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});
    return Object.keys(statusCounts).map((key) => ({
      name: key,
      count: statusCounts[key],
    }));
  }, [tableData]);

   
 

  // SVG Linear Color Gradients Configs
  const Gradients = (
    <defs>
      <linearGradient id="majorGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#D75961" />
        <stop offset="100%" stopColor="#FFCED2" />
      </linearGradient>
      <linearGradient id="minorGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#BDBD32" />
        <stop offset="100%" stopColor="#FFFF00" />
      </linearGradient>
      <linearGradient id="warningGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="19%" stopColor="#007C7C" />
        <stop offset="100%" stopColor="#72FFFF" />
      </linearGradient>
    </defs>
  );

  const getColor = (name) => {
    if (name === "Major") return "url(#majorGrad)";
    if (name === "Minor") return "url(#minorGrad)";
    if (name === "Warning") return "url(#warningGrad)";
    return "#cccccc";
  };

  // --- Click Actions (Safe clean invocations bypassing raw event arguments) ---
  const handlePieDownload = () => {
    if (pieData.length === 0) return; // Safety check
    const columns = [
      { header: "Severity Level", dataKey: "name" },
      { header: "Total Count", dataKey: "value" }
    ];
    exportSingleChartWithTable(
      "Pie Chart Summary (Based on Priority)",
      columns,
      pieData,
      "pie-chart-container",
      "Priority_Distribution"
    );
  };

  const handleBarDownload = () => {
    if (statusData.length === 0) return; // Safety check
    const columns = [
      { header: "Ticket Status", dataKey: "name" },
      { header: "Total Count", dataKey: "count" }
    ];
    exportSingleChartWithTable(
      "Bar Chart Summary (Ticket Status Breakdown)",
      columns,
      statusData,
      "bar-chart-container",
      "Status_Matrix_Report"
    );
  };

  const theme = useTheme()
  const chartColors = theme.palette.custom.chart;

  return (
    <Box style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '12px', width: '100%' }}>

      {/* Pie Chart Container */}
      <Box id="pie-chart-container" style={{ position: 'relative', padding: '12px', borderRadius: '10px', border: '1px solid #E5E7EB', height: '230px' }} sx={{ background: theme.palette.custom.chart.chartbg }}>
        <h3 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600' }}>Piechart (Based on Priority)</h3>

        {/* Notice the arrow function format: () => handlePieDownload() */}
        <button
          onClick={() => handlePieDownload()}
          disabled={pieData.length === 0}
          className="download-btn-cls"
          style={{
            position: 'absolute', top: '8px', right: '8px',
            zIndex: 10, border: '1px solid #D1D5DB'
            , padding: '4px', borderRadius: '4px',
            cursor: pieData.length === 0 ? 'not-allowed' : 'pointer',
            opacity: pieData.length === 0 ? 0.5 : 1,
            backgroundColor: pieData.length === 0 ? '#f3f4f6' : 'transparent'
          }}
          title={pieData.length > 0 ? "Download Priority Report" : "No data to download"}
        >
          <img src={download} alt="Download" style={{
            width: '16px',
            height: '16px', display: 'block',
            filter: pieData.length === 0 ? 'grayscale(100%)' : theme.palette.custom.icon.iconFilter
          }} />
        </button>

        <Box style={{ width: '100%', height: '180px', }}
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              {Gradients}
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                dataKey="value"
                isAnimationActive={false}
                label={({ cx, cy, midAngle, outerRadius, percent }) => {
                  const RADIAN = Math.PI / 180;
                  const radius = outerRadius * 0.55;
                  const x = cx + radius * Math.cos(-midAngle * RADIAN);
                  const y = cy + radius * Math.sin(-midAngle * RADIAN);
                  return (
                    <text x={x} y={y} fill="#000000" textAnchor="middle" dominantBaseline="central" style={{ fontSize: '11px', fontWeight: 'bold' }}>
                      {`${(percent * 100).toFixed(0)}%`}
                    </text>
                  );
                }}
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(entry.name)} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} Units`, 'Volume']} contentStyle={{
                borderRadius: "8px",
                border: "none",
                boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                backgroundColor: chartColors.tooltipBg,
                color: chartColors.tooltipText, // Use theme tooltip text
              }} />
              <Legend verticalAlign="top" align="right" layout="vertical" iconType="circle" wrapperStyle={{ fontSize: "11px" }} />
            </PieChart>
          </ResponsiveContainer>
          
        </Box>
      </Box>

      {/* Bar Chart Container */}
      <Box id="bar-chart-container" style={{ position: 'relative', padding: '12px', borderRadius: '10px', border: '1px solid #E5E7EB', height: '230px' }} sx={{ background: theme.palette.custom.chart.chartbg }}>
        <h3 style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: '600' }}>Bar Chart (Based on Ticket Status)</h3>

        {/* Notice the arrow function format: () => handleBarDownload() */}
        <button
          onClick={() => handleBarDownload()}
          disabled={statusData.length === 0}
          className="download-btn-cls"
          style={{
            position: 'absolute', top: '8px', right: '8px',
            zIndex: 10, cursor: statusData.length === 0 ? 'not-allowed' : 'pointer', border: '1px solid #D1D5DB',
            padding: '4px', borderRadius: '4px',
            opacity: statusData.length === 0 ? 0.5 : 1,
            backgroundColor: statusData.length === 0 ? '#f3f4f6' : 'transparent'
          }}
          title={statusData.length > 0 ? "Download Status Report" : "No data available to download "}
        >
          <img src={download} alt="Download" style={{
            width: '16px',
            height: '16px', display: 'block',
            filter: statusData.length === 0 ? 'grayscale(100%)' : theme.palette.custom.icon.iconFilter
          }} />
        </button>

        <Box style={{ width: '100%', height: '180px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={statusData} margin={{ bottom: 15, top: 10, left: -15, right: 10 }} barSize={22}>
              {Gradients}
              <CartesianGrid vertical={false} stroke={chartColors.grid} />
              <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false}>
                <Label value="Ticket Status" position="bottom" offset={0} style={{ fontSize: '11px', fill: theme.palette.text.primary }} />
              </XAxis>
              <YAxis fontSize={10} axisLine={false} tickLine={false} allowDecimals={false}>
                <Label value="Count" angle={-90} position="insideLeft" offset={-5} style={{ fontSize: '11px', fill: theme.palette.text.primary }} />
              </YAxis>
              <Tooltip cursor={{ fill: chartColors.cursor }} contentStyle={{
                borderRadius: "8px",
                border: "none",
                boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
                backgroundColor: chartColors.tooltipBg,
                color: chartColors.tooltipText, // Use theme tooltip text
              }} />
              <Bar dataKey="count" fill="url(#warningGrad)" radius={[4, 4, 0, 0]} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </Box>
      </Box>
    </Box>
  );
};

export default HelpDeskChart;