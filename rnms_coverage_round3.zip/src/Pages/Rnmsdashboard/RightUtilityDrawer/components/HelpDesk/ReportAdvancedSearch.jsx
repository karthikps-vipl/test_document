
import React, { useEffect, useState } from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Box,
  Typography,
  Stack,
  Chip,
  useTheme,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import Help_Desk_AdvanceSearch from "@/assets/SVGIcons/Help_Desk_AdvanceSearch.svg";

import {
  FETCH_CNMS_ADDRESS_DETAILS,
  FETCH_UNIQUE_USER_LIST,
  GET_ALL_STATUS,
  GET_SEVERITY_KEY_VALUE_PAIR,
} from "@/RestAPI/url/endpoint";

import {
  FaultAxios,
  HelpDeskAxios,
  InventAxios,
} from "@/RestAPI/api/axiosApicall";

import MInput from "@/components/Reusable/Input/MInput";
import MSelect from "@/components/Reusable/Select/MSelect";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

const ReportAdvancedSearch = ({ data = [], setFilteredData }) => {
  const [expanded, setExpanded] = useState(false);

  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const [priority, setPriority] = useState(null);
  const [status, setStatus] = useState(null);
  const [user, setUser] = useState(null);

  const [priorityOptions, setPriorityOptions] = useState([]);
  const [statusOptions, setStatusOptions] = useState([]);
  const [userOptions, setUserOptions] = useState([]);

  const [targetHost, setTargetHost] = useState("");
  console.log("data", data[0])

  const port = import.meta.env.PROD ? "9012" : "8786"

  // ---------------- HOST ----------------
  useEffect(() => {
    const fetchHost = async () => {
      try {
        const res = await InventAxios(FETCH_CNMS_ADDRESS_DETAILS, "get");
        const addr = res?.data?.address;
        console.log("addr",res)

        if (addr) {
          setTargetHost(addr.includes(":") ? addr : `${addr}:${port}`);
        }
      } catch (e) {
        console.log(e);
      }
    };

    fetchHost();
  }, []);

  // ---------------- PRIORITY ----------------
  useEffect(() => {
    const fetchPriority = async () => {
      try {
        const res = await FaultAxios(GET_SEVERITY_KEY_VALUE_PAIR, "get");

        const options = Object.entries(res?.data || {}).map(([id, value]) => ({
          id,
          label: value,
          value,
        }));

        setPriorityOptions(options);
      } catch (e) {
        console.log(e);
      }
    };

    fetchPriority();
  }, []);

  // ---------------- STATUS ----------------
  useEffect(() => {
    if (!targetHost) return;

    const fetchStatus = async () => {
      try {
        const res = await HelpDeskAxios(
          GET_ALL_STATUS,
          "get",
          null,
          null,
          targetHost
        );
        console.log("GET_ALL_STATUS", res)
        const arr = Array.isArray(res?.data)
          ? res.data
          : Object.values(res?.data || {});

        const options = arr.map((item) => ({
          id: item.id,
          label: item.statusName,
          value: item.statusName,
        }));

        setStatusOptions(options);
      } catch (e) {
        console.log(e);
      }
    };

    fetchStatus();
  }, [targetHost]);

  // ---------------- USERS ----------------
  useEffect(() => {
    if (!targetHost) return;

    const fetchUsers = async () => {
      try {
        const res = await HelpDeskAxios(
          FETCH_UNIQUE_USER_LIST,
          "get",
          null,
          null,
          targetHost
        );

        const arr = Array.isArray(res?.data)
          ? res.data
          : Object.values(res?.data || {});

        setUserOptions(
          arr.map((u) => ({
            label: u,
            value: u,
          }))
        );
      } catch (e) {
        console.log(e);
      }
    };

    fetchUsers();
  }, [targetHost]);

  // ---------------- RUN FILTERS ----------------
  const applyFilter = () => {
    let filtered = [...data];

    // 1. Priority Filter
    if (priority && priority.value) {
      filtered = filtered.filter(
        (item) => String(item.priority).toLowerCase() === String(priority.value).toLowerCase()
      );
    }

    // 2. Status Filter
    if (status && status.value) {
      filtered = filtered.filter(
        (item) => String(item.status).toLowerCase() === String(status.value).toLowerCase()
      );
    }

    // 3. User Filter
    if (user && user.value) {
      filtered = filtered.filter((item) =>
        item.hdTicketSubDetails?.some(
          (sub) => String(sub.searchUser).toLowerCase() === String(user.value).toLowerCase()
        )
      );
    }

    if (fromDate || toDate) {
      filtered = filtered.filter((item) => {
        const subDetail = item.hdTicketSubDetails && item.hdTicketSubDetails.length > 0
          ? item.hdTicketSubDetails[0]
          : null;

        const rawDate = subDetail?.date;

        if (!rawDate) return false;

        const ticketDate = new Date(rawDate);
        if (isNaN(ticketDate.getTime())) return false;

        if (fromDate) {
          const startOfFromDate = new Date(`${fromDate}T00:00:00`);
          if (ticketDate < startOfFromDate) return false;
        }

        if (toDate) {
          const endOfToDate = new Date(`${toDate}T23:59:59.999`);
          if (ticketDate > endOfToDate) return false;
        }

        return true;
      });
    }

    setFilteredData(filtered);
    setExpanded(false);
  };

  const clearFilters = () => {
    setFromDate("");
    setToDate("");
    setPriority(null);
    setStatus(null);
    setUser(null);
    setFilteredData(data);
  };

  const theme = useTheme();

  return (
    <Accordion expanded={expanded}>
      <AccordionSummary
        expandIcon={
          <img
            src={Help_Desk_AdvanceSearch}
            alt=""
            style={{ filter: theme.palette.custom.icon.iconFilter }}
          />
        }
        onClick={() => setExpanded((p) => !p)}
      >
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', width: '100%' }}>
          <Typography sx={{ color: theme.palette.text.TitleTextcolor }}>
            Advanced Search
          </Typography>

          {/* Active Chips Section */}
          <Stack direction="row" spacing={1} sx={{ mt: 1, flexWrap: 'wrap', gap: 1 }}>
            {priority && <Chip label={`Priority: ${priority.value}`} size="small" onDelete={() => setPriority(null)} />}
            {status && <Chip label={`Status: ${status.value}`} size="small" onDelete={() => setStatus(null)} />}
            {user && <Chip label={`User: ${user.value}`} size="small" onDelete={() => setUser(null)} />}
            {fromDate && <Chip label={`From: ${fromDate}`} size="small" onDelete={() => setFromDate("")} />}
            {toDate && <Chip label={`To: ${toDate}`} size="small" onDelete={() => setToDate("")} />}

            {(priority || status || user || fromDate || toDate) && (
              <Chip
                label="Clear All"
                color="error"
                onClick={clearFilters}
                size="small"
                sx={{ cursor: 'pointer' }}
              />
            )}
          </Stack>
        </Box>
      </AccordionSummary>

      <AccordionDetails>
        <Box className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 items-end">
          {/* From Date */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 500 }}>
              From Date
            </Typography>
            <MInput
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
            />
          </Box>

          {/* To Date */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 500 }}>
              To Date
            </Typography>
            <MInput
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
            />
          </Box>

          {/* Priority */}
          <MSelect
            placeholder="Priority"
            options={priorityOptions}
            value={priority}
            onChange={setPriority}
          />

          {/* Status */}
          <MSelect
            placeholder="Status"
            options={statusOptions}
            value={status}
            onChange={setStatus}
          />

          {/* User */}
          <MSelect
            placeholder="User"
            options={userOptions}
            value={user}
            onChange={setUser}
          />

          {/* Filter Button */}
          <MButtonPrimary
            startIcon={<SearchIcon />}
            onClick={applyFilter}
            sx={{
              height: "45px",
              width: "100%",
            }}
          >
            Filter
          </MButtonPrimary>
        </Box>
      </AccordionDetails>
    </Accordion>
  );
};

export default ReportAdvancedSearch;
