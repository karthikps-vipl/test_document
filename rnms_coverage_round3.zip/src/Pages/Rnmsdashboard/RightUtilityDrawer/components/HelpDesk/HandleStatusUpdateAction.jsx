import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Box, Typography, CircularProgress, useTheme } from "@mui/material";
import { UPDATE_TICKET } from "@/RestAPI/url/endpoint";
import { HelpDeskAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import TextArea from "antd/es/input/TextArea";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";


const HandleStatusUpdateAction = ({
  id,
  mode, // e.g., "IN_PROGRESS", "RESOLVED", "PENDING"
  onClose,
  onRefresh,
  ticketData,
  isChildFullScreen
}) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [description, setDescription] = useState("");
  const [descError, setDescError] = useState("");

  const theme = useTheme();
  const userName = useSelector((state) => state.userSlice.userDetails.data.userName);

console.log("mode",mode)
console.log("mode id",id)

  const STATUS_MAP = {
    IN_PROGRESS: { id: 2, name: "In Progress" },
    PENDING: { id: 3, name: "Pending" },
    RESOLVED: { id: 4, name: "Resolved" },
  };

  const validateDescription = (e) => {
    let value = e.target.value;
    if (value.length > 255) value = value.slice(0, 255);

    // Regex cleaning logic from your original code
    value = value.replace(/[^a-zA-Z\d\._\-\s,]/g, "");
    const firstTwo = value.slice(0, 2);
    if (/[^a-zA-Z]/.test(firstTwo)) {
      const part1 = value.slice(0, 2).replace(/[^a-zA-Z]/g, "");
      const part2 = value.slice(2);
      value = part1 + part2;
    }

    setDescription(value);

    if (value.length === 0) {
      setDescError("");
    } else if (value.length < 2) {
      setDescError("First 2 characters must be text (letters)");
    } else {
      const firstTwoAreLetters = /^[a-zA-Z]{2}/.test(value);
      setDescError(!firstTwoAreLetters ? "Must start with 2 letters" : "");
    }
  };

  const updateTicket = async () => {
    // Use ticketId (the Ticket) instead of id (which might be the status)
    const actualTicketId = ticketData?.ticketId || id; 
  
    if (!actualTicketId) {
      alert("Error: Missing Ticket ID");
      return;
    }
  
    const normalizedMode = mode.toUpperCase().replace("-", "_");
    const targetStatus = STATUS_MAP[normalizedMode];
  
    if (!targetStatus) {
      console.error("Mapping Error: Mode", mode, "not found in STATUS_MAP");
      Toast("Error", "Invalid status mode selected", "error");
      return;
    }
  
    const lastSubDetail =
      ticketData?.hdTicketSubDetails?.length > 0
        ? ticketData.hdTicketSubDetails[ticketData.hdTicketSubDetails.length - 1]
        : null;
    
    const currentSequenceNum = lastSubDetail?.sequenceNum || 1;
    const currentLoggedUser = lastSubDetail?.loggedinUser || userName || "system";
  
    const payload = {
      hdTicketStatus: {
        // This sends the ID of the NEW status (e.g., 4 for Resolved)
        id: String(targetStatus.id), 
      },
      hdTicketDetail: {
        // This sends the ID of the actual Ticket
        id: String(actualTicketId), 
      },
      sequenceNum: currentSequenceNum,
      statement: description,
      loggedinUser: currentLoggedUser,
    };
  
    try {
      setLoading(true);
      console.log("Sending Payload:", payload);
  
      const response = await HelpDeskAxios(UPDATE_TICKET, "post", payload);
  
      if (response.status === 200 || response.status === 201) {
        Toast("Success!", `Ticket moved to ${targetStatus.name} successfully!`, "success");
        await onRefresh?.();
        onClose?.();
        setShowConfirm(false);
      } else {
        Toast("Error!", "Failed to update status", "error");
      }
    } catch (error) {
      console.error("API Error:", error.response?.data || error.message);
      Toast("Error!", "An error occurred while updating", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ borderRadius: "10px" }}>
      <Typography sx={{ fontFamily: "Montserrat", fontWeight: 500 }}>
        Status Update Remark *
      </Typography>

      <TextArea
        rows={6}
        value={description}
        placeholder={`Enter comments to move to ${mode.replace("_", " ").toLowerCase()}...`}
        onChange={validateDescription}
        className={theme.palette.mode === "dark" ? "dark-ant-textarea" : ""}
        style={{
          resize: "none",
          borderColor: descError ? "#ff4d4f" : "#d9d9d9",
          fontFamily: "Montserrat",
          width: "100%",
          background: theme.palette.mode === "dark" ? "#333333" : "#ffffff",
          color: theme.palette.mode === "dark" ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
        }}
      />

      <Typography
        variant="caption"
        sx={{ color: descError ? "#e75656" : "textSecondary" }}
      >
        {descError ? descError : `${description.length}/255`}
      </Typography>

      <Box sx={{ display: "flex", justifyContent: "end", mt: 2 }}>
        <MButtonPrimary
          disabled={loading || description.length < 2}
          onClick={() => setShowConfirm(true)}
        >
          {loading ? <CircularProgress size={24} color="inherit" /> : "  Update"}
        </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfirm}
        mode="child"
        isChildFullScreen={isChildFullScreen}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Status Change"
        message={`Are you sure you want to update this ticket to ${mode.replace("_", " ").toLowerCase()}?`}
        onConfirm={updateTicket}
        onClose={() => setShowConfirm(false)}
      />
    </Box>
  );
};

export default HandleStatusUpdateAction;