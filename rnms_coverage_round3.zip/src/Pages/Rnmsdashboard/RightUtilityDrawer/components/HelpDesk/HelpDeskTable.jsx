
import MTable from "@/components/Reusable/Table/MTable";
import { Box } from "@mui/system";
import { exportToCSV, exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import { useCallback, useEffect, useState } from "react";
import { HelpDeskAxios, InventAxios } from "@/RestAPI/api/axiosApicall";
import { GET_ALL_TICKET_FOR_GIVEN_REMOTE_ID, FETCH_CNMS_ADDRESS_DETAILS, GET_ALL_TICKET } from "@/RestAPI/url/endpoint";
import { useSelector } from "react-redux";
import { CircularProgress } from "@mui/material";
import MModal from "@/components/Reusable/Modal/MModal";
import HandleReopenAction from "./HandleReopenAction";
import HandleCloseAction from "./HandleCloseAction";
import HandleStatusUpdateAction from "./HandleStatusUpdateAction";
const HelpDeskTable = ({
  privilegeKey,
  handleDownload,
  refreshTrigger,
  tableData,
  setTableData,
  handleReopenAction,
  handleHistory,
  handleAdd,
  handleView,
  handleCloseAction,
  handlePendingAction,
}) => {
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedViewRow, setSelectedViewRow] = useState(null);

  const { isCnms } = useSelector(
    (state) => state.nodeDetails
  );

  const port = import.meta.env.PROD ? "9012" : "8786"

  const isCnmsActive =
    isCnms === true || isCnms === "true";

  const statusConfig = [
    { title: "Open", value: "Open", color: "#ff7290" },
    {
      title: "In-Progress",
      value: "In-Progress",
      color: "#f39c11",
    },
    {
      title: "Pending",
      value: "Pending",
      color: "#ff7f50",
    },
    {
      title: "Resolved",
      value: "Resolved",
      color: "#00c0ef",
    },
    {
      title: "Closed",
      value: "Closed",
      color: "#00a65a",
    },
    {
      title: "Reopen",
      value: "Reopen",
      color: "#db32bc",
    },
  ];

  const severityConfig = {
    MAJOR: {
      label: "Major",
      dotGradient:
        "linear-gradient(135deg, #ffced2 0%, #d75961 100%)",
    },
    MINOR: {
      label: "Minor",
      dotGradient:
        "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)",
    },
    WARNING: {
      label: "Warning",
      dotGradient:
        "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)",
    },
  };

  // const getStatus = (row) =>
  //   (
  //     row?.hdTicketStatus?.statusName ||
  //     row?.status ||
  //     ""
  //   )
  //     .toLowerCase()
  //     .trim();


  const getStatusText = (row) => {
    // Priority 1: hdTicketStatus.statusName (From your API)
    // Priority 2: status (Fallback)
    // Priority 3: Empty string
    const status = row?.hdTicketStatus?.statusName || row?.status || "";

    // Ensure we return a lowercase string for easy comparison
    return status ? status.toLowerCase().trim() : "";
  };

  const isOpen = (row) => getStatusText(row) === "open";
  // const isInProgress = (row) => getStatusText(row) === "in-progress";
  const isPending = (row) => getStatusText(row) === "pending";
  const isResolved = (row) => getStatusText(row) === "resolved";
  const isClosed = (row) => getStatusText(row) === "closed";


  const columns = [
    {
      name: "S. No ",
      uid: "sno",
      width: "70px",
    },
    {
      name: "Ticket No ",
      uid: "id",
      width: "90px",
    },
    {
      name: "Alarm Details",
      uid: "ticketAlarmDetail",
      width: "120px",
    },
    {
      name: "Ticketed Device ",
      uid: "ticketedDevice",
      width: "240px",
    },
    {
      name: "Priority",
      uid: "priority",
      filterType: "dropdown",
      width: "130px",
      render: (value) => {
        const sevConfig =
          severityConfig[value?.toUpperCase()];

        if (!sevConfig) return value;

        return (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <span
              style={{
                width: 12,
                height: 12,
                borderRadius: "50%",
                display: "inline-block",
                background: sevConfig.dotGradient,
                flexShrink: 0,
              }}
            />
            <span>{value}</span>
          </div>
        );
      },
    },
    {
      name: "Status",
      uid: "status",
      width: "120px",
      filterType: "dropdown",
      render: (value) => {
        const config = statusConfig.find(
          (s) =>
            s.title.toLowerCase() ===
            value?.toLowerCase()
        );

        return (
          <span
            style={{
              color: config
                ? config.color
                : "inherit",
              fontWeight: "600",
            }}
          >
            {value}
          </span>
        );
      },
    },
    {
      name: "Actions",
      uid: "actions",
      sortable: false,
      cellClassName: "sticky-actions",
      headerClassName: "sticky-actions",
      width: isCnmsActive
        ? "250px"
        : "150px",
    },
  ];

  const subDetailColumns = [
    {
      name: "Seq No.",
      uid: "sequenceNum",
      width: "90px",
    },
    {
      name: "User",
      uid: "loggedinUser",
      width: "140px",
    },
    {
      name: "Comment",
      uid: "statement",
      width: "220px",
    },
    {
      name: "Date",
      uid: "date",
      width: "250px",
      render: (value) => {
        if (!value) return "-";

        const dateObj = new Date(value);

        if (isNaN(dateObj.getTime())) {
          return value;
        }

        const day = String(
          dateObj.getDate()
        ).padStart(2, "0");

        const month = dateObj.toLocaleString(
          "en-GB",
          {
            month: "short",
          }
        );

        const year = dateObj.getFullYear();

        const time = dateObj
          .toTimeString()
          .split(" ")[0];

        return `${day}-${month}-${year} ${time}`;
      },
    },
    {
      name: "Status",
      uid: "statusName",
    },
  ];

  const remoteId = useSelector(
    (state) =>
      state.nodeDetails?.repDetails?.id
  );

  const fetchData = useCallback(
    async () => {
      if (!remoteId && !isCnmsActive) {
        return;
      }

      setLoading(true);

      try {
        const addressResponse =
          await InventAxios(
            FETCH_CNMS_ADDRESS_DETAILS,
            "get"
          );

        const fetchedAddress =
          addressResponse?.data?.address;

        if (!fetchedAddress) {
          console.error(
            "!!! ABORTED: Address not found"
          );
          return;
        }

        const targetHost =
          fetchedAddress.includes(":")
            ? fetchedAddress
            : `${fetchedAddress}:${port}`;

        let response;

        if (isCnmsActive) {
          response = await HelpDeskAxios(
            GET_ALL_TICKET,
            "get",
            null,
            null,
            targetHost

          );
          console.log("GET_ALL_TICKET", response)
        } else {
          response =
            await HelpDeskAxios(
              `${GET_ALL_TICKET_FOR_GIVEN_REMOTE_ID}/${remoteId}`,
              "get",
              null,
              null,
              targetHost
            );
        }

        const data = response?.data || [];

        const processedData = data.map(
          (item, index) => ({
            ...item,
            sno: index + 1,
            priority:
              item.hdTicketPriority
                ?.priority ||
              item.priority ||
              "N/A",
            status:
              item.hdTicketStatus
                ?.statusName ||
              item.status ||
              "N/A",
            filterDate:
              item.hdTicketSubDetails?.[0]
                ?.date ||
              item.date,
            hdTicketSubDetails:
              item.hdTicketSubDetails?.map(
                (sub) => {
                  let displayDate =
                    sub.date;

                  if (sub.date) {
                    const d = new Date(
                      sub.date
                    );

                    if (
                      !isNaN(
                        d.getTime()
                      )
                    ) {
                      const day = String(
                        d.getDate()
                      ).padStart(
                        2,
                        "0"
                      );

                      const month =
                        d.toLocaleString(
                          "en-GB",
                          {
                            month: "short",
                          }
                        );

                      const year =
                        d.getFullYear();

                      const time = d
                        .toTimeString()
                        .split(" ")[0];

                      displayDate = `${day}-${month}-${year} ${time}`;
                    }
                  }

                  return {
                    ...sub,
                    date: displayDate,
                    statusName:
                      sub
                        .hdTicketStatus
                        ?.statusName ||
                      sub.statusName ||
                      sub.status ||
                      "N/A",
                    searchUser:
                      sub.loggedinUser ||
                      sub.user ||
                      "",
                  };
                }
              ) || [],
          })
        );

        setTableData(processedData);
      } catch (error) {
        console.error(
          "HelpDesk fetch error:",
          error
        );
      } finally {
        setLoading(false);
      }
    },
    [
      remoteId,
      isCnmsActive,
      setTableData,
      refreshTrigger,
    ]
  );

  useEffect(() => {
    fetchData();
  }, [fetchData, refreshTrigger]);

  const onHandleViewClick = (row, mode) => {
    setSelectedViewRow({
      ...row,
    
      ticketId: row.id, 
      statusId: row.hdTicketStatus?.id, 
      isReopen: mode === "reopen",
      actionMode: mode,
    });
    setIsModalOpen(true);
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedViewRow(null);
  };
  console.log("Current CNMS Status:", isCnmsActive);
  useEffect(() => {
    console.log("Component Mounted - isCnmsActive:", isCnmsActive);
    console.log("Current Table Data Count:", tableData?.length);

    // Optional: Log the first row's status to verify helper functions work
    if (tableData && tableData.length > 0) {
      const firstRow = tableData[0];
      console.log("First Row Status:", getStatusText(firstRow));
      console.log("Is Closed?", isClosed(firstRow));
      console.log("Is Resolved?", isResolved(firstRow));
    }
  }, [isCnmsActive, tableData]);
  
  return (
    <Box>
      {loading ? (
        <Box className="flex justify-center p-10">
          <CircularProgress size={30} />
        </Box>
      ) : (
        <>
          <MTable
            columns={columns}
            tableData={tableData}
            showPagination={true}
            showSearch={true}
            AddText="Create"
            hideAdd={false}
            isCollapsible={true}

            handleAdd={() =>
              handleAdd({
                mode: "CREATE",
                title: "Create Ticket",
              })
            }

            handleHistory={(row) =>
              handleHistory({
                ...row,
                id: row.id,
                mode: "HISTORY",
                title: "Ticket History",
              })
            }

            handleCloseAction={
              isCnmsActive
                ? (row) => isResolved(row) ? onHandleViewClick(row, "close") : null
                : (row) => (isOpen(row) || isPending(row)) ? onHandleViewClick(row, "close") : null
            }
            handleReopenAction={
              isCnmsActive
                ? null
                : (row) => (isClosed(row) || isResolved(row)) ? onHandleViewClick(row, "reopen") : null
            }

            handleInProgressAction={
              isCnmsActive
                ? (row) => isOpen(row) ? onHandleViewClick(row, "inprogress") : null
                : undefined
            }

            handlePendingAction={
              isCnmsActive
                ? (row) => isOpen(row) ? onHandleViewClick(row, "pending") : null
                : undefined
            }

           
          handleResolvedAction={
  isCnmsActive
    ? (row) => {
        const status = getStatusText(row);
        // For CNMS: If status is valid, trigger click, otherwise do nothing
        if (status === "open" || status === "in-progress" || status === "pending") {
          onHandleViewClick(row, "resolved");
        }
      }
    : undefined  
}
            handleRefresh={true}
            onRefreshClick={fetchData}
            advancedSearch={true}
            collapseDataKey="hdTicketSubDetails"
            collapseColumns={subDetailColumns}
            loading={loading}

            handleDownloadPDF={() =>
              exportToPDF(
                "Help Desk Profile",
                columns,
                tableData,
                "Assign_Profile"
              )
            }

            handleDownloadCSV={() =>
              exportToCSV(
                "HelpDesk_Export",
                columns,
                tableData
              )
            }

            refreshTrigger={
              refreshTrigger
            }
          />

          {isModalOpen &&
            selectedViewRow && (
              <MModal
                open={isModalOpen}
                onClose={
                  handleCloseModal
                }
                title={
                  selectedViewRow.isReopen
                    ? "Reopen Comment"
                    : selectedViewRow.actionMode === "close"
                      ? "Close Comment"
                      : selectedViewRow.actionMode === "inprogress"
                        ? "In-Progress Comment"
                        : selectedViewRow.actionMode === "pending"
                          ? "Pending Comment"
                          : "Resolved Comment"
                }
                handleClose={
                  handleCloseModal
                }
                sideDrawer={true}
                enableFullScreen
              >
                <Box sx={{ borderRadius: "10px" }}>
                  {selectedViewRow.isReopen ? (
                    /* 1. If it's a Reopen action */
                    <HandleReopenAction
                      id={selectedViewRow.id}
                      onClose={handleCloseModal}
                      actionType="REOPEN"
                      ticketData={selectedViewRow}
                      onRefresh={fetchData}
                    />
                  ) : selectedViewRow.actionMode === "close" ? (
                    /* 2. If it's a Close action */
                    <HandleCloseAction
                      id={selectedViewRow.id}
                      onClose={handleCloseModal}
                      actionType="CLOSE"
                      ticketData={selectedViewRow}
                      onRefresh={fetchData}
                    />
                  ) : (
                    /* 3. For all other modes (pending, inprogress, resolved) */
                    <HandleStatusUpdateAction
                      mode={selectedViewRow.actionMode}
                      id={selectedViewRow.id}
                      onClose={handleCloseModal}
                      onRefresh={fetchData}
                    />
                  )}
                </Box>
              </MModal>
            )}
        </>
      )}
    </Box>
  );
};

export default HelpDeskTable;

