import React from "react";
import { cn } from "@/lib/utils";

/**
 * ChatBubble Component
 * 
 * @param {ReactNode} children - The content inside the bubble
 * @param {string} side - "left" (incoming/system) or "right" (outgoing/user)
 * @param {string} className - Additional Tailwind classes
 * @param {object} props - Any other standard HTML props
 */
export function ChatBubble({ children, side = "left", className, ...props }) {
  const isRight = side === "right";

  return (
    <div
      className={cn(
        "flex w-full mb-1",
        isRight ? "justify-end" : "justify-start"
      )}
    >
      <div
        {...props}
        className={cn(
          // CHANGED: replaced 'max-w-[95%]' with 'w-[85%]' or 'min-w-[250px]' 
          // to force a consistent width across all bubbles
          "relative w-[85%] max-w-[95%] px-2 py-2.5 text-sm border transition-all",
          
          // 1. Base tail logic using pseudo-elements
          "after:absolute after:top-0 after:h-0 after:w-0 after:border-b-[10px] after:border-b-transparent",
          
          // 2. Left Side Styling (Incoming/System)
          !isRight && [
            "  text-slate-800 border-gray-200 rounded-xl rounded-tl-none",
            "after:left-[-8px] after:border-r-[8px] after:border-r-slate-200"
          ],
          
          // 3. Added Right Side Styling (Since you use isRight)
          isRight && [
            "bg-blue-600 text-white border-blue-500 rounded-xl rounded-tr-none",
            "after:right-[-8px] after:border-l-[8px] after:border-l-blue-600"
          ],
  
          className
        )}
      >
        {children}
      </div>
    </div>
  );
}

export default ChatBubble;