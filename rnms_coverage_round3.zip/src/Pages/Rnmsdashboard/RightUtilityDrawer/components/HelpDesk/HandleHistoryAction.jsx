import React, { useEffect, useState, useCallback } from "react";
import {
  Box,
  CircularProgress,
  Typography,
} from "@mui/material";

import ShowMoreText from "./ShowMoreText";
import { FETCH_CNMS_ADDRESS_DETAILS, GET_TICKET_HISTORY_FOR_GIVEN_ID } from "@/RestAPI/url/endpoint";
import { HelpDeskAxios, InventAxios } from "@/RestAPI/api/axiosApicall";
import righticon from "@/assets/SVGIcons/right.svg"
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";


const HandleHistoryAction = ({ data, ticketStatusIdMapping }) => {
  // Extract id from 'data'
  const id = data?.id;
  console.log("data", data)
  console.log("idddddd", id)
  const [historyInfo, setHistoryInfo] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const port = import.meta.env.PROD ? "9012" : "8786"


  // Use data.status if you want to pass specific info, 
  // but usually statusMap is passed from parent
  const statusMap = ticketStatusIdMapping && Object.keys(ticketStatusIdMapping).length > 0
    ? ticketStatusIdMapping
    : { 1: "Open", 2: "In-Progress", 3: "Pending", 4: "Resolved", 5: "Closed", 6: "Reopen" };

  const fetchData = useCallback(async () => {
    if (!id) {
      console.warn("HandleHistoryAction: No ID provided in 'data' prop.");
      setLoading(false);
      setError("No valid Ticket ID found.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // 2. Fetch Target Host (CNMS Address)
      // This is required because HelpDeskAxios needs the dynamic targetHost
      console.log("HandleHistoryAction: Fetching CNMS Address...");
      const addressResponse = await InventAxios(FETCH_CNMS_ADDRESS_DETAILS, "get");
      const fetchedAddress = addressResponse?.data?.address;

      let targetHost = null;

      if (fetchedAddress) {
        // Append port if it's just an IP/Hostname
        targetHost = fetchedAddress.includes(":") ? fetchedAddress : `${fetchedAddress}:${port}`;
        console.log("HandleHistoryAction: Target Host determined:", targetHost);
      } else {
        throw new Error("CNMS Address not found. Cannot determine server location.");
      }

      // 3. Perform the main API call to get History
      console.log(`HandleHistoryAction: Fetching history for ID: ${id}`);
      const response = await HelpDeskAxios(
        `${GET_TICKET_HISTORY_FOR_GIVEN_ID}/${id}`,
        "get",
        null,
        null,
        targetHost // Passing the dynamic host here
      );

      // 4. Handle Response
      const apiData = response?.data || [];
      setHistoryInfo(apiData);

    } catch (err) {
      console.error("HandleHistoryAction: Error during data fetch:", err);
      setError(err.message || "An error occurred while fetching history.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // --- RENDER STATES ---

  // Loading State
  if (loading) {
    return (
      <Box sx={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "300px",
        py: 4
      }}>
        <CircularProgress size={30} />
        <Typography variant="caption" sx={{ mt: 2, color: 'text.secondary' }}>
          Loading history...
        </Typography>
      </Box>
    );
  }

  // Error State
  if (error) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Typography color="error" variant="body2">
          {error}
        </Typography>
      </Box>
    );
  }

  // Empty State
  if (!historyInfo || historyInfo.length === 0) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Typography variant="body2" color="textSecondary">
          No history available for this ticket.
        </Typography>
      </Box>
    );
  }

  // Success State: Timeline View
  return (
    <ScrollContainer className="h-full" >
      <Box sx={{ maxHeight: "calc(100vh - 150px)", overflowY: "auto", px: 2, py: 2 }}>
        {historyInfo.map((item, index) => (
          <Box
            key={item.id || `history-${index}`}
            sx={{
              display: "flex",
              position: "relative",
              pb: 4, // Spacing between timeline items
            }}
          >
            {/* Left Timeline Section (Icons and Lines) */}
            <Box
              sx={{
                width: "40px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                position: "relative",
              }}
            >
              <img
                src={righticon}
                size="10px"

              />
              {/* The Connecting Line (only if not the last item) */}
              {index !== historyInfo.length - 1 && (
                <Box
                  sx={{
                    position: "absolute",
                    top: 30, // Centered vertically with the icon
                    bottom: -32, // Reaches down to the next icon
                    width: "2px",
                    backgroundColor: "#14138d",
                    zIndex: 1,
                  }}
                />
              )}
            </Box>

            {/* Right Side Content Section */}
            <Box sx={{ flex: 1, pl: 2 }}>
              <ShowMoreText
                element={item}
                ticketStatusIdMapping={statusMap}
              />

            </Box>

          </Box>
        ))}
        <Box>

        </Box>
      </Box>
    </ScrollContainer>
  );
};

export default HandleHistoryAction;