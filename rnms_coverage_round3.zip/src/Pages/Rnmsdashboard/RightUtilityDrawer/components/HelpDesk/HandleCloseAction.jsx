import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { Box, CircularProgress,Typography, useTheme } from "@mui/material";
import TextArea from "antd/es/input/TextArea";
import React, { useState } from "react";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import { FETCH_CNMS_ADDRESS_DETAILS, UPDATE_TICKET } from "@/RestAPI/url/endpoint";
import { HelpDeskAxios, InventAxios } from "@/RestAPI/api/axiosApicall";
import { useSelector } from 'react-redux'; // 1. Import useSelector
import Toast from "@/components/Reusable/Toast/Toast";
const HandleCloseAction = ({
  id,
  onClose,
  actionType = "CLOSE",
  ticketData,
  onSuccess,
  onRefresh,
  isChildFullScreen
}) => {
  const [showConfirm, setShowConfirm] =
    useState(false);

    const port = import.meta.env.PROD ? "9012" : "8786"

  const [loading, setLoading] =
    useState(false);

  const [description, setDescription] =
    useState("");

  const userName = useSelector(
    (state) =>
      state.userSlice.userDetails.data
        .userName
  );

  const STATUS_MAP = {
    REOPEN: {
      id: 6,
      name: "Reopen",
    },
    CLOSE: {
      id: 5,
      name: "Closed",
    },
  };

  const [descError, setDescError] =
    useState("");

  const validateDescription = (e) => {
    let value = e.target.value;

    if (value.length > 255) {
      value = value.slice(0, 255);
    }

    value = value.replace(
      /[^a-zA-Z\d\._\-\s,]/g,
      ""
    );

    const firstTwo = value.slice(0, 2);

    if (/[^a-zA-Z]/.test(firstTwo)) {
      const part1 = value
        .slice(0, 2)
        .replace(/[^a-zA-Z]/g, "");

      const part2 = value.slice(2);

      value = part1 + part2;
    }

    setDescription(value);

    if (value.length === 0) {
      setDescError("");
    } else if (value.length < 2) {
      setDescError(
        "First 2 characters must be text (letters)"
      );
    } else {
      const firstTwoAreLetters =
        /^[a-zA-Z]{2}/.test(value);

      if (!firstTwoAreLetters) {
        setDescError(
          "Must start with 2 letters"
        );
      } else {
        setDescError("");
      }
    }
  };

  const updateTicket = async () => {
    if (!id) {
      alert("Error: Missing Ticket ID");
      return;
    }

    const targetStatus =
      actionType === "REOPEN"
        ? STATUS_MAP.REOPEN
        : STATUS_MAP.CLOSE;

    const lastSubDetail =
      ticketData?.hdTicketSubDetails
        ?.length > 0
        ? ticketData
            .hdTicketSubDetails[
            ticketData.hdTicketSubDetails
              .length - 1
          ]
        : null;

    const currentSequenceNum =
      lastSubDetail?.sequenceNum || 1;

    const currentLoggedUser =
      lastSubDetail?.loggedinUser ||
      userName ||
      "system";

    const payload = {
      hdTicketStatus: {
        id: String(
          targetStatus.id
        ),
      },
      hdTicketDetail: {
        id: String(id),
      },
      sequenceNum:
        currentSequenceNum,
      statement: description,
      loggedinUser:
        currentLoggedUser,
    };

    try {
      setLoading(true);

      let targetHost = null;

      const addressResponse =
        await InventAxios(
          FETCH_CNMS_ADDRESS_DETAILS,
          "get"
        );

      const fetchedAddress =
        addressResponse?.data?.address;

      if (fetchedAddress) {
        targetHost =
          fetchedAddress.includes(":")
            ? fetchedAddress
            : `${fetchedAddress}:${port}`;
      }

      const response =
        await HelpDeskAxios(
          UPDATE_TICKET,
          "post",
          payload,
          null,
          targetHost
        );

      if (
        response.status === 200 ||
        response.status === 201
      ) {
        Toast(
          "Success!",
          "Ticket closed successfully!",
          "success"
        );

        await onRefresh?.();

        onSuccess?.();

        setShowConfirm(false);

        onClose?.();
      } else {
        Toast(
          "Error!",
          "Failed to update",
          "error"
        );
      }
    } catch (error) {
      console.error(
        "API Error:",
        error.response?.data ||
          error.message
      );
    } finally {
      setLoading(false);
    }
  };

 

  const theme = useTheme();

  return (
    <Box
      sx={{
        borderRadius: "10px",
      }}
    >
      <Typography
        sx={{
          fontFamily: "Montserrat",
          fontWeight: 500,
        }}
      >
        Ticket Closed Statement *
      </Typography>

      <TextArea
        rows={6}
        value={description}
        placeholder="Enter comments..."
        onChange={validateDescription}
        className={
          theme.palette.mode === "dark"
            ? "dark-ant-textarea"
            : ""
        }
        style={{
          resize: "none",
          borderColor: descError
            ? "#ff4d4f"
            : "#d9d9d9",
          fontFamily: "Montserrat",
          width: "100%",
          background:
            theme.palette.mode === "dark"
              ? "#333333"
              : "#ffffff",
          color:
            theme.palette.mode === "dark"
              ? "#ffffff"
              : "rgba(0, 0, 0, 0.88)",
        }}
      />

      <Typography
        variant="caption"
        sx={{
          color: descError
            ? "#e75656"
            : "textSecondary",
        }}
      >
        {descError
          ? descError
          : `${description.length}/255`}
      </Typography>

      <Box
        sx={{
          display: "flex",
          justifyContent: "end",
          mt: 2,
        }}
      >
        <MButtonPrimary
          disabled={
            loading ||
            description.length < 2
          }
          onClick={() => {
            setShowConfirm(true);
          }}
        >
          {loading ? (
            <CircularProgress
              size={24}
              color="inherit"
            />
          ) : (
            "Confirm"
          )}
        </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfirm}
        mode="child"
        isChildFullScreen={isChildFullScreen}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Action"
        message={`Are you sure you want to proceed with ${actionType.toLowerCase()}?`}
        onConfirm={updateTicket}
        onClose={() =>
          setShowConfirm(false)
        }
      />
    </Box>
  );
};

export default HandleCloseAction;
