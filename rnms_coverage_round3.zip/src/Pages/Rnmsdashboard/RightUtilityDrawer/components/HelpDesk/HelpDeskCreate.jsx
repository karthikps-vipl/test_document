
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MSelect from "@/components/Reusable/Select/MSelect";
import { Box, CircularProgress, Typography } from "@mui/material";
import React, { useEffect, useState } from "react"

import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import MInput from "@/components/Reusable/Input/MInput";
import { useSelector } from "react-redux";
import { CREATE_TICKET, FETCH_CNMS_ADDRESS_DETAILS, GET_SEVERITY_KEY_VALUE_PAIR } from "@/RestAPI/url/endpoint";
import { FaultAxios, HelpDeskAxios, InventAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import { FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID } from "@/RestAPI/url/cnmsEndPoint";

const HelpDeskCreate = ({ onSuccess, onClose, onRefresh, isGrandchildFullScreen }) => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [severityOptions, setSeverityOptions] = useState([]);
  const [descError, setDescError] = useState("");
  const [remainingChar, setRemainingChar] = useState("255 characters remaining");
  const [alarmError, setAlarmError] = useState("");
  const [siteResources, setSiteResources] = useState([]); 
  const [fetchingResources, setFetchingResources] = useState(false);
const {isCnms } = useSelector(
        (state) => state.nodeDetails
    );
    const fetchSiteDetails = useSelector(
      (state) => state.remoteRepDetails.fetchSiteDetails || []
    );
  // FORM STATE CONTAINER
  const [formData, setFormData] = useState({
    resourceId: "",
    resourceName: "",
    alarmDetail: "",
    severityValue: "",
    comment: "",
    siteId: ""
  });

  const { allResourceInfo } = useSelector((state) => state.topologySlice);
  console.log("allResourceInfo",allResourceInfo)
  const userName = useSelector((state) => state.userSlice.userDetails.data.userName);
  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  const remoteId = useSelector((state) => state.nodeDetails?.repDetails?.id);
  console.log("remoteid", remoteId);
  const port = import.meta.env.PROD ? "9012" : "8786"
  useEffect(() => {
    const fetchResourcesBySite = async () => {
      if (isCnms && formData.siteId) {
        setFetchingResources(true);
        try {
          // API URL construction as per your requirement
          const endpoint = `${FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID}/${formData.siteId}`;
          const response = await InventoryAxios(endpoint, "get");
          
          // Assuming response.data is the array of resources
          setSiteResources(response?.data || []);
          
          // Reset selected resource when site changes to prevent mismatch
          setFormData(prev => ({ ...prev, resourceId: "", resourceName: "" }));
        } catch (err) {
          console.error("Error fetching site resources:", err);
          setSiteResources([]);
        } finally {
          setFetchingResources(false);
        }
      }
    };

    fetchResourcesBySite();
  }, [formData.siteId, isCnms]);
  // Fetch severity levels on mount
  useEffect(() => {
    FaultAxios(GET_SEVERITY_KEY_VALUE_PAIR, "get")
      .then((res) => {
        setSeverityOptions(
          Object.entries(res.data || {}).map(([v, l]) => ({ label: l, value: v }))
        );
      })
      .catch((err) => console.error("Error fetching severity options:", err));
  }, []);

  // Sync validation and state tracking for user comment field
  const handleCommentChange = (e) => {
    const value = e.target.value;
    const MAX_LENGTH = 255;

    if (/^\d/.test(value)) {
      setDescError("Description cannot start with a number");
    } else if (value.trim().length > 0 && value.trim().length <= 2) {
      setDescError("Need more than 2 Characters");
    } else if (value.length > MAX_LENGTH) {
      setDescError("Exceeded Maximum Limit");
    } else {
      setDescError("");
    }

    setRemainingChar(`${MAX_LENGTH - value.length} characters remaining`);
    setFormData((prev) => ({ ...prev, comment: value }));
  };

  const handleResourceChange = (val) => {
    if (!val) return;
    setFormData((prev) => ({
      ...prev,
      resourceId: val.value,
      resourceName: val.label
    }));
  };

  const handleSeverityChange = (val) => {
    if (!val) return;
    setFormData((prev) => ({ ...prev, severityValue: val.value }));
  };

  const handleAlarmDetailChange = (e) => {
    const value = e.target.value;
    const MAX_LENGTH = 100;

    if (/^\d/.test(value)) {
      setAlarmError("Description cannot start with a number");
    } else if (value.trim().length > 0 && value.trim().length <= 2) {
      setAlarmError("Min 3 Characters required");
    } else if (value.length > MAX_LENGTH) {
      setAlarmError("Exceeded Maximum Limit");
    } else {
      setAlarmError("");
    }
    setFormData((prev) => ({ ...prev, alarmDetail: value }));



  };
 
const handleConfirmSubmit = async () => {
  setShowConfirm(false);
  setLoading(true);

  try {
    let targetHost = null;

    // 1. Handle targetHost ONLY for non-CNMS
    if (!isCnms) {
      const addressResponse = await InventAxios(FETCH_CNMS_ADDRESS_DETAILS, "get");
      const fetchedAddress = addressResponse?.data?.address;
      if (fetchedAddress) {
        targetHost = fetchedAddress.includes(":") ? fetchedAddress : `${fetchedAddress}:${port}`;
      }
    }

    // 2. Determine the Device Identifier
    // If CNMS: use the selected siteId. If Non-CNMS: use the remoteId from selector.
    const deviceIdentifier = isCnms 
      ? formData.siteId 
      : (remoteId || repDetails?.id || formData.resourceId);

    // 3. Construct the Payload exactly as requested
    const payload = {
      // Both remoteId and remoteName must match the device identifier
      remoteId: deviceIdentifier ? String(deviceIdentifier) : "",
      remoteName: deviceIdentifier ? String(deviceIdentifier) : "",
      
      // nmsType as requested (e.g., 1 or empty string for CNMS)
      nmsType: isCnms ? "" : (repDetails?.imTerminalType?.id ? String(repDetails.imTerminalType.id) : "1"),
      
      ticketAlarmDetail: formData.alarmDetail || "",
      ticketedDevice: formData.resourceName || "", // This maps to "ANTP" in your example
      
      hdTicketPriority: {
        id: formData.severityValue ? Number(formData.severityValue) : 1 // Default to 1 or user selection
      },
      
      hdTicketSubDetails: [
        {
          loggedinUser: userName,
          statement: formData.comment || ""
        }
      ]
    };

    console.log("Sending Payload:", payload);

  
    const response = await HelpDeskAxios(
      CREATE_TICKET,
      "post",
      payload,
      null,     
      targetHost 
    );

    if (response.status === 200 || response.status === 201) {
      Toast("Success!", "Ticket created successfully!", "success");
      onSuccess?.();
    } else {
      Toast("Error!", "Failed to save", "error");
    }
  } catch (error) {
    console.error("Submission Error:", error);
    Toast("Error!", "Failed to save details", "error");
  } finally {
    setLoading(false);
  }
};

  const selectedSeverityOption = severityOptions.find(
    (opt) => String(opt.value) === String(formData.severityValue)
  ) || null;
  const handleSiteChange = (val) => {
    if (!val) return;
    setFormData((prev) => ({ ...prev, siteId: val.value }));
  };
  const currentResourceList = isCnms ? siteResources : allResourceInfo;
  const resourceOptions = currentResourceList?.map((item) => ({
    label: item.resourceName,
    value: item.resourceId,
  })) || [];

  // const found = allResourceInfo?.find(i => i.resourceId === formData.resourceId);
  
  const selectedResourceOption = resourceOptions.find(
    (opt) => String(opt.value) === String(formData.resourceId)
  ) || null;
  const isFormInvalid =
    !formData.resourceId ||
    !formData.alarmDetail.trim() ||
    !formData.severityValue ||
    !formData.comment.trim() ||
    (isCnms && !formData.siteId) ||
    !!alarmError || // Check alarm error
    !!descError;
  const blockFirstCharNumber = (e) => {
    // If it's the first character being typed (value is empty)
    // and the key pressed is a number (0-9)
    if (e.target.value.length === 0 && /^[0-9]$/.test(e.key)) {
      e.preventDefault(); // This literally kills the keystroke
    }
  };
  return (
    <Box className="flex flex-col gap-2" sx={{ ml: 3, mr: 5 }}>
      <Box sx={{ display: "flex", flexDirection: "column", height: 70 }}>
        <Typography sx={{ mb: 0.5 }}>Remote Name</Typography>
        {isCnms ? (
          <MSelect
            placeholder="Select Site"
            // Changed: label now uses site.siteId instead of site.siteName
            options={fetchSiteDetails.map((site) => ({
              label: site.siteId,
              value: site.siteId,
            }))}
            // Changed: finding by siteId to ensure the correct label shows when selected
            value={fetchSiteDetails.find(s => s.siteId === formData.siteId)
              ? { label: fetchSiteDetails.find(s => s.siteId === formData.siteId).siteId, value: formData.siteId }
              : null}
            onChange={handleSiteChange}
          />
        ) : (
          <MInput
            disabled
            value={`${repDetails?.imTerminalType?.terminalTypeName || ""} #${String(repDetails?.remoteNumber || 0).padStart(3, '0')}: ${repDetails?.siteName || "empty"}`}
          />
        )}
      </Box>

      {/* User Name (Read Only) */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5, }}>User Name</Typography>
        <MInput disabled value={userName} />
      </Box>
  <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5, }}>Ticket Device *</Typography>
        <MSelect
          placeholder={fetchingResources ? "Loading..." : "Select Device Name"}
          // Use the pre-calculated options
          options={resourceOptions}
          // Use the correctly matched object
          value={selectedResourceOption} 
          onChange={handleResourceChange}
          disabled={fetchingResources}
        />
      </Box>

      {/* Alarm Details */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5, }}>Ticket Alarm Details *</Typography>
        {/* FIXED: Controlled input value tracking binding logic */}
        <MInput
          value={formData.alarmDetail}
          onChange={handleAlarmDetailChange}
          placeholder="Enter alarm configurations..."
          onKeyDown={blockFirstCharNumber}

        />
        <Typography variant="caption" sx={{ color: alarmError ? "red" : "textSecondary", mt: 0.5 }}>
          {alarmError}
        </Typography>
      </Box>

      {/* Severity Selection */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 70, mt: 2 }}>
        <Typography sx={{ mb: 0.5, }}>Severity *</Typography>
        <MSelect
          placeholder="Select Severity"
          options={severityOptions}
          value={selectedSeverityOption}
          onChange={handleSeverityChange}
        />
      </Box>

      {/* Comment */}
      <Box sx={{ display: "flex", flexDirection: "column", height: 85, mt: 2 }}>
        <Typography sx={{ mb: 0.5, }}>Comment *</Typography>
        {/* FIXED: Controlled input value tracking binding logic */}
        <MInput
          value={formData.comment}
          onChange={handleCommentChange}
          placeholder="Enter description comments..."
          onKeyDown={blockFirstCharNumber}
        />
        <Typography variant="caption" sx={{ color: descError ? "red" : "textSecondary", mt: 0.5 }}>
          {descError || remainingChar}
        </Typography>
      </Box>

      {/* Actions Layer */}
      <Box className="flex justify-end mt-6" sx={{ gap: 2 }}>
        <MButtonPrimary
          onClick={() => setShowConfirm(true)}
          disabled={loading || isFormInvalid}
        >
          {loading ? <CircularProgress size={20} color="inherit" /> : "Create"}
        </MButtonPrimary>
      </Box>

      {/* Global Confirmation Modal */}
      <MDialog
        open={showConfirm}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to log this new ticket request?"
        onConfirm={handleConfirmSubmit}
        onClose={() => setShowConfirm(false)}
        mode="grandchild"
        isGrandchildFullScreen={isGrandchildFullScreen}
      />
    </Box>
  );
};

export default HelpDeskCreate;


