import HelpDeskSeverity from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskSeverity";
import HelpDeskChart from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskChart";
import HelpDeskTable from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskTable";
import React, { useEffect, useState } from "react";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
import ReportAdvancedSearch from "./ReportAdvancedSearch";

export default function HelpDeskDashboard({
  handleAdd,
  handleCloseAction,
  handleView,
  handleHistory,
  handleReopenAction,
  refreshTrigger,
  handleInProgressAction,handlePendingAction,handleResolvedAction
}) {
  const [tableData, setTableData] =
    useState([]);

  const [filteredData, setFilteredData] =
    useState([]);

  useEffect(() => {
    setFilteredData(tableData);
  }, [tableData]);

  return (
    <div className="flex flex-col w-full h-full rounded-xl gap-0.5 border border-gray-200 overflow-hidden">
      <div className="flex-none">
        <HelpDeskSeverity
          tableData={filteredData}
        />
      </div>

      <ScrollContainer>
        <div className="flex-none p-1">
          <HelpDeskChart
            tableData={filteredData}
          />
        </div>

        <div className="flex-none">
          <ReportAdvancedSearch
            data={tableData}
            setFilteredData={
              setFilteredData
            }
          />
        </div>

        <div className="flex-1 min-h-0 w-full overflow-hidden flex flex-col">
          <div className="flex-1 overflow-auto rounded-md">
            <div className="min-w-[500px]">
              <HelpDeskTable
                tableData={filteredData}
                setTableData={setTableData}
                handleAdd={() =>
                  handleAdd({
                    mode: "CREATE",
                    title: "Create Ticket",
                  })
                }
                handleView={() =>
                  handleView({
                    mode: "CREATE",
                    title: "Create Ticket",
                  })
                }
                handleHistory={(row) =>
                  handleHistory({
                    ...row,
                    mode: "HISTORY",
                    title: "Ticket History",
                  })
                }
                handleReopenAction={() =>
                  handleReopenAction({
                    mode: "REOPEN",
                    title: "Create Ticket",
                  })
                }
                handleCloseAction={() =>
                  handleCloseAction({
                    mode: "CLOSE",
                    title: "Create Ticket",
                  })
                }
                handleInProgressAction={() =>
                  handleInProgressAction({
                    mode: "INPROGRESS",
                    title: "Create Ticket",
                  })
                }
                handlePendingAction={() =>
                  handlePendingAction({
                    mode: "PENDING",
                    title: "Create Ticket",
                  })
                }
                handleResolvedAction={() =>
                  handleResolvedAction({
                    mode: "PENDING",
                    title: "Create Ticket",
                  })
                }
                refreshTrigger={
                  refreshTrigger
                }
              />
            </div>
          </div>
        </div>
      </ScrollContainer>
    </div>
  );
}


//  export default function HelpDeskDashboard({ handleAdd, handleCloseAction, handleView,handleHistory,handleReopenAction, refreshTrigger }) {
//   const [tableData, setTableData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]); 
//   useEffect(() => {
//     setFilteredData(tableData);
//   }, [tableData]);

  
//   return (
//     <div className="flex flex-col w-full h-full rounded-xl gap-0.5  border border-gray-200 overflow-hidden">
     
//        <div className="flex-none ">
//         <HelpDeskSeverity tableData={filteredData} />
//       </div>
//       <ScrollContainer>
//       <div className="flex-none p-1">
//         <HelpDeskChart tableData={filteredData} />
//       </div>
//       <div className="flex-none  ">
//         <ReportAdvancedSearch 
//           data={tableData} 
//           setFilteredData={setFilteredData} 
//         />
//       </div>

//       <div className="flex-1 min-h-0 w-full overflow-hidden flex flex-col">
//         <div className="flex-1 overflow-auto   rounded-md">
//           <div className="min-w-[500px]">
//             {/* 2. Pass the function you just defined */}
//             <HelpDeskTable 
//               tableData={filteredData}
//               setTableData={setTableData} 
//               handleAdd={() => handleAdd({ mode: 'CREATE', title: 'Create Ticket' })}
//               handleView={() => handleView({ mode: 'CREATE', title: 'Create Ticket' })}
//               handleHistory={(row) => handleHistory({ ...row, mode: 'HISTORY', title: 'Ticket History' })}
//               handleReopenAction={() => handleReopenAction({ mode: 'REOPEN', title: 'Create Ticket' })}
//               handleCloseAction={() => handleCloseAction({ mode: 'CLOSE', title: 'Create Ticket' })}
//                 refreshTrigger={refreshTrigger}
               
//             />
//           </div>
//         </div>
//       </div>
//       </ScrollContainer>
//     </div>
//   );
// }