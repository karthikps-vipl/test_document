import React, { useEffect, useState } from "react";
import OpenIcon from "@/assets/SVGIcons/Help_Desk_Open.svg";
import ProgressIcon from "@/assets/SVGIcons/Help_Desk_Ongoing.svg";
import PendingIcon from "@/assets/SVGIcons/Help_Desk_Pending.svg";
import ResolvedIcon from "@/assets/SVGIcons/Help_Desk_Resolved.svg";
import ClosedIcon from "@/assets/SVGIcons/Help_Desk_Closed.svg";
import ReopenIcon from "@/assets/SVGIcons/Help_Desk_Reopen.svg";
import { Box, useTheme } from "@mui/material";

const DISPLAY_DATA_TEMPLATE = [
  { title: "Open", value: 0, bgColor: "#ffe0e7", image: OpenIcon },
  { title: "In-Progress", value: 0, bgColor: "#f4e5cc", image: ProgressIcon },
  { title: "Pending", value: 0, bgColor: "#fde0d6", image: PendingIcon },
  { title: "Resolved", value: 0, bgColor: "#d7eeff", image: ResolvedIcon },
  { title: "Closed", value: 0, bgColor: "#dbffee", image: ClosedIcon },
  { title: "Reopen", value: 0, bgColor: "#ffe0ff", image: ReopenIcon },
];

// FIXED: Moved useTheme inside the component
const Card = ({ title, value, bgColor, image }) => {
  const theme = useTheme(); // Call the hook here

  return (
    <Box 
      className="flex flex-row items-center justify-between border border-gray-300 rounded-lg pl-2 pr-1 h-auto shadow-sm min-w-0" 
      sx={{ background: theme.palette.background.cardbg }} // Note: usually it's .paper or .default, ensure .cardbg exists in your theme
    >
      <Box className="grid grid-cols-1 pl-0 pr-2 min-w-0 flex-1">
        <Box className="text-[10px] sm:text-xs">
          {title}
        </Box>
        <Box className="text-sm sm:text-base font-semibold break-words leading-tight">
          {value}
        </Box>
      </Box>
      <Box className="flex shrink-0 items-center mr-1">
        <Box
          className="-p-0.5 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: bgColor }}
        >
          {image ? (
            <img src={image} alt={title} className="w-5 h-5 sm:w-6 sm:h-6 object-contain" />
          ) : (
            <span className="text-[8px] sm:text-[10px] text-white font-bold">N/A</span>
          )}
        </Box>
      </Box>
    </Box>
  );
};

const HelpDeskSeverity = ({
  tableData = [],
}) => {
  const [data, setData] = useState(
    DISPLAY_DATA_TEMPLATE
  );

  useEffect(() => {
    const counts =
      DISPLAY_DATA_TEMPLATE.reduce(
        (acc, item) => {
          acc[item.title] = 0;
          return acc;
        },
        {}
      );

    tableData.forEach((item) => {
      const status = item.status;

      if (
        status &&
        Object.prototype.hasOwnProperty.call(
          counts,
          status
        )
      ) {
        counts[status]++;
      }
    });

    const updatedData =
      DISPLAY_DATA_TEMPLATE.map(
        (item) => ({
          ...item,
          value:
            counts[item.title] || 0,
        })
      );

    setData(updatedData);
  }, [tableData]);

  return (
    <Box className="p-1">
      <Box className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 p-1">
        {data.map(
          (item, index) => (
            <Card
              key={`${item.title}-${index}`}
              title={item.title}
              value={item.value}
              bgColor={item.bgColor}
              image={item.image}
            />
          )
        )}
      </Box>
    </Box>
  );
};


export default HelpDeskSeverity;