import MDialog from "@/components/Reusable/Dialog/MDialog";
import MTable from "@/components/Reusable/Table/MTable";
import Toast from "@/components/Reusable/Toast/Toast";
import { CertAxios, ConfigurationAxios, InventAxios } from "@/RestAPI/api/axiosApicall";
import { DELETE_CSR_URL, DOWNLOAD_FILE_FOR_GIVEN_ID_URL, DOWNLOAD_PACKAGE_CERT_URL, FETCH_CNMS_ADDRESS_DETAILS, GET_ALL_CERT, UPLOAD_CERT, UPLOAD_CERT_TO_MODEM, UPLOAD_PACKAGED_CRT_FILE_URL } from "@/RestAPI/url/endpoint";
import { Box, Card, CardContent, CircularProgress, createTheme, Grid, MenuItem, Paper, Popover, Tab, Tabs, TextField, ThemeProvider, Tooltip, Typography, useTheme } from "@mui/material";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Certificate_Download from "@/assets/SVGIcons/Certificate_Download.svg";
import { CheckCircleIcon, Download, UploadIcon } from "lucide-react";
import { Add, Assignment, AssignmentTurnedIn, CancelOutlined, CheckCircleOutline, PendingActions, VpnKey, WarningAmber } from "@mui/icons-material";
import XCertificate_Exporttomodem from "@/assets/SVGIcons/Certificate_Exporttomodem.svg";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import UploadRootOrSubCA from "./UploadRootOrSubCA";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import { CERT_URL } from "@/RestAPI/url/baseUrl";
import { clearCertificateExportResponse } from "@/store/features/X509Certificate/certificateExportSlice";

const Xcertificate = ({
    privilegeKey,
    handleAdd,
    handleEdit,
    handleView,
    refreshTrigger,
    handleDelete, isChildFullScreen
}) => {
    const [loading, setLoading] = useState(false);
    const [certTableData, setCertTableData] = useState([]);
    const [rowToDelete, setRowToDelete] = useState({
        visible: false,
        row: null
    });


    const downloadRowtempRef = useRef(null)
    console.log("downloadRowtempRef", downloadRowtempRef.packagedcertFile)
    const dispatch = useDispatch();
    useEffect(() => {
        // Clear the export response whenever the privilegeKey changes
        // This handles the scenario where the modal is closed and reopened
        dispatch(clearCertificateExportResponse());
    }, [privilegeKey, dispatch]);
    const exportCertificateResponse = useSelector(
        (state) => state.certificateExport.commandResponse
    );
    console.log("exportCertificateResponse", exportCertificateResponse)

    // const [isFilterOpen, setIsFilterOpen] = useState(false);
    const [loadingExport, setLoadingExport] = useState(false);
    const [targetHost, setTargetHost] = useState("");
    const [tabValue, setTabValue] = useState(0);
    const [certificateExpiringValue, setCertificateExpiringValue] = useState([]);
    const [apiData, setApiData] = useState(null);
    // const [selectedOptionObjs, setSelectedOptionObjs] = useState([]);
    const [uploadedRows, setUploadedRows] = useState({});
    const [uploadingRowId, setUploadingRowId] = useState(null);
    const [packagingRowId, setPackagingRowId] = useState(null);

    const [downloadAnchorEl, setDownloadAnchorEl] = useState(null);
    const [downloadRow, setDownloadRow] = useState(null);
    console.log("downloadRow", downloadRow)
    const theme = useTheme()
    const isDark = theme.palette.mode === "dark";

    const { repDetails, siteDetails, isCnms } = useSelector(
        (state) => state.nodeDetails
    );
    // const [selectedOptionObj, setSelectedOptionObj] = useState(null);
    const [summaryCounts, setSummaryCounts] = useState({
        expired: 0,
        requested: 0,
        expiring30: 0,
        expiring90: 0,
        expiring180: 0,
        expiring365: 0,
        issued: 0
    });
    const userName = useSelector(
        (state) => state.userSlice.userDetails.data.userName
    );

    const formatCustomDate = (dateVal) => {
        if (!dateVal) return "---";
        const date = new Date(dateVal);
        if (isNaN(date.getTime())) {
            return "---";
        }

        const year = date.getFullYear();
        // getMonth() is zero-indexed, so we add 1. padStart ensures 02 instead of 2.
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        const hours = String(date.getHours()).padStart(2, "0");
        const minutes = String(date.getMinutes()).padStart(2, "0");
        const seconds = String(date.getSeconds()).padStart(2, "0");

        // Returns format: YYYY-MM-DD HH:mm:ss
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };



    const handleCertificateExpiryChange = (newValue) => {
        setCertificateExpiringValue(newValue);
    };



    const handleOpenDownloadMenu = (event, row) => {

        setDownloadRow(row);
        downloadRowtempRef.current = row
        setDownloadAnchorEl(event.currentTarget);
    };

    const handleCloseDownloadMenu = () => {
        setDownloadAnchorEl(null);
        setDownloadRow(null);
    };

    const handleDownloadBlob = (
        data,
        fileName,
        mimeType = "application/octet-stream"
    ) => {
        try {
            const blob = new Blob([data], { type: mimeType });
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement("a");

            link.href = url;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);

            Toast("Success", "File downloaded successfully!", "success");
        } catch (error) {
            console.error("File download error:", error);
            Toast("Download Error", "Failed to download file.", "error");
        }
    };

    const handleDownloadFile = async (row, fileType) => {

        if (!row?.id) {
            Toast("Download Error", "Certificate ID is missing.", "error");
            return;
        }

        try {
            // For PCRT or CRT, use the reliable direct URL download method for both modes
            if (fileType === "PCRT" || fileType === "CRT") {
                let baseUrl = "";

                if (isCnms) {
                    // In CNMS mode, point to the backend server/port. 
                    // If your backend runs on a specific port or same origin without frontend routing interference:
                    // Option A: window.location.origin (if proxied) or adjust the port if your backend runs elsewhere (e.g., 8080/9787)
                    baseUrl = window.location.origin;
                } else {
                    let formattedHost = targetHost.trim();
                    if (!/^https?:\/\//i.test(formattedHost)) {
                        formattedHost = `http://${formattedHost}`;
                    }
                    baseUrl = formattedHost.replace(/\/$/, "");
                }

                const encodedId = encodeURIComponent(row.id);
                const encodedCommonName = encodeURIComponent(row.commonName || "unknown");

                const downloadUrl = `${baseUrl}${DOWNLOAD_PACKAGE_CERT_URL}/${encodedId}/${encodedCommonName}/PCRT`;

                const link = document.createElement("a");
                link.href = downloadUrl;

                // Force the correct archive extension (.zip or .rar as preferred)
                const fileName =
                    row.packagedcertFileName ||
                    `${row.commonName || "certificate"}.zip`; // Change to .rar if preferred
                link.download = fileName;

                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                Toast("Success", "Download started!", "success");
                return;
            }

            // Keep API fetch logic for CSR and KEY
            const request = {
                id: row.id,
                commonName: row.commonName,
                downloadFileType: fileType
            };

            const response = await CertAxios(DOWNLOAD_FILE_FOR_GIVEN_ID_URL, "post", request);
            let fileData;
            let fileName;
            let mimeType = "application/octet-stream";

            if (fileType === "CSR") {
                fileData = response?.data?.csr;
                fileName = `${row.siteId || "certificate"}_${row.commonName || "unknown"}.csr`;
                mimeType = "application/pkcs10";
            } else if (fileType === "KEY") {
                fileData = response?.data?.privateKey;
                fileName =
                    row.terminal === "HUB-NMS"
                        ? "NMS_IAF NMS Certificate_KEYS_2048_PKCS8.der"
                        : `VSAT_${row.commonName || "unknown"}_KEYS_2048_PKCS1.DER`;
            }

            if (!fileData) {
                Toast("Download", "No data found.", "info");
                return;
            }

            handleDownloadBlob(fileData, fileName, mimeType);
        } catch (error) {
            console.error("DOWNLOAD FILE ERROR:", error);
            Toast(
                "Download Error",
                error?.response?.data?.errorMessage ||
                error?.response?.data?.message ||
                error?.message ||
                "Unable to download file.",
                "error"
            );
        } finally {
            handleCloseDownloadMenu();
        }
    };

    const handleDownloadPackagedCertificate = (row) => {
        if (!row?.id || !row?.commonName) {
            Toast(
                "Download Error",
                "Certificate ID or Common Name is missing.",
                "error"
            );
            return;
        }

        try {
            // Use the same base URL + endpoint construction used in the old UI.
            // Your new UI's constructUrl() already returns CERT_URL + DOWNLOAD_PACKAGE_CERT_URL.
             const baseUrl = constructUrl();
            // const baseUrl = constructUrl()
            const protocol = import.meta.env.PROD ? "https://" : "http://";
             
            const rnmsBaseUrl = `${protocol}${targetHost}${DOWNLOAD_PACKAGE_CERT_URL}`;
            console.log("rnmsBaseUrl",rnmsBaseUrl)
            console.log("rnmsBaseUrl",rnmsBaseUrl)

            const finalBase = isCnms ? baseUrl : rnmsBaseUrl;

 
            const downloadUrl =
                `${finalBase}/` +
                `${encodeURIComponent(row.id)}/` +
                `${encodeURIComponent(row.commonName)}/PCRT`;

            console.log("Packaged certificate download URL:", downloadUrl);

            // Direct browser download, exactly like the working old UI.
            const link = document.createElement("a");
            link.href = downloadUrl;
            link.target = "_blank";
            link.rel = "noopener noreferrer";

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            Toast("Success", "File Downloaded Sucessfully!", "success");
        } catch (error) {
            console.error("Packaged certificate download error:", error);

            Toast(
                "Download Error",
                "Unable to download the packaged certificate.",
                "error"
            );
        }
    };

 
const blackConsoleTheme = createTheme({
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          backgroundColor: "#000000",
          "& .MuiOutlinedInput-input": { color: "#ffff", fontFamily: "Courier New" }
        }
    }
}
}
});
    const handleDeleteRow = async (rowId) => {
        // 1. Update UI immediately
        setCertTableData((prevData) => prevData.filter((item) => item.id !== rowId.id));

        try {
            // 2. Append the ID to the ENDPOINT (e.g., /api/delete/123)
            // Instead of sending the ID in the payload, we put it in the URL
            const urlWithId = `${DELETE_CSR_URL}/${rowId.id}`;

            // 3. Pass NULL as the payload because the ID is now in the URL
            const response = await CertAxios(urlWithId, "post", null);

            const result = response?.data || response;
            Toast("Success", result?.message || "Deleted successfully!", "success");

            setRowToDelete({ visible: false, row: null });
        } catch (error) {

            Toast("Delete Failed", error.message, "error");
        }
    };
    const handleCnmsFileUpload = async (row, file) => {
        if (!isCnms || !row?.id || !file) return;

        try {
            setUploadingRowId(row.id);
            const formData = new FormData();
            formData.append("user", userName);
            formData.append("id", row.id);
            formData.append("certFile", file);

            const response = await CertAxios(UPLOAD_CERT, "post", formData);
            const result = response?.data || response;

            if (result?.errorMessage) {
                Toast("Upload Failed", result.errorMessage, "error");
                return;
            }

            Toast("Success", "Certificate File uploaded successfully!", "success");
            setUploadedRows((previous) => ({ ...previous, [row.id]: true }));
            await fetchCertData();
        } catch (error) {
            console.error("UPLOAD_CERT ERROR:", error);
            const errorMessage =
                error?.response?.data?.errorMessage ||
                error?.response?.data?.message ||
                error?.message ||
                "Failed to upload Certificate File!";
            Toast("Upload Failed", errorMessage, "error");
        } finally {
            setUploadingRowId(null);
        }
    };

    const handlePackageCertificate = async (row) => {
        if (!isCnms || !row?.id) return;

        const alreadyPackaged =
            row.packagedcertFile === true ||
            row.packagedcertFile === "YES" ||
            !!row.packagedcertFileString;

        const uploadedSuccessfully = uploadedRows[row.id] === true;

        if (!alreadyPackaged && !uploadedSuccessfully) {
            Toast("Warning", "Please upload the certificate first.", "warning");
            return;
        }

        try {
            setPackagingRowId(row.id);
            const formData = new FormData();
            formData.append("id", row.id);

            const response = await CertAxios(UPLOAD_PACKAGED_CRT_FILE_URL, "post", formData);
            const result = response?.data || response;

            if (result?.errorMessage) {
                Toast("Package Failed", result.errorMessage, "error");
                return;
            }

            Toast("Success", "Certificate packaged successfully!", "success");
            await fetchCertData();

            setUploadedRows((previous) => {
                const updated = { ...previous };
                delete updated[row.id];
                return updated;
            });
        } catch (error) {
            console.error("PACKAGE CERTIFICATE ERROR:", error);
            const errorMessage =
                error?.response?.data?.errorMessage ||
                error?.response?.data?.message ||
                error?.message ||
                "Failed to package certificate.";
            Toast("Package Failed", errorMessage, "error");
        } finally {
            setPackagingRowId(null);
        }
    };

    const nonCnmsColumns = [
        { name: "S. No", uid: "sno", width: "60px" },
        { name: "Terminal", uid: "terminal", width: "150px" },
        { name: "SiteId", uid: "siteId", width: "150px" },
        { name: "MAC/IP Address", uid: "commonName", width: "160px" },
        { name: "Certificate Generated Date", uid: "csrdate", width: "180px" },
        { name: "CSR Issue Date", uid: "certissuedate", width: "180px" },
        { name: "Expiry Date", uid: "certexpirydate", width: "220px" },
        {
            name: "Certificate Validity",
            uid: "validityStatus",
            width: "220px",
            render: (cellValue, row) => {
                const data = row || cellValue;
                if (!data?.certexpirydate || data.certexpirydate === "N/A") {
                    return null;
                }
                const expiryDate = new Date(data.certexpirydate);
                const today = new Date();
                const isExpired = !isNaN(expiryDate.getTime()) && expiryDate < today;

                return (
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                        {isExpired ? (
                            <CancelOutlined sx={{ color: "error.main", fontSize: "28px" }} />
                        ) : (
                            <CheckCircleIcon sx={{ color: "success.main", fontSize: "28px" }} />
                        )}
                    </Box>
                );
            }
        },
        {
            name: "Actions",
            uid: "actions",
            sortable: false,
            cellClassName: "sticky-actions",
            headerClassName: "sticky-actions",
            render: (row) => (
                <Box sx={{ display: "flex", justifyContent: "center", gap: 1 }}>
                    <Tooltip title="Download Packaged Certificate">
                        <IconButton
                            disabled={!(row?.packagedcertFile || row?.packagedcertFileString)}
                            onClick={() => handleDownloadPackagedCertificate(row)}
                        >
                            <img
                                src={Certificate_Download}
                                style={{ width: "23px", height: "23px", objectFit: "contain" }}
                                alt="download"
                            />
                        </IconButton>
                    </Tooltip>
                </Box>
            )
        }
    ];

    const cnmsColumns = [
        { name: "S. No", uid: "sno", width: "72px" },
        { name: "Terminal", uid: "terminal", width: "150px" },


        { name: "Site ID", uid: "siteId", width: "160px" },
        { name: "Days to Expiry", uid: "daysToExpiry", width: "150px" },
        { name: "MAC/IP Address", uid: "commonName", width: "170px" },

        { name: "CSR Generated Date", uid: "csrdate", width: "190px" },
        { name: "Certificate Issue Date", uid: "certissuedate", width: "200px" },
        { name: "Certificate Expiry Date", uid: "certexpirydate", width: "220px" },
        {
            name: "Certificate Validity",
            uid: "validityStatus",
            width: "220px",
            render: (cellValue, row) => {
                const data = row || cellValue;

                // 1. ENHANCED CHECK: 
                // We check if data exists, AND if certexpirydate exists, 
                // AND if it's not just an empty string or "N/A"
                if (!data?.certexpirydate || data?.certexpirydate === "N/A" || data.certexpirydate === "") {
                    return (
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                            <Typography sx={{ color: "text.secondary" }}>—</Typography>
                        </Box>
                    );
                }

                const expiryDate = new Date(data.certexpirydate);
                const today = new Date();

                // 2. ADDITIONAL SAFETY:
                // If the date string is invalid (e.g., "undefined" or a broken string), 
                // expiryDate.getTime() will be NaN.
                const isInvalidDate = isNaN(expiryDate.getTime());

                // If it's an invalid date, show the dash instead of "Valid"
                if (isInvalidDate) {
                    return (
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                            <Typography >---</Typography>
                        </Box>
                    );
                }

                const isExpired = expiryDate < today;

                return (
                    <Box sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 1
                    }}>
                        {isExpired ? (
                            <>
                                <CancelOutlined sx={{ color: "error.main", fontSize: "28px" }} />
                                <Typography sx={{ color: "error.main", fontWeight: 'medium' }}>
                                    Expired
                                </Typography>
                            </>
                        ) : (
                            <>
                                <CheckCircleOutline sx={{ color: "success.main", fontSize: "28px" }} />
                                <Typography sx={{ color: "success.main", fontWeight: 'medium' }}>
                                    Valid
                                </Typography>
                            </>
                        )}
                    </Box>
                );
            }
        },
        {
            name: "Modem ACK Status",
            uid: "modemAckStatus",
            width: "190px",
            render: (cellValue, row) => {
                // 1. Get the data object (handling both row and row.original for compatibility)
                const rowData = row?.original || row || cellValue;

                // 2. Normalize the terminal name:
                // We remove the hyphen and convert to lowercase so that "HUB-NMS" becomes "hubnms"
                const terminalValue = rowData?.terminal ? rowData.terminal.toString().toLowerCase().replace("-", "") : "";

                // 3. Check if it matches "hubnms"
                if (terminalValue === "hubnms") {
                    return (
                        <Box sx={{
                            display: "flex",
                            justifyContent: "center",
                            color: "text.secondary",
                            fontWeight: 'medium'
                        }}>
                            N/A
                        </Box>
                    );
                }

                // 4. Existing logic for Success/Failed/Empty
                if (cellValue === true) {
                    return (
                        <Box sx={{ display: "flex", justifyContent: "center", color: "success.main" }}>
                            Success
                        </Box>
                    );
                }

                if (cellValue === false) {
                    return (
                        <Box sx={{ display: "flex", justifyContent: "center", color: "error.main" }}>
                            Failed
                        </Box>
                    );
                }

                // Default fallback for null/undefined values
                return (
                    <Box sx={{ display: "flex", justifyContent: "center", color: "text.secondary" }}>
                        ---
                    </Box>
                );
            }
        },
        { name: "Modem ACK Date", uid: "modemAckDateTime", width: "170px" },
        {
            name: "Upload Certificate",
            uid: "packagedcertFile",
            width: "220px",
            render: (cellValue, row) => {
                const data = row || cellValue;
                const hasFile = data?.packagedcertFile || data?.packagedcertFileString;
                const fileName = hasFile ? "Certific...." : "Select file";
                const isUploading = uploadingRowId === data?.id;

                return (
                    <Box sx={{ display: "flex", justifyContent: "center", py: 1 }}>
                        <label style={{ width: "100%", cursor: isUploading ? "default" : "pointer" }}>
                            <Box
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    border: "1px solid #ccc",
                                    borderRadius: "8px",
                                    width: "100%",
                                    height: "40px",
                                    overflow: "hidden",
                                    bgcolor: "#fff",
                                    transition: "all 0.2s",
                                    "&:hover": { borderColor: "primary.main", bgcolor: "#fcfcfc" }
                                }}
                            >
                                <Box
                                    sx={{
                                        flexGrow: 1,
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "space-between",
                                        px: 2,
                                        color: hasFile ? "#000" : "#999",
                                        fontSize: "14px",
                                        whiteSpace: "nowrap",
                                        overflow: "hidden",
                                        textOverflow: "ellipsis"
                                    }}
                                >
                                    <span>{isUploading ? "Uploading..." : fileName}</span>
                                    <Add sx={{ fontSize: "20px", color: "#666" }} />
                                </Box>
                                <Box
                                    sx={{
                                        borderLeft: "1px solid #ccc",
                                        height: "100%",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        px: 1.5,
                                        color: "#3f51b5"
                                    }}
                                >
                                    {isUploading ? <CircularProgress size={20} /> : <UploadIcon sx={{ fontSize: "22px" }} />}
                                </Box>
                            </Box>
                            <input
                                type="file"
                                hidden
                                accept=".crt,.pem,.der"
                                disabled={isUploading}
                                onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                        handleCnmsFileUpload(data, file);
                                    }
                                    e.target.value = "";
                                }}
                            />
                        </label>
                    </Box>
                );
            }
        },
        {
            name: "Package Certificate",
            uid: "packageCertificate",
            width: "190px",
            render: (cellValue, row) => {
                const data = row || cellValue;
                const alreadyPackaged =
                    data?.packagedcertFile === true ||
                    data?.packagedcertFile === "YES" ||
                    !!data?.packagedcertFileString;
                const uploadedSuccessfully = uploadedRows[data?.id] === true;
                const isPackaging = packagingRowId === data?.id;
                const canPackage = alreadyPackaged || uploadedSuccessfully;

                return (
                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                        <MButtonSecondary
                            variant="outlined"
                            sx={{
                                color: "#14348D",
                                borderRadius: "10px",
                                textTransform: "none",
                                fontFamily: "Montserrat",
                                border: "2px solid #14348D",
                                px: 4,
                                width: { xs: "100%", sm: "30%" }
                            }}
                            disabled={!canPackage || isPackaging}
                            onClick={() => handlePackageCertificate(data)}
                        >
                            {isPackaging ? "Generating..." : "Generate"}
                        </MButtonSecondary>
                    </Box>
                );
            }
        },
        {
            name: "Certificate Actions",
            uid: "actions",
            sortable: false,
            cellClassName: "sticky-actions",
            headerClassName: "sticky-actions",
            width: "200px",
            render: (row) => (
                <Box sx={{ display: "flex", justifyContent: "center", gap: 1 }}>
                    <Tooltip title="Download Options">
                        <IconButton onClick={(event) => handleOpenDownloadMenu(event, row)}>
                            <img
                                src={Certificate_Download}
                                style={{ width: "23px", height: "23px", objectFit: "contain" }}
                                alt="download"
                            />
                        </IconButton>
                    </Tooltip>
                </Box>
            )
        }
    ];
    const calculateDaysToExpiry = (rowItem) => {
        if (!rowItem?.rawCertExpiryDate) return null;

        const expiryDate = new Date(rowItem.rawCertExpiryDate);

        if (isNaN(expiryDate.getTime())) return null;

        const today = new Date();
        today.setHours(0, 0, 0, 0);
        expiryDate.setHours(0, 0, 0, 0);

        const diffTime = expiryDate.getTime() - today.getTime();

        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    };

    const port = import.meta.env.PROD ? "9012" : "9787"

    useEffect(() => {
        if (isCnms) return;

        const fetchHost = async () => {
            try {
                const res = await InventAxios(FETCH_CNMS_ADDRESS_DETAILS, "get");
                const addr = res?.data?.address;
                if (addr) {
                    setTargetHost(addr.includes(":") ? addr : `${addr}:${port}`);
                }
            } catch (e) {
                console.log(e);
            }
        };

        fetchHost();
    }, [isCnms]);

    const fetchCertData = async () => {
        if (!siteDetails?.terminalTypeName) return;
        if (!isCnms && !repDetails?.id) return;
        if (!isCnms && !targetHost) return;

        setLoading(true);
        try {
            let payload = isCnms
                ? { terminal: siteDetails?.terminalTypeName }
                : { siteId: repDetails.id, terminal: siteDetails?.terminalTypeName };

            let response = isCnms
                ? await CertAxios(GET_ALL_CERT, "post", payload)
                : await CertAxios(GET_ALL_CERT, "post", payload, null, targetHost);

            // 1. Get the data object from response
            const apiData = response?.data;
            setApiData(apiData);
            console.log("apiData", apiData)
            if (apiData) {
                const newCounts = {
                    issued: apiData.certificateIssuedCount || 0,
                    expired: apiData.certficateExpiredCount || 0,
                    requested: apiData.certficateRequestedCount || 0,
                    expiring30: apiData.certifcateAboutExpireNext30DaysCount || 0,
                    expiring90: apiData.certifcateAboutExpireNext3MonthsCount || 0,
                    expiring180: apiData.certifcateAboutExpireNext6MonthsCount || 0,
                    expiring365: apiData.certifcateAboutExpireNext1YearCount || 0,
                };

                console.log("Setting new summary counts to:", newCounts); // Log it here
                setSummaryCounts(newCounts);
            }

            // 2. Extract the certificate list. 
            // We check if apiData exists and if it has a 'certificateList' property.
            // If not, we default to an empty array [].
            const certList = apiData?.certificateList && Array.isArray(apiData.certificateList)
                ? apiData.certificateList
                : [];

            // 3. Map over the actual list (certList), not the whole object
            const processedData = certList.map((item, index) => {
                const processedItem = {
                    ...item,
                    sno: index + 1,
                    terminal: item?.terminal || "---",
                    siteId: item?.siteId || "---",
                    commonName: item?.commonName || "---",
                    rawCsrDate: item?.csrdate,
                    rawCertIssueDate: item?.certissuedate,
                    rawCertExpiryDate: item?.certexpirydate,
                    rawCertUploadDate: item?.certuploaddate,
                    rawModemAckDateTime: item?.modemAckDateTime,
                    csrdate: formatCustomDate(item?.csrdate),
                    certissuedate: formatCustomDate(item?.certissuedate),
                    certexpirydate: formatCustomDate(item?.certexpirydate),
                    certuploaddate: formatCustomDate(item?.certuploaddate),
                    modemAckDateTime: formatCustomDate(item?.modemAckDateTime),
                    modemAckStatus: item?.modemAckStatus ?? false,
                    certficateExpiringCount: item?.certficateExpiringCount
                };

                return {
                    ...processedItem,
                    daysToExpiry: calculateDaysToExpiry(processedItem)
                };
            });


            // Now use processedData for your table/state
            console.log(processedData);
            setCertTableData(processedData);

            setUploadedRows((previous) => {
                const updated = { ...previous };
                processedData.forEach((item) => {
                    const packaged =
                        item.packagedcertFile === true ||
                        item.packagedcertFile === "YES" ||
                        !!item.packagedcertFileString;
                    if (packaged) {
                        delete updated[item.id];
                    }
                });
                return updated;
            });
        } catch (error) {
            console.error("GET_ALL_CERT ERROR:", error);
            Toast("Error", error?.message || "Failed to fetch certificates", "error");
        } finally {
            setLoading(false);
        }
    };


    useEffect(() => {
        fetchCertData();
    }, [refreshTrigger, siteDetails?.terminalTypeName, repDetails?.id, targetHost, isCnms]);
    const filteredCertTableData = useMemo(() => {
        const selectedValues = Array.isArray(certificateExpiringValue)
            ? certificateExpiringValue
            : certificateExpiringValue
                ? [certificateExpiringValue]
                : [];

        // No selection: show all certificates
        if (selectedValues.length === 0) {
            return certTableData;
        }

        return certTableData.filter((item) => {
            const days = item.daysToExpiry;

            return selectedValues.some((selectedValue) => {
                switch (selectedValue) {
                    case "expired":
                        return item.expired === true ||
                            (days !== null && days < 0);

                    case "issued":
                        return item.dsc === "YES" ||
                            (days !== null && days > 0);

                    case "30":
                        return days !== null && days >= 0 && days <= 30;

                    case "90":
                        return days !== null && days >= 0 && days <= 90;

                    case "180":
                        return days !== null && days >= 0 && days <= 180;

                    case "365":
                        return days !== null && days >= 0 && days <= 365;

                    default:
                        return false;
                }
            });
        });
    }, [certTableData, certificateExpiringValue]);

    const onRefreshClick = async () => {
        // Reset the selected filter
        setCertificateExpiringValue(null);
        // setSelectedOptionObj(null);

        // Fetch all certificates again
        await fetchCertData();
    };

    const handleDownloadAction = async (row) => {
        if (isCnms) {
            handleOpenDownloadMenu({ currentTarget: document.activeElement }, row);
        } else {
            handleDownloadPackagedCertificate(row);
        }
    };

    // const handleExportCertificate = async () => {
    //     if (loadingExport) return;
    //     setLoadingExport(true);

    //     try {
    //         const payload = { timeout: 600000 };
    //         const response = await ConfigurationAxios(UPLOAD_CERT_TO_MODEM, "post", payload, null);
    //         const result = response?.data || response;

    //         if (result.statusCode === 1) {
    //             Toast("Success", result.status || "Certificate exported successfully", "success");
    //             fetchCertData();
    //         } else {
    //             Toast("Export Failed", result.status || "Failed to export certificate", "error");
    //         }
    //     } catch (error) {
    //         console.error("Exception:", error);
    //         Toast("Error", "Request failed or timed out", "error");
    //     } finally {
    //         setLoadingExport(false);
    //     }
    // };

    const handleExportCertificate = async () => {
        if (loadingExport) return;
    
        setLoadingExport(true);
    
        try {
            const payload = { timeout: 600000 };
    
            const response = await ConfigurationAxios(
                UPLOAD_CERT_TO_MODEM,
                "post",
                payload,
                null
            );
    
            const result = response?.data || response;
    
            if (result.statusCode === 1) {
                Toast(
                    "Success",
                    result.status || "Certificate export initiated successfully",
                    "success"
                );
    
                await fetchCertData();
            } else {
                Toast(
                    "Export Failed",
                    result.status || "Failed to export certificate",
                    "error"
                );
            }
        } catch (error) {
            console.error("Certificate export exception:", error);
    
            Toast(
                "Error",
                "Request failed or timed out",
                "error"
            );
        } finally {
            setLoadingExport(false);
        }
    };
    
    const renderCnmsSummary = () => {
        const CompactCard = ({ title, value, icon: Icon, color, isSelector }) => (
            <Card
                elevation={1}
                sx={{
                    // Remove flex: 1 to allow Grid to control the width
                    borderRadius: 2,
                    borderLeft: `4px solid ${color}`,
                    height: '100%',
                    boxSizing: 'border-box'
                }}
            >
                <CardContent sx={{ p: 2, '&:last-child': { pb: 1.5 } }}>
                    {isSelector ? (
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, fontSize: 'clamp(0.7rem, 2vw, 1rem)', }}>
                                <Icon sx={{ fontSize: 24, color: color, backgroundColor: `${color}15`, }} />
                                <Typography sx={{ fontSize: 'clamp(0.7rem, 2vw, 0.9rem)' }}>
                                    {title}
                                </Typography>
                            </Box>

                            <Box sx={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                width: '100%',
                                ml: 5, fontWeight: "bold"

                            }}>

                                <Typography fontWeight={900} sx={{ lineHeight: 1.1, overflow: 'hidden', textOverflow: 'ellipsis', fontSize: '20px' }}>
                                    {apiData?.certifcateAboutExpireNext30DaysCount}
                                </Typography>
                            </Box>
                        </Box>
                    ) : (
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                            <Box sx={{
                                display: 'flex', p: 0.7, borderRadius: 1,
                                backgroundColor: `${color}15`, color: color, flexShrink: 0
                            }}>
                                <Icon sx={{ fontSize: 20 }} />
                            </Box>
                            <Box sx={{ minWidth: 0 }}>
                                <Typography sx={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 500 }}>
                                    {title}
                                </Typography>
                                <Typography variant="h6" fontWeight={700} sx={{ lineHeight: 1.1, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                    {value}
                                </Typography>
                            </Box>
                        </Box>
                    )}
                </CardContent>
            </Card>
        );

        return (

            <Grid container spacing={2} sx={{ width: "100%", mb: 3 }}>
                <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
                    <CompactCard
                        title="Requested"
                        value={summaryCounts.requested}
                        icon={PendingActions}
                        color={isDark ? "#fff" : "#14348d"}

                    />
                </Grid>
                <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
                    <CompactCard
                        title="Issued"
                        value={summaryCounts.issued}
                        icon={AssignmentTurnedIn}
                        color={isDark ? "#fff" : "#14348d"}

                    />
                </Grid>
                <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
                    <CompactCard
                        title="Expired"
                        value={summaryCounts.expired}
                        icon={CancelOutlined}
                        color={isDark ? "#fff" : "#14348d"}

                    />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
                    <CompactCard
                        title="Expiring within in 30-days  "
                        icon={WarningAmber}
                        color={isDark ? "#fff" : "#14348d"}

                        isSelector={true}
                    />
                </Grid>
            </Grid>
        );
    };
    const renderCnmsContent = () => (
        <Box sx={{ width: "100%", border: "2px solid #eee", borderRadius: "20px" }}>
            <Tabs
                value={tabValue}
                onChange={(_, val) => setTabValue(val)}
                variant="scrollable"
                scrollButtons="auto"
                sx={{ ml: 2, "& .MuiTab-root": { textTransform: "none" }, borderBottom: "2px solid #eee" }}
            >
                <Tab label="CSR" />
                <Tab label="ROOT Sub CA" />
            </Tabs>

            {tabValue === 0 && (
                <Box sx={{ p: 1, }}>
                    {renderCnmsSummary()}
                    <MTable
                        privilegeKey={privilegeKey}
                        columns={cnmsColumns}
                        tableData={filteredCertTableData}
                        showPagination={true}
                        addDisable={false}
                        hideAdd={false}
                        handleAdd={() => handleAdd({ mode: "CREATE", title: "Add   Generate CSR Details" })}
                        AddText="Generate CSR"
                        handleDownload={(row) => handleDownloadAction(row)}
                        handleDelete={(row) => setRowToDelete({ visible: true, row: row })}
                        showSearch={true}
                        handleRefresh={true}
                        onRefreshClick={onRefreshClick}
                        handleFilter={true}
                        filterMenu={
                            <MAlarmSelect
                                value={certificateExpiringValue}
                                onChange={handleCertificateExpiryChange}
                                options={[
                                    { label: "Expired", value: "expired" },
                                    { label: "Issued", value: "issued" },
                                    { label: "Exp. Within 1 Month", value: "30" },
                                    { label: "Exp. Within 3 Month", value: "90" },
                                    { label: "Exp. Within 6 Month", value: "180" },
                                    { label: "Exp. Within 1 Year", value: "365" }
                                ]}
                                placeholder="Select"
                                style={{ width: "170px" }}
                            />
                        }

                    />

                </Box>
            )}

            {tabValue === 1 && (
                <Box sx={{ p: 1 }}>
                    {/* 
                   Instead of manually writing the Table here, 
                   we call your new component and pass the props 
                */}
                    <UploadRootOrSubCA

                    />
                </Box>
            )}
        </Box>
    );

    const renderNonCnmsContent = () => (
        <Box>
            <MTable
                privilegeKey={privilegeKey}
                columns={nonCnmsColumns}
                tableData={certTableData}
                showPagination={true}
                addDisable={false}
                hideAdd={true}
                AddText="CSR"
                handleAdd={() => handleAdd({ mode: "CREATE", title: "Add Representative" })}
                handleDownload={(row) => handleDownloadAction(row)}
                showSearch={true}
                showExportButton={true}
                onExportClick={handleExportCertificate}
                exportIcon={XCertificate_Exporttomodem}
            />
            {exportCertificateResponse !== "" && (
    <Grid container sx={{ mt: 2 }}>
        <Grid size={{ xs: 12 }}>
            <Box
                sx={{
                    backgroundColor: "#14348d",
                    color: "#fff",
                    p: 1,
                    borderRadius: "4px 4px 0 0"
                }}
            >
                Output
            </Box>

            <Paper sx={{ p: 2, border:"2px solid #e3e3e3"}}>
                <ThemeProvider theme={blackConsoleTheme}>
                <TextField
                sx={{color:"#fff"}}
                    multiline
                    fullWidth
                    minRows={8}
                    maxRows={8}
                    value={exportCertificateResponse}
                    variant="outlined"
                    InputProps={{
                        readOnly: true
                    }}
                />
                </ThemeProvider>
               

               <Box sx={{mt:1,display:'flex', alignItems: "flex-end",
            justifyContent: "flex-end",}}>
               <MButtonSecondary
                     
                     onClick={() => {
                         dispatch(clearCertificateExportResponse());
                     }}
                 >
                     Clear
                 </MButtonSecondary>
               </Box>
            </Paper>
        </Grid>
    </Grid>
)}
        </Box>
    );

    const downloadMenuOpen = Boolean(downloadAnchorEl);


    const constructUrl = () => {
        // const isProd = import.meta.env.PROD
        //  const downloadPackageCertUrl = isProd ? "https://" : "http://"
        // const backendDest = isProd ? window.APP_CONFIG?.BASE_URL : CERT_URL

        const url = `${CERT_URL}${DOWNLOAD_PACKAGE_CERT_URL}`

        console.log(url, "sdjsdhfsdjhfks");

        return url

    }



    return (
        <Box>
            {loading ? (
                <Box className="flex justify-center p-10">
                    <CircularProgress size={30} />
                </Box>
            ) : isCnms ? (
                renderCnmsContent()
            ) : (
                renderNonCnmsContent()
            )}

            <Popover
                open={isCnms && downloadMenuOpen}
                anchorEl={downloadAnchorEl}
                onClose={handleCloseDownloadMenu}
            >
                <Box sx={{ px: 1.5, py: 1 }}>
                    <Typography sx={{ fontSize: "16px", fontWeight: 600, color: isDark ? "#fff" : "#14348d", mb: 1 }}>
                        Download
                    </Typography>

                    <MenuItem
                        disabled={!downloadRow?.csr}
                        onClick={() => handleDownloadFile(downloadRow, "CSR")}
                        sx={{ borderRadius: "8px", mb: 0.5 }}
                    >
                        <Assignment sx={{ mr: 1.5, color: isDark ? "#fff" : "#14348d" }} />
                        CSR
                    </MenuItem>

                    <MenuItem
                        disabled={!downloadRow?.privateKey}
                        onClick={() => handleDownloadFile(downloadRow, "KEY")}
                        sx={{ borderRadius: "8px", mb: 0.5 }}
                    >
                        <VpnKey sx={{ mr: 1.5, color: isDark ? "#fff" : "#14348d" }} />
                        Private Key
                    </MenuItem>


                    {downloadRowtempRef.current?.terminal == "HUB-NMS" ? (
                        <>
                            {!(downloadRowtempRef.current?.packagedcertFile || downloadRowtempRef.current?.packagedcertFileString) ? (
                                /* Not packaged yet → render a disabled MenuItem, no anchor at all */
                                <MenuItem disabled sx={{ borderRadius: "8px" }}>
                                    <Download color="orange" />
                                    <span style={{ marginLeft: "8px" }}>Packaged Certificate</span>
                                </MenuItem>
                            ) : (
                                /* Packaged → wrap in anchor so the browser download works */
                                <a
                                    target="_blank"
                                    rel="noreferrer"
                                    href={`${constructUrl()}/${downloadRowtempRef.current?.id}/${downloadRowtempRef.current?.commonName}/PCRT`}
                                    download={`${downloadRowtempRef.current?.commonName}`}
                                    style={{
                                        cursor: "pointer",
                                        textDecoration: "none",
                                        color: "inherit",
                                        display: "block",
                                    }}
                                    onClick={() => handleCloseDownloadMenu()}
                                >
                                    <MenuItem sx={{ borderRadius: "8px" }}>
                                        <Download color="orange" />
                                        <span style={{ marginLeft: "8px" }}>Packaged Certificate</span>
                                    </MenuItem>
                                </a>
                            )}
                        </>
                    ) : (
                        <MenuItem
                            disabled={!(downloadRow?.packagedcertFile || downloadRow?.packagedcertFileString)}
                            onClick={() => {
                                handleDownloadPackagedCertificate(downloadRow);
                                handleCloseDownloadMenu();
                            }}
                            sx={{ borderRadius: "8px" }}
                        >
                            <img
                                src={Certificate_Download}
                                alt="download"
                                style={{ width: "20px", height: "20px", marginRight: "12px" }}
                            />
                            <span>Packaged Certificate</span>
                        </MenuItem>
                    )}

                    {/* {downloadRowtempRef.current?.terminal == "HUB-NMS" ? <>

                        <a target='_blank' href={`${constructUrl()}/${downloadRowtempRef.current?.id}/${downloadRowtempRef.current?.commonName}/PCRT`} download={`${downloadRowtempRef.current?.commonName}`} style={{ cursor: 'pointer', background: 'red', }}  >
                            <div style={{display:'flex', gap:"8px",marginLeft:"14px"}}>   
                                 <Download color='orange' />
                                <span>Packaged Certificate</span></div>
                        </a>

                    </> : <>

                        <MenuItem
                            disabled={!(downloadRow?.packagedcertFile || downloadRow?.packagedcertFileString)}
                            onClick={() => {
                                handleDownloadPackagedCertificate(downloadRow); // Call the direct download function
                                handleCloseDownloadMenu(); // Close menu after clicking
                            }}
                            sx={{ borderRadius: "8px" }}
                        >
                            <img
                                src={Certificate_Download}
                                alt="download"
                                style={{ width: "20px", height: "20px", marginRight: "12px" }}
                            />
                         
                            <span>Packaged Certificate</span>
                        </MenuItem>
                    </>} */}
                </Box>
            </Popover>

            {rowToDelete.visible && (
                <MDialog
                    open={rowToDelete.visible}
                    variant="error"
                    title="Confirm Action"
                    icon={Delete_Icon_}
                    mode="child"
                    isChildFullScreen={isChildFullScreen}
                    message={`Are you sure you want to delete the certificate having Site Id : ${rowToDelete.row?.siteId || "---"
                        } and MAC/IP Address : ${rowToDelete.row?.commonName || "---"
                        }?`}
                    onConfirm={() => {
                        handleDeleteRow(rowToDelete.row);
                    }} onClose={() => setRowToDelete({ visible: false, row: null })}

                />
            )}
        </Box>
    );
};

export default Xcertificate;  