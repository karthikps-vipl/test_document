import React, { useEffect, useRef, useState } from "react";
import { Box, Typography, useTheme } from "@mui/material";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MTable from "@/components/Reusable/Table/MTable";
import {
  GET_ROOT_OR_SUB_CA_URL,
  UPLOAD_CERT_ROOT_OR_SUB,
} from "@/RestAPI/url/endpoint";
import { CertAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import moment from "moment";
import { CancelOutlined, CheckCircleOutline } from "@mui/icons-material";

const UploadCard = ({ buttonText, onFileSelect, disabled }) => {
  const fileInputRef = useRef(null);
  const handleButtonClick = () => !disabled && fileInputRef.current.click();

  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      onFileSelect(e.target.files[0]);
      e.target.value = null; // Reset input so same file can be selected again
    }
  };
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  return (
    <Box
      sx={{
        width: 320,
        border: "1px dashed #bdbdbd",
        borderRadius: "8px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        p: 3,
        textAlign: "center",
        bgcolor: isDark ? "#000" : "#fff",
        opacity: disabled ? 0.6 : 1,
        pointerEvents: disabled ? "none" : "auto",
      }}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        style={{ display: "none" }}
        accept=".DER,.cer" // Fixed from .jpg/.png to match CA requirements
      />
      <UploadFileIcon sx={{ fontSize: 35, mb: 1 }} />
      <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
        Choose a File
      </Typography>
      <Typography variant="caption" sx={{ color: "text.secondary", mb: 2 }}>
        DER, CER (Max 20KB)
      </Typography>
      <MButtonPrimary
        onClick={handleButtonClick}
        sx={{ textTransform: "none" }}
        disabled={disabled}
      >
        {buttonText}
      </MButtonPrimary>
    </Box>
  );
};

const UploadRootOrSubCA = ({ refreshTrigger, privilegeKey }) => {
  const [tableData, setTableData] = useState([]);
//   const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  const columns = [
    { name: "S. No ", uid: "sno", width: "73px" },
    { name: "Certificate Type", uid: "caType", width: "180px" },
    { name: "Certificate File Name", uid: "CaFilename1", width: "380px" },
    { name: "Issue Date", uid: "caIssuedate", width: "200px" },
    { name: "Expiry Date", uid: "caExpiredate", width: "200px" },
    {
      name: "Certificate Validity",
      uid: "validityStatus",
      width: "180px",
      render: (cellValue, row) => {
        // Instead of re-calculating using moment,
        // use the 'validity' string we created in fetchData
        if (!row || !row.validity) {
          return null;
        }

        const isValid = row.validity === "Valid";

        return (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {isValid ? (
              <CheckCircleOutline sx={{ color: "#4caf50", fontSize: "28px" }} /> // Hardcoded Green
            ) : (
              <CancelOutlined sx={{ color: "#f44336", fontSize: "28px" }} /> // Hardcoded Red
            )}
          </Box>
        );
      },
    },
  ];
  // --- LOGIC: Fetch and Process Data ---
  // const fetchData = async () => {
  //     try {
  //         setLoading(true);
  //         const response = await CertAxios(GET_ROOT_OR_SUB_CA_URL, "get");
  //         const rawData = response?.data;
  //         console.log("rawData", rawData);

  //         if (rawData && Array.isArray(rawData)) {
  //             let processedList = [];

  //             rawData.forEach((obj) => {
  //                 // 1. Prepare the formatted dates
  //                 const formattedExpire = moment(obj.caExpiredate).format('DD-MMM-YYYY hh:mm:ss');
  //                 const formattedIssue = moment(obj.caIssuedate).format('DD-MMM-YYYY hh:mm:ss');
  //                 const isExpired = moment(obj.caExpiredate).isBefore(moment());

  //                 // 2. Create the MAIN ROW (This mimics the 'Modem_Root_CA' change)
  //                 const mainRow = {
  //                     ...obj,
  //                     caExpiredate: formattedExpire,
  //                     caIssuedate: formattedIssue,
  //                     sno: processedList.length + 1,
  //                     validity: isExpired ? 'Expired' : 'Valid'
  //                 };

  //                 // Update caType for the main row to match the old code's mutation
  //                 if (obj.caType === 1) {
  //                     mainRow.caType = "Modem_Root_CA";
  //                 } else if (obj.caType === 2) {
  //                     mainRow.caType = "Modem_Sub_CA";
  //                 }

  //                 processedList.push(mainRow);

  //                 // 3. Create the SHADOW ROW (TotalNMS rows)
  //                 if (obj.caType === 1) {
  //                     processedList.push({
  //                         ...mainRow, // Spread the formatted mainRow
  //                         caType: "TotalNMS_Root_CA",
  //                         caFilename1: obj.caFilename2,
  //                         sno: processedList.length + 1,
  //                         // Ensure we don't accidentally overwrite caType back to Modem_Root_CA
  //                     });
  //                 } else if (obj.caType === 2) {
  //                     processedList.push({
  //                         ...mainRow,
  //                         caType: "TotalNMS_Sub_CA",
  //                         caFilename1: obj.caFilename2,
  //                         sno: processedList.length + 1,
  //                     });
  //                 }
  //             });

  //             setTableData(processedList);
  //         } else {
  //             setTableData([]);
  //         }
  //     } catch (error) {
  //         console.error("Error fetching data:", error);
  //         Toast("Error!", "Failed to fetch details", "error");
  //         setTableData([]);
  //     } finally {
  //         setLoading(false);
  //     }
  // };
  const fetchData = async () => {
    try {
    //   setLoading(true);
      const response = await CertAxios(GET_ROOT_OR_SUB_CA_URL, "get");
      const rawData = response?.data;

      if (rawData && Array.isArray(rawData)) {
        let processedList = [];

        rawData.forEach((obj) => {
          // 1. Prepare the formatted dates
          const formattedExpire = moment(obj.caExpiredate).format(
            "DD-MMM-YYYY hh:mm:ss"
          );
          const formattedIssue = moment(obj.caIssuedate).format(
            "DD-MMM-YYYY hh:mm:ss"
          );
          const isExpired = moment(obj.caExpiredate).isBefore(moment());

          // 2. Create the MAIN ROW (Modem Row)
          const mainRow = {
            ...obj,
            caExpiredate: formattedExpire,
            caIssuedate: formattedIssue,
            sno: processedList.length + 1,
            validity: isExpired ? "Expired" : "Valid",
            // Ensure we map the filename to the exact UID used in columns
            CaFilename1: obj.CaFilename1 || obj.caFilename1,
          };

          // Map caType to Modem labels
          if (obj.caType === 1) {
            mainRow.caType = "Modem_Root_CA";
          } else if (obj.caType === 2) {
            mainRow.caType = "Modem_Sub_CA";
          }

          processedList.push(mainRow);

          // 3. Create the SHADOW ROW (TotalNMS Row)
          if (obj.caType === 1) {
            processedList.push({
              ...mainRow,
              caType: "TotalNMS_Root_CA",
              // For TotalNMS, use the second filename (caFilename2/CaFilename2)
              CaFilename1: obj.CaFilename2 || obj.caFilename2,
              sno: processedList.length + 1,
            });
          } else if (obj.caType === 2) {
            processedList.push({
              ...mainRow,
              caType: "TotalNMS_Sub_CA",
              // For TotalNMS, use the second filename (caFilename2/CaFilename2)
              CaFilename1: obj.CaFilename2 || obj.caFilename2,
              sno: processedList.length + 1,
            });
          }
        });

        setTableData(processedList);
      } else {
        setTableData([]);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Toast("Error!", "Failed to fetch details", "error");
      setTableData([]);
    } finally {
    //   setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [refreshTrigger]);

  // --- LOGIC: Handle File Upload ---
  const handleFile = async (file, type) => {
    // 1. Validation
    if (file.size > 20000) {
      Toast("Warning", "File size should not be more than 20 kB", "info");
      return;
    }

    const fd = new FormData();
    // type 1 = Root, type 2 = Sub
    fd.append("id", type);
    fd.append("caType", type);
    fd.append("certFile", file);

    try {
      setUploading(true);
      // Note: Using your existing CertAxios structure
      const response = await CertAxios(UPLOAD_CERT_ROOT_OR_SUB, "post", fd);

      if (response?.data?.status) {
        Toast("Success", "Certificate File Uploaded", "success");
        fetchData(); // Refresh table
      } else {
        Toast(
          "Error",
          response?.data?.errorMessage || "Upload failed",
          "error"
        );
      }
    } catch (err) {
      console.error(err);
      Toast(
        "Error",
        "Failed to upload Certificate File! Server Error",
        "error"
      );
    } finally {
      setUploading(false);
    }
  };

  return (
    <Box sx={{ width: "100%" }}>
      {/* 1. The Upload Area */}
      <Box
        sx={{ display: "flex", justifyContent: "center", gap: 3, mb: 4, mt: 2 }}
      >
        <UploadCard
          buttonText="UPLOAD ROOT CA"
          onFileSelect={(file) => handleFile(file, 1)}
          disabled={uploading}
        />
        <UploadCard
          buttonText="UPLOAD SUB CA"
          onFileSelect={(file) => handleFile(file, 2)}
          disabled={uploading}
        />
      </Box>

      {/* 2. The Table Area */}
      <MTable
        privilegeKey={privilegeKey}
        tableTitle="Root and Sub CA"
        columns={columns}
        tableData={tableData}
        showPagination={true}
        addDisable={false}
        hideAdd={true}
        showSearch={true}
        // Custom Cell Rendering for Validity (if your MTable supports it)
        // Or just rely on the string "Valid"/"Expired" being passed in tableData
      />
    </Box>
  );
};

export default UploadRootOrSubCA;
