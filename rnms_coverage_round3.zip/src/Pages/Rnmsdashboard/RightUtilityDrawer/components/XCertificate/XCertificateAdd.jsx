
import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Typography,
  IconButton,
  CircularProgress,
  Checkbox,
  Paper,
  Divider,
  Tooltip,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";

import confirmation_icon from "@/assets/SVGIcons/question_mark.svg";



// Keep your existing toast import
import MSelect from "@/components/Reusable/Select/MSelect";
import FormField from "@/components/Reusable/Form/FormField";
import { CREATE_CSR_URL, FETCH_TERMINAL_BY_TERMINAL_NAME, GET_IP_ADDRESS_AT_CNMS_URL, GET_MAC_ADDRESS } from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { CertAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { Add, Delete, Language } from "@mui/icons-material";
import { Stack } from "@mui/system";

const isValidIpV4 = (ip = "") =>
  /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/.test(
    ip.trim()
  );

const isValidMac = (mac = "") =>
  /^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$/.test(mac.trim()) ||
  /^[0-9a-fA-F]{12}$/.test(mac.trim());
  const schema = Yup.object({
    terminal: Yup.string().required("Terminal is required"),
    siteId: Yup.string().required("Site ID is required"),
    commonName: Yup.string()
    .trim()
    // We remove the static .required("Ip Address is required") 
    // and handle requirement inside the test below
    .test(
      "common-name-validation",
      "Invalid format", 
      function (value) {
        const { terminal } = this.parent;
        const isEmpty = !value || value.trim() === "";

        // 1. Handle Requirement (Dynamic Message)
        if (isEmpty) {
          if (terminal === "CNMS" || terminal === "HUB-NMS") {
            return this.createError({ message: "IP Address is required" });
          }
          return this.createError({ message: "MAC Address is required" });
        }

        // 2. Handle Validation (Specific Format Message)
        if (terminal === "CNMS" || terminal === "HUB-NMS") {
          const isIpValid = isValidIpV4(value);
          if (!isIpValid) {
            return this.createError({ message: "Enter a valid IPv4 Address" });
          }
          return true;
        } else {
          const isMacValid = isValidMac(value);
          if (!isMacValid) {
            return this.createError({ message: "Enter a valid MAC Address" });
          }
          return true;
        }
      }
    ),
    organization: Yup.string()
      .matches(
        /^[a-zA-Z0-9\s]+$/,
        "Only alphanumeric characters and spaces are allowed"
      )
      .min(2, "Organization must contain at least 2 characters")
      .max(25, "Organization must not exceed 25 characters")
      .required("Organization is required"),
    organizationUnit: Yup.string()
      .matches(
        /^[a-zA-Z0-9\s]+$/,
        "Only alphanumeric characters and spaces are allowed"
      )
      .min(2, "Organization Unit must contain at least 2 characters")
      .max(25, "Organization Unit must not exceed 25 characters")
      .required("Organization Unit is required"),
    location: Yup.string()
      .matches(/^[a-zA-Z\s]*$/, "Only alphabets and spaces are allowed")
      .max(30, "Location must not exceed 30 characters"),
    state: Yup.string()
      .matches(/^[a-zA-Z\s]*$/, "Only alphabets and spaces are allowed")
      .max(25, "State must not exceed 25 characters"),
    country: Yup.string().required("Country is required"),
  });
const initialValues = {
  terminal: "",
  siteId: "",
  commonName: "",
  organization: "IAF",
  organizationUnit: "",
  location: "",
  state: "",
  country: "IN",
};

const XCertificateAdd = ({
  row,
  mode,
  onClose,
  onSuccess,
  onRefresh,
  refreshTrigger,
  isGrandchildFullScreen,
  allCertData = [],
}) => {
  const allTerminalsFromRedux = useSelector(
    (state) => state.nodeDetails.allTerminalTypeDetails
  );
  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  console.log(repDetails, "gdhdhdhdfhtrrecsvt5byhdf")
  const userName = useSelector(
    (state) => state.userSlice.userDetails.data.userName
  );
  const [showSanFields, setShowSanFields] = useState(true);

  const [DNS, setDNS] = useState("");
  const [IP, setIP] = useState("");

  const [dns, setDns] = useState([]);
  const [ip, setIp] = useState([]);

  const [dnsError, setDnsError] = useState("");
  const [ipError, setIpError] = useState("");
  const isValidDNS = (value) => {
    const dnsRegex =
      /^(?=.{1,255}$)(?!-)(?!.*\.\.)(?!.*--)[a-zA-Z0-9.*?&%#=:/-]+(?<!-)$/;

    return dnsRegex.test(value) && value.split(".").length <= 4;
  };

  const isValidIpV4 = (value) => {
    const parts = value.split(".");

    return (
      parts.length === 4 &&
      parts.every(
        (part) =>
          /^\d{1,3}$/.test(part) &&
          Number(part) >= 0 &&
          Number(part) <= 255
      )
    );
  };

  const handleDNSInput = (value) => {
    setDNS(value);

    if (!value.trim()) {
      setDnsError("DNS should not be empty");
    } else if (!isValidDNS(value.trim())) {
      setDnsError("Invalid DNS");
    } else {
      setDnsError("");
    }
  };

  const handleIPInput = (value) => {
    setIP(value);

    if (!value.trim()) {
      setIpError("IP address should not be empty");
    } else if (!isValidIpV4(value.trim())) {
      setIpError("Invalid IPv4 address");
    } else {
      setIpError("");
    }
  };

  const handleAddDNS = () => {
    const value = DNS.trim();

    if (!value || !isValidDNS(value)) {
      setDnsError(!value ? "DNS should not be empty" : "Invalid DNS");
      return;
    }

    setDns((prev) => [...prev, value]);
    setDNS("");
    setDnsError("");
  };

  const handleAddIP = () => {
    const value = IP.trim();

    if (!value || !isValidIpV4(value)) {
      setIpError(!value ? "IP address should not be empty" : "Invalid IPv4 address");
      return;
    }

    setIp((prev) => [...prev, value]);
    setIP("");
    setIpError("");
  };

  const handleRemoveDNS = (index) => {
    setDns((prev) => prev.filter((_, i) => i !== index));
  };

  const handleRemoveIP = (index) => {
    setIp((prev) => prev.filter((_, i) => i !== index));
  };

  const handleDNSListChange = (index, value) => {
    setDns((prev) =>
      prev.map((item, i) => (i === index ? value : item))
    );
  };

  const handleIPListChange = (index, value) => {
    setIp((prev) =>
      prev.map((item, i) => (i === index ? value : item))
    );
  };

  const [allSites, setAllSites] = useState([]);
  const [selectedTerminal, setSelectedTerminal] = useState("");
  const [enableIp, setEnableIP] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const terminalOptions = useMemo(() => {
    if (!Array.isArray(allTerminalsFromRedux)) return [];

    return allTerminalsFromRedux.map((terminal) => ({
      label: terminal?.terminalTypeName || "",
      value: terminal?.terminalTypeName || "",
      raw: terminal,
    }));
  }, [allTerminalsFromRedux]);

  const formik = useFormik({
    initialValues,
    validationSchema: schema,
    validateOnChange: true,
    validateOnBlur: true,
    validateOnMount: true,
    onSubmit: async (values) => {
      console.log("Form submitted successfully with values:", values); // <-- Add this
      setShowConfirm(true);
    },
  });

  const getError = (field) =>
    formik.touched[field] ? formik.errors[field] || null : null;

  const handleInputChange = (field) => (event) => {
    formik.setFieldValue(field, event.target.value);
  };

  const isCSRAlreadyExists = (commonName) => {
    if (!Array.isArray(allCertData)) return false;

    return allCertData.some(
      (cert) => cert?.commonName === commonName
    );
  };

  const handleFetchAllSiteDetails = async (selectedOption) => {
    const terminalValue =
      typeof selectedOption === "object"
        ? selectedOption?.value
        : selectedOption;

    if (!terminalValue) return;

    setSelectedTerminal(terminalValue);
    setEnableIP(
      terminalValue === "CNMS" || terminalValue === "HUB-NMS"
    );
    setAllSites([]);

    await formik.setFieldValue("terminal", terminalValue);
    await formik.setFieldValue("siteId", "");
    await formik.setFieldValue("commonName", "");
    await formik.setFieldTouched("terminal", true, false);

    try {
      if (terminalValue === "CNMS") {
        // Map site details directly from repDetails Redux slice for CNMS terminal
        setAllSites(Array.isArray(repDetails) ? repDetails : []);
        return;
      }

      const url =
        `${FETCH_TERMINAL_BY_TERMINAL_NAME}/${encodeURIComponent(
          terminalValue
        )}`;

      const response = await InventoryAxios(url, "get");
      const sites = response?.data?.lstSiteDetails;

      setAllSites(Array.isArray(sites) ? sites : []);
    } catch (error) {
      console.error("Error fetching site details:", error);
      setAllSites([]);
      Toast("Error!", "Failed to load site details", "error");
    }
  };


  const fetchCommonNameForSite = async (siteId, terminal) => {
    if (!siteId || !terminal || terminal === "CNMS") return;

    try {
      if (terminal === "HUB-NMS") {
        const url =
          `${GET_IP_ADDRESS_AT_CNMS_URL}/${encodeURIComponent(siteId)}`;

        const response = await InventoryAxios(url, "get");

        const ipAddress =
          typeof response?.data === "string" ? response.data : "";

        await formik.setFieldValue("commonName", ipAddress);
        await formik.setFieldTouched("commonName", true, false);
        return;
      }

      const response = await InventoryAxios(GET_MAC_ADDRESS, "post", {
        terminal,
        siteId,
      });

      const macAddress =
        typeof response?.data === "string"
          ? response.data.replace(/[:-]/g, "")
          : "";

      await formik.setFieldValue("commonName", macAddress);
      await formik.setFieldTouched("commonName", true, false);
    } catch (error) {
      console.error("Error fetching common name:", error);
      await formik.setFieldValue("commonName", "");
      Toast("Error!", "Failed to fetch Common Name", "error");
    }
  };

  const handleSiteChange = async (selectedOption) => {
    const selectedValue =
      typeof selectedOption === "object"
        ? selectedOption?.value
        : selectedOption;

    const siteId = selectedValue ? String(selectedValue) : "";

    await formik.setFieldValue("siteId", siteId);
    await formik.setFieldTouched("siteId", true, false);
    await formik.setFieldValue("commonName", "");
    await formik.setFieldTouched("commonName", false, false);

    if (siteId) {
      await fetchCommonNameForSite(siteId, selectedTerminal);
    }
  };

  const siteOptions = useMemo(() => {
    if (!Array.isArray(allSites)) return [];

    return allSites.map((site) => {
      const siteId = site?.id ?? site?.siteId ?? "";
      const siteName = site?.siteName ?? siteId;
      // const remoteNumber = site?.remoteNumber;

      return {
        value: String(siteId),
        label: String(siteName),
        raw: site,
      };
    });
  }, [allSites]);

  const handleSuccess = async (values) => {
    if (loading) return;

    setLoading(true);

    try {
      const commonName = values.commonName.trim();

      if (isCSRAlreadyExists(commonName)) {
        Toast(
          "Error!",
          `CSR already exists for ${commonName}`,
          "error"
        );
        return;
      }

      const payload = {
        organization: values.organization.trim(),
        organizationUnit: values.organizationUnit.trim(),
        country: values.country || "IN",
        commonName,
        algorthimName: "RSA",
        keySize: "2048",
        user: userName,
        terminal: values.terminal,
        siteId: values.siteId,
        location: values.location || "",
        state: values.state || "",
        dnsNames: showSanFields
          ? [...dns, ...(DNS.trim() ? [DNS.trim()] : [])]
          : [],

        ipAddresses: showSanFields
          ? [...ip, ...(IP.trim() ? [IP.trim()] : [])]
          : [],

      };

      const response = await CertAxios(
        CREATE_CSR_URL,
        "post",
        payload
      );

      if (
        response &&
        response.status >= 200 &&
        response.status < 300
      ) {
        Toast(
          "Success!",
          "CSR generated successfully!",
          "success"
        );

        formik.resetForm();
        setAllSites([]);
        setSelectedTerminal("");
        setEnableIP(false);
        setShowConfirm(false);
        setShowSanFields(true);
        setDNS("");
        setIP("");
        setDns([]);
        setIp([]);
        setDnsError("");
        setIpError("");

        if (typeof onRefresh === "function") onRefresh();
        if (typeof onSuccess === "function") onSuccess(response);
        if (typeof onClose === "function") onClose();
      } else {
        Toast("Error!", "Failed to generate CSR", "error");
      }
    } catch (error) {
      console.error("Error generating CSR:", error);

      const errorMessage =
        error?.response?.data?.message ||
        error?.message ||
        "Failed to generate CSR";

      Toast("Error!", errorMessage, "error");
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmSubmit = async () => {
    if (loading) return;

    setShowConfirm(false);

    const touchedFields = Object.keys(formik.values).reduce(
      (result, field) => {
        result[field] = true;
        return result;
      },
      {}
    );

    await formik.setTouched(touchedFields, false);

    const errors = await formik.validateForm();

    if (Object.keys(errors).length > 0) return;

    await handleSuccess(formik.values);
  };
  const isSaveDisabled = () => {
    const hasValidDNS =
  dns.some(
    (value) => value.trim() !== "" && isValidDNS(value.trim())
  ) ||
  (DNS.trim() !== "" && isValidDNS(DNS.trim()));

const hasValidIP =
  ip.some(
    (value) => value.trim() !== "" && isValidIpV4(value.trim())
  ) ||
  (IP.trim() !== "" && isValidIpV4(IP.trim()));

const sanInvalid =
  showSanFields && (!hasValidDNS || !hasValidIP);



  return (
    loading ||
    !formik.values.terminal ||
    !formik.values.siteId ||
    !formik.values.commonName ||
    !formik.values.organization ||
    !formik.values.organizationUnit ||
    !formik.values.country||
    sanInvalid
  );
};
 
  useEffect(() => {
    return () => {
      setAllSites([]);
    };
  }, []);

  return (
    <>
      <Box
        component="form"
        onSubmit={formik.handleSubmit}
        className="flex flex-col gap-5"
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            ml: 3,
            mr: 5,
          }}
        >
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>
              Terminal *
            </Typography>

            <MSelect
              options={terminalOptions}
              value={formik.values.terminal}
              onChange={handleFetchAllSiteDetails}
              placeholder="Select Terminal"
              error={getError("terminal")}
              errorMessage={getError("terminal")}
              disabled={terminalOptions.length === 0 || loading}
            />
          </Box>

          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              mt: 2,
            }}
          >
            <Typography sx={{ mb: 0.5, fontFamily: "Montserrat" }}>
              Site ID *
            </Typography>

            <MSelect
              options={siteOptions}
              value={formik.values.siteId}
              onChange={handleSiteChange}
              placeholder={
                formik.values.terminal
                  ? "Select Site ID"
                  : "Select Terminal first"
              }
              getOptionValue={(option) => option.value}
              getOptionLabel={(option) => option.label}
              disabled={!formik.values.terminal || loading}
              error={getError("siteId")}
              errorMessage={getError("siteId")}
            />

            {formik.values.terminal && siteOptions.length === 0 && (
              <Typography
                variant="caption"
                color="error"
                sx={{ mt: 1 }}
              >
                No Site IDs found for this Terminal.
              </Typography>
            )}
          </Box>

          <Box sx={{ mt: 2, mb: 2 }}>
            <FormField
              label={enableIp ? "IP Address" : "MAC Address"}
              required
              value={formik.values.commonName}
              onChange={handleInputChange("commonName")}
              onBlur={() =>
                formik.setFieldTouched("commonName", true)
              }
              error={Boolean(getError("commonName"))}
              errorMessage={getError("commonName")}
              placeholder={
                enableIp ? "___.___.___.___" : "AABBCCDDEEFF"
              }
              inputProps={{ maxLength:enableIp ? 15 : 12
               }}
              disabled={loading}
            />
          </Box>

          <Box sx={{ mb: 2 }}>
            <FormField
              label="Organization (O)"
              required
              value={formik.values.organization}
              onChange={handleInputChange("organization")}
              onBlur={() =>
                formik.setFieldTouched("organization", true)
              }
              error={Boolean(getError("organization"))}
              errorMessage={getError("organization")}
              inputProps={{ minLength: 2, maxLength: 25 }}
              disabled={loading}
            />
          </Box>

          <Box sx={{ mb: 2 }}>
            <FormField
              label="Organization Unit (OU)"
              required
              value={formik.values.organizationUnit}
              onChange={handleInputChange("organizationUnit")}
              onBlur={() =>
                formik.setFieldTouched("organizationUnit", true)
              }
              error={Boolean(getError("organizationUnit"))}
              errorMessage={getError("organizationUnit")}
              inputProps={{ minLength: 2, maxLength: 25 }}
              disabled={loading}
            />
          </Box>

          <Box sx={{ mb: 2 }}>
            <FormField
              label="Location"
              value={formik.values.location}
              onChange={handleInputChange("location")}
              onBlur={() =>
                formik.setFieldTouched("location", true)
              }
              error={Boolean(getError("location"))}
              errorMessage={getError("location")}
              inputProps={{ maxLength: 30 }}
              disabled={loading}
            />
          </Box>

          <Box sx={{ mb: 2 }}>
            <FormField
              label="State"
              value={formik.values.state}
              onChange={handleInputChange("state")}
              onBlur={() => formik.setFieldTouched("state", true)}
              error={Boolean(getError("state"))}
              errorMessage={getError("state")}
              inputProps={{ maxLength: 25 }}
              disabled={loading}
            />
          </Box>

          <Box sx={{ mb: 2 }}>
            <FormField
              label="Country"
              required
              value={formik.values.country}
              disabled
              error={Boolean(getError("country"))}
              errorMessage={getError("country")}
            />
          </Box>
          <Box sx={{ mt: 3, mb: 3, }}>
            <Paper
              elevation={0}
              sx={{
                border: "1px solid #E0E4E8",
                borderRadius: 3,
                overflow: "hidden",
                transition: "all 0.3s ease",

              }}
            >
              {/* Header Section */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  p: 2,
                  bgcolor: "#FFFFFF",
                  borderBottom: "1px solid #E0E4E8",
                  backgroundColor: "#14348d"
                }}
              >
                <Checkbox
                  checked={showSanFields}
                  onChange={(event) => {
                    setShowSanFields(event.target.checked);
                    if (!event.target.checked) {
                      setDNS("");
                      setIP("");
                      setDns([]);
                      setIp([]);
                      setDnsError("");
                      setIpError("");
                    }
                  }}
                  disabled={loading}
                />
                <Box >
                  <Typography sx={{ fontWeight: 700, fontSize: '0.95rem', color: 'white' }}>
                    Subject Alternative Name (SAN)
                  </Typography>
                  <Typography sx={{ fontSize: '0.75rem', color: 'white' }}>
                    Add DNS names or IP addresses to the certificate
                  </Typography>
                </Box>
              </Box>

              {showSanFields && (
                <Box sx={{ p: 3, display: "flex", flexDirection: "column", gap: 4 }}>

                  {/* --- DNS SECTION --- */}
                  <Box>
                    <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
                      <Language fontSize="small" />
                      <Typography sx={{ fontWeight: 600, }}>
                        DNS Names
                      </Typography>
                    </Stack>

                    <Box sx={{ display: "flex", gap: 1.5, alignItems: "flex-start" }}>
                      <Box sx={{ flex: 1 ,mb:1}}>
                        <FormField
                          label=" DNS *"
                          value={DNS}
                          onChange={(event) => handleDNSInput(event.target.value)}
                          error={Boolean(dnsError)}
                          errorMessage={dnsError}
                          placeholder="e.g. cnmsksl.iaf.in"
                          inputProps={{ maxLength: 150 }}
                          disabled={loading}
                        />
                      </Box>
                      <Box sx={{ pt: 3.5 }}> {/* pt: 1 aligns the button with the input field if there is a label */}
                        <MButtonPrimary
                          type="button"
                          onClick={handleAddDNS}
                          disabled={loading || !DNS.trim() || Boolean(dnsError)}
                        >
                          <Add />
                        </MButtonPrimary>
                      </Box>
                    </Box>

                    {/* List of added DNS items */}
                    <Stack spacing={1.5}>
                      {dns.map((value, index) => (
                        <Box
                          key={`dns-${index}`}
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                            p: 1,
                            pr: 0.5,
                            bgcolor: "#FFFFFF",
                            border: "1px solid #E2E8F0",
                            borderRadius: 2,
                          }}
                        >
                          <Typography sx={{ px: 1, }}>
                            {index + 1}
                          </Typography>
                          <Box sx={{ flex: 1 }}>
                            <FormField
                              value={value}
                              onChange={(event) => handleDNSListChange(index, event.target.value)}
                              disabled={loading}
                              sx={{ '& .MuiInputBase-root': { fontSize: '0.875rem' } }}
                              // Note: Hide label for list items to save space
                              label={undefined}
                            />
                          </Box>
                          <Tooltip title="Remove">
                            <IconButton
                              onClick={() => handleRemoveDNS(index)}
                              color="error"
                              size="small"
                              disabled={loading}
                            >
                              <Delete fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      ))}
                    </Stack>
                  </Box>

                  <Divider sx={{ ml: -4, mr: -6 }} />

                  {/* --- IP SECTION --- */}
                  <Box sx={{ display: "flex", gap: 1, alignItems: "flex-start" }}>
                    <Box sx={{ flex: 1}}>
                      <FormField
                        label="IP Address *"
                        value={IP}
                        onChange={(event) => handleIPInput(event.target.value)}
                        error={Boolean(ipError)}
                        errorMessage={ipError}
                        placeholder="___.___.___.___"
                        inputProps={{ maxLength: 15 }}
                        disabled={loading}
                      />
                    </Box>
                    <Box sx={{ pt: 3.5 }}> {/* pt: 1 helps align button with input if label exists */}
                      <MButtonPrimary
                        type="button"
                        onClick={handleAddIP}
                        disabled={loading || !IP.trim() || Boolean(ipError)}
                      >
                        <Add />
                      </MButtonPrimary>
                    </Box>
                  </Box>
                  {/* List of added IP items */}
                  <Stack spacing={1.5} >
                    {ip.map((value, index) => (
                      <Box
                        key={`ip-${index}`}
                        sx={{
                          display: "flex",
                          alignItems: "center",
                    
                          p: 1,
                          pr: 0.5,
                          bgcolor: "#FFFFFF",
                          border: "1px solid #E2E8F0",
                          borderRadius: 2,
                        }}
                      >
                        <Typography sx={{ px: 1, }}>
                          {index + 1}
                        </Typography>
                        <Box sx={{ flex: 1 }}>
                          <FormField
                            value={value}
                            onChange={(event) => handleIPListChange(index, event.target.value)}
                            disabled={loading}
                            sx={{ '& .MuiInputBase-root': { fontSize: '0.875rem' } }}
                            label={undefined}
                          />
                        </Box>
                        <Tooltip title="Remove">
                          <IconButton
                            onClick={() => handleRemoveIP(index)}
                            color="error"
                            size="small"
                            disabled={loading}
                          >
                            <Delete fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    ))}
                  </Stack>
                </Box>
               
              )}
        </Paper>
      </Box>

      <Box
        sx={{
          display: "flex",
          mt: 3,
          justifyContent: "flex-end",
        }}
      >
        <MButtonPrimary
          type="button" // Change from submit to button to handle click manually
          onClick={formik.handleSubmit}
          disabled={isSaveDisabled()}
        >
          {loading ? (
            <CircularProgress size={20} color="inherit" />
          ) : (
            "Generate"
          )}
        </MButtonPrimary>
      </Box>
    </Box >
      </Box >

  <MDialog
    open={showConfirm}
    variant="warning"
    title="Confirm Action"
    message="Are you sure you want to generate CSR certificate?"
    onConfirm={handleConfirmSubmit}
    onClose={() => setShowConfirm(false)}
    mode="grandchild"
    isGrandchildFullScreen={isGrandchildFullScreen}
    icon={confirmation_icon}
  />
    </>
  );
};

export default XCertificateAdd;
