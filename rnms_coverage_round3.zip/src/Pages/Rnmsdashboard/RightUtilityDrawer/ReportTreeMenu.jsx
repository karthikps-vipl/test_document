// import React, { useState, useEffect } from "react";
// import {
//   List,
//   ListItemButton,
//   ListItemText,
//   Collapse,
//   Box,
//   TextField,
//   InputAdornment,
//   useTheme,
// } from "@mui/material";
// import { ExpandMore, ChevronRight, Search } from "@mui/icons-material";

// const ReportTreeItem = ({ node, level = 0, selectedKey, onSelect, search }) => {
//   const theme = useTheme(); // 2. Initialize theme
//   const isdarkmode = theme.palette.mode === "dark";
//   const hasChildren = node.children && node.children.length > 0;
//   const [open, setOpen] = useState(false);

//   // Auto-expand folder nodes if a search query is active
//   useEffect(() => {
//     if (search && hasChildren) {
//       setOpen(true);
//     }
//   }, [search, hasChildren]);

//   const isSelected = selectedKey === node.key;
//   const getSelectedBgColor = () => {
//     if (!isSelected) return "transparent";

//     if (level === 0) {
//       return "#E9EFFF"; // Original Root selection color
//     } else {
//       // CHANGE THIS: This is the color for selected CHILD nodes
//       return isdarkmode ? "rgba(255, 255, 255, 0.15)" : "#E0E7FF"; 
//     }
//   };

//   const getSelectedTextColor = () => {
//     if (!isSelected) return "inherit";
//     return level === 0 ? "#14348D" : ""; // Dark blue for root, Grey for children
//   };

//   const handleClick = (e) => {
//     e.stopPropagation();
//     if (hasChildren) {
//       setOpen(!open);
//     } else {
//       onSelect(node.key);
//     }
//   };
//   const darkHoverColor = "rgba(255, 255, 255, 0.12)"; 
//   return (
//     <>
//       <Box sx={{ position: "relative" }}>
//         {/* Dynamic Vertical Guide Lines for Deep Hierarchy nesting */}
//         {level > 0 && (
//           <Box
//             sx={{
//               position: "absolute",
//               left: `${level * 16}px`,
//               top: 0,
//               bottom: 0,
//               borderLeft: "1.5px solid #d0d0d0",
//               zIndex: 1,
//             }}
//           />
//         )}

// <ListItemButton
//           sx={{
//             pl: 2 + level * 2,
//             // Use the dynamic functions here
//             bgcolor: getSelectedBgColor(),
//             color: getSelectedTextColor(),
//             "&:hover": {
//               bgcolor: isSelected
//                 ? getSelectedBgColor() // Keep selection color on hover
//                 : (isdarkmode ? "rgba(255, 255, 255, 0.08)" : "#F5F8FF"),
//             },
//             borderRadius: "8px",
//             margin: "2px 0",
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "space-between",
//           }}
//           onClick={handleClick}
//         >
//           <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//             {node.icon && (
//               <span
//                 style={{
//                   color: "#14348D",
//                   filter: "invert(1) brightness(2)" // This inverts the color and boosts brightness
//                 }}
//               >
//                 {node.icon}
//               </span>
//             )}            <ListItemText
//               primary={node.label}
//               primaryTypographyProps={{
//                 fontWeight: isSelected ? 600 : hasChildren ? 500 : 400,
//                 fontSize: "0.85rem",
//               }}
//             />
//           </Box>
//           {hasChildren ? (
//             open ? (
//               <ExpandMore fontSize="small" />
//             ) : (
//               <ChevronRight fontSize="small" />
//             )
//           ) : null}
//         </ListItemButton>
//       </Box>

//       {hasChildren && (
//         <Collapse in={open} timeout="auto" unmountOnExit>
//           <List component="div" disablePadding>
//             {node.children.map((child) => (
//               <ReportTreeItem
//                 key={child.key || child.label}
//                 node={child}
//                 level={level + 1}
//                 selectedKey={selectedKey}
//                 onSelect={onSelect}
//                 search={search}
//               />
//             ))}
//           </List>
//         </Collapse>
//       )}
//     </>
//   );
// };

// export const ReportTreeMenu = ({ treeData, selectedKey, onSelect }) => {
//   const [searchQuery, setSearchQuery] = useState("");

//   // Simple local search filter for the tree structure
//   const filteredTree = React.useMemo(() => {
//     if (!searchQuery.trim()) return treeData;
//     const lowerQuery = searchQuery.toLowerCase();

//     return treeData
//       .map((node) => {
//         if (node.label.toLowerCase().includes(lowerQuery)) return node;
//         if (node.children) {
//           const filteredChildren = node.children.filter((child) =>
//             child.label.toLowerCase().includes(lowerQuery)
//           );
//           if (filteredChildren.length > 0) {
//             return { ...node, children: filteredChildren };
//           }
//         }
//         return null;
//       })
//       .filter(Boolean);
//   }, [treeData, searchQuery]);

//   return (
//     <Box
//       sx={{ display: "flex", flexDirection: "column", height: "100%", }}
//     >
//       <Box sx={{ mb: 2 }}>
//         <TextField
//           fullWidth
//           size="small"
//           variant="outlined"
//           placeholder="Filter reports..."
//           value={searchQuery}
//           onChange={(e) => setSearchQuery(e.target.value)}
//           InputProps={{
//             startAdornment: (
//               <InputAdornment position="start">
//                 <Search fontSize="small" style={{ color: "#14348D" }} />
//               </InputAdornment>
//             ),
//             style: { borderRadius: "10px", fontSize: "0.85rem" },
//           }}
//         />
//       </Box>
//       <Box sx={{ flex: 1, overflowY: "auto" }}>
//         <List>
//           {filteredTree.map((node) => (
//             <ReportTreeItem
//               key={node.key || node.label}
//               node={node}
//               level={0}
//               selectedKey={selectedKey}
//               onSelect={onSelect}
//               search={searchQuery}
//             />
//           ))}
//         </List>
//       </Box>
//     </Box>
//   );
// };
import React, { useState, useEffect } from "react";
import {
  List,
  ListItemButton,
  ListItemText,
  Collapse,
  Box,
  TextField,
  InputAdornment,
  useTheme,
} from "@mui/material";
import { ExpandMore, ChevronRight, } from "@mui/icons-material";
import search_b from "@/assets/SVGIcons/search_b.svg"

const ReportTreeItem = ({ node, level = 0, selectedKey, onSelect, search, allNodes }) => {
  const theme = useTheme();
  const isdarkmode = theme.palette.mode === "dark";
  const hasChildren = node.children && node.children.length > 0;
  const [open, setOpen] = useState(false);

  // --- LOGIC TO FIND IF THIS NODE IS A PARENT OF THE SELECTED KEY ---
  const checkIfParent = (currentNode, targetKey) => {
    if (!currentNode.children) return false;
    return currentNode.children.some((child) => {
      if (child.key === targetKey) return true;
      return checkIfParent(child, targetKey);
    });
  };

  const isSelected = selectedKey === node.key;
  const isParent = checkIfParent(node, selectedKey);


  const getStyles = () => {
    if (isSelected) {
      return {
        bgcolor: isdarkmode ? "rgba(255, 255, 255, 0.15)" : " #9bb3ea",
        color: isdarkmode ? "#fff" : "#000",
        fontWeight: 800,
      };
    }
    if (isParent) {
      return {
        // Highlight parents with a subtle background or a left border
        bgcolor: isdarkmode ? "rgba(255, 255, 255, 0.31)" : " rgb(66, 99, 188) ",
        color: "inherit",
        fontWeight: 500,
      };
    }
    return {
      bgcolor: "transparent",
      color: "inherit",
      fontWeight: hasChildren ? 500 : 400,
    };
  };

  const styles = getStyles();

  useEffect(() => {
    if (search && hasChildren) {
      setOpen(true);
    }
  }, [search, hasChildren]);

  const handleClick = (e) => {
    e.stopPropagation();
    if (hasChildren) {
      setOpen(!open);
    } else {
      onSelect(node.key);
    }
  };

  return (
    <>
      <Box sx={{ position: "relative" }}>
        {level > 0 && (
          <Box
            sx={{
              position: "absolute",
              left: `${level * 25}px`,
              top: 0,
              bottom: 0,
              borderLeft: isParent ? "2px solid #14348D" : "1.5px solid #d0d0d0", // Thicker line if it's a parent
              zIndex: 1,
              transition: "all 0.2s",
            }}
          />
        )}
        <ListItemButton
          sx={{
            pl: 2 + level * 2,
            bgcolor: styles.bgcolor,
            color: styles.color,
            fontWeight: styles.fontWeight,
            // "&:hover": {
            //   bgcolor: isSelected
            //     ? styles.bgcolor
            //     : (isdarkmode ? "rgba(255, 255, 255, 0.11)" : "#5583e5"),
            // },
            borderRadius: "8px",
            margin: "2px 0",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
          onClick={handleClick}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            {hasChildren ? (
              open ? <ExpandMore fontSize="small" /> : <ChevronRight fontSize="small" />
            ) : null}
            {node.icon && (
              <span
                style={{
                  color: "inherit", // Follows the ListItemText color
                  filter: theme.palette.custom.icon.iconFilter, 
                }}
              >
                {node.icon}
              </span>
            )}

            <ListItemText
              primary={node.label}
              primaryTypographyProps={{
                fontSize: "0.85rem",
              }}
            />
          </Box>

        </ListItemButton>
      </Box>
      {hasChildren && (
        <Collapse in={open || isParent} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {node.children.map((child) => (
              <ReportTreeItem
                key={child.key || child.label}
                node={child}
                level={level + 1}
                selectedKey={selectedKey}
                onSelect={onSelect}
                search={search}
              />
            ))}
          </List>
        </Collapse>
      )}
    </>
  );
};

export const ReportTreeMenu = ({ treeData, selectedKey, onSelect }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const theme = useTheme();
  const isdarkmode = theme.palette.mode === "dark";
  const filteredTree = React.useMemo(() => {
    if (!searchQuery.trim()) return treeData;
    const lowerQuery = searchQuery.toLowerCase();
    return treeData
      .map((node) => {
        if (node.label.toLowerCase().includes(lowerQuery)) return node;
        if (node.children) {
          const filteredChildren = node.children.filter((child) =>
            child.label.toLowerCase().includes(lowerQuery)
          );
          if (filteredChildren.length > 0) {
            return { ...node, children: filteredChildren };
          }
        }
        return null;
      })
      .filter(Boolean);
  }, [treeData, searchQuery]);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <Box sx={{ mb: 2 }}>
        <TextField
          fullWidth
          size="small"
          variant="outlined"
          placeholder="Filter reports..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",

                    borderRadius: "4px",
                    p: 0.5,
                  }}
                >
                  <img
                    src={search_b}
                    alt="search"
                    style={{
                      width: '18px', // adjust size as needed
                      height: '18px',

                      filter: isdarkmode ? "invert(1) brightness(2)" : "none"
                    }}
                  />
                </Box>
              </InputAdornment>
            ),
            style: { borderRadius: "10px", fontSize: "0.85rem" },
          }}
        />
      </Box>
      <Box sx={{ flex: 1, overflowY: "auto" }}>
        <List>
          {filteredTree.map((node) => (
            <ReportTreeItem
              key={node.key || node.label}
              node={node}
              level={0}
              selectedKey={selectedKey}
              onSelect={onSelect}
              search={searchQuery}
            />
          ))}
        </List>
      </Box>
    </Box>
  );
};