/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : RightUtilityDrawer
   File Name                : RightUtilityDrawer.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\Pages\Rnmsdashboard\RightUtilityDrawer\RightUtilityDrawer.jsx
   Purpose                  : A reusable side-drawer component used to display utility 
                              previliges. 
   Created Date             : 20-03-2026
***********************************************************************************************/
import React, {
  useState,
  useMemo,
  useEffect,
  useRef,
  useCallback,
  
} from "react";
import {
  Drawer,
  Box,
  Tooltip,
  Popover,
  IconButton,
  Typography,
  
} from "@mui/material";
import {
  Search,
  //Fullscreen as FullscreenIcon,
  ChevronLeft,
  ChevronRight,
  Folder,
} from "lucide-react";
import { useSelector } from "react-redux";
import {
  Close as CloseIcon,
  Description,
  
  FullscreenExit,
  Fullscreen as FullscreenIcon,
} from "@mui/icons-material";
import { styled, useTheme } from "@mui/material/styles";

import {
  FileList,
  IconList,
} from "../../../utility/RightSideBar/iconAndFileList";
 
import ConfigEditRepDetails from "./components/Configuration/RepDetails/ConfigEditRepDetails";
import ConfigAddRepDetails from "./components/Configuration/RepDetails/ConfigAddRepDetails";
import ConfigAddDeviceLogin from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/DeviceLoginManagement/ConfigAddDeviceLogin";
import ConfigEditDeviceLogin from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/DeviceLoginManagement/ConfigEditDeviceLogin";
import ConfigViewDeviceLogin from "./components/Configuration/DeviceLoginManagement/ConfigViewDeviceLogin";
import PerformanceAddThreshold from "./components/Performance/Threshold/PerformanceAddThreshold";
import PerformanceEditThreshold from "./components/Performance/Threshold/PerformanceEditThreshold";
import SiteConfigCreateProfile from "./components/SiteConfiguator/Snmp/SiteConfigCreateProfile";
import SiteConfigEditProfile from "./components/SiteConfiguator/Snmp/SiteConfigEditProfile";
import SiteConfigViewProfile from "./components/SiteConfiguator/Snmp/SiteConfigViewProfile";
import ConfigAddScheduleBackup from "./components/Configuration/ScheduleBackup/ConfigAddScheduleBackup";
import ConfigEditScheduleBackup from "./components/Configuration/ScheduleBackup/ConfigEditScheduleBackup";
import ConfigViewScheduleBackup from "./components/Configuration/ScheduleBackup/ConfigViewScheduleBackup";
import { ReportTreeMenu } from "./ReportTreeMenu";
import reportTreeData from "../../../JsonFile/ReportTreeView.json";
import parentIconAudit from "@/assets/SVGIcons/Audit.svg";
import parentIconFault from "@/assets/SVGIcons/Fault.svg";
import parentIconInventory from "@/assets/SVGIcons/Inventory.svg";
import parentIconPerformance from "@/assets/SVGIcons/Performances.svg";
import parentIconDatabase from "@/assets/SVGIcons/Database.svg";
import HandleReopenAction from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleHistoryAction";
import HelpDeskCreate from "./components/HelpDesk/HelpDeskCreate";
import HandleHistoryAction from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleHistoryAction";
import ScrollContainer from "@/components/Reusable/Scrollbar/ScrollContainer";
import SearchIcon from "@/assets/SVGIcons/search.svg";
import ConfigAddRemoteRep from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/RemoteRep/ConfigAddRemoteRep";
import ConfigEditRemoteRep from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/RemoteRep/ConfigEditRemoteRep";
import IPwhiteListAdd from "./components/Security/IPwhitelisting/IPwhiteListAdd";
import UserMgmtAdd from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/UserMgmtAdd";
import UserMgmtEdit from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/UserMgmtEdit";
import GroupMgmtAdd from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtAdd";
import GroupViewDetails from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtView";
import GroupMgmtEdit from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtEdit";
import XCertificateAdd from "./components/XCertificate/XCertificateAdd";
import RoleAssignmentForm from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/RoleAssignmentDialog";
import ViewRemoteGroup from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/RemoteGroup/ViewRemoteGroup";
import AddRemoteGroup from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/RemoteGroup/AddRemoteGroup";
import CnmsSyslogSettingsAdd from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsTools/CnmsSyslogSettingsAdd";
import CnmsSyslogSettingsEdit from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsTools/CnmsSyslogSettingsEdit";
const FORM_MAPPING = {
  configuration_rep: {
    CREATE: ConfigAddRepDetails,
    EDIT: ConfigEditRepDetails,
    VIEW: null,
  },
  performance_settings_threshold: {
    CREATE: PerformanceAddThreshold,
    EDIT: PerformanceEditThreshold,
    VIEW: null,
  },
  configuration_device_login_management: {
    CREATE: ConfigAddDeviceLogin,
    EDIT: ConfigEditDeviceLogin,
    VIEW: ConfigViewDeviceLogin,
  },
  site_config_snmp: {
    CREATE: SiteConfigCreateProfile,
    EDIT: SiteConfigEditProfile,
    VIEW: SiteConfigViewProfile,
  },
  configuration_schedule_backup: {
    CREATE: ConfigAddScheduleBackup,
    EDIT: ConfigEditScheduleBackup,
    VIEW: ConfigViewScheduleBackup,
  },
  help_desk_child: {
    CREATE: HelpDeskCreate,
    CLOSE: HelpDeskCreate,
    HISTORY: HandleHistoryAction,
    REOPEN: HandleReopenAction,
  },
  configuration_remote_rep: {
    CREATE: ConfigAddRemoteRep,
    EDIT: ConfigEditRemoteRep,
  },
  security_ip: {
    CREATE: IPwhiteListAdd,
  },
  security_user: {
    CREATE: UserMgmtAdd,
    EDIT: UserMgmtEdit,
  },
  security_group: {
    CREATE: GroupMgmtAdd,
    VIEW: GroupViewDetails,
    EDIT: GroupMgmtEdit,
  },
  "x.509_cert_child": {
    CREATE: XCertificateAdd,
  },
  site_config_rnms_role_assignment: {
    CREATE: RoleAssignmentForm,
  },
  site_config_remote_group: {
    CREATE: AddRemoteGroup,
    VIEW: ViewRemoteGroup,
    EDIT: AddRemoteGroup,
  },
  tools_fm_syslog_settings: {
    CREATE: CnmsSyslogSettingsAdd,
    EDIT: CnmsSyslogSettingsEdit,
  },
};

export const SquareIconButton = styled(IconButton)(({ theme }) => ({
  // Light mode: light blue | Dark mode: dark blue/grey
  backgroundColor: theme.palette.mode === "light" ? "#D7EEFF" : "#3e3b3b",
  borderRadius: "20%",
  width: "30px",
  height: "30px",
  padding: "0",
  margin: "0",
  color: theme.palette.text.primary, // Ensures the X icon is visible
  "& .MuiIconButton-root": {
    borderRadius: "0",
  },
  "& .MuiIconButton-icon": {
    fontSize: "12px",
  },
  "&:hover": {
    // Add a slight hover effect for better UX
    backgroundColor: theme.palette.mode === "light" ? "#BEE3F8" : "#3D3D3D",
  },
}));

const RightUtilityDrawer = ({ selectedNode }) => {
  const [activeParent, setActiveParent] = useState(null);
  const [activeChild, setActiveChild] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchAnchor, setSearchAnchor] = useState(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [drawerWidth, setDrawerWidth] = useState("45%");
  const [isSubFullScreen, setIsSubFullScreen] = useState(false);
  // Track hover state for the expanding sidebar
  const [isHovered, setIsHovered] = useState(false);

  const [subDrawerData, setSubDrawerData] = useState(null);
 
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const { userDetails } = useSelector((state) => state.userSlice);
  const privilege = userDetails?.data?.group?.privileges || [];
  const { siteDetails } = useSelector((state) => state.nodeDetails);
  const deployedType = siteDetails?.id === 1 ? "cnms" : "rnms";
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);
  const [refreshMap, setRefreshMap] = useState({});
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const EXCLUDED_KEYS = [
    "delete_rnms_site",           // The "Delete Site" parent
    "sms_email",                  // The "SMS and E-Mail Settings" parent
    "sms_email_settings",         // The child under SMS
    "alarm_settings_alarm_workflow", // The child under Alarm Settings
    "alarm_settings_alarm_suppression"
  ];

  // Helper to check if an item should be hidden
  const shouldHideItem = (item) => {
    if (isCnms) {
      // If CNMS: Hide the specific CNMS items + the shared items
      if (EXCLUDED_KEYS.includes(item.key)) return true;
    } else {
      // If RNMS: Only hide the shared items (Alarm Workflow & Suppression)
      // The CNMS specific items (SMS, Delete Site) are NOT hidden in RNMS
      if (EXCLUDED_KEYS.includes(item.key)) return true;
    }
    return false;
  };
  useEffect(() => {
    if (searchAnchor) {
      const timer = setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [searchAnchor]);
  const triggerRefresh = useCallback((key) => {
    setRefreshMap((prev) => ({
      ...prev,
      [key]: (prev[key] || 0) + 1,
    }));
  }, []);

  const filteredPrivileges = useMemo(() => {
    if (!privilege) return [];
    return privilege.filter((item) =>
      deployedType === "rnms" ? item.rnms : item.cnms
    );
  }, [privilege, deployedType]);
  //disabling NMS CHAT BOT icon in Right side menu
  const parentPrivileges = useMemo(
    () =>
      filteredPrivileges.filter(
        (item) => 
          item.parent === 0 && 
          item.key !== "nms_chat_bot" &&
          !shouldHideItem(item) // Apply exclusion check for top-level items too
      ),
    [filteredPrivileges, isCnms]
  );
  const getIconForKey = (key) => IconList[key] || null;
 
  const getChildren = (parentId) => {
    return filteredPrivileges.filter((item) => {
      // Basic parent check
      if (item.parent !== parentId) return false;
      
      // Apply global exclusion logic
      if (shouldHideItem(item)) return false;

      return true;
    });
  };
  // const getChildren = (parentId) =>
  //   filteredPrivileges.filter((item) => item.parent === parentId);

  const currentActiveParentObj = useMemo(() => {
    return parentPrivileges.find((p) => p.id === activeParent);
  }, [parentPrivileges, activeParent]);
  const theme = useTheme();
  const isdark = theme.palette.mode === "dark";
  const isReportsCategory = useMemo(() => {
    if (!currentActiveParentObj) return false;
    const name = currentActiveParentObj.privilegeName.toLowerCase();
    const key = currentActiveParentObj.key?.toLowerCase() || "";
    return name.includes("report") || key.includes("report");
  }, [currentActiveParentObj]);

  const reportsTreeStructure = useMemo(() => {
    if (!isReportsCategory || !activeParent || !reportTreeData) return [];

    return Object.entries(reportTreeData).reduce(
      (acc, [groupKey, groupData]) => {
        const isGroupValid =
          groupData.terminalType === "BOTH" ||
          groupData.terminalType?.toLowerCase() === deployedType;

        if (!isGroupValid) return acc;

        const childLeaves = (groupData.components || [])
          .filter((child) => {
            return (
              child.terminalType === "BOTH" ||
              child.terminalType?.toLowerCase() === deployedType
            );
          })
          // .map((child) => ({
          //   key: child.key,
          //   label: child.title.toUpperCase(),
          //   icon: <Description fontSize="small" style={{ color: "black" }} />,
          //   children: null,
          //   activeTabConfig: {
          //     mainParent: groupData.key,
          //     key: child.key,
          //     label: child.title,
          //     fields: child.fields,
          //   },
          //   metaFields: child.fields,
          // }));
          .map((child) => {
            // --- LOGIC ADDED HERE ---
            let displayLabel = child.title.toUpperCase();

            // Check if the key matches your specific requirement
            if (child.key === "db_BackupStatusLog") {
              // Convert deployedType to uppercase to match standard naming (CNMS/RNMS)
              const prefix = deployedType?.toUpperCase() || "RNMS";
              displayLabel = `${prefix} ${child.title.toUpperCase()}`;
            }
            // -------------------------

            return {
              key: child.key,
              label: displayLabel, // Use the new dynamic label
              icon: <Description fontSize="small" style={{ color: "black" }} />,
              children: null,
              activeTabConfig: {
                mainParent: groupData.key,
                key: child.key,
                label: child.title, // Keep original title for config if needed
                fields: child.fields,
              },
              metaFields: child.fields,
            };
          });
        if (childLeaves.length > 0) {
          const getParentIcon = (key) => {
            switch (key) {
              case "audit":
                return parentIconAudit;
              case "fault":
                return parentIconFault;
              case "inventory":
                return parentIconInventory;
              case "performance":
                return parentIconPerformance;
              case "database":
                return parentIconDatabase;
              default:
                return <Folder fontSize="small" />;
            }
          };
          acc.push({
            label: groupData.title,
            icon: (
              <img
                src={getParentIcon(groupKey)}
                alt={groupData.title}
                style={{ width: "20px", height: "20px", objectFit: "contain" }}
              />
            ),
            children: childLeaves,
          });
        }

        return acc;
      },
      []
    );
  }, [isReportsCategory, activeParent, deployedType]);

  useEffect(() => {
    if (isReportsCategory && reportsTreeStructure.length > 0 && !activeChild) {
      const firstGroup = reportsTreeStructure[0];
      if (firstGroup.children && firstGroup.children.length > 0) {
        setActiveChild(firstGroup.children[0].key);
      }
    }
  }, [isReportsCategory, reportsTreeStructure]);

  const suggestions = useMemo(() => {
    if (!searchQuery.trim()) return parentPrivileges;
    const lower = searchQuery.toLowerCase();
    return filteredPrivileges.filter(
      (item) =>
        item.privilegeName.toLowerCase().includes(lower) ||
        item.key.toLowerCase().includes(lower)
    );
  }, [searchQuery, filteredPrivileges, parentPrivileges]);

  const handleSelectFromSearch = (item) => {
    if (item.parent === 0) {
      setActiveParent(item.id);
      setActiveChild(null);
    } else {
      setActiveParent(item.parent);
      setActiveChild(item.id);
    }
    setSearchQuery("");
    setSearchAnchor(null);
  };

  const toggleParent = (parentId) => {
    if (activeParent === parentId) {
      setActiveParent(null);
      setActiveChild(null);
      setSubDrawerData(null);
    } else {
      setActiveParent(parentId);
      setActiveChild(null);
    }
  };

  const activeChildKey = useMemo(() => {
    const targetId = activeChild || getChildren(activeParent)[0]?.id;
    return filteredPrivileges.find((i) => i.id === targetId)?.key;
  }, [activeChild, activeParent, filteredPrivileges]);
  //new scroll
  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      // Use a 1px buffer to account for sub-pixel rendering
      setCanScrollLeft(scrollLeft > 1);
      setCanScrollRight(scrollWidth - clientWidth - scrollLeft > 1);
    }
  };

  // Check scroll on mount and when content changes
  useEffect(() => {
    // Small timeout ensures the DOM is fully painted and drawer animation is finished
    const timer = setTimeout(() => {
      checkScroll();
    }, 300);

    window.addEventListener("resize", checkScroll);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("resize", checkScroll);
    };
  }, [getChildren(activeParent)]); // Re-run if children change

  const scroll = (direction) => {
    if (scrollRef.current) {
      const scrollAmount = 200; // Adjust scroll speed
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  // Monitor scroll event to update buttons state
  const handleScroll = () => {
    checkScroll();
  };
  const tabs = getChildren(activeParent);
  const inactiveTextColor =
    theme.palette.mode === "dark" ? "text-white" : "text-[#14348D]";
  const activeBg = theme.palette.mode === "dark" ? "#14348d" : "#D5E0FF";
  const activeIcon = theme.palette.mode === "dark" ? "#fff" : "#14348d";
  const disabledBg =
    theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "#F0F0F0";
  const disabledIcon = theme.palette.mode === "dark" ? "#666666" : " #A0A0A0";

  // const handleTabClick = (childId, e) => {
  //   setActiveChild(childId);
  //   setSubDrawerData(null);

  //   const element = e.currentTarget;
  //   element.scrollIntoView({
  //     behavior: "smooth",
  //     block: "nearest",
  //     inline: "start",
  //   });

  //   // REMOVED setTimeout. The onScroll event will trigger
  //   // as the element slides into view.
  // };
  const handleTabClick = (childId, e, index) => {
    setActiveChild(childId);
    setSubDrawerData(null);

    const container = scrollRef.current;
    const element = e.currentTarget;

    if (container && element) {
      // 1. HARD FIX FOR FIRST TAB: If clicking/double-clicking index 0, jump to absolute 0
      if (index === 0) {
        container.scrollTo({
          left: 0,
          behavior: "smooth",
        });
        setCanScrollLeft(false); // Force disable left arrow instantly
        return;
      }

      // 2. Normal scroll offset calculation for other items
      const containerRect = container.getBoundingClientRect();
      const elementRect = element.getBoundingClientRect();

      const newScrollLeft =
        container.scrollLeft + (elementRect.left - containerRect.left);

      container.scrollTo({
        left: newScrollLeft,
        behavior: "smooth",
      });

      // Recalculate scroll limits when smooth movement completes
      const onScrollEnd = () => {
        checkScroll();
        container.removeEventListener("scrollend", onScrollEnd);
      };

      container.addEventListener("scrollend", onScrollEnd);
      setTimeout(checkScroll, 350);
    }
  };
  return (
    <Box
      className="flex h-full relative   "
      sx={{ border: (theme) => theme.palette.custom.dashboardBorder }}
    >
      <ScrollContainer className="h-full">
        <Box
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className={`flex flex-col items-center p-4 gap-y-2.5  h-full z-10 transition-all duration-300 ease-in-out   ${
            isHovered ? "w-[220px]" : "w-[80px]" // CHANGE THIS: 20 -> 50, and 56 -> 300
          }`}
          sx={{
            // Ensure the background is visible even when it's just the slim bar
            backgroundColor: (theme) => theme.palette.background.toplogybg,
          }}
        >
          {/* Search Layout Button Area */}
          <Tooltip title={!isHovered ? "Search" : ""} placement="left" arrow>
            <button
              onClick={(e) => setSearchAnchor(e.currentTarget)}
              style={{
                color: (theme) =>
                  theme.palette.custom.rightUtilityDrawer.headerText,
              }}
              className={`flex items-center justify-start gap-3 p-3 w-full rounded-xl transition-all border  overflow-hidden ${
                isdark
                  ? "border-[#4f4d4d] hover:bg-gray-700"
                  : "border-gray-300 hover:bg-gray-200"
              }`}
            >
              <Box className="flex-shrink-0 flex items-center justify-center  ">
                <img
                  src={SearchIcon}
                  alt="Search"
                  className={`w-[18px] h-[18px] object-contain ${
                    isdark ? "brightness-0 invert" : ""
                  }`}
                />
              </Box>

              <span
                className={`text-xs font-semibold tracking-wide transition-all duration-200 whitespace-nowrap ${
                  isHovered
                    ? "opacity-100 translate-x-0"
                    : "opacity-0 -translate-x-4 hidden"
                }`}
                // 2. Dynamically set text color based on isdark
                style={{ color: isdark ? "#ffffff" : "#374151" }} // Matches your theme headerText
              >
                Search Options
              </span>
            </button>
          </Tooltip>

          <Popover
            open={Boolean(searchAnchor)}
            anchorEl={searchAnchor}
            onClose={() => {
              setSearchAnchor(null);
              setSearchQuery("");
            }}
            disableRestoreFocus
            disableEnforceFocus
            anchorOrigin={{ vertical: "center", horizontal: "left" }}
            transformOrigin={{ vertical: "center", horizontal: "right" }}
            sx={{ mt: "8%", mr: 5 }}
          >
            <Box className="w-72 p-2">
              <Box
                className="flex items-center rounded-md p-3 mb-2"
                // 3. Dynamically style the search input container based on dark mode
                sx={{
                  border: isdark ? "2px solid #444" : "2px solid #eee",
                  borderRadius: "15px",
                  backgroundColor:
                    theme.palette.custom.rightUtilityDrawer.headerBg,
                }}
              >
                <Search
                  size={18}
                  className={isdark ? "text-gray-400" : "text-gray-500"}
                />{" "}
                <input
                  type="text"
                  ref={inputRef}
                  value={searchQuery}
                  autoFocus
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search privilege..."
                  className={`ml-2 w-full outline-none text-sm placeholder-gray-400 ${
                    isdark ? "bg-transparent text-white" : ""
                  }`}
                />
              </Box>
              <Box className=" min-h-[230px] max-h-64">
                {suggestions.length > 0 ? (
                  suggestions.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleSelectFromSearch(item)}
                      className="flex w-full justify-start items-center gap-2 px-2 py-1 text-sm cursor-pointer hover:bg-[#D5E0FF] hover:text-black rounded"
                    >
                      <span className="truncate">{item.privilegeName}</span>
                    </button>
                  ))
                ) : (
                  // 3. Show a "No results" message so the box doesn't look empty
                  <Box className="text-sm text-gray-400 p-2 text-center">
                    No results found
                  </Box>
                )}
              </Box>
            </Box>
          </Popover>

          {/* Action Privileges Mapping List Area */}
          {parentPrivileges.map((item) => (
            <Tooltip
              title={!isHovered ? item.privilegeName : ""}
              placement="left"
              key={item.id}
              arrow
            >
              <button
                onClick={() => toggleParent(item.id)}
                className={`flex items-center justify-start gap-3 p-2.5 w-full rounded-xl transition-all border overflow-hidden ${
                  isdark ? "border-[#4f4d4d]" : "border-gray-300"
                } ${
                  activeParent === item.id
                    ? "bg-gray-600 shadow-lg border-gray-600"
                    : isdark
                    ? "hover:bg-gray-700 text-gray-200"
                    : "hover:bg-gray-200 text-gray-700"
                }`}
                style={{
                  color: (theme) =>
                    theme.palette.custom.rightUtilityDrawer.headerText,
                }}
              >
                <Box className="flex-shrink-0 flex items-center justify-center">
                  <img
                    src={getIconForKey(item.key)}
                    alt=""
                    className={`w-6 h-6 object-contain ${
                      isdark ? "brightness-0 invert" : ""
                    }`}
                  />
                </Box>
                <span
                  className={`text-xs font-semibold tracking-wide transition-all duration-200 whitespace-nowrap truncate ${
                    isHovered
                      ? "opacity-100 translate-x-0"
                      : "opacity-0 -translate-x-4 hidden"
                  }`}
                  // 5. KEY FIX: Control text color based on active state AND dark mode
                  style={{
                    color:
                      activeParent === item.id
                        ? "#ffffff"
                        : isdark
                        ? "#f8fafc"
                        : "#374151", // Uses theme colors
                  }}
                >
                  {item.privilegeName}
                </span>
              </button>
            </Tooltip>
          ))}
        </Box>

        {/* PRIMARY DRAWER */}
        <Drawer
          anchor="right"
          open={!!activeParent}
          onClose={() => {
            setActiveParent(null);
            setIsFullScreen(false);
            setDrawerWidth("45%");
          }}
          variant="temporary"
          PaperProps={{
            sx: {
              width: drawerWidth,
              borderTopLeftRadius: "40px",
              background: (theme) => theme.palette.background.paper,
              display: "flex", // Ensure drawer behaves as a flex container
              flexDirection: "column",
            },
          }}
        >
          {/* 
      Main container must be h-full and flex-col. 
      We do NOT put overflow-y-auto on this Box, 
      only on the content boxes below.
  */}
          <Box className="flex flex-col h-full p-4 overflow-hidden">
            {/* 1. STICKY HEADER: Title and Action Buttons */}
            <Box className="sticky top-0 z-20 bg-inherit pt-2 ">
              <Box className="flex justify-between items-center mb-2">
                <Typography
                  variant="h6"
                  className="font-bold"
                  sx={{ color: (theme) => theme.palette.text.TitleTextcolor }}
                >
                  {
                    parentPrivileges.find((p) => p.id === activeParent)
                      ?.privilegeName
                  }
                </Typography>
                <Box className="flex gap-2   ">
                  <Tooltip
                    title={
                      isFullScreen ? "Exit Full Screen" : "Enter Full Screen"
                    }
                    // disablePortal={false}
                    PopperProps={{
                      style: { zIndex: 99999, position: "fixed" },
                    }}
                    placement="top"
                  >
                    <SquareIconButton
                      onClick={() => {
                        setIsFullScreen(!isFullScreen);
                        setDrawerWidth(!isFullScreen ? "100%" : "45%");
                      }}
                    >
                      {isFullScreen ? (
                        <FullscreenExit size={20} />
                      ) : (
                        <FullscreenIcon size={20} />
                      )}
                    </SquareIconButton>
                  </Tooltip>
                  <Tooltip title="Close">
                    <span className="inline-block">
                      <SquareIconButton
                        onClick={() => {
                          setActiveParent(null);
                          setIsFullScreen(false);
                          setDrawerWidth("45%");
                        }}
                      >
                        <CloseIcon />
                      </SquareIconButton>
                    </span>
                  </Tooltip>
                </Box>
              </Box>
              <hr className="border-t border-gray-200 -ml-4 mb-4 -mr-3" />
            </Box>

            {isReportsCategory ? (
              <Box
                sx={{ display: "flex", flex: 1, overflow: "hidden", gap: 2 }}
              >
                {/* Sidebar remains fixed */}
                <Box
                  sx={{
                    width: "255px",
                    borderRight: "1px solid #eee",
                    overflowY: "auto",
                    pr: 1,
                  }}
                >
                  <ReportTreeMenu
                    treeData={reportsTreeStructure}
                    selectedKey={activeChild}
                    onSelect={(selectedKey) => {
                      setActiveChild(selectedKey);
                      setSubDrawerData(null);
                    }}
                  />
                </Box>

                {/* Scrollable Content Area */}
                <Box className="flex-1 overflow-y-auto">
                  {(() => {
                    if (!activeChild)
                      return (
                        <Typography
                          variant="body2"
                          className="p-4 text-gray-400 text-center"
                        >
                          Select a sub-report option from the nested list.
                        </Typography>
                      );
                    const translatedKey = activeChild.replace(".", "_");
                    const Component = FileList[translatedKey];
                    // const Component = FileList[activeChild];
                    const flatReportsList = reportsTreeStructure.flatMap(
                      (group) => group.children || []
                    );
                    const selectedReportLeaf = flatReportsList.find(
                      (child) => child.key === activeChild
                    );
                    if (Component) {
                      return (
                        <Component
                          privilegeKey={activeChild}
                          refreshTrigger={refreshMap[activeChildKey]}
                          onRefresh={() => triggerRefresh(activeChildKey)}
                          activeTab={selectedReportLeaf?.activeTabConfig}
                        />
                      );
                    }
                    return (
                      <Typography
                        variant="body2"
                        className="p-4 text-red-400 text-center"
                      >
                        Module layout mapping component error for key:{" "}
                        {activeChild}
                      </Typography>
                    );
                  })()}
                </Box>
              </Box>
            ) : (
              /* 2. NON-REPORT VIEW: Sticky Tabs + Scrollable Body */
              <>
                {/* STICKY TABS BAR */}

                <Box className="sticky top-[80px] z-10 bg-inherit mt-3">
                  <Box className="flex items-center mb-4 gap-2">
                    {/* LEFT ARROW */}
                    <IconButton
                      onClick={() => scroll("left")}
                      disabled={!canScrollLeft}
                      sx={{
                        transition: "all 0.3s ease",
                        // 1. Default Enabled State (Light Blue Tint)
                        backgroundColor: activeBg,
                        color: activeIcon,

                        // 2. Hover State (Solid Blue with White Icon)
                        "&:hover": {
                          backgroundColor: activeBg,
                          color: activeIcon,
                        },

                        // 3. Disabled State (Gray Background & Gray Icon)
                        "&.Mui-disabled": {
                          backgroundColor: disabledBg,
                          color: disabledIcon,
                          // Ensure hover doesn't trigger when disabled
                          "&:hover": {
                            backgroundColor: disabledBg,
                          },
                        },
                      }}
                    >
                      <ChevronLeft />
                    </IconButton>

                    {/* TABS CONTAINER */}
                    <Box
                      ref={scrollRef}
                      onScroll={handleScroll}
                      sx={{
                        background:
                          theme.palette.custom.rightUtilityDrawer.tabsbg,
                        overflowX: "auto",
                        msOverflowStyle: "none",
                        scrollbarWidth: "none",
                        "&::-webkit-scrollbar": { display: "none" },
                      }}
                      className="flex no-scrollbar scroll-smooth gap-2 p-3 rounded-full flex-1"
                    >
                      {/* {tabs.map((child) => {
                        const isActive = activeChild === child.id || (!activeChild && tabs[0]?.id === child.id);
                        return (
                          <button
                            key={child.id}
                            onClick={(e) => handleTabClick(child.id, e)}
                            className={`px-4 py-2 rounded-full text-xs font-medium uppercase whitespace-nowrap transition-all duration-300 ${isActive
                              ? "bg-[#14348D] text-white"
                              : `${inactiveTextColor} hover:bg-blue-200/20`
                              }`}
                          >
                            {child.privilegeName}
                          </button>
                        );
                      })} */}
                      {tabs.map((child, index) => {
                        // 👈 Added index here
                        const isActive =
                          activeChild === child.id ||
                          (!activeChild && tabs[0]?.id === child.id);
                        return (
                          <button
                            key={child.id}
                            onClick={(e) => handleTabClick(child.id, e, index)} // 👈 Passed index here
                            className={`px-4 py-2 rounded-full text-xs font-medium uppercase whitespace-nowrap transition-all duration-300 ${
                              isActive
                                ? "bg-[#14348D] text-white"
                                : `${inactiveTextColor} hover:bg-blue-200/20`
                            }`}
                          >
                            {child.privilegeName}
                          </button>
                        );
                      })}
                    </Box>

                    {/* RIGHT ARROW */}
                    <IconButton
                      onClick={() => scroll("right")}
                      disabled={!canScrollRight}
                      sx={{
                        transition: "all 0.3s ease",
                        // 1. Default Enabled State
                        backgroundColor: activeBg,
                        color: activeIcon,

                        // 2. Hover State
                        "&:hover": {
                          backgroundColor: activeBg,
                          color: activeIcon,
                        },

                        // 3. Disabled State
                        "&.Mui-disabled": {
                          backgroundColor: disabledBg,
                          color: disabledIcon,
                          "&:hover": {
                            backgroundColor: disabledBg,
                          },
                        },
                      }}
                    >
                      <ChevronRight />
                    </IconButton>
                  </Box>
                </Box>
                {/* 3. SCROLLABLE CONTENT AREA */}
                <Box className="flex-1 overflow-y-auto">
                  {activeParent &&
                    (() => {
                      const Component = FileList[activeChildKey];
                      if (Component) {
                        return (
                          <Component
                            privilegeKey={activeChildKey}
                            refreshTrigger={refreshMap[activeChildKey] || 0}
                            onRefresh={() => triggerRefresh(activeChildKey)}
                            isChildFullScreen={isFullScreen}
                            handleAdd={(data) => {
                              console.log("ADD DATA FROM TABLE:", data);

                              setSubDrawerData({
                                ...data,
                                mode: "CREATE",
                              });
                            }}
                            // handleAdd={(data) => setSubDrawerData({ ...data, mode: "CREATE" })}
                            handleEdit={(row) =>
                              setSubDrawerData({ ...row, mode: "EDIT" })
                            }
                            handleView={(row) =>
                              setSubDrawerData({ ...row, mode: "VIEW" })
                            }
                            handleHistory={(row) =>
                              setSubDrawerData({ ...row, mode: "HISTORY" })
                            }
                            handleCloseAction={(row) =>
                              setSubDrawerData({ ...row, mode: "CLOSE" })
                            }
                            handleInProgressAction={(row) =>
                              setSubDrawerData({ ...row, mode: "INPROGRESS" })
                            }
                            handlePendingAction={(row) =>
                              setSubDrawerData({ ...row, mode: "PENDING" })
                            }
                            handleResolvedAction={(row) =>
                              setSubDrawerData({ ...row, mode: "RESOLVED" })
                            }
                            handleReopenAction={(data) =>
                              setSubDrawerData({ ...data, mode: "REOPEN" })
                            }
                            handleDownload={(data) =>
                              setSubDrawerData({ ...data, mode: "DOWNLOAD" })
                            }
                            handleChangePasswordClick={(data) =>
                              setSubDrawerData({
                                ...data,
                                mode: "CHANGEPASSWORD",
                              })
                            }
                          />
                        );
                      }
                      return null;
                    })()}
                </Box>
              </>
            )}
          </Box>

          {/* SUB DRAWER CONTAINMENT */}
          <Drawer
            anchor="right"
            open={!!subDrawerData}
            onClose={() => {
              setSubDrawerData(null);
              setIsSubFullScreen(false); // Reset when closed
            }}
            hideBackdrop={false}
            PaperProps={{
              sx: {
                // Use 100% if isSubFullScreen is true, otherwise use the logic you had
                width: isSubFullScreen ? "100%" : isFullScreen ? "35%" : "25%",
                height: "100%",
                borderTopLeftRadius: "40px",
                border: "1px solid #D5E0FF",
                zIndex: 1301,
              },
            }}
          >
            <Box className="flex flex-col h-full  ">
              <Box className="p-3 ml-3 flex justify-between items-center">
                <Typography
                  variant="subtitle1"
                  className="font-bold text-[#14348D]"
                  sx={{
                    color: theme.palette.custom.rightUtilityDrawer.headerText,
                  }}
                >
                  {subDrawerData?.title || subDrawerData?.mode}
                </Typography>
                <Box className="flex gap-2">
                  <Tooltip
                    title={
                      isSubFullScreen ? "Exit Full Screen" : "Enter Full Screen"
                    }
                  >
                    <SquareIconButton
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsSubFullScreen(!isSubFullScreen);
                      }}
                    >
                      {isSubFullScreen ? (
                        <FullscreenExit size={20} />
                      ) : (
                        <FullscreenIcon size={20} />
                      )}
                    </SquareIconButton>
                  </Tooltip>

                  <SquareIconButton
                    size="small"
                    onClick={() => {
                      setSubDrawerData(null); // Closes the drawer
                      setIsSubFullScreen(false); // Resets the width
                    }}
                  >
                    <CloseIcon sx={{ color: theme.palette.text.primary }} />
                  </SquareIconButton>
                </Box>
              </Box>
              <Box style={{ border: "1px solid #eee" }}></Box>
              <ScrollContainer className="h-full">
                <Box className=" pr-2 p-4">
                  {(() => {
                    const mode = subDrawerData?.mode;
                    const currentKey = activeChildKey || activeChild;
                    const TargetComponent = FORM_MAPPING[currentKey]?.[mode];

                    if (TargetComponent) {
                      return (
                        // <TargetComponent
                        //   data={subDrawerData}
                        //   mode={mode}
                        //   onClose={() => setSubDrawerData(null)}
                        //   onSuccess={() => {

                        //     setSubDrawerData(null);
                        //     triggerRefresh(currentKey);
                        //   }}
                        //   onRefresh={() => triggerRefresh(currentKey)}
                        // />
                        <TargetComponent
                          data={subDrawerData}
                          row={subDrawerData?.row || subDrawerData}
                          mode={mode}
                          siteId={subDrawerData?.siteId}
                          onClose={() => setSubDrawerData(null)}
                          isGrandchildFullScreen={isSubFullScreen}
                          onSuccess={() => {
                            setSubDrawerData(null);
                            triggerRefresh(currentKey);
                          }}
                          onRefresh={() => triggerRefresh(currentKey)}
                        />
                      );
                    }

                    return (
                      <Box className="space-y-4">
                        {Object.entries(subDrawerData || {}).map(
                          ([k, v]) =>
                            !["mode", "sno", "id", "title"].includes(k) && (
                              <Box
                                key={k}
                                className="border-b border-gray-100 pb-2"
                              >
                                <Typography
                                  variant="caption"
                                  className="text-gray-400 font-bold uppercase block"
                                >
                                  {k.replace(/([A-Z])/g, " $1")}
                                </Typography>
                                <Typography
                                  variant="body2"
                                  className="text-gray-800 font-medium"
                                >
                                  {typeof v === "object"
                                    ? JSON.stringify(v)
                                    : String(v)}
                                </Typography>
                              </Box>
                            )
                        )}
                      </Box>
                    );
                  })()}
                </Box>
              </ScrollContainer>
            </Box>
          </Drawer>
        </Drawer>
      </ScrollContainer>
    </Box>
  );
};

export default RightUtilityDrawer;
