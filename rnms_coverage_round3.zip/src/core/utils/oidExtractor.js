export const extractOidsFromLayout = (layout) => {
    const staticOids = new Set();
    const tableOids = new Set();
  
    layout?.status?.forEach((tab) => {
      tab?.widget?.forEach((widget) => {
        if (widget?.data?.length) {
          widget.data.forEach((item) => {
            if (item?.oid) {
              staticOids.add(item.oid);
            }
          });
        }
  
        // image widgets (table mapping case)
        if (widget?.mapForDisplay) {
          Object.values(widget.mapForDisplay).forEach((oid) => {
            tableOids.add(oid);
          });
        }
      });
    });
  
    return {
      staticOids: Array.from(staticOids),
      tableOids: Array.from(tableOids),
    };
  };


  export const applyOidOperation = (value, mapping) => {
    if (value == null) return "-";
  
    if (!mapping) return value;
  
    switch (mapping.operation) {
      case "removemilisecsysuptime":
        return formatSysUptime(value);
  
      case "divide":
        return Number(value) / Number(mapping.operator_map || 1);
  
      case "multiply":
        return Number(value) * Number(mapping.operator_map || 1);
  
      default:
        return value;
    }
  };
  
  const formatSysUptime = (ticks) => {
    const sec = Number(ticks);
  
    const days = Math.floor(sec / 86400);
    const hours = Math.floor((sec % 86400) / 3600);
    const minutes = Math.floor((sec % 3600) / 60);
    const seconds = sec % 60;
  
    return `${days} D : ${hours} H : ${minutes} M : ${seconds} S`;
  };