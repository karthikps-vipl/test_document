const layoutCache = new Map();

export const getCachedLayout = (terminalType) =>
  layoutCache.get(terminalType);

export const setCachedLayout = (terminalType, layout) =>
  layoutCache.set(terminalType, layout);

export const clearLayoutCache = () => layoutCache.clear();