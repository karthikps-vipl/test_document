
import React, { lazy } from "react";

const LazyDeviceDialog = lazy(() => import("../../components/Dialogs/DeviceDialog.jsx"));
const withDefaultProps = (Component, defaultProps) => {
  return function WrappedComponent(props) {
    return React.createElement(Component, { ...defaultProps, ...props });
  };
};

export const MODAL_REGISTRY = {
  inventory: lazy(() => import("../../components/Dialogs/InventoryDialog")),
  status: withDefaultProps(LazyDeviceDialog, { mode: "status" }),
  configuration: withDefaultProps(LazyDeviceDialog, { mode: "configuration" }),
  viewActiveAlarm: lazy(() =>
    import("../../components/Dialogs/Fault/ActiveAlarmDialog")
  ),
  pollingInterval: lazy(() =>
    import("../../components/Dialogs/Fault/PollingIntervalDialog")
  ),
  alarmSuppression: lazy(() =>
    import("../../components/Dialogs/AlarmSuppression/AlarmSuppressionDialog")
  ),
  addDevice: lazy(() => import("../../components/Dialogs/AddDeviceDialog.jsx")),
  deleteDevice: lazy(() =>
    import("../../components/Dialogs/DeleteDeviceDialog.jsx")
  ),
  rnms: lazy(() => import("../../components/Dialogs/RnmsSiteDetails.jsx")),
  inventoryDetails: lazy(() =>
    import("../../components/Dialogs/InventoryDetails.jsx")
  ),

  segmentDetails: lazy(() =>
    import("../../components/Dialogs/Segment/SegmentDetailsDialog")
  ),

  segmentAlarms: lazy(() =>
    import("../../components/Dialogs/Segment/SegmentAlarmDialog")
  ),

  cnmsconfiguration: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/ViewUpdateConfiguration")
  ),

  cnmssitedetails: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/SiteDetails")
  ),

  cnmsViewSiteDetails: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsSegmentSiteDetails.jsx")
  ),

  cnmsactivealarms: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsActiveAlarm.jsx")
  ),

  cnmsTopology: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsTopology.jsx")
  ),

  cnmsInventory: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsVehicleInventoryView.jsx")
  ),

  cnmsMoveToMaintenance: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsMoveToMaintenance.jsx")
  ),
  cnmsAddSite: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsAddSite.jsx")
  ),
  cnmsDeleteSite: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/CnmsDeleteSite.jsx")
  ),
  cnmsViewActiveAlarm: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/VehicleActiveAlarm.jsx")
  ),
  confirmDeleteSite: lazy(() =>
    import("../../components/Dialogs/CNMS_DIALOG/ConfirmDeleteSite.jsx")
  ),
  addAlarmSuppression: lazy(() =>
    import("../../components/Dialogs/AlarmSuppression/AddAlarmSuppressionDialog")
  ),
  editAlarmSuppression: lazy(() =>
    import("../../components/Dialogs/AlarmSuppression/AddAlarmSuppressionDialog")
  ),
};
