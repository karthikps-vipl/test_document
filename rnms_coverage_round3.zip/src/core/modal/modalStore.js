// import { create } from "zustand";

// export const useModalStore = create((set) => ({
//   isOpen: false,
//   modalType: null,
//   modalProps: {},

//     // Stack for nested modals
//     modalStack: [],

//   openModal: (type, props = {}) =>
//     set({
//       isOpen: true,
//       modalType: type,
//       modalProps: props,
//     }),

//   closeModal: () =>
//     set({
//       isOpen: false,
//       modalType: null,
//       modalProps: {},
//     }),
//     resetModal: () => set({ isOpen: false, modalType: null, modalProps: {} }), 
// }));




import { create } from "zustand";

export const useModalStore = create((set) => ({
  isOpen: false,
  modalType: null,
  modalProps: {},

  // Stack for nested modals
  modalStack: [],

  openModal: (type, props = {}) =>
    set((state) => {
      const newModal = {
        modalType: type,
        modalProps: props,
      };

      const updatedStack = [...state.modalStack, newModal];

      return {
        modalStack: updatedStack,
        isOpen: true,
        modalType: newModal.modalType,
        modalProps: newModal.modalProps,
      };
    }),

  closeModal: () =>
    set((state) => {
      const updatedStack = state.modalStack.slice(0, -1);
      const previousModal = updatedStack[updatedStack.length - 1];

      return {
        modalStack: updatedStack,
        isOpen: updatedStack.length > 0,
        modalType: previousModal?.modalType ?? null,
        modalProps: previousModal?.modalProps ?? {},
      };
    }),

  resetModal: () =>
    set({
      isOpen: false,
      modalType: null,
      modalProps: {},
      modalStack: [],
    }),
}));