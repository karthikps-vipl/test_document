import { setViewOnMap } from "@/store/features/Cnms/mapViewSlice";
import { useDispatch } from "react-redux";
import { useModalStore } from "./modalStore";
import { useEffect } from "react";


const ModalSideEffects = () => {
    const dispatch = useDispatch();
  
    const {
      modalStack,
      lastOpenedModalId,
    } = useModalStore();
  
    useEffect(() => {
      if (!lastOpenedModalId) return;
  
      const modal = modalStack.find(
        (item) => item.id === lastOpenedModalId
      );
  
      if (modal?.type !== "cnmsViewOnMap") {
        return;
      }
  
      const {
        latitude,
        longitude,
      } = modal.props?.node || {};
  
      if (latitude == null || longitude == null) {
        return;
      }
  
      dispatch(
        setViewOnMap([latitude, longitude])
      );
    }, [
      lastOpenedModalId,
      modalStack,
      dispatch,
    ]);
  
    return null;
  };

  export default ModalSideEffects;