// import React, { Suspense } from "react";
// import {
//   Dialog,
//   CircularProgress,
//   Box,
//   IconButton,
//   Tooltip,
//   DialogTitle,
//   Divider,
// } from "@mui/material";
// import { useModalStore } from "./modalStore";
// import { MODAL_REGISTRY } from "./modalRegistry";
// import { MODAL_CONFIG } from "./modalConfig";
// import CloseIcon from "@mui/icons-material/Close";
// import { Fullscreen, FullscreenExit } from "@mui/icons-material";
// import { useDispatch, useSelector } from "react-redux";
// import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
// import { SquareIconButton } from "@/components/Reusable/Modal/MModal";
// import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
// import { setViewOnMap } from "@/store/features/Cnms/mapViewSlice";

// const GlobalModalRenderer = () => {
//   const { isOpen, modalType, modalProps, closeModal } = useModalStore();
//   const dispatch = useDispatch();

//   console.log("modalType", modalType);
//   console.log("modalProps", modalProps);

//   if (modalType == "cnmsViewOnMap") {
//     dispatch(
//       setViewOnMap([modalProps?.node?.latitude, modalProps?.node?.longitude])
//     );
//   }

//   // Get the maximization state from Redux
//   const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

//   console.log("isMaximized", isMaximized);

//   if (!modalType) return null;
//   const Component = MODAL_REGISTRY[modalType];
//   if (!Component) return null;

//   const config = MODAL_CONFIG[modalType] || { maxWidth: "md" };

//   const handleToggleMaximize = () => {
//     dispatch(toggleTableMaximize());
//   };

//   const handleClose = (event, reason) => {
//     // If the user clicks the backdrop or presses Escape, do nothing
//     if (reason === "backdropClick" || reason === "escapeKeyDown") {
//       return;
//     }
//     // Otherwise, proceed with closing the modal
//     closeModal();
//   };

//   const isTargetModal =
//     modalType === "alarmSuppression" ||
//     modalType === "inventoryDetails" ||
//     modalType === "inventory" ||
//     modalType === "status" ||
//     modalType === "segmentDetails" ||
//     modalType === "segmentAlarms" ||
//     modalType === "configuration" ||
//     modalType === "viewActiveAlarm" ||
//     modalType === "rnms" ||
//     modalType === "cnmsconfiguration" ||
//     modalType === "cnmssitedetails" ||
//     modalType === "cnmsViewSiteDetails" ||
//     modalType === "cnmsactivealarms" ||
//     modalType === "cnmsTopology" ||
//     modalType === "cnmsInventory" ||
//     modalType === "cnmsMoveToMaintenance" ||
//     modalType === "cnmsAddSite" ||
//     modalType === "cnmsViewActiveAlarm" ||
//     modalType === "cnmsDeleteSite";

//   const shouldBeFullScreen = isMaximized && isTargetModal;

//   return (
//     <Dialog
//       open={isOpen}
//       onClose={handleClose}
//       // onClose={closeModal}
//       // fullScreen={isMaximized && modalType === "alarmSuppression"}
//       fullScreen={shouldBeFullScreen}
//       fullWidth
//       maxWidth={
//         // isMaximized && modalType === "alarmSuppression"
//         shouldBeFullScreen ? false : config.maxWidth
//       }
//       sx={{
//         "& .MuiDialog-paper": {
//           borderRadius: isMaximized ? "0px" : "30px",
//           overflow: "hidden",
//           ...(isMaximized && modalType === "alarmSuppression"
//             ? {
//                 width: "100vw",
//                 height: "100vh",
//                 margin: 0,
//                 borderRadius: 0,
//               }
//             : config.customSx),
//         },
//       }}
//     >
//       {modalType === "alarmSuppression" && (
//         <>
//           <DialogTitle
//             sx={{
//               color: "text.TitleTextcolor",
//               display: "flex",
//               justifyContent: "space-between",
//               alignItems: "center",
//               py: 2,
//             }}
//           >
//             <span style={{ fontWeight: "bold" }}>
//               {modalProps?.node?.resourceName} - Alarm Suppression
//             </span>

//             <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//               <CustomeFullscreen
//                 onClose={closeModal}
//                 isFullScreen={isMaximized}
//                 onToggleFullScreen={handleToggleMaximize}
//               />
//             </Box>
//           </DialogTitle>
//           <Divider />
//         </>
//       )}

//       <Suspense
//         fallback={
//           <Box p={5} textAlign="center">
//             <CircularProgress />
//           </Box>
//         }
//       >
//         <Component
//           {...modalProps}
//           onClose={closeModal}
//           sx={{ border: "2px solid red" }}
//         />
//       </Suspense>
//     </Dialog>
//   );
// };

// export default GlobalModalRenderer;

import React, { Suspense, useEffect } from "react";
import {
  Dialog,
  CircularProgress,
  Box,
  DialogTitle,
  Divider,
} from "@mui/material";

import { useModalStore } from "./modalStore";
import { MODAL_REGISTRY } from "./modalRegistry";
import { MODAL_CONFIG } from "./modalConfig";

import { useDispatch, useSelector } from "react-redux";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import { setViewOnMap } from "@/store/features/Cnms/mapViewSlice";

// const GlobalModalRenderer = () => {
//   const { modalStack, closeModal } = useModalStore();
//   const dispatch = useDispatch();

//   const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

//   const activeModal = modalStack[modalStack.length - 1];

//   useEffect(() => {
//     if (activeModal?.modalType === "cnmsViewOnMap") {
//       const { latitude, longitude } = activeModal.modalProps?.node || {};

//       if (latitude != null && longitude != null) {
//         dispatch(setViewOnMap([latitude, longitude]));
//       }
//     }
//   }, [activeModal, dispatch]);

//   const handleToggleMaximize = () => {
//     dispatch(toggleTableMaximize());
//   };

//   const handleClose = (event, reason) => {
//     // Keep the existing behavior:
//     // Ignore backdrop clicks and Escape.
//     if (reason === "backdropClick" || reason === "escapeKeyDown") {
//       return;
//     }

//     closeModal();
//   };

//   if (!modalStack.length) return null;

//   return (
//     <>
//       {modalStack.map((modal, index) => {
//         const { modalType, modalProps } = modal;
//         const isTopModal = index === modalStack.length - 1;

//         const Component = MODAL_REGISTRY[modalType];

//         if (!Component) return null;

//         const config = MODAL_CONFIG[modalType] || {
//           maxWidth: "md",
//         };

//         console.log("modalTypeyy", modalType);

//         const isTargetModal =
//           modalType === "alarmSuppression" ||
//           modalType === "addAlarmSuppression" ||
//           modalType === "editAlarmSuppression" ||
//           modalType === "inventoryDetails" ||
//           modalType === "inventory" ||
//           modalType === "status" ||
//           modalType === "segmentDetails" ||
//           modalType === "segmentAlarms" ||
//           modalType === "configuration" ||
//           modalType === "viewActiveAlarm" ||
//           modalType === "rnms" ||
//           modalType === "cnmsconfiguration" ||
//           modalType === "cnmssitedetails" ||
//           modalType === "cnmsViewSiteDetails" ||
//           modalType === "cnmsactivealarms" ||
//           modalType === "cnmsTopology" ||
//           modalType === "cnmsInventory" ||
//           modalType === "cnmsMoveToMaintenance" ||
//           modalType === "cnmsAddSite" ||
//           modalType === "cnmsViewActiveAlarm" ||
//           modalType === "cnmsDeleteSite";

//         // const shouldBeFullScreen =
//         //   isMaximized && isTargetModal;

//         const shouldBeFullScreen = isTopModal && isMaximized && isTargetModal;

//         // Preserve the existing map-view behavior,
//         // but only apply it to the top modal.
//         // if (
//         //   isTopModal &&
//         //   modalType === "cnmsViewOnMap"
//         // ) {
//         //   const latitude = modalProps?.node?.latitude;
//         //   const longitude = modalProps?.node?.longitude;

//         //   if (
//         //     latitude != null &&
//         //     longitude != null
//         //   ) {
//         //     // See the useEffect improvement below
//         //     // if you want to avoid dispatching during render.
//         //   }
//         // }

//         return (
//           <Dialog
//             key={`${modalType}-${index}`}
//             open={true}
//             onClose={handleClose}
//             fullScreen={shouldBeFullScreen}
//             fullWidth
//             maxWidth={shouldBeFullScreen ? false : config.maxWidth}
//             sx={{
//               // zIndex: 1300 + index * 10,
//               zIndex: isTopModal ? 1500 : 1300 + index * 10,

//               // Keep the previous dialogs mounted and
//               // visible behind the newest dialog.
//               "& .MuiDialog-paper": {
//                 borderRadius: isMaximized ? "0px" : "30px",
//                 overflow: "hidden",

//                 ...(isMaximized && modalType === "alarmSuppression"
//                   ? {
//                       width: "100vw",
//                       height: "100vh",
//                       margin: 0,
//                       borderRadius: 0,
//                     }
//                   : config.customSx),
//               },
//             }}
//           >
//             {[
//               "alarmSuppression",
//               "addAlarmSuppression",
//               "editAlarmSuppression",
//             ].includes(modalType) && (
//               <>
//                 <DialogTitle
//                   sx={{
//                     color: "text.TitleTextcolor",
//                     display: "flex",
//                     justifyContent: "space-between",
//                     alignItems: "center",
//                     py: 2,
//                   }}
//                 >
//                   <span style={{ fontWeight: "bold" }}>
//                     {modalType === "alarmSuppression"
//                       ? `${modalProps?.node?.resourceName} - Alarm Suppression`
//                       : modalType === "addAlarmSuppression"
//                       ? "Add Alarm Suppression"
//                       : "Edit Alarm Suppression"}
//                   </span>

//                   <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                     <CustomeFullscreen
//                       onClose={closeModal}
//                       isFullScreen={isMaximized}
//                       onToggleFullScreen={handleToggleMaximize}
//                       isFullScreenvisible={
//                         ![
//                           "addAlarmSuppression",
//                           "editAlarmSuppression",
//                         ].includes(modalType)
//                       }
//                     />
//                   </Box>
//                 </DialogTitle>

//                 <Divider />
//               </>
//             )}
//             <Suspense
//               fallback={
//                 <Box p={5} textAlign="center">
//                   <CircularProgress />
//                 </Box>
//               }
//             >
//               <Component
//                 {...modalProps}
//                 onClose={closeModal}
//                 sx={{ border: "2px solid red" }}
//               />
//             </Suspense>
//           </Dialog>
//         );
//       })}
//     </>
//   );
// };

// export default GlobalModalRenderer;
const BASE_MODAL_Z_INDEX = 1300;
const MODAL_Z_INDEX_STEP = 10;

const GlobalModalRenderer = () => {
  const { modalStack, closeModal } = useModalStore();
  const dispatch = useDispatch();

  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const activeModal = modalStack[modalStack.length - 1];

  useEffect(() => {
    if (activeModal?.modalType === "cnmsViewOnMap") {
      const { latitude, longitude } = activeModal.modalProps?.node || {};

      if (latitude != null && longitude != null) {
        dispatch(setViewOnMap([latitude, longitude]));
      }
    }
  }, [activeModal, dispatch]);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  const handleClose = (event, reason) => {
    if (reason === "backdropClick" || reason === "escapeKeyDown") {
      return;
    }

    closeModal();
  };

  if (!modalStack.length) return null;

  return (
    <>
      {modalStack.map((modal, index) => {
        const { modalType, modalProps } = modal;

        const isTopModal = index === modalStack.length - 1;

        const Component = MODAL_REGISTRY[modalType];

        if (!Component) return null;

        const config = MODAL_CONFIG[modalType] || {
          maxWidth: "md",
        };

        const isTargetModal = [
          "alarmSuppression",
          "addAlarmSuppression",
          "editAlarmSuppression",
          "inventoryDetails",
          "inventory",
          "status",
          "segmentDetails",
          "segmentAlarms",
          "configuration",
          "viewActiveAlarm",
          "rnms",
          "cnmsconfiguration",
          "cnmssitedetails",
          "cnmsViewSiteDetails",
          "cnmsactivealarms",
          "cnmsTopology",
          "cnmsInventory",
          "cnmsMoveToMaintenance",
          "cnmsAddSite",
          "cnmsViewActiveAlarm",
          "cnmsDeleteSite",
        ].includes(modalType);

        const shouldBeFullScreen = isTopModal && isMaximized && isTargetModal;

        const modalZIndex = BASE_MODAL_Z_INDEX + index * MODAL_Z_INDEX_STEP;

        return (
          <Dialog
            key={`${modalType}-${index}`}
            open={true}
            onClose={handleClose}
            fullScreen={shouldBeFullScreen}
            fullWidth
            maxWidth={shouldBeFullScreen ? false : config.maxWidth}
            sx={{
              zIndex: modalZIndex,

              "& .MuiDialog-paper": {
                borderRadius: isMaximized ? "0px" : "30px",

                overflow: "hidden",

                ...(isMaximized && modalType === "alarmSuppression"
                  ? {
                      width: "100vw",
                      height: "100vh",
                      margin: 0,
                      borderRadius: 0,
                    }
                  : config.customSx),
              },
            }}
          >
            {[
              "alarmSuppression",
              "addAlarmSuppression",
              "editAlarmSuppression",
            ].includes(modalType) && (
              <>
                <DialogTitle
                  sx={{
                    color: "text.TitleTextcolor",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    py: 2,
                  }}
                >
                  <span style={{ fontWeight: "bold" }}>
                    {modalType === "alarmSuppression"
                      ? `${modalProps?.node?.resourceName} - Alarm Suppression`
                      : modalType === "addAlarmSuppression"
                      ? "Add Alarm Suppression"
                      : "Edit Alarm Suppression"}
                  </span>

                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <CustomeFullscreen
                      onClose={closeModal}
                      isFullScreen={isMaximized}
                      onToggleFullScreen={handleToggleMaximize}
                      isFullScreenvisible={
                        ![
                          "addAlarmSuppression",
                          "editAlarmSuppression",
                        ].includes(modalType)
                      }
                    />
                  </Box>
                </DialogTitle>

                <Divider />
              </>
            )}

            <Suspense
              fallback={
                <Box p={5} textAlign="center">
                  <CircularProgress />
                </Box>
              }
            >
              <Component {...modalProps} onClose={closeModal} />
            </Suspense>
          </Dialog>
        );
      })}
    </>
  );
};

export default GlobalModalRenderer;
