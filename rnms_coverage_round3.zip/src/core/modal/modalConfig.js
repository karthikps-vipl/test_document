export const MODAL_CONFIG = {
  inventory: { maxWidth: "md" },
  status: { maxWidth: "xl" },
  pollingInterval: {
    maxWidth: "sm",
    customSx: {
      width: {
        xs: "90%",
        sm: "60%",
        md: "40%",
        lg: "26%",
      },

      height: {
        xs: "auto",
        md: "19vh",
      },
      overflow: "auto",
    },
  },
  addDevice: { maxWidth: "sm" },
  viewActiveAlarm: { maxWidth: "lg" },
  deleteDevice: { maxWidth: "xs" },
  rnms: { maxWidth: "sm" },
  inventoryDetails: { maxWidth: "xl" },
  alarmSuppression: {
    maxWidth: "md",
    customSx: { height: { xs: "auto", md: "auto" } },
  },
  configuration: { maxWidth: "xl" },
  segmentDetails: { maxWidth: "xl"},
  segmentAlarms: { maxWidth: "xl"},
  cnmssitedetails: { maxWidth: "xl"},
  cnmsViewSiteDetails: { maxWidth: "xl"},
  cnmsactivealarms: { maxWidth: "xl"},
  cnmsTopology: { maxWidth: "xl"},
  cnmsInventory: { maxWidth: "xl"},
  cnmsMoveToMaintenance: { maxWidth: "sm"},
  cnmsAddSite: { maxWidth: "sm" },
  cnmsDeleteSite: { maxWidth: "sm" },
  cnmsViewActiveAlarm: { maxWidth: "xl" },
  confirmDeleteSite: { maxWidth: "sm" },
  addAlarmSuppression: {
    maxWidth: "md",
    customSx: {
      width: "650px",
      maxWidth: "90vw",
    },
  },
  
  editAlarmSuppression: {
    maxWidth: "md",
    customSx: {
      width: "650px",
      maxWidth: "90vw",
    },
  },
};
