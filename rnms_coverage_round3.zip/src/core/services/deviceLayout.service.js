
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { GET_LAYOUT_FOR_DEVICE_CNMS } from "@/RestAPI/url/cnmsEndPoint";
import { GET_DEVICE_LAYOUT } from "@/RestAPI/url/endpoint";

export const getDeviceLayout = async (terminalType) => {

  const response = await ConfigurationAxios(
    `${GET_DEVICE_LAYOUT}/${terminalType}`
  );

  return response.data;
};

export const getDeviceLayoutfofCnms = async (terminalId,siteId,resourceId) => {

  const response = await ConfigurationAxios(
    `${GET_LAYOUT_FOR_DEVICE_CNMS}/${terminalId}/${siteId}/${resourceId}`
  );

  return response.data;
};
