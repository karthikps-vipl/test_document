import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { GET_STATUS_BY_DEVICE_AND_TAB_CNMS } from "@/RestAPI/url/cnmsEndPoint";
import { FETCH_OID_MAPPING, GET_STATUS_BY_DEVICE_AND_TAB, SAVE_SNMP_DATA_FOR_DEVICE } from "@/RestAPI/url/endpoint";
 
// POST: OID mapping API
export const fetchOidMapping = async (payload) => {
  const response = await ConfigurationAxios(
    FETCH_OID_MAPPING,
    "post",
    payload
  );

  return response?.data || [];
};

export const getDeviceStatusByTab = async (deviceId, screen, tab) => {
  const response = await ConfigurationAxios(
    `${GET_STATUS_BY_DEVICE_AND_TAB}/${deviceId}/${screen}/${tab}`,
    "get"
  );  
  return response?.data;
};

export const getDeviceStatusByTabForCnms = async (terminalId,siteId,resourceId, screen, tab) => {
  const response = await ConfigurationAxios(
    `${GET_STATUS_BY_DEVICE_AND_TAB_CNMS}/${terminalId}/${siteId}/${resourceId}/${screen}/${tab}`,
    "get"
  );  
  return response?.data;
};


export const saveSnmpDataForDevice = async (deviceId, payload) => {
  const response = await ConfigurationAxios(
    `${SAVE_SNMP_DATA_FOR_DEVICE}/${deviceId}/0`,
    "post",
    payload
  );

  return response?.data;
};