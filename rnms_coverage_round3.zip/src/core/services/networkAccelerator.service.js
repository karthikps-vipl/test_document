
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_NETWORK_ACCELERATOR_RTT_MODE } from "@/RestAPI/url/endpoint";

export const getNetworkAcceleratorRttMode = async (resourceId) => {
  try {
    // 1. Call the API
    const response = await ConfigurationAxios(
      `${FETCH_NETWORK_ACCELERATOR_RTT_MODE}/${resourceId}`,
      "get"
    );

    // 2. Log the response object to verify structure
    console.log("Response Object:", response?.data?.data);

    // 3. Return the actual data from the response
    return response?.data?.data; 
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error; // Re-throw so the caller can handle errors
  }
};
