import { useModalStore } from "../modal/modalStore";

// export const dispatchContextAction = ({ action, node, source }) => {
//   const { openModal } = useModalStore.getState();
//   console.log(node,"sdfjsssskhsdfkjhsjkdfhks");
  
//   openModal(action, {
//     node,
//     source,
//     terminalType: node.terminalTypeName,
//   });
// };

export const dispatchContextAction = ({
  action,
  node,
  source,
}) => {
  const { openModal } = useModalStore.getState();

  const terminalType =
    node?.terminalTypeName ||
    node?.data?.terminalTypeName ||
    node?.data?.imTerminalType?.terminalTypeName;

  openModal(action, {
    node,
    source,
    terminalType,
  });
};
