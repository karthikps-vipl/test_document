// import { useEffect, useState } from "react";
// import { getDeviceStatusByTab } from "../services/deviceStatus.service";
// // Replace with your actual service imports

// const useDeviceConfig = (deviceId, screen, tab, enabled = true) => {
//   const [configData, setConfigData] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [saving, setSaving] = useState(false);

//   const loadConfig = async () => {
//     if (!deviceId || !enabled) return;
//     try {
//       setLoading(true);
//       const response = await getDeviceStatusByTab(deviceId, screen, tab);
//       setConfigData(response.data);
//     } catch (err) {
//       console.error("Failed to load config:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     if (enabled) {
//       loadConfig();
//     }
//   }, [deviceId, screen, tab, enabled]);

//   const saveConfig = async (oid, value) => {
//     try {
//       setSaving(true);
//       // Refresh configuration after save
//       await loadConfig();
//     } catch (err) {
//       console.error("Failed to update config:", err);
//     } finally {
//       setSaving(false);
//     }
//   };

//   return {
//     configData,
//     loading,
//     saving,
//     saveConfig,
//     refetch: loadConfig,
//   };
// };

// export default useDeviceConfig;
import { useEffect, useState } from "react";
import {
  fetchOidMapping,
  getDeviceStatusByTab,
  saveSnmpDataForDevice,
} from "../services/deviceStatus.service";
import Toast from "@/components/Reusable/Toast/Toast";

const useDeviceConfig = (
  deviceId,
  screen,
  tab,
  enabled = true,
  configurationTabs = []
) => {
  const [configData, setConfigData] = useState(null);
  const [oidMapping, setOidMapping] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // const loadConfig = async () => {
  //   if (!deviceId || !enabled) return;

  //   try {
  //     setLoading(true);

  //     // 1. Get current configuration values
  //     const response = await getDeviceStatusByTab(
  //       deviceId,
  //       screen,
  //       tab
  //     );

  //     setConfigData(response?.data || null);

  //     // 2. Get all OIDs from configuration layout
  //     const allOids = [];

  //     configurationTabs.forEach((tabData) => {
  //       (tabData?.oids?.static || []).forEach((oid) => {
  //         const cleanOid = String(oid || "").trim();

  //         if (cleanOid && !allOids.includes(cleanOid)) {
  //           allOids.push(cleanOid);
  //         }
  //       });
  //     });

  //     console.log("OIDs sent for mapping:", allOids);

  //     // 3. Fetch OID mapping
  //     if (allOids.length > 0) {
  //       const mappingResponse = await fetchOidMapping(allOids);

  //       console.log("OID Mapping Response:", mappingResponse);

  //       setOidMapping(
  //         mappingResponse?.data ||
  //           mappingResponse ||
  //           []
  //       );
  //     } else {
  //       setOidMapping([]);
  //     }
  //   } catch (err) {
  //     console.error("Failed to load config:", err);
  //     setOidMapping([]);
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const loadConfig = async () => {
    if (!deviceId || !enabled) return;

    try {
      setLoading(true);

      const allOids = [];

      configurationTabs.forEach((tabData) => {
        (tabData?.oids?.static || []).forEach((oid) => {
          const cleanOid = String(oid || "").trim();

          if (cleanOid && !allOids.includes(cleanOid)) {
            allOids.push(cleanOid);
          }
        });
      });

      const [statusResponse, mappingResponse] = await Promise.all([
        getDeviceStatusByTab(deviceId, screen, tab),

        allOids.length > 0 ? fetchOidMapping(allOids) : Promise.resolve([]),
      ]);
      if (statusResponse?.status === 0) {
        // Ensure Toast is imported correctly (see note below)
        Toast(
          "Error",
          statusResponse?.message || "Failed to load device status",
          "error"
        );
      }
      setConfigData(statusResponse?.data || null);

      setOidMapping(mappingResponse?.data || mappingResponse || []);
    } catch (err) {
      console.error("Failed to load config:", err);

      setOidMapping([]);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (enabled) {
      loadConfig();
    }
  }, [deviceId, screen, tab, enabled, configurationTabs]);

  const saveConfig = async (payload) => {
    if (!Array.isArray(payload) || payload.length === 0) {
      return {
        success: false,
        message: "No configuration values to save",
      };
    }

    try {
      setSaving(true);

      const response = await saveSnmpDataForDevice(deviceId, payload);

      // Refresh configuration after successful save
      await loadConfig();

      return {
        success: true,
        response,
      };
    } catch (err) {
      console.error("Failed to save configuration:", err);

      return {
        success: false,
        message:
          err?.response?.data?.message ||
          err?.message ||
          "Failed to save configuration",
      };
    } finally {
      setSaving(false);
    }
  };

  return {
    configData,
    oidMapping,
    loading,
    saving,
    saveConfig,
    refetch: loadConfig,
  };
};

export default useDeviceConfig;
