import { useEffect, useState } from "react";

import {
  getDeviceLayout,
  getDeviceLayoutfofCnms,
} from "../services/deviceLayout.service";
import { setCachedLayout } from "../utils/layoutCache";
import { useSelector } from "react-redux";

const useDeviceLayout = (terminalType, node) => {
  const [layout, setLayout] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { isCnms } = useSelector((state) => state.nodeDetails);
  console.log("isCnmsisCnmsvvv", isCnms);

  const terminalId = node?.imSiteDetail?.imTerminalType?.id;
  const siteId = node?.siteId;
  const resourceId = node?.resourceId;
  useEffect(() => {
    if (!terminalType) return;
    // const cachedLayout = getCachedLayout(terminalType);

    // if (cachedLayout) {
    //   setLayout(cachedLayout);
    //   return;
    // }

    let isMounted = true;

    const fetchLayout = async () => {
      try {
        setLoading(true);

        // const response = await getDeviceLayout(
        //   terminalType
        // );

        // 1. Declare a variable to hold the response
        let response;

        // 2. Assign the result based on the condition
        if (isCnms) {
          response = await getDeviceLayoutfofCnms(
            terminalId,
            siteId,
            resourceId
          );
        } else {
          response = await getDeviceLayout(terminalType);
        }

        const parsedLayout = JSON.parse(response.data.layout);

        if (!isMounted) return;

        setCachedLayout(terminalType, parsedLayout);

        setLayout(parsedLayout);
      } catch (err) {
        console.error(err);

        if (!isMounted) return;

        setError(err);
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchLayout();

    return () => {
      isMounted = false;
    };
  }, [terminalType]);

  return {
    layout,
    loading,
    error,
  };
};

export default useDeviceLayout;
