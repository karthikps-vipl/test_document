import { useEffect, useState } from "react";
import { getNetworkAcceleratorRttMode } from "../services/networkAccelerator.service";
import Toast from "@/components/Reusable/Toast/Toast";

const useNetworkAcceleratorRttMode = (deviceId, enabled = false) => {
  const [data, setData] = useState({
    mode: "",
    rtt: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!deviceId || !enabled) {
      return;
    }

    let cancelled = false;
    let timer = null;

    const fetchData = async (isInitial = false) => {
      try {
        setLoading(true);
        setError(null);
        if (isInitial) {
          setLoading(true);
        }
        const response = await getNetworkAcceleratorRttMode(deviceId);
        if (cancelled) return;
        if (response && response.status === 0) {
          Toast("Error", response.message || "Failed to fetch data", "error");
          return;
        }
        setData({
          mode: response?.mode ?? "",
          rtt: response?.rtt ?? "",
        });
        if (isInitial) {
          setLoading(false);
        }
      } catch (err) {
        if (!cancelled) {
          console.error("Failed to fetch Network Accelerator RTT/Mode:", err);

          setError(err);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    fetchData(true);

    timer = setInterval(() => {
      fetchData(false);
    }, 30000);

    return () => {
      cancelled = true;
      if (timer) {
        clearInterval(timer);
      }
      setError(null); 
    };
  }, [deviceId, enabled]);

  return {
    data,
    loading,
    error,
  };
};

export default useNetworkAcceleratorRttMode;
