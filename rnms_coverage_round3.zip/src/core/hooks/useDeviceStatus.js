// import { useEffect, useState } from "react";
// import { extractOidsFromLayout } from "../utils/oidExtractor";
// import { getDeviceStatus } from "../services/deviceStatus.service";

// const useDeviceStatus = (layout, deviceId) => {
//   const [oidValueMap, setOidValueMap] = useState({});
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);

//   console.log("oidValueMap", oidValueMap);

//   useEffect(() => {
//     if (!layout || !deviceId) return;

//     const fetchStatus = async () => {
//       try {
//         setLoading(true);

//         // STEP 1: extract OIDs
//         const { staticOids, tableOids } = extractOidsFromLayout(layout);

//         const payload = [
//             ...new Set([
//                ...staticOids,
//                ...tableOids
//             ])
//          ];

//         // STEP 3: API CALL (single call)
//         const response = await getDeviceStatus(payload);

//         console.log("oid_Data", response);

//         // STEP 4: build map
//         // expected: { ".1.3.6.1...": "value" }

//         const mapping = {};

//         (response || []).forEach((item) => {
//           mapping[item.oidName] = item;
//         });

//         setOidValueMap(mapping);

//         // setOidValueMap(response?.data || {});
//       } catch (err) {
//         console.error(err);
//         setError(err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchStatus();
//   }, [layout, deviceId]);

//   return {
//     oidValueMap,
//     loading,
//     error,
//   };
// };

// export default useDeviceStatus;

// import { useEffect, useState } from "react";
// import {
//   fetchOidMapping,
//   getDeviceStatusByTab,
// } from "../services/deviceStatus.service";

// const useDeviceStatus = (deviceId, screen, tab) => {
//   const [statusData, setStatusData] = useState(null);
//   const [oidMap, setOidMap] = useState({});
//   const [loading, setLoading] = useState(false);

//   console.log("jfhvj", deviceId);

//   useEffect(() => {
//     if (!deviceId) return;

//     let cancelled = false;

//     const load = async () => {
//       try {
//         setLoading(true);

//         const statusRes = await getDeviceStatusByTab(deviceId, screen, tab);

//         if (cancelled) return;

//         const data = statusRes?.data || {};

//         setStatusData(data);

//         const allOids = new Set();

//         Object.keys(data.static || {}).forEach((oid) => allOids.add(oid));

//         Object.values(data.table || {}).forEach((rows) => {
//           rows.forEach((row) => {
//             Object.keys(row).forEach((oid) => allOids.add(oid));
//           });
//         });

//         const mappingRes = await fetchOidMapping([...allOids]);

//         if (cancelled) return;

//         const map = {};

//         (mappingRes || []).forEach((item) => {
//           map[item.oidName] = {
//             value: item.operator_map,
//           };
//         });

//         setOidMap(map);

//         // const map = {};

//         // (mappingRes || []).forEach((item) => {
//         //   map[item.oidName] = item.operator_map;
//         // });

//         // setOidMap(map);
//       } catch (e) {
//         console.error(e);
//       } finally {
//         if (!cancelled) setLoading(false);
//       }
//     };

//     load();

//     const timer = setInterval(load, 20000);

//     return () => {
//       cancelled = true;

//       clearInterval(timer);
//     };
//   }, [deviceId, screen, tab]);
//   return { statusData, oidMap, loading };
// };

// export default useDeviceStatus;

import { useEffect, useState } from "react";
import {
  getDeviceStatusByTab,
  getDeviceStatusByTabForCnms,
} from "../services/deviceStatus.service";
import Toast from "@/components/Reusable/Toast/Toast";
import { useSelector } from "react-redux";

const useDeviceStatus = (deviceId, screen, tab, enabled = true, node) => {
  const [statusData, setStatusData] = useState(null);
  const [loading, setLoading] = useState(false);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  console.log("statusDatastatusData", statusData);

  const terminalId = node?.imSiteDetail?.imTerminalType?.id;
  const siteId = node?.siteId;
  const resourceId = node?.resourceId;

  // const transformToCnmsFormat = (input) => {
  //   let rawData;

  //   // STEP 1: Handle Stringified JSON
  //   // If input is a string (like in your actual response), parse it into an object first
  //   try {
  //     if (typeof input === 'string') {
  //       rawData = JSON.parse(input);
  //     } else {
  //       rawData = input;
  //     }
  //   } catch (e) {
  //     console.error("Failed to parse JSON string:", e);
  //     return null;
  //   }

  //   // DEBUG: Verify we now have an object
  //   console.log("DEBUG: Parsed Raw Data:", rawData);

  //   if (!rawData) return null;

  //   const transformed = {
  //     readingTime: rawData.readingTime || new Date().toISOString(),
  //     static: rawData.static || {},
  //     table: {}
  //   };

  //   // STEP 2: Process Static Data
  //   transformed.static = rawData.static || {};

  //   // STEP 3: Process Table Data (Cleaning the OID keys)
  //   if (rawData.table) {
  //     Object.keys(rawData.table).forEach((key) => {
  //       const value = rawData.table[key];

  //       if (Array.isArray(value) && value.length > 0) {
  //         // Split the long concatenated OID string and take the first OID
  //         // Converts ".1.3.6..._ .1.3.6..." -> ".1.3.6..."
  //         const cleanKey = key.split('_')[0];

  //         if (!transformed.table[cleanKey]) {
  //           transformed.table[cleanKey] = [];
  //         }

  //         // Push the objects (rows) into the cleaned key
  //         transformed.table[cleanKey].push(...value);
  //       }
  //     });
  //   }

  //   return transformed;
  // };
  const transformToCnmsFormat = (input) => {
    let rawData;

    try {
      if (typeof input === "string") {
        rawData = JSON.parse(input);
      } else {
        rawData = input;
      }
    } catch (e) {
      console.error("Failed to parse JSON string:", e);
      return null;
    }

    if (!rawData) return null;

    const transformed = {
      readingTime: rawData.readingTime || new Date().toISOString(),
      static: rawData.static || {},
      table: {},
    };

    // 1. Process Static Data
    transformed.static = rawData.static || {};

    // 2. Process Table Data
    if (rawData.table) {
      Object.keys(rawData.table).forEach((key) => {
        const value = rawData.table[key];

        if (Array.isArray(value) && value.length > 0) {
          // Get the first row to inspect its internal keys
          const firstRow = value[0];
          const internalKeys = Object.keys(firstRow);

          let reconstructedKey;

          if (key.includes("_")) {
            // If the key already has underscores, it's already concatenated.
            // We use it as is.
            reconstructedKey = key;
          } else if (internalKeys.length > 1) {
            // If the key is single (the issue) but there are multiple OIDs inside the object,
            // we RECONSTRUCT the key by joining the internal OIDs with an underscore.
            // Example: ".OID1" and ".OID2" inside -> becomes ".OID1_.OID2_"
            reconstructedKey = internalKeys.join("_") + "_";
          } else {
            // If it's just one OID, keep the key as it is.
            reconstructedKey = key;
          }

          // If this reconstructed key doesn't exist in our transformed object, create it
          if (!transformed.table[reconstructedKey]) {
            transformed.table[reconstructedKey] = [];
          }

          // Push the data into the reconstructed key
          transformed.table[reconstructedKey].push(...value);
        }
      });
    }

    return transformed;
  };
  useEffect(() => {
    if (!deviceId || !enabled) return;
    // if (!statusData) {
    //   setLoading(true);
    // }
    let cancelled = false;
    setStatusData(null);
    setLoading(true);

    const load = async (isInitial = false) => {
      try {
        let response;
        if (isCnms) {
          response = await getDeviceStatusByTabForCnms(
            terminalId,
            siteId,
            resourceId,
            screen,
            tab
          );
        } else {
          response = await getDeviceStatusByTab(deviceId, screen, tab);
        }

        if (cancelled) return;
        if (response.status === 0) {
          Toast("Error", `${response.message}`, "error");
        }
        // NOTE: Your actual response shows status 7 for "RNMS not reachable"
        // You might want to check if status === 0 or if it's a specific error code
        if (response.status !== 0 && response.status !== 7) {
          // Add logic here if status 7 is considered an error in your UI
        }

        if (isCnms) {
          // response.data.value is the STRINGified JSON from your log
          const cleanData = transformToCnmsFormat(response?.data?.value);
          setStatusData(cleanData);
        } else {
          setStatusData(response?.data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    load(true);

    const timer = setInterval(() => load(false), 30000);

    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [deviceId, screen, tab, enabled]);

  return {
    statusData,
    loading,
  };
};

export default useDeviceStatus;
