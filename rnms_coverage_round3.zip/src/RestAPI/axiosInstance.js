/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : RestAPI
   File Name                : axiosInstance.js
   Author                   : SURAJ - VIPL
   Package                  : src\RestAPI\axiosInstance.js
   Purpose                  : The purpose is to show the entire IAF-NMS Axios Instance and Token authorization are defined in this file. 
   Created Date             : 21-02-2026
 *******************************************************************************************/
import axios from "axios";
import Cookies from "js-cookie";
const token = Cookies.get("token");
export const AxiosInstance = axios.create();
AxiosInstance.interceptors.request.use(
  (config) => {
    console.log(token, "token");
    config.headers.Authorization = token && `Bearer ${token}`; // Add token to headers
    console.log(config, "LL");
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
// Interceptor to handle 401 errors (Unauthorized)
AxiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.log("logout");
      return Promise.reject(error);
    }
    return Promise.reject(error);
  }
);
