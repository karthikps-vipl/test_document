export const NmsSocketTopic = `/IAFNMSWebSocketTopic`;

export const DEVICE_REACHABILITY_STATUS = `/IAFNMSWebSocketTopic/deviceReachabilityStatus`;
export const VEHICLE_UP_TIME = `/IAFNMSWebSocketTopic/VehicleUptimeUpdate`;

export const ALARM_SOCKET_NMS = "/IAFNMSWebSocketTopic/sendAlarmToUI";

// Port status
export const PORT_STATUS = `/IAFNMSWebSocketTopic/PortStatusUpdate`;
//
export const PING_TOOLS = "/IAFNMSWebSocketTopic/sendPingToolToUI";

export const REAL_TIME_REPORT_DATA_UPDATE_TO_UI =
  "/IAFNMSWebSocketTopic/RealTimeReportDataUpdateToUI";

export const DELAY_RESPONSE_SOCKET = `/IAFNMSWebSocketTopic/DelayAndResponseDataUpdateToUI`;

export const LINK_STATUS_CONFIGURATION = `/IAFNMSWebSocketTopic/LinkStatusData`;

export const PERFORMANCE_DATA_UPDATE_TO_UI = `/IAFNMSWebSocketTopic/PerformanceDataUpdateToUI`;
export const CNMS_REACH_ABILITY_STATUS = `/IAFNMSWebSocketTopic/cnmsReachabilityStatus`;

export const SYSLOG_AUDIT_TOPIC = `/syslogAIWebSocketTopic/syslogAudit`;

export const DISCOVERY_STAGE_DATA = `/IAFNMSWebSocketTopic/sendSiteDiscoveryData`;
export const DISCOVERY_STAGE_DATA_RNMS = `/IAFNMSWebSocketTopic/sendDiscoveryStageData`;

// cnms map topics
export const SITE_LOCATION_UPDATE = `/IAFNMSWebSocketTopic/SiteLocationUpdate`;
export const ALARM_SOCKET_CNMS = `/IAFNMSWebSocketTopic/cnmsAlarm`;
export const SITE_REACHABILITY_STATUS = `/IAFNMSWebSocketTopic/siteReachabilityStatus`;
export const CNMS_ACTIVE_STATUS_UPDATE = `/IAFNMSWebSocketTopic/CNMSActiveActiveStatusUpdate`;
export const SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT = `/IAFNMSWebSocketTopic/sendNotificationToUiForUserLogout`;

export const CHAT_BASE = `/nmsChat`;
export const CHAT_TOPIC = "/topic/public";
export const ACK_DESTINATION = "/app/sendMessage";
export const SEND_EXPORT_CERTIFICATE_STATUS_TO_UI =`/IAFNMSWebSocketTopic/exportCetificateToModem`;