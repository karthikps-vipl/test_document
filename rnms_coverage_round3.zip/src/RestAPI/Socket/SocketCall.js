/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Socket
   File Name                : SocketCall.js
   Author                   : SURAJ - VIPL
   Package                  : src\RestAPI\Socket\SocketCall.js
   Purpose                  : The purpose is to show the entire IAF-NMS websocket calling endpoint from this file 
   Created Date             : 19-02-2026
 *******************************************************************************************/
import { SOCKET_URL, CHAT_URL } from "../url/baseUrl";
import { CHAT_BASE } from "./Endpoint";

//port 8006
export const SocketMgmt = (ENDPOINT) => {
  return SOCKET_URL + ENDPOINT;
};

export const ChatSocketMgmt = CHAT_URL + CHAT_BASE;

// Syslog AI socket (FastAPI backend, upstream syslogai:8050)
// Uses the same SOCKET_URL origin so relative resolution works unchanged.
export const SyslogSocketMgmt = (ENDPOINT = "/syslogai/ws") => {
  return SOCKET_URL + ENDPOINT;
};
