export const FETCH_ALL_SITE_DETAILS = `/InventoryMgmt/SiteDetails/fetchAllSiteDetails`;
export const UPDATE_CNMS_CONFIGURATION = `/InventoryMgmt/Rnms/updateCnmsConfiguration`;
export const FETCH_SITEDETAILS_BY_TERMINALTYPE_ID = `/InventoryMgmt/SiteDetails/fetchSiteDetailsByTerminalTypeId`;
export const FETCH_ALL_OPEN_ALARM_CNMS = `/fault/cnmsview/fetchAllOpenAlarms`;

export const FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID = `/InventoryMgmt/SiteResource/fetchAllSiteResourceInfoBySiteId`;
export const FETCH_SITE_RESOURCE_PORT_INFO = `/InventoryMgmt/SiteResource/fecthSiteResourcePortInfo`;
export const FETCH_SITE_DETAILS_BY_ID = `/InventoryMgmt/SiteDetails/fetchSiteDetailsById`;

export const CNMS_DELETE_SITE = `/InventoryMgmt/SiteDetails/deleteSite`;
export const CNMS_ADD_SITE = `/InventoryMgmt/SiteDetails/addSite`;

// Discovery
export const PERFORM_SITE_DISCOVERY = `/InventoryMgmt/SiteDetails/performSiteDiscovery`;
export const FETCH_ALL_TERMINAL_TYPE_ALONG_WITH_SITE = `/InventoryMgmt/Rnms/fetchAllTerminalTypeAlongWithSite`;

// Site Summary
export const FETCH_SITE_SUMMARY_DETAILS = `/InventoryMgmt/SiteDetails/fetchsiteSummaryDetails`;
export const COUNT_SITE_ACTIVE_MODE_OF_COMM_SUMMARY = `/InventoryMgmt/SiteDetails/countSiteActiveModeOfCommSummary`;

export const FETCH_ALL_SITE_GROUPS = `/InventoryMgmt/fetchAllSiteGroups`;
export const DELETE_SITE = `/InventoryMgmt/SiteDetails/removeSite`;

//Role configurator
export const ROLE_ASSIGNMENT_SITE = `/InventoryMgmt/SiteDetails/fetchRoleAssignmentSites`;
export const FETCH_SITE_DETAILS_BASED_ON_LOCAL_MODE = `/InventoryMgmt/SiteDetails/fetchSiteDetailsBasedOnLocalMode`;
export const SAVE_ROLE_ASSIGNMENT_CONFIGURATION = `/InventoryMgmt/SiteDetails/saveRoleAssignmentConfiguration`;
export const DELETE_ROLE_CONFIGURATION = `/InventoryMgmt/SiteDetails/deleteRoleConfiguration`;

// map
export const UPDATE_SITE_LATLONG_DETAILS = `/InventoryMgmt/SiteDetails/updateSiteLatLongDetails`;

export const SITE_LOCATION_UPDATE_LOG = `/InventoryMgmt/SiteDetails/fetchSiteLocationUpdatelog`;

export const GET_LDAP_CONFIG = `/LdapConfig/getLdapConfig`;
export const SAVE_LDAP_CONFIG = `/LdapConfig/setLdapConfig`;

// Alarm Summary
export const UPDATE_WORKFLOW_CNMS = "/fault/cnmsview/updateWorkflow";

// Alarm Configuration CNMS
export const FETCH_RESOURCE_MASTER_TYPE_BASED_ON_TERMINAL_ID = `/InventoryMgmt/Resource/fetchResourceMasterTypeBasedOnTerminalId`;
export const GET_ALL_ALARM_TYPE_CNMS = `/fault/getAllAlarmTypeCnms`;
export const UPDATE_ALARM_TYPE_CNMS = `/fault/updateAlarmTypeCnms`;
export const GET_ALARM_AUGMENTATION = `/fault/cnmsview/getAlarmAugmentation`;
export const ALL_ALARM_TYPE_CNMS_BY_TERMINAL_TYPE_ID = `/fault/AllAlarmTypeCnmsByTerminalTypeId`;
// ---------------REPORTS---------------
export const GET_ALL_USERS_FOR_DEPLOYED_TERMINAL_TYPE = `/SecurityMgmt/getAllUsersForDeployedTerminalType`;
export const FETCH_CNMS_DB_RESTORE_LOG_BETWEEN_THE_DATES = `/DBTool/fetchCnmsDbRestoreLogsBetweenTheDates`;
export const FETCH_SITE_AVAILABILITY_OPS_NONOPS_LOG_REPORT = `/fault/fetchSiteOpsNonopsLogReport`;
export const FETCH_SITE_DB_BACKUP_LOGS = `/DBTool/fetchSiteDBBackupLogs`;
export const FETCH_SITE_DB_RESTORE_LOGS_BETWEEN_DATES = `/DBTool/fetchSiteDBRestoreLogsBetweenDates`;
export const FETCH_ALL_FOREIGN_IP_ALARMS = `/fault/fetchAllForeignIpAlarms`;
export const SITE_MAINTENANCE_REPORT = `/InventoryMgmt/SiteDetails/siteMainatainanceReport`;
export const GET_SITE_REACHABILITY_ALARM_REPORT = `/fault/cnms/getSiteReachabilityAlarmReport`;
export const FETCH_SITE_REP_DETAILS_BY_SITE_ID = `/InventoryMgmt/RepDetails/fetchSiteRepDetailsBySiteId`;
export const FETCH_SEGMENT_DETAILS_BASED_ON_TERMINAL_TYPE = `/InventoryMgmt/Resource/fetchSegmentDetailsBasedOnTerminalType`;
export const FIND_ALL_RESOURCE_FOR_GIVEN_TERMINAL_TYPE_AND_SEGMENT = `/InventoryMgmt/Resource/findAllResourceForGivenTerminalTypeAndSegment`;
export const GET_ALARM_TYPE_FOR_RESOURCE_LIST = `/fault/getAlarmTypeForResourceList`;
export const GET_ALL_RNMS_ESCALATED_ALARM_REPORT = `/fault/cnms/getAllRNMSEscalatedAlarmReport`;
export const FETCH_LST_OF_RESOURCE_INFO_BASED_ON_SYSLOG_GIVEN_TERMINAL = `/InventoryMgmt/Resource/fetchLstOfResourceInfoBasedOnSyslogGivenTerminal`;
export const GET_SITE_SYSLOG_REPORT = `/fault/getSiteSyslogReport`;
export const FETCH_SITE_LINK_STATUS_REPORT = `/TopologyMgmt/Site/LinkStatus/fetchSiteLinkStatusReport`;
export const FETCH_SITE_LINK_STATUS_SUMMARY = `/TopologyMgmt/Site/LinkStatus/fetchSiteLinkStatusSummary`;

// remotegroup
export const ADD_SITE_GROUP = `/InventoryMgmt/siteGroup`;
export const LDAP_LOGIN = `/auth/cnms/loginLdap`;
export const RESET_PASSWORD = "/auth/resetAdminPasswordNew";

// upload
export const FTECH_BACKUP_DATA_BY_RESOURCE_ID_SITE_ID_AT_CNMS = `/ConfigurationMgmt/fetchBackupDataByResourceIdAndSiteIdAtCnms`;
export const FTECH_ALL_DEVICE_BACKUP = `/ConfigurationMgmt/fetchAllDeviceBackup`;
export const FETCH_BACKUP_DATA_BY_RESOURCE_ID = `/ConfigurationMgmt/fetchBackupDataByResourceId`;
export const FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES = `/InventoryMgmt/Resource/findAllBackupUploadTypeDevices`;
export const FETCH_ALL_BACKUP_UPLOAD_TYPE_DEVICES_AT_CNMS = `/InventoryMgmt/SiteResource/findAllBackupUploadTypeDevicesAtCnms`;
export const FETCH_ALL_REMOTE_TERMINAL_TYPE_DETAILS_AT_CNMS = `/InventoryMgmt/Rnms/fetchAllRemoteTerminalTypeDetailsAtCNMS`;

// file comparison

export const GET_COMPARE_TYPE_ENUM = `/ConfigurationMgmt/getCompareTypeEnum`;
export const COMPARE_BACKUP_DATA_AT_CNMS = `/ConfigurationMgmt/compareBackupDataAtCnms`;
export const COMAPARE_BACKUP_DATA = `/ConfigurationMgmt/compareBackupData`;
export const GET_BACKUP_MODE_ENUM = `/ConfigurationMgmt/getBackupModeEnum`;

//Db store
export const RESTORE_SITE_DB_BACKUP = "/DBTool/restoreSiteDBBackup";
export const GET_RESTORE_BACKUP_FILE_LIST = "/DBTool/getRestoreBackupFileList";
export const DB_DATA_RESTORE = "/DBTool/dbDataRestore";
export const GET_SITE_DB_BACKUP_SQL_FILELIST =
  "/DBTool/getSiteDBBackupSQLFileList";

// sms and email settings

export const GET_SMS_GATEWAY = `/emailsms/getSmsGateway`;
export const GET_EMAIL_GATEWAY = `/emailsms/getEmailGateway`;
export const GET_ALL_USERS_EMAIL_SMS_SERVICE = `/emailsms/getAllUsers`;
export const GET_SMTP_GATEWAY_CONNECTIVITY = `/emailsms/getSmtpGatewayConnectivity`;
export const GET_SMS_GATEWAY_CONNECTIVITY = `/emailsms/getSmsGatewayConnectivity`;
export const UPLOAD_SINGLE_DEVICE_BACKUP = `/ConfigurationMgmt/uploadSingleDeviceBackUp`;
export const UPLOAD_ALL_DEVICE_BACKUP = `/ConfigurationMgmt/uploadAllDeviceBackUp`;
export const UPLOAD_SINGLE_DEVICE_BACKUP_FROM_CNMS = `/ConfigurationMgmt/uploadSingleDeviceBackUpFromCnms`;
export const GET_ALL_SMS_MAIL_LOG = `/emailsms/getAllSmsMailLog`;
export const FETCH_EVENTBASED_ALERT_CONFIG_DETAILS = `/emailsms/fetchEventBasedAlertConfigurationDeatils`;
export const SAVE_EVENTBASED_ALERT_CONFIG_DETAILS = `/emailsms/SaveEventBasedAlertConfigurationDeatils`;
export const SEND_IMMEDIATE_ADHOC_SMS = `/emailsms/sendImmediateAdhocSms`;
export const SEND_SCHEDULED_ADHOC_SMS = `/emailsms/sendScheduledAdhocSms`;
export const SEND_IMMEDIATE_ADHOC_EMAIL = `/emailsms/sendImmediateAdhocEmail`;
export const SEND_SCHEDULED_ADHOC_EMAIL = `/emailsms/sendScheduledAdhocEmail`;
export const GET_ADHOC_MSG_TEMPLATE = `/emailsms/getAdhocMsgTemplate`;
export const GET_SMS_TEMPLATE = `/emailsms/getSmsTemplate`;
export const FETCH_SITE_REP_DETAILS_FOR_EMAIL_BY_SITEID = `/InventoryMgmt/RepDetails/fetchSiteRepDetailsForEmailBySiteId`;
export const SAVE_AND_UPDATE_ADHOC_MSG_TEMPLATE = `/emailsms/saveAndUpdateAdhocMsgTemplate`;
export const SAVE_AND_UPDATE_SMS_TEMPLATE = `/emailsms/saveAndUpdateSmsTemplate`;
export const SAVE_AND_UPDATE_USERS = `/emailsms/saveAndUpdateUsers`;
export const SOFT_DELETE_USER_BY_ID = `/emailsms/softDeleteUserById`;
export const SAVE_AND_UPDATE_EMAIL_GATEWAY = `/emailsms/saveAndUpdateEmailGateway`;
export const GET_SMS_CONFIG_REMOTE = `/emailsms/getSmsConfigRemote`;
export const SAVE_AND_UPDATE_SMS_CONFIG_REMOTE = `/emailsms/saveAndUpdateSmsConfigRemote`;
export const GET_ALERT_PROFILE_FOR_GIVEN_ALERT_PROFILE_ID = `/emailsms/getAlertProfileForGivenAlertProfileId`;
export const GET_ALERT_PROFILE_FOR_GIVEN_REMOTE_ID = `/emailsms/getAlertProfileForGivenRemoteId`;
export const GET_SITE_RESOURCE_LIST_FAULT_SUMMARY = `/fault/cnmsview/getSiteResourceListFaultSummary`;
export const FETCH_UP_DOWN_COUNT_OF_DEVICES_FOR_GIVEN_SITEID = `/InventoryMgmt/SiteResource/fetchUpAndDownCountOfDevicesForGivenSiteId`;
export const FETCH_SITE_REP_DETAILS_BY_SITEID = `/InventoryMgmt/RepDetails/fetchSiteRepDetailsBySiteId`;
export const GET_MAJOR_ALARM_COUNT_BY_SITEID = `/fault/cnmsview/getMajorAlarmCountBySiteId`;
export const FETCH_SITE_VEHICLE_UPTIME_BY_SITEID = `/InventoryMgmt/SiteDetails/fetchSiteVehicleUpTimeBySiteId`;
export const FETCH_UP_DEVICESLIST = `/InventoryMgmt/SiteDetails/fetchUpDevicesLst`;
export const FETCH_DOWN_DEVICES_LIST = `/InventoryMgmt/SiteDetails/fetchDownDevicesLst`;
export const FETCH_STATUS_OF_SITE_BASED_ON_SITEID = `/InventoryMgmt/SiteDetails/fetchStatusOfSiteBasedOnSiteId`;
export const SAVE_AND_UPDATE_ALERT_PROFILE = `/emailsms/saveAndUpdateAlertProfile`;
export const DELETE_ALERT_PROFILE = `/emailsms/deleteAlertProfile`;
export const SAVE_AND_UPDATE_SMS_GATEWAY = `/emailsms/saveAndUpdateSmsGateway`;
//version matrix

export const GET_VERSION_DETAILS_BY_DATES = `/ConfigurationMgmt/getVersionDetailsBwDates`;
export const UPDATE_SITE_ACTIVE_MODE_COMMUNICATION = `/InventoryMgmt/SiteDetails/updateSiteActiveModeOfCommunication`;

//sysLog
export const FETCH_SYS_LOG_SERVER_SETTINGS = "/fault/fetchSyslogServerSettings";
export const REMOVE_SYS_LOG_SERVER_SETTINGS =
  "/fault/removeSyslogServerSettings";
export const ADD_SYS_LOG_SERVER_SETTINGS = "/fault/addSyslogServerSettings";
export const UPDATE_SYS_LOG_SERVER_SETTINGS =
  "/fault/updateSyslogServerSettings";

//CNMS
export const GET_LAYOUT_FOR_DEVICE_CNMS = `/ConfigurationMgmt/deviceLayout/getLayoutForDeviceCNMS`;
export const GET_STATUS_BY_DEVICE_AND_TAB_CNMS = `/ConfigurationMgmt/deviceStatus/getStatusByDeviceAndTabCNMS`;

export const FETCH_CNMS_ACTIVE_STATUS_DETAIL = `/InventoryMgmt/CnmsDetails/fetchCnmsActiveStatusDetail`;
//certificate
export const GET_ALL_CERTIFICATE_EXPIRE_COUNT =
  "/cert/getAllCertificateExpiredCount";

// ACU CNMS CONFIG API
export const JOG_ANTENNA_CNMS = "/ConfigurationMgmt/epAcu/jogAntennaAtCNMS";
export const STOP_ANTENNA_CNMS = "/ConfigurationMgmt/epAcu/stopAntennaAtCNMS";
export const MISC_MOVEMENT_CNMS = "/ConfigurationMgmt/epAcu/miscMovementAtCNMS";
export const LOCATE_ANTENNA_CNMS =
  "/ConfigurationMgmt/epAcu/locateAntennaAtCNMS";
export const GET_POSITION_CNMS = "/ConfigurationMgmt/epAcu/getPositionAtCNMS";
export const GET_STATUS_FOR_CONFIGURATION_ACU_CNMS =
  "/ConfigurationMgmt/epAcu/getStatusForConfigurationAtCNMS";

// ANTP CNMS CONFIG API
export const GET_STATUS_FOR_CONFIGURATION_CNMS =
  "/ConfigurationMgmt/AntpJisnu/getStatusForConfigurationAtCNMS";
export const SAVE_MANUAL_GPS_CNMS =
  "/ConfigurationMgmt/AntpJisnu/saveManualGPSAtCNMS";
export const SAVE_TARGET_GPS_CNMS =
  "/ConfigurationMgmt/AntpJisnu/saveTargetGPSAtCNMS";
export const SAVE_MANUAL_STOW_CNMS =
  "/ConfigurationMgmt/AntpJisnu/performLOSAtCNMS";
export const SAVE_AUTO_STOW_CNMS =
  "/ConfigurationMgmt/AntpJisnu/performAutoStowAtCNMS";
export const SAVE_HOMING_CNMS =
  "/ConfigurationMgmt/AntpJisnu/performHomingAtCNMS";
export const SAVE_ELEVATION_MOVEMENT_CNMS =
  "/ConfigurationMgmt/AntpJisnu/performElevationMovementAtCNMS";
export const SAVE_AZIMUTH_MOVEMENT_CNMS =
  "/ConfigurationMgmt/AntpJisnu/performAzimuthMovementAtCNMS";
export const FETCH_CURRENT_AZ_EL_CNMS =
  "/ConfigurationMgmt/AntpJisnu/fetchAntpMovementStatusAtCNMS";
export const PERFORM_STAND_BY_MODE_CNMS =
  "/ConfigurationMgmt/AntpJisnu/performStandByModeAtCNMS";
export const GO_TO_AZIMUTH_ELEVATION_POSITION_CNMS =
  "/ConfigurationMgmt/AntpJisnu/gotoAzimuthElevationPositionAtCNMS";

export const FETCH_MODEM_ENCRYPTOR_PASSWORD =
  "/InventoryMgmt/SiteDetails/fecthModemEcryptorPasswordByTeminalTypeId";

export const UPDATE_MODEM_ENCRYPTOR_PASSWORD =
  "/InventoryMgmt/SiteDetails/updateRemotesModemAndEncryptorDevicePassword";
