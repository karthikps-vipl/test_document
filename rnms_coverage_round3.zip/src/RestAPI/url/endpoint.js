/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : url
   File Name                : endpoint.js
   Author                   : SURAJ - VIPL
   Package                  : src\RestAPI\url\endpoint.js
   Purpose                  : The purpose is to show the entire IAF-NMS API endpoint are defined in this file. 
   Created Date             : 21-02-2026
 *******************************************************************************************/
//Inventory
export const DEPLOYED_TERMINAL_TYPE = `/InventoryMgmt/Rnms/fetchDeployedTerminalType`;
export const VALIDATE_IP = `/auth/validateIP`;
export const NODE_DETAILS = `/InventoryMgmt/Rnms/fetchRnmsDetails`;
export const FETCH_CNMS_DETAILS = `/InventoryMgmt/Rnms/fetchCnmsDetails`;
export const SAVE_RNMS_DETAILS = `/InventoryMgmt/Rnms/saveRnmsDetails`;

export const FETCH_REMOTE_REP_DETAILS = `/InventoryMgmt/RepDetails/fetchRemoteRepDetails`;
export const UPDATE_LOCATION_API = `/InventoryMgmt/Rnms/updateLocationDetails`;
export const FETCH_NETWORK_ACCELERATOR_DETAILS_OF_TERMINAL_TYPE = `/InventoryMgmt/Resource/fetchNetworkAcceleratorDetailsOfTerminalType`;

export const SAVE_REMOTE_REP_DETAIL = `/InventoryMgmt/RepDetails/saveRemoteRepDetail`;

export const MODIFY_REMOTE_REP_DETAIL = `/InventoryMgmt/RepDetails/modifyRemoteRepDetail`;

export const DELETE_REMOTE_REP_DETAILS = `/InventoryMgmt/RepDetails/deleteRemoteRepDetail`;

export const FETCH_RESOURCE_INFO_BY_SNMP_AND_SOAP_COMMUNICATION_TYPE = `/InventoryMgmt/Resource/fetchResourceInfoBySNMPAndSoapCommunicationType`;
export const FETCH_RESOURCE_MASTER_TYPE_DETAILS_BY_PROTOTYPE_ID = `/InventoryMgmt/Resource/fetchResourceMasterTypeDetailsByProtoTypeId/1`;
export const FIND_DISCOVERD_RES_BY_DEVICE_TYPE_ID =
  "/InventoryMgmt/Resource/findDiscoveredResByDeviceTypeId";
export const FETCH_MISC_CONFIGURATION_BY_ID =
  "/InventoryMgmt/MiscConfiguration/fetchMiscConfigurationById/10";

export const UPDATE_MISC_CONFIGURATION_BASED_ON_ID =
  "/InventoryMgmt/MiscConfiguration/updateMiscConfigurationBasedOnId";
export const FETCH_ALL_MISC_CONFIGURATION =
  "/InventoryMgmt/MiscConfiguration/fetchAllMiscConfiguration";
export const FETCH_MASTER_TYPES_BASED_ON_WEB_CONFIG_FOR_GIVEN_TERMINAL_ID = `/InventoryMgmt/Resource/fetchMasterTypesBasedOnWebConfigForGivenTerminalId`;
export const FETCH_RESOURCE_INFO_BY_SNMP_AND_SNMP_COMMUNICATION_TYPE = `/InventoryMgmt/Resource/fetchResourceInfoBySNMPCommunicationType`;
export const SAVE_RESOURCE_MASTER_DATA_CONFIGURATION =
  "/InventoryMgmt/Resource/saveResourceMasterDataConfiguration";
export const FETCH_ALL_POLLING_INTERVAL =
  "/InventoryMgmt/PollingInterval/fetchAllPollingIntervals";
export const FETCH_ALL_UNITS = "/InventoryMgmt/PollingInterval/fetchAllUnits";
export const UPDATE_POLLING_INTERVAL =
  "/InventoryMgmt/PollingInterval/updatePollingIntervals";
export const ASSIGN_PROFILE_TO_RESOURCES = `/InventoryMgmt/Resource/assignProfileToResources`;
export const FIND_ALL_BACKUP_UPLOAD_TYPE_DEVICE = `/InventoryMgmt/Resource/findAllBackupUploadTypeDevices`;

export const FETCH_RESOURCE_INFO_BY_RESOURCE_TYPE_ID = `/InventoryMgmt/Resource/fetchResourceInfoByResourceTypeId`;
export const FETCH_CNMS_ADDRESS_DETAILS = `/InventoryMgmt/CnmsDetails/fetchCnmsAddressDetails`;

export const UPDATE_ENTERPRISE_OID_OF_RESMASTERTYPE_BY_RESOURCE_ID_URL =
  "/InventoryMgmt/Resource/updateEnterpriseOidofResMasterTypeByResourceTypeId";
export const UPDATE_SYS_OID_OF_RESMASTERTYPE_BY_RESOURCE_ID_URL =
  "/InventoryMgmt/Resource/updateSysOidofResMasterTypeByResourceTypeId";
export const FETCH_TERMINAL_BY_TERMINAL_NAME =
  "/InventoryMgmt/Rnms/fetchTerminalDetailsByTerminalName";
//To Get the data from View Device Details upon right click on the Segment in the sidebar tree..
export const FETCH_ALL_RESOURCES_OF_GIVEN_SEGMENT =
  "/InventoryMgmt/Resource/fetchAllResourcesOfGivenSegment";

//auth
export const GET_CAPTCHA = `/auth/generateCaptcha`;
export const GET_CAPTCHA_AT_CNMS = "/auth/generateCaptchaAtCNMS";
export const LOGIN = `/auth/login`;
export const LOGOUT = `/auth/logoutUser`;
export const GET_CNMS_LINK_AVAILABILITY = "/auth/getCNMSLinkAvailability";
export const LOGIN_AT_CNMS = "/auth/loginAtCNMS";

//configure
export const FETCH_ALL_ROUTER_CONSOLE_DETAILS = `/ConfigurationMgmt/fetchALLRouterConsoleDetails`;
export const GET_NET_CONFIG_API_TOKEN_FOR_GIVEN_RESID = `/ConfigurationMgmt/deviceStatus/getNetConfigApiTokenForGivenResId`;
export const UPDATE_NET_CONFIG_API_TOKEN_FOR_GIVEN_RESID = `/ConfigurationMgmt/deviceStatus/updateNetConfigApiTokenForGivenResId`;
export const SAVE_ROUTER_CONSOLE_DETAILS = `/ConfigurationMgmt/saveRouterConsoleDetails`;
export const UPDATE_ROUTER_CONSOLE_DETAILS = `/ConfigurationMgmt/updateRouterConsoleDetails`;
export const DELETE_ROUTER_CONSOLE_DETAILS = `/ConfigurationMgmt/deleteRouterConsoleDetails`;
export const FETCH_ROUTER_CONSOLE_DETAILS_BY_ID_AUTH = `/ConfigurationMgmt/fetchRouterConsoleDetailsByIdAuth`;
export const SCHEDULE_BACKUP = `/ConfigurationMgmt/scheduleBackUp`;
export const FETCH_ALL_DEVICE_SETTING_BASED_ON_TERMINAL_TYPE = `/ConfigurationMgmt/DeviceSettings/fetchAllDeviceSettingsBasedOnTerminalType`;
export const FETCH_DEVICE_SETTINGS = `/ConfigurationMgmt/DeviceSettings/fetchDeviceSettings`;
export const UPDATE_DEVICE_SETTINGS = `/ConfigurationMgmt/DeviceSettings/updateDeviceSettings`;

export const SINGLE_DEVICE_BACKUP = "/ConfigurationMgmt/singleDeviceBackup";
export const UPDATE_SCHEDULER_TASKS = `/ConfigurationMgmt/updateSchedulerTasks`;
export const VIEW_ALL_SCHEDULER_TASKS = `/ConfigurationMgmt/viewAllSchedulerTasks`;
export const DELETE_SCHEDULER_TASKS = `/ConfigurationMgmt/deleteSchedulerTasks`;
export const GET_TASK_TRIGGER_TYPE_ENUM =
  "/ConfigurationMgmt/getTaskTriggerTypeEnum";
export const GET_EXECUTION_STATUS_ENUM = `/ConfigurationMgmt/getExecutionStatusEnum`;
export const FETCH_SCHEDULED_TASK_EXECUTION_BY_ID = `/ConfigurationMgmt/fetchScheduledTaskExecutionById`;

export const DO_SNMP_GET = `/ConfigurationMgmt/SNMP/doSnmpGet`;

export const LINK_CONFIGURATION = `/TopologyMgmt/LinkConfiguration/fetchLinkDetailsOfGivenTerminalTypeId`;
export const MANAGED_UNMANAGED_DEVICES = `/InventoryMgmt/Resource/fetchAllResourceOfManagedAndUnManangedGivenTerminal`;
export const FETCH_NETWORK_ACCELERATOR_RTT_MODE = `/ConfigurationMgmt/deviceStatus/fetchNetworkAcceleratorRTTMode`;

// Resource
export const FETCH_ALL_RESOURCE_INFO = `/InventoryMgmt/Resource/fetchAllResourceInfo`;
export const GET_ALL_RESOURCES_BY_TERMINAL = `/InventoryMgmt/Resource/fetchAllResourceOfManagedAndUnManangedGivenTerminal`;
export const FETCH_ALL_MASTER_TERMINAL_TYPE_DETAILS = `/InventoryMgmt/Rnms/fetchAllMasterTerminalTypeDetails`;
export const FETCH_ALL_TERMINAL_TYPE_DETAILS = `/InventoryMgmt/Rnms/fetchAllTerminalTypeDetails`;
export const FETCH_ALL_RESOURCES_OF_GIVEN_TERMINAL = `/InventoryMgmt/Resource/fetchAllResourceOfGivenTerminal`;
export const FETCH_ALL_SEGMENTS = `/InventoryMgmt/Resource/fetchAllSegmentInfo`;
export const FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST = `/InventoryMgmt/Resource/fetchAllResourcesWithInSegmentLst`;

// Alarm Settings
export const FETCH_ALL_RESOURCE_MASTER_TYPE_DETAILS = `/InventoryMgmt/Resource/fetchAllResourceMasterTypeDetails`;
export const GET_ALL_ALARM_TYPE = `/fault/getAllAlarmType`;
export const GET_DEFAULT_POLL_INTERVAL = "/fault/getDefaultPollInterval";
export const UPDATE_DEFAULT_POLL_INTERVAL = "/fault/updateDefaultPollInterval";
export const GET_ALL_ALARM_NOTIFICATION = "/fault/getAllAlarmNotification";
export const UPDATE_ALL_ALARM_NOTIFICATION_SETTINGS =
  "/fault/updateAllAlarmNotificationSettings";
// Fault
export const FETCH_ALL_OPEN_ALARM = `/fault/fetchAllOpenAlarms`;
export const GET_SEVERITY_KEY_VALUE_PAIR = `/fault/getSeverityKeyValuePair`;
export const UPDATE_WORKFLOW = `/fault/updateWorkflow`;
export const GET_PING_SETTINGS = `/fault/getPingSettings`;
export const VIEW_ALARM_AUGMENTATION = `/fault/viewAlarmAugmentation`;
export const UPDATE_HD_TICKET_STATUS = `/fault/updateHDTicketStatus`;

export const FAULT_GET_VIEW_ACTIVE_ALARM = `/fault/viewDeviceActiveAlarms`;
export const FAULT_GET_ALARMSUPRESSION_INFO = `/fault/getAlarmSupressionInfo`;
export const FAULT_ADD_ALARMSUPRESSION = `/fault/saveAlarmSupressionInfo`;
export const FAULT_ALARMSUPRESSION_FETCH_ALARMTYPE = `/fault/fetchAlarmType`;
export const FAULT_ALARMSUPRESSION_DELETE = `/fault/deleteAlarmSupressionInfo`;
export const FAULT_ALARMSUPRESSION_UPDATE = `/fault/updateAlarmSupressionInfo`;

export const UPDATE_PING_SETTINGS = `/fault/updatePingSettings`;
//Topology
export const FETCH_EXISTING_LINK_CONFIGURATION_DETAILS = `/TopologyMgmt/LinkConfiguration/fetchExistingLinkConfigurationDetails`;
export const SAVE_TOPOLOGY = `/InventoryMgmt/Rnms/savetopologyData`;
export const SAVE_RACK = `/InventoryMgmt/Rnms/saveRackViewData`;
export const FETCH_SNMP_PROFILE_DETAILS = `/TopologyMgmt/SnmpProfile/fetchSnmpProfileDetails`;
export const DELETE_SNMP_PROFILE_DETAILS = `/TopologyMgmt/SnmpProfile/deleteSnmpProfileDetails`;
export const SAVE_SNMP_PROFILE_DETAILS = `/TopologyMgmt/SnmpProfile/saveSnmpProfileDetails`;
export const UPDATE_SNMP_PROFILE_DETAILS = `/TopologyMgmt/SnmpProfile/updateSnmpProfileDetails`;
export const fetchAllForeignIPDetailUrl =
  "/TopologyMgmt/fetchAllForeignIPDetail";
export const REMOVE_FOREIEGN_IP_URL = "/TopologyMgmt/removeForeignIP";
export const ADD_FOREIEGN_IP_URL = "/TopologyMgmt/addForeignIP";
export const FETCH_LINK_STATUS_SUMMARY =
  "/TopologyMgmt/LinkConfiguration/fetchLinkStatusSummary";
// Discovery

export const PERFORM_DISCOVERY = `/TopologyMgmt/performDiscovery`;
export const PERFORM_CNMS_DEVICE_DISCOVERY = `/TopologyMgmt/performCNMSDeviceDiscovery`;
//Maintanance device
export const MOVE_TO_MAINTANANCE = `/TopologyMgmt/deleteDevice`;
export const ADD_DEVICE = `/TopologyMgmt/addDevice`;

//Status
export const GET_DEVICE_LAYOUT = `/ConfigurationMgmt/deviceLayout/getLayoutForDevice`;

//Network Accelelator
export const INVENTORY_UPDATE_RESOURCEINFO = `/InventoryMgmt/Resource/updateResourceInfo`;
export const INVENTORY_UPDATE_POLLING_INTERVAL = `/fault/updatePollInterval`;
export const GET_DEVICE_POLLING_INTERVAL = "/fault/getNePollingInterval";
export const PING_TOOLS = "/fault/pingTool";
export const ARP_TOOL_FIND_IP = "/fault/arpToolFindIP";
export const TRACE_TOOL = "	/fault/traceTool";
export const GET_SOS_ALERTS_LOG_BY_SITE_AND_DATE =
  "/SecurityMgmt/getSosAlertsLogBySiteAndDate";
export const FETCH_RESOURCE_INFO_DEVICEID =
  "/InventoryMgmt/Resource/fetchResourceInfoByDeviceId";

export const FETCH_PORT_INFO =
  "/TopologyMgmt/LinkConfiguration/fetchPortInfoOfRouters";
export const UPDATE_LINK_CONFIG =
  "/TopologyMgmt/LinkConfiguration/updateLinkConfigurationDetails";
export const GET_COM_PORTLIST = `/TopologyMgmt/SerialDeviceConfig/getComPortList`;
export const MODIFY_SERIAL_DEVICE_CONFIGURATION_DATA = `/TopologyMgmt/SerialDeviceConfig/modifySerailDeviceConfigurationData`;
export const FETCH_ALL_SERIAL_DEVICE_COMM_CONFIGURATION_DATA = `/TopologyMgmt/SerialDeviceConfig/fetchAllSerialDeviceCommConfigurationData`;
export const FETCH_ALL_FOREIGN_IP_DETAIL_URL = `/TopologyMgmt/fetchAllForeignIPDetail`;
export const REMOVE_FOREIGN_IP_URL = "/TopologyMgmt/removeForeignIP";

export const UPDATE_LINK_CONFIGURATION_DETAILS = `/TopologyMgmt/LinkConfiguration/updateLinkConfigurationDetails`;
// device tool tip
export const GET_DEVICE_TOOLTIP_OPTIONS = `/InventoryMgmt/TooltipConfiguration/fetchAllTooltipConfiguration`;
export const SAVE_TOOLTIP_OPTIONS = `/InventoryMgmt/TooltipConfiguration/saveTooltipConfiguration`;
export const FETCH_PORT_INFO_DETAILS_BY_RESOURCE_ID = `/TopologyMgmt/PortInfo/fetchPortInfoDetailsByResourceId`;
export const FETCH_ALL_PORT_INFO_DETAILS = `/TopologyMgmt/PortInfo/fetchAllPortInfoDetails`;

// Performance
export const FETCH_CPU_RAM_DISK = `/PerformanceMgmt/fetchCpuRamDisk`;
export const FETCH_ALL_THRESHOLD_INFO = `/PerformanceMgmt/fetchAllThresholdInfo`;
export const FETCH_ALL_PERFORMANCE_PARAM_MONITORING_DETAILS = `/PerformanceMgmt/fetchAllPerformanceParamMonitoringDetails`;
export const MODIFY_PERPARAM_MONITORING_STATUS = `/PerformanceMgmt/modifyPerfParamMonitoringStatus`;
export const MODIFY_PERPARAM_MONITORING_TIME_INTERVAL = `/PerformanceMgmt/modifyPerfParamMonitoringTimeInterval`;
export const DELETE_THRESHOLD_INFO = `/PerformanceMgmt/deleteThresholdInfo`;
export const FETCH_THRESHOLD_PRIMARY_RANGE =
  "/PerformanceMgmt/fetchThresholdPrimaryRange";
export const FETCH_PERF_PARAM_OF_RESOURCE_TYPE =
  "/PerformanceMgmt/fetchPerfParamOfResourceType";
export const MODIFY_THRESHOLD_DATA = `/PerformanceMgmt/modifyThresholdData`;
export const SAVE_THRESHOLD_DATA = "/PerformanceMgmt/saveThresholdData";

// Security 8010
export const FETCH_GET_ALL_IP = `/SecurityMgmt/getallIP`;
export const FETCH_SECURITY_SETTINGS = `/SecurityMgmt/fetchSecuritySettings`;
export const FETCH_SECURITY_SETTINGS_WITH_AUTH = `/SecurityMgmt/fetchSecuritySettingsWithAuth`;
export const UPDATE_SECURITY_SETTINGS = "/SecurityMgmt/updateSecuritySettings";

export const CALL_SOS = `/SecurityMgmt/callSOS`;
export const ALARM_LOGOUT = `/SecurityMgmt/logout`;
export const CHANGED_PASSWORD_SELF_URL = "/SecurityMgmt/changePasswordSelf";
export const CHANGED_PASSWORD_DEFAULT_SELF_URL =
  "/SecurityMgmt/changeDefaultPasswordSelf";
//PORT-STATUS Resourcename
export const PORT_RESOURCE_DETAILS = `/InventoryMgmt/Resource/fetchRouterSwitchDetailsOfTerminalType`;
//port 8011 Db backup
export const EXECUTE_BACKUP_COMMAND = `/DBTool/executeBackupCommand`;
export const VIEW_SCHEDULED_TASK = `/DBTool/viewScheduledTask`;

export const FETCH_TASK_BASED_ON_TASK_TYPE = `/DBTool/fetchTaskBasedOnTaskType/1`;
export const CREATE_SCHEDULE_TASK = `/DBTool/createScheduleTask`;
//Help Desk
export const GET_ALL_PRIORITY = `/helpdesk/getAllPriority`;
export const GET_ALL_STATUS = `/helpdesk/getAllStatus`;
export const GET_ALL_TICKET = `/helpdesk/getAllTicket`;
export const CREATE_TICKET = `/helpdesk/createTicket`;
export const GET_TICKET_HISTORY_FOR_GIVEN_ID = `/helpdesk/getTicketHistoryForGivenId`;

export const UPDATE_TICKET = `/helpdesk/updateTicket`;
export const GET_ALL_TICKET_FOR_GIVEN_REMOTE_ID = `/helpdesk/getAllTicketForGivenRemoteId`;

export const FETCH_UNIQUE_USER_LIST = `/helpdesk/fetchUniqueUserList`;
// ------------SNMP CONFIG API--------------------
export const GET_LAYOUT_FOR_DEVICE = `/ConfigurationMgmt/deviceLayout/getLayoutForDevice`;
export const GET_STATUS_BY_DEVICE_AND_TAB = `/ConfigurationMgmt/deviceStatus/getStatusByDeviceAndTab`;
export const UPDATE_DEVICE_LAYOUT = `/ConfigurationMgmt/deviceLayout/updateDeviceLayout`;
export const FETCH_OID_MAPPING = `/ConfigurationMgmt/deviceStatus/fetchOidMapping`;
export const FETCH_SNMP_OUTPUT_MAPPING = `/ConfigurationMgmt/deviceStatus/fetchSNMPOutputMapping`;
export const SAVE_DEVICE_LAYOUT = `/ConfigurationMgmt/deviceLayout/saveDeviceLayout`;
export const SAVE_SNMP_DATA_FOR_DEVICE = `/ConfigurationMgmt/deviceStatus/saveSNMPDataForDevice`;
export const UPLOAD_CERT_TO_MODEM =
  "/ConfigurationMgmt/serialdevice/x509modem/uploadCertificateToModemLocallyFromRnms";
export const UPLOAD_CERT = "/cert/uploadCert";

//  -----------------REPORT API------------------
// Audit Log
export const GET_ALL_USERS = `/SecurityMgmt/getAllUsers`;
export const GET_EVNT_TYPE_LIST = `/auditMgnt/getEvntTypeList`;
export const FETCH_ALL_FILTERED_AUDIT_LOGS = `/auditMgnt/fetchAllFilteredAuditLogs`;

// User Blocked Names
export const FETCH_ALL_USER_BLOCK_ALARM = `/fault/fetchAllUserBlockAlaram`;

// Foreign Ip
export const FETCH_ALL_FOREIGN_IP_ALARMS_AT_RNMS = `/fault/fetchAllForeignIpAlarmsAtRnms`;

// Alarm Log
// export const FETCH_ALL_SEGMENTS = `/InventoryMgmt/Resource/fetchAllSegmentInfo`;
// export const FETCH_ALL_RESOURCES_WITHIN_SEGMENT_LIST = `/InventoryMgmt/Resource/fetchAllResourcesWithInSegmentLst`;
export const GET_ALARM_TYPE_FOR_RESOURCE_LIST = `/fault/getAlarmTypeForResourceList`;
export const GET_ALL_SEVERITY_KEY_VALUE_PAIR = `/fault/getAllSeverityKeyValuePair`;
export const GET_ALARM_REPORT = `/fault/getAlarmReport`;

// System Log
export const FETCH_LST_OF_RESOURCE_INFO_BASED_ON_SYSLOG = `/InventoryMgmt/Resource/fetchLstOfResourceInfoBasedOnSyslog`;
export const GET_SYSLOG_SEVERITY_KEY_VALUE_PAIR = `	/fault/getSyslogSeverityKeyValuePair`;
export const GET_SYSLOG_FACILITY_KEY_VALUE_PAIR = `/fault/getSyslogFacilityKeyValuePair`;
export const GET_SYSLOG_INFO_REPORT = `/fault/getSyslogInfoReport`;

// Device Availability
export const FETCH_DEVICE_AVAILABILITY_LOG = `/fault/fetchDeviceAvailabilityLog`;

// Device Maintenance
export const DEVICE_MAINTENANCE_REPORT = `/TopologyMgmt/deviceMainatainanceReport`;
export const FETCH_VEHICLE_UPTIME_LOG_REPORT = `/InventoryMgmt/Rnms/fetchVehicleUptimeLogReport`;
export const FETCH_RNMS_UPTIME_LOG_REPORT = `	/InventoryMgmt/Rnms/fetchRNMSUptimeLogReport`;

// Link Summary
// export const FETCH_EXISTING_LINK_CONFIGURATION_DETAILS = `/TopologyMgmt/LinkConfiguration/fetchExistingLinkConfigurationDetails`
export const GET_LINK_STATUS_LOG_REPORT = `/TopologyMgmt/LinkConfiguration/getLinkStatusLogReport`;

export const FETCH_FM_ACU_LOG_DETAILS = `/fault/fetchFmAcuLogDeatils`;
// DB Report
export const FETCH_RNMS_DB_BACKUP_LOGS_BETWEEN_THE_DATES = `/DBTool/fetchRnmsDbBackupLogsBetweenTheDates`;

// Performance
export const FETCH_PERFORMANCE_MONITORING_DEVICES_LIST = `/PerformanceMgmt/fetchPerformanceMonitoringDevicesLst`;
// export const FETCH_PERF_PARAM_OF_RESOURCE_TYPE =
//   "/PerformanceMgmt/fetchPerfParamOfResourceType";
export const FETCH_HISTORICAL_PERFORMANCE_DATA =
  "/PerformanceMgmt/fetchHistoricalPerfData";
export const FETCH_REAL_TIME_PERFORMANCE_DATA = `/PerformanceMgmt/fetchRealTimePerformanceData`;
export const STOP_REAL_TIME_PERFORMANCE_DATA = `/PerformanceMgmt/stopRealTimePerformanceData`;
export const STOP_REAL_TIME_INTERFACE_PERFORMANCE_DATA = `/PerformanceMgmt/stopInterfaceLvlRealTimePerformanceData`;
export const FETCH_RESOURCE_FOR_INTERFACE_LEVEL_REPORT = `/PerformanceMgmt/ResourcesForInterfaceLvlReport`;
export const FETCH_PERFORM_PARAM_FOR_INTERFACE_LEVEL = `/PerformanceMgmt/fetchPerfParamForInterfacelvl`;
export const FETCH_HISTORICAL_INTERFACE_LEVEL_DATA = `/PerformanceMgmt/fetchInterfaceLvlHistoricalPerfData`;
export const FETCH_REAL_TIME_INTERFACE_LEVEL_DATA = `/PerformanceMgmt/fetchInterfaceLvlRealTimePerformanceData`;
export const FETCH_DELAY_RESPONSE_DATA = `/PerformanceMgmt/fetchDelayAndResponse`;
export const STOP_DELAY_AND_RESPONSE = `/PerformanceMgmt/stopDelayAndResponse`;

// SERIAL DEVICE DG-SET API
// export const FETCH_DG_SET_PARAMS_AT_CNMS = '/ConfigurationMgmt/serialdevice/dgset/fetchDgSetParamsAtCNMS'
export const FETCH_DG_SET_PARAMS =
  "/ConfigurationMgmt/serialdevice/dgset/fetchDgSetParams";
// export const FETCH_DG_SET_OFF_PARAMS = '/ConfigurationMgmt/serialdevice/dgset/fetchDgSetOffParams'
// export const GET_ALL_CERT = "/cert/getAllCert";
export const GET_ALL_CERT = "/cert/getAllCertNew";

export const CREATE_CSR_URL = "/cert/createCSR";
export const DELETE_CSR_URL = "/cert/deleteCertNew";
export const UPLOAD_CERT_URL = "/cert/uploadCert";
export const GET_ROOT_OR_SUB_CA_URL = "/cert/getAllRootAndSubCADetails";
export const UPLOAD_KEY_URL = "/cert/uploadPrivateKey";
export const DOWNLOAD_FILE_FOR_GIVEN_ID_URL = "/cert/downloadFileForGivenID";
export const DOWNLOAD_PACKAGE_CERT_URL = "/cert/downloadPackageCert";
export const UPLOAD_PACKAGED_CRT_FILE_URL = "/cert/packageCert";
export const GET_MAC_ADDRESS =
  "/InventoryMgmt/SiteDetails/fetchRemoteModemMacAddressForGivenSite";
export const GET_MAC_ADDRESS_AT_CNMS_URL =
  "/InventoryMgmt/SiteResource/fetchRemoteModemDetailsForAGivenSiteId";
export const GET_IP_ADDRESS_AT_CNMS_URL =
  "/InventoryMgmt/SiteResource/fetchTotalNmsDetailsForAGivenSiteId";
export const GET_ALL_ROOT_AND_SUB_CA_DETAILS =
  "/cert/getAllRootAndSubCADetails";
export const UPLOAD_CERT_ROOT_OR_SUB = "/cert/uploadCertRootOrSub";

// ACU CONFIG API
export const JOG_ANTENNA = "/ConfigurationMgmt/epAcu/jogAntenna";
export const STOP_ANTENNA = "/ConfigurationMgmt/epAcu/stopAntenna";
export const MISC_MOVEMENT = "/ConfigurationMgmt/epAcu/miscMovement";
export const LOCATE_ANTENNA = "/ConfigurationMgmt/epAcu/locateAntenna";
export const GET_POSITION = "/ConfigurationMgmt/epAcu/getPosition";
export const GET_STATUS_FOR_CONFIGURATION_ACU =
  "/ConfigurationMgmt/epAcu/getStatusForConfiguration";

// ANTP CONFIG API
export const GET_STATUS_FOR_CONFIGURATION =
  "/ConfigurationMgmt/AntpJisnu/getStatusForConfiguration";
export const SAVE_MANUAL_GPS = "/ConfigurationMgmt/AntpJisnu/saveManualGPS";
export const SAVE_TARGET_GPS = "/ConfigurationMgmt/AntpJisnu/saveTargetGPS";
export const SAVE_MANUAL_STOW = "/ConfigurationMgmt/AntpJisnu/performLOS";
export const SAVE_AUTO_STOW = "/ConfigurationMgmt/AntpJisnu/performAutoStow";
export const SAVE_HOMING = "/ConfigurationMgmt/AntpJisnu/performHoming";
export const SAVE_ELEVATION_MOVEMENT =
  "/ConfigurationMgmt/AntpJisnu/performElevationMovement";
export const SAVE_AZIMUTH_MOVEMENT =
  "/ConfigurationMgmt/AntpJisnu/performAzimuthMovement";
export const FETCH_CURRENT_AZ_EL =
  "/ConfigurationMgmt/AntpJisnu/fetchAntpMovementStatus";
export const PERFORM_STAND_BY_MODE =
  "/ConfigurationMgmt/AntpJisnu/performStandByMode";
export const GO_TO_AZIMUTH_ELEVATION_POSITION =
  "/ConfigurationMgmt/AntpJisnu/gotoAzimuthElevationPosition";

///////////Nms msg//////////////////
export const SUBSCRIBER_STATUS_URL =
  "/NMSMessaging/subscriberConnectionStatus ";
export const PUBLISHER_STATUS_URL = "/NMSMessaging/publisherConnectionStatus ";
export const CNMS_STATUS_URL =
  "/InventoryMgmt/CnmsDetails/fetchCnmsAddressDetails";
///////////////////////////CNMS /////////////////////////////
export const SAVE_CNMS_DETAILS = "/InventoryMgmt/Rnms/saveCnmsDetails";
export const VALIDATE_RESOURCE_PASSWORD =
  "/InventoryMgmt/Resource/validatingResourcePassword";

export const GET_ALL_GROUPS = "/SecurityMgmt/getAllGroups";
export const FETCH_SITE_REP_DETAILS =
  "/InventoryMgmt/RepDetails/fetchSiteRepDetails";
export const DELETE_SITE_REP_DETAILS =
  "/InventoryMgmt/RepDetails/deleteSiteRepDetails";
export const ADD_SITE_REP_DETAILS =
  "/InventoryMgmt/RepDetails/addSiteRepDetail";
export const EDIT_SITE_REP_DETAILS =
  "/InventoryMgmt/RepDetails/modifySiteRepDetail";

export const FETCH_ALL_TERMINAL_REMOTE_TYPE_DETAILS_ATCNMS =
  "/InventoryMgmt/Rnms/fetchAllRemoteTerminalTypeDetailsAtCNMS";
export const FETCH_GET_ALL_ALLOWED_IP = `/SecurityMgmt/getAllAllowedIP`;
export const DELETE_IP = `/SecurityMgmt/deleteIP`;

export const ADD_ALLOWED_IP = "/SecurityMgmt/addAllowedIp";
export const FETCH_DB_CONFIG_DATA = "/DBTool/fetchDBConfigData";
export const CHECK_FOR_BACKUP_FILES = "/DBTool/checkForBackupFiles";
export const CONFIG_NO_OF_BACKUP_FILES = "/DBTool/configNoOfBackUpFiles";
export const GET_SITE_DEFAULT_POLLING_INTERVAL =
  "/fault/getSiteDefaultPollInterval";
export const UPDATE_SITE_DEFAULT_POLLING_INTERVAL =
  "/fault/updateSiteDefaultPollInterval";
export const FORCE_DELETE_USER = "/SecurityMgmt/forceDeleteUser";
export const GET_ALL_NON_DEFAULT_GROUPS =
  "/SecurityMgmt/getAllNonDefaultGroups";
export const ADD_USERS = "/SecurityMgmt/adduser";
export const UPDATE_USERS = "/SecurityMgmt/updateUser";
export const RESET_PASSWORD = "/SecurityMgmt/setdefaultpassword";
export const CHANGE_PASSWORD_OTHER_USER =
  "/SecurityMgmt/changePasswordOtherUser";
export const BLOCK_USER = "/SecurityMgmt/blockUser";
export const UNBLOCK_USER = "/SecurityMgmt/unblockUser";
export const GET_ALL_PRIVILEGES = "/SecurityMgmt/getAllPrivileges";
export const DELETE_GROUP = "/SecurityMgmt/forceDeleteGroup";
export const GET_USERS_BY_GROUP = "/SecurityMgmt/getAllUsersByGroupId/";
export const ADD_GROUP = "/SecurityMgmt/addGroup";
export const GET_RESOURCE_TYPE_BY_SEGMENT =
  "/InventoryMgmt/Resource/getResourceTypeBySegment";
export const MODIFY_GROUP = "/SecurityMgmt/modifyGroup";
//
// SyslogAI"
// export const SYSLOG_DEBUG_EXCEL = `/syslogai/debug-excel`;
// export const SYSLOG_RUN_AUDIT = `/syslogai/run-audit`;
// export const SYSLOG_DETAILED_EXPORT_SYNCED = `/syslogai/detailed-export-synced`; // Usage: `${SYSLOG_DETAILED_EXPORT_SYNCED}/${batchName}`
// export const SYSLOG_GET_SYNCED_LOGS = `/syslogai/get-synced-logs`;
// export const SYSLOG_GET_MODELS = `/syslogai/models`;
// export const SYSLOG_LOAD_MODEL = `/syslogai/load-model`;
// export const SYSLOG_ENGINE_STATUS = `/syslogai/enginestatus`;
// export const SYSLOG_BATCH_DOWNLOAD = `/syslogai/download/batch/`

// SyslogAI
export const SYSLOG_DEBUG_EXCEL = `/syslogai/debug-excel`;
export const SYSLOG_RUN_AUDIT = `/syslogai/run-audit`;
export const SYSLOG_STOP_AUDIT = `/syslogai/stop-audit`;
export const SYSLOG_AUDIT_STATUS = `/syslogai/audit-status`;
export const SYSLOG_DETAILED_EXPORT_SYNCED = `/syslogai/detailed-export-synced`; // Usage: `${SYSLOG_DETAILED_EXPORT_SYNCED}/${batchName}`
export const SYSLOG_MASTER_DOWNLOAD = `/syslogai/download/master`; //USAGE:'/syslogai/download/master/{file_type}'
export const SYSLOG_GET_SYNCED_LOGS = `/syslogai/get-synced-logs`;
export const SYSLOG_GET_MODELS = `/syslogai/models`;
export const SYSLOG_LOAD_MODEL = `/syslogai/load-model`;
export const SYSLOG_ENGINE_STATUS = `/syslogai/enginestatus`;
export const SYSLOG_BATCH_DOWNLOAD = `/syslogai/download/batch/`;
export const SYSLOG_WEBSOCKETS = `/syslogai/stream-results`;

//NMS chatbot
export const NMS_CHATBOT_QUERY = `/query`;
export const NMS_CHATBOT_DB_QUERY = `/query-db`;

// CNMS MAP VIEW
export const GEO_SERVER_MAP_VIEW = `/geoserver/MCT_LSV_GIS/wms`;

// HUB-NMS
// GILAT SATCOM MODULE
export const FETCH_TOTAL_NMS_STATUS =
  "/ConfigurationMgmt/soapInterface/fetchTotalNMSStatus";
export const GET_NETWORK_SEGMENTS =
  "/ConfigurationMgmt/soapInterface/getNetworkSegments";
export const GET_NETWORK_SEGMENTS_CNMS =
  "/ConfigurationMgmt/soapInterface/getNetworkSegmentsCNMS";
export const GETCH_CPE_MANAGED_GROUPS =
  "/ConfigurationMgmt/soapInterface/fetchCPEManagedGroups";
export const FETCH_CPE_MANAGED_GROUPS_CNMS =
  "/ConfigurationMgmt/soapInterface/fetchCPEManagedGroupsCNMS";
export const FETCH_CPE_SECTION =
  "/ConfigurationMgmt/soapInterface/fetchCPESection";
export const FETCH_CPE_SECTION_AT_CNMS =
  "/ConfigurationMgmt/soapInterface/fetchCPESectionAtCnms";

// BUC STATUS AND CONFIG
export const GET_BUC_SERIAL_STATUS =
  "/ConfigurationMgmt/serialdevice/buc/getBucSerialStatus";
export const GET_BUC_SERIAL_STATUS_AT_CNMS =
  "/ConfigurationMgmt/serialdevice/buc/getBucSerialStatusAtCnms";
export const GET_BUC_SERIAL_CONFIG_STATUS_AT_CNMS =
  "/ConfigurationMgmt/serialdevice/buc/getBucSerialConfigStatusAtCnms";
export const CONFIG_BUC_SERIAL_AT_CNMS =
  "/ConfigurationMgmt/serialdevice/buc/configBucSerialAtCnms";
export const GET_BUC_SERIAL_CONFIG_STATUS =
  "/ConfigurationMgmt/serialdevice/buc/getBucSerialConfigStatus";
export const CONFIG_BUC_SERIAL =
  "/ConfigurationMgmt/serialdevice/buc/configBucSerial";

// LNB_RCU STATUS AND CONFIG
export const GET_LNBC_SERIAL_STATUS =
  "/ConfigurationMgmt/serialdevice/lnbc/getLnbcSerialStatus";
export const GET_LNBC_SERIAL_STATUS_AT_CNMS =
  "/ConfigurationMgmt/serialdevice/lnbc/getLnbcSerialStatusAtCnms";
export const GET_LNBC_SERIAL_CONFIG_STATUS_AT_CNMS =
  "/ConfigurationMgmt/serialdevice/lnbc/getLnbcSerialConfigStatusAtCnms";
export const CONFIG_LNBC_SERIAL_AT_CNMS =
  "/ConfigurationMgmt/serialdevice/lnbc/configLnbcSerialAtCnms";
export const GET_LNBC_SERIAL_CONFIG_STATUS =
  "/ConfigurationMgmt/serialdevice/lnbc/getLnbcSerialConfigStatus";
export const CONFIG_LNBC_SERIAL =
  "/ConfigurationMgmt/serialdevice/lnbc/configLnbcSerial";

// MK-II TERMINAL
// ACU STATUS
export const ACU_GET_ALL_SYSTEM_STATUS = `/ConfigurationMgmt/serialdevice/acu/getAllSystemStatus`;
export const ACU_GET_ALL_SYSTEM_STATUS_CNMS = `/ConfigurationMgmt/serialdevice/acu/getAllSystemStatusCNMS`;
// ACU CONFIG
export const ACU_GET_NAVIGATIONAL_DATA = `/ConfigurationMgmt/serialdevice/acu/getNavigationalData`;
export const ACU_GET_ANTENNA_RESET = `/ConfigurationMgmt/serialdevice/acu/getAntennaReset`;
export const ACU_GET_LOCATE = `/ConfigurationMgmt/serialdevice/acu/getLocate`;
export const ACU_GET_STATUS = `/ConfigurationMgmt/serialdevice/acu/getStatus`;
export const ACU_GET_STATUS_CNMS = `/ConfigurationMgmt/serialdevice/acu/getStatusACUAtCNMS`;
export const ACU_GET_STOP = `/ConfigurationMgmt/serialdevice/acu/getStop`;
export const ACU_GET_MOVE_JOG = `/ConfigurationMgmt/serialdevice/acu/getJogMove`;
export const ACU_GET_STOW = `/ConfigurationMgmt/serialdevice/acu/getStow`;
export const ACU_GET_DEPLOY = `/ConfigurationMgmt/serialdevice/acu/getDeploy`;
export const ACU_AUTO_MOVE = `/ConfigurationMgmt/serialdevice/acu/getAutoMove`;
export const GET_SATELLITE_DATA =
  "/ConfigurationMgmt/serialdevice/acu/getSatelliteData";
export const SAVE_SATELLITE_DATA =
  "/ConfigurationMgmt/serialdevice/acu/writeSatelliteData";

// ANTP STATUS
export const GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS =
  "/ConfigurationMgmt/serialdevice/getModeAndGetAntenaPositionerStatus";
export const GET_MODE_AND_GET_ANTENNA_POSITIONER_STATUS_CNMS =
  "/ConfigurationMgmt/serialdevice/getModeAndGetAntenaPositionerStatusCNMS";
export const GET_SWITCH_TO_REMOTE =
  "/ConfigurationMgmt/serialdevice/getSwitchToRemote";
export const GET_SWITCH_TO_REMOTE_CNMS =
  "/ConfigurationMgmt/serialdevice/getSwitchToRemoteCnms";
export const FETCH_LOS_RADIO_CLIENT_TABLE = `/ConfigurationMgmt/deviceStatus/fetchLOSRadioClientTable`;
export const FETCH_LOS_RADIO_CLIENT_TABLE_CNMS = `/ConfigurationMgmt/deviceStatus/fetchLOSRadioClientTableCNMS`;
// ANTP CONFIG
export const GET_AZIMUTH_QUERY = `/ConfigurationMgmt/serialdevice/getAzimuthQuery`;
export const GET_ELEVATION_QUERY = `/ConfigurationMgmt/serialdevice/getElevationQuery`;
export const GET_ELEVATION_UP = `/ConfigurationMgmt/serialdevice/getElevationUP`;
export const GET_ELEVATION_DOWN = `/ConfigurationMgmt/serialdevice/getElevationDOWN`;
export const GET_AZIMUTH_CW_DIRECTION = `/ConfigurationMgmt/serialdevice/getAzimuthCWDirection`;
export const GET_AZIMUTH_CCW_DIRECTION = `/ConfigurationMgmt/serialdevice/getAzimuthCCWDirection`;
export const GET_STOP = `/ConfigurationMgmt/serialdevice/getStop`;
export const GET_ALIGN = `/ConfigurationMgmt/serialdevice/getAlign`;
export const GET_SWITCH_TO_LOCAL = '/ConfigurationMgmt/serialdevice/getSwitchToLocal'

export const CALCULATE_DIST = `/ConfigurationMgmt/serialdevice/calculateDistanceForGivenLatLongOfTwoPoints`;
export const GET_ALL_SERIAL_DEVICE_SITES = '/ConfigurationMgmt/serialdevice/getAllSerialDeviceSites'
export const GET_SERIAL_DEVICE_SITES_FOR_GIVEN_ID = '/ConfigurationMgmt/serialdevice/getSerialDeviceSitesForGivenId'
export const LOS_ANTENNA_ADD_SITE_DATABASE = `/ConfigurationMgmt/serialdevice/saveSerialDeviceSite`;


// BTR STATUS
export const GET_BTR_ALL_STATUS = `/ConfigurationMgmt/serialdevice/btr/getBtrAllStatus`;
export const GET_BTR_ALL_STATUS_AT_CNMS = `/ConfigurationMgmt/serialdevice/btr/getBtrAllStatusAtCnms`;
// BTR CONFIG
export const GET_BTR_CONFIG_STATUS = `/ConfigurationMgmt/serialdevice/btr/getBtrConfigStatus`;
export const GET_BTR_CONFIG_STATUS_AT_CNMS = `/ConfigurationMgmt/serialdevice/btr/getBtrConfigStatusAtCNMS`;
export const CONFIG_ALL_FIELD_OF_BTR = `/ConfigurationMgmt/serialdevice/btr/configAllFieldOfBtr`;
export const CONFIG_ALL_FIELD_OF_BTR_CNMS = `/ConfigurationMgmt/serialdevice/btr/configAllFieldOfBtrCNMS`;

// NETWORK ACCELERATOR
export const GET_ALL_NETWORK_ACCELERATOR_RESPONSE = `/ConfigurationMgmt/serialdevice/nwa/getAllNetworkAcceleratorResponse`;
export const GET_ALL_NETWORK_ACCELERATOR_RESPONSE_CNMS = `/ConfigurationMgmt/serialdevice/nwa/getAllNetworkAcceleratorResponseCNMS`;

// LOS RADIO
export const FETCH_DEVICE_STATUS_RADIO = `/ConfigurationMgmt/deviceStatus/fetchDeviceStatus`