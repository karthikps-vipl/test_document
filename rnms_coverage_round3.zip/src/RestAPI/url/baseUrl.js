/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Socket
   File Name                : baseUrl.js
   Author                   : Ankitha - VIPL
   Package                  : src\RestAPI\url\baseUrl.js
   Purpose                  : The purpose is to show the entire IAF-NMS Base URL defined in this file. 
   Created Date             : 17-02-2026
 *******************************************************************************************/
// // works for production
// export const Is_Production = process.env.NODE_ENV === 'production';
// export const Is = process.env;

import { GEO_SERVER_MAP_VIEW } from "./endpoint";

// const getConfigValue = (key) => {
//   if (Is_Production) {
//     return window.RUNTIME_CONFIG?.GATEWAY_url || ''; // for production reads fron window.config
//   } else {
//     return meta.env[key] || ''; // for development reads from .env file
//   }
// };

// export const INVENTORY_URL = getConfigValue('REACT_APP_INVENTORY');

// export const Is_Production = import.meta.env.MODE === 'production';
// export const INVENTORY_URL = import.meta.env.REACT_APP_INVENTORY;

// export const Is_Production = import.meta.env.MODE === "production";
// // export const SUPERADMIN = window..SuperAdmin;

// export const INVENTORY_URL = import.meta.env.VITE_APP_INVENTORY;
// export const SECURITY_URL = import.meta.env.VITE_APP_SECURITY;
// export const AUTH_URL = import.meta.env.VITE_APP_AUTH;
// export const FAULT_URL = import.meta.env.VITE_APP_FAULT;
// export const TOPOLOGY_URL = import.meta.env.VITE_APP_TOPOLOGY;
// export const PERFORMANCE_URL = import.meta.env.VITE_APP_PERFORMANCE;
// export const SOCKET_URL = import.meta.env.VITE_APP_WEBSOCKET;
// export const CONFIG_URL = import.meta.env.VITE_APP_CONFIGURATION;
// export const DB_URL = import.meta.env.VITE_APP_DBBACKUP;
// export const AUDIT_URL = import.meta.env.VITE_APP_AUDIT;
// export const HELPDESK_URL = import.meta.env.VITE_APP_HELPDESK;

const getBaseUrl = (envVar) => {
  // 1. Production: Read dynamic configuration injected in index.html

  if (import.meta.env.PROD) {
    const host = window.APP_CONFIG?.BASE_URL;
    return `${host}:9012`;
  }

  // 2. Development (npm run dev): Fallback to Vite env variables
  return (envVar || "").trim();
};

export const INVENTORY_URL = getBaseUrl(import.meta.env.VITE_APP_INVENTORY);
export const SECURITY_URL = getBaseUrl(import.meta.env.VITE_APP_SECURITY);
export const AUTH_URL = getBaseUrl(import.meta.env.VITE_APP_AUTH);
export const FAULT_URL = getBaseUrl(import.meta.env.VITE_APP_FAULT);
export const TOPOLOGY_URL = getBaseUrl(import.meta.env.VITE_APP_TOPOLOGY);
export const PERFORMANCE_URL = getBaseUrl(import.meta.env.VITE_APP_PERFORMANCE);
export const SOCKET_URL = getBaseUrl(import.meta.env.VITE_APP_WEBSOCKET);
export const CONFIG_URL = getBaseUrl(import.meta.env.VITE_APP_CONFIGURATION);
export const DB_URL = getBaseUrl(import.meta.env.VITE_APP_DBBACKUP);
export const AUDIT_URL = getBaseUrl(import.meta.env.VITE_APP_AUDIT);
export const HELPDESK_URL = getBaseUrl(import.meta.env.VITE_APP_HELPDESK);
export const CERT_URL = getBaseUrl(import.meta.env.VITE_APP_CERT);
export const SYSLOGAI_URL = getBaseUrl(import.meta.env.VITE_APP_SYSLOGAI);
export const NMSMESSAGE_URL = getBaseUrl(import.meta.env.VITE_APP_NMSMESSAGE);
export const NMSChatBot_URL = getBaseUrl(import.meta.env.VITE_APP_NMSCHATBOT);
export const SMS_URL = getBaseUrl(import.meta.env.VITE_APP_SMS);
export const CHAT_URL = getBaseUrl(import.meta.env.VITE_APP_CHAT_SOCKET);

export const GEO_SERVER_MAP_VIEW_URL = `${getBaseUrl(
  import.meta.env.VITE_APP_GEOSERVER
)}${GEO_SERVER_MAP_VIEW}`;
