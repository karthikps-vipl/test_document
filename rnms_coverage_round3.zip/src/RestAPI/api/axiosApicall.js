/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : api
   File Name                : axiosApicall.js
   Author                   : Ankitha - VIPL
   Package                  : src\RestAPI\api\axiosApicall.js
   Purpose                  : The purpose is to show the entire IAF-NMS Axios Api Calling methodology from this file 
   Created Date             : 16-02-2026
 *******************************************************************************************/
// import {
//   fetchDeployedTerminalType
// } from '../url/endpoint';
import {
  AUTH_URL,
  INVENTORY_URL,
  FAULT_URL,
  TOPOLOGY_URL,
  PERFORMANCE_URL,
  SECURITY_URL,
  CONFIG_URL,
  DB_URL,
  AUDIT_URL,
  SYSLOGAI_URL,
  HELPDESK_URL,
  CERT_URL,
  NMSMESSAGE_URL,
  NMSChatBot_URL,
  SMS_URL
} from "../url/baseUrl";
import { MakeApiRequest } from "./axiosRequest";
import axios from "axios"; // without token

//port 8020
export const AuthAxios = async (ENDPOINT, method, payload, id) => {
  let apiResult;
  const url = AUTH_URL + ENDPOINT;
  if (method === "get") {
    apiResult = await axios.get(url);
  } else if (method === "post") {
    apiResult = await axios.post(url, payload);
  } else {
    throw new Error(`Unsupported HTTP method: ${method}`);
  }
  return apiResult;
};

// export const AuthAxios2 = async (ENDPOINT, method, payload, id) => {
//   let apiResult;
//   const url = AUTH_URL + ENDPOINT;
//   if (method === "get") {
//     apiResult = await axios.get(url);
//   } else if (method === "post") {
//     apiResult = await axios.post(url, payload);
//   } else {
//     throw new Error(`Unsupported HTTP method: ${method}`);
//   }

//   return apiResult;
// };
export const AuthAxios2 = async (ENDPOINT, method, payload, id) => {
  const url = AUTH_URL + ENDPOINT;
  
  // We use the generic axios() method which accepts a config object
  // This handles 'get', 'post', 'put', 'delete', etc., dynamically
  const response = await axios({
    url: url,
    method: method.toLowerCase(),
    data: method.toLowerCase() === "get" ? null : payload
  });

  return response;
};
//port  8012 - without token
export const InventAxios = async (ENDPOINT, method, payload, id) => {
  let apiResult;
  const url = INVENTORY_URL + ENDPOINT;

  if (method === "get") {
    apiResult = await axios.get(url);
  } else if (method === "post") {
    apiResult = await axios.post(url, payload);
  } else {
    throw new Error(`Unsupported HTTP method: ${method}`);
  }
  return apiResult;
};

//port  8012  with token
export const InventoryAxios = async (ENDPOINT, method, payload, id) => {
  const url = INVENTORY_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

export const LogoutAxios = async (ENDPOINT, method, payload, id) => {
  const url = AUTH_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

// port 8006
export const FaultAxios = async (ENDPOINT, method, payload, id) => {
  const url = FAULT_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

//port 8013
export const TopologyAxios = async (ENDPOINT, method, payload, id) => {
  const url = TOPOLOGY_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

//port 8009
export const PerformanceAxios = async (ENDPOINT, method, payload, id) => {
  const url = PERFORMANCE_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

//port
//configuration
export const ConfigurationAxios = async (ENDPOINT, method, payload, id) => {
  const url = CONFIG_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

//PORT 8010
export const SecurityAxios = async (ENDPOINT, method, payload, id) => {
  const url = SECURITY_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

export const DbAxios = async (ENDPOINT, method, payload, id) => {
  const url = DB_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};
// PORT 8008
export const AuditManagementAxios = async (ENDPOINT, method, payload, id) => {
  const url = AUDIT_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};
//Help desk
// export const HelpDeskAxios = async (ENDPOINT, method, payload, id) => {
//   const url = HELPDESK_URL + ENDPOINT;
//   return MakeApiRequest(url, method, payload, id);
// };
export const HelpDeskAxios = async (ENDPOINT, method, payload, id, dynamicHost) => {
  const protocol = import.meta.env.PROD ? `https://${dynamicHost}` : `http://${dynamicHost}`
  // If a dynamic host IP is passed, use it. Otherwise, fall back to default HELPDESK_URL
  const baseUrl = dynamicHost ? protocol : HELPDESK_URL;
  
  const url = baseUrl + ENDPOINT;
  return MakeApiRequest(url, method, payload, id,dynamicHost);
};
// Add dynamicHost as a parameter
export const CertAxios = async (ENDPOINT, method, payload, id, dynamicHost) => {
  const protocol = import.meta.env.PROD ? `https://${dynamicHost}` : `http://${dynamicHost}`
  
  // Use the passed dynamicHost parameter here!
  const baseUrl = dynamicHost ? protocol : CERT_URL;
  
  const url = baseUrl + ENDPOINT;
  
  // Pass it through to MakeApiRequest
  return MakeApiRequest(url, method, payload, id, dynamicHost);
};


// Port 8050 - SyslogAI
export const SyslogAiAxios = async (ENDPOINT, method, payload, id, response) => {
  const url = SYSLOGAI_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id, response);
};
 
///nms messaging 8014
export const NmsMessageAxios = async (ENDPOINT, method, payload, id) => {
  const url = NMSMESSAGE_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};
export const NmsChatBotAxios = async (ENDPOINT, method, payload, id) => {
  const url = NMSChatBot_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};
export const SmsAxios = async (ENDPOINT, method, payload, id) => {
  const url = SMS_URL + ENDPOINT;
  return MakeApiRequest(url, method, payload, id);
};

