/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : api
   File Name                : axiosRequest.js
   Author                   : SURAJ - VIPL
   Package                  : src\RestAPI\api\axiosRequest.js
   Purpose                  : The purpose is to show the entire IAF-NMS Axios Api Calling request methodology from this file 
   Created Date             : 17-02-2026
 *******************************************************************************************/
import axios from "axios";
export const MakeApiRequest = async (Url, method = "get", data = null) => {
  const AxiosInstance = axios.create();

  let apiResult;
  const token = sessionStorage.getItem("authToken");

  AxiosInstance.interceptors.request.use(
    (config) => {
      if (token !== "") {
        config.headers.Authorization = `Bearer ${token}`; // Add token to headers
        return config;
      }
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Interceptor to handle 401 errors (Unauthorized)
  AxiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response?.status === 401) {
        console.log("logout");
        return Promise.reject(error);
      }
      return Promise.reject(error);
    }
  );

  if (method === "get") {
    apiResult = await AxiosInstance.get(Url);
  } else if (method === "getBlob") {
    apiResult = await AxiosInstance.get(Url, {responseType: 'blob'});
  } else if (method === "post") {
    apiResult = await AxiosInstance.post(Url, data);
  } else if (method === "put") {
    apiResult = await AxiosInstance.put(Url, data);
  } else if (method === "delete") {
    apiResult = await AxiosInstance.delete(Url);
  } else {
    throw new Error(`Unsupported HTTP method: ${method}`);
  }
  return apiResult; // Return the data directly
};
