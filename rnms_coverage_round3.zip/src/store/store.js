/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Store
   File Name                : store.js
   Author                   : ANKITHA - VIPL
   Package                  : src\store\store.js
   Purpose                  : Configures and exports the Redux store, integrating reducers, 
                              and providing the centralized state container for the application.
   Created Date             : 17-04-2026
***********************************************************************************************/

import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import nodeDetailsSlice from "./features/nodeDetailsSlice";
import userSlice from "./features/LoggedInUser/userSlice";
import topologyNodesslice from "./features/Topology/topologyNodesslice";
import leftSidebarSlice from "./features/LeftSideBar/leftSideBar";
import toolTipOptionsSlice from "./features/Tooltip/toolTipSlice";
import socketMiddleware from "./socket/socketMiddleware";
import faultAlarmSlice from "./features/Fault/alarmSlice";
import portStatusSlice from "./features/PortStatus/portStatusSlice";
import inventoryReducer from "./features/Inventory/inventorySlice";
import linkSliceReducer from "./features/LinkStatus/linkSlice";
import realTimeSystemSlice from "./features/Reports/PerformanceReports/realTimeSystemSlice";
import realTimeInterfaceLevelSlice from "./features/Reports/PerformanceReports/realTimeInterfaceLevelSlice";
import pingReducer from "./features/Ping/pingSlice";
import delayAndResponseSlice from "./features/Reports/PerformanceReports/delayAndResponseSlice";
import syslogReducer from "./features/SyslogAI/syslogSlice";
import cnmsReducer from "./features/Cnms/cnmsSlice";
import remoteRepDetailsReducer from "./features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import rnmsTerminalsReducers from "./features/Cnms/remoteRepDetails/rnmsTerminalTypes";
import cnmsStatusReducer from "./features/LinkStatus/cnmsStatusSlice";
import authReducer from "@/store/features/Logout/authSlice";
import getAllUsersReducer from "./features/Cnms/GetAllUsers/getAllUsersSlice";
import terminalTypeReducer from "./features/Cnms/remoteRepDetails/terminalTypeSlice";
import performanceReducer from "./features/Performance/performanceSlice";
import syslogSocketMiddleware from "./socket/syslogSocketMiddleware";
import getAllGroupsReducers from "./features/Cnms/GetAllGroups/groupSlice";
import siteDiscoveryReducer from "./features/Cnms/CnmsDiscovery/siteDiscoverySlice";
import mapViewSlice from "./features/Cnms/mapViewSlice";
import siteSummaryReducer from "./features/Cnms/SiteSummary/siteSummarySlice";
import cnmsActiveStatusReducer from "./features/Cnms/remoteRepDetails/cnmsActiveStatusSlice";
import chatReducer from "./features/Chats/chatSlice";
import certificateExportReducer from "./features/X509Certificate/certificateExportSlice";

import chatSocketMiddleware from "./socket/chatSocketMiddleware";

const persistConfig = {
  key: "root", // Key for the persisted state in storage
  storage, // The storage engine to use
  whitelist: [],
};

const rootReducer = combineReducers({
  nodeDetails: nodeDetailsSlice,
  userSlice: userSlice,
  topologySlice: topologyNodesslice,
  alarmSlice: faultAlarmSlice,
  leftSidebarSlice: leftSidebarSlice,
  toolTipOptionsSlice: toolTipOptionsSlice,
  portStatusSlice: portStatusSlice,
  inventory: inventoryReducer,
  linkSlice: linkSliceReducer,
  ping: pingReducer,
  realTimeSystemSlice: realTimeSystemSlice,
  realTimeInterfaceLevelSlice: realTimeInterfaceLevelSlice,
  delayAndResponseSlice: delayAndResponseSlice,
  syslog: syslogReducer,
  performance: performanceReducer,
  cnmsConfig: cnmsReducer,
  remoteRepDetails: remoteRepDetailsReducer,
  rnmsTerminals: rnmsTerminalsReducers,
  cnmsStatus: cnmsStatusReducer,
  getAllUsers: getAllUsersReducer,
  terminalTypes: terminalTypeReducer,
  groups: getAllGroupsReducers,
  // rnmsTerminals: rnmsTerminalsReducers,
  // cnmsStatus: cnmsStatusReducer,
  // getAllUsers: getAllUsersReducer,
  // terminalTypes: terminalTypeReducer,
  siteDiscovery: siteDiscoveryReducer,
  mapViewSlice: mapViewSlice,
  siteSummary: siteSummaryReducer,
  cnmsActiveStatus: cnmsActiveStatusReducer,
  auth: authReducer,
  chat: chatReducer,
  certificateExport: certificateExportReducer,
});

const resettableRootReducer = (state, action) => {
  if (action.type === "USER_LOGOUT") {
    // Clear storage for redux-persist
    storage.removeItem("persist:root");
    state = undefined; // This resets all slices to initialState
  }
  return rootReducer(state, action);
};

const persistedReducer = persistReducer(persistConfig, resettableRootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [
          "persist/PERSIST",
          "persist/REHYDRATE",
          "persist/REGISTER",
        ],
      },
    }).concat(
      socketMiddleware(),
      syslogSocketMiddleware(),
      chatSocketMiddleware()
    ),
});

export const persistor = persistStore(store);
