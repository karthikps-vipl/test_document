import { filterSwitchPorts } from "@/utility/portFilterUtils";
import { createSlice } from "@reduxjs/toolkit";
const inventorySlice = createSlice({
  name: "inventory",
  initialState: {
    segments: [],
    resources: [],
    realtimePerformance: {},
    activeRealtimeKeys: {},
    isTableMaximized: false,
    isAlarmDrawer: false,
    activeRealtimeConfig: null,
    treeClickedItem: null,
    nePollingInfo: {
      id: null,
      imResourceInfo: null,
      isDefaultPolling: true,
      isReachable: true,
      maxSeverity: 0, // Initial value
      pollingInterval: 10,
      siteId: null,
    },
  },
  reducers: {
    setSegments: (state, action) => {
      state.segments = action.payload.segments;

      // state.resources = (action.payload.resources || []).map((resource) => {
      //   if (
      //     resource.resourceId === "MCT_EP_SWITCH-24PORT" &&
      //     resource.lstPortInfoDtl
      //   ) {
      //     return {
      //       ...resource,
      //       lstPortInfoDtl: filterSwitchPorts(resource.lstPortInfoDtl),
      //     };
      //   }
      //   return resource;
      // });
    },
    setResources: (state, action) => {
      state.resources = (action.payload.resources || []).map((resource) => {
        // Check if it's the specific switch and has port details
        if (
          resource.resourceId === "MCT_EP_SWITCH-24PORT" &&
          resource.lstPortInfoDtl
        ) {
          // 1. First, filter the ports (keep your existing filter logic here)
          // Assuming filterSwitchPorts exists and returns an array
          const filteredPorts = filterSwitchPorts(resource.lstPortInfoDtl);

          // 2. Then, sort the filtered ports by ifindex
          const sortedPorts = [...filteredPorts].sort(
            (a, b) => a.ifindex - b.ifindex
          );

          return {
            ...resource,
            lstPortInfoDtl: sortedPorts,
          };
        }
        return resource;
      });
    },

    updateMaxSeverity: (state, action) => {
      // action.payload will be the severity number from the socket
      state.nePollingInfo.maxSeverity = action.payload;
    },

    // If you need to set the whole object at once later
    setNePollingInfo: (state, action) => {
      state.nePollingInfo = action.payload;
    },
    toggleTableMaximize: (state) => {
      state.isTableMaximized = !state.isTableMaximized;
    },
    toggleAlarmDrawer: (state) => {
      state.isAlarmDrawer = !state.isAlarmDrawer;
    },
    setTableMaximized: (state, action) => {
      state.isTableMaximized = action.payload;
    },
    setRealTimePerfPoint: (state, action) => {
      const { resourceId, paramId, point } = action.payload;
      const key = `${String(resourceId)}_${String(paramId)}`;

      if (!state.realtimePerformance[key]) {
        state.realtimePerformance[key] = [];
      }

      state.realtimePerformance[key].push({
        value: Number(point.value ?? 0),
        timestamp: point.timestamp
          ? new Date(point.timestamp).toISOString()
          : new Date().toISOString(),
      });

      if (state.realtimePerformance[key].length > 300) {
        state.realtimePerformance[key].shift();
      }
    },

    clearRealTimeStream: (state, action) => {
      const key = action.payload;
      delete state.realtimePerformance[key];
      delete state.activeRealtimeKeys[key];
    },

    markRealtimeActive: (state, action) => {
      const key = action.payload;
      state.activeRealtimeKeys[key] = true;
    },

    markRealtimeInactive: (state, action) => {
      const key = action.payload;
      delete state.activeRealtimeKeys[key];
    },
    startRealTimeSession: (state, action) => {
      state.activeRealtimeConfig = action.payload;
    },
    clearRealTimeSession: (state) => {
      state.activeRealtimeConfig = null;
    },
    updateResourceStatus: (state, action) => {
      const { resourceId, isDiscovered, isMaintainance, lstPortInfoDtl } =
        action.payload;

      const index = state.resources.findIndex(
        (res) => res.resourceId === resourceId
      );

      if (index !== -1) {
        state.resources[index] = {
          ...state.resources[index],
          isDiscovered: isDiscovered,
          isMaintainance: isMaintainance,
          lstPortInfoDtl: lstPortInfoDtl,
        };
      }
    },
    updateDiscoveredDeviceStatusFabric: (state, action) => {
      const updatedDevices = action.payload;

      if (Array.isArray(updatedDevices)) {
        updatedDevices.forEach((updatedItem) => {
          const targetId = updatedItem.resourceId;

          // In your inventory slice, we look through the 'resources' array
          const index = state.resources.findIndex(
            (res) => res.resourceId === targetId
          );

          if (index !== -1) {
            state.resources[index] = {
              ...state.resources[index],
              isDiscovered: updatedItem.isDiscovered,
              isMaintainance: updatedItem.isMaintainance,
              status: updatedItem.status,
              resourceIp: updatedItem.resourceIp,
              // Add the port details here
              lstPortInfoDtl: updatedItem.lstPortInfoDtl || [],
            };
          }
        });
      }
    },
    updateInventoryDetails: (state, action) => {
      const updatedItem = action.payload;

      // Validate the API response
      if (!updatedItem || !updatedItem.resourceId) {
        console.warn("Invalid inventory update payload:", updatedItem);
        return;
      }

      // Find the existing resource
      const index = state.resources.findIndex(
        (res) => res.resourceId === updatedItem.resourceId
      );

      if (index !== -1) {
        // Update only the required fields.
        // All other existing resource properties are preserved.
        state.resources[index] = {
          ...state.resources[index],
          firmwareVersion:
            updatedItem.firmwareVersion ??
            state.resources[index].firmwareVersion,

          resourceSerialno:
            updatedItem.resourceSerialno ??
            state.resources[index].resourceSerialno,
          resourceDesc:
            updatedItem.resourceDesc ?? state.resources[index].resourceDesc,
        };

        console.log("Inventory updated successfully:", state.resources[index]);
      } else {
        console.warn(
          "Resource not found in inventory:",
          updatedItem.resourceId
        );
      }
    },
    updateAddDeviceIP: (state, action) => {
      const updatedItem = action.payload;

      // Validate the API response
      if (!updatedItem || !updatedItem.resourceId) {
        console.warn("Invalid inventory update payload:", updatedItem);
        return;
      }

      // Find the existing resource
      const index = state.resources.findIndex(
        (res) => res.resourceId === updatedItem.resourceId
      );

      if (index !== -1) {
        // Update only the required fields.
        // All other existing resource properties are preserved.
        state.resources[index] = {
          ...state.resources[index],
          resourceIp:
            updatedItem.resourceIp ??
            state.resources[index].resourceIp,
        };

        console.log("Inventory updated successfully:", state.resources[index]);
      } else {
        console.warn(
          "Resource not found in inventory:",
          updatedItem.resourceId
        );
      }
    },
    // reducer to remove ip from old device and make the device discovered false
    updateResourceIp: (state, action) => {
      const responseData = action.payload;

      if (!Array.isArray(responseData) || responseData.length === 0) {
        console.warn("Payload is not a valid array or is empty.");
        return state;
      }

      return {
        ...state,
        resources: state.resources.map((node) => {
          const item = responseData.find(
            (dataItem) => dataItem.resourceIp === node.resourceIp
          );

          if (!item) return node;

          return {
            ...node,
            resourceIp: null,
            isDiscovered: false,
            resourceStateName: "managed",
            // maxSeverity: -1,
          };
        }),
      };
    },
    updatePortStatusFromSocket: (state, action) => {
      const { resourceId, wsData } = action.payload;

      // 1. Find the specific device in the inventory
      const resource = state.resources.find(
        (res) => res.resourceId === resourceId
      );

      if (resource?.lstPortInfoDtl) {
        // 2. Find the specific port within the device's original port list
        const portIndex = resource.lstPortInfoDtl.findIndex(
          (port) => port.ifindex === wsData.ifindex
        );

        if (portIndex !== -1) {
          // 3. Update ONLY the properties of that specific port
          // This uses Immer (built into Redux Toolkit) to mutate the state safely
          resource.lstPortInfoDtl[portIndex] = {
            ...resource.lstPortInfoDtl[portIndex],
            ...wsData,
          };

          console.log(
            `Port ${wsData.ifindex} on ${resourceId} updated successfully.`
          );
        }
      }
    },
    // updatePortStatusFromSocket: (state, action) => {
    //   // Destructure the payload to get both the single update and the list
    //   const { wsData, filteredPorts } = action.payload;

    //   // 1. Find the resource index in the main state
    //   const resourceIndex = state.resources.findIndex(
    //     (res) => res.resourceId === wsData.resourceId
    //   );

    //   if (resourceIndex !== -1) {
    //     // 2. Find the specific port within the PROVIDED filtered list
    //     const portIndex = filteredPorts.findIndex(
    //       (port) => port.ifindex === wsData.ifindex
    //     );

    //     if (portIndex !== -1) {
    //       // 3. Update the port inside the filtered list
    //       filteredPorts[portIndex] = {
    //         ...filteredPorts[portIndex],
    //         ...wsData
    //       };

    //       // 4. Replace the old lstPortInfoDtl with this newly updated filtered list
    //       state.resources[resourceIndex].lstPortInfoDtl = filteredPorts;

    //       console.log(`Port123 ${wsData.ifindex} updated and state synchronized.`);
    //     }
    //   }
    // },
    updateResourceFromSocket: (state, action) => {
      const socketData = action.payload;
      const resourceInfo = socketData?.imResourceInfo;

      if (!resourceInfo?.resourceId) return;

      const targetId = resourceInfo.resourceId;
      const existingResourceIndex = state.resources.findIndex(
        (res) => res.resourceId === targetId
      );

      if (existingResourceIndex !== -1) {
        const existingResource = state.resources[existingResourceIndex];
        const calculatedStatus = socketData.isReachable ? "Success" : "Failed";

        // 1. Construct the nePollingInfo object
        // We take the existing info (to keep id, siteId, etc.)
        // and overwrite/add the new values from the root of socketData
        const updatedNePollingInfo = {
          ...(existingResource.nePollingInfo || {}), // Keep existing properties like id, siteId, pollingInterval
          ...socketData.nePollingInfo, // Overwrite if nePollingInfo exists in socket
          isReachable: socketData.isReachable, // Explicitly map from root
          maxSeverity: socketData.maxSeverity, // Explicitly map from root
          isDefaultPolling: socketData.isDefaultPolling, // Map from root
          pollingInterval: socketData.pollingInterval, // Map from root
        };

        // 2. Update the state
        state.resources[existingResourceIndex] = {
          ...existingResource,
          isDiscovered:
            resourceInfo.isDiscovered ?? existingResource.isDiscovered,
          isMaintainance:
            resourceInfo.isMaintainance ?? existingResource.isMaintainance,
          status: calculatedStatus,
          resourceIp: resourceInfo.resourceIp || existingResource.resourceIp,
          nePollingInfo: updatedNePollingInfo, // Assign the newly constructed object
        };
      }
    },
    setTreeClickedItem: (state, action) => {
      state.treeClickedItem = action.payload;
    },
  },
});

export const {
  setInventoryData,
  updateResourceStatus,
  setRealTimePerfPoint,
  toggleTableMaximize,
  setTableMaximized,
  clearRealTimeStream,
  markRealtimeActive,
  markRealtimeInactive,
  startRealTimeSession,
  clearRealTimeSession,
  updateResourceFromSocket,
  setTreeClickedItem,
  updatePortStatusFromSocket,
  updateMaxSeverity,
  updateDiscoveredDeviceStatusFabric,
  setSegments,
  setResources,
  updateResourceIp,
  toggleAlarmDrawer,
  updateInventoryDetails,
  updateAddDeviceIP,
} = inventorySlice.actions;
export default inventorySlice.reducer;
