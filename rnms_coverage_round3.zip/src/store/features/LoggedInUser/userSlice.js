/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : LoggedInUser 
   File Name                : userSlice.js
   Author                   : ANKITHA - VIPL
   Package                  : src\store\features\LoggedInUser\userSlice.js    
   Purpose                  : Manages global Redux state for user authentication and profile data.
   Created Date             : 27-03-2026
 ***********************************************************************************************/
import { createSelector, createSlice } from "@reduxjs/toolkit";

const initialState = {
  userDetails: null,
  isUserLoggedIn: false,
  privileges: [],
  devicePrivileges: null,
  privilegesKeysSet: null,
  isEmailUpdateRequired: false,
  isReadOnlyMode: false,
};

// this object is added from ui to render create snmp tab in right side bar
const snmp_config_not_from_db = {
  cnms: true,
  id: 7022,
  key: "snmp_config_not_from_db",
  level: 0,
  parent: 701,
  privilegeId: 7022,
  privilegeName: "Create snmp config",
  rnms: true,
};

const userSlice = createSlice({
  name: "userSlice",
  initialState,
  reducers: {
    setLoggedInUserDetails: (state, action) => {
      const { res, devicePrivileges } = action.payload;
      state.userDetails = res;

      state.devicePrivileges = devicePrivileges;

      // added snmp config tab here
      if (window.isSuperAdmin) {
        state?.userDetails?.data?.group?.privileges?.push(
          snmp_config_not_from_db
        );
      }
    },
    setIsUserLoggedIn: (state, action) => {
      state.isUserLoggedIn = action.payload;
    },
    setPrivilege: (state, action) => {
      state.privilege = action.payload;
    },
    setPrivilegesKeysSet: (state, action) => {
      state.privilegesKeysSet = action.payload;
    },
    setRequiresEmailUpdate: (state, action) => {
      state.isEmailUpdateRequired = action.payload;
    },
    resetEmailUpdateRequirement: (state) => {
      state.isEmailUpdateRequired = false;
    },
    setReadOnlyMode: (state, action) => {
      state.isReadOnlyMode = action.payload;
    },
    
  },
});

export const {
  setLoggedInUserDetails,
  setIsUserLoggedIn,
  setPrivilege,
  setPrivilegesKeysSet,
  setRequiresEmailUpdate, resetEmailUpdateRequirement ,setReadOnlyMode
} = userSlice.actions;
export default userSlice.reducer;

// This selector converts the array to a Set ONLY when the component asks for it.
// It is extremely fast and cached (memoized).
export const selectPrivilegesSet = createSelector(
  (state) => state.userSlice.privilegesKeysSet,
  (privilegesArray) => new Set(privilegesArray)
);
