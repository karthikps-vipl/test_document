/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Fault Management
   File Name                : alarmSlice.js
   Author                   : SURAJ - VIPL
   Package                  : src\store\features\Fault\alarmSlice.js
   Purpose                  : Manages the global Redux state and logic for all Alarm-related data.
   Created Date             : 16-04-2026
 ***********************************************************************************************/

import { createSlice } from "@reduxjs/toolkit";
// import showToast from 'components/ToastPart/alarmToast';
// import MajorSound from 'AudioWave/MAJOR.wav';
// import MinorSound from 'AudioWave/MINOR.wav';
// import CriticalSound from 'AudioWave/WARNING.wav';
// import { Critical } from 'assets/svgs';
// import { NormalSvg } from 'assets/svgs';
// import { WarningSVG } from 'assets/svgs';
// import { MinorsSvg } from 'assets/svgs';
// import { ErrorSvg } from 'assets/svgs';

const initialState = {
  alarmCount: 1,
  onAlarmPage: false, // Flag to indicate if the user is on the /cnms/alarm route
  newAlaram: null,
  deleteId: null,
  updateAlaram: null,
  severityData: null,
  alarmNotification: true,
  notificationDisabled: false,
  totalAlarmCount: null,
  popUpData: [],
  fetchAllAlarm: [],
  badgeCount: [],
  cnmsBadgeCount: [],
  severityDataOri: [0, 0, 0],
  // alarmNotificationSettings: {
  //   0: {
  //     audioFileName: "WARNING.wav",
  //     isMute: false,
  //     isPopup: true,
  //   },
  //   1: {
  //     audioFileName: "MINOR.wav",
  //     isMute: false,
  //     isPopup: true,
  //   },
  //   2: {
  //     audioFileName: "MAJOR.wav",
  //     isMute: false,
  //     isPopup: true,
  //   },
  // },
  alarmNotificationSettings: null,
};

const alarmSlice = createSlice({
  name: "alarmSlice",
  initialState,
  reducers: {
    
    decrementAlarmCount: (state) => {
      if (!state.onAlarmPage) {
        //Only decrement if NOT on alarm page
        state.alarmCount -= 1;
      }
    },
    setAlarmSeverityCount: (state, action) => {
      console.log(action.payload, "action.payload");
      return {
        ...state,
        severityData: action.payload,
      };
    },
    setSeverityData: (state, action) => {
      state.severityDataOri = action.payload;
    },

    updateSingleAlarm: (state, action) => {
      const updatedAlarm = action.payload;
      const existingAlarms = [...state.fetchAllAlarm];

      // 1. Find the index by a combination of Name AND Device/IP
      // This ensures "Firmware Change" on Device A is treated differently than "Firmware Change" on Device B
      // But "Firmware Change" on Device A received twice will increment the same row.
      const index = existingAlarms.findIndex(
        (a) =>
          a.alarmName?.trim().toLowerCase() ===
            updatedAlarm.alarmName?.trim().toLowerCase() &&
          a.resourceIp?.trim().toLowerCase() ===
            updatedAlarm.resourceIp?.trim().toLowerCase()
      );

      if (updatedAlarm.alarmState === 0) {
        // Remove alarm if state is 0
        state.fetchAllAlarm = existingAlarms.filter((_, i) => i !== index);
      } else if (index === -1) {
        // NEW ALARM: Add to top
        // Ensure we initialize alarmCount to 1 if it doesn't exist
        state.fetchAllAlarm = [updatedAlarm, ...existingAlarms];
      } else {
        existingAlarms.splice(index, 1);
       incrementAlarmCount: (state) => {
      if (!state.onAlarmPage) {
        //Only increment if NOT on alarm page
        state.alarmCount += 1;
        console.log(state.alarmCount, "state.alarmCount");
      }
    }, state.fetchAllAlarm = [updatedAlarm, ...existingAlarms];
      }

      // 2. Recalculate severity counts
      const counts = { 0: 0, 1: 0, 2: 0 };
      state.fetchAllAlarm.forEach((alarm) => {
        if (counts.hasOwnProperty(alarm.severity)) {
          counts[alarm.severity]++;
        }
      });
      state.severityData = counts;
    },
    setNewAlarm: (state, action) => {
      state.updateAlaram = action.payload;
    },
    clearUpdateAlarm: (state) => {
      state.updateAlaram = null; // This "consumes" the alarm so the toast only fires once
    },
    // setBadgeCount: (state, action) => {
    //   const rawAlarms = action.payload;

    //   // 1. Group counts by resourceId and track which severity level is active
    //   const resourceMap = rawAlarms.reduce((acc, alarm) => {
    //     const { resourceId, severity } = alarm;

    //     if (!acc[resourceId]) {
    //       acc[resourceId] = { major: 0, minor: 0, warning: 0 };
    //     }

    //     // Using your numeric logic: 2=major, 1=minor, 0=warning
    //     if (severity === 2) acc[resourceId].major++;
    //     else if (severity === 1) acc[resourceId].minor++;
    //     else if (severity === 0) acc[resourceId].warning++;

    //     return acc;
    //   }, {});

    //   const finalBadgeCounts = [];

    //   // 2. Transform the map into the array format with severity labels
    //   Object.keys(resourceMap).forEach((resId) => {
    //     const counts = resourceMap[resId];
    //     let countToDisplay = 0;
    //     let activeSeverity = ""; // <--- NEW: Track the string label

    //     // Apply priority logic: Major (2) -> Minor (1) -> Warning (0)
    //     if (counts.major > 0) {
    //       countToDisplay = counts.major;
    //       activeSeverity = "major"; // <--- Set the label
    //     } else if (counts.minor > 0) {
    //       countToDisplay = counts.minor;
    //       activeSeverity = "minor"; // <--- Set the label
    //     } else if (counts.warning > 0) {
    //       countToDisplay = counts.warning;
    //       activeSeverity = "warning"; // <--- Set the label
    //     }

    //     if (countToDisplay > 0) {
    //       finalBadgeCounts.push({
    //         id: resId,
    //         badgeCount: countToDisplay,
    //         severity: activeSeverity, // <--- IMPORTANT: Passing this to the component
    //       });
    //     }
    //   });

    //   state.badgeCount = finalBadgeCounts;
    // },
    setBadgeCount: (state, action) => {
      const rawAlarms = action.payload || [];
    
      const resourceMap = rawAlarms.reduce((acc, alarm) => {
        const { resourceId, severity } = alarm;
    
        if (!acc[resourceId]) {
          acc[resourceId] = {
            major: 0,
            minor: 0,
            warning: 0,
          };
        }
    
        // 2 = Major, 1 = Minor, 0 = Warning
        if (severity === 2) {
          acc[resourceId].major++;
        } else if (severity === 1) {
          acc[resourceId].minor++;
        } else if (severity === 0) {
          acc[resourceId].warning++;
        }
    
        return acc;
      }, {});
    
      // Store all three severity counts
      state.badgeCount = Object.entries(resourceMap).map(
        ([resId, counts]) => ({
          id: resId,
          major: counts.major,
          minor: counts.minor,
          warning: counts.warning,
        })
      );
    },
    setCnmsBadgeCount: (state, action) => {
      const rawAlarms = action.payload || [];
    
      const siteMap = rawAlarms.reduce((acc, alarm) => {
        const {
          siteId,
          resourceId,
          severity,
          alarmCount
        } = alarm;
    
        // Ignore invalid IDs
        if (
          !siteId ||
          !resourceId ||
          String(resourceId).trim().toUpperCase() === "NA"
        ) {
          return acc;
        }
    
        // Create a unique combination of siteId + resourceId
        const key = `${siteId}_${resourceId}`;
    
        if (!acc[key]) {
          acc[key] = {
            siteId,
            resourceId,
            major: 0,
            minor: 0,
            warning: 0,
          };
        }
    
        // Use alarmCount instead of incrementing by 1
        const count = Number(alarmCount) || 0;
    
        // 2 = Major, 1 = Minor, 0 = Warning
        if (severity === 2) {
          acc[key].major += count;
        } else if (severity === 1) {
          acc[key].minor += count;
        } else if (severity === 0) {
          acc[key].warning += count;
        }
    
        return acc;
      }, {});
    
      state.cnmsBadgeCount = Object.values(siteMap);
    },
    
    updateSingleBadge: (state, action) => {
      const alarm = action.payload;
      const { resourceId, severity } = alarm;
      
      // 1. Map numeric severity to labels
      const severityMap = { 2: 'major', 1: 'minor', 0: 'warning' };
      const incomingSeverityLabel = severityMap[severity] ?? 'warning';
  
      // 2. Find if this resource already has a badge
      const existingBadge = state.badgeCount.find(b => b.id === resourceId);
  
      if (existingBadge) {
        // --- INCREMENT LOGIC ---
        existingBadge.badgeCount += 1;
  
        // --- PRIORITY LOGIC (Matching your setBadgeCount logic) ---
        // If the incoming alarm is MORE severe than the current badge, upgrade the badge
        const severityOrder = { 'major': 3, 'minor': 2, 'warning': 1 };
        const currentSeverityRank = severityOrder[existingBadge.severity] || 0;
        const incomingSeverityRank = severityOrder[incomingSeverityLabel] || 0;
  
        if (incomingSeverityRank > currentSeverityRank) {
          existingBadge.severity = incomingSeverityLabel;
        }
      } else {
        // 3. If the resource is new, create the badge
        state.badgeCount.push({
          id: resourceId,
          badgeCount: 1, // Start at 1 because this is the first alarm we see
          severity: incomingSeverityLabel,
        });
      }
    },
    
    setAlarmNotificationSettings: (state, action) => {
      const settings = action.payload;
    
      state.alarmNotificationSettings = {
        ...state.alarmNotificationSettings,
        ...settings,
      };
    },
    // setBadgeCount: (state, action) => {
    //   const alarms = action.payload;

    //   const resourceMap = {};

    //   for (let i = 0; i < alarms.length; i++) {
    //     const { resourceId, severity } = alarms[i];

    //     let resource = resourceMap[resourceId];

    //     if (!resource) {
    //       resource = resourceMap[resourceId] = {
    //         major: 0,
    //         minor: 0,
    //         warning: 0,
    //       };
    //     }

    //     if (severity === 2) resource.major++;
    //     else if (severity === 1) resource.minor++;
    //     else resource.warning++;
    //   }

    //   const badgeMap = {};

    //   for (const id in resourceMap) {
    //     const c = resourceMap[id];

    //     if (c.major) {
    //       badgeMap[id] = {
    //         badgeCount: c.major,
    //         severity: "major",
    //       };
    //     } else if (c.minor) {
    //       badgeMap[id] = {
    //         badgeCount: c.minor,
    //         severity: "minor",
    //       };
    //     } else if (c.warning) {
    //       badgeMap[id] = {
    //         badgeCount: c.warning,
    //         severity: "warning",
    //       };
    //     }
    //   }

    //   state.badgeCount = badgeMap;
    // },
    setActiveAllAlarms: (state, action) => {
      console.log(action.payload, "fetchAllAlarm");
      return {
        ...state,
        fetchAllAlarm: action.payload,
      };
    },

    // resetAlarmCount: (state) => {
    //   state.alarmCount = 0;
    // },
    // setAlarmPage: (state) => {
    //   // Action to set onAlarmPage to true
    //   state.onAlarmPage = true;
    // },
    // leaveAlarmPage: (state) => {
    //   // Action to set onAlarmPage to false
    //   state.onAlarmPage = false;
    // },

    // setPopUpMuteData: (state, action) => {
    //   console.log('Action payload in PopUp:', action.payload);
    //   return {
    //     ...state,
    //     popUpData: action.payload || [],
    //   };
    // },

    // setPopUpMuteUpdate: (state, action) => {
    //   const { severity, mute, popUp } = action.payload;
    //   console.log(severity, mute, popUp, 'whfwggfs');
    //   console.log('Action payload in PopUp:', action.payload);

    //   return {
    //     ...state,
    //     popUpData: state.popUpData.map((item) => {
    //       if (item.severity == severity) {
    //         console.log(severity, item.severity, 'KUMARSEVREITY');
    //         return {
    //           ...item,
    //           mute: mute,
    //           popUp: popUp,
    //         };
    //       } else {
    //         return item;
    //       }
    //     }),
    //   };
    // },

    // setnewAlram: (state, action) => {
    //   console.log(action.payload, 'lklklklklklk');

    //   // state.newAlaram = action.payload;
    //   // let data = state.newAlaram;
    //   // console.log(data, 'TestingData');

    //   const updatedState = {
    //     ...state, // Copy the existing state
    //     newAlaram: action.payload, // Update the newAlaram property
    //   };

    //   console.log(updatedState?.newAlaram, 'updatedState');
    //   const SendedData = updatedState?.newAlaram;
    //   console.log(SendedData, 'SendedData');

    //   // state.newAlaram = SendedData;

    //   // alert('alarm inside slice setnewAlram')
    //   // for Here to --------------------------------------------------------------------
    //   const severity = state.popUpData[0]?.severity;
    //   // const mute = state.popUpData[0].mute;
    //   // const popUp = state.popUpData[0].popUp;
    //   const actionSeverity = action.payload.severity;
    //   const actionWorkflow = action.payload?.workflowstate;
    //   const actionAlarmState = action.payload?.alarmState;
    //   const actionAlarmName = action.payload?.alarmName;
    //   const actionNodeName =
    //     action.payload.resourceDetails?.nodeDetails?.name ||
    //     action.payload.nodeDetails?.name ||
    //     ' N/A';
    //   const actionDeviceName =
    //     action.payload?.resourceDetails?.resourceName || 'Site Alarm';
    //   //       if(action.payload.stateAlarm === true){
    //   //         // const actionDeviceName = action.payload?.resourceDetails?.resourceName;
    //   //          actionNodeName = action.payload.nodeDetails?.name;
    //   //          console.log(actionNodeName, "HelloKumarData")
    //   //         return actionNodeName

    //   //       }else if(action.payload.deviceAlarm === true){
    //   //          actionDeviceName = action.payload?.resourceDetails?.resourceName;
    //   //          actionNodeName = action.payload.resourceDetails?.nodeDetails?.name;

    //   // console.log(actionDeviceName,actionNodeName, "HelloKumarData")
    //   //         return{
    //   //           actionNodeName,actionDeviceName
    //   //         }

    //   //       }
    //   // const soundFile = MajorSound;
    //   // alert(severity,actionSeverity,actionWorkflow,actionAlarmState,actionAlarmName,actionDeviceName, )
    //   console.log(
    //     // severity,
    //     actionSeverity,
    //     // actionWorkflow,
    //     // actionAlarmState,
    //     // actionAlarmName,
    //     // actionDeviceName,
    //     // actionNodeName,
    //     'HelloKumarData',
    //   );

    //   // console.log(actionNodeName, 'actionAlarmState');

    //   const SEVERITY_AUDIO_MAP = {
    //     3: MajorSound, // Assuming severity 3 plays Major.wav
    //     2: MinorSound, // Assuming severity 2 plays Minor.wav
    //     1: CriticalSound, // Assuming severity 1 plays Critical.wav
    //     '-1': MinorSound,
    //     0: CriticalSound,
    //   };

    //   const soundFile = SEVERITY_AUDIO_MAP[severity];

    //   //  Find the matching mute/popup config based on severity
    //   const muteConfig = state.popUpData.find((item) => {
    //     console.log(
    //       item.severity === actionSeverity,
    //       item.mute,
    //       item.severity,
    //       'updateAlaram',
    //     );
    //     return item.severity === actionSeverity;
    //   });
    //   // console.log(muteConfig[0], 'updateAlaram');

    //   if (muteConfig) {
    //     console.log('Mute Config Found:', muteConfig); // Log the entire object
    //     console.log('Mute Value:', muteConfig.mute); // Log specific properties
    //     console.log('PopUp Value:', muteConfig.popUp);
    //     console.log('severity Value:', muteConfig.severity);
    //   } else {
    //     console.log('No Mute Config Found for Severity:', actionSeverity); // Indicate no match
    //   }

    //   if (
    //     soundFile &&
    //     muteConfig.severity === actionSeverity &&
    //     actionWorkflow === 0 &&
    //     actionAlarmState === 0 &&
    //     muteConfig?.mute === false &&
    //     muteConfig?.popUp === true
    //   ) {
    //     try {
    //       const audio = new Audio(soundFile);
    //       if (actionSeverity === -1) {
    //         showToast(
    //           `A NewAlarm ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'default',
    //           <NormalSvg/>,
    //           "Normal"

    //         );
    //       } else if (actionSeverity === 0) {
    //         showToast(
    //           `A NewAlarm ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'primary',
    //           <WarningSVG/>,
    //           "Warning"
    //         );
    //       } else if (actionSeverity === 1) {
    //         showToast(
    //           `A NewAlarm ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'secondary',
    //           <MinorsSvg/>,
    //           "Minor"
    //         );
    //       } else if (actionSeverity === 2) {
    //         showToast(
    //           `A NewAlarm ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'warning',
    //           <ErrorSvg/>,
    //           "Major"
    //         );
    //       } else if (actionSeverity === 3) {
    //         showToast(
    //           `A NewAlarm ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'danger',
    //           <Critical/>,
    //           "Critical"
    //         );
    //       }

    //       // addToast({
    //       //   title: `A NewAlarm  ${actionAlarmName} has been detected. KUMAR `,
    //       //   description: `Source: ${actionDeviceName} (Node: ${actionNodeName})`,
    //       //   status: "error",
    //       //   duration: null,
    //       //   isClosable: true,
    //       //   position: "bottom-right",
    //       //   variant: "left-accent",
    //       // })

    //       audio.play().catch((error) => {
    //         console.error(`Alarm not Generated ${severity}:`, error);
    //       });
    //     } catch (e) {
    //       console.error('Error creating or playing audio object:', e);
    //     }
    //   } else if (
    //     soundFile &&
    //     muteConfig.severity === actionSeverity &&
    //     actionWorkflow === 0 &&
    //     actionAlarmState === 0 &&
    //     muteConfig?.mute === true &&
    //     muteConfig?.popUp === true
    //   ) {
    //     try {
    //       if (actionSeverity === -1) {
    //         showToast(
    //           `A NewAlarm  ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'default',
    //           <NormalSvg />,
    //           "Normal"
    //         );
    //       } else if (actionSeverity === 0) {
    //         showToast(
    //           `A NewAlarm  ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'primary',
    //           <WarningSVG />,
    //           "Warning"
    //         );
    //       } else if (actionSeverity === 1) {
    //         showToast(
    //           `A NewAlarm  ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'secondary',
    //           <MinorsSvg />,
    //           "Minor"
    //         );
    //       } else if (actionSeverity === 2) {
    //         showToast(
    //           `A NewAlarm  ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'warning',
    //           <ErrorSvg />,   //----> Major
    //           "Major"
    //         );
    //       } else if (actionSeverity === 3) {
    //         showToast(
    //           `A NewAlarm  ${actionAlarmName} has been detected.`,
    //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
    //           'danger',
    //           <Critical />,
    //           "Critical"
    //         );
    //       }
    //     } catch (e) {
    //       console.error('Error showing toast:', e);
    //     }
    //   } else if (
    //     soundFile &&
    //     muteConfig.severity === actionSeverity &&
    //     actionWorkflow === 0 &&
    //     actionAlarmState === 0 &&
    //     muteConfig?.mute === false &&
    //     muteConfig?.popUp === false
    //   ) {
    //     try {
    //       const audio = new Audio(soundFile);
    //       audio.play().catch((error) => {
    //         console.error(`Alarm not Generated ${severity}:`, error);
    //       });
    //     } catch (e) {
    //       console.error('Error creating or playing audio object:', e);
    //     }
    //   } else if (
    //     soundFile &&
    //     muteConfig.severity === actionSeverity &&
    //     actionWorkflow === 0 &&
    //     actionAlarmState === 0 &&
    //     muteConfig?.mute === true &&
    //     muteConfig?.popUp === false
    //   ) {
    //     try {
    //       console.log('Its Mute ');
    //     } catch (e) {
    //       console.error('Error creating or playing audio object:', e);
    //     }
    //   }
    //   // till here ---------------------------------------------
    //   // return SendedData;
    //   return {
    //     ...state,
    //     newAlaram: SendedData,
    //   };
    // },

    setupdateAlram: (state, action) => {
      console.log(action.payload, "updateAlaram");
      const UpdatedSeverity = state.popUpData.map((itm) => itm.severity); // Extract just the severities
      console.log(UpdatedSeverity, "updateAlaramies");

      // ------------------------------------ For Here To there ----------------------------------
      //   const severity = state.popUpData[0]?.severity;
      //   const mute = state.popUpData[0]?.mute;
      //   const popUp = state.popUpData[0]?.popUp;
      //   const actionSeverity = action.payload.severity;
      //   const actionWorkflow = action.payload.workflowstate;
      //   const actionAlarmState = action.payload.alarmState;
      //   const actionAlarmName = action.payload.alarmName;
      //   const actionNodeName =
      //     action.payload.resourceDetails?.nodeDetails?.name ||
      //     action.payload.nodeDetails?.name ||
      //     ' N/A';
      //   const actionDeviceName =
      //     action.payload?.resourceDetails?.resourceName || 'Site Alarm';
      //   // const actionDeviceName = action.payload.resourceDetails.resourceName;
      //   // const actionNodeName = action.payload.resourceDetails.nodeDetails.name;

      //   const SEVERITY_AUDIO_MAP = {
      //     3: MajorSound, // Assuming severity 3 plays Major.wav
      //     2: MinorSound, // Assuming severity 2 plays Minor.wav
      //     1: CriticalSound, // Assuming severity 1 plays Critical.wav
      //     '-1': MinorSound,
      //     0: CriticalSound,
      //   };

      //   console.log(
      //     severity,
      //     actionSeverity,
      //     actionWorkflow,
      //     actionAlarmState,
      //     actionAlarmName,
      //     // actionDeviceName,
      //     // actionNodeName,
      //     mute,
      //     popUp,
      //     'updateAlaram',
      //   );

      //   // console.log(actionAlarmState, 'actionAlarmState');
      //   const soundFile = SEVERITY_AUDIO_MAP[severity];

      //   //  Find the matching mute/popup config based on severity
      //   const muteConfig = state.popUpData.find((item) => {
      //     // console.log(
      //     //   item.severity === actionSeverity,
      //     //   item.mute,
      //     //   item.severity,
      //     //   'updateAlaram',
      //     // );
      //     return item.severity === actionSeverity;
      //   });
      //   // console.log(muteConfig[0], 'updateAlaram');

      //   if (muteConfig) {
      //     console.log('Mute Config Found:', muteConfig); // Log the entire object
      //     console.log('Mute Value:', muteConfig.mute); // Log specific properties
      //     console.log('PopUp Value:', muteConfig.popUp);
      //     console.log('severity Value:', muteConfig.severity);
      //   } else {
      //     console.log('No Mute Config Found for Severity:', actionSeverity); // Indicate no match
      //   }

      //   console.log(
      //     soundFile &&
      //       muteConfig.severity === actionSeverity &&
      //       // actionWorkflow === 0 &&
      //       actionAlarmState === 0 &&
      //       muteConfig?.mute === false &&
      //       muteConfig?.popUp === true,
      //     'actionAlarmState',
      //   );

      //   if (
      //     soundFile &&
      //     muteConfig.severity === actionSeverity &&
      //     actionWorkflow === 0 &&
      //     actionAlarmState === 0 &&
      //     muteConfig?.mute === false &&
      //     muteConfig?.popUp === true
      //   ) {
      //     try {
      //       const audio = new Audio(soundFile);
      //       // console.log("ACK alarm updated")
      //       if (actionSeverity === -1) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'default',
      //           <NormalSvg />,
      //           "Normal"
      //         );
      //       } else if (actionSeverity === 0) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'primary',
      //           <WarningSVG />,
      //           "Warning"
      //         );
      //       } else if (actionSeverity === 1) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'secondary',
      //           <MinorsSvg />,
      //           "Minor"
      //         );
      //       } else if (actionSeverity === 2) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'warning',
      //           <ErrorSvg />,
      //           "Major"
      //         );
      //       } else if (actionSeverity === 3) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'danger',
      //           <Critical/>,
      //           "Critical"
      //         );
      //       }
      //       audio.play().catch((error) => {
      //         console.error(`Alarm not Generated ${severity}:`, error);
      //       });
      //     } catch (e) {
      //       console.error('Error creating or playing audio object:', e);
      //     }
      //   } else if (
      //     soundFile &&
      //     muteConfig.severity === actionSeverity &&
      //     actionWorkflow === 0 &&
      //     actionAlarmState === 0 &&
      //     muteConfig?.mute === true &&
      //     muteConfig?.popUp === true
      //   ) {
      //     try {
      //       if (actionSeverity === -1) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'default',
      //           <NormalSvg />,
      //           "Normal"
      //         );
      //       } else if (actionSeverity === 0) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'primary',
      //           <ErrorSvg />,
      //           "Warning"
      //         );
      //       } else if (actionSeverity === 1) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'secondary',
      //           <MinorsSvg />,
      //           "Minor"
      //         );
      //       } else if (actionSeverity === 2) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'warning',
      //           <ErrorSvg />,
      //           "Major"
      //         );
      //       } else if (actionSeverity === 3) {
      //         showToast(
      //           `A RepeatedAlarm  ${actionAlarmName} has been detected.`,
      //           `Source: ${actionDeviceName} , (Node: ${actionNodeName}).`,
      //           'danger',
      //           <Critical />,
      //           "Critical"
      //         );
      //       }
      //     } catch (e) {
      //       console.error('Error showing toast:', e);
      //     }
      //   } else if (
      //     soundFile &&
      //     muteConfig.severity === actionSeverity &&
      //     actionWorkflow === 0 &&
      //     actionAlarmState === 0 &&
      //     muteConfig?.mute === false &&
      //     muteConfig?.popUp === false
      //   ) {
      //     try {
      //       const audio = new Audio(soundFile);
      //       audio.play().catch((error) => {
      //         console.error(`Alarm not Generated ${severity}:`, error);
      //       });
      //     } catch (e) {
      //       console.error('Error creating or playing audio object:', e);
      //     }
      //   }
      // else if (
      //   soundFile &&
      //   muteConfig.severity === actionSeverity &&
      //   // actionWorkflow === 0 &&
      //   actionAlarmState === 0 &&
      //   muteConfig?.mute === true &&
      //   muteConfig?.popUp === false
      // ) {
      //   try {
      //     console.log('Its Mute ');
      //   } catch (e) {
      //     console.error('Error creating or playing audio object:', e);
      //   }
      // }
      // ------------------------------------ For Here To there ----------------------------------
      return {
        ...state,
        updateAlaram: action.payload,
      };
    },

    // setAlarmTotalCount: (state, action) => {
    //   state.totalAlarmCount = action.payload || 0;
    //   console.log(state.totalAlarmCount, 'totalAlarmCount');
    // },
    // setdeleteAlram: (state, action) => {
    //   return {
    //     ...state,
    //     deleteId: action.payload,
    //   };
    // },
    // toggleAlarmNotification: (state) => {
    //   state.alarmNotification = !state.alarmNotification;
    //   // state.alarmNotification = false;
    // },
    // setAlarmNotification: (state, action) => {
    //   // New Reducer to set alarmNotification to true
    //   state.alarmNotification = action.payload;
    // },
  },
});

export const {
  incrementAlarmCount,
  setAlarmSeverityCount,
  decrementAlarmCount,
  setAlarmTotalCount,
  resetAlarmCount,
  setAlarmPage,
  leaveAlarmPage,
  setnewAlram,
  setupdateAlram,
  setdeleteAlram,
  toggleAlarmNotification,
  setAlarmNotification,
  setPopUpMuteData,
  setPopUpMuteUpdate,
  setActiveAllAlarms,
  setBadgeCount,
  setSeverityData,
  updateSingleAlarm,
  clearUpdateAlarm,
  setNewAlarm,
  updateSingleBadge,
  setAlarmNotificationSettings,
  setCnmsBadgeCount
} = alarmSlice.actions;
export default alarmSlice.reducer;
