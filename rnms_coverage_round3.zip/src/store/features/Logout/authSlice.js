import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  isLogoutPending: false,
  logoutMessage: "",
   targetUser: "",
    
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    // This action will be triggered by the socket middleware
    setLogoutPending: (state, action) => {
      console.log("REDUX: Updating state with message:", action.payload);
      state.isLogoutPending = true;
      state.logoutMessage = action.payload.message;
      state.targetUser = action.payload.targetUser;
    },
    // Reset state when user logs back in
    resetAuthStatus: (state) => {
      state.isLogoutPending = false;
      state.logoutMessage = "";
      state.targetUser = ""; 
    }
  },
});

export const { setLogoutPending, resetAuthStatus } = authSlice.actions;
export default authSlice.reducer;