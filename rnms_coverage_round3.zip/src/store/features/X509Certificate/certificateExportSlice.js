import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    commandResponse: "",
};

const certificateExportSlice = createSlice({
    name: "certificateExport",
    initialState,
    reducers: {
        setCertificateExportResponse: (state, action) => {
            state.commandResponse = action.payload || "";
            console.log(" state.commandResponse", state.commandResponse)
        },

        clearCertificateExportResponse: (state) => {
            state.commandResponse = "";
        },
    },
});

export const {
    setCertificateExportResponse,
    clearCertificateExportResponse,
} = certificateExportSlice.actions;

export default certificateExportSlice.reducer;