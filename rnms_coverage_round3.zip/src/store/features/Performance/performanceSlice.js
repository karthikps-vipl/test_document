import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  // This is the missing piece that caused the error
  performanceData: {}, 
  
  // You can keep these if you use them elsewhere, 
  // but your reducer currently relies on the object above
  resourceId: null,
  cpu: 0,    
  memory: 0, 
  disk: 0,   
  lastUpdated: null,
};

const performanceSlice = createSlice({
  name: "performance",
  initialState,
  reducers: {
    /**
     * Updates the specific metric based on the paramId received from WebSocket
     * @param {Object} payload - { resourceId, paramId, value }
     */
    updatePerformanceData: (state, action) => {
      const { resourceId, paramId, value } = action.payload;

      // 1. Safety check: Ensure performanceData exists (redundant if initialState is correct, but good practice)
      if (!state.performanceData) {
        state.performanceData = {};
      }

      // 2. Ensure we have a container for this specific resource
      // Note: If resourceId is a number, it will be used as a key in the object
      if (!state.performanceData[resourceId]) {
        state.performanceData[resourceId] = {};
      }

      // 3. Update only the specific paramId (1400, 1600, or 2100)
      state.performanceData[resourceId][paramId] = value;
      
      // Optional: Update the top-level lastUpdated or resourceId if needed
      state.lastUpdated = new Date().toISOString();
      state.resourceId = resourceId;
    },

    /**
     * Resets the performance data
     */
    resetPerformanceData: (state) => {
      // When returning a new object in Redux Toolkit, 
      // it replaces the entire state with this object
      return initialState;
    },
  },
});

export const { updatePerformanceData, resetPerformanceData } = performanceSlice.actions;
export default performanceSlice.reducer;