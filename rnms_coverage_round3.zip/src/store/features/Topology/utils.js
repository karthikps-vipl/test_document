import { normalizeReactFlowNode } from "./topologyNodesslice";

export function determineStatus(item) {
  const managedState =
    item?.imResourceType?.imResourceStateInfo?.resourceStateId;

  if (managedState === 1) {
    if (item?.isMaintainance)
      return { resourceStateName: "maintainance", maxSeverity: null };

    // updated to handle empty nePollingInfo {} and null nePollingInfo
    if (item?.isDiscovered) {
      if (item?.nePollingInfo && Object.keys(item?.nePollingInfo).length > 0) {
        return {
          resourceStateName: item?.nePollingInfo?.isReachable ? "up" : "down",
          maxSeverity: item?.nePollingInfo?.maxSeverity ?? null,
        };
      } else {
        return {
          resourceStateName: "up",
          maxSeverity: null,
        };
      }
    }
    return {
      resourceStateName:
        item?.imResourceType?.imResourceStateInfo?.resourceStateName ?? "",
      maxSeverity: item.maxSeverity ?? null,
    };
  }

  if (managedState === 2)
    return { resourceStateName: "unmanaged", maxSeverity: null };
  return {};
}

export function mapNodeDetails(item) {
  return {
    resourceIp: item.resourceIp,
    imResourceType: mapResourceType(item.imResourceType),
    imSegmentInfo: mapSegmentInfo(item.imSegmentInfo),
    resourceSerialNo: item.resourceSerialNo,
    resourceDesc: item.resourceDesc,
    firmwareVersion: item.firmwareVersion,
    tmSnmpProfile: mapSnmpProfile(item.tmSnmpProfile),
    macAddress: item.macAddress,
    discoveredTime: item.discoveredTime,
    nePollingInfo: mapPollingInfo(item.nePollingInfo),
    status: item.status,
    discoveryMode: item.discoveryMode,
    portNumber: item.portNumber,
    devicePosition: item.devicePosition,
    remarks: item.remarks,
    discoveredstatusMessage: item.discoveredstatusMessage,
    timestamp: item.timestamp,
    lstPortInfoDtl: item.lstPortInfoDtl,
    latitude: item.latitude,
    longitude: item.longitude,
    ids: item.id,
  };
}

export function mapResourceType(type) {
  return {
    resourceTypeId: type?.resourceTypeId,
    resourceTypeName: type?.resourceTypeName,
    configurable: type?.configurable,
    imResourceStateInfo: {
      resourceStateId: type?.imResourceStateInfo?.resourceStateId,
    },
    make: type?.make,
    model: type?.model,
    sysOidValue: type?.sysOidValue,
    enterpriseOid: type?.enterpriseOid,
    imCommunicationType: {
      id: type?.imCommunicationType?.id,
      protoTypeName: type?.imCommunicationType?.protoTypeName,
    },
    nodeType: {
      id: type?.nodeType?.id,
      name: type?.nodeType?.name,
      description: type?.nodeType?.description,
      topologyData: type?.nodeType?.topologyData,
    },
    resourceNickName: type?.resourceNickName,
    data: { ...type?.data }, // for context menu

    serialNumOid: type?.serialNumOid,
    firmwareNumOid: type?.firmwareNumOid,
    resourceSubType: type?.resourceSubType,
  };
}

export function mapSegmentInfo(segment) {
  return {
    segmentId: segment?.segmentId,
    segmentName: segment?.segmentName,
    segmentDesc: segment?.segmentDesc,
  };
}

export function mapSnmpProfile(profile) {
  return {
    snmpProfileId: profile?.snmpProfileId,
    version: profile?.version,
    port: profile?.port,
    timeout: profile?.timeout,
    retries: profile?.retries,
    username: profile?.username,
    authPassword: profile?.authPassword,
    authProtocol: profile?.authProtocol,
    contextName: profile?.contextName,
    privPassword: profile?.privPassword,
    privProtocol: profile?.privProtocol,
    readCommunity: profile?.readCommunity,
    securityLevel: profile?.securityLevel,
    snmpProfileName: profile?.snmpProfileName,
    writeCommunity: profile?.writeCommunity,
    ipAddress: profile?.ipAddress,
  };
}

export function mapPollingInfo(polling) {
  return {
    id: polling?.id,
    pollingInterval: polling?.pollingInterval,
    isDefaultPolling: polling?.isDefaultPolling,
    imResourceInfo: polling?.imResourceInfo,
  };
}


export const mergeSavedRackWithReduxNodes = (savedRackNodes, reduxNodes) => {
  if (!Array.isArray(savedRackNodes)) return [];
  if (!Array.isArray(reduxNodes)) return savedRackNodes;

  const reduxByResourceId = new Map(
    reduxNodes
      .filter((node) => node?.data?.resourceId)
      .map((node) => [node.data.resourceId, node])
  );

  return savedRackNodes.map((savedNode) => {
    const resourceId = savedNode?.data?.resourceId;

    if (!resourceId) {
      return normalizeReactFlowNode(savedNode, "rackNode");
    }

    const latestReduxNode = reduxByResourceId.get(resourceId);

    if (!latestReduxNode) {
      // Device no longer exists in Redux.
      // Keep saved topology information.
      return normalizeReactFlowNode(savedNode, "rackNode");
    }

    return normalizeReactFlowNode(
      {
        ...savedNode,

        // IMPORTANT:
        // saved JSON controls topology/layout
        position: savedNode.position,

        // Redux controls current device information
        data: {
          ...savedNode.data,
          ...latestReduxNode.data,
        },
      },
      "rackNode"
    );
  });
};


