/* eslint-disable no-unused-vars */

import { createSlice } from "@reduxjs/toolkit";
import { applyEdgeChanges, applyNodeChanges } from "@xyflow/react";
import { determineStatus } from "./utils";
import {
  getEdgeColor,
} from "@/Pages/Rnmsdashboard/Topology/utils";

const initialState = {
  isCnms: false,
  nodes: [], //nodes inTopology
  edges: [],
  currentViewTopology: true,
  rackNodes: [], //nodes in rack
  undoStack: [],
  redoStack: [],
  undoStackRack: [],
  redoStackRack: [],
  rackLayout: [],
  canUndo: false,
  canRedo: false,
  canUndoRack: false,
  canRedoRack: false,
  currentNodeView: "simpleViewNode",
  allResourceInfo: [],
  imagePortStatus: [],
  currentViewMode: "reactflow",
  terminalTypes: [],
  past: [],
  present: null,
  future: [],
  switchTopology: "simpleViewNode",
  deviceStats: {
    online: 0,
    offline: 0,
    maintenance: 0,
    undiscovered: 0,
    unmanaged: 0,
  },
  linkStatusData: [],
  activeAction: "",
  arrowMenuAnchor: null,
};

const getUnifiedDevice = (node, isCnms = false) => {
  console.log("addnodee", node);

  // 1. Extract basic properties safely
  const resourceStateId =
    node?.imResourceType?.imResourceStateInfo?.resourceStateId;
  const isDiscovered = !!node?.isDiscovered;
  const isMaintainance = !!node?.isMaintainance;

  // 2. Determine Reachability (Handle null/empty nePollingInfo)
  // Logic: If nePollingInfo exists and has keys, use isReachable.
  // If it's null or empty, we treat it as "up" (isReachable = true) per your status logic.
  
  // const hasPollingInfo =
  //   node?.nePollingInfo && Object.keys(node.nePollingInfo).length > 0;
  // const isReachable = hasPollingInfo ? !!node.nePollingInfo.isReachable : true;


    // 1. Determine reachability based on topology mode
    let isReachable;

    if (isCnms) {
      // CNMS: Ignore nePollingInfo completely
      isReachable = !!node?.isReachable;;
    } else {
      // RNMS: Preserve existing polling behavior
      const hasPollingInfo =
        node?.nePollingInfo &&
        Object.keys(node.nePollingInfo).length > 0;
  
      isReachable = hasPollingInfo
        ? !!node.nePollingInfo.isReachable
        : true;
    }

  // 3. Determine Online/Offline status based on the hierarchy in determineStatus
  let isOnline = false;
  let offline = false;

  if (resourceStateId === 1) {
    if (isMaintainance) {
      // In maintenance: not technically "online" in terms of traffic
      isOnline = false;
      offline = false;
    } else if (isDiscovered) {
      // If discovered, online depends on reachability (or defaults to true if info is missing)
      isOnline = isReachable;
      offline = !isReachable;
    } else {
      // Not discovered and not in maintenance
      isOnline = false;
      offline = false;
    }
  } else if (resourceStateId === 2) {
    // Unmanaged state
    isOnline = false;
    offline = false;
  }

  return {
    isReachable,
    isDiscovered,
    isMaintainance,
    resourceStateId,
    offline,
    isOnline,
  };
};

export const determineStatusRedux = (node, isCnms = false) => {
  const {
    isReachable,
    isDiscovered,
    isMaintainance,
    resourceStateId,
    offline,
    isOnline,
  } = getUnifiedDevice(node,isCnms);

  // unmanaged (highest priority)
  if (resourceStateId === 2) return "unmanaged";

  if (isOnline) return "online";

  if (offline) return "offline";

  if (!isDiscovered && isMaintainance) return "maintenance";

  if (!isDiscovered && !isMaintainance) return "undiscovered";

  // return "offline";
};

const calculateStats = (nodes,isCnms = false,type="") => {
  const stats = {
    online: 0,
    offline: 0,
    maintenance: 0,
    undiscovered: 0,
    unmanaged: 0,
  };

  console.log("nodesuhnodes", nodes);
  console.log("calculateStatstype",type);
  console.log("isCnmsisCnmsisCnms",isCnms);
  

  for (const node of nodes) {
    const status = determineStatusRedux(node.data ,isCnms);

    if (stats[status] !== undefined) {
      stats[status]++;
    }
  }
  console.log("FINAL STATS OBJECT:", stats);
  return stats;
};

export const normalizeReactFlowNode = (node, defaultType = "rackNode") => {
  return {
    ...node,

    id: node?.id || crypto.randomUUID(),

    type: node?.type || defaultType,

    position: {
      x: Number(node?.position?.x) || 0,
      y: Number(node?.position?.y) || 0,
    },

    data: node?.data || {},
  };
};

const topologyNodes = createSlice({
  name: "topologyNodes",
  initialState,

  reducers: {
    callCalculateStatus: (state, action) => {
      // state.deviceStats = calculateStats(state.nodes);
    },
    setIsCnmsMode: (state, action) => {
      state.isCnms = !!action.payload;
    
      // Recalculate all device statistics when mode changes
      state.deviceStats = calculateStats(
        state.nodes,
        state.isCnms,
        "setIsCnmsMode"
      );
    },
    setNodes: (state, action) => {
      const incoming = action.payload;
      state.nodes = incoming;
      state.deviceStats = calculateStats(state.nodes, state.isCnms,"setNodes");
    },
    setCNMSDeviceStats: (state, action) => {
      const incoming = action.payload;
      state.nodes = incoming;
      state.deviceStats = calculateStats(state.nodes, state.isCnms,"setCNMSDeviceStats");
    },
    setRackLayout: (state, action) => {
      state.rackLayout = (action.payload || []).map((node) =>
        normalizeReactFlowNode(node, "rackNode")
      );
    },
    setInitialEdges: (state, action) => {
      state.edges = action.payload;
    },
    setEdges: (state, action) => {
      state.edges = [...state.edges, ...action.payload];
    },
    setCurrentViewTopology: (state, action) => {
      state.currentViewTopology = !state.currentViewTopology;
    },
    setCurrentViewCnmsTopology: (state, action) => {
      state.currentViewTopology = action.payload;
    },
    addNode: (state, action) => {
      state.nodes = [...state.nodes, ...action.payload];
    },
    addNodeToRack: (state, action) => {
      const safeNodes = (action.payload || []).map((node) =>
        normalizeReactFlowNode(node, "rackNode")
      );

      state.rackLayout = [...state.rackLayout, ...safeNodes];
    },
    onNodesChange: (state, action) => {
      state.nodes = applyNodeChanges(action.payload, state.nodes);
    },
    onNodesChangeOfRack: (state, action) => {
      const updated = applyNodeChanges(action.payload, state.rackLayout);

      state.rackLayout = updated.map((node) =>
        normalizeReactFlowNode(node, "rackNode")
      );
    },
    onEdgesChange: (state, action) => {
      state.edges = applyEdgeChanges(action.payload, state.edges);
    },
    setCurrentViewMode: (state, action) => {
      state.currentViewMode = action.payload;
    },
    setTerminalTypes: (state, action) => {
      state.terminalTypes = action.payload;
    },
    setLinkStatusData: (state, action) => {
      state.linkStatusData = action.payload;
    },
    setActiveAction: (state, action) => {
      state.activeAction = action.payload;
    },
    setArrowMenuAnchor: (state, action) => {
      state.arrowMenuAnchor = action.payload;
    },
    // updateNodeLabel: (state, action) => {
    //   const { id, label, color, borderColor } = action.payload;

    //   const updateNodeProperties = (node) => {
    //     if (node.id === id || node.data?.resourceId === id) {
    //       return {
    //         ...node,
    //         // 1. Update the data object (Common for custom nodes)
    //         data: {
    //           ...node.data,
    //           label: label,
    //           text: label,
    //           color: color,
    //           bgColor: color,
    //           backgroundColor: color,
    //           borderColor: borderColor,
    //         },
    //         // 2. Update the style object (React Flow standard CSS overrides)
    //         style: {
    //           ...node.style,
    //           background: color,
    //           backgroundColor: color,
    //           borderColor: borderColor,
    //         },
    //       };
    //     }
    //     return node;
    //   };

    //   state.nodes = state.nodes.map(updateNodeProperties);
    //   state.rackNodes = state.rackNodes.map(updateNodeProperties);
    // },
    updateNodeLabel: (state, action) => {
      const { id, label, color, borderColor } = action.payload;
    
      const updateNodeProperties = (node) => {
        if (node.id === id || node.data?.resourceId === id) {
          return {
            ...node,
            data: {
              ...node.data,
              label: label,
              text: label,
              color: color,
              bgColor: color,
              backgroundColor: color,
              borderColor: borderColor,
            },
            style: {
              ...node.style,
              background: color,
              backgroundColor: color,
              borderColor: borderColor,
            },
          };
        }
    
        return node;
      };
    
      state.nodes = state.nodes.map(updateNodeProperties);
    
      // Important: rack nodes are stored in rackLayout
      state.rackLayout = state.rackLayout.map(updateNodeProperties);
    },
    resetMenuState: (state) => {
      state.activeAction = "";
      state.arrowMenuAnchor = null;
    },
    setImageNodePortStatusLive: (state, action) => {
      const { resourceId, lstPortInfoDtl } = action.payload;
      state.nodes = state.nodes.map((node) => {
        if (node.data.resourceId === resourceId) {
          return {
            ...node,
            data: {
              ...node.data,
              lstPortInfoDtl: lstPortInfoDtl,
            },
          };
        }
        return node;
      });

      state.rackNodes = state.rackNodes.map((node) => {
        if (node.data.resourceId === resourceId) {
          return {
            ...node,
            data: {
              ...node.data,
              lstPortInfoDtl: lstPortInfoDtl,
            },
          };
        }
        return node;
      });
    },

    updateNodeViewType: (state, action) => {
      return {
        ...state,
        currentNodeView: action.payload,
        nodes: state.nodes.map((node) => {
          return {
            ...node,
            data: {
              ...node.data,
              viewMode: action.payload,
            },
          };
        }),
      };
    },
    updateSwitchTopology: (state, action) => {
      state.switchTopology = action.payload;
    },
    updateNodeStyle: (state, action) => {
      const { id, style } = action.payload;
      const node = state.nodes.find((n) => n.id === id);
      if (node) {
        node.style = { ...node.style, ...style };
      }
    },

    pushToUndoStack: (state) => {
      state.undoStack.push({
        nodes: [...state.nodes],
        edges: [...state.edges],
      });
      state.redoStack = [];
    },
    performUndo: (state) => {
      console.log("perfoem undo called");
      if (state.undoStack.length > 0) {
        const lastState = state.undoStack.pop();
        state.redoStack.push({
          nodes: [...state.nodes],
          edges: [...state.edges],
        });
        state.nodes = lastState.nodes;
        state.edges = lastState.edges;
      }
    },
    performRedo: (state) => {
      if (state.redoStack.length > 0) {
        const nextState = state.redoStack.pop();
        state.undoStack.push({
          nodes: [...state.nodes],
          edges: [...state.edges],
        });
        state.nodes = nextState.nodes;
        state.edges = nextState.edges;
      }
    },

    updateNodeStatus: (state, action) => {
      const updatedApiResponse = action.payload;
      const targetId = updatedApiResponse.resourceId;

      state.nodes = state.nodes.map((node) => {
        if (node.id !== targetId && node.data?.resourceId !== targetId) {
          return node;
        }

        return {
          ...node,

          data: {
            ...node.data,

            ...updatedApiResponse,

            nePollingInfo: {
              ...node.data?.nePollingInfo,
              ...updatedApiResponse.nePollingInfo,
            },

            imResourceType: {
              ...node.data?.imResourceType,
              ...updatedApiResponse.imResourceType,

              imResourceStateInfo: {
                ...node.data?.imResourceType?.imResourceStateInfo,
                ...updatedApiResponse.imResourceType?.imResourceStateInfo,
              },
            },
          },
        };
      });

      state.deviceStats = calculateStats(state.nodes, state.isCnms,"updateNodeStatus");
    },

    updateDiscoveredDeviceStatus: (state, action) => {
      const updatedDevices = action.payload;

      if (Array.isArray(updatedDevices)) {
        updatedDevices.forEach((updatedItem) => {
          const targetId = updatedItem.resourceId;

          const index = state.nodes.findIndex(
            (node) => node.id === targetId || node.data?.resourceId === targetId
          );

          if (index !== -1) {
            state.nodes[index].data = {
              ...state.nodes[index].data,
              isDiscovered: updatedItem.isDiscovered,
              isMaintainance: updatedItem.isMaintainance,
              status: updatedItem.status,
              lstPortInfoDtl: updatedItem.lstPortInfoDtl || [],
            };
          }

          const rackIndex = state.rackNodes.findIndex(
            (node) => node.id === targetId || node.data?.resourceId === targetId
          );

          if (rackIndex !== -1) {
            state.rackNodes[rackIndex].data = {
              ...state.rackNodes[rackIndex].data,
              isDiscovered: updatedItem.isDiscovered,
              isMaintainance: updatedItem.isMaintainance,
              status: updatedItem.status,
            };
          }
        });
      }
      state.deviceStats = calculateStats(state.nodes, state.isCnms,"updateDiscoveredDeviceStatus");
    },
    pushToUndoStackRack: (state) => {
      state.undoStackRack.push({
        rackLayout: [...state.rackLayout],
      });

      state.redoStackRack = [];
    },
    performUndoRack: (state) => {
      if (state.undoStackRack.length === 0) {
        return;
      }

      const lastState = state.undoStackRack.pop();

      state.redoStackRack.push({
        rackLayout: [...state.rackLayout],
      });

      state.rackLayout = lastState.rackLayout.map((node) =>
        normalizeReactFlowNode(node, "rackNode")
      );
    },
    performRedoRack: (state) => {
      if (state.redoStackRack.length === 0) {
        return;
      }

      const nextState = state.redoStackRack.pop();

      state.undoStackRack.push({
        rackLayout: [...state.rackLayout],
      });

      state.rackLayout = nextState.rackLayout.map((node) =>
        normalizeReactFlowNode(node, "rackNode")
      );
    },
    //
    deleteAllNodesAndEdges: (state, action) => {
      state.nodes = [];
      state.edges = [];
    },
    deleteAllNodesAndEdgesOfRack: (state, action) => {
      state.rackLayout = [];
    },
    updateLinkType: (state, action) => {
      const { edgeId, type } = action.payload;
      const typeStyles = {
        "10GE": {
          stroke: "grey",

          strokeWidth: 3,
          strokeDasharray: "0",
          animated: false,
        },
        "1GE": {
          stroke: "grey",

          strokeWidth: 3,
          strokeDasharray: "3,3",
          animated: false,
        },
        mgmt: {
          stroke: "grey",

          strokeWidth: 3,
          strokeDasharray: "7,7",
          animated: false,
        },
      };

      state.edges = state.edges.map((e) =>
        e.id === edgeId
          ? {
              ...e,
              style: {
                ...e.style,
                // stroke: typeStyles[type].stroke,
                strokeWidth: typeStyles[type].strokeWidth,
                strokeDasharray: typeStyles[type].strokeDasharray || "0",
              },
              animated: typeStyles[type].animated,
              linkType: type,
              data: { ...e.data, type },
            }
          : e
      );
    },
    updateEdgeColorByContextMenu: (state, action) => {
      const { edgeId, color } = action.payload;

      return {
        ...state,
        edges: state.edges.map((edge) => {
          if (edge.id === edgeId) {
            return {
              ...edge,
              style: {
                ...edge.style,
                stroke: color,
              },
            };
          } else {
            return edge;
          }
        }),
      };
    },
    deleteLink: (state, action) => {
      const edgeId = action.payload;

      state.edges = state.edges.filter((edge) => edge.id !== edgeId);
    },
    deleteNode: (state, action) => {
      const nodeId = action.payload;

      state.nodes = state.nodes.filter((node) => node.id !== nodeId);
      state.edges = state.edges.filter(
        (edge) => edge.source !== nodeId && edge.target !== nodeId
      );
    },

    setAllResourceInfo: (state, action) => {
      const responseData = action.payload;

      if (!Array.isArray(responseData) || responseData.length === 0) {
        return;
      }

      const responseMap = new Map();

      responseData.forEach((item) => {
        if (item?.resourceId !== undefined && item?.resourceId !== null) {
          responseMap.set(String(item.resourceId), item);
        }
      });

      state.nodes = state.nodes.map((node) => {
        const resourceId = node?.data?.resourceId;

        if (resourceId === undefined || resourceId === null) {
          return node;
        }

        const apiItem = responseMap.get(String(resourceId));

        if (!apiItem) {
          return node;
        }

        const currentData = node.data || {};

        const currentPollingInfo = currentData.nePollingInfo || {};

        const apiPollingInfo = apiItem.nePollingInfo || {};

        const currentResourceType = currentData.imResourceType || {};

        const apiResourceType = apiItem.imResourceType || {};

        const currentResourceState =
          currentResourceType.imResourceStateInfo || {};

        const apiResourceState = apiResourceType.imResourceStateInfo || {};
        const statusInfo = determineStatus({
          ...currentData,
          ...apiItem,
          nePollingInfo: {
            ...currentPollingInfo,
            ...apiPollingInfo,
          },
          imResourceType: {
            ...currentResourceType,
            ...apiResourceType,
            imResourceStateInfo: {
              ...currentResourceState,
              ...apiResourceState,
            },
          },
        });

        return {
          ...node,

          data: {
            ...currentData,
            ...apiItem,

            // Preserve latest port information
            lstPortInfoDtl:
              apiItem.lstPortInfoDtl ?? currentData.lstPortInfoDtl ?? [],

            // Preserve/merge polling information
            nePollingInfo: {
              ...currentPollingInfo,
              ...apiPollingInfo,
            },

            // Merge resource type information
            imResourceType: {
              ...currentResourceType,
              ...apiResourceType,

              imResourceStateInfo: {
                ...currentResourceState,
                ...apiResourceState,

                resourceStateName:
                  statusInfo?.resourceStateName ??
                  apiResourceState.resourceStateName ??
                  currentResourceState.resourceStateName,
              },
            },

            isDiscovered:
              apiItem.isDiscovered !== undefined
                ? !!apiItem.isDiscovered
                : currentData.isDiscovered,

            isMaintainance:
              apiItem.isMaintainance !== undefined
                ? !!apiItem.isMaintainance
                : currentData.isMaintainance,
          },
        };
      });

      // Redux is now the single source of truth
      // for current device information.
      state.allResourceInfo = responseData;

      // IMPORTANT:
      // Do NOT update state.rackNodes here.
      //
      // rack nodes are derived from:
      // state.rackLayout + state.nodes
      //
      // Therefore the selector will automatically
      // receive the latest information.
      state.deviceStats = calculateStats(state.nodes, state.isCnms,"setAllResourceInfo");
    },

    updateNodeStatusThroughSocket: (state, action) => {
      const {
        isDiscovered,
        isMaintainance,
        resourceIp,
        status,
        isReachable,
        maxSeverity,
        resourceIdVal,
      } = action.payload;

      state.nodes = state.nodes.map((node) => {
        if (node?.data?.resourceId !== resourceIdVal) {
          return node;
        }

        return {
          ...node,

          data: {
            ...node.data,

            resourceIp:
              resourceIp !== undefined ? resourceIp : node.data.resourceIp,

            maxSeverity:
              maxSeverity !== undefined ? maxSeverity : node.data.maxSeverity,

            isDiscovered:
              isDiscovered !== undefined
                ? isDiscovered
                : node.data.isDiscovered,

            isMaintainance:
              isMaintainance !== undefined
                ? isMaintainance
                : node.data.isMaintainance,

            nePollingInfo: {
              ...node.data?.nePollingInfo,

              isReachable:
                isReachable !== undefined
                  ? isReachable
                  : node.data?.nePollingInfo?.isReachable,
            },

            imResourceType: {
              ...node.data?.imResourceType,

              imResourceStateInfo: {
                ...node.data?.imResourceType?.imResourceStateInfo,

                resourceStateName:
                  status ??
                  node.data?.imResourceType?.imResourceStateInfo
                    ?.resourceStateName,
              },
            },
          },
        };
      });

      state.deviceStats = calculateStats(state.nodes, state.isCnms,"updateNodeStatusThroughSocket");
    },

    setImageNodePortStatus: (state, action) => {
      state.imagePortStatus = action.payload;

      console.log("jkdfvimageportstatus", action.payload);

      // state.nodes = action.payload
    },
    saveTopologyState: (state, action) => {
      const newState = action.payload;

      if (state.present) {
        state.past.push(state.present);
      }

      state.present = newState;

      // clear redo stack
      state.future = [];
    },
    undoTopologyState: (state) => {
      if (state.past.length === 0) return;

      const previous = state.past.pop();

      if (state.present) {
        state.future.unshift(state.present);
      }

      state.present = previous;
    },
    redoTopologyState: (state) => {
      if (state.future.length === 0) return;

      const next = state.future.shift();

      if (state.present) {
        state.past.push(state.present);
      }

      state.present = next;
    },
    resetTopologyHistory: (state) => {
      state.past = [];
      state.present = null;
      state.future = [];
    },
    upsertNodeFromSocket: (state, action) => {
      const incoming = action.payload;
      const targetResourceId =
        incoming?.imResourceInfo?.resourceId || incoming?.resourceId;

      // 1. Process Standard Nodes
      const index = state.nodes.findIndex(
        (n) =>
          n?.data?.resourceId === targetResourceId || n?.id === incoming?.id
      );

      let updatedNodes = [...state.nodes];
      if (index !== -1) {
        updatedNodes[index] = {
          ...updatedNodes[index],
          data: {
            ...updatedNodes[index]?.data,
            ...incoming?.imResourceInfo,
            nePollingInfo: {
              ...updatedNodes[index]?.data?.nePollingInfo,
              isReachable: incoming?.isReachable,
            },
          },
        };
      } else {
        updatedNodes.push({
          id: incoming?.id,
          data: incoming?.imResourceInfo,
        });
      }
      state.nodes = updatedNodes;

      // 2. Process Rack Nodes
      const rackIndex = state.rackNodes.findIndex(
        (n) =>
          n?.data?.resourceId === targetResourceId || n?.id === incoming?.id
      );

      let updatedRackNodes = [...state.rackNodes];
      if (rackIndex !== -1) {
        updatedRackNodes[rackIndex] = {
          ...updatedRackNodes[rackIndex],
          data: {
            ...updatedRackNodes[rackIndex]?.data,
            ...incoming?.imResourceInfo,
            nePollingInfo: {
              ...updatedRackNodes[rackIndex]?.data?.nePollingInfo,
              isReachable: incoming?.isReachable,
            },
          },
        };
      } else {
        updatedRackNodes.push(
          normalizeReactFlowNode(
            {
              id: incoming?.id,
              data: incoming?.imResourceInfo,
            },
            "rackNode"
          )
        );
      }
      state.rackNodes = updatedRackNodes;

      state.deviceStats = calculateStats(state.nodes, state.isCnms,"upsertNodeFromSocket");
    },
    mergeNodesFromAPI: (state, action) => {
      const apiNodes = action.payload;

      const map = new Map();

      // keep existing nodes first
      state.nodes.forEach((n) => {
        map.set(n?.data?.resourceId, n);
      });

      apiNodes.forEach((n) => {
        map.set(n?.data?.resourceId, n);
      });

      const merged = Array.from(map.values());

      state.nodes = merged;
      state.deviceStats = calculateStats(state.nodes, state.isCnms,"mergeNodesFromAPI");
    },

    updateResourceStatus: (state, action) => {
      const { resourceId, isDiscovered, isMaintainance } = action.payload;

      state.nodes = state.nodes.map((node) => {
        if (node.id === resourceId || node.data?.resourceId === resourceId) {
          return {
            ...node,

            data: {
              ...node.data,

              isDiscovered,
              isMaintainance,
            },
          };
        }

        return node;
      });

      state.deviceStats = calculateStats(state.nodes, state.isCnms,"updateResourceStatus");
    },

    updateEdgeConfiguration: (state, action) => {
      const { edgeId, color, linkId, linkName, linkStatus } = action.payload;

      state.edges = state.edges.map((edge) => {
        if (edge.id !== edgeId) return edge;

        return {
          ...edge,
          style: {
            ...edge.style,
            stroke: color,
          },
          data: {
            ...edge.data,
            linkId,
            linkName,
            linkStatus,
          },
        };
      });
    },
    updateEdgeStatusFromSocket: (state, action) => {
      const { linkId, linkStatus, linkProperties, resourceId } = action.payload;
      const color = getEdgeColor(linkStatus);

      state.edges = state.edges.map((edge) => {
        // Match using linkId (recommended)
        if (edge.data?.linkId !== linkId) return edge;

        return {
          ...edge,
          style: {
            ...edge.style,
            stroke: color,
          },
          data: {
            ...edge.data,
            linkStatus,
            linkProperties,
            resourceId,
          },
        };
      });
    },
    updateLinkStatusFromSocket: (state, action) => {
      const { linkId, linkStatus } = action.payload;

      const link = state.linkStatusData.find((item) => item.linkId === linkId);

      if (link) {
        link.linkStatus = linkStatus;
      }

      state.linkStatusData = state.linkStatusData.map((link) => {
        if (link.linkId !== action.payload.linkId) return link;

        return {
          ...link,

          linkStatus: action.payload.linkStatus,
        };
      });
    },

    hydrateRackFromSavedTopology: (state, action) => {
      const savedRackNodes = action.payload || [];

      state.rackLayout = savedRackNodes.map((node) =>
        normalizeReactFlowNode(node, "rackNode")
      );
    },

    hydrateTopologyFromSavedTopology: (state, action) => {
      const savedTopology = action.payload || {};

      const savedNodes = Array.isArray(savedTopology?.nodes)
        ? savedTopology.nodes
        : [];

      const savedEdges = Array.isArray(savedTopology?.edges)
        ? savedTopology.edges
        : [];

      /*
       * Saved JSON is responsible for:
       * - node position
       * - node type
       * - node id
       * - saved layout/style information
       *
       * Existing Redux node data is considered the latest
       * device information and must be preserved.
       */

      const reduxNodeMap = new Map();

      state.nodes.forEach((node) => {
        const resourceId = node?.data?.resourceId;

        if (resourceId !== undefined && resourceId !== null) {
          reduxNodeMap.set(String(resourceId), node);
        }

        if (node?.id) {
          reduxNodeMap.set(String(node.id), node);
        }
      });

      state.nodes = savedNodes.map((savedNode) => {
        const resourceId = savedNode?.data?.resourceId;

        const currentReduxNode =
          (resourceId !== undefined && resourceId !== null
            ? reduxNodeMap.get(String(resourceId))
            : null) || reduxNodeMap.get(String(savedNode?.id));

        return normalizeReactFlowNode(
          {
            ...savedNode,

            /*
             * JSON/layout information remains authoritative
             * for the canvas.
             */
            id: savedNode?.id,
            type: savedNode?.type,

            position: {
              x: Number(savedNode?.position?.x) || 0,
              y: Number(savedNode?.position?.y) || 0,
            },

            /*
             * Latest Redux device information wins.
             * Saved JSON information is retained for fields
             * that do not exist in Redux.
             */
            data: {
              ...(savedNode?.data || {}),
              ...(currentReduxNode?.data || {}),
            },

            style: {
              ...(savedNode?.style || {}),
              ...(currentReduxNode?.style || {}),
            },
          },
          "commonNode"
        );
      });

      /*
       * Restore the saved canvas edges.
       */
      state.edges = savedEdges;
//restore-fix
      // state.deviceStats = calculateStats(state.nodes,"hydrateTopologyFromSavedTopology");
    },
  },
});

export const selectRackNodes = (state) => {
  const topologyState = state.topologySlice;

  const nodes = topologyState?.nodes || [];
  const rackLayout = topologyState?.rackLayout || [];

  if (!Array.isArray(rackLayout)) {
    return [];
  }

  const deviceMap = new Map();

  nodes.forEach((node) => {
    const resourceId = node?.data?.resourceId;

    if (resourceId !== undefined && resourceId !== null) {
      deviceMap.set(String(resourceId), node);
    }
  });

  return rackLayout.map((layoutNode) => {
    const resourceId = layoutNode?.data?.resourceId;

    const currentDevice = deviceMap.get(String(resourceId));

    if (!currentDevice) {
      return normalizeReactFlowNode(layoutNode, "rackNode");
    }

    return normalizeReactFlowNode(
      {
        ...layoutNode,

        // JSON/layout information
        id: layoutNode.id,
        type: layoutNode.type || "rackNode",
        position: layoutNode.position,

        // Latest Redux device information
        data: {
          ...layoutNode.data,
          ...currentDevice.data,
        },
      },
      "rackNode"
    );
  });
};

export const selectCanUndo = (state) => state.topologySlice.past.length > 0;

export const selectCanRedo = (state) => state.topologySlice.future.length > 0;

export const selectPresentTopology = (state) => state.topologySlice.present;

export const {
  setNodes,
  setCNMSDeviceStats,
  setRackNode,
  setEdges,
  addNode,
  onNodesChange,
  onEdgesChange,
  pushToUndoStack,
  performUndo,
  performRedo,
  updateNodeStatus,
  // rack
  pushToUndoStackRack,
  performRedoRack,
  performUndoRack,
  deleteAllNodesAndEdges,
  deleteAllNodesAndEdgesOfRack,
  updateNodeViewType,
  updateLinkType,
  deleteLink,
  deleteNode,
  setAllResourceInfo,
  updateNodeStyle,
  setCurrentViewTopology,
  addNodeToRack,
  onNodesChangeOfRack,
  setInitialEdges,
  updateEdgeColorByContextMenu,
  updateNodeStatusThroughSocket,
  setImageNodePortStatus,
  setImageNodePortStatusLive,
  setCurrentViewMode,
  setTerminalTypes,
  updateNodeLabel,

  upsertNodeFromSocket,
  mergeNodesFromAPI,

  updateEdgeConfiguration,
  updateEdgeStatusFromSocket,
  setLinkStatusData,
  updateLinkStatusFromSocket,

  updateSwitchTopology,
  updateDiscoveredDeviceStatus,
  saveTopologyState,
  undoTopologyState,
  redoTopologyState,
  resetTopologyHistory,
  updateResourceStatus,
  setActiveAction,
  setArrowMenuAnchor,
  resetMenuState,
  callCalculateStatus,
  hydrateRackFromSavedTopology,
  hydrateTopologyFromSavedTopology,
  setRackLayout,
  setCurrentViewCnmsTopology,
  setIsCnmsMode
} = topologyNodes.actions;

export default topologyNodes.reducer;

// import { createSlice } from "@reduxjs/toolkit";
// import { applyEdgeChanges, applyNodeChanges } from "@xyflow/react";
// import { determineStatus } from "./utils";
// import { getEdgeColor } from "@/Pages/Rnmsdashboard/Topology/utils";

// const initialState = {
//   nodes: [], //nodes inTopology
//   edges: [],
//   currentViewTopology: true,
//   rackNodes: [], //nodes in rack
//   undoStack: [],
//   redoStack: [],
//   undoStackRack: [],
//   redoStackRack: [],
//   rackLayout: [],
//   topologyLayout: [],
//   canUndo: false,
//   canRedo: false,
//   canUndoRack: false,
//   canRedoRack: false,
//   currentNodeView: "simpleViewNode",
//   allResourceInfo: [],
//   imagePortStatus: [],
//   currentViewMode: "reactflow",
//   terminalTypes: [],
//   past: [],
//   present: null,
//   future: [],
//   switchTopology: "simpleViewNode",
//   deviceStats: {
//     online: 0,
//     offline: 0,
//     maintenance: 0,
//     undiscovered: 0,
//     unmanaged: 0,
//   },
//   linkStatusData: [],
//   activeAction: "",
//   arrowMenuAnchor: null,
// };

// const getUnifiedDevice = (node) => {
//   console.log("addnodee", node);

//   // 1. Extract basic properties safely
//   const resourceStateId =
//     node?.imResourceType?.imResourceStateInfo?.resourceStateId;
//   const isDiscovered = !!node?.isDiscovered;
//   const isMaintainance = !!node?.isMaintainance;

//   // 2. Determine Reachability (Handle null/empty nePollingInfo)
//   // Logic: If nePollingInfo exists and has keys, use isReachable.
//   // If it's null or empty, we treat it as "up" (isReachable = true) per your status logic.
//   const hasPollingInfo =
//     node?.nePollingInfo && Object.keys(node.nePollingInfo).length > 0;
//   const isReachable = hasPollingInfo ? !!node.nePollingInfo.isReachable : true;

//   // 3. Determine Online/Offline status based on the hierarchy in determineStatus
//   let isOnline = false;
//   let offline = false;

//   if (resourceStateId === 1) {
//     if (isMaintainance) {
//       // In maintenance: not technically "online" in terms of traffic
//       isOnline = false;
//       offline = false;
//     } else if (isDiscovered) {
//       // If discovered, online depends on reachability (or defaults to true if info is missing)
//       isOnline = isReachable;
//       offline = !isReachable;
//     } else {
//       // Not discovered and not in maintenance
//       isOnline = false;
//       offline = false;
//     }
//   } else if (resourceStateId === 2) {
//     // Unmanaged state
//     isOnline = false;
//     offline = false;
//   }

//   return {
//     isReachable,
//     isDiscovered,
//     isMaintainance,
//     resourceStateId,
//     offline,
//     isOnline,
//   };
// };

// export const determineStatusRedux = (node) => {
//   const {
//     isReachable,
//     isDiscovered,
//     isMaintainance,
//     resourceStateId,
//     offline,
//     isOnline,
//   } = getUnifiedDevice(node);

//   // unmanaged (highest priority)
//   if (resourceStateId === 2) return "unmanaged";

//   if (isOnline) return "online";

//   if (offline) return "offline";

//   if (!isDiscovered && isMaintainance) return "maintenance";

//   if (!isDiscovered && !isMaintainance) return "undiscovered";

//   // return "offline";
// };

// const calculateStats = (nodes) => {
//   const stats = {
//     online: 0,
//     offline: 0,
//     maintenance: 0,
//     undiscovered: 0,
//     unmanaged: 0,
//   };

//   console.log("nodesuhnodes", nodes);

//   for (const node of nodes) {
//     const status = determineStatusRedux(node.data);

//     if (stats[status] !== undefined) {
//       stats[status]++;
//     }
//   }
//   console.log("FINAL STATS OBJECT:", stats);
//   return stats;
// };

// export const normalizeReactFlowNode = (node, defaultType = "rackNode") => {
//   return {
//     ...node,

//     id: node?.id || crypto.randomUUID(),

//     type: node?.type || defaultType,

//     position: {
//       x: Number(node?.position?.x) || 0,
//       y: Number(node?.position?.y) || 0,
//     },

//     data: node?.data || {},
//   };
// };

// const topologyNodes = createSlice({
//   name: "topologyNodes",
//   initialState,

//   reducers: {
//     callCalculateStatus: (state, action) => {
//       // state.deviceStats = calculateStats(state.nodes);
//     },
//     setNodes: (state, action) => {
//       const incoming = action.payload;
//       state.nodes = incoming;
//       state.deviceStats = calculateStats(state.nodes);
//     },
//     setCNMSDeviceStats: (state, action) => {
//       const incoming = action.payload;
//       state.nodes = incoming;
//       state.deviceStats = calculateStats(state.nodes);
//     },

//     setRackLayout: (state, action) => {
//       state.rackLayout = (action.payload || []).map((node) =>
//         normalizeReactFlowNode(node, "rackNode")
//       );
//     },
//     setInitialEdges: (state, action) => {
//       state.edges = action.payload;
//     },
//     setEdges: (state, action) => {
//       state.edges = [...state.edges, ...action.payload];
//     },
//     setCurrentViewTopology: (state, action) => {
//       state.currentViewTopology = !state.currentViewTopology;
//     },
//     addNode: (state, action) => {
//       state.nodes = [...state.nodes, ...action.payload];
//     },
//     addNodeToRack: (state, action) => {
//       const safeNodes = (action.payload || []).map((node) =>
//         normalizeReactFlowNode(node, "rackNode")
//       );

//       state.rackLayout = [
//         ...state.rackLayout,
//         ...safeNodes,
//       ];
//     },
//     onNodesChange: (state, action) => {
//       state.nodes = applyNodeChanges(action.payload, state.nodes);
//     },
//     onNodesChangeOfRack: (state, action) => {
//       const updated = applyNodeChanges(
//         action.payload,
//         state.rackLayout
//       );

//       state.rackLayout = updated.map((node) =>
//         normalizeReactFlowNode(node, "rackNode")
//       );
//     },
//     onEdgesChange: (state, action) => {
//       state.edges = applyEdgeChanges(action.payload, state.edges);
//     },
//     setCurrentViewMode: (state, action) => {
//       state.currentViewMode = action.payload;
//     },
//     setTerminalTypes: (state, action) => {
//       state.terminalTypes = action.payload;
//     },
//     setLinkStatusData: (state, action) => {
//       state.linkStatusData = action.payload;
//     },
//     setActiveAction: (state, action) => {
//       state.activeAction = action.payload;
//     },
//     setArrowMenuAnchor: (state, action) => {
//       state.arrowMenuAnchor = action.payload;
//     },
//     updateNodeLabel: (state, action) => {
//       const { id, label, color, borderColor } = action.payload;

//       const updateNodeProperties = (node) => {
//         if (node.id === id || node.data?.resourceId === id) {
//           return {
//             ...node,
//             // 1. Update the data object (Common for custom nodes)
//             data: {
//               ...node.data,
//               label: label,
//               text: label,
//               color: color,
//               bgColor: color,
//               backgroundColor: color,
//               borderColor: borderColor,
//             },
//             // 2. Update the style object (React Flow standard CSS overrides)
//             style: {
//               ...node.style,
//               background: color,
//               backgroundColor: color,
//               borderColor: borderColor,
//             },
//           };
//         }
//         return node;
//       };

//       state.nodes = state.nodes.map(updateNodeProperties);
//       state.rackNodes = state.rackNodes.map(updateNodeProperties);
//     },
//     resetMenuState: (state) => {
//       state.activeAction = "";
//       state.arrowMenuAnchor = null;
//     },
//     setImageNodePortStatusLive: (state, action) => {
//       const { resourceId, lstPortInfoDtl } = action.payload;
//       state.nodes = state.nodes.map((node) => {
//         if (node.data.resourceId === resourceId) {
//           return {
//             ...node,
//             data: {
//               ...node.data,
//               lstPortInfoDtl: lstPortInfoDtl,
//             },
//           };
//         }
//         return node;
//       });

//       state.rackNodes = state.rackNodes.map((node) => {
//         if (node.data.resourceId === resourceId) {
//           return {
//             ...node,
//             data: {
//               ...node.data,
//               lstPortInfoDtl: lstPortInfoDtl,
//             },
//           };
//         }
//         return node;
//       });
//     },
//     updateNodeViewType: (state, action) => {
//       return {
//         ...state,
//         currentNodeView: action.payload,
//         nodes: state.nodes.map((node) => {
//           return {
//             ...node,
//             data: {
//               ...node.data,
//               viewMode: action.payload,
//             },
//           };
//         }),
//       };
//     },
//     updateSwitchTopology: (state, action) => {
//       state.switchTopology = action.payload;
//     },
//     updateNodeStyle: (state, action) => {
//       const { id, style } = action.payload;
//       const node = state.nodes.find((n) => n.id === id);
//       if (node) {
//         node.style = { ...node.style, ...style };
//       }
//     },

//     pushToUndoStack: (state) => {
//       state.undoStack.push({
//         nodes: [...state.nodes],
//         edges: [...state.edges],
//       });
//       state.redoStack = [];
//     },
//     performUndo: (state) => {
//       console.log("perfoem undo called");
//       if (state.undoStack.length > 0) {
//         const lastState = state.undoStack.pop();
//         state.redoStack.push({
//           nodes: [...state.nodes],
//           edges: [...state.edges],
//         });
//         state.nodes = lastState.nodes;
//         state.edges = lastState.edges;
//       }
//     },
//     performRedo: (state) => {
//       if (state.redoStack.length > 0) {
//         const nextState = state.redoStack.pop();
//         state.undoStack.push({
//           nodes: [...state.nodes],
//           edges: [...state.edges],
//         });
//         state.nodes = nextState.nodes;
//         state.edges = nextState.edges;
//       }
//     },
//     // updateNodeStatus: (state, action) => {
//     //   const updatedApiResponse = action.payload;
//     //   const targetId = updatedApiResponse.resourceId;

//     //   const updateNode = (node) => {
//     //     if (node.id === targetId || node.data?.resourceId === targetId) {
//     //       return {
//     //         ...node,

//     //         data: {
//     //           ...node.data,

//     //           ...updatedApiResponse,

//     //           nePollingInfo: {
//     //             ...node.data?.nePollingInfo,
//     //             ...updatedApiResponse.nePollingInfo,
//     //           },

//     //           imResourceType: {
//     //             ...node.data?.imResourceType,
//     //             ...updatedApiResponse.imResourceType,

//     //             imResourceStateInfo: {
//     //               ...node.data?.imResourceType?.imResourceStateInfo,
//     //               ...updatedApiResponse.imResourceType?.imResourceStateInfo,
//     //             },
//     //           },
//     //         },
//     //       };
//     //     }

//     //     return node;
//     //   };

//     //   state.nodes = state.nodes.map(updateNode);
//     //   state.rackNodes = state.rackNodes.map(updateNode);

//     //   // IMPORTANT
//     //   // refresh StatusCard values
//     //   state.deviceStats = calculateStats(state.nodes);
//     // },
//     updateNodeStatus: (state, action) => {
//       const updatedApiResponse = action.payload;
//       const targetId = updatedApiResponse.resourceId;

//       state.nodes = state.nodes.map((node) => {
//         if (
//           node.id !== targetId &&
//           node.data?.resourceId !== targetId
//         ) {
//           return node;
//         }

//         return {
//           ...node,

//           data: {
//             ...node.data,

//             ...updatedApiResponse,

//             nePollingInfo: {
//               ...node.data?.nePollingInfo,
//               ...updatedApiResponse.nePollingInfo,
//             },

//             imResourceType: {
//               ...node.data?.imResourceType,
//               ...updatedApiResponse.imResourceType,

//               imResourceStateInfo: {
//                 ...node.data?.imResourceType?.imResourceStateInfo,
//                 ...updatedApiResponse.imResourceType
//                   ?.imResourceStateInfo,
//               },
//             },
//           },
//         };
//       });

//       state.deviceStats = calculateStats(state.nodes);
//     },

//     updateDiscoveredDeviceStatus: (state, action) => {
//       const updatedDevices = action.payload;

//       if (Array.isArray(updatedDevices)) {
//         updatedDevices.forEach((updatedItem) => {
//           const targetId = updatedItem.resourceId;

//           const index = state.nodes.findIndex(
//             (node) => node.id === targetId || node.data?.resourceId === targetId
//           );

//           if (index !== -1) {
//             state.nodes[index].data = {
//               ...state.nodes[index].data,
//               isDiscovered: updatedItem.isDiscovered,
//               isMaintainance: updatedItem.isMaintainance,
//               status: updatedItem.status,
//               lstPortInfoDtl: updatedItem.lstPortInfoDtl || [],
//             };
//           }

//           const rackIndex = state.rackNodes.findIndex(
//             (node) => node.id === targetId || node.data?.resourceId === targetId
//           );

//           if (rackIndex !== -1) {
//             state.rackNodes[rackIndex].data = {
//               ...state.rackNodes[rackIndex].data,
//               isDiscovered: updatedItem.isDiscovered,
//               isMaintainance: updatedItem.isMaintainance,
//               status: updatedItem.status,
//             };
//           }
//         });
//       }
//       state.deviceStats = calculateStats(state.nodes);
//     },
//     // pushToUndoStackRack: (state) => {
//     //   state.undoStackRack.push({
//     //     rackNodes: [...state.rackNodes],
//     //   });
//     //   state.redoStackRack = [];
//     // },
//     pushToUndoStackRack: (state) => {
//       state.undoStackRack.push({
//         rackLayout: [...state.rackLayout],
//       });

//       state.redoStackRack = [];
//     },
//     performUndoRack: (state) => {
//       if (state.undoStackRack.length === 0) {
//         return;
//       }

//       const lastState = state.undoStackRack.pop();

//       state.redoStackRack.push({
//         rackLayout: [...state.rackLayout],
//       });

//       state.rackLayout = lastState.rackLayout.map((node) =>
//         normalizeReactFlowNode(node, "rackNode")
//       );
//     },
//     performRedoRack: (state) => {
//       if (state.redoStackRack.length === 0) {
//         return;
//       }

//       const nextState = state.redoStackRack.pop();

//       state.undoStackRack.push({
//         rackLayout: [...state.rackLayout],
//       });

//       state.rackLayout = nextState.rackLayout.map((node) =>
//         normalizeReactFlowNode(node, "rackNode")
//       );
//     },
//     //
//     deleteAllNodesAndEdges: (state, action) => {
//       state.nodes = [];
//       state.edges = [];
//     },
//     deleteAllNodesAndEdgesOfRack: (state, action) => {
//       state.rackLayout = [];
//     },
//     updateLinkType: (state, action) => {
//       const { edgeId, type } = action.payload;
//       const typeStyles = {
//         "10GE": {
//           stroke: "grey",

//           strokeWidth: 3,
//           strokeDasharray: "0",
//           animated: false,
//         },
//         "1GE": {
//           stroke: "grey",

//           strokeWidth: 3,
//           strokeDasharray: "3,3",
//           animated: false,
//         },
//         mgmt: {
//           stroke: "grey",

//           strokeWidth: 3,
//           strokeDasharray: "7,7",
//           animated: false,
//         },
//       };

//       state.edges = state.edges.map((e) =>
//         e.id === edgeId
//           ? {
//               ...e,
//               style: {
//                 ...e.style,
//                 // stroke: typeStyles[type].stroke,
//                 strokeWidth: typeStyles[type].strokeWidth,
//                 strokeDasharray: typeStyles[type].strokeDasharray || "0",
//               },
//               animated: typeStyles[type].animated,
//               linkType: type,
//               data: { ...e.data, type },
//             }
//           : e
//       );
//     },
//     updateEdgeColorByContextMenu: (state, action) => {
//       const { edgeId, color } = action.payload;

//       return {
//         ...state,
//         edges: state.edges.map((edge) => {
//           if (edge.id === edgeId) {
//             return {
//               ...edge,
//               style: {
//                 ...edge.style,
//                 stroke: color,
//               },
//             };
//           } else {
//             return edge;
//           }
//         }),
//       };
//     },
//     deleteLink: (state, action) => {
//       const edgeId = action.payload;

//       state.edges = state.edges.filter((edge) => edge.id !== edgeId);
//     },
//     deleteNode: (state, action) => {
//       const nodeId = action.payload;

//       state.nodes = state.nodes.filter((node) => node.id !== nodeId);
//       state.edges = state.edges.filter(
//         (edge) => edge.source !== nodeId && edge.target !== nodeId
//       );
//     },

//     // setAllResourceInfo: (state, action) => {
//     //   const responseData = action.payload;

//     //   if (!Array.isArray(responseData) || responseData.length === 0) {
//     //     return;
//     //   }

//     //   const updatedNodes = state.nodes.map((node) => {
//     //     const apiItem = responseData.find(
//     //       (item) => item.resourceId === node.data.resourceId
//     //     );

//     //     if (!apiItem) return node;

//     //     return {
//     //       ...node,
//     //       data: {
//     //         ...node.data,
//     //         ...apiItem,
//     //         lstPortInfoDtl:
//     //           apiItem.lstPortInfoDtl || node.data.lstPortInfoDtl || [],
//     //         imResourceType: {
//     //           ...node.data.imResourceType,
//     //           ...apiItem.imResourceType,
//     //           imResourceStateInfo: {
//     //             resourceStateId:
//     //               apiItem.imResourceType?.imResourceStateInfo?.resourceStateId,
//     //             resourceStateName: determineStatus(apiItem).resourceStateName,
//     //           },
//     //         },
//     //         isDiscovered: !!apiItem.isDiscovered,
//     //       },
//     //     };
//     //   });

//     //   const updatedRackNodes = state.rackNodes.map((node) => {
//     //     const apiItem = responseData.find(
//     //       (item) => item.resourceId === node.data.resourceId
//     //     );

//     //     if (!apiItem) return node;

//     //     return {
//     //       ...node,
//     //       data: {
//     //         ...node.data,
//     //         ...apiItem,
//     //         lstPortInfoDtl:
//     //           apiItem.lstPortInfoDtl || node.data.lstPortInfoDtl || [],
//     //         imResourceType: {
//     //           ...node.data.imResourceType,
//     //           ...apiItem.imResourceType,
//     //           imResourceStateInfo: {
//     //             resourceStateId:
//     //               apiItem.imResourceType?.imResourceStateInfo?.resourceStateId,
//     //             resourceStateName: determineStatus(apiItem).resourceStateName,
//     //           },
//     //         },
//     //         isDiscovered: !!apiItem.isDiscovered,
//     //       },
//     //     };
//     //   });

//     //   state.allResourceInfo = responseData;
//     //   state.nodes = updatedNodes;
//     //   state.rackNodes = updatedRackNodes;

//     //   // ⭐ This is the missing line

//     //   console.log(updatedNodes, "updatedNodesasasas");

//     //   state.deviceStats = calculateStats(state.nodes);
//     // },

//     setAllResourceInfo: (state, action) => {
//       const responseData = action.payload;

//       if (!Array.isArray(responseData) || responseData.length === 0) {
//         return;
//       }

//       const responseMap = new Map();

//       responseData.forEach((item) => {
//         if (item?.resourceId !== undefined && item?.resourceId !== null) {
//           responseMap.set(String(item.resourceId), item);
//         }
//       });

//       state.nodes = state.nodes.map((node) => {
//         const resourceId = node?.data?.resourceId;

//         if (resourceId === undefined || resourceId === null) {
//           return node;
//         }

//         const apiItem = responseMap.get(String(resourceId));

//         if (!apiItem) {
//           return node;
//         }

//         const currentData = node.data || {};

//         const currentPollingInfo =
//           currentData.nePollingInfo || {};

//         const apiPollingInfo =
//           apiItem.nePollingInfo || {};

//         const currentResourceType =
//           currentData.imResourceType || {};

//         const apiResourceType =
//           apiItem.imResourceType || {};

//         const currentResourceState =
//           currentResourceType.imResourceStateInfo || {};

//         const apiResourceState =
//           apiResourceType.imResourceStateInfo || {};

//         const statusInfo = determineStatus({
//           ...currentData,
//           ...apiItem,
//           nePollingInfo: {
//             ...currentPollingInfo,
//             ...apiPollingInfo,
//           },
//           imResourceType: {
//             ...currentResourceType,
//             ...apiResourceType,
//             imResourceStateInfo: {
//               ...currentResourceState,
//               ...apiResourceState,
//             },
//           },
//         });

//         return {
//           ...node,

//           data: {
//             ...currentData,
//             ...apiItem,

//             // Preserve latest port information
//             lstPortInfoDtl:
//               apiItem.lstPortInfoDtl ??
//               currentData.lstPortInfoDtl ??
//               [],

//             // Preserve/merge polling information
//             nePollingInfo: {
//               ...currentPollingInfo,
//               ...apiPollingInfo,
//             },

//             // Merge resource type information
//             imResourceType: {
//               ...currentResourceType,
//               ...apiResourceType,

//               imResourceStateInfo: {
//                 ...currentResourceState,
//                 ...apiResourceState,

//                 resourceStateName:
//                   statusInfo?.resourceStateName ??
//                   apiResourceState.resourceStateName ??
//                   currentResourceState.resourceStateName,
//               },
//             },

//             isDiscovered:
//               apiItem.isDiscovered !== undefined
//                 ? !!apiItem.isDiscovered
//                 : currentData.isDiscovered,

//             isMaintainance:
//               apiItem.isMaintainance !== undefined
//                 ? !!apiItem.isMaintainance
//                 : currentData.isMaintainance,
//           },
//         };
//       });

//       // Redux is now the single source of truth
//       // for current device information.
//       state.allResourceInfo = responseData;

//       // IMPORTANT:
//       // Do NOT update state.rackNodes here.
//       //
//       // rack nodes are derived from:
//       // state.rackLayout + state.nodes
//       //
//       // Therefore the selector will automatically
//       // receive the latest information.
//       state.deviceStats = calculateStats(state.nodes);
//     },
//     // updateNodeStatusThroughSocket: (state, action) => {
//     //   const {
//     //     isDiscovered,
//     //     isMaintainance,
//     //     resourceIp,
//     //     status,
//     //     isReachable,
//     //     maxSeverity,
//     //     resourceIdVal,
//     //   } = action.payload;

//     //   const updateNodeFields = (node) => {
//     //     if (node.data.resourceId === resourceIdVal) {
//     //       if (isDiscovered && resourceIp !== null) {
//     //         return {
//     //           ...node,
//     //           data: {
//     //             ...node.data, // preserve existing fields
//     //             resourceIp: resourceIp,
//     //             maxSeverity: maxSeverity,
//     //             nePollingInfo: {
//     //               ...node.data.nePollingInfo,
//     //               isReachable: isReachable,
//     //             },
//     //             isDiscovered: isDiscovered,
//     //             imResourceType: {
//     //               ...node.data.imResourceType,
//     //               imResourceStateInfo: {
//     //                 ...node.data.imResourceType?.imResourceStateInfo,
//     //                 resourceStateName: status,
//     //               },
//     //             },
//     //           },
//     //         };
//     //       }
//     //       return node;
//     //     }
//     //     return node;
//     //   };

//     //   state.nodes = state.nodes.map(updateNodeFields);
//     //   state.rackNodes = state.rackNodes.map(updateNodeFields);
//     //   state.deviceStats = calculateStats(state.nodes);
//     // },

//     updateNodeStatusThroughSocket: (state, action) => {
//       const {
//         isDiscovered,
//         isMaintainance,
//         resourceIp,
//         status,
//         isReachable,
//         maxSeverity,
//         resourceIdVal,
//       } = action.payload;

//       state.nodes = state.nodes.map((node) => {
//         if (node?.data?.resourceId !== resourceIdVal) {
//           return node;
//         }

//         return {
//           ...node,

//           data: {
//             ...node.data,

//             resourceIp:
//               resourceIp !== undefined
//                 ? resourceIp
//                 : node.data.resourceIp,

//             maxSeverity:
//               maxSeverity !== undefined
//                 ? maxSeverity
//                 : node.data.maxSeverity,

//             isDiscovered:
//               isDiscovered !== undefined
//                 ? isDiscovered
//                 : node.data.isDiscovered,

//             isMaintainance:
//               isMaintainance !== undefined
//                 ? isMaintainance
//                 : node.data.isMaintainance,

//             nePollingInfo: {
//               ...node.data?.nePollingInfo,

//               isReachable:
//                 isReachable !== undefined
//                   ? isReachable
//                   : node.data?.nePollingInfo?.isReachable,
//             },

//             imResourceType: {
//               ...node.data?.imResourceType,

//               imResourceStateInfo: {
//                 ...node.data?.imResourceType?.imResourceStateInfo,

//                 resourceStateName:
//                   status ??
//                   node.data?.imResourceType?.imResourceStateInfo
//                     ?.resourceStateName,
//               },
//             },
//           },
//         };
//       });

//       state.deviceStats = calculateStats(state.nodes);
//     },

//     setImageNodePortStatus: (state, action) => {
//       state.imagePortStatus = action.payload;

//       console.log("jkdfvimageportstatus", action.payload);

//       // state.nodes = action.payload
//     },
//     saveTopologyState: (state, action) => {
//       const newState = action.payload;

//       if (state.present) {
//         state.past.push(state.present);
//       }

//       state.present = newState;

//       // clear redo stack
//       state.future = [];
//     },
//     undoTopologyState: (state) => {
//       if (state.past.length === 0) return;

//       const previous = state.past.pop();

//       if (state.present) {
//         state.future.unshift(state.present);
//       }

//       state.present = previous;
//     },
//     redoTopologyState: (state) => {
//       if (state.future.length === 0) return;

//       const next = state.future.shift();

//       if (state.present) {
//         state.past.push(state.present);
//       }

//       state.present = next;
//     },
//     resetTopologyHistory: (state) => {
//       state.past = [];
//       state.present = null;
//       state.future = [];
//     },
//     upsertNodeFromSocket: (state, action) => {
//       const incoming = action.payload;
//       const targetResourceId =
//         incoming?.imResourceInfo?.resourceId || incoming?.resourceId;

//       // 1. Process Standard Nodes
//       const index = state.nodes.findIndex(
//         (n) =>
//           n?.data?.resourceId === targetResourceId || n?.id === incoming?.id
//       );

//       let updatedNodes = [...state.nodes];
//       if (index !== -1) {
//         updatedNodes[index] = {
//           ...updatedNodes[index],
//           data: {
//             ...updatedNodes[index]?.data,
//             ...incoming?.imResourceInfo,
//             nePollingInfo: {
//               ...updatedNodes[index]?.data?.nePollingInfo,
//               isReachable: incoming?.isReachable,
//             },
//           },
//         };
//       } else {
//         updatedNodes.push({
//           id: incoming?.id,
//           data: incoming?.imResourceInfo,
//         });
//       }
//       state.nodes = updatedNodes;

//       // 2. Process Rack Nodes
//       const rackIndex = state.rackNodes.findIndex(
//         (n) =>
//           n?.data?.resourceId === targetResourceId || n?.id === incoming?.id
//       );

//       let updatedRackNodes = [...state.rackNodes];
//       if (rackIndex !== -1) {
//         updatedRackNodes[rackIndex] = {
//           ...updatedRackNodes[rackIndex],
//           data: {
//             ...updatedRackNodes[rackIndex]?.data,
//             ...incoming?.imResourceInfo,
//             nePollingInfo: {
//               ...updatedRackNodes[rackIndex]?.data?.nePollingInfo,
//               isReachable: incoming?.isReachable,
//             },
//           },
//         };
//       } else {
//         updatedRackNodes.push(
//           normalizeReactFlowNode(
//             {
//               id: incoming?.id,
//               data: incoming?.imResourceInfo,
//             },
//             "rackNode"
//           )
//         );
//       }
//       state.rackNodes = updatedRackNodes;

//       state.deviceStats = calculateStats(state.nodes);
//     },
//     mergeNodesFromAPI: (state, action) => {
//       const apiNodes = action.payload;

//       const map = new Map();

//       // keep existing nodes first
//       state.nodes.forEach((n) => {
//         map.set(n?.data?.resourceId, n);
//       });

//       apiNodes.forEach((n) => {
//         map.set(n?.data?.resourceId, n);
//       });

//       const merged = Array.from(map.values());

//       state.nodes = merged;
//       state.deviceStats = calculateStats(state.nodes);
//     },
//     // updateResourceStatus: (state, action) => {
//     //   const { resourceId, isDiscovered, isMaintainance } = action.payload;

//     //   const updateFields = (node) => {
//     //     if (node.id === resourceId || node.data?.resourceId === resourceId) {
//     //       return {
//     //         ...node,

//     //         data: {
//     //           ...node.data,

//     //           isDiscovered,

//     //           isMaintainance,
//     //         },
//     //       };
//     //     }

//     //     return node;
//     //   };

//     //   state.nodes = state.nodes.map(updateFields);

//     //   state.rackNodes = state.rackNodes.map(updateFields);

//     //   // refresh StatusCard
//     //   state.deviceStats = calculateStats(state.nodes);
//     // },

//     updateResourceStatus: (state, action) => {
//       const {
//         resourceId,
//         isDiscovered,
//         isMaintainance,
//       } = action.payload;

//       state.nodes = state.nodes.map((node) => {
//         if (
//           node.id === resourceId ||
//           node.data?.resourceId === resourceId
//         ) {
//           return {
//             ...node,

//             data: {
//               ...node.data,

//               isDiscovered,
//               isMaintainance,
//             },
//           };
//         }

//         return node;
//       });

//       state.deviceStats = calculateStats(state.nodes);
//     },

//     updateEdgeConfiguration: (state, action) => {
//       const { edgeId, color, linkId, linkName, linkStatus } = action.payload;

//       state.edges = state.edges.map((edge) => {
//         if (edge.id !== edgeId) return edge;

//         return {
//           ...edge,
//           style: {
//             ...edge.style,
//             stroke: color,
//           },
//           data: {
//             ...edge.data,
//             linkId,
//             linkName,
//             linkStatus,
//           },
//         };
//       });
//     },
//     updateEdgeStatusFromSocket: (state, action) => {
//       const { linkId, linkStatus, linkProperties, resourceId } = action.payload;
//       const color = getEdgeColor(linkStatus);

//       state.edges = state.edges.map((edge) => {
//         // Match using linkId (recommended)
//         if (edge.data?.linkId !== linkId) return edge;

//         return {
//           ...edge,
//           style: {
//             ...edge.style,
//             stroke: color,
//           },
//           data: {
//             ...edge.data,
//             linkStatus,
//             linkProperties,
//             resourceId,
//           },
//         };
//       });
//     },
//     updateLinkStatusFromSocket: (state, action) => {
//       const { linkId, linkStatus } = action.payload;

//       const link = state.linkStatusData.find((item) => item.linkId === linkId);

//       if (link) {
//         link.linkStatus = linkStatus;
//       }

//       state.linkStatusData = state.linkStatusData.map((link) => {
//         if (link.linkId !== action.payload.linkId) return link;

//         return {
//           ...link,

//           linkStatus: action.payload.linkStatus,
//         };
//       });
//     },
//     hydrateRackFromSavedTopology: (state, action) => {
//       const savedRackNodes = action.payload || [];

//       state.rackLayout = savedRackNodes.map((node) =>
//         normalizeReactFlowNode(node, "rackNode")
//       );
//     },
//     hydrateTopologyFromSavedTopology: (state, action) => {
//       const savedTopology = action.payload || {};

//       state.topologyLayout = (savedTopology.nodes || []).map((node) =>
//         normalizeReactFlowNode(node, "commonNode")
//       );

//       state.edges = Array.isArray(savedTopology.edges)
//         ? savedTopology.edges
//         : [];
//     },
//   },
// });

// export const selectRackNodes = (state) => {
//   const topologyState = state.topologySlice;

//   const nodes = topologyState?.nodes || [];
//   const rackLayout = topologyState?.rackLayout || [];

//   if (!Array.isArray(rackLayout)) {
//     return [];
//   }

//   const deviceMap = new Map();

//   nodes.forEach((node) => {
//     const resourceId = node?.data?.resourceId;

//     if (resourceId !== undefined && resourceId !== null) {
//       deviceMap.set(String(resourceId), node);
//     }
//   });

//   return rackLayout.map((layoutNode) => {
//     const resourceId = layoutNode?.data?.resourceId;

//     const currentDevice = deviceMap.get(String(resourceId));

//     if (!currentDevice) {
//       return normalizeReactFlowNode(
//         layoutNode,
//         "rackNode"
//       );
//     }

//     return normalizeReactFlowNode(
//       {
//         ...layoutNode,

//         // JSON/layout information
//         id: layoutNode.id,
//         type: layoutNode.type || "rackNode",
//         position: layoutNode.position,

//         // Latest Redux device information
//         data: {
//           ...layoutNode.data,
//           ...currentDevice.data,
//         },
//       },
//       "rackNode"
//     );
//   });
// };

// export const selectTopologyNodes = (state) => {
//   const topologyState = state.topologySlice;

//   const nodes = topologyState?.nodes || [];
//   const topologyLayout = topologyState?.topologyLayout || [];

//   if (!Array.isArray(topologyLayout)) {
//     return [];
//   }

//   const deviceMap = new Map();

//   nodes.forEach((node) => {
//     const resourceId = node?.data?.resourceId;

//     if (resourceId !== undefined && resourceId !== null) {
//       deviceMap.set(String(resourceId), node);
//     }
//   });

//   return topologyLayout.map((layoutNode) => {
//     const resourceId = layoutNode?.data?.resourceId;

//     const currentDevice = deviceMap.get(String(resourceId));

//     if (!currentDevice) {
//       return normalizeReactFlowNode(
//         layoutNode,
//         "commonNode"
//       );
//     }

//     return normalizeReactFlowNode(
//       {
//         ...layoutNode,

//         // Saved topology/layout information
//         id: layoutNode.id,
//         type: layoutNode.type || "commonNode",
//         position: layoutNode.position,

//         // Latest Redux device information
//         data: {
//           ...layoutNode.data,
//           ...currentDevice.data,
//         },
//       },
//       "commonNode"
//     );
//   });
// };

// export const selectCanUndo = (state) => state.topologySlice.past.length > 0;

// export const selectCanRedo = (state) => state.topologySlice.future.length > 0;

// export const selectPresentTopology = (state) => state.topologySlice.present;

// export const {
//   setNodes,
//   setCNMSDeviceStats,
//   setRackNode,
//   setEdges,
//   addNode,
//   onNodesChange,
//   onEdgesChange,
//   pushToUndoStack,
//   performUndo,
//   performRedo,
//   updateNodeStatus,
//   // rack
//   pushToUndoStackRack,
//   performRedoRack,
//   performUndoRack,
//   deleteAllNodesAndEdges,
//   deleteAllNodesAndEdgesOfRack,
//   updateNodeViewType,
//   updateLinkType,
//   deleteLink,
//   deleteNode,
//   setAllResourceInfo,
//   updateNodeStyle,
//   setCurrentViewTopology,
//   addNodeToRack,
//   onNodesChangeOfRack,
//   setInitialEdges,
//   updateEdgeColorByContextMenu,
//   updateNodeStatusThroughSocket,
//   setImageNodePortStatus,
//   setImageNodePortStatusLive,
//   setCurrentViewMode,
//   setTerminalTypes,
//   updateNodeLabel,

//   upsertNodeFromSocket,
//   mergeNodesFromAPI,

//   updateEdgeConfiguration,
//   updateEdgeStatusFromSocket,
//   setLinkStatusData,
//   updateLinkStatusFromSocket,

//   updateSwitchTopology,
//   updateDiscoveredDeviceStatus,
//   saveTopologyState,
//   undoTopologyState,
//   redoTopologyState,
//   resetTopologyHistory,
//   updateResourceStatus,
//   setActiveAction,
//   setArrowMenuAnchor,
//   resetMenuState,
//   callCalculateStatus,
//   hydrateRackFromSavedTopology,
//   hydrateTopologyFromSavedTopology,
//   setRackLayout
// } = topologyNodes.actions;

// export default topologyNodes.reducer;

// /* eslint-disable no-unused-vars */

// import { createSlice } from "@reduxjs/toolkit";
// import {
//   applyEdgeChanges,
//   applyNodeChanges,
// } from "@xyflow/react";
// import { determineStatus } from "./utils";

// const initialState = {
//   nodes: [], //nodes inTopology
//   edges: [],
//   currentViewTopology: true,
//   rackNodes: [], //nodes in rack
//   undoStack: [],
//   redoStack: [],
//   undoStackRack: [],
//   redoStackRack: [],
//   canUndo: false,
//   canRedo: false,
//   canUndoRack: false,
//   canRedoRack: false,
//   currentNodeView: "simpleViewNode",
//   allResourceInfo: [],
//   imagePortStatus: [],
//   currentViewMode: "reactflow",
//   terminalTypes: [],
//   past: [],
//   present: null,
//   future: [],
//   deviceStats: {
//     online: 0,
//     offline: 0,
//     maintenance: 0,
//     undiscovered: 0,
//     unmanaged: 0,
//   },
// };

// const getUnifiedDevice = (node) => {
//   // API format (node.data)
//   const data = node?.data ?? node;

//   const isReachable =
//     data?.nePollingInfo?.isReachable ??
//     node?.isReachable ??
//     false;

//   const isDiscovered =
//     data?.isDiscovered ??
//     false;

//   const isMaintainance =
//     data?.isMaintainance ??
//     false;

//   const resourceStateId =
//     data?.imResourceType?.imResourceStateInfo?.resourceStateId;

//   return {
//     isReachable,
//     isDiscovered,
//     isMaintainance,
//     resourceStateId,
//   };
// };

// export const determineStatusRedux = (node) => {
//   const {
//     isReachable,
//     isDiscovered,
//     isMaintainance,
//     resourceStateId,
//   } = getUnifiedDevice(node);

//   // unmanaged (highest priority)
//   if (resourceStateId === 2) return "unmanaged";

//   if (isReachable && isDiscovered) return "online";

//   if (isReachable && !isDiscovered) return "offline";

//   if (!isDiscovered && isMaintainance) return "maintenance";

//   if (!isDiscovered && !isMaintainance) return "undiscovered";

//   return "offline";
// };

// const calculateStats = (nodes) => {
//   const stats = {
//     online: 0,
//     offline: 0,
//     maintenance: 0,
//     undiscovered: 0,
//     unmanaged: 0,
//   };

//   for (const node of nodes) {
//     const status = determineStatusRedux(node);

//     if (stats[status] !== undefined) {
//       stats[status]++;
//     }
//   }

//   return stats;
// };

// const topologyNodes = createSlice({
//   name: "topologyNodes",
//   initialState,

//   reducers: {
//     // setNodes: (state, action) => {
//     //   // set initial nodes to store
//     //   console.log(action.payload, "ybbfcj");
//     //   state.nodes = action.payload;
//     // },
//     setNodes: (state, action) => {
//       const incoming = action.payload;

//       state.nodes = incoming;

//       state.deviceStats = calculateStats(incoming);
//     },
//     setRackNode: (state, action) => {
//       state.rackNodes = action.payload;
//     },
//     setInitialEdges: (state, action) => {
//       state.edges = action.payload;
//     },
//     setEdges: (state, action) => {
//       state.edges = [...state.edges, ...action.payload];
//     },
//     setCurrentViewTopology: (state, action) => {
//       state.currentViewTopology = !state.currentViewTopology;
//     },
//     addNode: (state, action) => {
//       state.nodes = [...state.nodes, ...action.payload];
//     },
//     addNodeToRack: (state, action) => {
//       state.rackNodes = [...state.rackNodes, ...action.payload];
//     },
//     onNodesChange: (state, action) => {
//       state.nodes = applyNodeChanges(action.payload, state.nodes);
//     },
//     onNodesChangeOfRack: (state, action) => {
//       state.rackNodes = applyNodeChanges(action.payload, state.rackNodes);
//     },
//     onEdgesChange: (state, action) => {
//       state.edges = applyEdgeChanges(action.payload, state.edges);
//     },
//     setCurrentViewMode: (state, action) => {
//       state.currentViewMode = action.payload;
//     },
//     setTerminalTypes: (state, action) => {
//       state.terminalTypes = action.payload;
//     },
//     setImageNodePortStatusLive: (state, action) => {
//       const { resourceId, lstPortInfoDtl } = action.payload;
//       state.nodes = state.nodes.map((node) => {
//         if (node.data.resourceId === resourceId) {
//           return {
//             ...node,
//             data: {
//               ...node.data,
//               lstPortInfoDtl: lstPortInfoDtl,
//             },
//           };
//         }
//         return node;
//       });

//       state.rackNodes = state.rackNodes.map((node) => {
//         if (node.data.resourceId === resourceId) {
//           return {
//             ...node,
//             data: {
//               ...node.data,
//               lstPortInfoDtl: lstPortInfoDtl,
//             },
//           };
//         }
//         return node;
//       });
//     },
//     updateNodeViewType: (state, action) => {
//       console.log(action.payload, "actionddddd");

//       return {
//         ...state,
//         currentNodeView: action.payload,
//         nodes: state.nodes.map((node) => {
//           return {
//             ...node,
//             data: {
//               ...node.data,
//               viewMode: action.payload,
//             },
//           };
//         }),
//       };
//     },
//     updateNodeStyle: (state, action) => {
//       const { id, style } = action.payload;
//       const node = state.nodes.find((n) => n.id === id);
//       if (node) {
//         node.style = { ...node.style, ...style };
//       }
//     },

//     pushToUndoStack: (state) => {
//       state.undoStack.push({
//         nodes: [...state.nodes],
//         edges: [...state.edges],
//       });
//       state.redoStack = [];
//     },
//     performUndo: (state) => {
//       console.log("perfoem undo called");
//       if (state.undoStack.length > 0) {
//         const lastState = state.undoStack.pop();
//         state.redoStack.push({
//           nodes: [...state.nodes],
//           edges: [...state.edges],
//         });
//         state.nodes = lastState.nodes;
//         state.edges = lastState.edges;
//       }
//     },
//     performRedo: (state) => {
//       if (state.redoStack.length > 0) {
//         const nextState = state.redoStack.pop();
//         state.undoStack.push({
//           nodes: [...state.nodes],
//           edges: [...state.edges],
//         });
//         state.nodes = nextState.nodes;
//         state.edges = nextState.edges;
//       }
//     },
//     updateNodeStatus: (state, action) => {
//       const updatedApiResponse = action.payload;
//       const targetId = updatedApiResponse.resourceId;

//       const index = state.nodes.findIndex(
//         (node) => node.id === targetId || node.data?.resourceId === targetId
//       );

//       if (index !== -1) {
//         const node = state.nodes[index];

//         state.nodes[index].data = {
//           ...node.data,
//           imResourceType: {
//             ...node.data.imResourceType,

//             imResourceStateInfo: {
//               ...node.data.imResourceType?.imResourceStateInfo,
//               resourceStateName:
//                 updatedApiResponse.imResourceStateInfo?.resourceStateName ||
//                 "Managed",
//             },
//           },

//           isDiscovered: updatedApiResponse.isDiscovered,
//           isMaintainance: updatedApiResponse.isMaintainance,
//           status: updatedApiResponse.status,
//         };
//       }
//     },

//     updateDiscoveredDeviceStatus: (state, action) => {
//       const updatedDevices = action.payload;

//       if (Array.isArray(updatedDevices)) {
//         updatedDevices.forEach((updatedItem) => {
//           const targetId = updatedItem.resourceId;

//           const index = state.nodes.findIndex(
//             (node) => node.id === targetId || node.data?.resourceId === targetId
//           );

//           if (index !== -1) {
//             state.nodes[index].data = {
//               ...state.nodes[index].data,
//               isDiscovered: updatedItem.isDiscovered,
//               isMaintainance: updatedItem.isMaintainance,
//               status: updatedItem.status,
//             };
//           }
//         });
//       }
//     },
//     pushToUndoStackRack: (state) => {
//       state.undoStackRack.push({
//         rackNodes: [...state.rackNodes],
//       });
//       state.redoStackRack = [];
//     },
//     performUndoRack: (state) => {
//       if (state.undoStackRack.length > 0) {
//         const lastState = state.undoStackRack.pop();
//         state.redoStackRack.push({
//           rackNodes: [...state.rackNodes],
//         });
//         state.rackNodes = lastState.rackNodes;
//       }
//     },
//     performRedoRack: (state) => {
//       if (state.redoStackRack.length > 0) {
//         const nextState = state.redoStackRack.pop();
//         state.undoStackRack.push({
//           rackNodes: [...state.rackNodes],
//         });
//         state.rackNodes = nextState.rackNodes;
//       }
//     },
//     //
//     deleteAllNodesAndEdges: (state, action) => {
//       state.nodes = [];
//       state.edges = [];
//     },
//     deleteAllNodesAndEdgesOfRack: (state, action) => {
//       state.rackNodes = [];
//     },
//     updateLinkType: (state, action) => {
//       const { edgeId, type } = action.payload;
//       const typeStyles = {
//         "10GE": {
//           stroke: "grey",

//           strokeWidth: 3,
//           strokeDasharray: "0",
//           animated: false,
//         },
//         "1GE": {
//           stroke: "grey",

//           strokeWidth: 3,
//           strokeDasharray: "3,3",
//           animated: false,
//         },
//         mgmt: {
//           stroke: "grey",

//           strokeWidth: 3,
//           strokeDasharray: "7,7",
//           animated: false,
//         },
//       };

//       state.edges = state.edges.map((e) =>
//         e.id === edgeId
//           ? {
//               ...e,
//               style: {
//                 ...e.style,
//                 // stroke: typeStyles[type].stroke,
//                 strokeWidth: typeStyles[type].strokeWidth,
//                 strokeDasharray: typeStyles[type].strokeDasharray || "0",
//               },
//               animated: typeStyles[type].animated,
//               linkType: type,
//               data: { ...e.data, type },
//             }
//           : e
//       );
//     },
//     updateEdgeColorByContextMenu: (state, action) => {
//       const { edgeId, color } = action.payload;

//       return {
//         ...state,
//         edges: state.edges.map((edge) => {
//           if (edge.id === edgeId) {
//             return {
//               ...edge,
//               style: {
//                 ...edge.style,
//                 stroke: color,
//               },
//             };
//           } else {
//             return edge;
//           }
//         }),
//       };
//     },
//     deleteLink: (state, action) => {
//       const edgeId = action.payload;

//       state.edges = state.edges.filter((edge) => edge.id !== edgeId);
//     },
//     deleteNode: (state, action) => {
//       const nodeId = action.payload;

//       state.nodes = state.nodes.filter((node) => node.id !== nodeId);
//       state.edges = state.edges.filter(
//         (edge) => edge.source !== nodeId && edge.target !== nodeId
//       );
//     },

//     setAllResourceInfo: (state, action) => {
//       const responseData = action.payload;
//       if (!Array.isArray(responseData) || responseData.length === 0) {
//         console.warn("Payload is not a valid array or is empty.");
//         return state;
//       }

//       return {
//         ...state,
//         allResourceInfo: responseData,
//         nodes: state.nodes.map((node) => {
//           const apiItem = responseData.find(
//             (dataItem) => dataItem?.resourceId === node.data.resourceId
//           );
//           if (!apiItem) return node;

//           return {
//             ...node,
//             data: {
//               ...node.data, // preserve existing fields: type, switchTemplateKey, etc.
//               ...apiItem, // overwrite with API data
//               lstPortInfoDtl:
//                 apiItem.lstPortInfoDtl || node.data.lstPortInfoDtl || [],
//               imResourceType: {
//                 ...node.data.imResourceType,
//                 ...apiItem.imResourceType,
//                 imResourceStateInfo: {
//                   resourceStateId:
//                     apiItem.imResourceType?.imResourceStateInfo
//                       ?.resourceStateId,
//                   resourceStateName: determineStatus(apiItem).resourceStateName,
//                 },
//               },
//               isDiscovered: !!apiItem.isDiscovered,
//             },
//           };
//         }),
//         rackNodes: state.rackNodes.map((node) => {
//           const apiItem = responseData.find(
//             (dataItem) => dataItem?.resourceId === node.data.resourceId
//           );
//           if (!apiItem) return node;

//           return {
//             ...node,
//             data: {
//               ...node.data,
//               ...apiItem,
//               lstPortInfoDtl:
//                 apiItem.lstPortInfoDtl || node.data.lstPortInfoDtl || [],
//               imResourceType: {
//                 ...node.data.imResourceType,
//                 ...apiItem.imResourceType,
//                 imResourceStateInfo: {
//                   resourceStateId:
//                     apiItem.imResourceType?.imResourceStateInfo
//                       ?.resourceStateId,
//                   resourceStateName: determineStatus(apiItem).resourceStateName,
//                 },
//               },
//               isDiscovered: !!apiItem.isDiscovered,
//             },
//           };
//         }),
//       };
//     },

//     updateNodeStatusThroughSocket: (state, action) => {
//       const { discovered, resourceIp, status, isReachable,maxSeverity, resourceIdVal } =
//         action.payload;

//       return {
//         ...state,
//         nodes: state.nodes.map((node) => {
//           if (node.data.resourceId === resourceIdVal) {
//             return {
//               ...node,
//               data: {
//                 ...node.data, // preserve existing fields
//                 resourceIp: resourceIp ?? node.data.resourceIp,
//                 maxSeverity: maxSeverity ?? node.data.maxSeverity,
//                 nePollingInfo: {
//                   ...node.data.nePollingInfo,
//                   isReachable: isReachable,
//                 },
//                 isDiscovered: discovered ?? node.data.isDiscovered,
//                 imResourceType: {
//                   ...node.data.imResourceType,
//                   imResourceStateInfo: {
//                     ...node.data.imResourceType?.imResourceStateInfo,
//                     resourceStateName:
//                       status ??
//                       node.data.imResourceType?.imResourceStateInfo
//                         ?.resourceStateName,
//                   },
//                 },
//               },
//             };
//           }
//           return node;
//         }),
//       };
//     },

//     setImageNodePortStatus: (state, action) => {
//       state.imagePortStatus = action.payload;

//       console.log("jkdfvimageportstatus", action.payload);

//       // state.nodes = action.payload
//     },
//     saveTopologyState: (state, action) => {
//       const newState = action.payload;

//       if (state.present) {
//         state.past.push(state.present);
//       }

//       state.present = newState;

//       // clear redo stack
//       state.future = [];
//     },
//     undoTopologyState: (state) => {
//       if (state.past.length === 0) return;

//       const previous = state.past.pop();

//       if (state.present) {
//         state.future.unshift(state.present);
//       }

//       state.present = previous;
//     },
//     redoTopologyState: (state) => {
//       if (state.future.length === 0) return;

//       const next = state.future.shift();

//       if (state.present) {
//         state.past.push(state.present);
//       }

//       state.present = next;
//     },
//     resetTopologyHistory: (state) => {
//       state.past = [];
//       state.present = null;
//       state.future = [];
//     },
//     upsertNodeFromSocket: (state, action) => {
//       const incoming = action.payload;

//       const index = state.nodes.findIndex(
//         (n) =>
//           n?.data?.resourceId === incoming?.imResourceInfo?.resourceId ||
//           n?.data?.resourceId === incoming?.resourceId ||
//           n?.id === incoming?.id
//       );

//       let updatedNodes;

//       if (index !== -1) {
//         updatedNodes = [...state.nodes];
//         updatedNodes[index] = {
//           ...updatedNodes[index],
//           data: {
//             ...updatedNodes[index]?.data,
//             ...incoming?.imResourceInfo,
//             nePollingInfo: {
//               ...updatedNodes[index]?.data?.nePollingInfo,
//               isReachable: incoming?.isReachable,
//             },
//           },
//         };
//       } else {
//         // fallback insert (rare case)
//         updatedNodes = [
//           ...state.nodes,
//           {
//             id: incoming?.id,
//             data: incoming?.imResourceInfo,
//           },
//         ];
//       }

//       state.nodes = updatedNodes;
//       state.deviceStats = calculateStats(updatedNodes);
//     },
//     mergeNodesFromAPI: (state, action) => {
//       const apiNodes = action.payload;

//       const map = new Map();

//       // keep existing nodes first
//       state.nodes.forEach((n) => {
//         map.set(n?.data?.resourceId, n);
//       });

//       apiNodes.forEach((n) => {
//         map.set(n?.data?.resourceId, n);
//       });

//       const merged = Array.from(map.values());

//       state.nodes = merged;
//       state.deviceStats = calculateStats(merged);
//     },
//   },

// });

// export const selectCanUndo = (state) =>
//   state.topologySlice.past.length > 0;

// export const selectCanRedo = (state) =>
//   state.topologySlice.future.length > 0;

// export const selectPresentTopology = (state) =>
//   state.topologySlice.present;

// export const {
//   setNodes,
//   setRackNode,
//   setEdges,
//   addNode,
//   onNodesChange,
//   onEdgesChange,
//   pushToUndoStack,
//   performUndo,
//   performRedo,
//   updateNodeStatus,
//   // rack
//   pushToUndoStackRack,
//   performRedoRack,
//   performUndoRack,
//   deleteAllNodesAndEdges,
//   deleteAllNodesAndEdgesOfRack,
//   updateNodeViewType,
//   updateLinkType,
//   deleteLink,
//   deleteNode,
//   setAllResourceInfo,
//   updateNodeStyle,
//   setCurrentViewTopology,
//   addNodeToRack,
//   onNodesChangeOfRack,
//   setInitialEdges,
//   updateEdgeColorByContextMenu,
//   updateNodeStatusThroughSocket,
//   setImageNodePortStatus,
//   setImageNodePortStatusLive,
//   setCurrentViewMode,
//   setTerminalTypes,

//   upsertNodeFromSocket,
// mergeNodesFromAPI,

//   updateDiscoveredDeviceStatus,
//   saveTopologyState,
//   undoTopologyState,
//   redoTopologyState,
//   resetTopologyHistory
// } = topologyNodes.actions;

// export default topologyNodes.reducer;
