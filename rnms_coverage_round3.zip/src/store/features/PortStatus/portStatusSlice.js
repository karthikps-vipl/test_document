/* eslint-disable no-unused-vars */
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  availableResources: [],
  webSocketPortStatus: [],
};

const portStatusSlice = createSlice({
  name: "portStatusSlice",
  initialState,
  reducers: {
    // setAvailableResources: (state, action) => {
    //   state.availableResources = action.payload;
    // },
    setAvailableResources: (state, action) => {
      state.availableResources = action.payload.map((device) => ({
        ...device,
    
        lstPortInfoDtl: (device.lstPortInfoDtl || []).map((port) => ({
          ...port,
    
          // If API doesn't provide ifdesc, create fallback name
          ifdesc:
            port.ifdesc?.trim?.() ||
            port.ifportname?.trim?.() ||
            `port-${port.ifindex}`,
        })),
      }));
    },
    // setwebSocketPortStatus: (state, action) => {
    //   state.webSocketPortStatus = action.payload;
    
    //   const wsData = action.payload;
    
    //   console.log("hdgwsData", wsData);
    
    //   const device = state.availableResources.find(
    //     (device) => device.resourceId === wsData.resourceId
    //   );
    
    //   if (!device) return;
    
    //   const port = device.lstPortInfoDtl.find(
    //     (port) => port.ifindex === wsData.ifindex
    //   );
    
    //   if (port) {
    //     Object.assign(port, wsData); // ✅ merge WS into API
    //   }  
    // }
    setwebSocketPortStatus: (state, action) => {
      const wsData = action.payload;
    
      console.log("hdgwsData", wsData);
    
      state.webSocketPortStatus = wsData;
    
      const device = state.availableResources.find(
        (device) => device.resourceId === wsData.resourceId
      );
    
      if (!device) return;
    
      // Make sure the port list always exists
      if (!device.lstPortInfoDtl) {
        device.lstPortInfoDtl = [];
      }
    
      const portIndex = device.lstPortInfoDtl.findIndex(
        (port) => Number(port.ifindex) === Number(wsData.ifindex)
      );
    
      /*
       * IMPORTANT:
       * WebSocket sometimes sends ifdesc = null.
       *
       * Never allow null/empty ifdesc to overwrite the existing
       * port name.
       *
       * If there is no existing name, create:
       *     port-1
       *     port-2
       *     port-24
       *     etc.
       */
      const existingPort =
        portIndex !== -1 ? device.lstPortInfoDtl[portIndex] : null;
    
      const fallbackIfdesc =
        wsData.ifdesc?.trim?.() ||
        existingPort?.ifdesc?.trim?.() ||
        `port-${wsData.ifindex}`;
    
      const updatedPort = {
        ...(existingPort || {}),
        ...wsData,
    
        // NEVER allow null ifdesc
        ifdesc: fallbackIfdesc,
    
        // Keep ifindex as the stable port identity
        ifindex: wsData.ifindex,
      };
    
      if (portIndex !== -1) {
        // Update the existing port
        device.lstPortInfoDtl[portIndex] = updatedPort;
      } else {
        /*
         * If the WebSocket sends a port that doesn't exist
         * in the API list, add it instead of allowing it to disappear.
         */
        device.lstPortInfoDtl.push(updatedPort);
      }
    
      console.log(
        "Updated port:",
        updatedPort.ifindex,
        updatedPort.ifdesc,
        updatedPort.adminstatus,
        updatedPort.opstatus
      );
    },
  },
});

export const { setAvailableResources, setwebSocketPortStatus } =
  portStatusSlice.actions;

export default portStatusSlice.reducer;
