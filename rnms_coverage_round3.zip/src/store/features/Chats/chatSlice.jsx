import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  active: "Broadcast",
  conversations: {
    Broadcast: [],
  },

  isCnms: false,
  selfName: "",
  unread: 0,

  ackChat: {},
  ackChatForCnms: {},

  typing: {},

  notificationEnabled: true,
  chatOpen: false,
  chatBackendURL: "",
};

const chatSlice = createSlice({
  name: "chat",
  initialState,

  reducers: {
    configureChat: (state, action) => {
      state.isCnms = action.payload.isCnms;
      state.selfName = action.payload.selfName;

      if (!action.payload.isCnms) {
        state.active = "Broadcast";
      }
    },

    setActiveChat: (state, action) => {
      state.active = action.payload;
    },

    receiveChatMessage: (state, action) => {
      const { conversation, message } = action.payload;

      if (!state.conversations[conversation]) {
        state.conversations[conversation] = [];
      }

      const exists = state.conversations[conversation].some(
        (item) => String(item.id) === String(message.id)
      );

      if (!exists) {
        state.conversations[conversation].push(message);
      }
    },

    setTypingStatus: (state, action) => {
      const { conversation, typing } = action.payload;
      state.typing[conversation] = typing;
    },

    setUnreadCount: (state, action) => {
      state.unread = action.payload;
    },

    incrementUnread: (state) => {
      state.unread += 1;
    },

    resetUnread: (state) => {
      state.unread = 0;
    },

    setAckChat: (state, action) => {
      state.ackChat = action.payload || {};
    },

    setAckChatForCnms: (state, action) => {
      state.ackChatForCnms = action.payload || {};
    },

    setNotificationEnabled: (state, action) => {
      state.notificationEnabled = action.payload;
    },

    clearConversation: (state, action) => {
      state.conversations[action.payload] = [];
    },

    removeConversation: (state, action) => {
      delete state.conversations[action.payload];

      if (state.active === action.payload) {
        state.active = "Broadcast";
      }
    },

    setChatOpen: (state, action) => {
      state.chatOpen = action.payload;
    },
    setChatBackendUrl: (state, action) => {
      state.chatBackendURL = action.payload;
    },
  },
});

export const {
  configureChat,
  setActiveChat,
  receiveChatMessage,
  setTypingStatus,
  setUnreadCount,
  incrementUnread,
  resetUnread,
  setAckChat,
  setAckChatForCnms,
  setNotificationEnabled,
  clearConversation,
  removeConversation,
  setChatOpen,
  setChatBackendUrl,
} = chatSlice.actions;

export default chatSlice.reducer;
