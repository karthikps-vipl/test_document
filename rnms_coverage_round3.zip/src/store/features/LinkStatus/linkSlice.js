import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  links: [], // This will hold your JSON array
  loading: false,
  error: null,
};

const linkSlice = createSlice({
  name: "linkSlice",
  initialState,
  reducers: {
    // Action to set the entire array of links
    setLinks: (state, action) => {
      state.links = action.payload;
      state.loading = false;
    },
    // Action to clear links (useful for logout)
    clearLinks: (state) => {
      state.links = [];
    },
    // Optional: Loading states
    setLinksLoading: (state, action) => {
      state.loading = action.payload;
    }
  },
});

export const { setLinks, clearLinks, setLinksLoading } = linkSlice.actions;
export default linkSlice.reducer;