import { createSlice } from "@reduxjs/toolkit";

const INITIAL_STATUS = 3; // 0=DOWN, 1=UP, 2=OPERATIONALLY DOWN, 3=UNKNOWN

const cnmsSlice = createSlice({
  name: "cnmsStatus",

  initialState: {
    healthStatus: INITIAL_STATUS,
    lastUpdateTime: null,
    cnmsLinkAvailable: false,
  },

  reducers: {
    setHealthStatus: (state, action) => {
      state.healthStatus = action.payload.status;
      state.lastUpdateTime = action.payload.timestamp;
      console.log("healthStatus",state.healthStatus)
    },

    setCnmsLinkAvailable: (state, action) => {
      state.cnmsLinkAvailable = action.payload;

      console.log("cnmsLinkAvailable in redux ",state.cnmsLinkAvailable)
    },
  },
});

export const {
  setHealthStatus,
  resetStatus,
  setCnmsLinkAvailable
} = cnmsSlice.actions;

export default cnmsSlice.reducer;