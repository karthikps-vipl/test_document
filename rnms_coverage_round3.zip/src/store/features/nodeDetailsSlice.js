/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Topology 
   File Name                : nodeDetailsSlice.js
   Author                   : ARUN - VIPL
   Package                  : src\store\features\Topology\nodeDetailsSlice.js
   Purpose                  : Manages the global Redux state for detailed information 
                               regarding specific nodes selected within the topology view.
   Created Date             : 15-04-2026
 ***********************************************************************************************/

// import { createSlice } from "@reduxjs/toolkit";

// const initialState = {
//   siteDetails: null,
//   repDetails: null,
//   savedRnmsDetails: null,
//   isCnms:false
// };

// const nodeDetailsSlice = createSlice({
//   name: "nodeDetails",
//   initialState,
//   reducers: {
//     setDeployedSiteDetails: (state, action) => {
//       state.siteDetails = action.payload;
//     },
//     setRepDetails: (state, action) => {
//       state.repDetails = action.payload;
//     },
//     setSavedRnmsDetails: (state, action) => {
//       state.savedRnmsDetails = action.payload;
//     },
//     setIsCnms: (state, action) => {
//       state.isCnms = action.payload
//     }
//   },
// });

// export const {
//   setDeployedSiteDetails,
//   setRepDetails,
//   setSavedRnmsDetails,
//   setIsCnms,
// } = nodeDetailsSlice.actions;
// export default nodeDetailsSlice.reducer;

import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  siteDetails: null,
  repDetails: null,
  savedRnmsDetails: null,
  isCnms: false,
  allTerminalTypeDetails: [],
};

const nodeDetailsSlice = createSlice({
  name: "nodeDetails",
  initialState,

  reducers: {
    setDeployedSiteDetails: (state, action) => {
      state.siteDetails = action.payload;
    },

    setRepDetails: (state, action) => {
      state.repDetails = action.payload;
    },

    setSavedRnmsDetails: (state, action) => {
      state.savedRnmsDetails = action.payload;
    },

    setIsCnms: (state, action) => {
      state.isCnms = action.payload;
    },
    updateCnmsDetailsFromSidebar: (state, action) => {
      const incomingData = action.payload;

      // Safety check: ensure incomingData is an array before iterating
      if (!Array.isArray(incomingData)) return;

      incomingData.forEach((newItem) => {
        const existingIndex = state.repDetails.findIndex(
          (existing) => existing.id === newItem.id
        );

        if (existingIndex !== -1) {
          state.repDetails[existingIndex] = {
            ...state.repDetails[existingIndex],
            ...newItem,
          };
        }
      });
    },
    setAllTerminalTypeDetails: (state, action) => {
      state.allTerminalTypeDetails = action.payload;
    },
    updateRnmsLatLong: (state, action) => {
      if (state?.repDetails) {
        state.repDetails.latitude = action.payload.latitude;
        state.repDetails.longitude = action.payload.longitude;
      }
    },
  },
});

export const {
  setDeployedSiteDetails,
  setRepDetails,
  setSavedRnmsDetails,
  setIsCnms,
  updateCnmsDetailsFromSidebar,
  setAllTerminalTypeDetails,
  updateRnmsLatLong,
} = nodeDetailsSlice.actions;

export default nodeDetailsSlice.reducer;
