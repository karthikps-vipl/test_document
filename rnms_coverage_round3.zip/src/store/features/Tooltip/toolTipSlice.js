/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Tooltip
   File Name                : toolTipSlice.js
   Author                   : ARUN - VIPL
   Package                  : src\store\features\Tooltip\toolTipSlice.js
   Purpose                  : Manages the global Redux state for topology tooltips, 
                               including visibility, position, and content data.
   Created Date             : 27-03-2026
 ***********************************************************************************************/ import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  toolTipOptions: [],
  mapTooltipOptions: {},
  topologyToolTipOptions: {},
};

const toolTipOptionsSlice = createSlice({
  name: "toolTipOptionsSlice",
  initialState,
  reducers: {
    setToolTipOptions: (state, action) => {
      state.toolTipOptions = action.payload;
      action.payload.map((item) => {
        if (item.id === 2) {
          state.topologyToolTipOptions = JSON.parse(item?.value);
        } else if (item.id === 1) {
          state.mapTooltipOptions = item?.value;
        }
      });
    },
    setTopologyTooltipOptions: (state, action) => {
      state.topologyToolTipOptions = action.payload;
    },
  },
});

export const { setToolTipOptions, setTopologyTooltipOptions } =
  toolTipOptionsSlice.actions;
export default toolTipOptionsSlice.reducer;
