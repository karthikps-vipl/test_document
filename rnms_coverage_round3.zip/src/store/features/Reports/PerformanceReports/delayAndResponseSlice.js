import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  delayAndResponseChartData: [],
  delayAndResponseActiveWindowMinutes: 1, // Default fallback
  subscribeToDelayAndResponseSocket: false,
  currentDelayAndResponseResource: "",
};

const delayAndResponseSlice = createSlice({
  name: "delayAndResponseSlice",
  initialState,
  reducers: {
    // Call this when hitting the REST API to initialize the chart and set the window limit
    initDelayAndResponseChart: (state, action) => {
      const { initialPoint, windowMinutes } = action.payload;
      state.delayAndResponseActiveWindowMinutes =
        parseFloat(windowMinutes) || 1;
      state.delayAndResponseChartData = initialPoint ? [initialPoint] : [];
    },

    // Call this when your WebSocket delivers a streaming data packet
    addDelayAndResponseChartPoint: (state, action) => {
      const newTick = action.payload;
      state.delayAndResponseChartData.push(newTick);

      const windowLimitMs =
        state.delayAndResponseActiveWindowMinutes * 60 * 1000;
      const latestTimestamp = new Date(newTick.date).getTime();

      // Check the oldest point at index 0, drop it if it's older than 10 mins
      if (state.delayAndResponseChartData.length > 0) {
        const oldestTimestamp = new Date(
          state.delayAndResponseChartData[0].date
        ).getTime();

        console.log(
          "difffff=",
          latestTimestamp - oldestTimestamp,
          "   ",
          windowLimitMs
        );

        if (latestTimestamp - oldestTimestamp > windowLimitMs) {
          console.log("exceed");
          state.delayAndResponseChartData.shift(); // Removes the first point (FIFO)
        }
      }
    },
    clearDelayAndResponseChartData: (state) => {
      state.delayAndResponseChartData = [];
    },
    setSubscribeToDelayAndResponsetSocket: (state, action) => {
      state.subscribeToDelayAndResponseSocket = action.payload.subscribe;
      state.currentDelayAndResponseResource = action.payload.resourceId;
    },
  },
});

export const {
  initDelayAndResponseChart,
  addDelayAndResponseChartPoint,
  clearDelayAndResponseChartData,
  setSubscribeToDelayAndResponsetSocket,
} = delayAndResponseSlice.actions;
export default delayAndResponseSlice.reducer;
