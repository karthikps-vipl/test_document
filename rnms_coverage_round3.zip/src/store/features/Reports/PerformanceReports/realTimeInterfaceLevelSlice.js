import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  realtimeInterfaceLevelChartData: [],
  realTimeInterfaceLevelActiveWindowMinutes: 1, // Default fallback
  subscribeToRealtimeInterfaceLevelReportSocket: false,
  currentRealtimeInterfaceResource: "",
  currentRealtimeInterfacePortId: "",
  currentRealtimeInterfaceParamId: "",
};

const realTimeInterfaceLevelSlice = createSlice({
  name: "realTimeInterfaceLevelSlice",
  initialState,
  reducers: {
    // Call this when hitting the REST API to initialize the chart and set the window limit
    initRealTimeInterfaceLevelChart: (state, action) => {
      const { initialPoint, windowMinutes } = action.payload;
      state.realTimeInterfaceLevelActiveWindowMinutes =
        parseFloat(windowMinutes) || 1;
      state.realtimeInterfaceLevelChartData = initialPoint
        ? [initialPoint]
        : [];
    },

    // Call this when your WebSocket delivers a streaming data packet
    // addRealtimeInterfaceLevelChartPoint: (state, action) => {
    //   const newTick = action.payload;
    //   state.realtimeInterfaceLevelChartData.push(newTick);

    //   const windowLimitMs =
    //     state.realTimeInterfaceLevelActiveWindowMinutes * 60 * 1000;
    //   const latestTimestamp = new Date(newTick.date).getTime();

    //   // Check the oldest point at index 0, drop it if it's older than 10 mins
    //   if (state.realtimeInterfaceLevelChartData.length > 0) {
    //     const oldestTimestamp = new Date(
    //       state.realtimeInterfaceLevelChartData[0].date
    //     ).getTime();

    //     console.log(
    //       "old time=",
    //       oldestTimestamp,
    //       " latest time=",
    //       latestTimestamp
    //     );

    //     if (latestTimestamp - oldestTimestamp > windowLimitMs) {
    //       console.log("exceed");
    //       state.realtimeInterfaceLevelChartData.shift(); // Removes the first point (FIFO)
    //     }
    //   }
    // },
    addRealtimeInterfaceLevelChartPoint: (state, action) => {
      const newTick = action.payload;
    
      if (!newTick?.date) {
        return;
      }
    
      const newTimestamp = new Date(newTick.date).getTime();
    
      if (Number.isNaN(newTimestamp)) {
        return;
      }
    
      const newData = Number(newTick.data);
    
      if (Number.isNaN(newData)) {
        return;
      }
    
      const normalizedTick = {
        ...newTick,
        date: newTick.date,
        data: newData,
      };
    
      /*
       * Prevent REST + WebSocket duplication.
       *
       * If the same timestamp already exists, replace that point
       * instead of adding another point.
       */
      const existingIndex =
        state.realtimeInterfaceLevelChartData.findIndex(
          (point) =>
            new Date(point.date).getTime() === newTimestamp
        );
    
      if (existingIndex !== -1) {
        state.realtimeInterfaceLevelChartData[existingIndex] =
          normalizedTick;
      } else {
        state.realtimeInterfaceLevelChartData.push(normalizedTick);
      }
    
      /*
       * Keep data ordered chronologically.
       */
      state.realtimeInterfaceLevelChartData.sort(
        (a, b) =>
          new Date(a.date).getTime() -
          new Date(b.date).getTime()
      );
    
      /*
       * Enforce the selected realtime window.
       *
       * Example:
       * window = 5 minutes
       * newest = 15:10
       *
       * Anything older than 15:05 is removed.
       */
      const windowLimitMs =
        state.realTimeInterfaceLevelActiveWindowMinutes * 60 * 1000;
    
      const latestTimestamp =
        new Date(
          state.realtimeInterfaceLevelChartData[
            state.realtimeInterfaceLevelChartData.length - 1
          ].date
        ).getTime();
    
      while (
        state.realtimeInterfaceLevelChartData.length > 0
      ) {
        const oldestTimestamp =
          new Date(
            state.realtimeInterfaceLevelChartData[0].date
          ).getTime();
    
        if (
          latestTimestamp - oldestTimestamp <=
          windowLimitMs
        ) {
          break;
        }
    
        state.realtimeInterfaceLevelChartData.shift();
      }
    },
    
    clearRealtimeInterfaceLevelChartData: (state) => {
      state.realtimeInterfaceLevelChartData = [];
    },
    setSubscribeToRealtimeInterfaceLevelReportSocket: (state, action) => {
      state.subscribeToRealtimeInterfaceLevelReportSocket =
        action.payload.subscribe;
      state.currentRealtimeInterfaceResource = action.payload.resourceId;
      state.currentRealtimeInterfaceParamId = action.payload.paramId;
      state.currentRealtimeInterfacePortId = action.payload.portId;
    },
  },
});

export const {
  initRealTimeInterfaceLevelChart,
  addRealtimeInterfaceLevelChartPoint,
  clearRealtimeInterfaceLevelChartData,
  setSubscribeToRealtimeInterfaceLevelReportSocket,
} = realTimeInterfaceLevelSlice.actions;
export default realTimeInterfaceLevelSlice.reducer;
