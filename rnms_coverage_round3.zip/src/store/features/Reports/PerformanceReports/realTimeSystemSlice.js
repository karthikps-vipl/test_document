import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  realtimeChartData: [],
  activeWindowMinutes: 1, // Default fallback
  subscribeToRealtimeReportSocket: false,
  realTimeCurrentDevice: "",
  realTimeCurrentParamId: "",
};

const realTimeSystemSlice = createSlice({
  name: "realTimeSystemSlice",
  initialState,
  reducers: {
    // Call this when hitting the REST API to initialize the chart and set the window limit
    initRealTimeChart: (state, action) => {
      const { initialPoint, windowMinutes } = action.payload;
      state.activeWindowMinutes = parseFloat(windowMinutes) || 1;
      state.realtimeChartData = initialPoint ? [initialPoint] : [];
    },

    // Call this when your WebSocket delivers a streaming data packet
    // addRealtimeChartPoint: (state, action) => {
    //   const newTick = action.payload;
    //   state.realtimeChartData.push(newTick);

    //   const windowLimitMs = state.activeWindowMinutes * 60 * 1000;
    //   const latestTimestamp = new Date(newTick.date).getTime();

    //   // Check the oldest point at index 0, drop it if it's older than 10 mins
    //   if (state.realtimeChartData.length > 0) {
    //     const oldestTimestamp = new Date(
    //       state.realtimeChartData[0].date
    //     ).getTime();

    //     console.log(
    //       "old time=",
    //       oldestTimestamp,
    //       " latest time=",
    //       latestTimestamp
    //     );

    //     if (latestTimestamp - oldestTimestamp > windowLimitMs) {
    //       console.log("exceed");
    //       state.realtimeChartData.shift(); // Removes the first point (FIFO)
    //     }
    //   }
    // },

    addRealtimeChartPoint: (state, action) => {
      const newTick = action.payload;
    
      if (!newTick?.date) {
        return;
      }
    
      const newTimestamp = new Date(newTick.date).getTime();
    
      if (Number.isNaN(newTimestamp)) {
        return;
      }
    
      const newData = Number(newTick.data);
    
      if (Number.isNaN(newData)) {
        return;
      }
    
      const normalizedTick = {
        ...newTick,
        data: newData,
      };
    
      /*
       * Prevent duplicate REST + WebSocket points.
       */
      const existingIndex =
        state.realtimeChartData.findIndex(
          (point) =>
            new Date(point.date).getTime() === newTimestamp
        );
    
      if (existingIndex !== -1) {
        state.realtimeChartData[existingIndex] =
          normalizedTick;
      } else {
        state.realtimeChartData.push(normalizedTick);
      }
    
      /*
       * Keep chronological order.
       */
      state.realtimeChartData.sort(
        (a, b) =>
          new Date(a.date).getTime() -
          new Date(b.date).getTime()
      );
    
      /*
       * Enforce selected window.
       */
      const windowLimitMs =
        state.activeWindowMinutes * 60 * 1000;
    
      const latestTimestamp =
        new Date(
          state.realtimeChartData[
            state.realtimeChartData.length - 1
          ].date
        ).getTime();
    
      while (state.realtimeChartData.length > 0) {
        const oldestTimestamp =
          new Date(
            state.realtimeChartData[0].date
          ).getTime();
    
        if (
          latestTimestamp - oldestTimestamp <=
          windowLimitMs
        ) {
          break;
        }
    
        state.realtimeChartData.shift();
      }
    },
    clearRealtimeChartData: (state) => {
      state.realtimeChartData = [];
    },
    setSubscribeToRealtimeReportSocket: (state, action) => {
      state.subscribeToRealtimeReportSocket = action.payload.subscribe;
      state.realTimeCurrentDevice = action.payload.resourceId;
      state.realTimeCurrentParamId = action.payload.paramId;
    },
  },
});

export const {
  initRealTimeChart,
  addRealtimeChartPoint,
  clearRealtimeChartData,
  setSubscribeToRealtimeReportSocket,
} = realTimeSystemSlice.actions;
export default realTimeSystemSlice.reducer;
