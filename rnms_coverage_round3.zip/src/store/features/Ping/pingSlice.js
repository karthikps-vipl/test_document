import { createSlice } from "@reduxjs/toolkit";

const pingSlice = createSlice({
  name: "ping",
  initialState: {
    // Expects a unified object shape from your backend message stream:
    // { ipAddress: string, toolType: string, pingOutput?: string, arpOutput?: string, traceOutput?: string, isReachable?: boolean }
    pingData: null, 
  },
  reducers: {
    // Unified action handler to commit all inbound network diagnostic stream packets
    setPingData: (state, action) => {
      state.pingData = action.payload;
    },
    // Flushes out current cached console logs when navigating or triggering a new utility query
    clearPingData: (state) => {
      state.pingData = null;
    }
  }
});

export const { setPingData, clearPingData } = pingSlice.actions;
export default pingSlice.reducer;