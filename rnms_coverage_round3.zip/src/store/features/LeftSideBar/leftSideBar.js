 /***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Navigation Slice 
   File Name                : leftSidebarSlice.js
   Author                   : ANKITHA - VIPL
   Package                  : src\store\features\LeftSideBar\leftSidebarSlice.js
   Purpose                  : Manages the global Redux state for the left sidebar
   Created Date             : 21-02-2026
 ***********************************************************************************************/
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  leftSidebarVisible: false,
};

const leftSidebarSlice = createSlice({
  name: "leftSidebarSlice",
  initialState,
  reducers: {
    setToggleLeftSideBar: (state, action) => {
      state.leftSidebarVisible = !state.leftSidebarVisible;
    },
  },
});

export const { setToggleLeftSideBar } = leftSidebarSlice.actions;
export default leftSidebarSlice.reducer;
