import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  terminalTypes: [], // Stores the formatted objects {label, value, raw}
};

const terminalTypeSlice = createSlice({
  name: 'terminalTypes',
  initialState,
  reducers: {
    // This action will receive the formatted array from the component
    setTerminalTypesData: (state, action) => {
      state.terminalTypes = action.payload;
      console.log("state.terminalTypes",state.terminalTypes)
    },
    // Action to clear the data if needed
    clearTerminalTypes: (state) => {
      state.terminalTypes = [];
    }
  },
});

export const { setTerminalTypesData, clearTerminalTypes } = terminalTypeSlice.actions;
export const terminalTypeReducer = terminalTypeSlice.reducer;
export default terminalTypeSlice.reducer;