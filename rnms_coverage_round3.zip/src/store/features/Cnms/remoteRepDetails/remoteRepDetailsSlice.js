import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  remoteRepDetails: [],
  fetchSiteDetails: [], // all sites stored in this variable
  fetchAllTerminalTypeAlongWithSite: [], // all sites stored in this variable
  CnmsDeleteAddSite: [],
  CnmsDeleteSite: [],
  cnmsOpenAlarm: [],
  blinkingSites: [], //sites blibking in map
  cnmsAlarmNotificationEvent: null,
};
const normalize = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase();

// Identifies one logical alarm on one device/site.
const getCnmsAlarmKey = (alarm) =>
  [
    alarm?.terminalTypeName,
    alarm?.siteId,
    alarm?.resourceIp || alarm?.resourceName,
    alarm?.alarmName,
  ]
    .map(normalize)
    .join("|");

const isClearedCnmsAlarm = (alarm) =>
  Number(alarm?.alarmState) === 0 || Number(alarm?.workflow) === 2;
const remoteRepDetailsSlice = createSlice({
  name: "remoteRepDetails",
  initialState,
  reducers: {
    setRemoteRepDetails: (state, action) => {
      const payload = action.payload;

      // CASE 1: The payload is an Array of Objects (e.g., [{id:1}, {id:2}, {id:3}])
      if (Array.isArray(payload)) {
        state.remoteRepDetails = payload;
        return;
      }

      // CASE 2: The payload is an Object with a 'data' property containing an array
      // Common when API returns: { data: [{...}, {...}] }
      if (payload && payload.data && Array.isArray(payload.data)) {
        state.remoteRepDetails = payload.data;
        return;
      }

      // CASE 3: The payload is a single Object (e.g., { personnel: "AIR CMDE", ... })
      // We wrap it in an array so the state remains consistent
      if (payload && typeof payload === "object" && !Array.isArray(payload)) {
        state.remoteRepDetails = [payload];
        return;
      }

      // Fallback: Ignore invalid data
      console.warn("Invalid payload format:", payload);
    },

    clearData: (state) => {
      state.remoteRepDetails = [];
    },

    setFetchSiteDetails: (state, action) => {
      state.fetchSiteDetails = action.payload;
      console.log("action.payloadaction.payload", action.payload);
    },
    setFetchAllTerminalTypeAlongWithSite: (state, action) => {
      state.fetchAllTerminalTypeAlongWithSite = action.payload;
    },
    setCnmsDeleteAddSite: (state, action) => {
      state.CnmsDeleteAddSite = action.payload;
    },
    setCnmsDeleteSite: (state, action) => {
      const payload = action.payload;
      if (Array.isArray(payload)) {
        state.CnmsDeleteSite = payload;
      } else if (payload && typeof payload === "object") {
        state.CnmsDeleteSite = [payload]; // Wrap single object in array
      } else {
        state.CnmsDeleteSite = [];
      }
    },
    setCnmsOpenAlarm: (state, action) => {
      state.cnmsOpenAlarm = Array.isArray(action.payload) ? action.payload : [];
    },

    // upsertCnmsSocketAlarm: (state, action) => {
    //   const { alarm: incoming, notificationId } = action.payload || {};

    //   if (!incoming) return;

    //   const alarms = [...(state.cnmsOpenAlarm || [])];
    //   const key = getCnmsAlarmKey(incoming);

    //   const existingIndex = alarms.findIndex(
    //     (alarm) => getCnmsAlarmKey(alarm) === key
    //   );

    //   // END / recovery: remove the alarm without notifying.
    //   if (isClearedCnmsAlarm(incoming)) {
    //     state.cnmsOpenAlarm = alarms.filter(
    //       (alarm) => getCnmsAlarmKey(alarm) !== key
    //     );
    //     return;
    //   }

    //   const existing = existingIndex !== -1 ? alarms[existingIndex] : null;

    //   // Detect a workflow transition from NOT_ACK to ACK.
    //   const isAckUpdate =
    //     existing &&
    //     Number(existing.workflow) === 0 &&
    //     Number(incoming.workflow) === 1;

    //   // Notify only if this is not an ACK workflow transition.
    //   if (!isAckUpdate) {
    //     state.cnmsAlarmNotificationEvent = {
    //       ...incoming,
    //       notificationEventId: notificationId,
    //     };
    //   }

    //   if (existingIndex === -1) {
    //     state.cnmsOpenAlarm = [
    //       {
    //         ...incoming,
    //         alarmCount: Math.max(1, Number(incoming.alarmCount) || 1),
    //       },
    //       ...alarms,
    //     ];
    //     return;
    //   }

    //   const updatedAlarm = {
    //     ...existing,
    //     ...incoming,
    //     alarmId: existing.alarmId,

    //     // Don't increment the count for a workflow-only update.
    //     alarmCount: isAckUpdate
    //       ? existing.alarmCount
    //       : (Number(existing.alarmCount) || 1) + 1,
    //   };

    //   alarms.splice(existingIndex, 1);
    //   state.cnmsOpenAlarm = [updatedAlarm, ...alarms];
    // },

    // Keep your existing workflow-update behavior.
    upsertCnmsSocketAlarm: (state, action) => {
      const { alarm: incoming, notificationId } = action.payload || {};

      if (!incoming) return;

      const alarms = [...(state.cnmsOpenAlarm || [])];
      const key = getCnmsAlarmKey(incoming);

      const existingIndex = alarms.findIndex(
        (alarm) => getCnmsAlarmKey(alarm) === key
      );

      const existing = existingIndex !== -1 ? alarms[existingIndex] : null;

      // END / recovery: remove the alarm and never notify.
      if (isClearedCnmsAlarm(incoming)) {
        state.cnmsOpenAlarm = alarms.filter(
          (alarm) => getCnmsAlarmKey(alarm) !== key
        );

        return;
      }

      // ACK/END workflow API updates are not new alarm occurrences.
      const isWorkflowUpdate =
        incoming.workFlowOperation === true ||
        Number(incoming.workflow) === 1 ||
        Number(incoming.workflow) === 2;

      // Only genuine NOT_ACK alarm occurrences should notify.
      const shouldNotify =
        !isWorkflowUpdate &&
        Number(incoming.workflow) === 0 &&
        Number(incoming.alarmState) !== 0;

      if (shouldNotify) {
        state.cnmsAlarmNotificationEvent = {
          ...incoming,
          notificationEventId: notificationId,
        };
      }

      // New alarm: add it to Redux.
      if (existingIndex === -1) {
        state.cnmsOpenAlarm = [
          {
            ...incoming,
            alarmCount: Math.max(1, Number(incoming.alarmCount) || 1),
          },
          ...alarms,
        ];

        return;
      }

      // Update existing alarm without incrementing count for ACK.
      const updatedAlarm = {
        ...existing,
        ...incoming,
        alarmId: existing.alarmId,

        alarmCount: isWorkflowUpdate
          ? Number(existing.alarmCount) || 1
          : (Number(existing.alarmCount) || 1) + 1,
      };

      alarms.splice(existingIndex, 1);

      state.cnmsOpenAlarm = [updatedAlarm, ...alarms];
    },
    updateSingleCnmsAlarm: (state, action) => {
      const updatedAlarm = action.payload;

      if (!updatedAlarm) return;

      const alarms = [...(state.cnmsOpenAlarm || [])];

      const existingIndex = alarms.findIndex(
        (alarm) => String(alarm.alarmId) === String(updatedAlarm.alarmId)
      );

      if (isClearedCnmsAlarm(updatedAlarm)) {
        if (existingIndex !== -1) {
          alarms.splice(existingIndex, 1);
        }

        state.cnmsOpenAlarm = alarms;
        return;
      }

      if (existingIndex !== -1) {
        alarms[existingIndex] = {
          ...alarms[existingIndex],
          ...updatedAlarm,
        };
      } else {
        alarms.unshift(updatedAlarm);
      }

      state.cnmsOpenAlarm = alarms;
    },
    clearCnmsAlarmNotificationEvent: (state) => {
      state.cnmsAlarmNotificationEvent = null;
    },
    setSiteMoveToMaintaiance: (state, action) => {
      // 1. Defensive Extraction with Defaults
      // Ensures we don't crash if action.payload is missing or partial
      const {
        siteId,
        isMaintainance,
        discovered,
        maintenanceType,
        healthStatusId,
        healthStatusValue,
      } = action.payload;

      // 2. Guard Clause: Fail gracefully if critical ID is missing
      if (!siteId) {
        console.warn(
          "[Map Reducer] setSiteMoveToMaintaiance: Missing siteId. Ignoring action."
        );
        return state;
      }

      // 3. Map over the nodes array safely
      return {
        ...state,
        fetchSiteDetails: state.fetchSiteDetails.map((item) => {
          // Check if this is the correct site (with optional chaining for safety)
          if (item.siteId === siteId) {
            return {
              ...item,
              isMaintainance: isMaintainance ?? item.isMaintainance,
              discovered: discovered ?? item.discovered,
              maintenanceType: maintenanceType ?? item.maintenanceType,
              healthStatus: {
                value: healthStatusValue,
                id: healthStatusId,
              },
            };
          }

          // Return the original item unchanged if it's not the matching site
          return item;
        }),
      };
    },
    updateSiteReachabilityStatus: (state, action) => {
      const incomingSites = action.payload;

      incomingSites.forEach((newSite) => {
        // 1. Find if the site already exists in the Redux state using siteId
        const existingSiteIndex = state.fetchSiteDetails.findIndex(
          (site) => site.siteId === newSite.siteId
        );

        // 2. Only perform the update if the site was found (index is not -1)
        if (existingSiteIndex !== -1) {
          state.fetchSiteDetails[existingSiteIndex] = {
            ...state.fetchSiteDetails[existingSiteIndex], // Keep existing fields (like groupList)
            ...newSite, // Overwrite with new socket data
          };
        }
        // If not found, we do nothing (the new site is ignored)
      });
    },

    deleteSite: (state, action) => {
      // 1. Defensive Extraction
      // We expect the API response to contain 'siteId' to identify which site to remove.
      const { siteId } = action.payload;

      // 2. Guard Clause: Fail gracefully if siteId is missing
      if (!siteId) {
        console.warn(
          "[Map Reducer] deleteSite: Missing siteId in action payload. Cannot delete."
        );
        return state;
      }

      // 3. Filter out the site
      // We create a new array containing all items EXCEPT the one matching siteId
      const updatedSites = state.fetchSiteDetails.filter(
        (item) => item.siteId !== siteId
      );

      return {
        ...state,
        fetchSiteDetails: updatedSites,
      };
    },

    startBlink: (state, action) => {
      const { siteId, maintenanceType } = action.payload;

      // Prevent duplicate blinking entries
      state.blinkingSites = state.blinkingSites.filter(
        (item) => item.siteId !== siteId
      );

      state.blinkingSites.push({
        siteId,
        maintenanceType,
      });
    },

    stopBlink: (state, action) => {
      state.blinkingSites = state.blinkingSites.filter(
        (item) => item.siteId !== action.payload
      );
    },
    setSiteLocationUpdate: (state, action) => {
      const apiData = action.payload;

      // 1. Find the index of the existing site using siteId
      const index = state.fetchSiteDetails.findIndex(
        (site) => site.siteId === apiData.siteId
      );

      if (index !== -1) {
        // 2. If found, merge the old data with the new API data
        // This ensures fields present in storedData but NOT in API (like groupList) are preserved
        state.fetchSiteDetails[index] = {
          ...state.fetchSiteDetails[index],
          latitude: apiData.latitude,
          longitude: apiData.longitude,
          siteName: apiData.siteName,
          siteNickName: apiData.siteNickName,
        };
      }
    },
    updateFetchAllSite: (state, action) => {
      const siteData = action.payload;
      state.fetchSiteDetails.map((site) =>
        site?.siteId === siteData?.siteId ? { ...site, ...siteData } : site
      );
    },
  },
});

export const {
  setRemoteRepDetails,
  setCnmsDeleteAddSite,
  clearData,
  setFetchSiteDetails,
  setFetchAllTerminalTypeAlongWithSite,
  setCnmsOpenAlarm,
  updateSingleCnmsAlarm,
  upsertCnmsSocketAlarm,
  clearCnmsAlarmNotificationEvent,
  setCnmsDeleteSite,
  setSiteMoveToMaintaiance,
  deleteSite,
  startBlink,
  stopBlink,
  setSiteLocationUpdate,
  updateFetchAllSite,
  updateSiteReachabilityStatus,
} = remoteRepDetailsSlice.actions;
export default remoteRepDetailsSlice.reducer;
