import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  sites: [],
  loading: false,
  error: null,
};

const normalizeIp = (value) => String(value ?? "").trim();

const cnmsActiveStatusSlice = createSlice({
  name: "cnmsActiveStatus",
  initialState,

  reducers: {
    setCnmsActiveStatuses: (state, action) => {
      const payload = action.payload;

      const incoming = Array.isArray(payload)
        ? payload
        : Array.isArray(payload?.data)
        ? payload.data
        : payload && typeof payload === "object"
        ? [payload]
        : [];

      // Initial API fetch: replace the stored list.
      state.sites = incoming
        .filter((site) => site?.ipaddress)
        .map((site) => ({
          ipaddress: normalizeIp(site.ipaddress),
          linkStatus: Number(site.linkStatus),
          siteType: Number(site.siteType),
        }));
      state.loading = false;
      state.error = null;
    },

    updateCnmsActiveStatusFromSocket: (state, action) => {
      const payload = action.payload;

      const incoming = Array.isArray(payload)
        ? payload
        : Array.isArray(payload?.data)
        ? payload.data
        : payload && typeof payload === "object"
        ? [payload]
        : [];

      incoming.forEach((site) => {
        if (!site?.ipaddress) return;

        const ipaddress = normalizeIp(site.ipaddress);
        const existingIndex = state.sites.findIndex(
          (item) => normalizeIp(item.ipaddress) === ipaddress
        );

        const update = {
          ...(existingIndex !== -1 ? state.sites[existingIndex] : {}),
          ...site,
          ipaddress,
          linkStatus: Number(site.linkStatus),
          siteType: Number(site.siteType),
        };

        if (existingIndex !== -1) {
          state.sites[existingIndex] = update;
        } else {
          state.sites.push(update);
        }
      });
    },

    setCnmsActiveStatusLoading: (state, action) => {
      state.loading = action.payload;
    },

    setCnmsActiveStatusError: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },

    clearCnmsActiveStatuses: (state) => {
      state.sites = [];
      state.loading = false;
      state.error = null;
    },
  },
});

export const {
  setCnmsActiveStatuses,
  updateCnmsActiveStatusFromSocket,
  setCnmsActiveStatusLoading,
  setCnmsActiveStatusError,
  clearCnmsActiveStatuses,
} = cnmsActiveStatusSlice.actions;

export default cnmsActiveStatusSlice.reducer;
