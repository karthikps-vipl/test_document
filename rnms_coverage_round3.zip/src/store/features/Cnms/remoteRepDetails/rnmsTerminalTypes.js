import { createSlice } from "@reduxjs/toolkit";

const rnmsterminaltypesSlice = createSlice({
   name: "rnmsTerminals", 
  initialState: {
    rnmsterminaltypesData: [], 
  },
  reducers: {
    setRnmsterminaltypesData: (state, action) => {
      state.rnmsterminaltypesData = action.payload;
      
    },
    clearRnmsterminaltypesData: (state) => {
      state.rnmsterminaltypesData = [];  
    }
  }
});

 export const { setRnmsterminaltypesData, clearRnmsterminaltypesData } = rnmsterminaltypesSlice.actions;
export default rnmsterminaltypesSlice.reducer;
