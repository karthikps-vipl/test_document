import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  allGroups: [], // This will hold your array of objects
  loading: false,
  error: null,
};

const groupSlice = createSlice({
  name: 'groups',
  initialState,
  reducers: {
    // Action to store the API response
    setAllGroups: (state, action) => {
      state.allGroups = action.payload;
      state.loading = false;
      state.error = null;
    },
    // Action to handle loading state
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    // Action to handle errors
    setError: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },
    // Action to update a specific group (useful for editing)
    updateGroup: (state, action) => {
      const index = state.allGroups.findIndex(g => g.id === action.payload.id);
      if (index !== -1) {
        state.allGroups[index] = action.payload;
      }
    }
  },
});

export const { setAllGroups, setLoading, setError, updateGroup } = groupSlice.actions;
export default groupSlice.reducer;