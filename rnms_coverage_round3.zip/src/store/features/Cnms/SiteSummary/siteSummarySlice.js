import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  sites: [],
  loading: false,
  initialized: false,
};

const siteSummarySlice = createSlice({
  name: "siteSummary",
  initialState,

  reducers: {
    setSiteSummary: (state, action) => {
      state.sites = Array.isArray(action.payload) ? action.payload : [];

      state.initialized = true;
    },

    updateSiteSummarySite: (state, action) => {
      const updatedSite = action.payload;

      if (!updatedSite) {
        return;
      }

      const siteId = updatedSite.siteId;

      const index = state.sites.findIndex((site) => site.siteId === siteId);
      
      if (index !== -1) {
        // Update existing site
        state.sites[index] = {
          ...state.sites[index],
          ...updatedSite,
        };
      } else {
        // New site
        state.sites.push(updatedSite);
      }
      
    },

    removeSiteFromSummary: (state, action) => {
        const updatedSite = action.payload;
        const siteId = updatedSite.siteId;

      state.sites = state.sites.filter((site) => site.siteId !== siteId);
    },

    clearSiteSummary: (state) => {
      state.sites = [];
      state.initialized = false;
    },
  },
});

export const {
  setSiteSummary,
  updateSiteSummarySite,
  removeSiteFromSummary,
  clearSiteSummary,
} = siteSummarySlice.actions;

export default siteSummarySlice.reducer;
