import { createSlice } from '@reduxjs/toolkit';

const cnmsSlice = createSlice({
  name: 'cnmsConfig',
  initialState: {
    mountAbu: null,
    kasauli: null,
    representatives: {
      mountAbu: [],
      kasauli: [],
    },
    loading: false,
    error: null,
    savedData: null, // Added this to store the final response
  },
  reducers: {
    // 1. Set Mount Abu Site Details
    setMountAbuDetails: (state, action) => {
      state.mountAbu = action.payload;
    },

    // 2. Set Kasauli Site Details
    setKasauliDetails: (state, action) => {
      state.kasauli = action.payload;
    },

    // 3. Set Representatives
    setRepresentatives: (state, action) => {
      state.representatives = action.payload;
    },

    // 4. Clear All Data
    clearCnmsData: (state) => {
      state.mountAbu = null;
      state.kasauli = null;
      state.representatives = { mountAbu: [], kasauli: [] };
    },

    // 5. Set Loading State
    setLoading: (state, action) => {
      state.loading = action.payload;
    },

    // 6. NEW: Set Saved Data (Required for your handleSuccess function)
    setSavedRnmsDetails: (state, action) => {
      state.savedData = action.payload;
      // Optional: You might want to clear the form here too
      state.mountAbu = null;
      state.kasauli = null;
      state.representatives = { mountAbu: [], kasauli: [] };
    },
  },
});

export const {
  setMountAbuDetails,
  setKasauliDetails,
  setRepresentatives,
  clearCnmsData,
  setLoading,
  setSavedRnmsDetails, // Export the new action
} = cnmsSlice.actions;

export default cnmsSlice.reducer;