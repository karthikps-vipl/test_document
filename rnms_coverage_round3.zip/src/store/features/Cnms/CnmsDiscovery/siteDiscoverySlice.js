import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    siteDetails: [],
    terminalTypes: [],
    discoveryResults: [],
  
    discoveryProgress: {
      activeStep: 0,
      message: "",
      percentage: 0,
      isRunning: false,
      socketStage: null,
    },
  };

const siteDiscoverySlice = createSlice({
  name: "siteDiscovery",

  initialState,

  reducers: {
    setSiteDetails: (state, action) => {
      state.siteDetails = Array.isArray(action.payload) ? action.payload : [];
    },

    setTerminalTypes: (state, action) => {
      state.terminalTypes = Array.isArray(action.payload) ? action.payload : [];
    },

    setDiscoveryResults: (state, action) => {
      state.discoveryResults = Array.isArray(action.payload)
        ? action.payload
        : [];
    },

    setDiscoveryProgress: (state, action) => {
      state.discoveryProgress = {
        ...state.discoveryProgress,
        ...action.payload,
      };
    },

    resetDiscoveryProgress: (state) => {
        state.discoveryProgress = {
          activeStep: 0,
          message: "",
          percentage: 0,
          isRunning: false,
          socketStage: null,
        };
      },

    clearSiteDiscoveryData: (state) => {
      state.siteDetails = [];
      state.terminalTypes = [];
      state.discoveryResults = [];
    },
  },
});

export const {
  setSiteDetails,
  setTerminalTypes,
  setDiscoveryResults,
  setDiscoveryProgress,
  resetDiscoveryProgress,
  clearSiteDiscoveryData,
} = siteDiscoverySlice.actions;

export default siteDiscoverySlice.reducer;
