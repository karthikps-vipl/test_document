import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  allUsers: [], // Stores the full user array
};

const getAllUsersSlice = createSlice({
  name: 'getAllUsers',
  initialState,
  reducers: {
    // Only keep this one action
    setAllUsersData: (state, action) => {
      state.allUsers = action.payload;
      // No need to track isLoading or error
    },
    
    // Optional: If you ever need to clear it later
    clearAllUsers: (state) => {
      state.allUsers = [];
    }
  },
});

export const { setAllUsersData, clearAllUsers } = getAllUsersSlice.actions;
export const getAllUsersSliceReducer = getAllUsersSlice.reducer;
export default getAllUsersSlice.reducer;
