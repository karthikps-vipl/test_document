import { createSlice } from "@reduxjs/toolkit";

const mapViewSlice = createSlice({
  name: "mapViewSlice",
  initialState: {
    viewOnMap: [],
    allSiteGroups: [],
    shouldResetFilters: false, // filter reset flag
  },
  reducers: {
    setViewOnMap: (state, action) => {
      state.viewOnMap = action.payload;
    },
    setAllSiteGroups: (state, action) => {
      state.allSiteGroups = action.payload;
    },
    // Trigger the reset
    triggerFilterReset: (state) => {
      state.shouldResetFilters = true;
    },

    // Clear the flag after reset is done
    clearFilterResetFlag: (state) => {
      state.shouldResetFilters = false;
    },
  },
});

export const {
  setViewOnMap,
  setAllSiteGroups,
  triggerFilterReset,
  clearFilterResetFlag,
} = mapViewSlice.actions;

export default mapViewSlice.reducer;
