import { createSlice, createAction } from "@reduxjs/toolkit";

// Action dispatched from syslogTopicHandlers.js when a STOMP MESSAGE arrives.
export const applySyslogAuditEvent = createAction("syslog/applyAuditEvent");

const initialState = {
  // -------- existing fields (unchanged names for backward-compat) --------
  allRows: [],              // [{ id, dt, batch, records, crit, mod, low, model,
                            //     model_quality_score, run_id, liveRows, enriched,
                            //     processing }]
  starredRows: [],          // [batchId, ...]
  spamRows: [],             // [batchId, ...]
  selectedDate: null,       // "YYYY-MM-DD"
  selectedModel: null,      // "production_model"
  masterFiles: { pdf: null, excel: null },

  // -------- new fields for live audit state --------
  isRunning: false,         // true while an audit is in progress
  runId: null,              // current run's UUID
  isStompConnected: false,  // set by the middleware
  lastEvent: null,          // last terminal event (stopped / error), for snackbars
  lastError: null,          // last error message
};

const upsertBatchRow = (rows, incoming) => {
  const idx = rows.findIndex((r) => r.id === incoming.id);
  if (idx >= 0) {
    const next = [...rows];
    next[idx] = { ...next[idx], ...incoming };
    return next;
  }
  return [...rows, incoming];
};

const syslogSlice = createSlice({
  name: "syslog",
  initialState,
  reducers: {
    toggleStar: (state, action) => {
      const id = action.payload;
      const i = state.starredRows.indexOf(id);
      if (i >= 0) state.starredRows.splice(i, 1);
      else state.starredRows.push(id);
    },
    toggleSpam: (state, action) => {
      const id = action.payload;
      const i = state.spamRows.indexOf(id);
      if (i >= 0) state.spamRows.splice(i, 1);
      else state.spamRows.push(id);
    },
    setAllRows: (state, action) => { state.allRows = action.payload; },
    setSelectedDate: (state, action) => { state.selectedDate = action.payload; },
    setSelectedModel: (state, action) => { state.selectedModel = action.payload; },
    setMasterFiles: (state, action) => { state.masterFiles = action.payload; },
    setStompConnected: (state, action) => { state.isStompConnected = action.payload; },
    clearAuditRows: (state) => {
      state.allRows = [];
      state.masterFiles = { pdf: null, excel: null };
      state.lastEvent = null;
      state.lastError = null;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(applySyslogAuditEvent, (state, action) => {
      const data = action.payload;
      if (!data) return;

      const runId = data.run_id || state.runId;

      switch (data.type) {
        // -------------------------------------------------
        // Lifecycle
        // -------------------------------------------------
        case "started":
          state.isRunning = true;
          if (data.run_id) state.runId = data.run_id;
          break;

        case "status":
          if (typeof data.running === "boolean") state.isRunning = data.running;
          if (data.run_id) state.runId = data.run_id;
          if (data.selected_date) state.selectedDate = data.selected_date;
          break;

        case "database_connected":
        case "waiting_for_data":
        case "idle":
        case "heartbeat":
          break;

        // -------------------------------------------------
        // Batch placeholders — appear instantly
        // -------------------------------------------------
        case "batch_started": {
          const batchIndex = Number(data.batch_index || 0);
          const id = `${runId || "run"}-batch-${batchIndex}`;
          const row = {
            id,
            batch: `Batch ${batchIndex}`,
            dt: data.timestamp || new Date().toISOString(),
            records: Number(data.database_rows || 0),
            crit: 0,
            mod: 0,
            low: 0,
            model: data.model || state.selectedModel || "production_model",
            model_quality_score: Number(data.model_quality_score || 0),
            run_id: runId,
            liveRows: [],
            enriched: false,
            processing: true,
          };
          state.allRows = upsertBatchRow(state.allRows, row);
          state.isRunning = true;
          break;
        }

        // -------------------------------------------------
        // Batch complete (preliminary) — immediately visible
        // -------------------------------------------------
        case "batch": {
          const batchIndex = Number(data.batch_index || 0);
          const stats = data.stats || {};
          const id = `${runId || "run"}-batch-${batchIndex}`;
          const row = {
            id,
            batch: `Batch ${batchIndex}`,
            dt: data.timestamp || new Date().toISOString(),
            records: Number(data.database_rows || 0),
            crit: Number(stats.critical || 0),
            mod: Number(stats.moderate || 0),
            low: Number(stats.low || 0),
            model: data.model || state.selectedModel || "production_model",
            model_quality_score: Number(data.model_quality_score || 0),
            run_id: runId,
            liveRows: Array.isArray(data.rows) ? data.rows : [],
            enriched: false,
            processing: false,
          };
          state.allRows = upsertBatchRow(state.allRows, row);
          state.isRunning = true;
          break;
        }

        // -------------------------------------------------
        // Batch enriched (post-LLM) — upgrades the row
        // -------------------------------------------------
        case "batch_enriched": {
          const batchIndex = Number(data.batch_index || 0);
          const id = `${runId || "run"}-batch-${batchIndex}`;
          const idx = state.allRows.findIndex((r) => r.id === id);
          if (idx < 0) break;
          const stats = data.stats || {};
          state.allRows[idx] = {
            ...state.allRows[idx],
            crit: Number(stats.critical || 0),
            mod: Number(stats.moderate || 0),
            low: Number(stats.low || 0),
            liveRows: Array.isArray(data.rows)
              ? data.rows
              : state.allRows[idx].liveRows,
            model_quality_score: Number(
              data.model_quality_score ??
                state.allRows[idx].model_quality_score ??
                0
            ),
            enriched: true,
          };
          break;
        }

        // -------------------------------------------------
        // Terminal events
        // -------------------------------------------------
        case "stopped": {
          state.isRunning = false;
          const dateForDownload = state.selectedDate;
          if (dateForDownload) {
            state.masterFiles = {
              pdf: `/syslogai/download/master/pdf?selected_date=${encodeURIComponent(
                dateForDownload
              )}`,
              excel: `/syslogai/download/master/xlsx?selected_date=${encodeURIComponent(
                dateForDownload
              )}`,
            };
          }
          state.lastEvent = { ...data, _at: Date.now() };
          state.runId = null;
          break;
        }

        case "error":
          state.isRunning = false;
          state.lastError = data.message || "Audit failed";
          state.lastEvent = { ...data, _at: Date.now() };
          break;

        case "model_promoted":
        case "training":
          // Non-blocking info events; dashboards can react to lastEvent if desired.
          break;

        default:
          break;
      }
    });
  },
});

export const {
  toggleStar,
  toggleSpam,
  setAllRows,
  setSelectedDate,
  setSelectedModel,
  setMasterFiles,
  setStompConnected,
  clearAuditRows,
} = syslogSlice.actions;

export default syslogSlice.reducer;




// import { createSlice } from '@reduxjs/toolkit';

// const syslogSlice = createSlice({
//   name: 'syslog',
//   initialState: {
//     starredRows: [], // IDs of starred/important rows
//     spamRows: [],    // IDs of rows moved to spam/trash
//     // --- NEW PERSISTED DATA ---
//     allRows: [], 
//     selectedDate: new Date().toISOString().split('T')[0], // Default to today
//     selectedModel: "",
//     masterFiles: { pdf: null, excel: null },
//   },
//   reducers: {
//     /**
//      * Toggles the "Important" status of a log.
//      */
//     toggleStar: (state, action) => {
//       const id = action.payload;
//       if (state.starredRows.includes(id)) {
//         state.starredRows = state.starredRows.filter(rowId => rowId !== id);
//       } else {
//         if (!state.spamRows.includes(id)) {
//           state.starredRows.push(id);
//         }
//       }
//     },

//     /**
//      * Toggles the "Spam" status of a log.
//      */
//     toggleSpam: (state, action) => {
//       const id = action.payload;
//       if (state.spamRows.includes(id)) {
//         state.spamRows = state.spamRows.filter(rowId => rowId !== id);
//       } else {
//         state.spamRows.push(id);
//         state.starredRows = state.starredRows.filter(rowId => rowId !== id);
//       }
//     },

//     /**
//      * Clears all interaction states. 
//      */
//     resetLogs: (state) => {
//       state.starredRows = [];
//       state.spamRows = [];
//       state.allRows = [];
//       state.masterFiles = { pdf: null, excel: null };
//     },

//     /**
//      * Bulk update interaction states
//      */
//     setSyslogState: (state, action) => {
//       const { starredRows, spamRows } = action.payload;
//       if (starredRows) state.starredRows = starredRows;
//       if (spamRows) state.spamRows = spamRows;
//     },

//     // --- NEW ACTIONS FOR PERSISTENCE ---
//     setAllRows: (state, action) => {
//       state.allRows = action.payload;
//     },
//     setSelectedDate: (state, action) => {
//       state.selectedDate = action.payload;
//     },
//     setSelectedModel: (state, action) => {
//       state.selectedModel = action.payload;
//     },
//     setMasterFiles: (state, action) => {
//       state.masterFiles = action.payload;
//     }
//   },
// });

// export const { 
//   toggleStar, 
//   toggleSpam, 
//   resetLogs, 
//   setSyslogState,
//   setAllRows,
//   setSelectedDate,
//   setSelectedModel,
//   setMasterFiles 
// } = syslogSlice.actions;

// export default syslogSlice.reducer;