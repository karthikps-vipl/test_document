import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";

import {
  receiveChatMessage,
  setTypingStatus,
  incrementUnread,
  setAckChat,
  setAckChatForCnms,
} from "../features/Chats/chatSlice";
import { ChatSocketMgmt } from "@/RestAPI/Socket/SocketCall";
import { ACK_DESTINATION, CHAT_TOPIC } from "@/RestAPI/Socket/Endpoint";

// const CHAT_SOCKET_URL = ChatSocketMgmt;

const chatSocketMiddleware = () => {
  let client = null;
  let manuallyDisconnected = false;

  let pendingMessages = [];
  const typingTimers = new Map();

  const publish = (destination, body, queueIfDisconnected = true) => {
    if (manuallyDisconnected) {
      return {
        success: false,
        error: "Chat socket manually disconnected",
      };
    }

    if (!client?.connected) {
      // Never queue CHAT messages.
      if (queueIfDisconnected) {
        pendingMessages.push({ destination, body });
      }

      return {
        success: false,
        error: "Sockets disconnected.",
      };
    }

    try {
      client.publish({
        destination,
        body: JSON.stringify(body),
      });

      return { success: true };
    } catch (error) {
      console.error("Chat publish failed:", error);

      return {
        success: false,
        error: error.message || "Message sending failed",
      };
    }
  };

  const flushPendingMessages = () => {
    if (!client?.connected) return;

    const pending = [...pendingMessages];
    pendingMessages = [];

    pending.forEach(({ destination, body }) => {
      try {
        client.publish({
          destination,
          body: JSON.stringify(body),
        });
      } catch (error) {
        console.error("Chat pending message failed:", error);
        pendingMessages.push({ destination, body });
      }
    });
  };

  const stopTyping = (store, conversation) => {
    if (typingTimers.has(conversation)) {
      clearTimeout(typingTimers.get(conversation));
      typingTimers.delete(conversation);
    }

    store.dispatch(
      setTypingStatus({
        conversation,
        typing: false,
      })
    );
  };

  const handleTyping = (store, conversation) => {
    if (typingTimers.has(conversation)) {
      clearTimeout(typingTimers.get(conversation));
    }

    store.dispatch(
      setTypingStatus({
        conversation,
        typing: true,
      })
    );

    const timer = setTimeout(() => {
      store.dispatch(
        setTypingStatus({
          conversation,
          typing: false,
        })
      );

      typingTimers.delete(conversation);
    }, 600);

    typingTimers.set(conversation, timer);
  };

  const sendAck = (store, conversation, isCnms, id) => {
    publish(ACK_DESTINATION, {
      type: "ACK",
      conversation,
      readStatus: false,
      chatsForCnms: isCnms,
      id,
    });
  };

  const handleIncomingMessage = (store, message) => {
    try {
      console.log(message, "sdkfjhjsf");

      const msg = JSON.parse(message.body);

      const chatState = store.getState().chat;

      if (!chatState) return;

      const { isCnms, selfName, active, chatOpen } = chatState;

      console.log("========== RNMS CHAT DEBUG ==========");
      console.log("Terminal selfName:", selfName);
      console.log("Message sender:", msg.sender);
      console.log("Message receiver:", msg.reciever);
      console.log("Is CNMS:", isCnms);
      console.log("=====================================");

      // CHAT MESSAGE
      if (msg.type === "CHAT") {
        let conversation;

        if (isCnms) {
          // CNMS receives messages from all RNMS terminals.
          conversation = msg.reciever;
        } else {
          // RNMS receives messages addressed to itself
          // or messages addressed to Broadcast.
          if (msg.reciever !== selfName && msg.reciever !== "Broadcast") {
            return;
          }

          conversation = "Broadcast";
        }

        const chatMessage = {
          id: msg.id,
          sender: msg.sender,
          content: msg.content,
          dateAndTime: msg.dateTime,
        };

        store.dispatch(
          receiveChatMessage({
            conversation,
            message: chatMessage,
          })
        );

        const isIncoming = isCnms
          ? msg.sender !== "CNMS"
          : msg.sender !== selfName;

        const isConversationOpen = chatOpen && active === conversation;

        if (isIncoming) {
          if (!chatOpen) {
            store.dispatch(incrementUnread());
          }

          // ACK messages that are not currently being viewed.
          if (!isConversationOpen) {
            sendAck(store, isCnms ? conversation : selfName, isCnms, msg.id);
          }
        }

        stopTyping(store, conversation);

        return;
      }

      // TYPING INDICATOR
      if (msg.type === "TYPING") {
        let conversation;

        if (isCnms) {
          if (msg.sender === "CNMS") return;

          conversation = msg.reciever;

          // Only display typing for the selected conversation.
          if (active !== conversation) return;
        } else {
          if (msg.reciever !== selfName && msg.reciever !== "Broadcast") {
            return;
          }

          if (msg.sender !== "CNMS") return;

          conversation = "Broadcast";
        }

        handleTyping(store, conversation);
        return;
      }

      // ACKNOWLEDGEMENT RESPONSE
      if (msg.type === "ACK") {
        store.dispatch(setAckChat(msg.unreadChats || {}));

        store.dispatch(setAckChatForCnms(msg.unreadChatsByCnms || {}));

        return;
      }

      if (msg.type === "JOIN" || msg.type === "LEAVE") {
        console.log("Chat presence event:", msg);
      }
    } catch (error) {
      console.error("Chat socket message error:", error);
    }
  };

  const connect = (store) => {
    if (client?.active) {
      console.log("Chat socket is already active");
      return;
    }

    manuallyDisconnected = false;

    const CHAT_SOCKET_URL = store?.getState()?.chat?.chatBackendURL;
    console.log(CHAT_SOCKET_URL, "chat url in middleware");

    if (!CHAT_SOCKET_URL) {
      console.error("Chat socket URL is missing");
      return;
    }

    const stompClient = new Client({
      webSocketFactory: () => new SockJS(CHAT_SOCKET_URL),

      reconnectDelay: 5000,

      heartbeatIncoming: 10000,
      heartbeatOutgoing: 10000,

      debug: (message) => {
        console.log("[CHAT STOMP]", message);
      },

      onConnect: (frame) => {
        console.log("Chat socket connected successfully", frame);

        // Check that this is still the current client.
        if (client !== stompClient || !stompClient.connected) {
          console.warn("Chat client is no longer active");
          return;
        }

        stompClient.subscribe(CHAT_TOPIC, (message) => {
          handleIncomingMessage(store, message);
        });

        console.log("Subscribed to:", CHAT_TOPIC);

        flushPendingMessages();
      },

      onDisconnect: () => {
        console.log("Chat STOMP disconnected");
      },

      onStompError: (frame) => {
        console.error("Chat STOMP error:", frame.headers?.message, frame.body);
      },

      onWebSocketClose: (event) => {
        console.warn("Chat WebSocket closed:", event);
      },

      onWebSocketError: (error) => {
        console.error("Chat WebSocket error:", error);
      },
    });

    client = stompClient;

    stompClient.activate();
  };

  const disconnect = async () => {
    manuallyDisconnected = true;

    pendingMessages = [];

    typingTimers.forEach((timer) => clearTimeout(timer));
    typingTimers.clear();

    const currentClient = client;

    client = null;

    if (currentClient) {
      try {
        await currentClient.deactivate();
      } catch (error) {
        console.error("Chat disconnect error:", error);
      }
    }

    console.log("Chat socket disconnected");
  };

  return (store) => (next) => (action) => {
    switch (action.type) {
      case "chatSocket/connect":
        connect(store);
        return;

      case "chatSocket/disconnect":
        disconnect();
        return;

      case "chatSocket/send": {
        const { destination, body } = action.payload || {};

        if (!destination || body == null) {
          return {
            success: false,
            error: "Invalid chat socket message",
          };
        }

        // CHAT messages must never be queued.
        // Other events retain the existing queue behaviour.
        const result = publish(destination, body, body.type !== "CHAT");

        return result;
      }

      default:
        return next(action);
    }
  };
};

export default chatSocketMiddleware;
