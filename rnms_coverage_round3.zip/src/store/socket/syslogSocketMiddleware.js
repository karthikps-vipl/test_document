import { Stomp } from "@stomp/stompjs";
import SockJS from "sockjs-client";

import { SyslogSocketMgmt } from "@/RestAPI/Socket/SocketCall";
import { getSyslogTopicHandlers } from "./syslogTopicHandlers";

const MAX_RETRIES = 5;
const RETRY_DELAY = 5000;

const SYSLOG_SOCKET_URL = SyslogSocketMgmt(); // -> SOCKET_URL + "/syslogai/ws"
console.log(SYSLOG_SOCKET_URL, "SYSLOG_SOCKET_URL");

const syslogSocketMiddleware = () => {
  let stompClient = null;
  let retryCount = 0;
  let reconnectTimer = null;
  let manuallyDisconnected = false;
  let subscribers = {};

  const connect = (store) => {
    if (stompClient?.connected) {
      console.warn("[syslog-socket] already connected");
      return;
    }

    manuallyDisconnected = false;

    try {
      const socket = new SockJS(SYSLOG_SOCKET_URL);
      stompClient = Stomp.over(socket);
      stompClient.debug = () => {}; // silence

      stompClient.onConnect = () => {
        console.log("[syslog-socket] connected");
        retryCount = 0;
        if (reconnectTimer) {
          clearTimeout(reconnectTimer);
          reconnectTimer = null;
        }

        const topicHandlers = getSyslogTopicHandlers(store);

        Object.keys(topicHandlers).forEach((topic) => {
          subscribers[topic] = stompClient.subscribe(topic, (message) => {
            try {
              topicHandlers[topic](message);
            } catch (err) {
              console.error("[syslog-socket] handler error", err);
            }
          });
        });
      };

      stompClient.onStompError = (frame) => {
        console.error("[syslog-socket] STOMP error:", frame.headers["message"]);
        retryConnection(store);
      };

      stompClient.onWebSocketClose = () => {
        console.warn("[syslog-socket] WebSocket closed");
        subscribers = {};
        retryConnection(store);
      };

      stompClient.activate();
    } catch (err) {
      console.error("[syslog-socket] connect failed", err);
      retryConnection(store);
    }
  };

  const retryConnection = (store) => {
    if (manuallyDisconnected) return;
    if (retryCount >= MAX_RETRIES) {
      console.error("[syslog-socket] max retries reached");
      return;
    }
    retryCount++;
    console.log(`[syslog-socket] retry ${retryCount}/${MAX_RETRIES}`);
    reconnectTimer = setTimeout(() => connect(store), RETRY_DELAY);
  };

  const disconnect = () => {
    manuallyDisconnected = true;
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    Object.values(subscribers).forEach((sub) => {
      try { sub.unsubscribe(); } catch (_) { /* noop */ }
    });
    subscribers = {};
    if (stompClient) {
      try { stompClient.deactivate(); } catch (_) { /* noop */ }
      stompClient = null;
      console.log("[syslog-socket] manually disconnected");
    }
    retryCount = 0;
  };

  return (store) => (next) => (action) => {
    switch (action.type) {
      case "syslogSocket/connect":
        connect(store);
        break;
      case "syslogSocket/disconnect":
        disconnect();
        break;
      default:
        return next(action);
    }
  };
};

export default syslogSocketMiddleware;