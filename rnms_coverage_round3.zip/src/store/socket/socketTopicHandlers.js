/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Socket
   File Name                : getSocketTopicHandlers.js
   Author                   : ANKITHA - VIPL
   Package                  : src\store\socket\socketTopicHandlers.js
   Purpose                  : Provides a mapping utility that associates incoming socket 
                               event topics (payloads) with their respective Redux 
                               action creators to automate dispatching.
   Created Date             : 17-04-2026
***********************************************************************************************/

import {
  // ALARM_SOCKET_NMS,
  DEVICE_REACHABILITY_STATUS,
  VEHICLE_UP_TIME,
  ALARM_SOCKET_NMS,
  PORT_STATUS,
  PING_TOOLS,
  REAL_TIME_REPORT_DATA_UPDATE_TO_UI,
  DELAY_RESPONSE_SOCKET,
  LINK_STATUS_CONFIGURATION,
  PERFORMANCE_DATA_UPDATE_TO_UI,
  CNMS_REACH_ABILITY_STATUS,
  DISCOVERY_STAGE_DATA,
  DISCOVERY_STAGE_DATA_RNMS,
  SITE_LOCATION_UPDATE,
  ALARM_SOCKET_CNMS,
  SITE_REACHABILITY_STATUS,
  CNMS_ACTIVE_STATUS_UPDATE,
  SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT,
  SEND_EXPORT_CERTIFICATE_STATUS_TO_UI,
} from "@/RestAPI/Socket/Endpoint";
import {
  setNewAlarm,
  setupdateAlram,
  updateSingleAlarm,
  updateSingleBadge,
} from "../features/Fault/alarmSlice";
import { setwebSocketPortStatus } from "../features/PortStatus/portStatusSlice";
import {
  setImageNodePortStatusLive,
  updateEdgeStatusFromSocket,
  updateLinkStatusFromSocket,
  updateNodeStatusThroughSocket,
} from "../features/Topology/topologyNodesslice";
import { setPingData } from "../features/Ping/pingSlice";
import { addRealtimeChartPoint } from "../features/Reports/PerformanceReports/realTimeSystemSlice";
import { addRealtimeInterfaceLevelChartPoint } from "../features/Reports/PerformanceReports/realTimeInterfaceLevelSlice";
import { addDelayAndResponseChartPoint } from "../features/Reports/PerformanceReports/delayAndResponseSlice";
import {
  updateMaxSeverity,
  updatePortStatusFromSocket,
  updateResourceFromSocket,
} from "../features/Inventory/inventorySlice";
import { updatePerformanceData } from "../features/Performance/performanceSlice";
import { filterSwitchPorts } from "@/utility/portFilterUtils";

import { setHealthStatus } from "../features/LinkStatus/cnmsStatusSlice";
import { setDiscoveryProgress } from "../features/Cnms/CnmsDiscovery/siteDiscoverySlice";
import {
  setSiteLocationUpdate,
  startBlink,
  stopBlink,
  updateSiteReachabilityStatus,
  upsertCnmsSocketAlarm,
} from "../features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import { updateRnmsLatLong } from "../features/nodeDetailsSlice";
import { updateCnmsActiveStatusFromSocket } from "../features/Cnms/remoteRepDetails/cnmsActiveStatusSlice";
import { setLogoutPending } from "../features/Logout/authSlice";
import { setCertificateExportResponse } from "../features/X509Certificate/certificateExportSlice";
import { refreshAlarmData } from "@/utility/alarmService";

// --- 2. INITIALIZED AUDIO OBJECTS & HELPER FUNCTION ---
// const majorAudio = new Audio(MajorSound);
// const minorAudio = new Audio(MinorSound);
// const warningAudio = new Audio(CriticalSound);

// const playAlarmSound = (severity) => {
//   try {
//     if (severity === 2) {
//       majorAudio.currentTime = 0;
//       majorAudio.play().catch((err) => console.log("Audio play blocked:", err));
//     } else if (severity === 1) {
//       minorAudio.currentTime = 0;
//       minorAudio.play().catch((err) => console.log("Audio play blocked:", err));
//     } else if (severity === 0) {
//       warningAudio.currentTime = 0;
//       warningAudio
//         .play()
//         .catch((err) => console.log("Audio play blocked:", err));
//     }
//   } catch (error) {
//     console.error("Error playing alarm sound:", error);
//   }
// };
// -------------------

export const normalizeDate = (dateStr) => {
  if (!dateStr) return "";
  const parsedDate = new Date(dateStr);

  // Checks if the date string parsed successfully
  if (isNaN(parsedDate.getTime())) {
    return dateStr; // Fallback to raw string if parsing fails
  }

  // Returns clean standard format: "Jun 22, 2026, 1:11:29 PM"
  return parsedDate.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
};

export const getSocketTopicHandlers = (store) => {
  return {
    [PERFORMANCE_DATA_UPDATE_TO_UI]: (message) => {
      try {
        const data = JSON.parse(message.body);
        console.log("PERFORMANCE_DATA_RECEIVED:", data);

        if (data && data.perfParamInfoBean) {
          store.dispatch(
            updatePerformanceData({
              // Mapping the nested values to a flat object for the reducer
              resourceId: data.resourceInfoBean?.resourceId,
              paramId: data.perfParamInfoBean.paramId,
              value: parseFloat(data.data), // "78.0" becomes 78.0
            })
          );
        }
      } catch (err) {
        console.error("Error parsing PERFORMANCE_DATA_UPDATE_TO_UI", err);
      }
    },
    [SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT]: (message) => {
      const data = message.body;

      console.log(
        "SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT",
        SEND_NOTIFICATION_TO_UI_FOR_USER_LOGOUT
      );

      console.log("HANDLER EXECUTED", data);

      store.dispatch(
        setLogoutPending({
          message: "As new login request has come up for the user",
          targetUser: data,
        })
      );
    },

    [DEVICE_REACHABILITY_STATUS]: (message) => {
      const data = JSON.parse(message.body);
      console.log(
        "DEVICE_REACHABILITY_STATUS",

        "discovered=",
        data?.imResourceInfo?.isDiscovered,
        "maintain =",
        data?.imResourceInfo?.isMaintainance,
        " reachable=",
        data.isReachable,
        " ip=",
        data.imResourceInfo.resourceIp,
        " ",
        data.imResourceInfo.resourceId,
        data
      );

      if (data) {
        store.dispatch(
          updateNodeStatusThroughSocket({
            isDiscovered: data?.imResourceInfo?.isDiscovered,
            isMaintainance: data?.imResourceInfo?.isMaintainance,

            resourceIp: data.imResourceInfo.resourceIp,
            status: data.isReachable ? "up" : "down",
            isReachable: data.isReachable,
            maxSeverity: data.maxSeverity,
            resourceIdVal: data.imResourceInfo.resourceId,
          })
        );
        // store.dispatch(upsertNodeFromSocket(data));
        store.dispatch(updateResourceFromSocket(data));
      }
    },
    [PING_TOOLS]: (message) => {
      try {
        const data = JSON.parse(message.body);
        if (data) {
          console.log("TOOL_SOCKET Data Received:", data);

          // FIX: Instead of picking only specific fields,
          // dispatch the entire data object.
          // This ensures arpOutput and traceOutput are saved to Redux.
          store.dispatch(
            setPingData({
              pingOutput: data.pingOutput || "",
              arpOutput: data.arpOutput || "", // Added
              traceOutput: data.traceOutput || "", // Added
              isReachable: data.isReachable,
              ipAddress: data.ipAddress,
              ip: data.ip, // Added (for fallback)
              toolType: data.toolType, // Added (important for your tab logic)
            })
          );
        }
      } catch (err) {
        console.error("Error parsing PING_TOOLS message", err);
      }
    },

    [VEHICLE_UP_TIME]: (message) => {
      const data = JSON.parse(message.body);
      if (data) {
        console.log("VEHICLE_UP_TIME", data);
        // alert("Getting !!!!!!!!!!");
      }
    },
    // [ALARM_SOCKET_NMS]: (message) => {
    //   const data = JSON.parse(message.body);
    //   if (data) {
    //     console.log("ALARM_SOCKET_NMS", data);

    //     // // const newAlarm = JSON.parse(message.body);
    //     if (data.alarmCount === 1 && data?.workflowstate === 0) {
    //       // console.log('newAlarm', newAlarm);
    //       // alert("New Data")
    //       // store.dispatch(incrementAlarmCount());
    //       store.dispatch(setnewAlram(data));
    //       // store.dispatch(setnewAlram(data));
    //       store.dispatch(setAlarmSeverityCount(data));
    //     } else if (
    //       data.alarmCount !== 1 ||
    //       (data.alarmCount === 1 && data?.workflowstate !== 0)
    //     ) {
    //       console.log("newAlarm_update", data);
    //       // alert("Updated Data")
    //       // store.dispatch(incrementAlarmCount());
    //       store.dispatch(setupdateAlram(data));
    //     }
    //   }
    // },

    // -------------WORKING ONE-----------------------
    // [ALARM_SOCKET_NMS]: (message) => {
    //   const data = JSON.parse(message.body);
    //   if (data) {
    //     console.log("ALARM_SOCKET_NMS", data);

    //     // --- 3. TRIGGER AUDIO PLAYBACK BASED ON SEVERITY ---
    //     // playAlarmSound(data.severity);

    //     // Extract severity from incoming data and update Redux
    //     if (typeof data.severity === "number") {
    //       store.dispatch(updateMaxSeverity(data.severity));
    //     }

    //     if (data.alarmCount === 1 && data?.workflowstate === 0) {
    //       store.dispatch(setnewAlram(data));
    //       store.dispatch(setAlarmSeverityCount(data));
    //     } else if (
    //       data.alarmCount !== 1 ||
    //       (data.alarmCount === 1 && data?.workflowstate !== 0)
    //     ) {
    //       console.log("newAlarm_update", data);
    //       store.dispatch(setupdateAlram(data));
    //     }
    //   }
    // },

    [ALARM_SOCKET_NMS]: async (message) => {
      let data;

      try {
        data = JSON.parse(message.body);
      } catch (error) {
        console.error("Invalid alarm socket payload:", error);
        return;
      }

      if (!data) return;

      console.log("alarmsocketee", data);

      console.log("ALARM_SOCKET_NMS:", {
        alarmId: data.alarmId,
        alarmName: data.alarmName,
        alarmCount: data.alarmCount,
        workflow: data.workflow,
        workFlowOperation: data.workFlowOperation,
        alarmState: data.alarmState,
        severity: data.severity,
      });

      const alarmCount = Number(data.alarmCount);
      const workflow = Number(data.workflow);
      const severity = Number(data.severity);

      await refreshAlarmData(store.dispatch);

      if (Number.isFinite(severity)) {
        store.dispatch(updateMaxSeverity(severity));
        // store.dispatch(updateSingleBadge(data));
      }

      // ACK and END events update the alarm, but must
      // never trigger the new/repeated-alarm notification path.
      if (data.workFlowOperation === true) {
        store.dispatch(updateSingleAlarm(data));
        return;
      }

      // Ignore events that are not active, unacknowledged alarms.
      if (data.alarmState !== 1 || workflow !== 0) {
        return;
      }

      // First occurrence of an alarm.
      if (alarmCount === 1) {
        store.dispatch(setNewAlarm(data));
        return;
      }

      // Repeated occurrence of an active alarm.
      if (alarmCount > 1) {
        store.dispatch(setupdateAlram(data));
        // store.dispatch(updateSingleBadge(data));
      }
    },
    [LINK_STATUS_CONFIGURATION]: (message) => {
      const data = JSON.parse(message.body);
      console.log("link_status", data);
      if (data) {
        store.dispatch(
          updateEdgeStatusFromSocket({
            linkId: data.linkId,
            linkColor: data.linkColor,
            linkStatus: data.linkStatus,
            linkProperties: data.linkProperties,
            resourceId: data.linkResInfo?.resourceId,
          })
        );

        store.dispatch(
          updateLinkStatusFromSocket({
            linkId: data.linkId,
            linkStatus: data.linkStatus,
          })
        );
      }
    },

    // [PORT_STATUS]: (message) => {
    //   const data = JSON.parse(message.body);
    //   console.log("PORT_STATUS", data);

    //   store.dispatch(setwebSocketPortStatus(data));

    //   const state = store.getState();
    //   const device = state.portStatusSlice.availableResources.find(
    //     (d) => d.resourceId === data.resourceId
    //   );

    //   if (!device) return;

    //   // Filter ports specifically for your 24-port switch before passing to Topology
    //   let filteredPorts = device.lstPortInfoDtl;
    //   if (device.resourceId === "MCT_EP_SWITCH-24PORT") {
    //     filteredPorts = filterSwitchPorts(device.lstPortInfoDtl);
    //   }

    //   store.dispatch(
    //     setImageNodePortStatusLive({
    //       resourceId: device.resourceId,
    //       lstPortInfoDtl: filteredPorts,
    //     })
    //   );
    // },
    [PORT_STATUS]: (message) => {
      const data = JSON.parse(message.body);
      console.log("PORT_STATUS", data);

      store.dispatch(setwebSocketPortStatus(data));

      const state = store.getState();

      console.log("statettttt", state);

      // 1. Find the device in the current state
      const device = state.inventory.resources.find(
        (d) => d.resourceId === data.resourceId
      );
      console.log("stadevicete", device);

      if (!device) {
        // Even if device isn't found, we dispatch the raw data to setwebSocketPortStatus if needed
        return;
      }

      // 2. Prepare the filtered list using your utility
      let filteredPorts = device.lstPortInfoDtl;
      if (device.resourceId === "MCT_EP_SWITCH-24PORT") {
        filteredPorts = filterSwitchPorts(device.lstPortInfoDtl);
      }

      // // 3. Dispatch BOTH the update data and the filtered list to the reducer
      // store.dispatch(updatePortStatusFromSocket({
      //   wsData: data,
      //   filteredPorts: filteredPorts
      // }));

      store.dispatch(
        updatePortStatusFromSocket({
          resourceId: data.resourceId,
          wsData: data,
        })
      );

      // 4. Update the Topology UI immediately
      store.dispatch(
        setImageNodePortStatusLive({
          resourceId: device.resourceId,
          lstPortInfoDtl: filteredPorts,
        })
      );
    },
    [REAL_TIME_REPORT_DATA_UPDATE_TO_UI]: (message) => {
      const { realTimeSystemSlice, realTimeInterfaceLevelSlice } =
        store.getState();
      const parsed = JSON.parse(message.body);

      console.log(realTimeInterfaceLevelSlice, "realTimeInterfaceLevelSlice");

      console.log("REAL_TIME_REPORT_DATA_UPDATE_TO_UI", parsed);

      // realtime system
      if (
        realTimeSystemSlice.subscribeToRealtimeReportSocket &&
        realTimeSystemSlice.realTimeCurrentDevice ==
        parsed.resourceInfoBean.resourceId &&
        realTimeSystemSlice.realTimeCurrentParamId ===
        parsed.perfParamInfoBean.paramId
      ) {
        const parsed = JSON.parse(message.body);

        const incomingTick = {
          date: normalizeDate(parsed.date),
          data: parseFloat(parsed.data),
        };

        store.dispatch(addRealtimeChartPoint(incomingTick));
      }

      // realtime interface report
      if (
        realTimeInterfaceLevelSlice.subscribeToRealtimeInterfaceLevelReportSocket &&
        realTimeInterfaceLevelSlice.currentRealtimeInterfaceResource ==
        parsed.resourceInfoBean.resourceId &&
        realTimeInterfaceLevelSlice.currentRealtimeInterfaceParamId ===
        parsed.perfParamInfoBean.paramId &&
        realTimeInterfaceLevelSlice.currentRealtimeInterfacePortId ===
        parsed.interfaceNum
      ) {
        const incomingTick = {
          date: normalizeDate(parsed.date),
          data: parseFloat(parsed.data),
        };

        store.dispatch(addRealtimeInterfaceLevelChartPoint(incomingTick));
      }
    },

    [DELAY_RESPONSE_SOCKET]: (message) => {
      const { delayAndResponseSlice } = store.getState();
      const parsed = JSON.parse(message.body);

      console.log(delayAndResponseSlice, "realTimeInterfaceLevelSlice");

      console.log("DELAY_RESPONSE_SOCKET", parsed);

      if (
        delayAndResponseSlice.subscribeToDelayAndResponseSocket &&
        delayAndResponseSlice.currentDelayAndResponseResource ==
        parsed.resourceInfoBean.resourceId
      ) {
        const parsed = JSON.parse(message.body);

        const incomingTick = {
          date: normalizeDate(parsed.time),
          data: parseFloat(parsed.delayResponseTime),
        };

        store.dispatch(addDelayAndResponseChartPoint(incomingTick));
      }
    },
    [CNMS_REACH_ABILITY_STATUS]: (message) => {
      try {
        console.log("CNMS WebSocket raw message:", message.body);

        let data = JSON.parse(message.body);

        console.log("CNMS WebSocket parsed data:", data);

        

        const healthStatus = data?.healthStatus;

        // Accept only valid CNMS statuses
        if ([0, 1, 2, 3].includes(healthStatus)) {
          store.dispatch(
            setHealthStatus({
              status: healthStatus,
              timestamp: new Date().toISOString(),
            })
          );

          console.log("CNMS Redux status updated:", healthStatus);
        } else {
          console.warn("Invalid CNMS healthStatus:", healthStatus);
        }
      } catch (err) {
        console.error("Error parsing CNMS WebSocket message:", err);
      }
    },
    [DISCOVERY_STAGE_DATA]: (message) => {
      try {
        const data =
          typeof message.body === "string"
            ? JSON.parse(message.body)
            : message.body;

        console.log("CNMS DISCOVERY STAGE DATA:", data);

        const stage = Number(data?.stage);

        const stageConfig = {
          0: {
            activeStep: 0,
            message: "Starting Site Discovery...",
            percentage: 0,
          },

          1: {
            activeStep: 1,
            message: "Fetching Active IPs...",
            percentage: 33,
          },

          2: {
            activeStep: 2,
            message: "Performing Site Discovery...",
            percentage: 66,
          },

          3: {
            activeStep: 3,
            message: "Site Discovery completed successfully.",
            percentage: 100,
          },
        };

        const currentStage = stageConfig[stage];

        if (!currentStage) {
          console.warn("Unknown CNMS discovery stage:", stage, data);
          return;
        }

        store.dispatch(
          setDiscoveryProgress({
            ...currentStage,
            socketStage: stage,
            isRunning: stage !== 3,
          })
        );
      } catch (error) {
        console.error("Failed to process DISCOVERY_STAGE_DATA:", error);
      }
    },
    [DISCOVERY_STAGE_DATA_RNMS]: (message) => {
      try {
        const data =
          typeof message.body === "string"
            ? JSON.parse(message.body)
            : message.body;

        console.log("RNMS DISCOVERY STAGE DATA:", data);

        const stage = Number(data?.stage);

        const stageConfig = {
          0: {
            activeStep: 0,
            message: "Starting Device Discovery...",
            percentage: 0,
          },

          1: {
            activeStep: 1,
            message: "Fetching Active IPs...",
            percentage: 33,
          },

          2: {
            activeStep: 2,
            message: "Performing Device Discovery...",
            percentage: 66,
          },

          3: {
            activeStep: 3,
            message: "Device Discovery completed successfully.",
            percentage: 100,
          },
        };

        const currentStage = stageConfig[stage];

        if (!currentStage) {
          console.warn("Unknown RNMS discovery stage:", stage, data);
          return;
        }

        store.dispatch(
          setDiscoveryProgress({
            ...currentStage,
            socketStage: stage,
            isRunning: stage !== 3,
          })
        );
      } catch (error) {
        console.error("Failed to process DISCOVERY_STAGE_DATA_RNMS:", error);
      }
    },
    [SITE_LOCATION_UPDATE]: (message) => {
      const data = JSON.parse(message.body);
      console.log(data, "SITE_LOCATION_UPDATE");

      store.dispatch(setSiteLocationUpdate(data));
      store.dispatch(
        updateRnmsLatLong({
          longitude: data?.longitude,
          latitude: data?.latitude,
        })
      );
    },
    [SITE_REACHABILITY_STATUS]: (message) => {
      // Optional: Remove the alert if it's just for debugging
      // alert("dsmnmdfngm");

      try {
        const data = JSON.parse(message.body);
        console.log(data, "SITE_REACHABILITY_STATUS_UPDATE_TO_UI");

        // 1. Create an array to hold the Promises for the timeouts
        const pendingTimeouts = [];

        data.forEach((item) => {
          // Dispatch startBlink immediately
          store.dispatch(
            startBlink({
              siteId: item.siteId,
              maintenanceType: item.healthStatus?.value ?? 0,
            })
          );

          // 2. Create a Promise that resolves after 10 seconds
          const timeoutPromise = new Promise((resolve) => {
            const timer = setTimeout(() => {
              // Dispatch stopBlink
              store.dispatch(stopBlink(item.siteId));
              // Resolve the promise so the loop can continue
              resolve();
            }, 10000);

            // Cleanup: Clear timer if the component unmounts or this function is aborted
            return () => clearTimeout(timer);
          });

          // Add the promise to our array
          pendingTimeouts.push(timeoutPromise);
        });

        // 3. Wait for ALL timeouts to finish BEFORE updating the status
        // Promise.all waits for every promise in the array to resolve
        Promise.all(pendingTimeouts).then(() => {
          // This code runs ONLY after the last stopBlink has executed
          store.dispatch(updateSiteReachabilityStatus(data));
        });
      } catch (error) {
        console.error("Error parsing message body:", error);
      }
    },

    // [ALARM_SOCKET_CNMS]: (message) => {
    //   const data = JSON.parse(message.body);
    //   console.log("datadata", data)

    //   if (!data) return;

    //   const storeData = store.dispatch(updateSingleCnmsAlarm(data));

    //   console.log("storeData", storeData)
    // }
    [ALARM_SOCKET_CNMS]: (message) => {
      const alarm = JSON.parse(message.body);

      if (!alarm) return;

      store.dispatch(
        upsertCnmsSocketAlarm({
          alarm,
          notificationId: crypto.randomUUID(),
        })
      );
    },

    [CNMS_ACTIVE_STATUS_UPDATE]: (message) => {
      try {
        const data = JSON.parse(message.body);

        console.log("CNMS ACTIVE STATUS RECEIVED:", data);

        store.dispatch(updateCnmsActiveStatusFromSocket(data));
      } catch (err) {
        console.error("Error parsing CNMS_ACTIVE_STATUS_UPDATE", err);
      }
    },
    [SEND_EXPORT_CERTIFICATE_STATUS_TO_UI]: (message) => {
      console.log(
        "SEND_EXPORT_CERTIFICATE_STATUS_TO_UI and subscribed", SEND_EXPORT_CERTIFICATE_STATUS_TO_UI

      );

      try {

        const data = JSON.parse(message.body);

        console.log("CERTIFICATE EXPORT SOCKET DATA:", data);

        if (data) {
          store.dispatch(
            setCertificateExportResponse(
              data.commandResponse || ""
            )
          );
        }
      } catch (error) {
        console.error(
          "Error parsing certificate export WebSocket message:",
          error
        );
      }
    },

  };
};
