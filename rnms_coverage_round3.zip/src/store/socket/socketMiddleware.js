
/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Socket
   File Name                : socketMiddleware.js
   Author                   : ARUN - VIPL
   Package                  : src\store\socket\socketMiddleware.js
   Purpose                  : Implements the Redux middleware to manage WebSocket lifecycle 
                               (connect, disconnect, send) and maps incoming socket events 
                               to Redux dispatch actions.
   Created Date             : 17-04-2026
***********************************************************************************************/
import { Stomp } from "@stomp/stompjs";
import SockJS from "sockjs-client";

import { NmsSocketTopic } from "@/RestAPI/Socket/Endpoint";
import { getSocketTopicHandlers } from "./socketTopicHandlers";
import { SocketMgmt } from "@/RestAPI/Socket/SocketCall";

const MAX_RETRIES = 5;
const RETRY_DELAY = 5000;

const SOCKET_URL = SocketMgmt(NmsSocketTopic);
console.log(SOCKET_URL, "SOCKET_URL");

const socketMiddleware = () => {
  let stompClient = null;
  let retryCount = 0;
  let reconnectTimer = null;
  let manuallyDisconnected = false;

  const connect = (store) => {
    if (stompClient?.connected) {
      console.warn("Socket already connected");
      return;
    }

    manuallyDisconnected = false;

    try {
      const socket = new SockJS(SOCKET_URL);
      console.log(socket, "socket");

      stompClient = Stomp.over(socket);

      stompClient.onConnect = () => {
        console.log("Socket Connected");

        retryCount = 0;

        if (reconnectTimer) {
          clearTimeout(reconnectTimer);
          reconnectTimer = null;
        }

        const topicHandlers = getSocketTopicHandlers(store);
 
        Object.keys(topicHandlers).forEach((topic) => {
          stompClient.subscribe(topic, (message) => {
            try {
              console.log("vnfnfn",topic);
              
              // const data = JSON.parse(message.body);
              // console.log(message.body,"jkjkjkjkjkkkj");
              
              topicHandlers[topic](message);
            } catch (err) {
              console.error("Socket message parse error", err);
            }
          });
        });
      };

      stompClient.onStompError = (frame) => {
        console.error("STOMP error:", frame.headers["message"]);

        retryConnection(store);
      };

      stompClient.onWebSocketClose = () => {
        console.warn("WebSocket closed");

        retryConnection(store);
      };

      stompClient.activate();
    } catch (err) {
      console.error("Socket connection failed", err);

      retryConnection(store);
    }
  };

  const retryConnection = (store) => {
    if (manuallyDisconnected) return;

    if (retryCount >= MAX_RETRIES) {
      console.error("Max socket retries reached");

      return;
    }

    retryCount++;

    console.log(`Retrying socket connection (${retryCount}/${MAX_RETRIES})`);

    reconnectTimer = setTimeout(() => {
      connect(store);
    }, RETRY_DELAY);
  };

  const disconnect = () => {
    manuallyDisconnected = true;

    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }

    if (stompClient) {
      stompClient.deactivate();
      stompClient = null;

      console.log("Socket manually disconnected");
    }

    retryCount = 0;
  };

  return (store) => (next) => (action) => {
    switch (action.type) {
      case "socket/connect":
        connect(store);
        break;

      case "socket/disconnect":
        disconnect();
        break;

      default:
        return next(action);
    }
  };
};

export default socketMiddleware;
