import { SYSLOG_AUDIT_TOPIC } from "@/RestAPI/Socket/Endpoint";
import { applySyslogAuditEvent } from "../features/SyslogAI/syslogSlice";

export const getSyslogTopicHandlers = (store) => ({
  [SYSLOG_AUDIT_TOPIC]: (message) => {
    let data;
    try {
      data = JSON.parse(message.body);
    } catch (err) {
      console.error("[syslog-socket] bad payload:", message.body);
      return;
    }

    // 1. Update Redux with the event
    store.dispatch(applySyslogAuditEvent(data));

    // 2. Terminal events → close the syslog socket.
    //    The backend has already force-closed it server-side; this stops
    //    the middleware's auto-retry loop from reopening it.
    if (data.type === "stopped" || data.type === "error") {
      setTimeout(() => {
        store.dispatch({ type: "syslogSocket/disconnect" });
      }, 100);
    }
  },
});