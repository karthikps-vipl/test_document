/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : src
   File Name                : App.jsx
   Author                   : SURAJ - VIPL
   Package                  : src\App.jsx
   Purpose                  : Defined the entire project structure in this file. 
   Created Date             : 15-01-2026
 *******************************************************************************************/

import React from "react";
import {
  // BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import LandingPage from "./Pages/auth/LandingPage/LandingPage";
import Configuration from "./Pages/auth/configurator/Configuration";
import SucessConfigarator from "./Pages/auth/configurator/SucessConfigarator";
import SosModal from "./components/Topbar/SoSModal";
import LoginAtp from "./Pages/auth/LoginAtp";
import Header from "./components/Topbar/Header";
import TopologyWrapper from "./Pages/Rnmsdashboard/Topology/TopologyWrapper";
import FaultWrapper from "./Pages/Rnmsdashboard/FAult/AlarmDashboardLayout";
import DashboardLayout from "./Pages/Rnmsdashboard/DashboardLayout";
import { useSelector } from "react-redux";
import useLogout from "./utility/customHooks/useLogout";
import useSessionTimeout from "./utility/customHooks/useSessionTimeout";
import GlobalModalRenderer from "./core/modal/GlobalModalRenderer";

import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
 import "overlayscrollbars/overlayscrollbars.css";
import SyslogRows from "./Pages/Rnmsdashboard/Syslog AI/SyslogRows";
import SyslogDashboard from "./Pages/Rnmsdashboard/Syslog AI/SyslogDashboard";
import { Box, useTheme } from "@mui/material";
import CnmsConfiguration from "./Pages/auth/CnmsConfiguration/CnmsConfiguration";
import Login from "./Pages/auth/Login";
  
function App() {
  const Token = sessionStorage.getItem("authToken");
  const { userDetails } = useSelector((state) => state.userSlice);
  const { siteDetails } = useSelector((state) => state.nodeDetails);

  const { logoutHandler } = useLogout();
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const isAuthenticated = !!(userDetails && Token);
  const timeoutInMinutes = 24 * 60; // 1440 minutes
  useSessionTimeout(logoutHandler, isAuthenticated, timeoutInMinutes);
  // Initialize timeout (e.g., 10 minutes)
  // useSessionTimeout(logoutHandler, isAuthenticated, 10);
  // Determine initial route based on authentication status
  // let initialRoute = "/"; // Default to landing page

  // if (userDetails && Token) {
  //   initialRoute = "/dashboard"; // Or "/dashboard/topology", etc.  See note below.
  // }
  const theme = useTheme()
  return (
    <Box className="h-screen w-full flex flex-col overflow-hidden bg-slate-50">
      <Header />
      <Box
        className="flex-1 min-h-0 relative bg-red-200"
        sx={{ background: theme.palette.custom.configuration.configbg }}
      >
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route
            path="/configurator"
            element={siteDetails?.id ? <Configuration /> : <Navigate to="/" />}
          />
          <Route
            path="/cnmsconfigurator"
            element={siteDetails?.id ? <CnmsConfiguration /> : <Navigate to="/" />}
          />
          <Route
            path="/SucessConfigarator"
            element={
              siteDetails?.id ? <SucessConfigarator /> : <Navigate to="/" />
            }
          />
          <Route path="/sos" element={<SosModal />} />
        
          {isCnms ? (
            <Route
              path="/login"
              element={siteDetails?.id ? <LoginAtp /> : <Navigate to="/" />}
            />
          ) : (
            <Route
              path="/loginATP"
              element={siteDetails?.id ? <LoginAtp /> : <Navigate to="/" />}
            />
          )}
            <Route
            path="/login"
            element={siteDetails?.id ? < Login /> : <Navigate to="/" />}
          />
          <Route path="/SyslogDashboard" element={<SyslogDashboard />} />
          <Route path="/SyslogRows" element={<SyslogRows />} />
          {/* Authenticated Routes (Dashboard) */}
          {userDetails && Token ? (
            <Route path="/dashboard" element={<DashboardLayout />}>
              <Route index element={<Navigate to="topology" replace />} />
              <Route path="topology" element={<TopologyWrapper />} />
              <Route path="faults" element={<FaultWrapper />} />
              <Route
                path="performance"
                element={
                  <Box className="p-10">Performance Charts Coming Soon...</Box>
                }
              />
            </Route>
          ) : null}{" "}
          {/*If no auth route render nothing */}
          {/* Redirect unauthenticated users to landing page */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        {/* <Fullscreen /> */}
        <GlobalModalRenderer />
       
        {/* <ModalSideEffects/> */}
      </Box>
    </Box>
  );
}

export default App;
