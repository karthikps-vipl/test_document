import React from "react";
import { Box, Typography } from "@mui/material";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
} from "recharts";

const MPieChart = ({ title, maintenanceSeconds = 0, availableSeconds = 0, pieData }) => {
  let data = [];
  let isZeroData = false;

  // 1. If dynamic pieData is passed down (like from the Link tab), prioritize it
  if (pieData && Array.isArray(pieData) && pieData.length > 0) {
    data = pieData.map((item) => ({
      name: item.name,
      // Convert seconds to hours if value is calculated in seconds, or keep as is
      value: Number(item.value) || 0,
      color: item.color,
    }));
    isZeroData = data.every((item) => item.value === 0);
  } 
  else {
    /*
     * Standard Availability / Maintenance chart.
     *
     * Values are already seconds.
     */
    isZeroData =
      Number(maintenanceSeconds) === 0 &&
      Number(availableSeconds) === 0;

    data = isZeroData
      ? [
          {
            name: "No Data",
            value: 1,
            color: "#e2e8f0",
          },
        ]
      : [
          {
            name: "Maintenance",
            value: Number(maintenanceSeconds) || 0,
            color: "#C23003",
          },
          {
            name: "Available",
            value: Number(availableSeconds) || 0,
            color: "#2e7d32",
          },
        ].filter((item) => item.value > 0);
  }

  // else {
  //   // 2. Fallback to standard Availability / Maintenance calculations
  //   const maintenanceHrs = parseFloat(
  //     ((maintenanceMs || 0) / (1000 * 60 * 60)).toFixed(2)
  //   );
  //   const availableHrs = parseFloat(
  //     ((availableMs || 0) / (1000 * 60 * 60)).toFixed(2)
  //   );

  //   isZeroData = maintenanceHrs === 0 && availableHrs === 0;

  //   data = isZeroData
  //     ? [{ name: "No Windows Logged", value: 1, color: "#e2e8f0" }]
  //     : [
  //         {
  //           name: "Unavailable/Maintenance Hours",
  //           value: maintenanceHrs,
  //           color: "#C23003",
  //         },
  //         { name: "Available Hours", value: availableHrs, color: "#2e7d32" },
  //       ];
  // }

  // Handle absolute fallback condition
  if (isZeroData && (!pieData || pieData.length === 0)) {
    data = [{ name: "No Windows Logged", value: 1, color: "#e2e8f0" }];
  }

  return (
    <Box
      id="report-pie-chart"
      sx={{
        width: "100%",
        maxWidth: "340px",
        height: "250px",
        margin: "0 auto",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <Typography
        variant="body2"
        sx={{ fontWeight: "bold", mb: 0.5, color: "text.TitleTextcolor" }}
      >
        {title}
      </Typography>

      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="45%"
            innerRadius={0}
            outerRadius={65}
            paddingAngle={isZeroData ? 0 : 2}
            isAnimationActive={true}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.color}
                style={{ outline: "none" }}
              />
            ))}
          </Pie>

          <Tooltip
            formatter={(value, name) => {
              if (isZeroData) {
                return ["N/A", name];
              }

              const totalSeconds = Number(value) || 0;

              const days = Math.floor(totalSeconds / 86400);
              const hours = Math.floor(
                (totalSeconds % 86400) / 3600
              );
              const minutes = Math.floor(
                (totalSeconds % 3600) / 60
              );
              const seconds = Math.floor(totalSeconds % 60);

              return [
                `${days}d ${hours}h ${minutes}m ${seconds}s`,
                name,
              ];
            }}
            contentStyle={{
              borderRadius: "8px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
              border: "1px solid #e2e8f0",
            }}
          />

          <Legend
            verticalAlign="bottom"
            align="center"
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: "12px", paddingTop: "5px" }}
          />
        </PieChart>
      </ResponsiveContainer>
    </Box>
  );
};

export default MPieChart;
