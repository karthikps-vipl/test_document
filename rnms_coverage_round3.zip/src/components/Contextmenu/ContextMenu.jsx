/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : ContextMenu 
   File Name                : ContextMenu.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Contextmenu\ContextMenu.jsx
   Purpose                  : Reusable contextMenu 
   Created Date             : 1-02-2026
 ***********************************************************************************************/
// import React from "react";
// import { Menu, MenuItem, ListItemIcon, ListItemText } from "@mui/material";
// import { useSelector } from "react-redux";
// import { ContextMenuOptions } from "./utils";
// import NestedSubMenu from "./SubMenu";
// import { dispatchContextAction } from "@/core/actions/contextActionDispatcher";

// const UnifiedContextMenu = ({
//   anchor,
//   node,
//   onClose,
//   onAction,
//   container = null,
// }) => {
  
//   const nestedPrivileges = useSelector(
//     (state) => state.userSlice.devicePrivileges
//   );

//   const nodeData = node?.data || node;

//   const resourceTypeId = nodeData?.imResourceType?.resourceTypeId;
//   const deviceCapabilities = nodeData?.imResourceType?.data || {};
//   const privilegeSet = nestedPrivileges[resourceTypeId] || {};

//   const isMaintenance = nodeData?.isMaintainance;
//   const isDiscovered = nodeData?.isDiscovered;

//   const filteredOptions = ContextMenuOptions.filter((opt) => {
//     const hasPermission = privilegeSet[opt.previlage] === true;
//     const isSupportedByHardware = deviceCapabilities[opt.key] !== false;

//     if (!hasPermission || !isSupportedByHardware) return false;

//     // --- NEW FILTERING LOGIC ---
//     if (opt.value === "addDevice") {
//       // Only show "Add Device" if in maintenance mode
//       return isMaintenance;
//     }
//     if (opt.value === "deleteDevice") {
//       // Only show "Delete Device" if NOT in maintenance mode
//       return !isMaintenance;
//     }

//     // Other items are always filtered in (visibility based on permission/hardware)
//     return true;
//   });

//   console.log("jfnjfilteredOptions", filteredOptions);

//   // Check if "addDevice" exists in the current visible options
//   const isAddDevicePresent = filteredOptions.some(
//     (opt) => opt.value === "addDevice"
//   );

//   console.log("isAddDevicePresent", isAddDevicePresent);

//   return (
//     <Menu
//       open={Boolean(anchor)}
//       onClose={onClose}
//       anchorReference="anchorPosition"
//       anchorPosition={
//         anchor ? { top: anchor.mouseY, left: anchor.mouseX } : undefined
//       }
//       container={container}
//       PaperProps={{
//         sx: {
//           borderRadius: "20px",
//           "& .MuiMenuItem-root:hover": {
//             backgroundColor: "transparent",
//             //  color: "#14348D",
//             color: "#2196f3",
//             fontWeight: 900,
//           },
//         },
//       }}
//     >
//       {filteredOptions.map((opt) => {
//         const isDisabled = !isDiscovered && opt.value !== "addDevice";

//         return opt.submenu?.length > 0 ? (
//           <NestedSubMenu
//             key={opt.value}
//             option={opt}
//             nodeData={nodeData}
//             onAction={onAction}
//             closeAll={onClose}
//             container={container}
//             isDisabled={isDisabled}
//           />
//         ) : (
//           // <MenuItem
//           //   key={opt.value}
//           //   onClick={() => {
//           //     onAction(opt.value, nodeData);
//           //     onClose();
//           //   }}
//           //   disabled={isDisabled}
//           // >
//           <MenuItem
//             key={opt.value}
//             onClick={() => {
//               dispatchContextAction({
//                 action: opt.value,
//                 node: nodeData,
//                 source: "topology",
//               });
//               onClose();
//             }}
//             disabled={isDisabled}
//           >
//             {opt.icon && <ListItemIcon>{opt.icon}</ListItemIcon>}
//             <ListItemText>{opt.label}</ListItemText>
//           </MenuItem>
//         );
//       })}
//     </Menu>
//   );
// };

// export default UnifiedContextMenu;

// import React, { useState } from "react";
// import { Menu, MenuItem, ListItemIcon, ListItemText } from "@mui/material";
// import { useSelector } from "react-redux";
// import { ContextMenuOptions } from "./utils";
// import NestedSubMenu from "./SubMenu";
// import { dispatchContextAction } from "@/core/actions/contextActionDispatcher";
// import PasswordPromptDialog from "@/Pages/Rnmsdashboard/PasswordPromptDialog";
// import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import { VALIDATE_RESOURCE_PASSWORD } from "@/RestAPI/url/endpoint";

// const UnifiedContextMenu = ({
//   anchor,
//   node,
//   onClose,
//   onAction,
//   container = null,
// }) => {
//   const [passwordModalOpen, setPasswordModalOpen] = useState(false);
//   const [pendingActionOpt, setPendingActionOpt] = useState(null);
//   const [authError, setAuthError] = useState(false);
//   const [isVerifying, setIsVerifying] = useState(false);

//   const nestedPrivileges = useSelector(
//     (state) => state.userSlice.devicePrivileges
//   );

//   const nodeData = node?.data || node;

//   console.log("tgbnodeData",nodeData);
//   console.log("cnmsnestedPrivileges",nestedPrivileges);
  

//   const resourceTypeId = nodeData?.imResourceType?.resourceTypeId;
//   const deviceCapabilities = nodeData?.imResourceType?.data || {};
//   const privilegeSet = nestedPrivileges[resourceTypeId] || {};

//   console.log("cnmsresourceTypeId",resourceTypeId);
//   console.log("cnmsprivilegeSet",privilegeSet);
  

//   const isMaintenance = nodeData?.isMaintainance;
//   const isDiscovered = nodeData?.isDiscovered;

//   const authConfig = deviceCapabilities?.authentication;
//   const expectedEncryptedPassword = deviceCapabilities?.authenticationPassword;
//   const authPasswordExists = Boolean(expectedEncryptedPassword);

//   const filteredOptions = ContextMenuOptions.filter((opt) => {
//     const hasPermission = privilegeSet[opt.previlage] === true;
//     const isSupportedByHardware = deviceCapabilities[opt.key] !== false;

//     if (!hasPermission || !isSupportedByHardware) return false;

//     if (opt.value === "addDevice") return isMaintenance;
//     if (opt.value === "deleteDevice") return !isMaintenance;

//     return true;
//   });

//   console.log("cnmdfilteredOptions",filteredOptions);
  
//   const handleMenuClick = (opt) => {
//     const isStatusAction = opt.value === "status" || opt.value === "deviceStatus";
//     // Added configuration action trigger check
//     const isConfigAction = opt.value === "configuration" || opt.value === "deviceConfiguration";

//     if ((isStatusAction || isConfigAction) && authConfig === true && authPasswordExists) {
//       setPendingActionOpt(opt);
//       setAuthError(false);
//       setPasswordModalOpen(true);
//     } else {
//       executeAction(opt);
//     }
//   };

//   const executeAction = (opt, encryptedPassword = null) => {
//     dispatchContextAction({
//       action: opt.value,
//       node: {
//         ...nodeData,
//         ...(encryptedPassword ? { password: encryptedPassword } : {}),
//       },
//       source: "topology",
//     });
//     onClose();
//   };

//   const handlePasswordSubmit = async (encryptedPassword) => {
//     setIsVerifying(true);
//     setAuthError(false);

//     try {
//       const payload = {
//         resourceId: nodeData?.resourceId,
//         imResourceType: {
//           data: {
//             authenticationPassword: encryptedPassword,
//           },
//         },
//       };

//       const response = await InventoryAxios(
//         VALIDATE_RESOURCE_PASSWORD,
//         "post",
//         payload
//       );

//       if (response && (response.status === 200 && (response.data?.status === 1 || response.data === true))) {
//         setPasswordModalOpen(false);
//         if (pendingActionOpt) {
//           executeAction(pendingActionOpt, encryptedPassword);
//           setPendingActionOpt(null);
//         }
//       } else {
//         setAuthError(true);
//       }
//     } catch (error) {
//       console.error("Password validation failed:", error);
//       setAuthError(true);
//     } finally {
//       setIsVerifying(false);
//     }
//   };

//   return (
//     <>
//       <Menu
//         open={Boolean(anchor)}
//         onClose={onClose}
//         anchorReference="anchorPosition"
//         anchorPosition={
//           anchor ? { top: anchor.mouseY, left: anchor.mouseX } : undefined
//         }
//         container={container}
//         PaperProps={{
//           sx: {
//             borderRadius: "20px",
//             "& .MuiMenuItem-root:hover": {
//               backgroundColor: "transparent",
//               color: "#2196f3",
//               fontWeight: 900,
//             },
//           },
//         }}
//       >
//         {filteredOptions.map((opt) => {
//           const isDisabled = !isDiscovered && opt.value !== "addDevice";

//           return opt.submenu?.length > 0 ? (
//             <NestedSubMenu
//               key={opt.value}
//               option={opt}
//               nodeData={nodeData}
//               onAction={onAction}
//               closeAll={onClose}
//               container={container}
//               isDisabled={isDisabled}
//             />
//           ) : (
//             <MenuItem
//               key={opt.value}
//               onClick={() => handleMenuClick(opt)}
//               disabled={isDisabled}
//             >
//               {opt.icon && <ListItemIcon>{opt.icon}</ListItemIcon>}
//               <ListItemText>{opt.label}</ListItemText>
//             </MenuItem>
//           );
//         })}
//       </Menu>

//       <PasswordPromptDialog
//         open={passwordModalOpen}
//         onClose={() => {
//           setPasswordModalOpen(false);
//           setPendingActionOpt(null);
//           setAuthError(false);
//         }}
//         onSubmit={handlePasswordSubmit}
//         resourceName={nodeData?.resourceName || nodeData?.resourceNickName || "Device"}
//         externalError={authError}
//       />
//     </>
//   );
// };

// export default UnifiedContextMenu;


import React, { useState } from "react";
import { Menu, MenuItem, ListItemIcon, ListItemText } from "@mui/material";
import { useSelector } from "react-redux";
import { ContextMenuOptions } from "./utils";
import NestedSubMenu from "./SubMenu";
import { dispatchContextAction } from "@/core/actions/contextActionDispatcher";
import PasswordPromptDialog from "@/Pages/Rnmsdashboard/PasswordPromptDialog";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { VALIDATE_RESOURCE_PASSWORD } from "@/RestAPI/url/endpoint";

// -------------------------------------------------------------------
// CNMS view-only menu rules
//
// Inventory is always visible.
// The other three are shown ONLY when the matching flag on
// `imResourceType.data` is strictly true.
//
//   data == null          -> Inventory only
//   data.status   === true -> Inventory + Status
//   data.configured === true -> Inventory + Configuration
//   data.web      === true -> Inventory + Cross Launch
// -------------------------------------------------------------------
const CNMS_ALWAYS_KEYS = ["inventory"];

const CNMS_CONDITIONAL_KEYS = {
  status: (data) => data?.status === true,
  configured: (data) => data?.configured === true,
  cross_launch: (data) => data?.web === true,
};

const UnifiedContextMenu = ({
  anchor,
  node,
  onClose,
  onAction,
  container = null,
  viewOnly = false, // CNMS flag — defaults false so RNMS is untouched
}) => {
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [pendingActionOpt, setPendingActionOpt] = useState(null);
  const [authError, setAuthError] = useState(false);
  // const [isVerifying, setIsVerifying] = useState(false);

  const nestedPrivileges = useSelector(
    (state) => state.userSlice.devicePrivileges
  );

  const nodeData = node?.data || node;

  console.log("tgbnodeData", nodeData);
  console.log("cnmsnestedPrivileges", nestedPrivileges);

  const resourceTypeId = nodeData?.imResourceType?.resourceTypeId;
  const deviceCapabilities = nodeData?.imResourceType?.data || {};
  const privilegeSet = nestedPrivileges[resourceTypeId] || {};

  console.log("cnmsresourceTypeId", resourceTypeId);
  console.log("cnmsprivilegeSet", privilegeSet);

  const isMaintenance = nodeData?.isMaintainance;
  const isDiscovered = nodeData?.isDiscovered;

  const authConfig = deviceCapabilities?.authentication;
  const expectedEncryptedPassword = deviceCapabilities?.authenticationPassword;
  const authPasswordExists = Boolean(expectedEncryptedPassword);

  const filteredOptions = ContextMenuOptions.filter((opt) => {
    // ===============================================================
    // CNMS VIEW-ONLY PATH
    //
    // Rules are driven exclusively by `imResourceType.data`.
    // No privilege check, no hardware check — the flags themselves
    // are the source of truth for CNMS.
    // ===============================================================
    if (viewOnly) {
      const data = nodeData?.imResourceType?.data;

      if (CNMS_ALWAYS_KEYS.includes(opt.key)) return true;

      const checker = CNMS_CONDITIONAL_KEYS[opt.key];
      if (checker) return checker(data);

      // Everything else (Fault, Add/Delete, View On Map,
      // linkConfiguration, Cross Launch when web !== true, …)
      return false;
    }

    // ===============================================================
    // RNMS PATH — original logic, unchanged
    // ===============================================================
    const hasPermission = privilegeSet[opt.previlage] === true;
    const isSupportedByHardware = deviceCapabilities[opt.key] !== false;

    if (!hasPermission || !isSupportedByHardware) return false;

    if (opt.value === "addDevice") return isMaintenance;
    if (opt.value === "deleteDevice") return !isMaintenance;

    return true;
  });

  console.log("cnmdfilteredOptions", filteredOptions);

  const handleMenuClick = (opt) => {
    const isStatusAction =
      opt.value === "status" || opt.value === "deviceStatus";
    const isConfigAction =
      opt.value === "configuration" || opt.value === "deviceConfiguration";

    if (
      (isStatusAction || isConfigAction) &&
      authConfig === true &&
      authPasswordExists
    ) {
      setPendingActionOpt(opt);
      setAuthError(false);
      setPasswordModalOpen(true);
    } else {
      executeAction(opt);
    }
  };

  const executeAction = (opt, encryptedPassword = null) => {
    dispatchContextAction({
      action: opt.value,
      node: {
        ...nodeData,
        ...(encryptedPassword ? { password: encryptedPassword } : {}),
      },
      source: "topology",
    });
    onClose();
  };

  const handlePasswordSubmit = async (encryptedPassword) => {
    // setIsVerifying(true);
    setAuthError(false);

    try {
      const payload = {
        resourceId: nodeData?.resourceId,
        imResourceType: {
          data: {
            authenticationPassword: encryptedPassword,
          },
        },
      };

      const response = await InventoryAxios(
        VALIDATE_RESOURCE_PASSWORD,
        "post",
        payload
      );

      if (
        response &&
        response.status === 200 &&
        (response.data?.status === 1 || response.data === true)
      ) {
        setPasswordModalOpen(false);
        if (pendingActionOpt) {
          executeAction(pendingActionOpt, encryptedPassword);
          setPendingActionOpt(null);
        }
      } else {
        setAuthError(true);
      }
    } catch (error) {
      console.error("Password validation failed:", error);
      setAuthError(true);
    } finally {
      // setIsVerifying(false);
    }
  };

  return (
    <>
      <Menu
        open={Boolean(anchor)}
        onClose={onClose}
        anchorReference="anchorPosition"
        anchorPosition={
          anchor ? { top: anchor.mouseY, left: anchor.mouseX } : undefined
        }
        container={container}
        PaperProps={{
          sx: {
            borderRadius: "20px",
            "& .MuiMenuItem-root:hover": {
              backgroundColor: "transparent",
              color: "#2196f3",
              fontWeight: 900,
            },
          },
        }}
      >
        {filteredOptions.map((opt) => {
          // Original RNMS disabled rule — preserved for both paths.
          // In CNMS, all rendered items are just Inventory + flag-driven
          // ones, so undiscovered devices correctly show them greyed.
          const isDisabled = !isDiscovered && opt.value !== "addDevice";

          return opt.submenu?.length > 0 ? (
            <NestedSubMenu
              key={opt.value}
              option={opt}
              nodeData={nodeData}
              onAction={onAction}
              closeAll={onClose}
              container={container}
              isDisabled={isDisabled}
            />
          ) : (
            <MenuItem
              key={opt.value}
              onClick={() => handleMenuClick(opt)}
              disabled={isDisabled}
            >
              {opt.icon && <ListItemIcon>{opt.icon}</ListItemIcon>}
              <ListItemText>{opt.label}</ListItemText>
            </MenuItem>
          );
        })}
      </Menu>

      <PasswordPromptDialog
        open={passwordModalOpen}
        onClose={() => {
          setPasswordModalOpen(false);
          setPendingActionOpt(null);
          setAuthError(false);
        }}
        onSubmit={handlePasswordSubmit}
        resourceName={
          nodeData?.resourceName || nodeData?.resourceNickName || "Device"
        }
        externalError={authError}
      />
    </>
  );
};

export default UnifiedContextMenu;