/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : ContextMenu 
   File Name                : SubMenu.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Contextmenu\SubMenu.jsx
   Purpose                  : Reusable Nested Sub Menu
   Created Date             : 1-02-2026
 ***********************************************************************************************/

import React, { useState } from "react";
import { Menu, MenuItem, ListItemIcon, ListItemText } from "@mui/material";
import { ChevronRight } from "@mui/icons-material";
import { dispatchContextAction } from "@/core/actions/contextActionDispatcher";

function constructUrl(url, ip) {
  try {
    if (url && ip) {
      const u = new URL(url);
      console.log(u, "full url");

      u.hostname = ip;

      return u.href;
    } else {
      return "";
    }
  } catch (error) {
    console.error("Error:", error);
    return "";
  }
}

const NestedSubMenu = ({
  option,
  nodeData,
  closeAll,
  container,
  isDisabled,
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  console.log("djnfoption", option);
  console.log("djnisDisabled", isDisabled);

  // const handleOpen = (e) => setAnchorEl(e.currentTarget);
  const handleOpen = (e) => {
    // If the parent menu item is disabled, don't allow sub-menu to open
    if (!isDisabled) {
      setAnchorEl(e.currentTarget);
    }
  };
  const handleClose = () => setAnchorEl(null);

  const handleItemClick = (val) => {
    

    if (val === "webconsole") {
      const custumUrl = constructUrl(
        nodeData.imResourceType?.data?.webUrl,
        nodeData.resourceIp
      );

      console.log(custumUrl, "custumUrl");

      window.open(custumUrl, "_blank");
    }

    // Prevent action if disabled
    if (isDisabled) return;
    // onAction(val, nodeData);
    dispatchContextAction({
      action: val,
      node: nodeData,
      source: "topology",
    });
    handleClose();
    closeAll();
  };

  return (
    // Wrap in a div to catch MouseLeave for the entire area
    <div onMouseLeave={handleClose}>
      <MenuItem
        onMouseEnter={handleOpen}
        // Force the parent to stay highlighted while sub is open
        selected={open}
        sx={{ display: "flex", justifyContent: "space-between" }}
        disabled={isDisabled}
      >
        <div style={{ display: "flex", alignItems: "center" }}>
          {option.icon && <ListItemIcon>{option.icon}</ListItemIcon>}
          <ListItemText>{option.label}</ListItemText>
        </div>
        <ChevronRight fontSize="small" />
      </MenuItem>

      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        container={container}
        disableRestoreFocus
        slotProps={{
          backdrop: {
            sx: { pointerEvents: "none" },
          },
        }}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "left" }}
        sx={{
          pointerEvents: "none",
          "& .MuiPaper-root": {
            borderRadius: "20px",
            ml: 0,
            // Optional: adds a slight shadow to make the menu pop
            boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.1)",
          },
          "& .MuiMenuItem-root": {
            // This ensures the text color transitions smoothly
            transition: "color 0.2s ease-in-out",
          },
          "& .MuiMenuItem-root:hover": {
            backgroundColor: "transparent",
            color: "#2196f3", //#14348D// Your requested dark color
            fontWeight: 900,
          },
          // Optional: If you want the color to stay when the item is clicked/selected
          "& .Mui-selected": {
            backgroundColor: "rgba(20, 52, 141, 1.08)", // Very light tint of your blue
            color: "#14348D",
            "&:hover": {
              backgroundColor: "rgba(20, 52, 141, 5.12)",
            },
          },
        }}
      >
        <div style={{ pointerEvents: "auto" }}>
          {option.submenu.map((sub) => (
            <MenuItem
              key={sub.value}
              onClick={() => handleItemClick(sub.value)}
              disabled={isDisabled}
            >
              <ListItemText>{sub.label}</ListItemText>
            </MenuItem>
          ))}
        </div>
      </Menu>
    </div>
  );
};

export default NestedSubMenu;
