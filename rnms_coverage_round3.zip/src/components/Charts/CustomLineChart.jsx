import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Label,
} from "recharts";
import { Box, Paper, Typography } from "@mui/material";

const CustomTooltip = ({ active, payload, label, yAxisFormatter }) => {
  if (active && payload?.length > 0) {
    return (
      <Paper
        elevation={3}
        sx={{ p: 1.5, border: "1px solid", borderColor: "divider" }}
      >
        <Typography
          variant="caption"
          color="text.secondary"
          display="block"
          gutterBottom
        >
          {label}
        </Typography>
        {payload.map((entry, index) => (
          <Box
            key={index}
            sx={{ display: "flex", alignItems: "center", gap: 1, my: 0.5 }}
          >
            <Box
              sx={{
                width: 10,
                height: 10,
                borderRadius: "50%",
                backgroundColor: entry.color,
              }}
            />
            <Typography variant="body2" fontWeight={500}>
              {entry.name}:{" "}
              {yAxisFormatter ? yAxisFormatter(entry.value) : entry.value}
            </Typography>
          </Box>
        ))}
      </Paper>
    );
  }
  return null;
};

export const CustomLineChart = ({
  data,
  xAxisKey,
  lines = [],
  height = 350,
  yAxisFormatter,
  xAxisFormatter,
  gridLines = true,
  showLegend = true,
  xAxisLabel = "", // New Prop
  yAxisLabel = "", // New Prop
}) => {
  // const theme = useTheme();
  const xAxisTicks = useMemo(() => {
    return data.map((item) => item?.[xAxisKey]).filter(Boolean);
  }, [data, xAxisKey]);
  return (
    <Box sx={{ width: "100%", height: height }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          // Increased bottom and left margins to make room for axis labels
          margin={{
            top: showLegend ? 30 : 20,
            right: 20,
            left: 10,
            bottom: xAxisLabel ? 65 : 50,
          }}
        >
          {gridLines && (
            <CartesianGrid
              strokeDasharray="3 3"
              horizontal={true}
              vertical={true}
            />
          )}

          <XAxis
            // dataKey={xAxisKey}
            // tickFormatter={xAxisFormatter}
            // // tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
            // // stroke={theme.palette.divider}
            // style={{
            //   fontSize: 11,
            // }}
            dataKey={xAxisKey}
            ticks={xAxisTicks}
            tickFormatter={xAxisFormatter}
            interval={0}
            minTickGap={0}
            angle={-45}
            textAnchor="end"
            height={60}
            tick={{
              fontSize: 10,
            }}
            allowDuplicatedCategory={false}
          >
            {xAxisLabel && (
              <Label
                value={xAxisLabel}
                offset={-10}
                position="insideBottom"
                style={{
                  textAnchor: "middle",
                  // fill: theme.palette.text.primary,
                  fontSize: 13,
                  fontWeight: 500,
                }}
              />
            )}
          </XAxis>

          <YAxis
            tickFormatter={yAxisFormatter}
            // tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
            // stroke={theme.palette.divider}
          >
            {yAxisLabel && (
              <Label
                value={yAxisLabel}
                angle={-90}
                position="insideLeft"
                style={{
                  textAnchor: "middle",
                  // fill: theme.palette.text.primary,
                  fontSize: 13,
                  fontWeight: 500,
                }}
              />
            )}
          </YAxis>

          <Tooltip
            content={<CustomTooltip yAxisFormatter={yAxisFormatter} />}
          />

          {showLegend && (
            <Legend
              layout="horizontal"
              verticalAlign="top"
              align="center"
              wrapperStyle={{
                top: 5,
                fontSize: "12px",
              }}
            />
          )}

          {lines.map((line) => (
            <Line
              key={line.dataKey}
              name={line.label}
              type="monotone"
              dataKey={line.dataKey}
              stroke={line.color}
              strokeWidth={line.strokeWidth || 2}
              dot={line.dot ?? true}
              activeDot={{ r: 6, strokeWidth: 0 }}
              // PERFORMANCE FIXES: Turn off all animations completely
              isAnimationActive={false} // Disables initial rendering layout animations
              animateNewValues={false} // Disables transitional sliding animations on new socket updates
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </Box>
  );
};
