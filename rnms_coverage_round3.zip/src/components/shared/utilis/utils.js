export const linksMap = {
  1: "VSAT",
  2: "E1/LOS",
  3: "E1/LOS",
  4: "Not Configured",
};

export const terminalType = {
  CNMS: 1,
  HUB_NMS: 2,
  MCT_MK_I: 3,
  MCT_MK_II: 5,
  MCT_LSV: 7,
  MCT_LSV_ALPHA: 8,
};

export const UpdateURlFun = (baseURL, updatedIp) => {
  var lashIndex = baseURL.search("//");
  var colonIndex = baseURL.lastIndexOf(":");

  return baseURL.replace(
    baseURL.substring(lashIndex + 2, colonIndex),
    updatedIp
  );
};
