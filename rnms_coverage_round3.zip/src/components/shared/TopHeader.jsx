/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from "react";
import Typography from "@mui/material/Typography";
import logoLeft from "../../assets/svg/BelLogo.svg";
import logoRight from "../../assets/svg/AirforceLogo.svg";
import { Box } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { InventAxios } from "../../RestAPI/api/axiosApicall";
import { DEPLOYED_TERMINAL_TYPE } from "../../RestAPI/url/endpoint";

const TopHeader = () => {
  const theme = useTheme();
  const [rnmsLanding, setRnmsLanding] = useState([]);

  useEffect(() => {
    const fetchDeplyoyedTerminalType = async () => {
      try {
        const response = await InventAxios(DEPLOYED_TERMINAL_TYPE, "get");
        setRnmsLanding(response.data);
      } catch (error) {
        console.log("Error", error);
      }
    };
    fetchDeplyoyedTerminalType();
  }, []);
  return (
    <Box
      sx={{
        height: 74,
        backgroundColor: "white",
        borderBottom: "2px solid #ccc",
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center" }}>
        <Box
          sx={{
            mr: "80px",
            pl: 8,
            [theme.breakpoints.down("md")]: {
              mr: "24px",
            },
          }}
        >
          <Box
            component="img"
            src={logoLeft}
            alt="Left Logo"
            sx={{ height: "57px", width: "19px" }}
          />
        </Box>
        <Typography
          variant="h6"
          sx={{
            flexGrow: 1,
            color: "black",
            fontFamily: "Montserrat",
            fontSize: "24",
            textAlign: "center",

            fontWeight: "600",
            "@media (maxWidth: 600px)": {
              fontSize: "0.6rem",
            },
          }}
        >
          {rnmsLanding.terminalNickname}
          <Typography
            variant="body1"
            sx={{
              color: "#000000",
              textAlign: "center",
              fontFamily: "Montserrat",
              fontWeight: "500",
              "@media (maxWidth: 600px)": {
                fontSize: "0.5rem",
              },
            }}
          >
            Version :{document.getElementById("about_Version").innerHTML}
          </Typography>
        </Typography>
        <Box
          sx={{
            ml: "auto",
            p: 1,
            [theme.breakpoints.down("600px")]: {
              // Earlier breakpoint for logos
              p: 4,
            },
          }}
        >
          <Box
            component="img"
            src={logoRight}
            alt="Right Logo"
            sx={{
              height: "69px",
              width: "71px",
              [theme.breakpoints.down("600px")]: {
                // Adjust logo earlier
                height: "40px",
                width: "35px",
              },
            }}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default TopHeader;
