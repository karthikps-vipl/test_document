import React, { useState } from "react";
import { IconButton, Box, Typography, Tooltip, useTheme } from "@mui/material";
import danger from "@/assets/SVGIcons/danger.svg";
import { useSelector } from "react-redux";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Popover from "@mui/material/Popover";

const FaultSummary = () => {
  const [openPopover, setOpenPopover] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  // const [activeAlarm, setActiveAlarm] = useState(0);
  const theme = useTheme();
  const tablePalette = theme.palette.custom.table;

  // 1. Get the LIVE data that ActiveAlarmTable is updating via dispatch
  const severityCount = useSelector((state) => state.alarmSlice.severityData);
  
  console.log(severityCount, "severityCount");
  // 2. Calculate total directly in the render or useMemo (much cleaner)
  const activeAlarm = React.useMemo(() => {
    const minor = severityCount?.[1] || 0;
    const major = severityCount?.[2] || 0;
    const warning = severityCount?.[0] || 0;
    return major + minor + warning;
  }, [severityCount]);
  const severityConfig = {
    MAJOR: {
      label: "Major",
      dotGradient: "linear-gradient(135deg, #ffced2 0%, #d75961 100%)",
    },
    MINOR: {
      label: "Minor",
      dotGradient: "linear-gradient(135deg, #ffff00 0%, #bdbd32 100%)",
    },
    WARNING: {
      label: "Warning",
      dotGradient: "linear-gradient(135deg, #72ffff 0%, #007c7c 100%)",
    },
  };

  const tableData = [
    { type: "MAJOR", count: severityCount?.[2] || 0 },
    { type: "MINOR", count: severityCount?.[1] || 0 },
    { type: "WARNING", count: severityCount?.[0] || 0 },
  ];

  const columns = [
    { name: "Color", uid: "color" },
    { name: "Severity", uid: "severity" },
    { name: "Count", uid: "count" },
  ];

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenPopover(true);
  };

  const handleClose = () => {
    setOpenPopover(false);
    setAnchorEl(null);
  };

  const isdark = theme.palette.mode === "dark";
  return (
    <Box className="relative">
      <Tooltip title="Fault Summary" arrow>
        <IconButton
          onClick={handleClick}
          aria-describedby="fault-summary-popover"
        >
          <img
            src={danger}
            alt="Danger"
            className={`w-6 h-6 object-contain  `}
          />
          <span className="absolute -top-0.5 left-5 bg-red-600 text-white text-[10px] h-4 w-4 flex items-center justify-center rounded-full">
            {activeAlarm}
          </span>
        </IconButton>
      </Tooltip>

      <Popover
        open={openPopover}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        PaperProps={{
          sx: {
            borderRadius: "20px", // Adjust as needed
            overflow: "hidden", // IMPORTANT: This ensures child elements don't overlap the corners
            boxShadow: "0px 4px 20px rgba(0,0,0,0.1)", // Optional: makes it look cleaner
          },
        }}
      >
        <Box sx={{ p: 1 }}>
          <Typography sx={{ color: tablePalette.headerText }}>
            Alarm Summary
          </Typography>
          <Box sx={{ ml: -2, border: "1px solid #eee", mr: -3, mb: 1 }} />

          <TableContainer
            sx={{
              borderRadius: "15px",
              overflow: "hidden",
              border: `1px solid ${tablePalette.border}`, // Use dynamic border
            }}
          >
            <Table size="small" sx={{ borderCollapse: "collapse" }}>
              <TableHead>
                <TableRow>
                  {columns.map((col) => (
                    <TableCell
                      key={col.uid}
                      sx={{
                        bgcolor: tablePalette.headerBg, // Dynamic background
                        color: tablePalette.headerText, // Dynamic text color
                        borderRight: `1px solid ${tablePalette.border}`, // Dynamic border
                        whiteSpace: "nowrap",
                      }}
                    >
                      {col.name}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {tableData.map((row, index) => {
                  // 1. Look up the config based on the type (MAJOR, MINOR, etc.)
                  const config = severityConfig[row.type];

                  return (
                    <TableRow key={index} hover>
                      {/* CIRCLE COLUMN */}
                      <TableCell
                        sx={{
                          borderRight: `1px solid ${tablePalette.border}`,
                          borderBottom: `1px solid ${tablePalette.border}`,
                          textAlign: "center",
                          verticalAlign: "middle",
                        }}
                      >
                        <span
                          className="circle"
                          style={{
                            display: "inline-block",
                            width: "12px",
                            height: "12px",
                            borderRadius: "50%",
                            // 2. USE THE GRADIENT FROM CONFIG HERE
                            background: config.dotGradient,
                          }}
                        />
                      </TableCell>

                      {/* SEVERITY TEXT COLUMN */}
                      <TableCell
                        sx={{
                          borderRight: `1px solid ${tablePalette.border}`,
                          borderBottom: `1px solid ${tablePalette.border}`,
                          textAlign: "center",
                          verticalAlign: "middle",
                        }}
                      >
                        {/* 3. USE THE LABEL FROM CONFIG HERE */}
                        {config.label}
                      </TableCell>

                      {/* COUNT COLUMN */}
                      <TableCell
                        sx={{
                          borderRight: "none",
                          borderBottom: `1px solid ${tablePalette.border}`,
                          textAlign: "center",
                          verticalAlign: "middle",
                        }}
                      >
                        {row.count}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Popover>
    </Box>
  );
};

export default FaultSummary;
