import React, { useState, useEffect } from 'react';
import { IconButton, Box, Typography, Tooltip, useTheme } from '@mui/material';
import information from '@/assets/SVGIcons/information.svg';
import MModal from '@/components/Reusable/Modal/MModal';

const InfoModalSection = () => {
    const [openModal, setOpenModal] = useState(false);
    const [aboutDate, setAboutDate] = useState('N/A');
    const [aboutVersion, setAboutVersion] = useState('N/A');

    useEffect(() => {
        const readFromHtml = () => {
            const dateSpan = document.getElementById('about_Date'); 
            const versionSpan = document.getElementById('about_Version');  

            if (dateSpan && dateSpan.textContent) {
                setAboutDate(dateSpan.textContent);
            } else {
                setAboutDate('N/A');
            }

            if (versionSpan && versionSpan.textContent) {
                setAboutVersion(versionSpan.textContent);
            } else {
                setAboutVersion('N/A');
            }
        };

        readFromHtml();  // Call immediately after mounting

    }, []);
      const theme = useTheme(); 
    const isdark = theme.palette.mode === 'dark';
    return (
        <div className="relative">
          <Tooltip title="About" arrow> 
            <IconButton onClick={() => setOpenModal(true)}>
                <img src={information} alt="information"
                className={`w-6 h-6 object-contain ${isdark ? 'brightness-0 invert' : ''}`}/>
            </IconButton>
            </Tooltip> 
            <MModal
                open={openModal}
                handleClose={() => setOpenModal(false)}
                title="About"
                fullScreen={false}
                enableFullScreen
            >
                <Box >
                    <Typography >
                        Designed and Developed by BEL, Bangalore. 
                       
                    </Typography>
                    <Typography>
                    Copyright © 2026  Bharat Electronics Limited.
                    </Typography>
                    <Typography variant="body2">
                        Date: {aboutDate}
                    </Typography>
                    <Typography variant="body2">
                        Version:{aboutVersion}
                    </Typography>
                    <Typography variant="body2" >
                        Best Viewed in Google Chrome(v 136.0+) and Mozilla Firefox(130+)
                    </Typography>
                </Box>
            </MModal>
        </div>
    );
};

export default InfoModalSection;
 
