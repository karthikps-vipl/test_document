import React from "react";
import { useSelector } from "react-redux";
import { Box, Typography, Tooltip } from "@mui/material";

const STATUS_MAP = {
  0: {
    label: "N/A",
    color: "#808080",
    textColor: "#ffffff",
  },
  1: {
    label: "DC",
    color: "#2e7d32",
    textColor: "#ffffff",
  },
  2: {
    label: "DR",
    color: "#edc531",
    textColor: "#202020",
  },
  3: {
    label: "DOWN",
    color: "#d32f2f",
    textColor: "#ffffff",
  },
};

// Confirm these IDs with your backend.
const SITE_TYPE_MAP = {
  1: {
    name: "Mt.Abu",
    shortName: "A",
  },
  2: {
    name: "KSL",
    shortName: "B",
  },
};

const getStatus = (linkStatus) => {
  return STATUS_MAP[linkStatus] || STATUS_MAP[0];
};

const CnmsActiveStatus = () => {
  const sites = useSelector((state) => state.cnmsActiveStatus?.sites ?? []);

  // Match site records using the backend's siteType.
  const getSite = (siteType) =>
    sites.find((site) => Number(site.siteType) === Number(siteType));

  const siteCards = [1, 2].map((siteType) => {
    const config = SITE_TYPE_MAP[siteType];
    const site = getSite(siteType);

    const status = site ? getStatus(Number(site.linkStatus)) : STATUS_MAP[0];

    return {
      ...config,
      site,
      status,
    };
  });

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 0.5,
        flexShrink: 0,
      }}
    >
      {siteCards.map((item, index) => (
        <React.Fragment key={item.shortName}>
          {index === 1 && (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                minWidth: 24,
                mx: 0.25,
              }}
            >

              <Box
                sx={{
                  width: "100%",
                  height: 2,
                  bgcolor: "text.secondary",
                  mt: 0.25,
                }}
              />
            </Box>
          )}

          <Tooltip
            key={item.shortName}
            arrow
            title={
              item.site
                ? `${item.name} | IP: ${item.site.ipaddress} | Link Status: ${item.status.label}`
                : `${item.name} | Waiting for status`
            }
          >
            <Box
              sx={{
                minWidth: 90,
                px: 1,
                py: 0.75,
                borderRadius: 1.5,
                backgroundColor: item.status.color,
                color: item.status.textColor,
                textAlign: "center",
                border: "1px solid rgba(0,0,0,0.15)",
                transition: "background-color 200ms ease",
              }}
            >
              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 800,
                  lineHeight: 1.3,
                  whiteSpace: "nowrap",
                  display: "flex", // Ensures items stay in a row
                  alignItems: "center", // Vertically aligns text
                  justifyContent: "center", // Centers content horizontally
                  gap: 0.5, // Adds a small space between name and bracket
                }}
              >
                {item.name}
                <Box
                  component="span"
                  sx={{ fontSize: 10, fontWeight: 600, opacity: 0.9 }}
                >
                  ({item.status.label})
                </Box>
              </Typography>
            </Box>
          </Tooltip>
        </React.Fragment>
      ))}
    </Box>
  );
};

export default CnmsActiveStatus;
