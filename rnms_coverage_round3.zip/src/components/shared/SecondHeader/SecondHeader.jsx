import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setToggleLeftSideBar } from "../../../store/features/LeftSideBar/leftSideBar";
import {
  Button,
  Typography,
  IconButton,
  Tooltip,
  Box,
  useTheme,
} from "@mui/material";
import {
  InventoryAxios,
  NmsMessageAxios,
  PerformanceAxios,
  TopologyAxios,
} from "@/RestAPI/api/axiosApicall";
import {
  CNMS_STATUS_URL,
  FETCH_CPU_RAM_DISK,
  FETCH_EXISTING_LINK_CONFIGURATION_DETAILS,
  PUBLISHER_STATUS_URL,
  SUBSCRIBER_STATUS_URL,
} from "@/RestAPI/url/endpoint";

import Manual from "../../../assets/SVGIcons/Manual.svg";
import { MenuIcon } from "lucide-react";
import { linksMap, terminalType } from "../utilis/utils";

// Import our new component
import InfoModalSection from "@/components/shared/SecondHeader/components/InfoModalSection";
import FaultSummary from "@/components/shared/SecondHeader/components/faultsummary";
import DashboardTabs from "@/Pages/Rnmsdashboard/DashboardTabs/DashboardTabs";
import { Progress } from "antd";
import { setLinkStatusData } from "@/store/features/Topology/topologyNodesslice";
import { ArrowUpSVG } from "@/assets/SVGIcons/ArrowUpSVG";
import { ArrowDownSVG } from "@/assets/SVGIcons/ArrowDownSVG";
import { setHealthStatus } from "@/store/features/LinkStatus/cnmsStatusSlice";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";
import SmsAndEmailSettings from "./SMSandEmailSettings/SmsAndEmailSettings";
import emailIcon from "@/assets/SVGIcons/cnms/Email Composer.svg";

import CNMSFaultSummary from "@/Pages/CnmsDashboard/CnmsAlarmSummary/CNMSFaultSummary";
import {
  setCnmsActiveStatusError,
  setCnmsActiveStatuses,
  setCnmsActiveStatusLoading,
} from "@/store/features/Cnms/remoteRepDetails/cnmsActiveStatusSlice";
import { FETCH_CNMS_ACTIVE_STATUS_DETAIL } from "@/RestAPI/url/cnmsEndPoint";
import CnmsActiveStatus from "./CnmsActiveStatus";
const SecondHeader = ({ activeViewKey, setActiveViewKey }) => {
  const dispatch = useDispatch();
  const { leftSidebarVisible } = useSelector((state) => state.leftSidebarSlice);
  // const [navbarData, setNavbarData] = useState([]);
  const cnmsStatusState = useSelector((state) => state.cnmsStatus.healthStatus);
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const privilegesSet = useSelector(selectPrivilegesSet);
  const [isActiveSmsSmtp, setIsActiveSmsSmtp] = React.useState(false);

  console.log(cnmsStatusState, "");
  const linkStatusData = useSelector(
    (state) => state.topologySlice.linkStatusData
  );
  const POLL_INTERVAL = 30000;

  const getStatusInfo = (status) => {
    if (status === true) {
      return {
        color: "#4caf50",
        iconType: "up",
        iconColor: "#4caf50",
      };
    } else if (status === false) {
      return {
        color: "#f44336",
        iconType: "down",
        iconColor: "#f44336",
      };
    } else {
      return {
        color: "#f44336",
        iconType: "down",
        iconColor: "#f44336",
      };
    }
  };
  const [msgRxStatus, setMsgRxStatus] = useState(false);
  const [msgTxStatus, setMsgTxStatus] = useState(false);
  const [cnmsStatus, setCnmsStatus] = useState(3);

  const refreshCnmsStatus = async () => {
    try {
      const response = await InventoryAxios(CNMS_STATUS_URL, "get");

      const data = response?.data;

      console.log("CNMS API Response:", data);

      let healthStatus = 3;

      if (data && typeof data === "object") {
        healthStatus = data.healthStatus;

        // If healthStatus is inside nested data
        if (healthStatus === undefined && typeof data.data === "string") {
          try {
            const nestedData = JSON.parse(data);
            healthStatus = nestedData?.healthStatus;
          } catch (error) {
            console.error("Failed to parse nested CNMS data");
          }
        }
      } else if (typeof data === "string") {
        try {
          const parsedData = JSON.parse(data);
          healthStatus = parsedData?.healthStatus;
        } catch (error) {
          console.error("Failed to parse CNMS API response");
        }
      }

      // Only accept 0, 1, 2
      if ([0, 1, 2].includes(healthStatus)) {
        dispatch(
          setHealthStatus({
            status: healthStatus,
            timestamp: new Date().toISOString(),
          })
        );

        console.log("CNMS API status updated:", healthStatus);
      } else {
        // Unknown
        dispatch(
          setHealthStatus({
            status: 3,
            timestamp: new Date().toISOString(),
          })
        );
      }
    } catch (err) {
      console.error("Failed to fetch CNMS status:", err);

      // API failed = Unknown, NOT DOWN
      dispatch(
        setHealthStatus({
          status: 3,
          timestamp: new Date().toISOString(),
        })
      );
    }
  };

  const fetchStatusData = async () => {
    if (isCnms) return;
    try {
      const rxPromise = NmsMessageAxios(SUBSCRIBER_STATUS_URL, "get");
      const txPromise = NmsMessageAxios(PUBLISHER_STATUS_URL, "get");

      const [rxResponse, txResponse] = await Promise.all([
        rxPromise,
        txPromise,
      ]);

      const rxData = rxResponse?.data;
      const txData = txResponse?.data;

      if (rxData !== undefined) {
        setMsgRxStatus(rxData);
      }
      if (txData !== undefined) {
        setMsgTxStatus(txData);
      }
    } catch (err) {
      console.error("Failed to fetch messaging status:", err);

      setMsgRxStatus(false);
      setMsgTxStatus(false);
    }
  };

  useEffect(() => {
    if (isCnms) return;
    refreshCnmsStatus();
    fetchStatusData();

    const intervalId = setInterval(fetchStatusData, POLL_INTERVAL);

    return () => {
      clearInterval(intervalId);
    };
  }, [isCnms]);

  useEffect(() => {
    if (!isCnms) return;

    let cancelled = false;

    const fetchActiveStatus = async () => {
      dispatch(setCnmsActiveStatusLoading(true));

      try {
        const response = await InventoryAxios(
          FETCH_CNMS_ACTIVE_STATUS_DETAIL,
          "get"
        );

        if (cancelled) return;

        const data = response?.data;

        dispatch(setCnmsActiveStatuses(data));
      } catch (error) {
        if (cancelled) return;

        console.error("Failed to fetch CNMS active status:", error);

        dispatch(
          setCnmsActiveStatusError("Failed to fetch CNMS active status")
        );
      }
    };

    fetchActiveStatus();

    return () => {
      cancelled = true;
    };
  }, [isCnms, dispatch]);

  const navbarData = useMemo(() => {
    const statusMap = {
      0: {
        color: "#f44336",
        tooltip: "CNMS is down",
      },

      1: {
        color: "#4caf50",
        tooltip: "CNMS is up",
      },

      2: {
        color: "#fbc02d",
        tooltip: "CNMS operationally down",
      },

      3: {
        color: "gray",
        tooltip: "CNMS unknown",
      },
    };
    const links = linkStatusData.map((item) => {
      const status = statusMap[item.linkStatus] || statusMap[3];
      return {
        label: item.linkName,
        color: status.color,
        icon:
          item.linkStatus === 1 ? (
            <ArrowUpSVG size={20} color={status.color} />
          ) : (
            <ArrowDownSVG size={20} color={status.color} />
          ),
      };
    });

    const cnmsConfig = statusMap[cnmsStatusState] || statusMap[3];

    const specificItems = [
      {
        label: "CNMS",
        color: cnmsConfig.color,
        icon:
          cnmsStatusState === 1 ? (
            <ArrowUpSVG size={20} color={cnmsConfig.color} />
          ) : (
            <ArrowDownSVG size={20} color={cnmsConfig.color} strokeWidth={4} />
          ),
        tooltip: cnmsConfig.tooltip,
      },

      {
        label: "Msg Rx",
        config: getStatusInfo(msgRxStatus),
      },

      {
        label: "Msg Tx",
        config: getStatusInfo(msgTxStatus),
      },
    ];
    return [
      ...links,
      ...specificItems.map((item) => {
        if (item.config) {
          return {
            label: item.label,
            color: item.config.color,
            icon:
              item.config.iconType === "up" ? (
                <ArrowUpSVG size={20} color={item.config.iconColor} />
              ) : (
                <ArrowDownSVG
                  size={20}
                  color={item.config.iconColor}
                  strokeWidth={4}
                />
              ),
          };
        }

        return item;
      }),
    ];

    const finalSpecificItems = specificItems.map((item, index) => {
      const isDynamicMsg = item.config !== undefined;
      const isDynamicCnms = item.status !== undefined;

      if (isDynamicCnms) {
        const cnmsConfig = statusMap[item.status] || statusMap[3];
        return {
          label: item.label,
          color: cnmsConfig.color,
          icon:
            item.status === 1 ? (
              <ArrowUpSVG size={20} color={cnmsConfig.color} />
            ) : (
              <ArrowDownSVG
                size={20}
                color={cnmsConfig.color}
                strokeWidth={4}
              />
            ),
          tooltip: cnmsConfig.tooltip,
        };
      }

      return {
        label: item.label,
        color: isDynamicMsg ? item.config.color : item.color,
        icon: isDynamicMsg ? (
          item.config.iconType === "up" ? (
            <ArrowUpSVG size={20} color={item.config.iconColor} />
          ) : (
            <ArrowDownSVG
              size={20}
              color={item.config.iconColor}
              strokeWidth={4}
            />
          )
        ) : (
          item.icon
        ),
      };
    });

    return [...links, ...finalSpecificItems];
  }, [linkStatusData, msgRxStatus, msgTxStatus, cnmsStatusState]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  const siteDetails = useSelector((state) => state.nodeDetails?.siteDetails);
  console.log(siteDetails, "siteDetails");
  // Inside SecondHeader component
  const performanceDataMap = useSelector(
    (state) => state.performance.performanceData
  );
  const activeResourceId = useSelector((state) => state.performance.resourceId);

  // The current component uses performanceData from an API call:
  // const [performanceData, setPerformanceData] = useState([]); <--- REMOVE THIS
  const [loadingPerf, setLoadingPerf] = useState(true);
  const [apiPerformanceData, setApiPerformanceData] = useState([]);

  useEffect(() => {
    if (isCnms) return;
    const fetchData = async () => {
      try {
        const res = await PerformanceAxios(FETCH_CPU_RAM_DISK, "get", 1);
        if (Array.isArray(res.data)) setApiPerformanceData(res.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoadingPerf(false);
      }
    };
    fetchData();
  }, [isCnms]);

  useEffect(() => {
    if (isCnms) return;
    const fetchLinkData = async () => {
      try {
        const response = await TopologyAxios(
          FETCH_EXISTING_LINK_CONFIGURATION_DETAILS,
          "get"
        );

        if (Array.isArray(response.data)) {
          dispatch(setLinkStatusData(response.data));
        }
      } catch (err) {
        // Fallback to dummy data if API fails
        // setNavbarData(dummyData);
        setError("Failed to fetch link data.");
      } finally {
        setLoading(false);
      }
    };

    fetchLinkData();
  }, [isCnms, dispatch]);
  const progressBar = React.useMemo(() => {
    const liveMetrics = performanceDataMap[activeResourceId] || {};

    const getMetricValue = (paramId) => {
      // STEP A: Try to get value from WebSocket (Live)
      if (liveMetrics[paramId] !== undefined) {
        return parseFloat(liveMetrics[paramId]);
      }

      // STEP B: If no WebSocket data, fall back to API Array data
      const apiItem = apiPerformanceData.find(
        (i) => i.perfParamInfoBean?.paramId === paramId
      );
      return apiItem ? parseFloat(apiItem.data) : 0;
    };

    return [
      {
        id: "cpu",
        label: "CPU %",
        percent: getMetricValue(1400),
      },
      {
        id: "ram",
        label: "RAM %",
        percent: getMetricValue(1600),
      },
      {
        id: "disk",
        label: "Disk %",
        percent: getMetricValue(2100),
      },
    ];
  }, [apiPerformanceData, performanceDataMap, activeResourceId]); // Re-calculate whenever Redux updates

  const theme = useTheme();

  const isdark = theme.palette.mode === "dark";

  return (
    <Box
      className="w-full"
      sx={{
        border: (theme) => theme.palette.custom.dashboardBorder,
        display: "flex",
        alignItems: "center",
        px: 2.5,
        gap: 1,
        backgroundColor: (theme) => theme.palette.background.paper,
      }}
    >
      <Box className="flex w-full items-center justify-between gap-2">
        {/* 1. LEFT: Toggle + Info */}
        <Box className="flex items-center gap-4">
          <Tooltip title={isCnms ? "Map view" : "Device Details"} arrow>
            <Button
              variant="contained"
              sx={{
                minWidth: "auto",
                p: 0.5,
                bgcolor: "#E9EFFF",
                "&:hover": { bgcolor: "#f0f0f0" },
              }}
              onClick={() => dispatch(setToggleLeftSideBar())}
            >
              <MenuIcon
                className={
                  leftSidebarVisible ? "text-blue-500" : "text-gray-600"
                }
              />
            </Button>
          </Tooltip>

          {/* <Box className="flex flex-col justify-start items-start">
            <Typography
              variant="subtitle2"
              title={`#${String(repDetails?.remoteNumber || 0).padStart(
                3,
                "0"
              )}: ${repDetails?.siteName || "empty"}`}
              sx={{
                color: "text.primary",
                fontWeight: "bold",
                lineHeight: 1.2,
                textAlign: "left",
                cursor: "default",
              }}
            >
              {(() => {
                const fullText = `#${String(
                  repDetails?.remoteNumber || 0
                ).padStart(3, "0")}: ${repDetails?.siteName || "empty"}`;
                return fullText.length > 15
                  ? fullText.substring(0, 25) + "..."
                  : fullText;
              })()}
            </Typography>

            {siteDetails?.id !== terminalType.CNMS &&
              repDetails?.imTerminalMode && (
                <Typography
                  variant="caption"
                  color="text.gray"
                  sx={{ textAlign: "left" }}
                >
                  Role: {repDetails?.imTerminalMode.name} /{" "}
                  {linksMap[repDetails?.activeModeOfCommunication]}
                </Typography>
              )}
          </Box> */}

          <Box className="flex flex-col justify-start items-start">
            <Typography
              variant="subtitle2"
              // The title (tooltip) should still show the actual site name for debugging/full info
              title={`${
                siteDetails?.imTerminalType?.terminalTypeName || ""
              }: #${String(siteDetails?.remoteNumber || 0).padStart(3, "0")}: ${
                siteDetails?.siteName || "empty"
              }`}
              sx={{
                color: "text.primary",
                fontWeight: "bold",
                lineHeight: 1.2,
                textAlign: "left",
                cursor: "default",
              }}
            >
              {isCnms &&
                (() => {
                  // 1. Find the active site from the array first
                  const activeSite = repDetails?.find(
                    (site) => site.isActive === true
                  );
                  // 2. If no active site is found, return a fallback or empty string
                  if (!activeSite) return "No active site";
                  // 3. Get the Prefix (e.g., CNMS)
                  const terminalTypePrefix =
                    activeSite?.imTerminalType?.terminalTypeName || "";
                  // 4. Handle the #DC condition
                  const remoteNum =
                    activeSite.remoteNumber === 1 ||
                    activeSite.remoteNumber === 2
                      ? "DC"
                      : String(activeSite.remoteNumber || 0).padStart(3, "0");
                  // 5. Get the Site Name (just use it directly)
                  const siteName = activeSite.siteName || "empty";
                  // 6. Combine: [Type] #[DC or Number]: [Site Name]
                  const fullText = `${terminalTypePrefix} #${remoteNum}: ${siteName}`;
                  // 7. Truncation
                  return fullText.length > 25
                    ? fullText.substring(0, 22) + "..."
                    : fullText;
                })()}
            </Typography>

            {siteDetails?.id !== terminalType.CNMS &&
              repDetails?.imTerminalMode && (
                <Typography
                  variant="caption"
                  color="text.gray"
                  sx={{ textAlign: "left" }}
                >
                  Role: {repDetails?.imTerminalMode.name} /{" "}
                  {linksMap[repDetails?.activeModeOfCommunication]}
                </Typography>
              )}
          </Box>
          <Box>
            <DashboardTabs
              activeTabKey={activeViewKey}
              setActiveTabKey={setActiveViewKey}
            />
          </Box>
        </Box>

        {/* 3. RIGHT: Icons & Manual */}
        <Box className="flex items-center gap-x-2">
          {/* 2. CONDITIONAL RENDERING: Only show if NOT isCnms */}
          {!isCnms && (
            <>
              {/* Progress Bar Section */}
              <Box className="flex items-center gap-x-2">
                {!loadingPerf &&
                  progressBar.map((item) => {
                    let numberColor = "#234F16";
                    if (item.percent >= 95) numberColor = "#ED1C24";
                    else if (item.percent >= 80) numberColor = "#FFA500";

                    return (
                      <Tooltip
                        key={item.id}
                        title={`${item.label}: ${item.percent}%`}
                        arrow
                        placement="bottom"
                      >
                        <Box className="flex flex-col items-center mt-2">
                          <Box className="flex items-center justify-center font-bold bg-white rounded-full">
                            <Progress
                              type="circle"
                              percent={item.percent}
                              size={40}
                              strokeWidth={10}
                              strokeColor={{
                                "0%": "#377D22",
                                "50%": "#FFA500",
                                "100%": "#ED1C24",
                              }}
                              format={(percent) => (
                                <span
                                  style={{
                                    color: numberColor,
                                    fontWeight: "bold",
                                    fontSize: 14,
                                  }}
                                >
                                  {percent}
                                </span>
                              )}
                            />
                          </Box>
                          <span
                            className="text-[9px] font-bold uppercase"
                            style={{ color: isdark ? "#FFFFFF" : "#000000" }}
                          >
                            {item.label}
                          </span>
                        </Box>
                      </Tooltip>
                    );
                  })}
              </Box>

              {/* Navbar Data (Icons) Section */}
              <Box className="flex items-center gap-x-1 xl:gap-x-2">
                {navbarData.map((item, index) => (
                  <Tooltip key={index} title={item.tooltip || item.label} arrow>
                    <Box
                      className="flex items-center px-1 py-1 xl:px-2 xl:py-1 rounded-full shadow-sm"
                      sx={{
                        border: `2px solid ${item.color}`,
                        backgroundColor: isdark ? "#333" : "#ffffff",
                      }}
                    >
                      <Box className="scale-75 xl:scale-100">{item.icon}</Box>
                      <Typography
                        variant="caption"
                        sx={{
                          fontSize: { xs: "9px", xl: "11px" },
                          fontWeight: "bold",
                          color: isdark ? "#FFFFFF" : "#000000",
                          ml: { xs: 0.2, xl: 0.5 },
                        }}
                      >
                        {item.label}
                      </Typography>
                    </Box>
                  </Tooltip>
                ))}
              </Box>
            </>
          )}
          {/* End Conditional Rendering */}
          {isCnms && <CnmsActiveStatus />}
          {isCnms && privilegesSet.has("sms_email") && (
            <Tooltip title="SMS & Email Settings" placement="bottom">
              <button
                onClick={() => {
                  setIsActiveSmsSmtp(true);
                }}
                style={{ cursor: "pointer" }}
              >
                {/* <Email /> */}

                <img
                  src={emailIcon}
                  style={{
                    width: "45px",
                    height: "25px",
                    filter: theme.palette.custom.icon.iconFilter,
                  }}
                />
              </button>
            </Tooltip>
          )}

          {isActiveSmsSmtp && (
            <SmsAndEmailSettings
              onClose={() => {
                setIsActiveSmsSmtp(false);
              }}
            />
          )}

          {isCnms ? <CNMSFaultSummary /> : <FaultSummary />}
          <Tooltip title="Information" arrow>
            <InfoModalSection />
          </Tooltip>
          <Tooltip title="User Manual" arrow>
            <IconButton
              size="small"
              component="a"
              href="/mctlsv.html"
              target="_blank"
            >
              <img
                src={Manual}
                alt="Manual"
                className="w-6 h-6 object-contain"
              />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>
    </Box>
  );
};
export default SecondHeader;
