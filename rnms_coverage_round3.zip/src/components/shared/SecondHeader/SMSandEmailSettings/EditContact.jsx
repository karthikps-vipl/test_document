import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MModal from "@/components/Reusable/Modal/MModal";
import MInput from "@/components/Reusable/Input/MInput";
import { restrict } from "@/lib/utils";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import { SAVE_AND_UPDATE_USERS } from "@/RestAPI/url/cnmsEndPoint";
import { Box, CircularProgress, Typography } from "@mui/material";
import React, { useState } from "react";
import { useForm } from "react-hook-form";

export function EditContact({ onClose, showToast, selectedContact }) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting, isDirty },
  } = useForm({
    mode: "onChange",
    defaultValues: {
      userName: selectedContact?.userName || "",
      countryCode:
        selectedContact?.mobile?.length > 10
          ? selectedContact.mobile.slice(0, 2)
          : "91",
      mobile:
        selectedContact?.mobile?.length > 10
          ? selectedContact.mobile.slice(-10)
          : selectedContact?.mobile || "",
      emailId: selectedContact?.emailId || "",
    },
  });

  const [updatingContact, setUpdatingContact] = useState(false);

  const updateContact = async (data) => {
    const req = [
      {
        id: selectedContact.id,
        mobile: data.countryCode + data.mobile,
        emailId: data.emailId,
        userName: data.userName,
      },
    ];

    setUpdatingContact(true);
    try {
      await SmsAxios(SAVE_AND_UPDATE_USERS, "post", req);
      showToast("Updated successfully", "success");
      onClose();
    } catch (error) {
      console.error(error);
      showToast("Failed to Update", "error");
    }
    setUpdatingContact(false);
  };

  console.log(isDirty, "isDirtyisDirty");

  return (
    <form onSubmit={handleSubmit(updateContact)}>
      <MModal
        title="Edit Contact"
        handleClose={onClose}
        open={true}
        customWidth={"1008px"}
      >
        <Box sx={{ display: "flex", gap: 1, mt: 2 }}>
          <Box sx={{ display: "flex", width: "30%", flexDirection: "column" }}>
            <Typography>Name*</Typography>
            <MInput
              {...register("userName", {
                required: "Name is required",
                minLength: {
                  value: 3,
                  message: "Minimum 3 character required",
                },
                maxLength: {
                  value: 50,
                  message: "Exceeded max characters allowed",
                },
              })}
              fullWidth
              onInput={restrict.name}
              inputProps={{ maxLength: 50 }}
              label="Name"
              placeholder="Enter Name"
              variant="outlined"
              size="small"
              error={!!errors?.userName}
              helperText={errors.userName?.message}
              multiline
              maxRows={2}
            />
          </Box>

          <Box sx={{ display: "flex", width: "10%", flexDirection: "column" }}>
            <Typography>Code*</Typography>
            <MInput
              {...register("countryCode", {
                required: "Required",
                minLength: {
                  value: 2,
                  message: "Invalid",
                },
              })}
              fullWidth
              defaultValue={
                selectedContact?.mobile?.length > 10
                  ? selectedContact?.mobile.slice(0, 2)
                  : "91"
              }
              onInput={restrict.number}
              inputProps={{ maxLength: 2 }}
              label="Code"
              placeholder="Country Code"
              variant="outlined"
              size="small"
              error={!!errors?.countryCode}
              helperText={errors?.countryCode?.message}
            />
          </Box>

          <Box sx={{ display: "flex", width: "30%", flexDirection: "column" }}>
            <Typography>Mobile Number*</Typography>
            <MInput
              {...register("mobile", {
                required: "Mobile Number is required",
                minLength: {
                  value: 10,
                  message: "Invalid Mobile Number",
                },
                maxLength: {
                  value: 10,
                  message: "Exceeded max characters allowed",
                },
                pattern: {
                  value: /^[6-9][0-9]{9}/,
                  message: "Incorrect mobile number format",
                },
              })}
              fullWidth
              defaultValue={
                selectedContact?.mobile?.length > 10
                  ? selectedContact?.mobile.slice(-10)
                  : selectedContact?.mobile
              }
              onInput={restrict.number}
              inputProps={{ maxLength: 10 }}
              label="Mobile"
              placeholder="Enter Mobile"
              variant="outlined"
              size="small"
              error={!!errors?.mobile}
              helperText={errors?.mobile?.message}
            />
          </Box>

          <Box sx={{ display: "flex", width: "30%", flexDirection: "column" }}>
            <Typography>Email Address*</Typography>
            <MInput
              {...register("emailId", {
                required: "Email Address is required",
                pattern: {
                  value:
                    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/,
                  message: "Email is not valid!",
                },
                maxLength: {
                  value: 50,
                  message: "Exceeded max characters allowed",
                },
              })}
              fullWidth
              defaultValue={selectedContact?.emailId || ""}
              onInput={restrict.email}
              inputProps={{ maxLength: 50 }}
              label="Email"
              placeholder="Enter Email"
              variant="outlined"
              size="small"
              error={!!errors?.emailId}
              helperText={errors?.emailId?.message}
              multiline
              maxRows={2}
            />
          </Box>
        </Box>

        <Box sx={{ float: "right", mt: 2 }}>
          <MButtonPrimary
            onClick={handleSubmit(updateContact)}
            variant="contained"
            color="primary"
            disabled={!isDirty || isSubmitting || updatingContact}
          >
            {updatingContact && <CircularProgress size="24px" />} Update
          </MButtonPrimary>
        </Box>
      </MModal>
    </form>
  );
}
