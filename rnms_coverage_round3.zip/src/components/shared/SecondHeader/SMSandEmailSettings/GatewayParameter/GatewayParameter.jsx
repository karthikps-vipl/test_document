import MModal from "@/components/Reusable/Modal/MModal";
import { Box, Tab, Tabs, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import SmsParameter from "./Sms";
import EmailParameter from "../Email";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div hidden={value !== index} {...other}>
      {value === index && <Typography>{children}</Typography>}
    </div>
  );
}

const styles = {
  activeTab: {
    background: "green",
    opacity: "1",
    color: "black",
    borderBottom: `0.2em solid `,
  },
};

const GatewayParameter = ({
  onClose,
  showToast,
  getSmtpConnectivityStatus,
  getSmsConnectivityStatus,
  setSmsParam,
  setEmailParam,
}) => {
  const privilegesSet = useSelector(selectPrivilegesSet);
  const [value, setValue] = useState("sms");

  const handleChange = (event, newValue) => {
    setValue(newValue);
    console.log("dk tabs", newValue);
  };

  useEffect(() => {
    privilegesSet.has("sms_email_sms_parameter")
      ? setValue("sms")
      : setValue("email");
  }, [privilegesSet]);

  return (
    <MModal
      open={true}
      fullWidth
      title="SMS/E-Mail Gateway Parameter"
      handleClose={onClose}
      customWidth={`${value === "sms" ? "450px" : "770px"}`}
    >
      {/* Container for Tabs and the View/Modify Switch */}
      <Box
        sx={{
          borderBottom: 1,
          borderColor: "divider",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 2,
        }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          textColor="primary"
          sx={{
            "& .MuiTab-root": { textTransform: "none", fontWeight: "medium" },
          }}
        >
          {privilegesSet.has("sms_email_sms_parameter") && (
            <Tab value="sms" label="SMS" />
          )}
          {privilegesSet.has("sms_email_email_parameter") && (
            <Tab value="email" label="E-Mail" />
          )}
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ mt: 3, px: 2, pb: 2 }}>
        <TabPanel value={value} index={"sms"}>
          <SmsParameter
            setSmsParam={setSmsParam}
            onClose={onClose}
            showToast={showToast}
            getSmsConnectivityStatus={getSmsConnectivityStatus}
          />
        </TabPanel>
        <TabPanel value={value} index={"email"}>
          <EmailParameter
            setEmailParam={setEmailParam}
            onClose={onClose}
            showToast={showToast}
            getSmtpConnectivityStatus={getSmtpConnectivityStatus}
          />
        </TabPanel>
      </Box>
    </MModal>
  );
};

export default GatewayParameter;
