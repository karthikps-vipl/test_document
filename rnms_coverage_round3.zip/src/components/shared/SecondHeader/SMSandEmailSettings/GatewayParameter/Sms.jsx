import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";

import { restrict } from "@/lib/utils";
import { useSelector } from "react-redux";
import { useCallback, useEffect, useState } from "react";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_SMS_GATEWAY,
  SAVE_AND_UPDATE_SMS_GATEWAY,
} from "@/RestAPI/url/cnmsEndPoint";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";
import { Box, CircularProgress, Grid, Typography } from "@mui/material";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import { Save } from "@mui/icons-material";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Loader from "@/components/Reusable/Loader/Loader";

const schema = yup.object().shape({
  url: yup
    .string()
    .typeError("Must be a String")
    .min(10, "Min 10 characters are required")
    .max(256, "Max 256 characters reached")
    .required(),

  apiKey: yup
    .string()
    .typeError("Must be a Number")
    .min(10, "Min 10 characters are required")
    .max(100, "Max 256 characters reached")
    .required(),

  sender: yup
    .string()
    .typeError("Must be a String")
    .min(3, "Min 3 characters are required")
    .max(100, "Max 100 characters reached")
    .required(),
});

const Sms = ({ onClose, showToast, getSmsConnectivityStatus, setSmsParam }) => {
  const [loadingSavingSms, setLoadingSavingSms] = useState(false);
  const [loadingSms, setLoadingSms] = useState(false);
  const [isModify, setIsModify] = useState(false);

  const privilegesSet = useSelector(selectPrivilegesSet);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid, isDirty },
  } = useForm({
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  // For Getting SMS Parameter
  const getSmsParameters = useCallback(async () => {
    setLoadingSms(true);

    try {
      const response = await SmsAxios(GET_SMS_GATEWAY, "get");
      const parameter = response.data;

      setSmsParam(parameter);

      reset({
        url: parameter.smsUrl,
        apiKey: parameter.apiKey,
        sender: parameter.sender,
      });
    } catch (error) {
      showToast("Failed to get SMS Gateway", "error");
      console.error(error);
      setSmsParam([]);
    }

    setLoadingSms(false);
  }, [showToast, reset, setSmsParam]);

  useEffect(() => {
    getSmsParameters();
  }, [getSmsParameters]);

  const onFormSubmit = async (data) => {
    const parameter = {
      smsUrl: data.url,
      apiKey: data.apiKey,
      sender: data.sender,
    };

    setLoadingSavingSms(true);

    try {
      await SmsAxios(SAVE_AND_UPDATE_SMS_GATEWAY, "post", parameter);

      showToast("Successfully SMS Parameter updated", "success");
      setIsModify(false);
      getSmsConnectivityStatus();
      setSmsParam(parameter);
    } catch (error) {
      showToast("Failed to Update SMS Parameter", "error");
      setSmsParam([]);
      console.error(error);
    }

    setLoadingSavingSms(false);
  };

  return (
    <Box>
      {privilegesSet.has("sms_email_sms_parameter_modify") && (
        <Box sx={{ display: "flex", float: "right", mt: -7.5, gap: 1 }}>
          <Grid item style={{ fontWeight: "bold" }}>
            View
          </Grid>

          <Grid item>
            <CustomSwitch
              checked={isModify}
              onChange={() =>
                setIsModify((ps) => {
                  if (ps) {
                    getSmsParameters();
                  }

                  return !ps;
                })
              }
              name="toggleBtn"
            />
          </Grid>

          <Grid item style={{ fontWeight: "bold" }}>
            Modify
          </Grid>
        </Box>
      )}

      {loadingSms && <Loader />}

      <Box>
        <Box
          sx={{
            display: "flex",
            gap: 1,
            flexDirection: "column",
            mt: 2,
          }}
        >
          <Box sx={{ display: "flex", flex: 1, flexDirection: "column" }}>
            <Typography>URL of SMS Gateway*</Typography>
            <MInput
              {...register("url")}
              InputLabelProps={{ shrink: true }}
              multiline
              fullWidth
              maxRows={2}
              placeholder="URL"
              inputProps={{ maxLength: 256 }}
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              error={!!errors?.url}
              helperText={errors?.url?.message}
            />
          </Box>

          <Box sx={{ display: "flex", flex: 1, flexDirection: "column" }}>
            <Typography>Api Key*</Typography>
            <MInput
              {...register("apiKey")}
              multiline
              fullWidth
              maxRows={2}
              InputLabelProps={{ shrink: true }}
              onInput={restrict.apiKey}
              inputProps={{ maxLength: 256 }}
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              error={!!errors?.apiKey}
              helperText={errors?.apiKey?.message}
            />
          </Box>

          <Box sx={{ display: "flex", flex: 1, flexDirection: "column" }}>
            <Typography>Sender*</Typography>
            <MInput
              {...register("sender")}
              multiline
              fullWidth
              maxRows={2}
              InputLabelProps={{ shrink: true }}
              onInput={restrict.remarks}
              inputProps={{ maxLength: 100 }}
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              error={!!errors?.sender}
              helperText={errors?.sender?.message}
            />
          </Box>
        </Box>
      </Box>

      <Grid container justifyContent="flex-end">
        <Grid sx={{ mt: 2 }}>
          {isModify && (
            <MButtonPrimary
              disabled={!isDirty || !isValid || loadingSavingSms}
              startIcon={<Save />}
              variant="contained"
              color="primary"
              onClick={handleSubmit(onFormSubmit)}
            >
              {loadingSavingSms && <CircularProgress size="24px" />}
              Save
            </MButtonPrimary>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default Sms;
