import React, { useCallback, useEffect, useState } from "react";

import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";

import { useSelector } from "react-redux";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_EMAIL_GATEWAY,
  SAVE_AND_UPDATE_EMAIL_GATEWAY,
} from "@/RestAPI/url/cnmsEndPoint";
import { Box, CircularProgress, Grid, Typography } from "@mui/material";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import { restrict } from "@/lib/utils";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";
import MInput from "@/components/Reusable/Input/MInput";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Loader from "@/components/Reusable/Loader/Loader";
import IPv4Input, { isValidIPv4 } from "@/components/Reusable/Input/IPv4Input";

const preventAutoFill = (e) => {
  e.preventDefault();
};

const schema = yup.object().shape({
  port: yup
    .string()
    .typeError("Must be a Number")
    .min(1, "Min 1 character required")
    .required(),

  sender: yup.string().email().required(),

  alertprofilesubject: yup
    .string()
    .min(3, "Min 3 character required")
    .required(),
});

const Email = ({
  onClose,
  showToast,
  getSmtpConnectivityStatus,
  setEmailParam,
}) => {
  const [loadingEmail, setLoadingEmail] = useState(false);
  const [loadingSavingEmail, setLoadingSavingEmail] = useState(false);
  const [isModify, setIsModify] = useState(false);
  const [ipErrors, setIpErrors] = useState({
    main: "",
    standbyOne: "",
    standbyTwo: "",
  });
  const [ip, setIp] = useState("");
  const [smtpServerStandByOne, setsmtpServerStandByOne] = useState("");
  const [smtpServerStandByTwo, setsmtpServerStandByTwo] = useState("");
  const [isIpAddressChange, setIsIpAddressChange] = useState(false);

  const privilegesSet = useSelector(selectPrivilegesSet);
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid, isDirty },
  } = useForm({
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const getEmailParameters = useCallback(async () => {
    setLoadingEmail(true);

    try {
      const response = await SmsAxios(GET_EMAIL_GATEWAY, "get");
      const parameter = response.data;

      setEmailParam(parameter);

      reset({
        port: parameter.portNum,
        sender: parameter.sender,
        alertprofilesubject: parameter.alertprofilesubject,
        password: parameter.password,
        userId: parameter.userId,
      });

      setIp(parameter.hostName);
      setsmtpServerStandByOne(parameter.smtpServerStandByOne);
      setsmtpServerStandByTwo(parameter.smtpServerStandByTwo);

      setIpErrors({
        main: "",
        standbyOne: "",
        standbyTwo: "",
      });
    } catch (error) {
      showToast("Failed to get Email Gateway", "error");
      setEmailParam([]);
      console.error(error);
    }

    setLoadingEmail(false);
  }, [showToast, reset]);

  useEffect(() => {
    getEmailParameters();
  }, [getEmailParameters]);

  const validateIP = (value, mandatory = false) => {
    // 1. SAFETY CHECK: Handle undefined, null, or empty explicitly
    if (value === undefined || value === null || value === "") {
      return mandatory ? "Should not be empty" : "";
    }

    // 2. Clean the string (remove whitespace)
    const cleanValue = value.trim();

    // 3. Check if it's actually empty after trimming
    if (!cleanValue) {
      return mandatory ? "Should not be empty" : "";
    }

    // 4. Check for incomplete parts (e.g., "192.168.1.")
    // We split by '.' and check if any part is empty
    if (cleanValue.split(".").some((part) => part === "")) {
      return "Invalid IP";
    }

    // 5. Final IPv4 Validation
    // Assuming isValidIPv4 is a reliable helper function
    return isValidIPv4(cleanValue) ? "" : "Invalid IP";
  };

  const onFormSubmit = async (data) => {
    const mainError = validateIP(ip, true);
    const standbyOneError = validateIP(smtpServerStandByOne);
    const standbyTwoError = validateIP(smtpServerStandByTwo);

    setIpErrors({
      main: mainError,
      standbyOne: standbyOneError,
      standbyTwo: standbyTwoError,
    });

    if (mainError || standbyOneError || standbyTwoError) {
      return;
    }

    setLoadingSavingEmail(true);

    const parameter = {
      hostName: ip,
      smtpServerStandByOne: smtpServerStandByOne,
      smtpServerStandByTwo: smtpServerStandByTwo,
      portNum: data.port,
      sender: data.sender,
      alertprofilesubject: data.alertprofilesubject,
      password: data.password,
      userId: data.userId,
    };

    try {
      await SmsAxios(SAVE_AND_UPDATE_EMAIL_GATEWAY, "post", parameter);

      showToast("Successfully Email Parameter updated", "success");
      setIsIpAddressChange(false);
      setIsModify(false);
      getSmtpConnectivityStatus();
      setEmailParam(parameter);
    } catch (error) {
      showToast("Failed to Update Email Parameter", "error");
      setEmailParam([]);
      console.error(error);
    }

    setLoadingSavingEmail(false);
  };

  const handleIpChange = (value) => {
    setIp(value);
    setIsIpAddressChange(true);

    setIpErrors((prev) => ({
      ...prev,
      main: validateIP(value, true),
    }));
  };

  const handleIp1Change = (value) => {
    setsmtpServerStandByOne(value);
    setIsIpAddressChange(true);

    setIpErrors((prev) => ({
      ...prev,
      standbyOne: validateIP(value),
    }));
  };

  const handleIp2Change = (value) => {
    setsmtpServerStandByTwo(value);
    setIsIpAddressChange(true);

    setIpErrors((prev) => ({
      ...prev,
      standbyTwo: validateIP(value),
    }));
  };

  const isIPValid =
    isValidIPv4(ip) &&
    (!smtpServerStandByOne || isValidIPv4(smtpServerStandByOne)) &&
    (!smtpServerStandByTwo || isValidIPv4(smtpServerStandByTwo));

  return (
    <Box>
      {privilegesSet.has("sms_email_email_parameter_modify") && (
        <Grid
          container
          spacing={1}
          alignItems="center"
          justifyContent="flex-end"
          sx={{ mt: -7.5 }}
        >
          <Grid>View</Grid>

          <Grid item>
            <CustomSwitch
              checked={isModify}
              onChange={() =>
                setIsModify((ps) => {
                  if (ps) {
                    getEmailParameters();
                  }
                  return !ps;
                })
              }
              name="toggleBtn"
            />
          </Grid>

          <Grid>Modify</Grid>
        </Grid>
      )}

      {loadingEmail && <Loader />}

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1, mt: 2 }}>
        <Box className="two-inputs-in-one-row" sx={{ gap: 2 }}>
          <Box className="fullwidth-minpu-cont">
            <Typography>IP Address of Main SMTP Server*</Typography>
            <IPv4Input
              value={ip}
              onChange={handleIpChange}
              disabled={!isModify}
              error={!!ipErrors.main}
              helperText={ipErrors.main}
            />
          </Box>

          <Box className="fullwidth-minpu-cont">
            <Typography>IP Address of Stand By SMTP Server 1</Typography>
            <IPv4Input
              value={smtpServerStandByOne}
              onChange={handleIp1Change}
              disabled={!isModify}
              error={!!ipErrors.standbyOne}
              helperText={ipErrors.standbyOne}
            />
          </Box>
        </Box>

        <Box className="two-inputs-in-one-row" sx={{ gap: 2 }}>
          <Box className="fullwidth-minpu-cont">
            <Typography>IP Address of Stand By SMTP Server 2</Typography>
            <IPv4Input
              value={smtpServerStandByTwo}
              onChange={handleIp2Change}
              disabled={!isModify}
              error={!!ipErrors.standbyTwo}
              helperText={ipErrors.standbyTwo}
            />
          </Box>

          <Box className="fullwidth-minpu-cont">
            <Typography>Port Number*</Typography>
            <MInput
              label="Port Number*"
              {...register("port")}
              InputLabelProps={{ shrink: true }}
              fullWidth
              onInput={restrict.number}
              inputProps={{ maxLength: 4 }}
              placeholder="25"
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              error={!!errors?.port}
              helperText={errors?.port?.message}
            />
          </Box>
        </Box>

        <Box className="two-inputs-in-one-row" sx={{ gap: 2 }}>
          <Box className="fullwidth-minpu-cont">
            <Typography>User ID</Typography>
            <MInput
              label="User ID"
              {...register("userId")}
              InputLabelProps={{ shrink: true }}
              fullWidth
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
            />
          </Box>

          <Box className="fullwidth-minpu-cont">
            <Typography>Password</Typography>
            <MInput
              label="Password"
              {...register("password")}
              InputLabelProps={{ shrink: true }}
              fullWidth
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              type={showPassword ? "text" : "password"}
              onCopy={preventAutoFill}
              onCut={preventAutoFill}
              onPaste={preventAutoFill}
              InputProps={{
                autoComplete: "new-password",
                endAdornment: showPassword ? (
                  <Visibility
                    style={{ cursor: "pointer" }}
                    onClick={() => setShowPassword(false)}
                  />
                ) : (
                  <VisibilityOff
                    style={{ cursor: "pointer" }}
                    onClick={() => setShowPassword(true)}
                  />
                ),
              }}
            />
          </Box>
        </Box>

        <Box className="two-inputs-in-one-row" sx={{ gap: 2 }}>
          <Box className="fullwidth-minpu-cont">
            <Typography>Sender*</Typography>
            <MInput
              label="Sender*"
              {...register("sender")}
              InputLabelProps={{ shrink: true }}
              multiline
              fullWidth
              maxRows={2}
              onInput={restrict.email}
              inputProps={{ maxLength: 125 }}
              placeholder="Max length 125"
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              error={!!errors?.sender}
              helperText={errors?.sender?.message}
            />
          </Box>

          <Box className="fullwidth-minpu-cont">
            <Typography>Alert Profile Subject*</Typography>
            <MInput
              sx={{ justifyContent: "flex-end" }}
              label="Alert Profile Subject*"
              {...register("alertprofilesubject")}
              InputLabelProps={{ shrink: true }}
              multiline
              fullWidth
              maxRows={2}
              onInput={restrict.String}
              inputProps={{ maxLength: 50 }}
              placeholder="Max length 50"
              readOnly={!isModify}
              disabled={!isModify}
              variant="outlined"
              size="small"
              error={!!errors?.alertprofilesubject}
              helperText={errors?.alertprofilesubject?.message}
            />
          </Box>
        </Box>
      </Box>

      <Grid container justifyContent="flex-end">
        <Grid sx={{ mt: 2 }}>
          {isModify && (
            <MButtonPrimary
              onClick={handleSubmit(onFormSubmit)}
              disabled={
                !isValid ||
                !isIPValid ||
                !!ipErrors.main ||
                !!ipErrors.standbyOne ||
                !!ipErrors.standbyTwo ||
                (!isDirty && !isIpAddressChange) ||
                loadingSavingEmail
              }
              variant="contained"
              color="primary"
            >
              {loadingSavingEmail && <CircularProgress size="24px" />}
              Save
            </MButtonPrimary>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default Email;
