import MModal from "@/components/Reusable/Modal/MModal";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MTable from "@/components/Reusable/Table/MTable";
import formatDate from "@/lib/utils";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import { GET_ALL_SMS_MAIL_LOG } from "@/RestAPI/url/cnmsEndPoint";

import { useCallback, useEffect, useState } from "react";

const ViewLog = ({ onClose, showToast }) => {
  const [logsDetails, setLogsDetails] = useState([]);
  const [loadingLog, setLoadingLog] = useState(false);

  const [columns] = useState([
    {
      name: "S.No.",
      uid: "index",
      width: "70px",
    },
    {
      name: "Name",
      uid: "userName",
    },
    {
      name: "Number/Email ID",
      uid: "numberEmailId",
      width: "160px",
    },
    {
      name: "Type",
      uid: "type",
    },
    {
      name: "Message",
      uid: "message",
      // width: "400px",
    },
    {
      name: "Date & Time",
      uid: "dateTime",
    },
    {
      name: "Status",
      uid: "status",
      // align: "center",
    },
  ]);

  const getAllLogDetails = useCallback(async () => {
    setLoadingLog(true);
    try {
      const logs = await SmsAxios(GET_ALL_SMS_MAIL_LOG, "get");
      const mappedLogs = logs.data.reverse().map((el, i) => ({
        ...el,
        index: i + 1,
        userName: el.recieverUserName,
        type: el.type,
        message: el.message,
        status: el?.remarks,
        dateTime: el.dateTime ? formatDate(el.dateTime) : "NA",
        numberEmailId: el.receiverMailPhoneNumber,
      }));

      setLogsDetails(mappedLogs);
    } catch (error) {
      showToast("Unable to fetch logs", "error");
      console.error(error);
    }
    setLoadingLog(false);
  }, [showToast]);

  useEffect(() => {
    getAllLogDetails();
  }, [getAllLogDetails]);

  return (
    <MModal
      title="View Logs"
      handleClose={onClose}
      open={true}
      enableFullScreen={true}
    >
      <MTable
        tableTitle="SMS and Email Log"
        tableData={logsDetails}
        isLoading={loadingLog}
        columns={columns}
        title="SMS and Email Log"
        showPagination
        typeHeight="configuration"
        configHeight="100%"
        showSearch
        handleDownloadPDF={() =>
          exportToPDF(
            "SMS and Email Log",
            columns,
            logsDetails,
            "SMS and Email Log"
          )
        }
      />
    </MModal>
  );
};

export default ViewLog;
