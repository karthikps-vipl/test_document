import React, { useCallback, useEffect, useState } from "react";

import { SMSandEmailSettingsHeader } from "./SMSandEmailSettingsHeader";

import { useSelector } from "react-redux";
import Toast from "@/components/Reusable/Toast/Toast";
import MModal from "@/components/Reusable/Modal/MModal";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_ALL_USERS_EMAIL_SMS_SERVICE,
  GET_EMAIL_GATEWAY,
  GET_SMS_GATEWAY,
} from "@/RestAPI/url/cnmsEndPoint";
import { Box } from "@mui/material";
import { AlertProfiling } from "./AlertProfiling";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";
import MForm from "@/components/Reusable/Form/MForm";

export default function SmsSmtp({ onClose }) {
  // const [disableComposer, setDisableComposer] = useState(true)
  const privilegesSet = useSelector(selectPrivilegesSet);
  const [disableEmail, setDisableEmail] = useState(true);
  const [disableSms, setDisableSms] = useState(true);
  const [smsParam, setSmsParam] = useState([]);
  const [emailParam, setEmailParam] = useState([]);
  const [contacts, setContacts] = useState([]);

  const showToast = useCallback((message, type) => {
    if (type === "error") {
      Toast("", message, "error");
    } else if (type === "success") {
      Toast("", message, "success");
    }
  }, []);

  const check = async () => {
    try {
      const response1 = await SmsAxios(GET_SMS_GATEWAY, "get");
      const response2 = await SmsAxios(GET_EMAIL_GATEWAY, "get");
      setSmsParam(response1.data);
      setEmailParam(response2.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (Object.keys(smsParam).length) {
      setDisableSms(false);
    } else {
      setDisableSms(true);
    }
    if (Object.keys(emailParam).length) {
      setDisableEmail(false);
    } else {
      setDisableEmail(true);
    }
  }, [smsParam, emailParam]);

  const refreshAndGetUsers = useCallback(async () => {
    try {
      const response = await SmsAxios(GET_ALL_USERS_EMAIL_SMS_SERVICE, "get");
      const mappedData = response.data.reverse().map((el, i) => ({
        ...el,
        index: i + 1,
        mobileWithCode:
          el.mobile.length > 10
            ? `+(${el.mobile.slice(0, 2)}) ${el.mobile.slice(-10)}`
            : el.mobile,
      }));
      setContacts(mappedData);
    } catch (error) {
      console.error("Error:", error);
      showToast("Failed to get users", "error");
    }
  }, []);

  useEffect(() => {
    check();
    refreshAndGetUsers();
  }, []);

  return (
    <MModal
      open={true}
      handleClose={onClose}
      title="SMS AND Email Settings"
      customWidth={"1024px"}
      enableFullScreen={true}
    >
      {/* Header (Contacts & Crud Operation, ViewLog,Compose Mail and Sms ANd setting) */}
      <SMSandEmailSettingsHeader
        contacts={contacts}
        setContacts={setContacts}
        setSmsParam={setSmsParam}
        refreshAndGetUsers={refreshAndGetUsers}
        setEmailParam={setEmailParam}
        disableEmail={disableEmail}
        disableSms={disableSms}
        showToast={showToast}
      />
      {/* Alert Profile */}
      {privilegesSet.has("alert_profiling") && (
        <Box sx={{ mt: 2 }}>
          <MForm title={"Alert Profiling"} paddingX={1}>
            <AlertProfiling
              contacts={contacts}
              setContacts={setContacts}
              showToast={showToast}
              refreshAndGetUsers={refreshAndGetUsers}
            />
          </MForm>
        </Box>
      )}
    </MModal>
  );
}
