import MModal from "@/components/Reusable/Modal/MModal";
import { AppBar, Tab, Tabs } from "@mui/material";
import { useState } from "react";
import Sms from "./Sms";
import Email from "./Email";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div hidden={value !== index} {...other}>
      {value === index && <Typography>{children}</Typography>}
    </div>
  );
}

export default function TextConfiguration({ onClose, showSnackBar }) {
  const [value, setValue] = useState(0);

  const handleChange = (_, newValue) => {
    setValue(newValue);
  };

  return (
    <MModal
      handleClose={onClose}
      title="SMS And Email Configuration"
      open={true}
      maxWidth={"sm"}
    >
      <AppBar color="default" position="static" variant="outlined">
        <Tabs value={value} onChange={handleChange} scrollButtons="auto">
          <Tab label="SMS Text Configuration" />
          <Tab label="Email Text Configuration" />
        </Tabs>
      </AppBar>
      <TabPanel value={value} index={0}>
        <Sms showSnackBar={showSnackBar} onClose={onClose} />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <Email showSnackBar={showSnackBar} onClose={onClose} />
      </TabPanel>
    </MModal>
  );
}
