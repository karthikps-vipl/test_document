import MModal from "@/components/Reusable/Modal/MModal";
import MInput from "@/components/Reusable/Input/MInput";
import { restrict } from "@/lib/utils";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import { SAVE_AND_UPDATE_USERS } from "@/RestAPI/url/cnmsEndPoint";
import { Add, Delete } from "@mui/icons-material";
import {
  Box,
  CircularProgress,
  IconButton,
  Tooltip,
  Typography,
} from "@mui/material";
import React, { useState, useCallback } from "react";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";

export function AddContact({ onClose, showToast }) {
  const [loading, setLoading] = useState(false);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isDirty, isValid },
  } = useForm({
    mode: "onChange",
    defaultValues: {
      Contacts: [
        {
          userName: "",
          emailId: "",
          countryCode: "91",
          mobile: "",
        },
      ],
    },
  });

  const { fields, append, remove } = useFieldArray({
    name: "Contacts",
    control,
  });

  const saveContact = useCallback(
    async (data) => {
      setLoading(true);

      try {
        const res = await SmsAxios(
          SAVE_AND_UPDATE_USERS,
          "post",
          data.Contacts.map(({ countryCode, ...contact }) => ({
            ...contact,
            mobile: countryCode + contact.mobile,
          }))
        );

        if (!res.data) {
          showToast("Email or Mobile already exist", "error");
          return;
        }

        reset();
        showToast("Contact added successfully", "success");
        onClose();
      } catch (error) {
        console.error(error);
        showToast("Failed to add", "error");
      } finally {
        setLoading(false);
      }
    },
    [reset, showToast, onClose]
  );

  const emailRules = {
    required: "Email Address is required",
    pattern: {
      value:
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
      message: "Email is not valid!",
    },
    maxLength: {
      value: 50,
      message: "Exceeded max characters allowed",
    },
  };

  return (
    <MModal
      title="Add Contact"
      handleClose={onClose}
      open={true}
      customWidth={"1008px"}
    >
      <Box>
        <Tooltip title="Add Row" placement="right">
          <button
            style={{
              width: "40px",
              padding: 0,
              border: "2px solid rgba(0,0,0,0.2)",
              borderRadius: "5px",
            }}
            onClick={() =>
              append({
                userName: "",
                emailId: "",
                countryCode: "91",
                mobile: "",
              })
            }
          >
            <Add />
          </button>
        </Tooltip>

        <form
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "10px",
            marginTop: "10px",
          }}
          onSubmit={handleSubmit(saveContact)}
          id="add-contact-form"
        >
          {fields.map((item, index) => (
            <Box sx={{ display: "flex", gap: "5px" }} key={item.id}>
              <Box
                sx={{ display: "flex", width: "30%", flexDirection: "column" }}
              >
                <Controller
                  name={`Contacts.${index}.userName`}
                  control={control}
                  rules={{
                    required: "Required",
                    minLength: {
                      value: 3,
                      message: "Minimum 3 character required",
                    },
                    maxLength: {
                      value: 50,
                      message: "Exceeded max characters allowed",
                    },
                  }}
                  render={({ field }) => (
                    <>
                      <Typography>Name*</Typography>
                      <MInput
                        {...field}
                        label="Name*"
                        placeholder="Enter Name"
                        fullWidth
                        multiline
                        type="text"
                        onInput={restrict.name}
                        inputProps={{ maxLength: 50 }}
                        error={!!errors?.Contacts?.[index]?.userName}
                        helperText={
                          errors?.Contacts?.[index]?.userName?.message
                        }
                      />
                    </>
                  )}
                />
              </Box>

              <Box
                sx={{ display: "flex", width: "10%", flexDirection: "column" }}
              >
                <Controller
                  name={`Contacts.${index}.countryCode`}
                  control={control}
                  rules={{
                    required: "Required",
                    minLength: {
                      value: 2,
                      message: "Invalid",
                    },
                  }}
                  render={({ field }) => (
                    <>
                      <Typography>Code*</Typography>
                      <MInput
                        {...field}
                        label="Code*"
                        placeholder="Code"
                        fullWidth
                        onInput={restrict.number}
                        inputProps={{ maxLength: 2 }}
                        error={!!errors?.Contacts?.[index]?.countryCode}
                        helperText={
                          errors?.Contacts?.[index]?.countryCode?.message
                        }
                      />
                    </>
                  )}
                />
              </Box>

              <Box
                sx={{ display: "flex", width: "30%", flexDirection: "column" }}
              >
                <Controller
                  name={`Contacts.${index}.mobile`}
                  control={control}
                  rules={{
                    required: "Mobile Number is required",
                    minLength: {
                      value: 10,
                      message: "Invalid Mobile Number",
                    },
                    maxLength: {
                      value: 10,
                      message: "Exceeded max characters allowed",
                    },
                  }}
                  render={({ field }) => (
                    <>
                      <Typography>Mobile Number*</Typography>
                      <MInput
                        {...field}
                        label="Mobile Number*"
                        placeholder="Enter Mobile Number"
                        fullWidth
                        onInput={restrict.digits}
                        inputProps={{ maxLength: 10 }}
                        error={!!errors?.Contacts?.[index]?.mobile}
                        helperText={errors?.Contacts?.[index]?.mobile?.message}
                      />
                    </>
                  )}
                />
              </Box>

              <Box
                sx={{ display: "flex", width: "30%", flexDirection: "column" }}
              >
                <Controller
                  name={`Contacts.${index}.emailId`}
                  control={control}
                  rules={emailRules}
                  render={({ field }) => (
                    <>
                      <Typography>Email Address*</Typography>
                      <MInput
                        {...field}
                        label="Email Address*"
                        placeholder="abc@gmail.com"
                        fullWidth
                        multiline
                        onInput={restrict.email}
                        inputProps={{ maxLength: 50 }}
                        error={!!errors?.Contacts?.[index]?.emailId}
                        helperText={errors?.Contacts?.[index]?.emailId?.message}
                      />
                    </>
                  )}
                />
              </Box>

              {index !== 0 && (
                <Box
                  item
                  xs={1}
                  sx={{
                    textAlign: "center",
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <Tooltip title="Delete Row">
                    <IconButton
                      type="button"
                      onClick={() => remove(index)}
                      sx={{ marginTop: "20px" }}
                    >
                      <Delete color="error" />
                    </IconButton>
                  </Tooltip>
                </Box>
              )}
            </Box>
          ))}
        </form>
      </Box>

      <Box sx={{ display: "flex", gap: 1, mt: 2, float: "right" }}>
        <MButtonPrimary
          form="add-contact-form"
          type="submit"
          onClick={handleSubmit(saveContact)}
          variant="contained"
          color="primary"
          startIcon={
            loading ? <CircularProgress size={20} color="inherit" /> : <></>
          }
          disabled={loading || !isValid || !isDirty}
        >
          Add
        </MButtonPrimary>
      </Box>
    </MModal>
  );
}
