import MInput from "@/components/Reusable/Input/MInput";
import MModal from "@/components/Reusable/Modal/MModal";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MSelect from "@/components/Reusable/Select/MSelect";
import formatDate, { formatDateTime, restrict } from "@/lib/utils";
import { InventoryAxios, SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_SITE_REP_DETAILS_FOR_EMAIL_BY_SITEID,
  FETCH_SITEDETAILS_BY_TERMINALTYPE_ID,
  GET_ADHOC_MSG_TEMPLATE,
  GET_SMS_TEMPLATE,
  SAVE_AND_UPDATE_ADHOC_MSG_TEMPLATE,
  SAVE_AND_UPDATE_SMS_TEMPLATE,
  SEND_IMMEDIATE_ADHOC_EMAIL,
  SEND_IMMEDIATE_ADHOC_SMS,
  SEND_SCHEDULED_ADHOC_EMAIL,
  SEND_SCHEDULED_ADHOC_SMS,
} from "@/RestAPI/url/cnmsEndPoint";
import { FETCH_SITE_REP_DETAILS } from "@/RestAPI/url/endpoint";
import {
  Box,
  CircularProgress,
  Grid,
  Tooltip,
  Typography,
  useTheme,
} from "@mui/material";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import DateTimePicker from "@/components/Reusable/DateTime/DateTimePicker";
import MForm from "@/components/Reusable/Form/MForm";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import saveIcon from "@/assets/SVGIcons/save.svg";
import loadIcon from "@/assets/SVGIcons/cnms/Draft.svg";
import attachFile from "@/assets/SVGIcons/cnms/Attach file.svg";
import { Menu, MenuItem } from "@mui/material";
import { ArrowDropDown } from "@mui/icons-material";
import sendIcon from "@/assets/SVGIcons/cnms/send.svg";

const SmsAndEmailComposer = ({
  onClose,
  showToast,
  contacts = [],
  enableEmail,
}) => {
  const fileInputRef = useRef(null);
  const theme = useTheme();
  const [scheduleDateTime, setScheduleDateTime] = useState("0");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [openDateTimePicker, setOpenDateTimePicker] = useState(false);
  const [attachmentError] = useState(false);
  const [attachment, setAttachment] = useState([]);
  const [subject, setSubject] = useState("");
  const [subjectErr, setSubjectErr] = useState("Reqired");
  const [reps, setReps] = useState([]);
  const [selectedReps, setSelectedReps] = useState([]);
  //
  const [selectedUsers, setSelectedUsers] = useState([]);
  //
  const [loadingTemplate, setLoadingTemplate] = useState(false);
  const [smsTextError, setSmsTextError] = useState("Required");
  const [textMsg, setTextMsg] = useState("");
  const [text, setText] = useState("");
  const [disableLoadTemplate, setDisableLoadTemplate] = useState(true);
  //
  const [savingTemplate, setSavingTemplate] = useState(false);
  const [loadingSend, setLoadingSend] = useState(false);
  const [dateTimeError, setDateTimeError] = useState("");
  const [fileErr, setFileErr] = useState(null);

  const [remoteVehicles, setRemoteVehicles] = useState([]);
  const [terminalTypeState, setTerminalTypeState] = useState([]);
  const allTerminalTypeDetails = useSelector(
    (store) => store.nodeDetails.allTerminalTypeDetails
  );
  const [loadingRemoteVehicle, setLoadingRemoteVehicle] = useState(false);
  const [selectedTerminalType, setSelectedTerminalType] = useState(null);
  const [selectedRemoteVehicle, setSelectedRemoteVehicle] = useState(null);
  const [sendMenuAnchor, setSendMenuAnchor] = useState(null);

  const sendMenuOpen = Boolean(sendMenuAnchor);

  //
  const reset = () => {
    setAttachment([]);
    setText("");
    setSubject("");
    setSelectedUsers([]);
    setSmsTextError("Required");
    setSubjectErr("Required");
    setSelectedReps([]);
  };

  useEffect(() => {
    let arr = [];
    allTerminalTypeDetails.forEach((item) => {
      if (item.terminalTypeName !== "CNMS") {
        arr.push(item);
      }
    });
    setTerminalTypeState(arr);
  }, [allTerminalTypeDetails]);

  const getRemoteVehicleBasedOnTerminalType = async (id) => {
    setLoadingRemoteVehicle(true);
    try {
      const resp = await InventoryAxios(
        `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${id}`,
        "get"
      );
      setRemoteVehicles(resp.data);
    } catch (error) {
      showToast("No remotes available.", "error");
      setRemoteVehicles([]);

      console.error(error);
    }
    setLoadingRemoteVehicle(false);
  };
  const handleClearFields = () => {
    //reset All initial States
    setSelectedRemoteVehicle(null);
    setSelectedReps([]);
  };

  const sendSms = useCallback(
    async (body) => {
      // setLoadingSend(true);

      try {
        const res = await SmsAxios(SEND_IMMEDIATE_ADHOC_SMS, "post", body);
        if (res.data) {
          if (res.data.includes("not")) showToast(res.data, "error");
          else {
            showToast(res.data, "success");
          }
        } else {
          showToast("Sms failed to send", "error");
        }
      } catch (error) {
        showToast("Sms failed to send", "error");
        console.error("Error:", error);
      }
      setLoadingSend(false);
      reset();
    },
    [showToast]
  );

  const saveSms = useCallback(
    async (body) => {
      // setLoadingSend(true);

      try {
        await SmsAxios(SEND_SCHEDULED_ADHOC_SMS, "post", body);
        showToast("Scheduled Task saved successfully", "success");
      } catch (error) {
        showToast("Sms failed to save", "error");
        console.error(error);
      }
      setLoadingSend(false);
      reset();
    },
    [showToast]
  );

  const sendEmail = useCallback(
    async (b) => {
      // setLoadingSend(true);

      try {
        //      const res =  await fetch('http://localhost:8976/emailsms/sendImmediateAdhocEmail',{
        //       mode:'no-cors',
        //       // headers:{
        //       //   "Content-Type":"multipart/form-data boundary=CUSTOM"
        //       // },
        //       method:'POST',
        //       body:b,
        // });

        const res = await SmsAxios(SEND_IMMEDIATE_ADHOC_EMAIL, "post", b, {
          // mode: 'no-cors',
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        console.log(res, "AXS calling Email");
        if (res.data.includes("not")) showToast(res.data, "error");
        else {
          showToast(res.data, "success");
        }
        //showToast("Mail sent successfully", "success");
        reset();
      } catch (error) {
        console.error(error);

        showToast("Mail failed to send", "error");
      }
      setLoadingSend(false);
      reset();
    },
    [showToast]
  );

  const saveEmail = useCallback(
    async (body) => {
      // setLoadingSend(true);

      try {
        await SmsAxios(SEND_SCHEDULED_ADHOC_EMAIL, "post", body);
        showToast("Scheduled Task saved successfully", "success");
        // reset();
      } catch (error) {
        console.error(error);

        showToast("Email failed to save", "error");
      }
      setLoadingSend(false);
      reset();
    },
    [showToast]
  );

  const validateSms = (text) => {
    setText(text.trimStart());
    if (text.length < 3) {
      setSmsTextError("Need minimum 3 Characters");
    } else if (text.length <= 160) {
      setSmsTextError("");
      setTextMsg(`${160 - text.length} characters remaining`);
    } else {
      setSmsTextError(
        `${text.length - 160} characters over 160 character limit`
      );
      setTextMsg("");
    }
  };

  const handleSendBtnClick = async () => {
    console.log(selectedReps, "Kavya");
    setLoadingSend(true);
    const fd = new FormData();
    let req = {
      userIdList: selectedUsers.map((el) => el.id),
      mailBody: text.trim(),
      //file: "",
    };

    if (enableEmail) {
      fd.append("subject", subject);
    }
    fd.append(
      "userIdList",
      selectedUsers.map((el) => el.id)
    );
    fd.append("mailBody", text.trim());

    if (attachment?.content) {
      req = { ...req, file: attachment };
      // console.log(attachment.content, "AXS");
      // console.log("hari file", [attachment.content]);
    }
    if (attachment.name) {
      fd.append("file", attachment);
    }
    if (scheduleDateTime === "0") {
      // fd.headers.remove("[multipart/form-data")
      if (enableEmail) {
        fd.append(
          "siteRepsLst",
          selectedReps.map((e2) => e2.email)
        );
        fd.append(
          "userNameList",
          selectedReps.map((e3) => e3.personnelName)
        );
        sendEmail(fd);
      } else {
        await sendSms({
          userIdList: selectedUsers.map((el) => el.id),
          mailBody: text.trim(),
          siteRepsLst: selectedReps.map((e2) => e2.email),
          userNameList: selectedReps.map((e3) => e3.personnelName),
        });
      }
      // setLoadingSend(false);
    } else {
      // saveEmail({ ...req, scheduledTime: moment(selectedDate).add(5.5, "h").toISOString() }); //Adding 5.30 Hours in Iso String formate
      fd.append("scheduledTime", formatDateTime(selectedDate));
      if (enableEmail) {
        fd.append(
          "siteRepsLst",
          selectedReps.map((e2) => e2.email)
        );
        fd.append(
          "userNameList",
          selectedReps.map((e3) => e3.personnelName)
        );
        saveEmail(fd); //Adding 5.30 Hours in Iso String formate
      } else {
        // await saveSms({
        //   userIdList: selectedUsers.map((el) => el.id),
        //   mailBody: text.trim(),
        //   scheduledTime: moment(selectedDate).add(5.5, "h").toISOString(),
        // });
        fd.append(
          "siteRepsLst",
          selectedReps.map((e2) => e2.email)
        );
        fd.append(
          "userNameList",
          selectedReps.map((e2) => e2.personnelName)
        );
        saveSms(fd);
      }
      // setLoadingSend(false);
    }
    // setLoadingSend(false);
  };

  //to check whether we already have draft saved
  useEffect(() => {
    if (enableEmail) {
      SmsAxios(GET_ADHOC_MSG_TEMPLATE, "get")
        .then((response) => {
          if (response.data) {
            setDisableLoadTemplate(false);
          } else {
            setDisableLoadTemplate(true);
          }
        })
        .catch((error) => {
          // showToast("Failed to load template");
          // setLoadingTemplate(false);
          console.error(error);

          setDisableLoadTemplate(true);
        });
      // fetchSiteRepDetailsForEmail().then(({ data }) => {
      //   setReps(data)
      // }).catch((err) => {
      //   showToast('Failed to fetch Reps.')
      // })
    } else {
      SmsAxios(GET_SMS_TEMPLATE, "get")
        .then((response) => {
          if (response.data) {
            setDisableLoadTemplate(false);
          } else {
            setDisableLoadTemplate(true);
          }
        })
        .catch((error) => {
          console.error(error);

          setDisableLoadTemplate(true);
        });
      InventoryAxios(FETCH_SITE_REP_DETAILS, "get")
        .then(({ data }) => {
          setReps(data);
        })
        .catch((err) => {
          showToast("Failed to fetch Reps.");
          console.error(err);
        });
    }
  }, []);

  const handleLoadTemplateClick = () => {
    setLoadingTemplate(true);
    if (enableEmail) {
      // load template for EMAIL
      SmsAxios(GET_ADHOC_MSG_TEMPLATE, "get")
        .then((response) => {
          validateSms(response.data.msgTemplate);
          setSubject(response.data.subject);
          setLoadingTemplate(false);
        })
        .catch((error) => {
          showToast("Failed to load template");
          console.error(error);

          setLoadingTemplate(false);
        });
    } else {
      // load template for SMS
      SmsAxios(GET_SMS_TEMPLATE, "get")
        .then((response) => {
          validateSms(response.data.msgTemplate);
          setLoadingTemplate(false);
        })
        .catch((error) => {
          showToast("Failed to load template");
          setLoadingTemplate(false);
          console.error(error);
        });
    }
  };

  const handleRemoteVehicleChange = async (value) => {
    const { siteId, siteName } = value;
    setSelectedRemoteVehicle({ siteName, siteId });
    fetchRepDetails(siteId);
  };

  const fetchRepDetails = async (siteId) => {
    try {
      const resp = await InventoryAxios(
        `${FETCH_SITE_REP_DETAILS_FOR_EMAIL_BY_SITEID}/${siteId}`,
        "get"
      );
      console.log("dk res", resp?.data);
      setReps(resp?.data);
      //refreshAndGetUsers()
    } catch (error) {
      console.error(error);

      setReps([]);
      showToast("Failed to fetch Remote Reps.", "error");
    }
  };

  const handleSaveTemplateClick = () => {
    setSavingTemplate(true);
    let req = {
      msgTemplate: text,
    };
    if (enableEmail) {
      req.subject = subject;
      //  save template for E-MAIL
      SmsAxios(SAVE_AND_UPDATE_ADHOC_MSG_TEMPLATE, "post", req)
        .then(() => {
          showToast("Successfully template saved", "success");
          setDisableLoadTemplate(false);
          // setSavingTemplate(false);
        })
        .catch((error) => {
          showToast("Failed to save", "error");
          console.error(error);

          // setSavingTemplate(false);
        });
    } else {
      // save template for SMS
      SmsAxios(SAVE_AND_UPDATE_SMS_TEMPLATE, "post", req)
        .then(() => {
          showToast("Successfully template saved", "success");
          setDisableLoadTemplate(false);
          // setSavingTemplate(false);
        })
        .catch((error) => {
          setDisableLoadTemplate(true);
          showToast("Failed to save", "error");
          // setSavingTemplate(false);
          console.error(error);
        });
    }
    setSavingTemplate(false);
    reset();
  };

  const handleSMSChange = (e) => {
    validateSms(e.target.value);
  };

  console.log(reps, selectedReps, "calling reps");

  const handleFileChange = (e) => {
    const file = e.target?.files[0];
    if (!file) return;

    // 2.5 MB in bytes = 2.5 * 1024 * 1024
    if (file.size / 1048576 > 2.5) {
      setFileErr("File Size Cannot exceed 2.5 MB.");
      setAttachment(null);
    } else {
      setAttachment(file);
      setFileErr(null);
    }
  };

  return (
    <>
      <DateTimePicker
        open={openDateTimePicker}
        ampm={false}
        seconds
        onSubmit={(val) => {
          if (val < new Date()) {
            setDateTimeError("Select Future Date Time");
          } else {
            setDateTimeError("");
          }
          setSelectedDate(val);
        }}
        disableFuture={false}
        disablePast={true}
        value={selectedDate}
        onClose={() => {
          setOpenDateTimePicker(false);
        }}
      />
      <form
        onSubmit={handleSendBtnClick}
        encType="multipart/form-data"
        modelAttreibute="mailForm"
      >
        <MModal
          title={enableEmail ? "EMAIL COMPOSER" : "SMS COMPOSER"}
          handleClose={onClose}
          open={true}
          customWidth={"1024px"}
        >
          <Box>
            <MForm title={"New message"} paddingX={2}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    // gap: 2,
                    border: "2px solid #eee",
                    borderRadius: "5px",
                    // p: 2,
                  }}
                >
                  <Box sx={{ pl: 1, pt: 1 }}>To*</Box>

                  <Box
                    sx={{
                      borderTop: "2px solid #eee",
                      borderBottom: "2px solid #eee",
                      p: 1,
                    }}
                  >
                    <Box className="two-inputs-in-one-row" gap={2}>
                      <Box className="fullwidth-minpu-cont">
                        <MSelect
                          label="Terminal*"
                          placeholder="Select Terminal"
                          options={terminalTypeState}
                          value={selectedTerminalType}
                          getOptionLabel={(option) =>
                            option?.terminalTypeName || ""
                          }
                          getOptionValue={(option) => option.id}
                          onChange={(newValue) => {
                            setSelectedTerminalType(newValue);
                            handleClearFields();

                            if (newValue) {
                              getRemoteVehicleBasedOnTerminalType(newValue.id);
                            } else {
                              setRemoteVehicles([]);
                            }
                          }}
                        />
                      </Box>

                      <Box className="fullwidth-minpu-cont">
                        <MSelect
                          label="Remote Vehicle*"
                          placeholder={
                            loadingRemoteVehicle
                              ? "Loading..."
                              : "Select Remote Vehicle"
                          }
                          options={remoteVehicles}
                          value={selectedRemoteVehicle}
                          disabled={
                            !selectedTerminalType || loadingRemoteVehicle
                          }
                          getOptionLabel={(option) => option?.siteName || ""}
                          getOptionValue={(option) => option.siteId}
                          onChange={(newValue) => {
                            if (!newValue) {
                              handleClearFields();
                              return;
                            }

                            handleRemoteVehicleChange(newValue);
                          }}
                        />
                      </Box>
                    </Box>

                    <Box
                      sx={{
                        display: "flex",
                        maxWidth: "450px",
                        justifyContent: "center",
                        alignItems: "center",
                        margin: "0 auto",
                        mt: 1,
                      }}
                    >
                      <MAlarmSelect
                        label="Remote Rep(s)."
                        options={reps.map((rep) => ({
                          label: enableEmail
                            ? `${rep.personnelName} (${rep.email || ""})`
                            : `${rep.personnelName} (${
                                rep.primaryCivilMobile || ""
                              })`,
                          value: rep,
                        }))}
                        value={selectedReps}
                        multiple
                        onChange={setSelectedReps}
                      />
                    </Box>
                  </Box>

                  <Box>
                    <Box
                      sx={{
                        display: "flex",
                        maxWidth: "450px",
                        justifyContent: "center",
                        alignItems: "center",
                        margin: "0 auto",
                        mt: 1,
                        mb: 1,
                      }}
                    >
                      <MAlarmSelect
                        label="Others"
                        options={contacts.map((contact) => ({
                          label: enableEmail
                            ? `${contact.userName} (${contact.emailId || ""})`
                            : `${contact.userName} (${contact.mobile || ""})`,
                          value: contact,
                        }))}
                        value={selectedUsers}
                        multiple
                        onChange={setSelectedUsers}
                      />
                    </Box>
                  </Box>
                </Box>

                {enableEmail && (
                  <Box className="fullwidth-minpu-cont">
                    <Typography>Subject*</Typography>
                    <MInput
                      label="Subject"
                      value={subject}
                      onInput={restrict.sms}
                      inputProps={{ maxLength: 50 }}
                      placeholder="Enter characters between 3 - 50"
                      error={!!subjectErr}
                      helperText={subjectErr}
                      onChange={(e) => {
                        const value = e.target.value;
                        setSubject(value);

                        setSubjectErr(
                          value.length < 3
                            ? "Should be between 3 to 50 characters."
                            : ""
                        );
                      }}
                      fullWidth
                    />
                  </Box>
                )}

                <Box className="fullwidth-minpu-cont">
                  <Typography>
                    {enableEmail ? "Email Text*" : "SMS Text*"}
                  </Typography>
                  <MInput
                    // label={enableEmail ? "Email Text" : "SMS Text"}
                    value={text}
                    onInput={restrict.sms}
                    inputProps={{ maxLength: 160 }}
                    placeholder="Enter characters between 3 - 160"
                    error={!!smsTextError}
                    helperText={smsTextError || textMsg}
                    onChange={handleSMSChange}
                    multiline
                    minRows={5}
                    maxRows={5}
                    fullWidth
                  />
                </Box>
                {/* <Grid item xs={scheduleDateTime === "1" ? 6 : 12}>
                  <FormControl component="fieldset">
                    <RadioGroup
                      row
                      name="time"
                      value={scheduleDateTime}
                      onChange={(e) => setScheduleDateTime(e.target.value)}
                    >
                      <FormControlLabel
                        value="0"
                        control={<Radio color="primary" />}
                        label="Immediate"
                      />
                      <FormControlLabel
                        value="1"
                        control={
                          <Radio
                            color="primary"
                            onClick={() => {
                              setOpenDateTimePicker(true);
                            }}
                          />
                        }
                        label="Schedule"
                      />
                    </RadioGroup>
                  </FormControl>
                </Grid> */}
                {scheduleDateTime === "1" && (
                  <Grid item xs={6}>
                    <Typography>Selected Date & Time</Typography>
                    <MInput
                      label="DateTime"
                      value={formatDate(selectedDate)}
                      onClick={() => setOpenDateTimePicker(true)}
                      error={!!dateTimeError}
                      helperText={dateTimeError}
                      readOnly
                      fullWidth
                    />
                  </Grid>
                )}

                {enableEmail && (
                  <>
                    <p
                      style={{
                        fontSize: "15px",
                        color: theme.palette.background.avatar,
                      }}
                    >
                      Accepted files extensions - .pdf, .docx, .jpg, .txt, .png,
                      .rtf, .html, .xlsx, .xls, .csv files upto 2.5 MB.
                    </p>

                    {fileErr && (
                      <p style={{ fontSize: "15px", color: "red" }}>
                        {fileErr}
                      </p>
                    )}
                  </>
                )}
              </Box>
            </MForm>
          </Box>

          <Box
            sx={{
              float: "right",
              display: "flex",
              alignItems: "center",
              gap: 2,
            }}
          >
            {/* <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 2 }}> */}
            <Box>
              <Tooltip
                title={enableEmail ? "Save EMAIL Draft" : "Save SMS Draft"}
              >
                <button
                  onClick={handleSaveTemplateClick}
                  style={{
                    filter:
                      !!smsTextError || savingTemplate
                        ? "grayscale(1) opacity(0.5)"
                        : "none",
                    marginTop: "6px",
                  }}
                  disabled={!!smsTextError || savingTemplate}
                >
                  {/* {savingTemplate && <CircularProgress size="24px" />} */}
                  {/* {enableEmail ? "Save EMAIL Draft" : "Save SMS Draft"} */}
                  <img src={saveIcon} alt="save" />
                </button>
              </Tooltip>
            </Box>
            <Box>
              <Tooltip
                title={enableEmail ? "Load EMAIL Draft" : "Load SMS Draft"}
              >
                <button
                  onClick={handleLoadTemplateClick}
                  style={{
                    filter:
                      loadingTemplate || disableLoadTemplate
                        ? "grayscale(1) opacity(0.5)"
                        : "none",
                    marginTop: "6px",
                  }}
                  disabled={loadingTemplate || disableLoadTemplate}
                >
                  {/* {loadingTemplate && <CircularProgress size="24px" />} */}
                  {/* {enableEmail ? "Load EMAIL Draft" : "Load SMS Draft"} */}
                  <img src={loadIcon} alt="load" />
                </button>
              </Tooltip>
            </Box>
            {/* </Box> */}
            {/* {enableEmail ? (
              <Grid>
                <div style={{ display: "flex", gap: "7px" }}>
                  <p>Add Attatchment:</p>
                  <input
                    accept=".pdf, .docx, .jpg, .txt, .png, .rtf, .html, .xlsx, .xls, .csv"
                    type="file"
                    onChange={(e) => {
                      // if ((e.target.files[0].size / 1000000) > 1) {
                      if (e.target?.files[0]?.size / 1048576 > 2.5) {
                        setFileErr("File Size Cannot exceed 2.5 MB.");
                      } else {
                        setAttachment(e.target?.files[0]);
                        setFileErr(null);
                      }
                    }}
                  />
                </div>
              </Grid>
            ) : null} */}

            {enableEmail ? (
              <Grid>
                <div
                  style={{ display: "flex", alignItems: "center", gap: "10px" }}
                >
                  {/* <p style={{ margin: 0 }}>Add Attachment:</p> */}

                  {/* 1. The Hidden Input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    style={{ display: "none" }} // Hides the default ugly button
                    accept=".pdf, .docx, .jpg, .txt, .png, .rtf, .html, .xlsx, .xls, .csv"
                    onChange={handleFileChange}
                  />

                  <Tooltip title={"Attach file"}>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current.click()} // Triggers the hidden input
                      style={{
                        background: "none",
                        border: "none",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        padding: "4px",
                        borderRadius: "4px",
                        transition: "background 0.2s",
                      }}
                      onMouseOver={(e) =>
                        (e.currentTarget.style.background = "#f0f0f0")
                      }
                      onMouseOut={(e) =>
                        (e.currentTarget.style.background = "none")
                      }
                    >
                      <img src={attachFile} alt="attach file" />
                    </button>
                  </Tooltip>

                  {/* Optional: Show filename if selected */}
                  {attachment && (
                    <span
                      style={{
                        fontSize: "14px",
                        color: "gray",

                        maxWidth: "150px",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {attachment.name}
                    </span>
                  )}
                </div>

                {/* Error Message Display */}
                {/* {fileErr && (
                  <p
                    style={{ fontSize: "13px", color: "red", marginTop: "5px" }}
                  >
                    {fileErr}
                  </p>
                )} */}
              </Grid>
            ) : null}
            {/* <MButtonPrimary
              onClick={handleSendBtnClick}
              color="primary"
              variant="contained"
              startIcon={
                loadingSend ? <CircularProgress size="24px" /> : <Send />
              }
              disabled={
                attachmentError ||
                smsTextError ||
                loadingSend ||
                dateTimeError ||
                fileErr ||
                (enableEmail
                  ? subjectErr ||
                    (!selectedUsers.length && !selectedReps.length)
                  : false) ||
                (!enableEmail
                  ? !selectedReps.length && !selectedUsers.length
                  : false)
              }
            >
             
              {scheduleDateTime === "1"
                ? enableEmail
                  ? "Save Email"
                  : "Save SMS"
                : enableEmail
                ? "Send Email"
                : "Send SMS"}
            </MButtonPrimary> */}

            <Box sx={{ display: "flex", alignItems: "center" }}>
              {/* Main Send Button */}
              <MButtonPrimary
                style={{
                  borderTopRightRadius: "0px",
                  borderBottomRightRadius: "0px",
                }}
                onClick={handleSendBtnClick}
                color="primary"
                variant="contained"
                startIcon={
                  loadingSend ? (
                    <CircularProgress size={20} />
                  ) : (
                    <img src={sendIcon} alt="send" />
                  )
                }
                disabled={
                  attachmentError ||
                  !!smsTextError ||
                  loadingSend ||
                  !!dateTimeError ||
                  !!fileErr ||
                  (enableEmail
                    ? !!subjectErr ||
                      (!selectedUsers.length && !selectedReps.length)
                    : !selectedReps.length && !selectedUsers.length)
                }
                sx={{
                  borderTopRightRadius: 0,
                  borderBottomRightRadius: 0,
                }}
              >
                {scheduleDateTime === "1"
                  ? enableEmail
                    ? "Save Email"
                    : "Save SMS"
                  : enableEmail
                  ? "Send Email"
                  : "Send SMS"}
              </MButtonPrimary>

              {/* Dropdown Arrow */}
              <MButtonPrimary
                onClick={(e) => setSendMenuAnchor(e.currentTarget)}
                disabled={loadingSend}
                style={{
                  borderTopLeftRadius: "0px",
                  borderBottomLeftRadius: "0px",
                  height: "36.5px",
                  borderLeft: "1px solid #eee",
                }}
                color="primary"
                variant="contained"
              >
                <ArrowDropDown />
              </MButtonPrimary>

              {/* Dropdown Menu */}
              <Menu
                anchorEl={sendMenuAnchor}
                open={sendMenuOpen}
                onClose={() => setSendMenuAnchor(null)}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                transformOrigin={{
                  vertical: "bottom",
                  horizontal: "right",
                }}
              >
                <MenuItem
                  selected={scheduleDateTime === "0"}
                  onClick={() => {
                    setScheduleDateTime("0");
                    setDateTimeError("");
                    setSendMenuAnchor(null);
                  }}
                >
                  Immediate
                </MenuItem>

                <MenuItem
                  selected={scheduleDateTime === "1"}
                  onClick={() => {
                    setScheduleDateTime("1");
                    setSendMenuAnchor(null);
                    setOpenDateTimePicker(true);
                  }}
                >
                  Schedule
                </MenuItem>
              </Menu>
            </Box>
          </Box>
        </MModal>
      </form>
    </>
  );
};

export default SmsAndEmailComposer;
