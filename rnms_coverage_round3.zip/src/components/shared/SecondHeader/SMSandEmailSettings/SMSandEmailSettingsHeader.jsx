import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import GatewayParameter from "./GatewayParameter/GatewayParameter";
import TextConfiguration from "./TextConfiguration";
import ViewLog from "./ViewLog";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_SMS_GATEWAY_CONNECTIVITY,
  GET_SMTP_GATEWAY_CONNECTIVITY,
} from "@/RestAPI/url/cnmsEndPoint";
import { Box, Menu, MenuItem, Tooltip, Typography } from "@mui/material";
import { FiberManualRecord } from "@mui/icons-material";
import AlertConfig from "./AlertConfig";
import SmsAndEmailComposer from "./SmsAndEmailComposer";
import { AddContact } from "./AddContact";
import { DeleteContact } from "./DeleteContact";
import { EditContact } from "./EditContact";
import { selectPrivilegesSet } from "@/store/features/LoggedInUser/userSlice";
import MTable from "@/components/Reusable/Table/MTable";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Eye_icon from "@/assets/svg/FaultIcon/view eye.svg";
import gatewayIcon from "@/assets/SVGIcons/gateway.svg";
import emailIcon from "@/assets/SVGIcons/cnms/Email Composer.svg";
import SmsComposerIcon from "@/assets/SVGIcons/cnms/SMS Composer.svg";
import alertConfig from "@/assets/SVGIcons/cnms/Event based alert config.svg";

export const SMSandEmailSettingsHeader = ({
  contacts,
  setContacts,
  showToast,
  disableComposer,
  setSmsParam,
  setEmailParam,
  disableEmail,
  disableSms,
  refreshAndGetUsers,
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [openGatewayParameter, setOpenGatewayParameter] = useState(false);
  const [openTextConfiguration, setOpenTextConfiguration] = useState(false);
  const [openViewLog, setOpenViewLog] = useState(false);
  const [smsComposer, setSmsComposer] = useState(false);
  const [EmailComposer, setEmailComposer] = useState(false);
  const privilegesSet = useSelector(selectPrivilegesSet);
  const [openAlertConfig, setOpenAlertConfig] = useState(false);

  // const [smsAndEmailComposer, setSmsAndEmailComposer] = useState(false);
  //
  const [loadingContacts, setLoadingContacts] = useState(false);
  // const [contacts, setContacts] = useState([]);
  const [openAddContact, setOpenAddContact] = useState(false);
  //
  const [smtpGatewayConnectivity, setSmtpGatewayConnectivity] = useState(false);
  const [smsGatewayConnectivity, setSmsGatewayConnectivity] = useState(false);
  //
  const [selectedRow, setSelectedRow] = useState(null);
  const [openEditContact, setOpenEditContact] = useState(false);
  const [openDeleteContact, setOpenDeleteContact] = useState(false);
  const [columns] = useState([
    {
      name: "S.No.",
      uid: "index",
      align: "center",
      width: "5%",
    },
    {
      name: "Name",
      uid: "userName",
    },
    {
      name: "Mobile",
      uid: "mobileWithCode",
    },
    {
      name: "Email",
      uid: "emailId",
    },
    { name: "Actions", uid: "actions" },
  ]);

  const handleClickSetting = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const getSmtpConnectivityStatus = useCallback(async () => {
    try {
      const resp = await SmsAxios(GET_SMTP_GATEWAY_CONNECTIVITY, "get");
      setSmtpGatewayConnectivity(resp.data);
    } catch (error) {
      //showToast("Failed to get SMTP connectivity status", "error");
      console.log("Failed to get SMTP connectivity status", error);
    }
  }, [showToast]);

  const getSmsConnectivityStatus = useCallback(async () => {
    try {
      const resp = await SmsAxios(GET_SMS_GATEWAY_CONNECTIVITY, "get");
      setSmsGatewayConnectivity(resp.data);
    } catch (error) {
      console.log("Failed to get SMS connectivity status", error);
    }
  }, [showToast]);

  useEffect(() => {
    if (!openAddContact && !openDeleteContact && !openEditContact) {
      setLoadingContacts(true);
      refreshAndGetUsers();
      setLoadingContacts(false);
    }
  }, [refreshAndGetUsers, openAddContact, openDeleteContact, openEditContact]);

  useEffect(() => {
    getSmtpConnectivityStatus();
    getSmsConnectivityStatus();
  }, [getSmsConnectivityStatus, getSmtpConnectivityStatus]);

  // const actions = [
  //   privilegesSet.has("sms_email_edit_contacts") && {
  //     icon: () => <Edit color="primary" />,
  //     tooltip: "Edit Contact",
  //     onClick: (e, rowData) => {
  //       setSelectedRow(rowData);
  //       setOpenEditContact(true);
  //     },
  //   },
  //   privilegesSet.has("sms_email_delete_contacts") && {
  //     icon: () => <Delete color="error" />,
  //     tooltip: "Delete Contact",
  //     onClick: (e, rowData) => {
  //       setSelectedRow(rowData);
  //       setOpenDeleteContact(true);
  //     },
  //   },
  // ];

  return (
    <>
      {/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
      <Box>
        {privilegesSet.has("sms_email_view_contacts") && (
          // <Box>
          <MTable
            columns={columns}
            tableData={contacts}
            isLoading={loadingContacts}
            tableTitle=""
            handleEdit={(rowData) => {
              setSelectedRow(rowData);
              setOpenEditContact(true);
            }}
            handleDelete={(rowData) => {
              setSelectedRow(rowData);
              setOpenDeleteContact(true);
            }}
            configHeight={"100%"}
            typeHeight={"configuration"}
            showPagination
            tableHeader={
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  marginLeft: "-50px",
                  paddingTop: "5px",
                  paddingBottom: "5px",
                }}
              >
                <Typography sx={{ fontSize: "14px", display: "inline-block" }}>
                  <FiberManualRecord
                    style={{
                      color: smsGatewayConnectivity ? "#34C659" : "#D65960",
                    }}
                  />{" "}
                  SMS Gateway Connectivity
                  <FiberManualRecord
                    style={{
                      color: smtpGatewayConnectivity ? "#34C659" : "#D65960",
                    }}
                  />{" "}
                  E-MAIL Gateway Connectivity
                </Typography>
                {privilegesSet.has("sms_email_add_new_contact") && (
                  <MButtonPrimary
                    onClick={() => setOpenAddContact(true)}
                    style={{ whiteSpace: "nowrap" }}
                  >
                    Add Contact
                  </MButtonPrimary>
                )}
                <div
                  style={{
                    display: "flex",
                    gap: "10px",
                    alignItems: "center",
                  }}
                >
                  <Tooltip title="Event Based Alert Config.">
                    <button
                      onClick={() => {
                        setOpenAlertConfig(true);
                      }}
                      style={{
                        backgroundColor: "#ffffff",
                        display: "flex",
                        justifyContent: "center",
                        width: "35px",
                        height: "35px",
                        border: "2px solid rgba(0,0,0,0.1)",
                        backgroundClip: "padding-box",
                        alignItems: "center",
                        borderRadius: "4px",
                        cursor: "pointer",
                      }}
                    >
                      {/* <ContactMail /> */}
                      <img
                        src={alertConfig}
                        style={{
                          width: "30px",
                          height: "30px",
                          padding: "2px 2px",
                        }}
                        alt="event"
                      />
                    </button>
                  </Tooltip>
                  {privilegesSet.has("sms_email_sms_composer") && (
                    <Tooltip title="SMS Composer">
                      <button
                        disabled={disableSms}
                        onClick={() => setSmsComposer(true)}
                        style={{
                          backgroundColor: "#ffffff",
                          display: "flex",
                          justifyContent: "center",
                          width: "35px",
                          height: "35px",
                          border: "2px solid rgba(0,0,0,0.1)",
                          backgroundClip: "padding-box",
                          alignItems: "center",
                          borderRadius: "4px",
                        }}
                      >
                        {/* <MobileScreenShare />*/}

                        <img
                          src={SmsComposerIcon}
                          style={{
                            filter: disableSms
                              ? "grayscale(1) opacity(0.5)"
                              : "none",
                            width: "30px",
                            height: "30px",
                            padding: "2px 2px",
                          }}
                          alt="sms composer"
                        />
                      </button>
                    </Tooltip>
                  )}
                  {privilegesSet.has("sms_email_email_composer") && (
                    <Tooltip title="Email Composer">
                      <button
                        disabled={disableEmail}
                        onClick={() => setEmailComposer(true)}
                        style={{
                          backgroundColor: "#ffffff",
                          display: "flex",
                          justifyContent: "center",
                          width: "35px",
                          height: "35px",
                          border: "2px solid rgba(0,0,0,0.1)",
                          backgroundClip: "padding-box",
                          alignItems: "center",
                          borderRadius: "4px",
                        }}
                      >
                        <img
                          src={emailIcon}
                          style={{
                            filter: disableEmail
                              ? "grayscale(1) opacity(0.5)"
                              : "none",
                            width: "30px",
                            height: "30px",
                            padding: "2px 2px",
                          }}
                          alt="email composer"
                        />
                        {/* <EmailOutlined
                            style={{ color: !disableEmail && "#14348d" }}
                          /> */}
                      </button>
                    </Tooltip>
                  )}
                  {privilegesSet.has("sms_email_view_logs") && (
                    <Tooltip title="View Logs">
                      <button
                        disabled={disableEmail && disableSms}
                        onClick={() => setOpenViewLog(true)}
                        style={{
                          backgroundColor: "#ffffff",
                          display: "flex",
                          justifyContent: "center",
                          width: "35px",
                          height: "35px",
                          border: "2px solid rgba(0,0,0,0.1)",
                          backgroundClip: "padding-box",
                          alignItems: "center",
                          borderRadius: "4px",
                          cursor: "pointer",
                        }}
                      >
                        <img
                          src={Eye_icon}
                          style={{
                            width: "30px",
                            height: "30px",
                            padding: "2px 2px",
                          }}
                          alt="view logs"
                        />
                      </button>
                    </Tooltip>
                  )}
                  {privilegesSet.has("sms_email_gateway_parameters") && (
                    <Tooltip title="Settings">
                      <button
                        onClick={handleClickSetting}
                        style={{
                          backgroundColor: "#ffffff",
                          display: "flex",
                          justifyContent: "center",
                          width: "35px",
                          height: "35px",
                          border: "2px solid rgba(0,0,0,0.1)",
                          backgroundClip: "padding-box",
                          alignItems: "center",
                          borderRadius: "4px",
                          cursor: "pointer",
                        }}
                      >
                        <img
                          src={gatewayIcon}
                          style={{
                            width: "30px",
                            height: "30px",
                            padding: "2px 2px",
                          }}
                          alt="gateway params"
                        />
                      </button>
                    </Tooltip>
                  )}
                </div>
              </div>
            }
          />
          // </Box>
        )}
      </Box>

      {openGatewayParameter && (
        <GatewayParameter
          onClose={() => setOpenGatewayParameter(false)}
          setSmsParam={setSmsParam}
          setEmailParam={setEmailParam}
          showToast={showToast}
          getSmtpConnectivityStatus={getSmtpConnectivityStatus}
          getSmsConnectivityStatus={getSmsConnectivityStatus}
        />
      )}
      {openTextConfiguration && (
        <TextConfiguration
          onClose={() => setOpenTextConfiguration(false)}
          showToast={showToast}
        />
      )}
      {openViewLog && (
        <ViewLog onClose={() => setOpenViewLog(false)} showToast={showToast} />
      )}

      {/* ===========================Event based alert config ==================*/}
      {openAlertConfig && (
        <AlertConfig
          contacts={contacts}
          onClose={() => setOpenAlertConfig(false)}
          showToast={showToast}
        />
      )}

      {/* ===========================Email Composer Dialog ==================*/}
      {EmailComposer && (
        <SmsAndEmailComposer
          contacts={contacts}
          onClose={() => setEmailComposer(false)}
          showToast={showToast}
          enableEmail={true}
        />
      )}

      {/* ===========================SMS Composer Dialog ==================*/}
      {smsComposer && (
        <SmsAndEmailComposer
          contacts={contacts}
          onClose={() => setSmsComposer(false)}
          showToast={showToast}
          enableEmail={false}
        />
      )}

      {/*============================= AddContact============================ */}
      {openAddContact && (
        <AddContact
          showToast={showToast}
          onClose={() => {
            setOpenAddContact(false);
          }}
        />
      )}

      {/* ==============================DELETE Contact =================================*/}
      {openDeleteContact && (
        <DeleteContact
          showToast={showToast}
          onClose={() => {
            setOpenDeleteContact(false);
          }}
          selectedContact={selectedRow}
        />
      )}

      {/*================================ Edit Contact================================= */}
      {openEditContact && (
        <EditContact
          showToast={showToast}
          onClose={() => {
            setOpenEditContact(false);
          }}
          selectedContact={selectedRow}
        />
      )}

      {/* Context-MENU  */}
      <Menu
        id="simple-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleCloseMenu}
      >
        <MenuItem
          onClick={() => {
            setOpenGatewayParameter(true);
            handleCloseMenu();
          }}
        >
          Gateway Parameters
        </MenuItem>
      </Menu>
    </>
  );
};
