import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MModal from "@/components/Reusable/Modal/MModal";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import MSelect from "@/components/Reusable/Select/MSelect";
import {
  FaultAxios,
  InventoryAxios,
  SmsAxios,
} from "@/RestAPI/api/axiosApicall";
import {
  DELETE_ALERT_PROFILE,
  FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID,
  FETCH_DOWN_DEVICES_LIST,
  FETCH_SITE_REP_DETAILS_BY_SITEID,
  FETCH_SITE_VEHICLE_UPTIME_BY_SITEID,
  FETCH_SITEDETAILS_BY_TERMINALTYPE_ID,
  FETCH_STATUS_OF_SITE_BASED_ON_SITEID,
  FETCH_UP_DEVICESLIST,
  GET_ALERT_PROFILE_FOR_GIVEN_ALERT_PROFILE_ID,
  GET_ALERT_PROFILE_FOR_GIVEN_REMOTE_ID,
  GET_MAJOR_ALARM_COUNT_BY_SITEID,
  GET_SITE_RESOURCE_LIST_FAULT_SUMMARY,
  SAVE_AND_UPDATE_ALERT_PROFILE,
} from "@/RestAPI/url/cnmsEndPoint";

import {
  Backdrop,
  Box,
  Checkbox,
  CircularProgress,
  FormControl,
  FormControlLabel,
  FormGroup,
  Typography,
} from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";
import MTable from "@/components/Reusable/Table/MTable";

const minutes = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];
const hours = [
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
  22, 23, 24,
];

const initialWanLinkState = [
  {
    linkId: 1,
    linkName: "VSAT",
    isSelected: false,
  },
  {
    linkId: 2,
    linkName: "E1/OFC",
    isSelected: false,
  },
  // {
  //   linkId: 3,
  //   linkName: "E1/LINK-BEU",
  //   isSelected: false,
  // },
  {
    linkId: 4,
    linkName: "Radio",
    isSelected: false,
  },
];

const initialCheckBoxState = {
  currentStatus: false,
  vehicleUptime: false,
  autoDisable: false,
};
const initialDevicesCount = {
  downCount: "NA",
  upCount: "NA",
};

const createAlertProfileSnapshot = (profile) => ({
  deviceIds: (profile?.grAlertProfileDevices ?? [])
    .map((device) => String(device.deviceId))
    .sort(),

  repIds: (profile?.siteRepDetailBeans ?? [])
    .map((rep) => String(rep.repId))
    .sort(),

  contactIds: (profile?.userDetailsBeans ?? [])
    .map((contact) => String(contact.id))
    .sort(),

  currentStatus: Boolean(profile?.currentStatus),
  vehicleUptime: Boolean(profile?.vehicleUptime),
  autoDisable: Boolean(profile?.autoDisable),

  alertMediaType: Number(profile?.alertMediaType ?? 0),
  alertRepeatTime: Number(profile?.alertRepeatTime ?? 5),
});

const alertMediaObj = ["Only Email", "Only SMS", "Both"];

const columns = [
  { name: "Sl.No", uid: "sno", width: "50px" },
  { name: "profile", uid: "alertProfileId", width: "100px" },
  {
    name: "To",
    uid: "to",
    width: "15%",
  },
  {
    name: "Network Devices",
    uid: "networkDevices",
    width: "20%",
  },
  {
    name: "Status",
    uid: "status",
    width: "100px",
  },
  {
    name: "Vehicle (Uptime)",
    uid: "vehicleUptime",
    width: "100px",
  },
  {
    name: "Alert",
    uid: "alert",
    width: "110px",
  },
  {
    name: "Alert Profile Media(Email,SMS)",
    uid: "alertProfileMedia",
    width: "120px",
  },
  {
    name: "Auto Disable",
    uid: "autoDisable",
    width: "100px",
  },
  {
    name: "Actions",
    uid: "actions",
    width: "145px",
  },
];

export const AlertProfiling = ({
  contacts,
  setContacts,
  showToast,
  refreshAndGetUsers,
}) => {
  const terminalType = useSelector(
    (store) => store.nodeDetails.allTerminalTypeDetails
  );

  // const privilegesSet = useSelector(selectPrivilegesSet); commented for sonar
  //
  const [majorFaultCount, setMajorFaultCount] = useState("NA");
  const [checkBox, setCheckBox] = useState(initialCheckBoxState);
  const [wanLinkCheckBox, setWanLinkCheckBox] = useState(initialWanLinkState);
  const [loading, setLoading] = useState(false);
  //
  const [selectedRemoteVehicle, setSelectedRemoteVehicle] = useState(null);
  // const [modifyMode, setModifyMode] = useState(false);
  const [devices, setDevices] = useState([]);
  const [selectedDevicesId, setSelectedDevicesId] = useState([]);
  const [previewEnable, setPreviewEnable] = useState(false);
  const [selectedHour, setSelectedHour] = useState(0);
  const [selectedMinute, setSelectedMinute] = useState(5);
  const [selectedTerminalType, setSelectedTerminalType] = useState(null);
  const [remoteVehicles, setRemoteVehicles] = useState([]);
  const [loadingRemoteVehicle, setLoadingRemoteVehicle] = useState(false);
  const [loadingAlertProfile, setLoadingAlertProfile] = useState(false);
  // const [upAndDownCount, setUpAndDownCount] = useState(initialDevicesCount); commented for sonar
  const [terminalTypeState, setTerminalTypeState] = useState([]); //// to hide CNMS termninal type
  const [status, setStatus] = useState("NA");
  const [upDevices, setUpDevices] = useState([]);
  const [downDevices, setDownDevices] = useState([]);

  const [remoteReps, setRemoteReps] = useState([]);
  const [selectedReps, setSelectedReps] = useState([]);
  const [alertProfileMedia, setAlertProfileMedia] = useState(null);
  // const [contacts, setContacts] = useState([])
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [allAlertProfiles, setAllAlertProfiles] = useState([]);
  // const [selectedAlertProfile, setSelectedAlrtProfile] = useState(null);
  const [alertProfileId, setAlertProfileId] = useState();
  const [vehUpTime, setVehUpTime] = useState("");

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showEditConfirm, setShowEditConfirm] = useState(false);
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);
  const [openAlertProfileModal, setOpenAlertProfileModal] = useState(false);
  const [alertProfileMode, setAlertProfileMode] = useState("add");

  const [editingAlertProfile, setEditingAlertProfile] = useState(null);
  const [previewAction, setPreviewAction] = useState(null);
  const [originalEditForm, setOriginalEditForm] = useState(null);
  console.log("terminal state", terminalType);

  //// to hide CNMS termninal type
  useEffect(() => {
    let arr = [];
    terminalType.forEach((item) => {
      if (item.terminalTypeName !== "CNMS") {
        arr.push(item);
      }
    });
    setTerminalTypeState(arr);
  }, [terminalType]);

  // const getAllWanLinks = async (id) => {
  //   try {
  //     const response = await TopologyAxios(
  //       `${LINK_CONFIGURATION}/${id}`,
  //       "get"
  //     );
  //     setWanLinkCheckBox(
  //       _.sortBy(
  //         response.data.map((el) => ({ ...el, isSelected: false })),
  //         "linkId"
  //       )
  //     );
  //   } catch {
  //     showToast("Failed to get WAN links", "error");
  //     setWanLinkCheckBox([]);
  //   }
  // };

  const getRemoteVehicleBasedOnTerminalType = async (id) => {
    setLoadingRemoteVehicle(true);
    try {
      const resp = await InventoryAxios(
        `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${id}`,
        "get"
      );
      setRemoteVehicles(resp.data);
    } catch (error) {
      showToast("No remotes available.", "error");
      console.error(error);

      setRemoteVehicles([]);
      setContacts([]);
      setRemoteReps([]);
    }
    setLoadingRemoteVehicle(false);
  };

  const handleChangeCheckBox = (event) => {
    const { name, checked } = event.target;
    setCheckBox({ ...checkBox, [name]: checked });

    if (name === "currentStatus" && checked) {
      getFaultStatus();
      // getInventoryUpAndDownCount(); commented for sonar fix
    }
  };

  // const handleDeviceChange = (event) => {
  //   const value = event.target.value;

  //   setPreviewEnable(false);
  //   setSelectedDevicesId(value);
  // };

  const getAlertProfileBasedonProfileId = async (id) => {
    try {
      const response = await SmsAxios(
        `${GET_ALERT_PROFILE_FOR_GIVEN_ALERT_PROFILE_ID}/${id}`,
        "get"
      );
      if (response.data) {
        const {
          autoDisable,
          currentStatus,
          vehicleUptime,
          grAlertProfileDevices,
          alertRepeatTime,
          siteRepDetailBeans,
          userDetailsBeans,
          alertMediaType,
          alertProfileId,
        } = response.data;

        setAlertProfileId(alertProfileId);
        setAlertProfileMedia(String(alertMediaType));
        setCheckBox({
          autoDisable: autoDisable === true,
          currentStatus: currentStatus === true,
          vehicleUptime: vehicleUptime === true,
        });

        setSelectedReps(siteRepDetailBeans ? siteRepDetailBeans : []);
        setSelectedContacts(userDetailsBeans ? userDetailsBeans : []);
        setSelectedDevicesId(
          grAlertProfileDevices
            ? grAlertProfileDevices?.map((el) => el.deviceId)
            : []
        );
        if (+alertRepeatTime > 60) {
          setSelectedHour(Math.floor(+alertRepeatTime / 60));
          setSelectedMinute(Math.floor(+alertRepeatTime % 60));
        } else {
          setSelectedHour(0);
          setSelectedMinute(+alertRepeatTime);
        }
      }
      return response.data;
    } catch (error) {
      console.log("error", error);
    }
  };

  const getSelectedRemoteVehicleAlertProfile = async (vehicleId) => {
    try {
      const response = await SmsAxios(
        `${GET_ALERT_PROFILE_FOR_GIVEN_REMOTE_ID}/${vehicleId}`,
        "get"
      );
      if (response?.data?.length) {
        setAllAlertProfiles(response.data);
      } else {
        setAllAlertProfiles([]);
      }
    } catch (error) {
      // handleClearFields();
      console.error(error);

      setAllAlertProfiles([]);
      showToast("Failed to fetch alert profile", "error");
    }
  };

  const getDevicesBasedOnRemoteVehicle = async (id) => {
    try {
      const response = await InventoryAxios(
        `${FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID}/${id}`,
        "get"
      );
      setDevices(
        response.data.map((el) => ({
          deviceId: el.resourceId,
          deviceName: el.resourceName,
        }))
      );
    } catch (error) {
      setDevices([]);
      console.error(error);

      showToast("Failed to fetch Network Device", "error");
    }
  };

  const getFaultStatus = async () => {
    const req = selectedDevicesId.map((el) => el);
    try {
      const response = await FaultAxios(
        `${GET_SITE_RESOURCE_LIST_FAULT_SUMMARY}/${selectedRemoteVehicle.siteId}`,
        "post",
        req
      );
      setMajorFaultCount(response.data["MAJOR"] ?? "NA");
    } catch (error) {
      console.error(error);

      showToast("Failed to get fault Status (Major alarm count)", "error");
    }
  };

  // commented for sonar
  // const getInventoryUpAndDownCount = async () => {
  //   try {
  //     const response = await InventoryAxios(
  //       `${FETCH_UP_DOWN_COUNT_OF_DEVICES_FOR_GIVEN_SITEID}/${selectedTerminalType.id}`,
  //       "get"
  //     );
  //     setUpAndDownCount(response.data);
  //   } catch (error) {
  //     console.error(error);

  //     showToast("Failed to get Inventory Status (Up and Down count)", "error");
  //   }
  // };

  const handleRemoteVehicleChange = async (value) => {
    const { siteId, siteName } = value;
    setSelectedRemoteVehicle({ siteName, siteId });
    setWanLinkCheckBox(
      wanLinkCheckBox.map((el) => {
        return { ...el, isSelected: false };
      })
    );
    setCheckBox(initialCheckBoxState);
    //Get ALert Profile
    setLoadingAlertProfile(true);
    await getDevicesBasedOnRemoteVehicle(siteId);
    //getDevices for Selected vehicle
    await getSelectedRemoteVehicleAlertProfile(siteId);
    fetchRepDetails(siteId);
    setLoadingAlertProfile(false);
  };

  const fetchRepDetails = async (siteId) => {
    try {
      const resp = await InventoryAxios(
        `${FETCH_SITE_REP_DETAILS_BY_SITEID}/${siteId}`,
        "get"
      );
      console.log("res", resp?.data);
      setRemoteReps(resp?.data);
      refreshAndGetUsers();
    } catch (error) {
      console.error(error);

      setRemoteReps([]);
      showToast("Failed to fetch Remote Reps.", "error");
    }
  };

  const handleClearFields = () => {
    //reset All initial States
    setSelectedRemoteVehicle(null);
    setSelectedReps([]);
    // setSelectedAlrtProfile(null);
    setAllAlertProfiles([]);
    setAlertProfileMedia(0);
    setSelectedContacts([]);
    setWanLinkCheckBox(
      wanLinkCheckBox.map((el) => {
        return { ...el, isSelected: false };
      })
    );
    setCheckBox(initialCheckBoxState);
    setSelectedDevicesId([]);
    setDevices([]);
    setSelectedHour(0);
    setSelectedMinute(5);
    setAlertProfileId(null);
  };

  const resetAlertProfileFields = () => {
    setSelectedReps([]);
    // setSelectedAlrtProfile(null);
    setSelectedContacts([]);
    setCheckBox(initialCheckBoxState);
    setSelectedDevicesId([]);
    setSelectedHour(0);
    setSelectedMinute(5);
    setAlertProfileId(null);
    setAlertProfileMedia("0");
    setPreviewEnable(false);
  };

  const handleViewAlertProfile = async (rowData) => {
    setPreviewAction(null);
    console.log(rowData, "rowDatttt");

    // setSelectedAlrtProfile(rowData);
    setAlertProfileId(rowData.alertProfileId);

    setSelectedRemoteVehicle({
      siteId: rowData.remoteId,
      siteName: rowData.siteName,
    });

    setCheckBox({
      autoDisable: rowData.autoDisable === "Enabled",
      currentStatus: rowData.currentStatus,
      vehicleUptime: rowData.vehicleUptime === "Enabled",
    });

    setAlertProfileMedia(String(rowData.alertMediaType));

    setSelectedReps(rowData.siteRepDetailBeans ?? []);
    setSelectedContacts(rowData.userDetailsBeans ?? []);

    const repeatTime = Number(rowData.alertRepeatTime ?? 5);

    setSelectedHour(Math.floor(repeatTime / 60));
    setSelectedMinute(repeatTime % 60);

    setSelectedDevicesId(
      (rowData.grAlertProfileDevices ?? []).map((device) => device.deviceId)
    );

    await handlePreview(rowData);
  };

  //================Preview=================
  const handlePreview = async (profile = null) => {
    const siteId = profile?.remoteId ?? selectedRemoteVehicle?.siteId;

    const deviceIds = profile
      ? (profile.grAlertProfileDevices ?? []).map((device) => device.deviceId)
      : selectedDevicesId;

    if (!siteId || !deviceIds.length) {
      showToast("Please select a remote vehicle and network devices.", "error");
      return;
    }

    try {
      setLoadingAlertProfile(true);

      const [alarmsCount, upTime, upDevice, downDevice, siteStatus] =
        await Promise.all([
          FaultAxios(`${GET_MAJOR_ALARM_COUNT_BY_SITEID}/${siteId}`, "get"),
          InventoryAxios(
            `${FETCH_SITE_VEHICLE_UPTIME_BY_SITEID}/${siteId}`,
            "get"
          ),
          InventoryAxios(FETCH_UP_DEVICESLIST, "post", {
            siteId,
            deviceList: deviceIds,
          }),
          InventoryAxios(FETCH_DOWN_DEVICES_LIST, "post", {
            siteId,
            deviceList: deviceIds,
          }),
          InventoryAxios(
            `${FETCH_STATUS_OF_SITE_BASED_ON_SITEID}/${siteId}`,
            "get"
          ),
        ]);

      setMajorFaultCount(alarmsCount.data);
      setVehUpTime(upTime.data);
      setStatus(siteStatus.data);

      setUpDevices((upDevice.data ?? []).map((device) => device.resourceName));

      setDownDevices(
        (downDevice.data ?? []).map((device) => device.resourceName)
      );

      setPreviewEnable(true);
    } catch (error) {
      console.error(error);
      showToast("Failed to fetch preview data.", "error");
      setPreviewEnable(false);
    } finally {
      setLoadingAlertProfile(false);
    }
  };

  const handleConfirm = async () => {
    setLoading(true);
    try {
      // let reqLink = wanLinkCheckBox.filter((el) => {
      //   return el.isSelected === true;
      // });
      const profile = {
        alertRepeatTime: +selectedHour * 60 + selectedMinute,
        //if wan link is req uncomment below line
        // linkDetailsBeans: reqLink.map((el) => { return ({ linkId: el.linkId, linkName: el.linkName, linkStatus: el.linkStatus }) }),
        grAlertProfileDevices: selectedDevicesId
          .map((selectedDevice) =>
            devices.filter((el) => el.deviceId === selectedDevice)
          )
          .flat(),
        autoDisable: checkBox.autoDisable,
        vehicleUptime: checkBox.vehicleUptime,
        currentStatus: checkBox.currentStatus,
        remoteId: selectedRemoteVehicle.siteId,
        siteName: selectedRemoteVehicle.siteName,
        alertMediaType: +alertProfileMedia,
        userDetailsBeans: selectedContacts.map((el) => {
          const { id, emailId, mobile, userName } = el;
          return { id, emailId, mobile, userName };
        }),
        siteRepDetailBeans: selectedReps.map((el) => {
          const {
            repId,
            personnel,
            personnelName,
            unit,
            ipPhone,
            afcel,
            primaryCivilMobile,
            alternateCivilMobile,
            email,
            siteId,
          } = el;
          return {
            repId,
            personnel,
            personnelName,
            unit,
            ipPhone,
            afcel,
            primaryCivilMobile,
            alternateCivilMobile,
            email,
            siteId,
          };
        }),
      };
      if (alertProfileId) {
        profile.alertProfileId = alertProfileId;
      }
      console.log("data", profile);
      await SmsAxios(SAVE_AND_UPDATE_ALERT_PROFILE, "post", profile);
      // handleClearFields();
      resetAlertProfileFields();
      setPreviewEnable(false);
      showToast("Alert profile updated successfully", "success");
      setLoading(false);

      try {
        await getSelectedRemoteVehicleAlertProfile(
          selectedRemoteVehicle.siteId
        );
      } catch (refreshError) {
        console.error("Failed to refresh alert profiles:", refreshError);
      }

      return true;
    } catch (error) {
      setLoading(false);
      console.error(error);

      showToast("Failed to Update alert profile!", "error");
      return false;
    }
  };

  const handleDelete = async (alertProfileId) => {
    setLoading(true);

    try {
      const url = `${DELETE_ALERT_PROFILE}/${alertProfileId}`;
      const response = await SmsAxios(url, "post");

      if (response.status == 200 && response.data == true) {
        setAllAlertProfiles((prev) =>
          prev.filter((profile) => profile.alertProfileId !== alertProfileId)
        );

        // handleClearFields();
        resetAlertProfileFields();
        setPreviewEnable(false);
        showToast("Alert profile Deleted successfully", "success");
        setLoading(false);
      } else {
        setLoading(false);
        showToast("Failed to Delete alert profile!", "error");
      }
    } catch (error) {
      console.error(error);

      setLoading(false);
      showToast("Failed to Delete alert profile!", "error");
    }
  };

  const alertProfileTableData = useMemo(
    () =>
      allAlertProfiles.map((profile, idx) => ({
        ...profile,
        sno: idx + 1,
        to:
          [
            ...(profile.siteRepDetailBeans ?? []).map(
              (rep) => rep.personnelName
            ),
            ...(profile.userDetailsBeans ?? []).map((user) => user.userName),
          ]
            .filter(Boolean)
            .join(", ") || "--",

        networkDevices:
          (profile.grAlertProfileDevices ?? [])
            .map((device) => device.deviceName)
            .filter(Boolean)
            .join(", ") || "--",

        status: profile.currentStatus ? "Enabled" : "Disabled",

        vehicleUptime: profile.vehicleUptime ? "Enabled" : "Disabled",

        alert: `${Math.floor((profile.alertRepeatTime ?? 0) / 60)} Hour(s), ${
          (profile.alertRepeatTime ?? 0) % 60
        } Min(s)`,

        alertProfileMedia:
          ["Only Email", "Only SMS", "Both"][profile.alertMediaType] ??
          "Unknown",

        autoDisable: profile.autoDisable ? "Enabled" : "Disabled",
      })),
    [allAlertProfiles]
  );

  const handleAddAlertProfile = () => {
    setAlertProfileMode("add");
    setEditingAlertProfile(null);

    // Reset the existing form fields
    setSelectedReps([]);
    setSelectedContacts([]);
    setSelectedDevicesId([]);

    setCheckBox({
      currentStatus: true,
      vehicleUptime: false,
      autoDisable: false,
    });

    setSelectedHour(0);
    setSelectedMinute(5);
    setAlertProfileMedia("0");

    setPreviewEnable(false);
    // setModifyMode(true);

    setOpenAlertProfileModal(true);
  };

  const handleEditAlertProfile = async (rowData) => {
    setAlertProfileMode("edit");
    setEditingAlertProfile(rowData);
    setAlertProfileId(rowData.alertProfileId);
    setOriginalEditForm(null);
    setOpenAlertProfileModal(true);

    const profile = await getAlertProfileBasedonProfileId(
      rowData.alertProfileId
    );

    if (profile) {
      setOriginalEditForm(createAlertProfileSnapshot(profile));
    }
  };

  const handleCloseAlertProfileModal = () => {
    setOpenAlertProfileModal(false);
    setEditingAlertProfile(null);
  };

  const prepareAlertProfilePayload = () => {
    const payload = {
      remoteId: selectedRemoteVehicle?.siteId,
      siteName: selectedRemoteVehicle?.siteName,

      siteRepDetailBeans: selectedReps.map((rep) => {
        const {
          repId,
          personnel,
          personnelName,
          unit,
          ipPhone,
          afcel,
          primaryCivilMobile,
          alternateCivilMobile,
          email,
          siteId,
        } = rep;

        return {
          repId,
          personnel,
          personnelName,
          unit,
          ipPhone,
          afcel,
          primaryCivilMobile,
          alternateCivilMobile,
          email,
          siteId,
        };
      }),

      userDetailsBeans: selectedContacts.map((contact) => {
        const { id, emailId, mobile, userName } = contact;
        return { id, emailId, mobile, userName };
      }),

      grAlertProfileDevices: devices.filter((device) =>
        selectedDevicesId.some((id) => String(id) === String(device.deviceId))
      ),

      currentStatus: checkBox.currentStatus,
      vehicleUptime: checkBox.vehicleUptime,
      autoDisable: checkBox.autoDisable,

      alertRepeatTime: selectedHour * 60 + selectedMinute,
      alertMediaType: Number(alertProfileMedia),
    };

    if (alertProfileMode === "edit") {
      payload.alertProfileId = editingAlertProfile?.alertProfileId;
    }

    return payload;
  };

  const handleUpdateAlertProfile = async () => {
    const profileId = editingAlertProfile?.alertProfileId;
    const siteId = selectedRemoteVehicle?.siteId;

    if (!profileId) {
      showToast("Alert profile ID is missing.", "error");
      return;
    }

    if (!siteId) {
      showToast("Please select a remote vehicle.", "error");
      return;
    }

    const payload = prepareAlertProfilePayload();

    try {
      setLoading(true);

      console.log("Updating alert profile payload:", payload);

      // Call the existing save/update API directly.
      await SmsAxios(SAVE_AND_UPDATE_ALERT_PROFILE, "post", payload);

      showToast("Alert profile updated successfully.", "success");

      setOpenAlertProfileModal(false);
      setEditingAlertProfile(null);
      setPreviewEnable(false);

      // Refresh the table with the latest profile data.
      await getSelectedRemoteVehicleAlertProfile(siteId);
    } catch (error) {
      console.error("Failed to update alert profile:", error);

      showToast("Failed to update alert profile.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleOpenPreview = async () => {
    if (!selectedRemoteVehicle || !selectedDevicesId.length) {
      showToast("Please select a remote vehicle and network devices.", "error");
      return;
    }

    setOpenAlertProfileModal(false);
    setPreviewAction(alertProfileMode);

    await handlePreview();
  };

  const handleBackToEdit = () => {
    setPreviewEnable(false);
    setOpenAlertProfileModal(true);
  };

  const currentEditForm = useMemo(
    () => ({
      deviceIds: selectedDevicesId
        .map(String)
        .sort((a, b) => a.localeCompare(b)),

      repIds: selectedReps
        .map((rep) => String(rep.repId))
        .sort((a, b) => a.localeCompare(b)),

      contactIds: selectedContacts
        .map((contact) => String(contact.id))
        .sort((a, b) => a.localeCompare(b)),

      currentStatus: Boolean(checkBox.currentStatus),
      vehicleUptime: Boolean(checkBox.vehicleUptime),
      autoDisable: Boolean(checkBox.autoDisable),

      alertMediaType: Number(alertProfileMedia ?? 0),
      alertRepeatTime: Number(selectedHour) * 60 + Number(selectedMinute),
    }),
    [
      selectedDevicesId,
      selectedReps,
      selectedContacts,
      checkBox,
      alertProfileMedia,
      selectedHour,
      selectedMinute,
    ]
  );

  const isEditFormDirty = useMemo(() => {
    if (!originalEditForm) return false;

    return JSON.stringify(currentEditForm) !== JSON.stringify(originalEditForm);
  }, [currentEditForm, originalEditForm]);

  console.log(checkBox, "rfhgdfhgdf");

  return (
    <Box container spacing={1}>
      <Box item xs={6}>
        <Box>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {/* {privilegesSet.has("alert_profiling_Modify") && (
              <Box
                sx={{ display: "flex", justifyContent: "flex-end", mt: -7.5 }}
              >
                <Box sx={{ display: "flex", gap: 1 }}>
                  <Box item style={{ fontWeight: "bold" }}>
                    View
                  </Box>
                  <Box item>
                    <CustomSwitch
                      checked={modifyMode}
                      onChange={() => setModifyMode((ps) => !ps)}
                      name="toggleBtn"
                    />
                  </Box>
                  <Box item style={{ fontWeight: "bold" }}>
                    {selectedAlertProfile ? "Modify" : "Create"}
                  </Box>
                </Box>
              </Box>
            )} */}
            <Box className="two-inputs-in-one-row" gap={2}>
              <Box className="fullwidth-minpu-cont">
                <MSelect
                  label="Terminal*"
                  options={terminalTypeState}
                  value={selectedTerminalType}
                  onChange={(newValue) => {
                    setSelectedTerminalType(newValue);
                    handleClearFields();
                    setPreviewEnable(false);

                    if (newValue) {
                      getRemoteVehicleBasedOnTerminalType(newValue.id);
                      // getAllWanLinks(newValue.id);
                    } else {
                      setRemoteVehicles([]);
                    }
                  }}
                  placeholder="Select Terminal"
                  getOptionLabel={(option) => option?.terminalTypeName || ""}
                  getOptionValue={(option) => option.id}
                />
              </Box>

              <Box className="fullwidth-minpu-cont">
                <MSelect
                  label="Remote Vehicle*"
                  options={remoteVehicles}
                  value={
                    remoteVehicles.find(
                      (item) =>
                        String(item.siteId) ===
                        String(selectedRemoteVehicle?.siteId)
                    ) ?? null
                  }
                  onChange={(newValue) => {
                    setPreviewEnable(false);

                    if (!newValue) {
                      handleClearFields();
                    } else {
                      handleRemoteVehicleChange(newValue);
                    }
                  }}
                  placeholder="Select Remote Vehicle"
                  getOptionLabel={(option) => option?.siteName || ""}
                  getOptionValue={(option) => option.siteId}
                  disabled={!selectedTerminalType || loadingRemoteVehicle}
                />
              </Box>
            </Box>

            {/* {allAlertProfiles.length > 0 ? (
              <Box className="fullwidth-minpu-cont">
                <MSelect
                  label="Alert Profile(s)"
                  options={allAlertProfiles}
                  value={selectedAlertProfile}
                  onChange={(newValue) => {
                    setPreviewEnable(false);

                    if (!newValue) {
                      handleClearFields();
                    } else {
                      setSelectedAlrtProfile(newValue);
                      getAlertProfileBasedonProfileId(newValue.alertProfileId);
                    }
                  }}
                  placeholder="Select Alert Profile"
                  getOptionLabel={(option) =>
                    String(option?.alertProfileId ?? "")
                  }
                  getOptionValue={(option) => option.alertProfileId}
                />
              </Box>
            ) : null} */}
            {selectedRemoteVehicle && (
              <MTable
                columns={columns}
                tableData={alertProfileTableData}
                isLoading={loadingAlertProfile}
                tableTitle="Alert Profiles"
                handleView={handleViewAlertProfile}
                handleEdit={(rowData) => handleEditAlertProfile(rowData)}
                handleDelete={(rowData) => {
                  // setSelectedAlrtProfile(rowData);
                  setAlertProfileId(rowData.alertProfileId);
                  setShowDeleteConfirm(true);
                }}
                handleAdd={handleAddAlertProfile}
                hideAdd={false}
                AddText={"Add"}
                addDisable={!selectedRemoteVehicle}
                configHeight="100%"
                typeHeight="configuration"
                showPagination
              />
            )}

            {/* <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                mb: 2,
              }}
            >
              <MButtonPrimary
                onClick={handleAddAlertProfile}
                disabled={!selectedRemoteVehicle}
                variant="contained"
              >
                Add Alert Profile
              </MButtonPrimary>
            </Box> */}

            {openAlertProfileModal && (
              <MModal
                open={openAlertProfileModal}
                handleClose={handleCloseAlertProfileModal}
                title={
                  alertProfileMode === "add"
                    ? "Add Alert Profile"
                    : "Edit Alert Profile"
                }
                customWidth={"1024px"}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                    p: 1,
                  }}
                >
                  {/* To: Remote Reps and Others */}
                  <Box
                    sx={{
                      p: 2,
                      border: "2px solid #eee",
                      borderRadius: "5px",
                    }}
                  >
                    <Typography variant="subtitle1">To</Typography>

                    <Box className="two-inputs-in-one-row" gap={2}>
                      <Box className="fullwidth-minpu-cont">
                        <MAlarmSelect
                          label="Remote Rep(s)*"
                          options={remoteReps.map((rep) => ({
                            label: rep.personnelName || "",
                            value: rep.repId,
                          }))}
                          value={selectedReps.map((rep) => rep.repId)}
                          multiple
                          onChange={(ids) => {
                            setSelectedReps(
                              remoteReps.filter((rep) =>
                                ids.includes(rep.repId)
                              )
                            );
                          }}
                        />
                      </Box>

                      <Box className="fullwidth-minpu-cont">
                        <MAlarmSelect
                          label="Others"
                          options={contacts.map((contact) => ({
                            label: contact.userName || "",
                            value: contact.id,
                          }))}
                          value={selectedContacts.map((contact) => contact.id)}
                          multiple
                          onChange={(ids) => {
                            setSelectedContacts(
                              contacts.filter((contact) =>
                                ids.includes(contact.id)
                              )
                            );
                          }}
                        />
                      </Box>
                    </Box>
                  </Box>

                  {/* Network Devices */}
                  <FormControl fullWidth size="small">
                    <MAlarmSelect
                      label="Network Device*"
                      options={devices.map((device) => ({
                        label: device.deviceName || "",
                        value: device.deviceId,
                      }))}
                      value={selectedDevicesId}
                      multiple
                      onChange={setSelectedDevicesId}
                    />
                  </FormControl>

                  {/* Status and Vehicle Uptime */}
                  <FormGroup row>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkBox.currentStatus}
                          onChange={handleChangeCheckBox}
                          name="currentStatus"
                          color="primary"
                        />
                      }
                      label="Status (Current)"
                    />

                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkBox.vehicleUptime}
                          onChange={handleChangeCheckBox}
                          name="vehicleUptime"
                          color="primary"
                        />
                      }
                      label="Vehicle (Uptime)"
                    />

                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkBox.autoDisable}
                          onChange={handleChangeCheckBox}
                          name="autoDisable"
                          color="primary"
                        />
                      }
                      label="Auto Disable"
                    />
                  </FormGroup>

                  {/* Auto Disable */}
                  {/* <FormControl component="fieldset">
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={checkBox.autoDisable}
                        onChange={handleChangeCheckBox}
                        name="autoDisable"
                        color="primary"
                      />
                    }
                    label="Auto Disable"
                  />
                </FormControl> */}

                  <Box sx={{ display: "flex", gap: 2 }}>
                    {/* Alert Repetition Time */}
                    <Box
                      sx={{
                        display: "flex",
                        width: "50%",
                        flexDirection: "column",
                      }}
                    >
                      <Typography>Alert Repetition Time*</Typography>

                      <Box className="two-inputs-in-one-row">
                        <Box className="fullwidth-minpu-cont">
                          <MSelect
                            label="Select Hour"
                            options={hours.map((hour) => ({
                              value: hour,
                              label: String(hour),
                            }))}
                            value={selectedHour}
                            placeholder="Hour"
                            getOptionLabel={(option) => option.label}
                            getOptionValue={(option) => option.value}
                            onChange={(option) => {
                              const hour = Number(option?.value ?? 0);
                              setSelectedHour(hour);

                              if (hour === 24) {
                                setSelectedMinute(0);
                              } else if (hour === 0) {
                                setSelectedMinute(5);
                              }
                            }}
                            style={{
                              borderRadius: "0px",
                              borderTopLeftRadius: "10px",
                              borderBottomLeftRadius: "10px",
                            }}
                          />
                        </Box>

                        <Box className="fullwidth-minpu-cont">
                          <MSelect
                            label="Select Min"
                            options={minutes.map((minute) => ({
                              value: minute,
                              label: String(minute),
                              disabled:
                                (selectedHour === 0 && minute === 0) ||
                                selectedHour === 24,
                            }))}
                            value={selectedMinute}
                            placeholder="Minute"
                            getOptionLabel={(option) => option.label}
                            getOptionValue={(option) => option.value}
                            onChange={(option) => {
                              setSelectedMinute(Number(option?.value ?? 0));
                            }}
                            style={{
                              borderRadius: "0px",
                              borderTopRightRadius: "10px",
                              borderBottomRightRadius: "10px",
                            }}
                          />
                        </Box>
                      </Box>
                    </Box>

                    {/* Alert Profile Media */}
                    <Box
                      sx={{
                        display: "flex",
                        width: "50%",
                        flexDirection: "column",
                        justifyContent: "flex-end",
                      }}
                    >
                      <Box
                        className="fullwidth-minpu-cont"
                        sx={{ justifyContent: "flex-end" }}
                      >
                        <MSelect
                          label="Alert Profile Media*"
                          options={alertMediaObj.map((media, index) => ({
                            label: media,
                            value: String(index),
                          }))}
                          value={String(alertProfileMedia ?? "0")}
                          placeholder="Select Alert Profile Media"
                          getOptionLabel={(option) => option.label}
                          getOptionValue={(option) => option.value}
                          onChange={(option) => {
                            setAlertProfileMedia(String(option?.value ?? "0"));
                          }}
                        />
                      </Box>
                    </Box>
                  </Box>

                  {/* Modal Actions */}
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "flex-end",
                      gap: 2,
                      mt: 2,
                    }}
                  >
                    <MButtonSecondary onClick={resetAlertProfileFields}>
                      Clear
                    </MButtonSecondary>

                    <MButtonSecondary onClick={handleCloseAlertProfileModal}>
                      Cancel
                    </MButtonSecondary>

                    <MButtonPrimary
                      disabled={
                        !selectedReps.length ||
                        !selectedRemoteVehicle ||
                        !selectedDevicesId.length ||
                        loading ||
                        loadingAlertProfile ||
                        (alertProfileMode === "edit" &&
                          (!originalEditForm || !isEditFormDirty))
                      }
                      onClick={handleOpenPreview}
                      variant="contained"
                    >
                      {alertProfileMode === "add"
                        ? "Preview"
                        : "Preview changes"}
                    </MButtonPrimary>
                  </Box>
                </Box>
              </MModal>
            )}
          </Box>
        </Box>
      </Box>

      {previewEnable && selectedRemoteVehicle && (
        <MModal
          open={previewEnable && selectedRemoteVehicle}
          handleClose={() => setPreviewEnable(false)}
          title="PREVIEW"
          customWidth={"768px"}
        >
          {previewEnable && selectedRemoteVehicle && (
            <Box>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Remote Id:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    {previewEnable && (
                      <Typography sx={{ fontWeight: "bold" }}>
                        {" "}
                        {selectedRemoteVehicle?.siteId}
                      </Typography>
                    )}
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Site Name:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    {previewEnable && (
                      <Typography sx={{ fontWeight: "bold" }}>
                        {" "}
                        {selectedRemoteVehicle?.siteName}
                      </Typography>
                    )}
                  </Box>
                </Box>
                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Remote Rep(s):
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    <Box
                      sx={{
                        maxHeight: "100px",
                        overflowY: "scroll",
                        border: "2px solid #eee",
                        width: "100%",
                        borderRadius: "5px",
                        paddingLeft: "10px",
                      }}
                    >
                      {previewEnable && (
                        <Typography>
                          {selectedReps.map((el, i) => (
                            <Typography key={el}>
                              {el.personnelName}
                              {selectedReps.length - 1 !== i && ","}
                            </Typography>
                          ))}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Others:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    <Box
                      sx={{
                        maxHeight: "100px",
                        overflowY: "scroll",
                        border: "2px solid #eee",
                        width: "100%",
                        borderRadius: "5px",
                        paddingLeft: "10px",
                      }}
                    >
                      {previewEnable &&
                        (selectedContacts.length ? (
                          <Typography>
                            {selectedContacts.map((el, i) => (
                              <Typography key={el}>
                                {el.userName}
                                {selectedContacts.length - 1 !== i && ","}
                              </Typography>
                            ))}
                          </Typography>
                        ) : (
                          "--"
                        ))}
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Up Devices:
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      width: "60%",
                      flexDirection: "column",
                    }}
                  >
                    <Box
                      sx={{
                        maxHeight: "100px",
                        overflowY: "scroll",
                        border: "2px solid #eee",
                        width: "100%",
                        borderRadius: "5px",
                        paddingLeft: "10px",
                      }}
                    >
                      {previewEnable && (
                        <Typography
                          sx={{ display: "flex", flexDirection: "column" }}
                        >
                          {upDevices.length
                            ? upDevices.map((el, i) => (
                                <Typography key={el}>
                                  {el}
                                  {upDevices.length - 1 !== i && ","}
                                </Typography>
                              ))
                            : "No Up Devices"}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Down Devices:
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      width: "60%",
                      flexDirection: "column",
                    }}
                  >
                    <Box
                      sx={{
                        maxHeight: "100px",
                        overflowY: "scroll",
                        border: "2px solid #eee",
                        width: "100%",
                        borderRadius: "5px",
                        paddingLeft: "10px",
                      }}
                    >
                      {previewEnable && (
                        <Typography>
                          {downDevices.length
                            ? downDevices.map((el, i) => (
                                <Typography key={el}>
                                  {el}
                                  {downDevices.length - 1 !== i && ","}
                                </Typography>
                              ))
                            : "No Down Devices."}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Status:
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      width: "60%",
                      flexDirection: "column",
                    }}
                  >
                    {previewEnable && checkBox.currentStatus && (
                      <>
                        <Typography>{status}</Typography>
                        <Typography color="error">
                          Major alarms:{majorFaultCount ?? "NA"}
                        </Typography>
                      </>
                    )}
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Vehicle uptime:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    {previewEnable && checkBox.vehicleUptime && (
                      <Typography>{vehUpTime}</Typography>
                    )}
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Alert Repetition Time:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    {previewEnable && (
                      <Typography>{`${selectedHour} Hour(s),${selectedMinute} Min(s)`}</Typography>
                    )}
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Alert Profile Media:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    {previewEnable && (
                      <Typography>
                        {alertMediaObj[alertProfileMedia]}
                      </Typography>
                    )}
                  </Box>
                </Box>

                <Box sx={{ display: "flex" }}>
                  <Box sx={{ display: "flex", flex: 1, width: "40%" }}>
                    Auto-Disable:
                  </Box>
                  <Box sx={{ display: "flex", width: "60%" }}>
                    {previewEnable && checkBox.autoDisable ? (
                      <Typography>
                        Enabled (Alert profile will be sent only once)
                      </Typography>
                    ) : (
                      <Typography>Disabled</Typography>
                    )}
                  </Box>
                </Box>

                {previewAction && (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "flex-end",
                      gap: 2,
                      mt: 2,
                    }}
                  >
                    <MButtonSecondary onClick={handleBackToEdit}>
                      Edit
                    </MButtonSecondary>

                    <MButtonSecondary
                      onClick={() => {
                        setPreviewEnable(false);
                        setPreviewAction(null);
                      }}
                    >
                      Cancel
                    </MButtonSecondary>

                    <MButtonPrimary
                      disabled={loading || loadingAlertProfile}
                      onClick={async () => {
                        let success = false;

                        if (previewAction === "add") {
                          success = await handleConfirm();
                        } else if (previewAction === "edit") {
                          success = await handleUpdateAlertProfile();
                        }

                        if (success) {
                          setPreviewEnable(false);
                          setPreviewAction(null);
                        }
                      }}
                      variant="contained"
                    >
                      {loading
                        ? "Saving..."
                        : previewAction === "edit"
                        ? "Update"
                        : "Save"}
                    </MButtonPrimary>
                  </Box>
                )}

                {/* <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 2 }}>
                {previewEnable && modifyMode && (
                  <Box item>
                    <MButtonPrimary
                      onClick={() => {
                        setShowEditConfirm(true);
                      }}
                      variant="contained"
                    >
                      Edit
                    </MButtonPrimary>
                  </Box>
                )}
                {selectedAlertProfile && previewEnable && modifyMode && (
                  <Box item>
                    <MButtonPrimary
                      onClick={() => {
                        setShowDeleteConfirm(true);
                      }}
                      color="primary"
                      variant="contained"
                    >
                      Delete
                    </MButtonPrimary>
                  </Box>
                )}

                {modifyMode && (
                  <MButtonPrimary
                    disabled={
                      !selectedDevicesId.length || !previewEnable || loading
                    }
                    
                    onClick={() => setShowSaveConfirm(true)}
                    color="primary"
                    variant="contained"
                    startIcon={
                      loading ? (
                        <CircularProgress color="primary" size="24px" />
                      ) : (
                        <></>
                      )
                    }
                  >
                    Save
                  </MButtonPrimary>
                )}
              </Box> */}
              </Box>
            </Box>
          )}
        </MModal>
      )}

      <MDialog
        open={showDeleteConfirm}
        onClose={() => setShowDeleteConfirm(false)}
        onConfirm={() => {
          handleDelete(alertProfileId);
          setShowDeleteConfirm(false);
        }}
        title={"Confirmation"}
        message={"Are you sure want to delete?"}
        icon={confirmIcon}
      />
      <MDialog
        open={showEditConfirm}
        onClose={() => setShowEditConfirm(false)}
        onConfirm={() => {
          setPreviewEnable(false);
          setShowEditConfirm(false);
        }}
        title={"Confirmation"}
        message={"Are you sure want to edit?"}
        icon={confirmIcon}
      />
      <MDialog
        open={showSaveConfirm}
        onClose={() => setShowSaveConfirm(false)}
        onConfirm={() => {
          handleConfirm();
          setShowSaveConfirm(false);
        }}
        title={"Confirmation"}
        message={"Are you sure want to Save ?"}
        icon={confirmIcon}
      />
      <Backdrop
        style={{ zIndex: 1000, position: "absolute" }}
        open={loadingAlertProfile}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
    </Box>
  );
};
