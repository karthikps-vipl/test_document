import React, { useState, useEffect } from "react";

import { useSelector } from "react-redux";

import moment from "moment";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  GET_SMS_CONFIG_REMOTE,
  SAVE_AND_UPDATE_SMS_CONFIG_REMOTE,
} from "@/RestAPI/url/cnmsEndPoint";
import {
  Box,
  Button,
  CircularProgress,
  FormControlLabel,
  FormGroup,
  Grid,
  LinearProgress,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import MCheckbox from "@/components/Reusable/Checkbox/MCheckbox";
import { Cancel, CheckCircle, Save } from "@mui/icons-material";
import MDialog from "@/components/Reusable/Dialog/MDialog";

const initialState = {
  CNMSMAIN: false,
  CNMSSTD: false,
};

const Sms = ({ showToast, onClose }) => {
  const allTerminalName = useSelector(
    (store) => store.nodeDetails.allTerminalTypeDetails
  )
    .filter((el) => el.id !== 1)
    .map((el) => ({
      [el.terminalTypeName]: false,
    }));

  const initialStateTerminalName = Object.assign({}, ...allTerminalName);
  const initialStateCheckBox = { ...initialState, ...initialStateTerminalName };
  const terminalName = Object.keys(initialStateTerminalName);

  const [sendingTime, setSendingTime] = useState(new Date());
  const [msgFrequency, setMsgFrequency] = useState("weekly");
  const [checkBoxState, setCheckBoxState] = useState(initialStateCheckBox);
  const [loading, setLoading] = useState(true);
  const [savingLoading, setSavingLoading] = useState(false);
  const [modifyMode, setModifyMode] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);

  const handleCheckBoxStateChange = (e) => {
    const { checked, name } = e.target;
    setCheckBoxState({ ...checkBoxState, [name]: checked });
    setIsDirty(true);
  };

  useEffect(() => {
    SmsAxios(GET_SMS_CONFIG_REMOTE, "get")
      .then((response) => {
        let parameter = response.data;
        if (parameter) {
          setCheckBoxState({
            ...Object.assign(
              initialStateCheckBox,
              ...parameter.remoteTypeId.split(",").map((el) => ({ [el]: true }))
            ),
          });
          setSendingTime(parameter.scheduledTime);
          setMsgFrequency(parameter.frequency);
        }
        console.log(parameter, "parameter");
        setLoading(false);
      })
      .catch((error) => {
        setLoading(false);
        console.error(error);

        showToast("Failed to Fetch SMS Configuration", "error");
      });
    // initialStateTerminalName (Re-rending)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showToast]);

  const saveConfiguration = async () => {
    setSavingLoading(true);
    const req = {
      frequency: msgFrequency,
      remoteTypeId: Object.entries(checkBoxState)
        .filter((el) => el[1])
        .flat()
        .filter((el) => typeof el !== "boolean")
        .join(),
      scheduledTime: moment(sendingTime).add(5.5, "h").toISOString(),
    };
    try {
      await SmsAxios(SAVE_AND_UPDATE_SMS_CONFIG_REMOTE, "post", req);
      showToast("SMS configured successfully", "success");
      setIsDirty(false);
      setModifyMode(false);
      setOpenConfirmation(false);
    } catch (error) {
      console.error(error);

      showToast("Failed to configure SMS", "error");
    }
    setSavingLoading(false);
  };

  return (
    <>
      <Grid container spacing={0} justifyContent="center">
        <Grid item xs={12}>
          <Grid
            container
            spacing={1}
            alignItems="center"
            justifyContent="flex-end"
          >
            <Grid item style={{ fontWeight: "bold" }}>
              View
            </Grid>
            <Grid item>
              <CustomSwitch
                checked={modifyMode}
                onChange={() => {
                  setModifyMode((ps) => !ps);
                }}
                name="toggleBtn"
              />
            </Grid>
            <Grid item style={{ fontWeight: "bold" }}>
              Modify
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12} style={{ marginTop: "-20px" }}>
          <Typography
            color="primary"
            align="center"
            variant="subtitle1"
            style={{ fontWeight: "bold" }}
          >
            SMS PARAMETER
          </Typography>
          {loading && <LinearProgress />}
        </Grid>

        <Grid item xs={12}>
          <Grid>
            <Grid item xs={8}>
              <RadioGroup
                name="MsgFrequency"
                value={msgFrequency}
                onChange={(e) => {
                  setMsgFrequency(e.target.value);
                  setIsDirty(true);
                }}
                row
              >
                <FormControlLabel
                  disabled={!modifyMode}
                  value="daily"
                  control={<Radio color="primary" />}
                  label="Daily"
                />
                <FormControlLabel
                  disabled={!modifyMode}
                  value="weekly"
                  control={<Radio color="primary" />}
                  label="Weekly"
                />
                <FormControlLabel
                  disabled={!modifyMode}
                  value="monthly"
                  control={<Radio color="primary" />}
                  label="Monthly"
                />
              </RadioGroup>
            </Grid>
            <Grid item xs={4}>
              {/* <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <KeyboardTimePicker
                  label="SMS sending Time"
                  fullWidth
                  inputVariant="outlined"
                  size="small"
                  views={["hours", "minutes", "seconds"]}
                  ampm={false}
                  InputLabelProps={{ shrink: true }}
                  format={"HH:mm:ss"}
                  InputProps={{
                    readOnly: true,
                  }}
                  value={sendingTime}
                  onChange={(date) => {
                    setSendingTime(date);
                    setIsDirty(true);
                  }}
                  disabled={!modifyMode}
                />
              </MuiPickersUtilsProvider> */}
            </Grid>
          </Grid>
        </Grid>

        {terminalName.map((el) => {
          return (
            <Grid item xs={12} key={el}>
              <Grid container spacing={1} alignItems="center">
                <Grid item xs={4}>
                  <Typography>{el}:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <FormControlLabel
                    control={
                      <MCheckbox
                        name={el}
                        disabled={!modifyMode}
                        checked={checkBoxState[el]}
                        onChange={handleCheckBoxStateChange}
                        color="primary"
                      />
                    }
                    label="Online-Offline"
                  />
                </Grid>
              </Grid>
            </Grid>
          );
        })}
        <Grid item xs={12}>
          <Grid container spacing={1} alignItems="center">
            <Grid item xs={4}>
              <Typography>CNMS:</Typography>
            </Grid>
            <Grid item xs={8}>
              <FormGroup row>
                <FormControlLabel
                  control={
                    <MCheckbox
                      checked={checkBoxState["CNMSMAIN"]}
                      disabled={!modifyMode}
                      onChange={handleCheckBoxStateChange}
                      name="CNMSMAIN"
                      color="primary"
                    />
                  }
                  label="Main Status"
                />
                <FormControlLabel
                  control={
                    <MCheckbox
                      checked={checkBoxState["CNMSSTD"]}
                      disabled={!modifyMode}
                      onChange={handleCheckBoxStateChange}
                      name="CNMSSTD"
                      color="primary"
                    />
                  }
                  label="Std-by-Status"
                />
              </FormGroup>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid
        container
        spacing={2}
        justifyContent="flex-end"
        style={{ marginTop: "8px" }}
      >
        <Grid item>
          {modifyMode && (
            <Button
              onClick={() => setOpenConfirmation(true)}
              disabled={loading || savingLoading || !isDirty}
              color="primary"
              variant="contained"
              startIcon={<Save />}
            >
              {savingLoading && <CircularProgress size="24px" />} Save
            </Button>
          )}
        </Grid>
        <Grid item>
          <Button
            variant="contained"
            onClick={onClose}
            startIcon={<Cancel />}
            color="secondary"
          >
            close
          </Button>
        </Grid>
      </Grid>

      <MDialog
        title={"Confirmation"}
        onClose={() => setOpenConfirmation(true)}
        open={openConfirmation}
        maxWidth="xs"
      >
        <Box>
          <Typography align="center">
            Do you really want to save SMS Text Configuration in Database ?
          </Typography>
        </Box>
        <Box>
          <Button
            disabled={savingLoading}
            onClick={saveConfiguration}
            variant="contained"
            color="primary"
            startIcon={<CheckCircle />}
          >
            {savingLoading && <CircularProgress size="24px" />} Yes
          </Button>
          <Button
            onClick={() => setOpenConfirmation(false)}
            variant="contained"
            color="secondary"
            startIcon={<Cancel />}
          >
            No
          </Button>
        </Box>
      </MDialog>
    </>
  );
};

export default Sms;
