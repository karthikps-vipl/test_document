import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MCheckbox from "@/components/Reusable/Checkbox/MCheckbox";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import MForm from "@/components/Reusable/Form/MForm";
import MModal from "@/components/Reusable/Modal/MModal";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import { FaultAxios, SmsAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_EVENTBASED_ALERT_CONFIG_DETAILS,
  GET_ALL_USERS_EMAIL_SMS_SERVICE,
  SAVE_EVENTBASED_ALERT_CONFIG_DETAILS,
} from "@/RestAPI/url/cnmsEndPoint";
import { GET_SEVERITY_KEY_VALUE_PAIR } from "@/RestAPI/url/endpoint";
import { Box, CircularProgress, Grid } from "@mui/material";
import { useEffect, useState } from "react";
import confirmIcon from "@/assets/SVGIcons/Confirmation_icon.svg";

const AlertConfig = ({ onClose, showToast }) => {
  const [severities, setSeverities] = useState({});
  const [selectedSeverities, setSelectedSeverities] = useState([]);
  const [enableReps, setEnableReps] = useState(false);
  const [contacts, setContacts] = useState([]);
  const [contactOptions, setContactOptions] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [alertMedia, setAlertMedia] = useState({ sms: false, email: false });
  const [enableOthers, setEnableOthers] = useState(false);
  const [loading, setLoading] = useState(false);
  const [fetchLoad, setFetchLoad] = useState(false);
  const [proceed, setProceed] = useState(false);
  const [modifyMode, setModifyMode] = useState(false);
  const [sevError, setSevError] = useState([]);
  const [recErr, setRecErr] = useState(true);
  const [showConfigConfirm, setShowConfigConfirm] = useState(false);

  const fetchSeverity = async () => {
    try {
      let data = await FaultAxios(GET_SEVERITY_KEY_VALUE_PAIR, "get");
      setSeverities(data.data);
    } catch (error) {
      setSeverities([]);
      console.error(error);
    }
  };

  const refreshAndGetUsers = async () => {
    try {
      const response = await SmsAxios(GET_ALL_USERS_EMAIL_SMS_SERVICE, "get");

      const mappedData = [...response.data].reverse().map((el, i) => ({
        ...el,
        index: i + 1,
        mobileWithCode:
          el.mobile && el.mobile.length > 10
            ? `+(${el.mobile.slice(0, 2)}) ${el.mobile.slice(-10)}`
            : el.mobile || "",
      }));

      setContacts(mappedData);

      const options = mappedData.map((contact) => ({
        label: `${contact.userName} (${contact.mobileWithCode})`,
        value: contact.id,
      }));

      setContactOptions(options);
    } catch (error) {
      setContacts([]);
      setContactOptions([]);
      console.error(error);
      showToast("Failed to fetch contacts.", "error");
    }
  };

  const fetchEventBsedAlerts = () => {
    setFetchLoad(true);
    SmsAxios(FETCH_EVENTBASED_ALERT_CONFIG_DETAILS, "get")
      .then(({ data }) => {
        console.log("dk res", data);
        setFetchLoad(false);
        setAlertMedia({ sms: data.sms, email: data.email });
        setEnableReps(data.reps);
        setSelectedSeverities(
          data?.eventAlertSeverities
            ? data.eventAlertSeverities.map((el) => {
                return String(el.alarmSeverity);
              })
            : []
        );
        setSevError(
          data?.eventAlertSeverities
            ? data.eventAlertSeverities.map((el) => {
                return String(el.alarmSeverity);
              })
            : []
        );
        setSelectedContacts(
          data?.eventAlertUserInfos
            ? data.eventAlertUserInfos.map((el) => {
                return el.grUserId;
              })
            : []
        );
        data.eventAlertUserInfos?.length
          ? setEnableOthers(true)
          : setEnableOthers(false);
      })
      .catch((err) => {
        setFetchLoad(false);
        console.error(err);

        showToast("Failed to fetch Event Based Alerts", "error");
      });
  };

  const handleSave = () => {
    setLoading(true);
    setProceed(false);
    let data = {
      reps: enableReps,
      email: alertMedia.email,
      sms: alertMedia.sms,
      eventAlertUserInfos: selectedContacts.map((el) => {
        return {
          grUserId: {
            id: el.id,
            emailId: el.emailId,
            mobile: el.mobile,
            userName: el.userName,
            deleteStatus: false,
          },
        };
      }),
      eventAlertSeverities: selectedSeverities.map((el) => {
        return {
          alarmSeverity: Number(el),
          alarmName: severities[el],
        };
      }),
    };
    SmsAxios(SAVE_EVENTBASED_ALERT_CONFIG_DETAILS, "post", data)
      .then((res) => {
        showToast("Configured Successfully.", "success");
        setLoading(false);
      })
      .catch((err) => {
        showToast("Failed to configure.", "error");
        setLoading(false);
        console.error(err);
      });
  };

  useEffect(() => {
    fetchSeverity();
    refreshAndGetUsers();
    fetchEventBsedAlerts();
  }, []);

  const handleSeverityChange = (v) => {
    let checked = [...selectedSeverities];
    if (checked.includes(v)) {
      checked.splice(
        checked.findIndex((el) => {
          return el === v;
        }),
        1
      );
    } else {
      checked.push(v);
    }
    setSelectedSeverities([...checked]);
    setSevError(checked);
  };

  useEffect(() => {
    console.log("dk contacts", enableReps);
    if (enableReps) {
      setRecErr(false);
    } else if (enableOthers) {
      setRecErr(false);
    } else {
      setRecErr(true);
    }
  }, [enableReps, enableOthers]);

  // console.log('dk contacts', !proceed, !error.severity.length, !Object.values(alertMedia).includes(true), error.recievers, (enableOthers ? !selectedContacts.length : false))
  return (
    <MModal
      title="Event Based Alert Configuration"
      open={true}
      handleClose={onClose}
      customWidth={"600px"}
    >
      <Box>
        <Box style={{ display: "flex", justifyContent: "flex-end" }}>
          <Grid
            container
            spacing={1}
            alignItems="center"
            justifyContent="flex-end"
          >
            <Grid item style={{ fontWeight: "bold" }}>
              View
            </Grid>
            <Grid item>
              <CustomSwitch
                checked={modifyMode}
                onChange={() => setModifyMode((ps) => !ps)}
                name="toggleBtn"
              />
            </Grid>
            <Grid item style={{ fontWeight: "bold" }}>
              Modify
            </Grid>
          </Grid>
        </Box>

        {fetchLoad && (
          <CircularProgress
            style={{ zIndex: 1200, position: "fixed", top: "50%", left: "50%" }}
            color="white"
          />
        )}
        <Box sx={{ display: "flex", flexDirection: "column" }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Box item md={3}>
              Alarm Severity*
            </Box>

            <Box item md={9}>
              {Object.keys(severities).map((el) => (
                <MCheckbox
                  key={el}
                  checked={selectedSeverities.includes(el)}
                  onChange={() => {
                    handleSeverityChange(el);
                    setProceed(true);
                  }}
                  label={severities[el]}
                  // color={colors[severities[el]]}
                  // color={"red"}
                  disabled={!modifyMode}
                />
              ))}
            </Box>
          </Box>
          <MForm title={"Recievers:*"} paddingX={2}>
            <Box sx={{ display: "flex", gap: 2 }}>
              <Grid item xs={4}>
                <MCheckbox
                  checked={enableReps}
                  onChange={(e) => {
                    setEnableReps(e.target.checked);
                    setProceed(true);
                  }}
                  label="Remote Rep(s)"
                  color="primary"
                  disabled={!modifyMode}
                />
              </Grid>

              <Grid item xs={8}>
                <Box style={{ display: "flex" }}>
                  <MCheckbox
                    checked={enableOthers}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setEnableOthers(checked);

                      if (!checked) {
                        setSelectedContacts([]);
                      }
                    }}
                    color="primary"
                    disabled={!modifyMode}
                  />

                  <Box
                    style={{
                      display: "flex",
                      alignItems: "flex-start", // Changed to flex-start so label aligns with top of select if error appears
                      gap: 2,
                    }}
                  >
                    {/* Label Container */}
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-start",
                        alignItems: "center",
                        mt: 1,
                      }}
                    >
                      Others
                    </Box>

                    {/* Input and Error Message Container */}
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        // alignItems: "flex-start",
                        width: "230px",
                      }}
                    >
                      <MAlarmSelect
                        options={contactOptions}
                        multiple
                        disabled={!enableOthers || !modifyMode}
                        value={selectedContacts.map((contact) => contact.id)}
                        onChange={(selectedIds) => {
                          const ids = Array.isArray(selectedIds)
                            ? selectedIds
                            : [];
                          setSelectedContacts(
                            contacts.filter((contact) =>
                              ids.some(
                                (id) => String(id) === String(contact.id)
                              )
                            )
                          );
                          setProceed(true);
                        }}
                      />

                      {/* Error message will now appear directly below the select input */}
                      {enableOthers && !selectedContacts.length && (
                        <span
                          style={{
                            color: "red",
                            fontSize: ".7em",
                            marginTop: "4px",
                          }}
                        >
                          Kindly select others
                        </span>
                      )}
                    </Box>
                  </Box>
                </Box>
              </Grid>
            </Box>
          </MForm>

          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Grid item md={3}>
              Alert Media*
            </Grid>

            <Grid item md={9}>
              <MCheckbox
                checked={alertMedia.email}
                onChange={(e) => {
                  setAlertMedia({
                    ...alertMedia,
                    email: e.target.checked,
                  });
                  setProceed(true);
                }}
                label="Email"
                color="primary"
                disabled={!modifyMode}
              />

              <MCheckbox
                checked={alertMedia.sms}
                onChange={(e) => {
                  setAlertMedia({
                    ...alertMedia,
                    sms: e.target.checked,
                  });
                  setProceed(true);
                }}
                label="SMS"
                color="primary"
                disabled={!modifyMode}
              />
            </Grid>
          </Box>
        </Box>
      </Box>
      <Box sx={{ float: "right" }}>
        <MButtonPrimary
          size="small"
          disabled={
            !proceed ||
            (!sevError.length &&
            !Object.values(alertMedia).includes(true) &&
            recErr &&
            !enableOthers
              ? false
              : !sevError.length ||
                !Object.values(alertMedia).includes(true) ||
                recErr ||
                (enableOthers ? !selectedContacts.length : false))
          }
          startIcon={
            loading ? <CircularProgress size="24px" color="inherit" /> : <></>
          }
          onClick={() => setShowConfigConfirm(true)}
          variant="contained"
          color="primary"
        >
          Configure
        </MButtonPrimary>
      </Box>

      <MDialog
        open={showConfigConfirm}
        onClose={() => setShowConfigConfirm(false)}
        onConfirm={() => {
          handleSave();
          setShowConfigConfirm(false);
        }}
        title={"Confirmation"}
        message={"Are you sure want to save?"}
        icon={confirmIcon}
      />
    </MModal>
  );
};
export default AlertConfig;
