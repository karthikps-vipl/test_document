import MDialog from "@/components/Reusable/Dialog/MDialog";
import { SmsAxios } from "@/RestAPI/api/axiosApicall";
import { SOFT_DELETE_USER_BY_ID } from "@/RestAPI/url/cnmsEndPoint";
import { Box, Typography } from "@mui/material";
import { useState } from "react";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";

export function DeleteContact({ onClose, showToast, selectedContact }) {
  const [loading, setLoading] = useState(false);

  const deleteContact = async () => {
    setLoading(true);
    try {
      await SmsAxios(`${SOFT_DELETE_USER_BY_ID}/${selectedContact.id}`, "post");
      showToast("successfully Deleted", "success");
      onClose();
    } catch (error) {
      showToast("Failed to Delete", "error");
      console.error(error);
    }
    setLoading(false);
  };

  return (
    <MDialog
      onClose={onClose}
      title={"Confirmation"}
      open={true}
      fullWidth
      maxWidth="xs"
      icon={Delete_Icon_}
      onConfirm={deleteContact}
      cancelText="No"
      isSubmitting={loading}
      confirmDisabled={loading}
    >
      <Box dividers>
        <Typography align="center">
          Do you Really want to Delete{" "}
          <span style={{ fontWeight: "bold" }}>
            {selectedContact?.userName}
          </span>
          {""}?
        </Typography>
      </Box>
      {/* <Box>
        <Button
          onClick={deleteContact}
          disabled={loading}
          variant="contained"
          color="primary"
          startIcon={<CheckCircle />}
        >
          {loading && <CircularProgress size="24px" />} Yes
        </Button>
      </Box> */}
    </MDialog>
  );
}
