import { styled } from "@mui/material/styles";
import Switch from "@mui/material/Switch";

const CustomSwitchButton = styled(Switch)(({ theme }) => ({
  width: 54,
  height: 26,
  padding: 0,
  display: "flex",

  // Prevent the overall wrapper from washing out entirely
  "&.Mui-disabled": {
    opacity: 1,
  },

  "& .MuiSwitch-switchBase": {
    padding: 1,
    margin: 1,
    transitionDuration: "300ms",

    // --- STATE 1: ACTIVE & CHECKED ---
    "&.Mui-checked": {
      transform: "translateX(28px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        background:
          "linear-gradient(135deg, rgba(34,197,94,0.7), rgba(16,185,129,0.55))",
        opacity: 1,
        border: "1px solid rgba(255,255,255,0.18)",
        boxShadow:
          "0 4px 12px rgba(34,197,94,0.35), inset 0 1px 1px rgba(255,255,255,0.25)",
      },
      "& .MuiSwitch-thumb": {
        background:
          "linear-gradient(145deg, rgba(255,255,255,0.95), rgba(220,255,230,0.75))",
      },

      // --- STATE 2: DISABLED BUT STILL CHECKED ---
      // This solves the issue where the green color disappeared when rows were deselected
      "&.Mui-disabled": {
        "& + .MuiSwitch-track": {
          background:
            "linear-gradient(135deg, rgba(34,197,94,0.35), rgba(16,185,129,0.25))", // Subtle/Muted Green
          opacity: 0.7,
          border: "1px solid rgba(0, 0, 0, 0.1)",
          boxShadow: "none",
        },
        "& .MuiSwitch-thumb": {
          background: "rgba(240, 240, 240, 0.9)",
        },
      },
    },

    // --- STATE 3: DISABLED & UNCHECKED ---
    "&.Mui-disabled": {
      color: "rgba(200, 200, 200, 0.6)",
      "& + .MuiSwitch-track": {
        opacity: 1,
        background: "rgba(220, 220, 220, 0.45)", // A clearly visible subtle gray tracking line
        border: "1px solid rgba(0, 0, 0, 0.12)",
      },
    },
  },

  "& .MuiSwitch-thumb": {
    width: 22,
    height: 22,
    borderRadius: "50%",
    backdropFilter: "blur(12px)",
    background:
      "linear-gradient(145deg, rgba(255,255,255,0.85), rgba(255,255,255,0.55))",
    boxShadow:
      "0 2px 6px rgba(0,0,0,0.25), inset 0 1px 2px rgba(255,255,255,0.8)",
    border: "1px solid rgba(255,255,255,0.35)",
  },

  "& .MuiSwitch-track": {
    borderRadius: 26 / 2,
    background:
      "linear-gradient(135deg, rgba(180, 180, 180, 0.9), rgba(140, 140, 140, 0.8))",
    backdropFilter: "blur(14px)",
    border: "1px solid rgba(0, 0, 0, 0.1)",
    opacity: 1,
    transition: theme.transitions.create(
      ["background", "box-shadow", "border"],
      {
        duration: 500,
      }
    ),

    "&::before, &::after": {
      content: '""',
      position: "absolute",
      top: "50%",
      transform: "translateY(-50%)",
      width: 12,
      height: 12,
    },
    "&::before": {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="white" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      left: 6,
    },
    "&::after": {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="white" d="M19,13H5V11H19V13Z"/></svg>')`,
      right: 6,
    },
  },
}));

const CustomSwitch = (props) => {
  return <CustomSwitchButton {...props} />;
};

export default CustomSwitch;
