/* eslint-disable no-unused-vars */

import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  Box,
  Typography,
  Stack,
  Checkbox,
  TablePagination,
} from "@mui/material";
import {
  // Search as SearchIcon,
  Visibility as ViewIcon,
  // Edit as EditIcon,
  // Delete as DeleteIcon,
  History as HistoryIcon,
  VpnKey as KeyIcon,
  // Add as PlusIcon,
  // GetApp as DownloadIcon,
  AddCircleOutlineOutlined,
  DeleteOutlineRounded,
} from "@mui/icons-material";
import MButtonPrimary from "../Button/MButtonPrimary";
import { EditOutlined } from "@ant-design/icons";
import Warning from "../../../assets/svg/FaultIcon/warning.svg";
import Major from "../../../assets/svg/FaultIcon/major.svg";
import Minor from "../../../assets/svg/FaultIcon/minor.svg";

const AlarmTable = ({
  tableTitle = "",
  columns,
  tableData = [],
  showSearch = false,
  AddText = "",
  handleAdd,
  handleDownload,
  handleView,
  handleEdit,
  handleDelete,
  handleHistory,
  handleChangePasswordClick,
  isTerminalDisabled,
  onOpen,
  addDisable,
  hideAdd = true,
}) => {
  const [page, setPage] = useState(0); // MUI Pagination component uses 1-based index
  const [rowsPerPage, setRowsPerPage] = useState(5);
  console.log(tableData, "tableData");

  // Mapping for severities and workflows
  const severityColorMap = [
    {
      1: {
        // src: <NormalSvg />,
        src: <img src={Minor} alt="Minor" />,
        iconInfo: " Minor",
        color: "grey",
      },
    },
    {
      2: {
        // src: <NormalSvg />,
        src: <Major />,
        iconInfo: " Major",
        color: "grey",
      },
    },
    {
      0: {
        // src: <NormalSvg />,
        src: <Warning />,
        iconInfo: " Warning",
        color: "grey",
      },
    },
  ];


  const workflowMap = {
    1: "ACK",
    0: "NOT_ACK",
  };

  // Search Logic
  //   const filteredItems = useMemo(() => {
  //     return tableData.filter((item) =>
  //       Object.values(item).some((val) =>
  //         String(val).toLowerCase().includes(filterValue.toLowerCase())
  //       )
  //     );
  //   }, [filterValue, tableData]);

  //  const filteredItems = React.useMemo(() => {
  //        const start = (page - 1) * rowsPerPage;
  //        const end = start + rowsPerPage;

  //        return tableData?.slice(start, end);
  //      }, [page, tableData, rowsPerPage]);

  //   // Pagination Logic
  //   const paginatedItems = useMemo(() => {
  //     const start = (page - 1) * rowsPerPage;
  //     return filteredItems.slice(start, start + rowsPerPage);
  //   }, [page, rowsPerPage, filteredItems]);

  // Action Cell Renderer (Direct Display)
  const renderActions = (row) => (
    <Stack direction="row" spacing={0.5} justifyContent="center">
      {handleView && (
        <Tooltip title="View">
          <IconButton size="small" onClick={() => handleView(row)}>
            <ViewIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {handleEdit && (
        <Tooltip title="Edit">
          {/* <IconButton
            color="#fa9b53"
            backgroundColor="#FFD8BF"
            onClick={() => handleEdit(row)}
          >
            <EditIcon fontSize="small" />
          </IconButton> */}

          <EditOutlined
            style={{
              color: "#fa9b53",
              backgroundColor: "#FFD8BF",
              padding: "2px 2px",
              fontSize: "25px",
              borderRadius: "5px",
              cursor: "pointer",
            }}
            onClick={() => handleEdit(row)}
          />
        </Tooltip>
      )}
      {handleHistory && (
        <Tooltip title="History">
          <IconButton size="small" onClick={() => handleHistory(row)}>
            <HistoryIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {handleChangePasswordClick && (
        <Tooltip title="Change Password">
          <IconButton
            size="small"
            onClick={() => handleChangePasswordClick(row)}
          >
            <KeyIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {handleDelete && (
        <Tooltip title="Delete">
          {/* <IconButton
            size="small"
            color="error"
            onClick={() => handleDelete(row)}
          >
            <DeleteIcon fontSize="small" />
          </IconButton> */}

          <DeleteOutlineRounded
            style={{
              color: "#ff5757",
              backgroundColor: "#FFD8BF",
              height: "30px",
              fontSize: "20px",
              width: "28px",
              borderRadius: "5px",
              cursor: "pointer",
              padding: "3px 2px",
            }}
            onClick={() => handleDelete(row)}
          />
        </Tooltip>
      )}
    </Stack>
  );
  const renderCellValue = (col, row) => {
    if (col.uid === "severity") {
      const severityLevel = parseInt(row.severity);
      const severityIconData = severityColorMap.find(
        (obj) => Object.keys(obj)[0] == severityLevel
      );
      console.log(severityIconData, "severityIconData");
      if (!severityIconData) {
        return <div>Unknown Severity</div>;
      }
      const severityData = severityIconData[severityLevel];
      return (
        <div style={{ display: "flex", alignItems: "center" }}>
          <div>
            {severityData.iconInfo}
          </div>
        </div>
      );
    }
    if (col.uid === "workflow") {
      return workflowMap[row[col.uid]] || "Unknown";
    }
    return row[col.uid];
  };

  const handleChangePage = (event, newPage) => {
    console.log(newPage, "newPage");
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    const newRowsPerPage = Number(event.target.value);
    console.log(newRowsPerPage, "newRowsPerPage");
    setRowsPerPage(newRowsPerPage);
    setPage(1);
  };

  const visibleRows = React.useMemo(() => {
    const start = page * rowsPerPage;
    const end = start + rowsPerPage;

    //  console.log();

    return tableData.slice(start, end);
  }, [rowsPerPage, page, tableData]);

  return (
    <Box sx={{ width: "100%" }}>
      {/* Table Header Section */}

      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          p: 2,
          alignItems: "center",
        }}
      >
        <Typography
          variant="subtitle1"
          sx={{
            fontWeight: "regular",
            color: "#14348D",
            fontFamily: "Inter",
          }}
        >
          {tableTitle}
        </Typography>

        {!hideAdd && (
          <MButtonPrimary
            onClick={handleAdd}
            disabled={addDisable} // Applies the disabled state
            sx={{
              // Visual feedback for the disabled state
              "&.Mui-disabled": {
                backgroundColor: "rgba(0, 0, 0, 0.12)",
                color: "rgba(0, 0, 0, 0.26)",
                cursor: "not-allowed",
              },
            }}
          >
            <AddCircleOutlineOutlined sx={{ mr: 1, fontSize: "20px" }} />
            {AddText}
          </MButtonPrimary>
        )}
      </Box>

      {/* Table Content */}
      <TableContainer
        component={Paper}
        sx={{
          border: "1px solid #D5E0FF",
          boxShadow: "none",
          color: "#14348D",
        }}
      >
        <Table size="small">
          <TableHead sx={{ color: "#14348D" }}>
            <TableRow sx={{ bgcolor: "#D5E0FF" }}>
              <TableCell
                sx={{
                  borderRight: "1px solid #bcbcbc",
                  color: "#14348D",
                  width: "50px",
                }}
              >
                {" "}
                {/* Added width */}
                Select
              </TableCell>
              {columns.map((col) => (
                <TableCell
                  key={col.uid}
                  sx={{ borderRight: "1px solid #bcbcbc", color: "#14348D" }}
                >
                  {col.name}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {visibleRows.length > 0 ? (
              visibleRows.map((row, index) => (
                <TableRow key={row.id || index} hover>
                  <TableCell
                    sx={{
                      borderRight: "1px solid #bcbcbc",
                      borderBottom: "1px solid #bcbcbc",
                      width: "50px",
                    }}
                  >
                    {" "}
                    {/* Added width */}
                    <Checkbox
                      color="primary"
                      value={row.selected} // example attribute
                      // onChange={(event) => handleRowSelect(row, event)}
                    />
                  </TableCell>
                  {columns.map((col) => (
                    <TableCell
                      key={col.uid}
                      sx={{
                        borderRight: "1px solid #bcbcbc",
                        borderBottom: "1px solid #bcbcbc",
                      }}
                    >
                      {col.uid === "actions"
                        ? renderActions(row)
                        : renderCellValue(col, row)}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              /* Empty State Row */
              <TableRow>
                <TableCell colSpan={columns.length + 1} align="center">
                  {" "}
                  {/* Adjusted colSpan */}
                  <Box sx={{ textAlign: "center" }}>
                    <Typography component="p">No records found</Typography>
                  </Box>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[5, 10, 15]}
        component="div"
        count={tableData.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />

      {/* // Example handler function
const handleRowSelect = (row, event) => {
  // Implement your row selection logic here
  //For example: updating row.selected to the checked state.
  row.selected = event.target.checked;
  //Then you can update your tableData array using react state.
} */}
    </Box>
  );
};
export default AlarmTable;
