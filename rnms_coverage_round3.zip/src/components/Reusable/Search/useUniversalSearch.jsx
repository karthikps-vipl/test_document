// import React, { useMemo } from "react";

 
// const flattenValue = (
//   value,
//   {
//     depth = 0,
//     maxDepth = 10,
//     visited = new WeakSet(),
//     skipKeys = [],
//   } = {}
// ) => {
//   if (value === null || value === undefined) {
//     return "";
//   }

//   // Prevent infinitely deep objects
//   if (depth > maxDepth) {
//     return "";
//   }

//   // Primitive values
//   if (
//     typeof value === "string" ||
//     typeof value === "number" ||
//     typeof value === "boolean" ||
//     typeof value === "bigint"
//   ) {
//     return String(value);
//   }

//   // Date
//   if (value instanceof Date) {
//     return `${value.toString()} ${value.toISOString()}`;
//   }

//   // Don't search React elements
//   if (React.isValidElement(value)) {
//     return "";
//   }

//   // Don't search DOM nodes
//   if (
//     typeof HTMLElement !== "undefined" &&
//     value instanceof HTMLElement
//   ) {
//     return "";
//   }

//   // Prevent circular references
//   if (typeof value === "object") {
//     if (visited.has(value)) {
//       return "";
//     }

//     visited.add(value);
//   }

//   Array
//   if (Array.isArray(value)) {
//     return value
//       .map((item) =>
//         flattenValue(item, {
//           depth: depth + 1,
//           maxDepth,
//           visited,
//           skipKeys,
//         })
//       )
//       .join(" ");
//   }

//   // Object
//   if (typeof value === "object") {
//     return Object.entries(value)
//       .filter(([key]) => !skipKeys.includes(key))
//       .filter(([key]) => !key.startsWith("_"))
//       .map(([key, val]) => {
//         return `${key} ${flattenValue(val, {
//           depth: depth + 1,
//           maxDepth,
//           visited,
//           skipKeys,
//         })}`;
//       })
//       .join(" ");
//   }

//   return String(value);
// };


// /**
//  * Creates one big searchable string from a complete row.
//  */
// export const createSearchableText = (
//   row,
//   {
//     maxDepth = 10,
//     skipKeys = [],
//   } = {}
// ) => {
//   if (!row) {
//     return "";
//   }

//   return flattenValue(row, {
//     maxDepth,
//     skipKeys,
//   })
//     .toLowerCase()
//     .normalize("NFKC");
// };


// /**
//  * Universal search.
//  *
//  * Examples:
//  *
//  * search "switch"
//  * search "SWITCH"
//  * search "Switch"
//  *
//  * all work.
//  *
//  * search "123"
//  * will find number 123.
//  *
//  * search "true"
//  * will find boolean true.
//  *
//  * search "switch 123"
//  * requires BOTH values to exist somewhere in the row.
//  */
// export const universalSearch = (
//   rows = [],
//   searchValue = "",
//   options = {}
// ) => {
//   const query = String(searchValue ?? "")
//     .toLowerCase()
//     .normalize("NFKC")
//     .trim();

//   // No search -> return everything
//   if (!query) {
//     return rows;
//   }

//   // Split search into words
//   const tokens = query
//     .split(/\s+/)
//     .map((token) => token.trim())
//     .filter(Boolean);

//   return rows.filter((row) => {
//     const searchableText = createSearchableText(
//       row,
//       options
//     );

//     // Every typed word must exist somewhere in the row
//     return tokens.every((token) =>
//       searchableText.includes(token)
//     );
//   });
// };


// /**
//  * React hook version.
//  */
// export const useUniversalSearch = (
//   data = [],
//   searchValue = "",
//   options = {}
// ) => {
//   const {
//     maxDepth = 10,
//     skipKeys = [],
//   } = options;

//   return useMemo(() => {
//     return universalSearch(
//       data,
//       searchValue,
//       {
//         maxDepth,
//         skipKeys,
//       }
//     );
//   }, [
//     data,
//     searchValue,
//     maxDepth,
//     JSON.stringify(skipKeys),
//   ]);
// };

// export default useUniversalSearch;
import { useMemo } from "react";

const normalize = (value) =>
  String(value ?? "")
    .toLowerCase()
    .normalize("NFKC");

export const universalSearch = (
  rows = [],
  searchValue = "",
  columns = []
) => {
  const query = normalize(searchValue).trim();

  if (!query) {
    return rows;
  }

  const tokens = query.split(/\s+/).filter(Boolean);

  return rows.filter((row) => {
    // ONLY values of table columns
    const searchableText = columns
      .map((column) => {
        const value = row?.[column.uid];

        // Don't recursively search objects/arrays
        if (
          value !== null &&
          typeof value === "object"
        ) {
          return "";
        }

        return normalize(value);
      })
      .join(" ");

    // Every search word must exist in the table cells
    return tokens.every((token) =>
      searchableText.includes(token)
    );
  });
};

export const useUniversalSearch = (
  data = [],
  searchValue = "",
  columns = []
) => {
  return useMemo(
    () =>
      universalSearch(
        data,
        searchValue,
        columns
      ),
    [data, searchValue, columns]
  );
};

export default useUniversalSearch;