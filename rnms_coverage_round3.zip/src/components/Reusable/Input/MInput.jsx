/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Input 
   File Name                : MInput.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Input\MInput.jsx
   Purpose                  : A standardized, reusable wrapper for Material UI text fields 
                               to ensure UI consistency and simplified input handling.
   Created Date             : 16-03-2026
 ***********************************************************************************************/

// import React from "react";
// import { TextField, Typography, Box, useTheme } from "@mui/material";
// const MInput = ({
//   label,
//   value,
//   onChange,
//   error = false,
//   helperText = "",
//   placeholder = "",
//   type = "text",
//   // Accept both startIcon and startAdornment for flexibility
//   startIcon,
//   startAdornment,
//   endIcon,
//   fullWidth = true,
//   variant = "outlined",
//   size = "small",
//   errorMessage = "",
//   disabled = false,
//   onInput,
//   imageSrc,
//   readOnly = false,
//   InputProps: customInputProps,
//   showUnit = false,
//   unit = "",
//   ...props
// }) => {
//   const theme = useTheme();

//   // 1. Determine which start icon to use
//   const finalStartAdornment = startAdornment || startIcon;
//   const finalEndAdornment = endIcon || (customInputProps?.endAdornment || null);

//   // 2. Construct the InputProps object
//   const inputProps = {
//     ...customInputProps,
//     readOnly: readOnly,
//     startAdornment: finalStartAdornment ? (
//       <Box sx={{ display: 'flex', alignItems: 'center', mr: 1 }}>
//         {finalStartAdornment}
//       </Box>
//     ) : null,
//     endAdornment: finalEndAdornment ? (
//       <Box sx={{ display: 'flex', alignItems: 'center', ml: 1 }}>
//         {finalEndAdornment}
//       </Box>
//     ) : null,
//   };

//   return (
//     <Box sx={{ position: "relative", display: "inline-block" }}>
//       <TextField
//         fullWidth={fullWidth}
//         variant={variant}
//         size={size}
//         label=""
//         type={type}
//         value={value}
//         onChange={onChange}
//         error={error}
//         helperText={helperText}
//         placeholder={placeholder}
//         disabled={disabled}
//         InputProps={inputProps}
//         sx={{
//           "& .MuiOutlinedInput-root": {
//             borderRadius: "8px",
//             backgroundColor: disabled
//               ? (theme) => theme.palette.mode === 'dark' ? "#333" : "#eee"
//               : (props.sx?.backgroundColor || "transparent"),

//             // 1. TARGET THE PLACEHOLDER
//             "& .MuiInputBase-input::placeholder": {
//                fontSize: "0.85rem",
//               opacity: 1,
//               color: (theme) =>
//                 theme.palette.mode === 'dark' ? '#666666' : '#9e9e9e',
//             },

//             // 2. TARGET THE INPUT TEXT
//             "& .MuiInputBase-input": {
//               cursor: readOnly ? "default" : (disabled ? "not-allowed" : "text"),
//               color: (theme) => {
//                 if (disabled) return theme.palette.mode === 'dark' ? "rgba(255, 255, 255, 0.38)" : "#666";
//                 return theme.palette.mode === 'dark' ? "#ffffff" : "inherit";
//               },
//               WebkitTextFillColor: (theme) => {
//                 if (disabled) return theme.palette.mode === 'dark' ? "rgba(255, 255, 255, 0.38)" : "#666";
//                 return theme.palette.mode === 'dark' ? "#ffffff" : "initial";
//               },
//             },

//             // 3. BORDER LOGIC
//             "& .MuiOutlinedInput-notchedOutline": {
//               borderColor: (theme) =>
//                 theme.palette.mode === 'dark' ? "rgba(255, 255, 255, 0.23)" : "rgba(0, 0, 0, 0.23)",
//             },

//             // 4. HOVER STATE
//             "&:hover .MuiOutlinedInput-notchedOutline": {
//               borderColor: (theme) =>
//                 theme.palette.mode === 'dark' ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.87)",
//             },

//             // 5. FOCUS STATE
//             "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
//               borderColor: (theme) =>
//                 theme.palette.mode === 'dark' ? "#ffffff" : "#14138d",
//               borderWidth: "2px",
//             },

//             opacity: 1,
//           },
//           ...props.sx,
//         }}
//         onInput={onInput}
//       />
//       {errorMessage && (
//         <Typography
//           sx={{
//             color: "#e75656",
//             fontSize: "11.5px",
//             textAlign: "left",
//             position: "absolute",
//             top: "90%",
//             left: 0,
//             width: "100%",
//             padding: "4px 8px",
//             boxSizing: "border-box",
//           }}
//         >
//           {errorMessage}
//         </Typography>
//       )}
//     </Box>
//   );
// };

// export default MInput;
/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Input 
   File Name                : MInput.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Input\MInput.jsx
   Purpose                  : A standardized, reusable wrapper for Material UI text fields 
                               to ensure UI consistency and simplified input handling.
   Created Date             : 16-03-2026
 ***********************************************************************************************/

import React from "react";
import { TextField, Typography, Box } from "@mui/material";

const MInput = ({
  label,
  value,
  onChange,
  error = false,
  helperText = "",
  placeholder = "",
  type = "text",
  startIcon,
  endIcon,
  fullWidth = true,
  variant = "outlined",
  size = "small",
  errorMessage = "",
  disabled = false,
  onInput,
  imageSrc,
  readOnly = false,
  InputProps: customInputProps,
  showUnit = false,
  unit = "",
  sx = {},
  ...props
}) => {
  const { ref: inputRef, } = props;

  return (
    <Box sx={{ position: "relative", display: "inline-block", ...sx }}>
      {" "}
      {/* Container for TextField and error */}
      <TextField
        inputRef={inputRef}
        fullWidth={fullWidth}
        variant={variant}
        size={size}
        label=""
        type={type}
        // InputProps={InputProps}
        //  value={value}
        {...(value !== undefined ? { value } : {})}
        onChange={onChange}
        error={error}
        helperText={helperText}
        placeholder={placeholder}
        {...props}
        disabled={disabled}
        // This is the critical part for MUI:
        InputProps={{
          ...customInputProps,
          readOnly: readOnly,
          // FIX: Only use the unit/empty logic if endAdornment wasn't provided via props
          endAdornment: customInputProps?.endAdornment ? (
            customInputProps.endAdornment
          ) : showUnit ? (
            <Box>{unit}</Box>
          ) : null,
        }}
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "8px",
            backgroundColor: disabled
              ? (theme) => (theme.palette.mode === "dark" ? "#333" : "#eee")
              : props.sx?.backgroundColor || "transparent",

            // 1. TARGET THE PLACEHOLDER
            "& .MuiInputBase-input::placeholder": {
              fontSize: "0.85rem",
              opacity: 1, // Important: browsers often default placeholder opacity to 0.5
              color: (theme) =>
                theme.palette.mode === "dark" ? "#666666" : "#9e9e9e",
            },

            // 2. TARGET THE INPUT TEXT
            "& .MuiInputBase-input": {
              cursor: readOnly ? "default" : disabled ? "not-allowed" : "text",
              color: (theme) => {
                if (disabled)
                  return theme.palette.mode === "dark"
                    ? "rgba(255, 255, 255, 0.38)"
                    : "#666";
                return theme.palette.mode === "dark" ? "#ffffff" : "inherit";
              },
              WebkitTextFillColor: (theme) => {
                if (disabled)
                  return theme.palette.mode === "dark"
                    ? "rgba(255, 255, 255, 0.38)"
                    : "#666";
                return theme.palette.mode === "dark" ? "#ffffff" : "initial";
              },
            },

            // 3. BORDER LOGIC (Notched Outline)
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor: (theme) =>
                theme.palette.mode === "dark"
                  ? "rgba(255, 255, 255, 0.23)"
                  : "rgba(0, 0, 0, 0.23)",
            },

            // 4. HOVER STATE
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor: (theme) =>
                theme.palette.mode === "dark"
                  ? "rgba(255, 255, 255, 0.5)"
                  : "rgba(0, 0, 0, 0.87)",
            },

            // 5. FOCUS STATE
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: (theme) =>
                theme.palette.mode === "dark" ? "#ffffff" : "#14138d", // Use white in dark mode for visibility
              borderWidth: "2px",
            },

            opacity: 1,
          },
          ...props.sx,
        }}
        onInput={onInput}
      />
      {errorMessage && (
        <Typography
          sx={{
            color: "#e75656",
            fontSize: "11.5px",
            textAlign: "left",
            position: "absolute",
            top: "90%",
            left: 0,
            width: "100%",
            padding: "4px 8px",
            boxSizing: "border-box",
          }}
        >
          {errorMessage}
        </Typography>
      )}
    </Box>
  );
};

export default MInput;
