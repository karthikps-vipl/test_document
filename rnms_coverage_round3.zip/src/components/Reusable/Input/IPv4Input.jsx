import React from "react";
import { IMaskMixin } from "react-imask";
import { TextField } from "@mui/material";

// Partial IPv4 validation.
const validatePartialIPv4 = (value) => {
  const parts = value.split(".");

  if (parts.length > 4) return false;

  return parts.every((part) => {
    if (part.length > 3) return false;
    if (part === "00") return false;
    if (part !== "" && Number(part) > 255) return false;

    return /^\d*$/.test(part);
  });
};

// Complete IPv4 validation.
export const isValidIPv4 = (value) => {
  if (!value) return false;

  const parts = value.split(".");

  if (parts.length !== 4) return false;

  return parts.every((part) => {
    if (!/^\d{1,3}$/.test(part)) return false;
    if (part === "00") return false;

    return Number(part) >= 0 && Number(part) <= 255;
  });
};

// Automatic and manual dot handling.
const prepareIPv4 = (input, masked) => {
  let result = "";
  let current = masked.value || "";

  for (const char of input) {
    if (/\d/.test(char)) {
      const parts = current.split(".");
      const lastPart = parts[parts.length - 1];

      if (parts.length > 4) continue;

      if (lastPart.length > 0 && Number(lastPart + char) > 255) {
        if (parts.length >= 4) continue;

        result += ".";
        current += ".";
      }

      const updatedParts = current.split(".");
      const updatedLast = updatedParts[updatedParts.length - 1];

      if (updatedLast.length >= 3) continue;

      const candidate = current + char;

      if (!validatePartialIPv4(candidate)) continue;

      result += char;
      current += char;

      const currentParts = current.split(".");
      const octet = currentParts[currentParts.length - 1];

      if (currentParts.length < 4 && (octet === "0" || octet.length === 3)) {
        result += ".";
        current += ".";
      }
    } else if (char === ".") {
      if (current.endsWith(".")) continue;
      if (current.split(".").length >= 4) continue;

      result += ".";
      current += ".";
    }
  }

  return result;
};

// MUI + IMask integration.
const MaskedIPv4TextField = IMaskMixin(({ inputRef, ...props }) => (
  <TextField {...props} inputRef={inputRef} />
));

const IPv4Input = ({
  value = "",
  onChange,
  disabled = false,
  readOnly = false,
  error = false,
  helperText = "",
  placeholder = "___.___.___.___",
  fullWidth = true,
  variant = "outlined",
  size = "small",
  sx = {},
  InputProps: customInputProps,
  ...props
}) => {
  return (
    <MaskedIPv4TextField
      {...props}
      mask={/^\d{0,3}(?:\.\d{0,3}){0,3}$/}
      prepare={prepareIPv4}
      validate={validatePartialIPv4}
      value={value}
      onAccept={(acceptedValue) => {
        onChange?.(acceptedValue);
      }}
      lazy
      overwrite={false}
      disabled={disabled}
      placeholder={placeholder}
      fullWidth={fullWidth}
      variant={variant}
      size={size}
      error={error}
      helperText={helperText}
      InputProps={{
        ...customInputProps,
        readOnly,
      }}
      sx={{
        "& .MuiOutlinedInput-root": {
          borderRadius: "8px",

          backgroundColor: disabled
            ? (theme) => (theme.palette.mode === "dark" ? "#333" : "#eee")
            : "transparent",

          "& .MuiInputBase-input::placeholder": {
            fontSize: "0.85rem",
            opacity: 1,
            color: (theme) =>
              theme.palette.mode === "dark" ? "#666666" : "#9e9e9e",
          },

          "& .MuiInputBase-input": {
            cursor: readOnly ? "default" : disabled ? "not-allowed" : "text",

            color: (theme) => {
              if (disabled) {
                return theme.palette.mode === "dark"
                  ? "rgba(255, 255, 255, 0.38)"
                  : "#666";
              }

              return theme.palette.mode === "dark" ? "#ffffff" : "inherit";
            },

            WebkitTextFillColor: (theme) => {
              if (disabled) {
                return theme.palette.mode === "dark"
                  ? "rgba(255, 255, 255, 0.38)"
                  : "#666";
              }

              return theme.palette.mode === "dark" ? "#ffffff" : "initial";
            },
          },

          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: (theme) =>
              theme.palette.mode === "dark"
                ? "rgba(255, 255, 255, 0.23)"
                : "rgba(0, 0, 0, 0.23)",
          },

          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: (theme) =>
              theme.palette.mode === "dark"
                ? "rgba(255, 255, 255, 0.5)"
                : "rgba(0, 0, 0, 0.87)",
          },

          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: (theme) =>
              theme.palette.mode === "dark" ? "#ffffff" : "#14138d",
            borderWidth: "2px",
          },

          opacity: 1,
        },

        ...sx,
      }}
    />
  );
};

export default IPv4Input;
