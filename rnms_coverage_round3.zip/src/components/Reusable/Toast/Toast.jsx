import { notification } from "antd";

/**
 * @param {'success' | 'info' | 'warning' | 'error'} type
 */
export const Toast = (title, message, type = "info") => {
  const bgColors = {
    success: "#008746",
    error: "#ff4d4f",
    warning: "#faad14",
    info: "#1890ff",
  };

  notification[type]({
    //title: <span style={{color: "#fff !important",fontWeight: 600 }}>{title}</span>,
    title: <div style={{ color: "#fff", fontWeight: 600 }}>{title}</div>,

    description: <div style={{ color: "#fff", opacity: 0.9 }}>{message}</div>,
    closable: true,
    duration: 3,
    placement: "bottomLeft", 
    //placement: "topRight",
    className: "custom-toast custom-toast-white-text",
    style: {
      backgroundColor: bgColors[type] || bgColors.info,
      borderRadius: "4px",
    },
  });
};

export default Toast;

