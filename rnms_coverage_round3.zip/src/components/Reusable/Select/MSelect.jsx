
import React from "react";
import { FormControl, Select, MenuItem, useTheme, Typography } from "@mui/material";

const MSelect = ({
  label,
  options = [],
  value,
  onChange,
  placeholder,
  getOptionLabel = (option) => option.label,
  getOptionValue = (option) => option.value,
  style = {},
  disabled
}) => {
  const theme = useTheme();

  const isTrulyEmpty = (val) => {
    return (
      val === null ||
      val === undefined ||
      val === "" ||
      (Array.isArray(val) && val.length === 0)
    );
  };

  const getSelectValue = () => {
    if (isTrulyEmpty(value)) return "";
    if (typeof value === "object" && value !== null) {
      return getOptionValue(value);
    }
    return value;
  };

  return (
    <FormControl style={style} fullWidth>
      <Typography
        sx={{
          fontSize: "16px",
          color: theme.palette.mode === "dark" ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
        }}
      >
        {label}
      </Typography>
      <Select
        displayEmpty
        value={getSelectValue()}
        disabled={disabled}
        sx={{
          borderRadius: "10px",
          height: "40px",
          ...style,
        }}
        onChange={(e) => {
          if (disabled) return; 
          const selectedValue = e.target.value;
          if (selectedValue === "") {
            onChange(null);
            return;
          }
          const selectedOption = options.find(
            (opt) => getOptionValue(opt) === selectedValue
          );
          onChange(selectedOption || selectedValue);
        }}
        renderValue={(selectedId) => {
          // 1. Handle Placeholder Case
          if (selectedId === "") {
            return (
              <span style={{ color: "#aaa", fontSize: "14.5px" }}>
                {placeholder}
              </span>
            );
          }

          // 2. Get the Label text
          const option = options.find(
            (opt) => getOptionValue(opt) === selectedId
          );
          const labelText = option ? getOptionLabel(option) : "";

          // 3. Truncation Logic
          const MAX_LENGTH = 36; // Set your preferred character limit here

          if (labelText.length > MAX_LENGTH) {
            return (
              <Typography noWrap sx={{ fontSize: "14.5px" }}>
                {labelText.substring(0, MAX_LENGTH - 3)}...
              </Typography>
            );
          }

          // 4. Return full text if within limit
          return (
            <Typography noWrap sx={{ fontSize: "14.5px" }}>
              {labelText}
            </Typography>
          );
        }}
      >
        <MenuItem value="" disabled>
          <span style={{ fontSize: "14.5px" }}>{placeholder}</span>
        </MenuItem>
        {options.map((option) => {
          const optionVal = getOptionValue(option);
          const isDisabled = option.disabled === true;
          return (
            <MenuItem
              key={option.id || optionVal}
              value={optionVal}
              disabled={isDisabled}
              sx={{
                "&.Mui-disabled": {
                  color: "#9e9e9e",
                  opacity: 0.6,
                },
              }}
            >
              {getOptionLabel(option)}
            </MenuItem>
          );
        })}
      </Select>
    </FormControl>
  );
};

export default MSelect;