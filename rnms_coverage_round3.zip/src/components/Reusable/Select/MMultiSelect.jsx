 


 
 
 import MInput from "../Input/MInput";
import React, { useState } from "react";
import {
  Select,
  MenuItem,
  Checkbox,
  ListItemText,
  Typography,
  Box,
  useTheme,
} from "@mui/material";
import { Search } from "@mui/icons-material";

  
 

const MMultiSelect = ({
  options = [],
  value = [],
  onChange,
  placeholder,
  isCompact = false,
}) => {
  const [search, setSearch] = useState("");
  const theme = useTheme();

  const safeOptions = options.filter(
    (opt) =>
      opt &&
      opt.label !== undefined &&
      opt.value !== undefined
  );

  const filteredOptions = safeOptions.filter((opt) =>
    String(opt.label)
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  const isAllSelected =
    safeOptions.length > 0 &&
    safeOptions.every((opt) => value.includes(opt.value));

  const handleSelectChange = (event) => {
    const incomingValue = event.target.value;

    if (incomingValue.includes("all")) {
      if (isAllSelected) {
        onChange([]);
      } else {
        onChange(safeOptions.map((opt) => opt.value));
      }
      return;
    }

    onChange(incomingValue);
  };

  const handleClose = () => {
    setSearch("");
  };

  const fontSx = isCompact ? "0.9rem" : "0.98rem";
  const paddingSx = isCompact ? "2px 8px" : "4px 12px";
  const heightSx = isCompact ? "36px" : "46px";
  const minW = isCompact ? 140 : 240;

  return (
    <Select
      multiple
      displayEmpty
      value={value}
      onChange={handleSelectChange}
      onClose={handleClose}
      renderValue={(selected) => {
        if (selected.length === 0) {
          return (
            <span style={{ color: "#aaa" }}>
              {placeholder}
            </span>
          );
        }

        const labels = selected
          .map(
            (v) =>
              safeOptions.find((o) => o.value === v)?.label
          )
          .filter(Boolean);

        const fullText = labels.join(", ");
        const MAX_LENGTH = isCompact ? 15 : 49;

        return (
          <Typography
            noWrap
            sx={{ fontSize: "0.87rem" }}
          >
            {fullText.length > MAX_LENGTH
              ? `${fullText.substring(0, MAX_LENGTH - 3)}...`
              : fullText}
          </Typography>
        );
      }}
      sx={{
        borderRadius: "10px",
        height: heightSx,
        fontSize: fontSx,
        minWidth: `${minW}px`,
        maxWidth: "100%",

        "& .MuiSelect-select": {
          display: "flex",
          alignItems: "center",
          boxSizing: "border-box",
          padding: paddingSx,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        },
      }}
      MenuProps={{
        autoFocus: false,
        PaperProps: {
          style: {
            maxHeight: 300,
          },
        },
      }}
    >
      {/* SEARCH */}
      <Box
        onKeyDown={(e) => e.stopPropagation()}
        sx={{
          p: 1,
          bgcolor: theme.palette.background.paper,
        }}
      >
        <MInput
          autoFocus
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onClick={(e) => e.stopPropagation()}
          startAdornment={<Search />}
          sx={{
            "& .MuiInputBase-root": {
              fontSize: "0.9rem",
            },
          }}
        />
      </Box>

      {/* SELECT ALL */}
      <MenuItem
        value="all"
        sx={{
          px: isCompact ? 0.5 : 3,
          minHeight: isCompact ? "28px" : "33px",
          fontSize: fontSx,
          fontWeight: "bold",
        }}
      >
        <Checkbox
          checked={isAllSelected}
          size={isCompact ? "small" : "medium"}
        />

        <Typography
          variant="body2"
          sx={{ fontWeight: "bold" }}
        >
          Select All
        </Typography>
      </MenuItem>

      {/* OPTIONS */}
      {filteredOptions.map((opt) => (
        <MenuItem
          key={opt.value}
          value={opt.value}
          sx={{
            px: isCompact ? 0.5 : 3,
            minHeight: isCompact ? "28px" : "32px",
            fontSize: fontSx,
          }}
        >
          <Checkbox
            checked={value.includes(opt.value)}
            size={isCompact ? "small" : "medium"}
          />

          <ListItemText
            primary={opt.label}
            primaryTypographyProps={{
              fontSize: fontSx,
            }}
          />
        </MenuItem>
      ))}

      {filteredOptions.length === 0 && (
        <MenuItem
          disabled
          sx={{
            py: 0,
            minHeight: isCompact ? "28px" : "32px",
          }}
        >
          <ListItemText primary="No results" />
        </MenuItem>
      )}
    </Select>
  );
};

export default MMultiSelect;