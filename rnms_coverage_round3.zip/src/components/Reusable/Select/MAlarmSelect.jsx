import React, { useState } from "react";
import { Done } from "@mui/icons-material";
import {
  Box,
  Checkbox,
  Divider,
  FormControl,
  ListItemText,
  MenuItem,
  TextField,
  Typography,
  Select,
} from "@mui/material";

const MAlarmSelect = ({
  options = [],
  value,
  onChange,
  label,
  multiple = true,
  disabled = false,
  isDark = false,
}) => {
  const [search, setSearch] = useState("");
  const selectColors = {
    bg: isDark ? "#252525" : "#ffffff",
    text: isDark ? "#f3f4f6" : "#1f2937",
    border: isDark ? "#555555" : "#c4c4c4",
    placeholder: isDark ? "#9ca3af" : "#aaaaaa",
    hover: isDark ? "#333333" : "#f5f5f5",
    divider: isDark ? "#444444" : "#e0e0e0",
    paper: isDark ? "#202020" : "#ffffff",
  };
  // Ensure value defaults to a clean structural state depending on selection mode
  const selectionValue = multiple
    ? Array.isArray(value)
      ? value
      : []
    : Array.isArray(value)
    ? value[0] || ""
    : value || "";

  const filteredOptions = options.filter((item) =>
    String(item.label || "")
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  const handleMuiSelectChange = (event) => {
    const newValue = event.target.value;
    // For single select, MUI returns a string/number. For multiple, it returns an array.
    onChange(newValue);
  };

  const filteredValues = filteredOptions.map((item) => item.value);

  const isAllSelected =
    multiple &&
    filteredValues.length > 0 &&
    filteredValues.every((v) => selectionValue.includes(v));

  const isIndeterminate =
    multiple &&
    filteredValues.length > 0 &&
    !isAllSelected &&
    filteredValues.some((v) => selectionValue.includes(v));

  const handleSelectAll = (e) => {
    e.stopPropagation();
    if (!multiple) return;

    if (isAllSelected) {
      onChange(selectionValue.filter((v) => !filteredValues.includes(v)));
    } else {
      const uniqueCombined = Array.from(
        new Set([...selectionValue, ...filteredValues])
      );
      onChange(uniqueCombined);
    }
  };

  const checkboxIcons = {
    icon: (
      <Box
        sx={{
          width: 18,
          height: 18,
          bgcolor: "white",
          borderRadius: "2px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "2px solid #c4c4c4",
          marginLeft: "8px",
        }}
      />
    ),
    checkedIcon: (
      <Box
        sx={{
          width: 18,
          height: 18,
          bgcolor: "white",
          borderRadius: "2px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "2px solid #14348D",
          marginLeft: "8px",
        }}
      >
        <Done sx={{ color: "#14348D", width: 18, fontWeight: 900 }} />
      </Box>
    ),
    indeterminateIcon: (
      <Box
        sx={{
          width: 18,
          height: 18,
          bgcolor: "white",
          borderRadius: "2px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "2px solid #14348D",
          marginLeft: "8px",
        }}
      >
        <Box sx={{ width: 12, height: 2, bgcolor: "#14348D" }} />
      </Box>
    ),
  };

  return (
    <FormControl fullWidth>
      <Typography sx={{ mb: 0.3, fontSize: "14px", fontWeight: 500 }}>
        {label}
      </Typography>

      <Select
        disabled={disabled}
        multiple={multiple}
        value={selectionValue}
        onChange={handleMuiSelectChange}
        displayEmpty
        renderValue={(selected) => {
          let textToShow = "";

          if (multiple) {
            if (!selected || selected.length === 0) {
              return (
                <span style={{ color: selectColors.placeholder }}>
                  Select Options...
                </span>
              );
            }
            textToShow = options
              .filter((opt) => selected.includes(opt.value))
              .map((opt) => opt.label)
              .join(", ");
          } else {
            if (!selected) {
              return <span style={{ color: "#aaa" }}>Select Option...</span>;
            }
            const singleItem = options.find((opt) => opt.value === selected);
            textToShow = singleItem ? singleItem.label : selected;
          }

          return (
            <Box
              component="span"
              sx={{
                display: "block",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                maxWidth: "200px",
                width: "100%",
              }}
              title={textToShow}
            >
              {textToShow}
            </Box>
          );
        }}
        // sx={{
        //   borderRadius: "10px",
        //   height: "38px",
        //   width: "100%",
        //   "& .MuiSelect-select": {
        //     display: "flex",
        //     alignItems: "center",
        //     overflow: "hidden",
        //     width: "100%",
        //   },
        // }}
        sx={{
          borderRadius: "10px",
          height: "38px",
          width: "100%",
          backgroundColor: selectColors.bg,
          color: selectColors.text,
        
          "& .MuiSelect-select": {
            display: "flex",
            alignItems: "center",
            overflow: "hidden",
            width: "100%",
          },
        
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: selectColors.border,
          },
        
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: selectColors.border,
          },
        
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: isDark ? "#90a4ff" : "#14348D",
          },
        
          "& .MuiSvgIcon-root": {
            color: selectColors.text,
          },
        }}
        // MenuProps={{
        //   sx: {
        //     zIndex: 2600,
        //   },
        //   PaperProps: { style: { maxHeight: 250, width: 260 } },
        // }}
        MenuProps={{
          sx: {
            zIndex: 2600,
        
            "& .MuiPaper-root": {
              backgroundColor: selectColors.paper,
              color: selectColors.text,
              border: `1px solid ${selectColors.divider}`,
            },
        
            "& .MuiMenuItem-root": {
              color: selectColors.text,
        
              "&:hover": {
                backgroundColor: selectColors.hover,
              },
            },
          },
        
          PaperProps: {
            style: {
              maxHeight: 250,
              width: 260,
              backgroundColor: selectColors.paper,
            },
          },
        }}
        
      >
        {/* Sticky Search Header */}
        <Box
          sx={{
            p: 1,
            position: "sticky",
            top: 0,
            bgcolor: "background.paper",
            zIndex: 1,
          }}
          onKeyDown={(e) => e.stopPropagation()}
        >
          <TextField
            size="small"
            placeholder="Type here..."
            fullWidth
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onClick={(e) => e.stopPropagation()}
            sx={{
              "& .MuiOutlinedInput-root": {
                backgroundColor: selectColors.bg,
                color: selectColors.text,
            
                "& fieldset": {
                  borderColor: selectColors.border,
                },
            
                "&:hover fieldset": {
                  borderColor: selectColors.border,
                },
            
                "&.Mui-focused fieldset": {
                  borderColor: isDark ? "#90a4ff" : "#14348D",
                },
              },
            
              "& .MuiInputBase-input::placeholder": {
                color: selectColors.placeholder,
                opacity: 1,
              },
            }}
          />
        </Box>
        <Divider />

        {/* Select All Row */}
        {multiple && (
          <>
            <MenuItem
              onClick={handleSelectAll}
              sx={{ p: 0, minHeight: "34px", mt: 1 }}
            >
              <Checkbox
                checked={isAllSelected}
                indeterminate={isIndeterminate}
                disableRipple
                {...checkboxIcons}
                sx={{ padding: 0 }}
              />
              <ListItemText primary="Select All" sx={{ ml: 1 }} />
            </MenuItem>
            <Divider />
          </>
        )}

        {/* Options List */}
        {filteredOptions.map((item) => {
          const isSelected = multiple
            ? selectionValue.includes(item.value)
            : selectionValue === item.value;

          return (
            <MenuItem
              key={item.value}
              value={item.value}
              disabled={item.disabled} //disabled for selected oid usage
              sx={{
                p: 0,
                mb: 0.5,
                minHeight: "34px",
                opacity: item.disabled ? 0.4 : 1,
              }}
            >
              {multiple && (
                <Checkbox
                  checked={isSelected}
                  disableRipple
                  disabled={item.disabled} //disabled for selected oid usage
                  {...checkboxIcons}
                  sx={{ padding: 0 }}
                />
              )}
              <ListItemText
                // primary={item.label}
                primary={`${item.label}${
                  item.disabled ? " (Already Used)" : ""
                }`}
                sx={{ ml: multiple ? 1 : 2 }}
              />
            </MenuItem>
          );
        })}

        {filteredOptions.length === 0 && (
          <MenuItem disabled sx={{ py: 1, minHeight: "34px" }}>
            <ListItemText primary="No results found" />
          </MenuItem>
        )}
      </Select>
    </FormControl>
  );
};

export default MAlarmSelect;
