import React from 'react';
import {
  Box,
  IconButton,
  Tooltip,
  styled,
} from '@mui/material';
import {
  Close as CloseIcon,
  FullscreenExit,
  Fullscreen as FullscreenIcon,
} from '@mui/icons-material';

// --- Styles (Reusable) ---
const SquareIconButton = styled(IconButton)(({ theme }) => ({
  // Light mode: light blue | Dark mode: dark blue/grey
  backgroundColor: theme.palette.mode === 'light' ? "#D7EEFF" : "#3e3b3b",
  borderRadius: "20%",
  width: "30px",
  height: "30px",
  padding: "0",
  margin: "0",
  color: theme.palette.text.primary,
  "& .MuiIconButton-root": {
    borderRadius: "0",
  },
  "& .MuiIconButton-icon": {
    fontSize: "12px",
  },
  "&:hover": {
    backgroundColor: theme.palette.mode === "light" ? "#BEE3F8" : "#3D3D3D",
  },
}));

export const CustomeFullscreen= ({
  closeIconvisible = true,
  onToggleFullScreen,
  onClose,
  isFullScreen,
  fullscreenTooltipTitle,
  isFullScreenvisible = true,
  drawerWidthWhenFull = "100%",
  drawerWidthWhenClosed = "45%",
}) => {

  return (
    <Box
      className="flex gap-2 mr-2"
      sx={{
        // Optional: Ensure the box itself aligns correctly if needed
        justifyContent: 'center', 
      }}
    >
      {/* Fullscreen Toggle Button */}
      {isFullScreenvisible && (
      <Tooltip
        title={fullscreenTooltipTitle || (isFullScreen ? "Exit Full Screen" : "Enter Full Screen")}
        PopperProps={{
          style: { zIndex: 99999, position: 'fixed' },
        }}
        placement="top"
      >
        <SquareIconButton
          onClick={onToggleFullScreen}
          size="small" // Ensures icon scaling matches your style
        >
          {isFullScreen ? (
            <FullscreenExit size={20} />
          ) : (
            <FullscreenIcon size={20} />
          )}
        </SquareIconButton>
      </Tooltip>
      )}

      {/* Close Button */}
      {closeIconvisible && (
      <Tooltip title="Close">
        <Box sx={{ display: 'inline-flex', alignItems: 'center' }}>
          <SquareIconButton
            onClick={onClose}
            size="small"
          >
            <CloseIcon fontSize="small" />
          </SquareIconButton>
        </Box>
      </Tooltip>
      )}
    </Box>
  );
};
