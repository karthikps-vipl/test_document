import { useTheme } from '@mui/material/styles';
import { OverlayScrollbarsComponent } from "overlayscrollbars-react";
import "overlayscrollbars/overlayscrollbars.css";

export default function ScrollContainer({ children, className ,style}) {
  const theme = useTheme(); 
  const scrollbarColor = theme.palette.custom.icon.scrollcolor;
  return (
    
    <OverlayScrollbarsComponent
      defer
      className={className}
      options={{
        overflow: {
          x: "scroll",
          y: "scroll",
        },
        scrollbars: {
          autoHide: "never",
          autoHideDelay: 0,
          clickScroll: true,
          dragScroll: true,
          theme: "os-theme-dark",
        },
      }}
      style={{ 
        height: "100%", 
        ...style,
        // Inject your MUI primary color into CSS variables
        "--os-handle-color": scrollbarColor, 
       }}
    >
      {children}
    </OverlayScrollbarsComponent>
  );
}