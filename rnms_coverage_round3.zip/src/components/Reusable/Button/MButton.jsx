/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Button 
   File Name                : MButton.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Button\MButton.jsx
   Purpose                  : Reusable Material Button 
   Created Date             : 09-03-2026
 ***********************************************************************************************/

import { Button } from "@mui/material";
import React from "react";

const MButton = ({
  disabled = false,
  onClick,
  variant,
  startIcon,
  type = "primary",
  children,
}) => {
  return (
    <Button
      className={`${type === "primary" ? "primary-btn" : "secondary-btn"}`}
      variant={variant}
      onClick={onClick}
      disabled={disabled}
      startIcon={startIcon}
    >
      {children}
    </Button>
  );
};

export default MButton;
