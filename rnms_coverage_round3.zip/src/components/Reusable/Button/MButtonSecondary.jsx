/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Secondary Button 
   File Name                : MButtonSecondary.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Button\MButtonSecondary.jsx
   Purpose                  : A reusable secondary button component used to differentiate non-primary actions from the main primary buttons in the UI.
   Created Date             : 16-04-2026
 ***********************************************************************************************/

import { Button, Tooltip, useTheme } from "@mui/material";
import React from "react";
import { useSelector } from "react-redux";

const MButtonSecondary = ({
  disabled = false,
  onClick,
  variant,
  style,
  toolTipText = "",
  children,
}) => {

  const { isReadOnlyMode, isUserLoggedIn } = useSelector(
    (state) => state.userSlice
  );

  const isDisabled =
    disabled || (isUserLoggedIn && isReadOnlyMode);
  const theme = useTheme();
  return (
    <Tooltip title={toolTipText}>
      <Button
        variant={variant}
        sx={{
          display: "flex",
          borderRadius: "10px",
          border: theme.palette.mode === "dark" ? "1px solid #ffffff" : "1px solid #14348d",
          fontFamily: "Montserrat",
          fontWeight: "Medium",
          color: "text.TitleTextcolor",

          textTransform: "none",
          ...style,
        }}
        onClick={onClick}
        // disabled={disabled}
        disabled={isDisabled}
      >
        {children}
      </Button>
    </Tooltip>
  );
};

export default MButtonSecondary;
