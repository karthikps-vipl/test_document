/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Button 
   File Name                : MButtonPrimary.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Button\MButtonPrimary.jsx
   Purpose                  : Reusable Material Button  
   Created Date             : 11-03-2026
 ***********************************************************************************************/

import { Button } from "@mui/material";
import React from "react";
import { useSelector } from "react-redux";

const MButtonPrimary = ({
  disabled = false,
  onClick,
  variant,
  style,
  startIcon,
  children,
  ...props
}) => {
  const { isReadOnlyMode, isUserLoggedIn } = useSelector(
    (state) => state.userSlice
  );
  const isDisabled =
    disabled || (isUserLoggedIn && isReadOnlyMode);
  return (
    <Button
      variant={variant}
      {...props}
      sx={{
        display: "flex",
        borderRadius: "10px",
        backgroundColor: disabled ? "grey" : "#14348D",
        fontFamily: "Montserrat",
        fontWeight: "Medium",
        color: "white",
        px: "20px",
        textTransform: "none",
        ...style,
        "&.Mui-disabled": {
          backgroundColor: "#ccc",
          color: "#666"
        }
      }}
      onClick={onClick}
      // disabled={disabled}
      disabled={isDisabled}
      startIcon={startIcon}
    >
      {children}
    </Button>
  );
};

export default MButtonPrimary;
