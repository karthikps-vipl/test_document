
/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Loading Indicator
   File Name                : Loader.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Loader\Loader.jsx
   Purpose                  : A reusable component to display a loading state (spinner/overlay) 
                               to improve User Experience during background processes.
   Created Date             : 16-04-2026
 ***********************************************************************************************/import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
 
export default function Loader() {
  return (
    // <Box sx={{ display: "flex",position:'absolute',backgroundColor:'red' }}>
    // <Portal>
    <Box
      sx={{
        backgroundColor: "#15111182",
        zIndex: 110000,
        height: "100%",
        width: "100%",
        position: "fixed",
        left: 0,
        bottom: 0,
        right: 0,
        top: 0,
        display: "grid",
        placeItems: "center",
        // backdropFilter: "blur(5px)",
      }}
    >
      <CircularProgress style={{ color: "white" }}  />
      
    </Box>
    // {/* </Portal> */}
  );
}
