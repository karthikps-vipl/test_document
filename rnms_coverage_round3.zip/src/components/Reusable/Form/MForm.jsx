import React from "react";
import { Box, Typography, Divider } from "@mui/material";
import ScrollContainer from "../Scrollbar/ScrollContainer";

const MForm = ({ paddingX, title, children }) => {
  return (
    <ScrollContainer className="h-full">
      <Box
        sx={{
          border: "2px solid #eee",
          borderRadius: "10px",
          overflow: "hidden",
          mb: 3,
        }}
      >
        {/* Title Section */}
        <Box sx={{ px: paddingX ? paddingX : 4, pt: 2, pb: 1, height: "100%" }}>
          <Typography
            sx={{
              color: (theme) => theme.palette.custom.table.headerText,
              fontFamily: "Montserrat",
            }}
          >
            {title}
          </Typography>
        </Box>

        <Divider sx={{ borderBottomWidth: "2px", borderColor: "#eee" }} />

        {/* 
          Content Area: We REMOVE the hardcoded grid here. 
          We provide a container that children can use to define their own grid.
      */}
        <Box sx={{ p: 3, px: paddingX ? paddingX : 4 }}>{children}</Box>
      </Box>
    </ScrollContainer>
  );
};

export default MForm;
