import { Box, Typography } from "@mui/material";
import React from "react";
import MInput from "../Input/MInput";

// Change disabled = true TO disabled = false
const FormField = ({ label, required = false, disabled = false, error, errorMessage, ...inputProps }) => (
    <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
      <Typography sx={{ mb: 0.5, fontFamily: "Montserrat",  }}>
        {label} {required && <span>*</span>}
      </Typography>
      <MInput
        disabled={disabled}
        error={error} // This triggers the red border
        errorMessage={errorMessage} // This triggers the error text below the input
        {...inputProps}
      />
    </Box>
  );
export default FormField;