import React, { useEffect, useState } from "react";
import dayjs from "dayjs";
import { DateTimePicker as MuiDateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";

const DateTimePicker = ({
  open,
  onClose,
  onSubmit,
  onChange,
  value,
  disableFuture = true,
  disablePast = false,
  ampm = true,
  seconds = false,
}) => {
  const [selectedDate, setSelectedDate] = useState(
    value && dayjs(value).isValid() ? dayjs(value) : dayjs()
  );

  // Sync the picker whenever it opens or the parent value changes.
  useEffect(() => {
    if (open) {
      setSelectedDate(value && dayjs(value).isValid() ? dayjs(value) : dayjs());
    }
  }, [open, value]);

  const handleDateChange = (newDate) => {
    setSelectedDate(newDate);

    // Keep the existing callback compatible with JavaScript Date values.
    onChange?.(newDate && newDate.isValid() ? newDate.toDate() : null);
  };

  const handleAccept = (newDate) => {
    const dateToSubmit = newDate ?? selectedDate;

    if (dateToSubmit && dateToSubmit.isValid()) {
      onSubmit?.(dateToSubmit.toDate());
    }

    onClose?.();
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <MuiDateTimePicker
        open={open}
        value={selectedDate}
        onChange={handleDateChange}
        onAccept={handleAccept}
        onClose={onClose}
        disableFuture={disableFuture}
        disablePast={disablePast}
        ampm={ampm}
        views={
          seconds
            ? ["year", "month", "day", "hours", "minutes", "seconds"]
            : ["year", "month", "day", "hours", "minutes"]
        }
        viewRenderers={{
          hours: renderTimeViewClock,
          minutes: renderTimeViewClock,
          seconds: renderTimeViewClock,
        }}
        format={seconds ? "DD/MM/YYYY HH:mm:ss" : "DD/MM/YYYY HH:mm"}
        slotProps={{
          actionBar: {
            actions: ["cancel", "accept"],
          },
          textField: {
            size: "small",
            fullWidth: true,
          },
        }}
      />
    </LocalizationProvider>
  );
};

export default DateTimePicker;
