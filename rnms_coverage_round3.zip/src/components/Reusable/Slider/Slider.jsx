import React, { useState } from "react";
import Up_Arrow from "@/assets/SVGIcons/ALL_Reports_View.svg";
import { Close, FullscreenExit } from "@mui/icons-material";
import { Fullscreen } from "lucide-react";
import { Box, IconButton, Slide, Typography } from "@mui/material";

const Slider = ({ open, onClose,direction, children }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <Slide direction={direction} in={open} mountOnEnter unmountOnExit>
      <Box
        sx={{
          position: "fixed",
          top: 0,
          right: 0,
          width: isFullscreen ? "100vw" : "45vw",
          height: "100vh",
          bgcolor: "#fff",
          zIndex: 1400,
          boxShadow: "-4px 0 24px rgba(0,0,0,0.15)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          borderTopLeftRadius: isFullscreen ? "0px" : "40px",
          transition: "width 0.3s ease-in-out",
        }}
      >
        <Box
          sx={{
            bgcolor: "#F4F7FE",
            px: 3,
            py: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            borderBottom: "1px solid #e2e8f0",
          }}
        >
          <Typography
            variant="subtitle1"
            sx={{
              textAlign: "left",
              fontWeight: 600,
              color: "#14348D",
            }}
          >
            Reports
          </Typography>
          <IconButton
            onClick={onClose}
            size="medium"
            sx={{
              bgcolor: "#D7EEFF",
              "&:hover": { bgcolor: "#bde4ff" },
              // Only rounds the top-left and top-right corners
              borderTopLeftRadius: "16px",
              borderTopRightRadius: "16px",
              borderBottomLeftRadius: "0px",
              borderBottomRightRadius: "0px",
              px: 6,
              borderBottom: "none",
            }}
          >
            <img
              src={Up_Arrow}
              alt="Close"
              style={{ width: "24px", height: "24px", display: "block" }}
            />
          </IconButton>
          <Box>
            <IconButton
              onClick={toggleFullscreen}
              size="medium"
              sx={{
                px: 1,
              }}
            >
              {isFullscreen ? <FullscreenExit /> : <Fullscreen />}
            </IconButton>
            <IconButton
              onClick={onClose}
              size="medium"
              sx={{
                bgcolor: "#E0F2FE", // Slightly different color to distinguish
                "&:hover": { bgcolor: "#bae6fd" },
                borderRadius: "2px",
                p: 1,
                ml: 2,
              }}
            >
              <Close />
            </IconButton>
          </Box>
        </Box>

        <Box>{children}</Box>
      </Box>
    </Slide>
  );
};

export default Slider;
