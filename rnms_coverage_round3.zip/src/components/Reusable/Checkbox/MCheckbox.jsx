import React from "react";
import { Checkbox, FormControlLabel, FormControl } from "@mui/material";

const MCheckbox = ({
  checked,
  onChange,
  label,
  color = "primary",
  disabled = false,
  size = "medium",
  sx = {},
  ...props // Captures any other standard MUI checkbox props
}) => {
  return (
    <FormControl disabled={disabled}>
      <FormControlLabel
        control={
          <Checkbox
            checked={checked}
            onChange={onChange}
            color={color}
            size={size}
            {...props} // Spreads additional props like 'name', 'aria-label', etc.
          />
        }
        label={label}
        sx={{
          margin: 0, // Removes default margin for better layout control
          "& .MuiFormControlLabel-label": {
            fontSize: "0.9rem", // Standardizing text size
            color: disabled ? "text.disabled" : "text.primary",
          },
          ...sx, // Allows overriding styles from the parent
        }}
      />
    </FormControl>
  );
};

export default MCheckbox;
