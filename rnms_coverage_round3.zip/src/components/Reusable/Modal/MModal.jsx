/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Modal 
   File Name                : MModal.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Modal\MModal.jsx
   Purpose                  : A reusable wrapper for Material UI Modals to ensure consistent 
                               overlay behavior and standardized layering throughout the app.
   Created Date             : 10-03-2026
 ***********************************************************************************************/

import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Box,
  IconButton,
  Typography,
} from "@mui/material";
import {
  Close as CloseIcon,
  Fullscreen,
  FullscreenExit,
} from "@mui/icons-material";
import { styled, useTheme } from "@mui/material/styles";

// 1. The Close Button (SquareIconButton)
export const SquareIconButton = styled(IconButton)(({ theme }) => ({
  // Light mode: light blue | Dark mode: dark blue/grey
  backgroundColor:
    theme.palette.mode === "light" ? "#D7EEFF" : "rgb(62, 59, 59)",
  borderRadius: "20%",
  width: "30px",
  height: "30px",
  padding: "0",
  margin: "0",
  color: theme.palette.text.primary, // Ensures the X icon is visible
  "& .MuiIconButton-root": {
    borderRadius: "0",
  },
  "& .MuiIconButton-icon": {
    fontSize: "12px",
  },
  "&:hover": {
    // Add a slight hover effect for better UX
    backgroundColor: theme.palette.mode === "light" ? "#BEE3F8" : "#3D3D3D",
  },
}));

// 2. The Fullscreen Toggle Button (FullscreenToggleBtn)
const FullscreenToggleBtn = styled(IconButton)(({ theme }) => ({
  // Light mode: light grey | Dark mode: deep grey
  backgroundColor:
    theme.palette.mode === "light" ? "#D7EEFF" : "rgb(62, 59, 59)",
  borderRadius: "20%",
  width: "30px",
  height: "30px",
  padding: "0",
  marginRight: "8px",
  color: theme.palette.text.primary, // Ensures the icon is visible
  "& .MuiIconButton-icon": {
    fontSize: "16px",
  },
  "&:hover": {
    backgroundColor: theme.palette.mode === "light" ? "#CCCCCC" : "#444444",
  },
}));

const MModal = ({
  open,
  handleClose,
  title = "",
  fullScreen = false,
  children,
  customWidth,
  enableFullScreen,
  sideDrawer = false,
  info = "",
  showCloseButton = true,
}) => {
  const theme = useTheme(); // Access the current MUI theme from provider
  const [isExpanded, setIsExpanded] = useState(fullScreen);

  useEffect(() => {
    setIsExpanded(fullScreen);
  }, [fullScreen]);

  const handleBackdropClick = (event, reason) => {
    if (reason !== "backdropClick") {
      handleClose();
    }
  };

  const toggleFullScreen = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <Dialog
      open={open}
      onClose={handleBackdropClick}
      fullWidth
      fullScreen={isExpanded}
      anchor={sideDrawer ? "right" : "center"}
      // sx={{
      //   zIndex: 1600,
      // }}
      PaperProps={{
        sx: {
          overflow: "hidden",
          // Use theme colors for the background
          backgroundColor: theme.palette.background.paper,
          color: theme.palette.text.primary,

          borderRadius: isExpanded ? "0px" : sideDrawer ? "20px" : "30px",
          width: isExpanded
            ? "100%"
            : sideDrawer
            ? "400px"
            : customWidth || "auto",
          maxWidth: isExpanded ? "100vw" : sideDrawer ? "400px" : "60vw",
          height: isExpanded ? "100%" : sideDrawer ? "50vh" : "auto",
          maxHeight: isExpanded ? "100vh" : sideDrawer ? "35vh" : "90vh",

          ...(!isExpanded &&
            sideDrawer && {
              position: "fixed",
              margin: "auto",
              right: "25vh",
            }),
        },
      }}
    >
      <DialogTitle
        sx={{
          m: 0,
          p: 2,
          // Light mode: Dark gray (high contrast against light bg)
          // Dark mode: White with low opacity (high contrast against dark bg)
          borderBottom: `2px solid ${
            theme.palette.mode === "dark"
              ? theme.palette.divider || "rgba(255,255,255,0.12)"
              : theme.palette.mode === "light" // Explicitly check for light
              ? "rgba(0, 0, 0, 0.2)" // Dark solid color
              : "rgba(0, 0, 0, 0.8)"
          }`,

          position: "relative",
          display: "flex",
          alignItems: "center",
          justifyContent: sideDrawer && !isExpanded ? "flex-start" : "center",
          minHeight: "50px",
        }}
      >
        <Typography
          sx={{
            // Link this to your theme's text color
            color: theme.palette.text.TitleTextcolor,
            fontSize: "15px",
            fontWeight: 800,
          }}
        >
          {title}
        </Typography>
        <Box
          sx={{
            position: "absolute",
            right: 20,
            top: "50%",
            transform: "translateY(-50%)",
            display: "flex",
            alignItems: "center",
          }}
        >
          {enableFullScreen && (
            <FullscreenToggleBtn onClick={toggleFullScreen} size="small">
              {isExpanded ? <FullscreenExit /> : <Fullscreen />}
            </FullscreenToggleBtn>
          )}
          {showCloseButton && (
            <SquareIconButton onClick={handleClose}>
              <CloseIcon sx={{ color: theme.palette.text.primary }} />
            </SquareIconButton>
          )}
        </Box>
      </DialogTitle>

      {info !== "" && (
        <Typography
          sx={{
            color: "red",
            display: "flex",
            justifyContent: "left",
            pl: "3%",
            pt: 2,
            pb: -5,
          }}
        >
          {info}
        </Typography>
      )}
      <DialogContent sx={{ color: theme.palette.text.primary }}>
        <Box sx={{ mt: 1 }}>{children}</Box>
      </DialogContent>
    </Dialog>
  );
};

export default MModal;
