import React from 'react';
import styled from '@emotion/styled'; // Or use standard CSS/Sx
import { Input } from 'antd';
import { Typography } from '@mui/material';

// We create a wrapper to hold the TextArea and the Unit
const TextAreaWrapper = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  width: 100%;

  /* This targets the unit we will place inside */
  .unit-container {
    position: absolute;
    right: 12px;
    top: 5px; /* Adjust this based on your minRows/padding */
    pointer-events: none; /* So clicking the unit still focuses the textarea */
    color: rgba(0, 0, 0, 0.45); /* Ant Design default color for help text/units */
    font-size: 14px;
    z-index: 2;
  }
`;

const MTextAreaAntD = ({
  value,
  onChange,
  showUnit = false,
  unit = "",
  autoSize,
  style,
  fullWidth = true,
  errorMessage = "",
  ...props
}) => {
  return (
    <TextAreaWrapper>
      <Input.TextArea
        value={value}
        onChange={onChange}
        autoSize={autoSize}
        style={{
          resize: 'none',
          // paddingRight: showUnit ? '45px' : '12px', // Make room for the unit
          paddingRight: "0px", // Make room for the unit
          ...style,
        }}
        {...props}
      />
      
      {/* The Unit Implementation */}
      {showUnit && (
        <div className="unit-container ">
          {unit}
        </div>
      )}

      {/* Error Message below the box */}
      {errorMessage && (
        <Typography.Text type="danger" style={{ fontSize: '12px', marginTop: '4px' }}>
          {errorMessage}
        </Typography.Text>
      )}
    </TextAreaWrapper>
  );
};

export default MTextAreaAntD;