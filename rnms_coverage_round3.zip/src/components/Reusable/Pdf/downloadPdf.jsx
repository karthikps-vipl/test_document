/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : PDF Utility
   File Name                : downloadPdf.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Pdf\downloadPdf.jsx
   Purpose                  : A utility service providing standardized logic for generating, 
                               formatting, and downloading PDF documents across the application using JsPdf.
   Created Date             : 10-03-2026
 ***********************************************************************************************/
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import moment from "moment";
import html2canvas from "html2canvas";
import BELLogo from "@/assets/svg/BelLogo.svg";
import IndianAirforceLogo from "@/assets/svg/AirforceLogo.svg";
import Toast from "../Toast/Toast";
import {
  formatDateTime,
  linkStatusConfig,
  severityConfig,
  syslogSeverityConfig,
} from "@/lib/utils";

// const severityLabels = { "-1": "Normal", 0: "Warning", 1: "Minor", 2: "Major" };
const severityLabels = {
  "-1": "Normal",
  0: "Warning",
  1: "Minor",
  2: "Major",
  MINOR: "Minor",
  MAJOR: "Major",
  WARNING: "Warning",
  NORMAL: "Normal",
};
const workFlowLabels = { 0: "NOT_ACK", 1: "ACK", 2: "END" };
const alarmStateLabels = { 0: "CLEARED", 1: "RAISED" };
const currentAlarmStateLabels = { 0: "CLEARED", 1: "RAISED" };
const systemAndRnmsUptime = { 1: "DOWN TIME", 0: "UP TIME" };

// Severity Color mapping for PDF dots [Red, Green, Blue]
const severityColors = {
  MAJOR: ["#eb9399"], // Red
  MINOR: ["#dbdb1b"], // Yellow / Amber
  WARNING: ["#34b8b8"], // Orange
  NORMAL: [40, 167, 69], // Green
  2: ["#eb9399"],
  1: ["#dbdb1b"],
  0: ["#34b8b8"],
  "-1": [40, 167, 69],
};

const svgToPngBase64 = (url) => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.src = url;
    img.onload = () => {
      const scaleFactor = 4;
      const canvas = document.createElement("canvas");
      canvas.width = img.width * scaleFactor;
      canvas.height = img.height * scaleFactor;
      const ctx = canvas.getContext("2d");
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.scale(scaleFactor, scaleFactor);
      ctx.drawImage(img, 0, 0);
      resolve(canvas.toDataURL("image/png", 1.0));
    };
    img.onerror = (err) => reject(err);
  });
};

export const getChartImageBase64 = async (elementId) => {
  const element = document.getElementById(elementId);
  if (!element) return null;

  await new Promise((resolve) => setTimeout(resolve, 600));

  try {
    const downloadBtn = element.querySelector("button");
    if (downloadBtn) downloadBtn.style.visibility = "hidden";

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: "#FFFFFF",
      logging: false,
      imageTimeout: 0,
    });

    if (downloadBtn) downloadBtn.style.visibility = "visible";
    return canvas.toDataURL("image/png", 1.0);
  } catch (err) {
    console.error("Capture error:", err);
    return null;
  }
};

const drawSummaryLine = (doc, label, value, x, y, color = [30, 30, 30]) => {
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...color);
  doc.text(`${label}:`, x, y);

  const labelWidth = doc.getTextWidth(`${label}:`);

  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 30, 30);
  doc.text(String(value ?? "N/A"), x + labelWidth + 2, y);
};
const hexToRgb = (hex) => {
  if (!hex) return [30, 30, 30];

  const cleanHex = hex.replace("#", "");

  return [
    parseInt(cleanHex.substring(0, 2), 16),
    parseInt(cleanHex.substring(2, 4), 16),
    parseInt(cleanHex.substring(4, 6), 16),
  ];
};
export const exportToPDF = async (
  title,
  columns,
  data,
  reportName,
  userDetails,
  chartElementIds = [],
  reportSummary = null,
  summaryTable = null,
  auditSiteInfo = null,
  extraInfo = null
) => {
  const tableData = data || [];
  if (tableData.length === 0) {
    Toast("Information", "No data available to export", "info");
    return;
  }

  const doc = new jsPDF({
    orientation: "p",
    unit: "mm",
    format: "a4",
    compressPdf: true,
  });

  const idsArray = Array.isArray(chartElementIds)
    ? chartElementIds
    : chartElementIds
    ? [chartElementIds]
    : [];

  const chartPromises = idsArray.map((id) => getChartImageBase64(id));
  const [logo1, logo2, ...capturedCharts] = await Promise.all([
    svgToPngBase64(BELLogo),
    svgToPngBase64(IndianAirforceLogo),
    ...chartPromises,
  ]);

  const validCharts = capturedCharts.filter((img) => img !== null);
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;

  // Header Section
  doc.addImage(logo1, "PNG", 10, 7, 30, 12, undefined, "FAST");
  doc.addImage(logo2, "PNG", 185, 6, 15, 15, undefined, "FAST");

  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(0, 0, 0); // Ensure black text
  doc.text(`${title}`, pageWidth / 2, 14, { align: "center" });

  // 2. Draw "From - To" Date (Centered below Title)
  let dynamicTableStartY = 22; // Positioned below the title (14 + margin)
  
  if (extraInfo?.fromDate || extraInfo?.toDate) {
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 30, 30);
    
    // Using optional chaining here as well to avoid "undefined - undefined" strings
    const fromDate = extraInfo?.fromDate || "";
    const toDate = extraInfo?.toDate || "";
    const isInvalid = (val) => !val || val === "N/A" || val === "undefined";

    // 3. Only create a dateRange if BOTH dates are valid and not "N/A"
    const dateRange = (!isInvalid(fromDate) && !isInvalid(toDate)) 
      ? `${fromDate} - ${toDate}` 
      : "";

    // Centered on the page
    doc.text(dateRange, pageWidth / 2, dynamicTableStartY, {
      align: "center",
    });
    dynamicTableStartY += 7; 
}

  // 3. Draw "Report Generated Date and Time" (Right Aligned)
  // We place this slightly lower or at the same level as the date range
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(80);
  const timestamp = `Report generated Date and Time: ${moment().format("DD-MM-YYYY HH:mm:ss")}`;
  
  // If you want it on the same horizontal line as the Date Range but on the right:
  // Use 'dynamicTableStartY' for the Y coordinate
  doc.text(
    timestamp,
    pageWidth - 10,
    dynamicTableStartY, 
    { align: "right" }
  );

  // Adjust the table start position based on how much header we used
  dynamicTableStartY += 7; 
  if (auditSiteInfo) {
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 30, 30);
    dynamicTableStartY += 6;

    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");

    if (auditSiteInfo.terminalTypeName) {
      doc.text(
        `Terminal: ${auditSiteInfo.terminalTypeName}`,
        90,
        dynamicTableStartY
      );
    } else {
      // Fallback to Site Name if terminalName isn't there
      doc.text(
        `Site Name: ${auditSiteInfo.siteName || "N/A"}`,
        90,
        dynamicTableStartY
      );
    }
    doc.text(`Site ID: ${auditSiteInfo.siteId}`, 10, dynamicTableStartY);
    dynamicTableStartY += 5;
  }
  if (summaryTable?.rows?.length) {
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 30, 30);

    doc.text("Site Summary Overview:", 10, dynamicTableStartY);

    dynamicTableStartY += 5;

    const summaryHead = [
      ["TERMINAL", "ONLINE", "OFFLINE", "RNMS DOWN", "MAINTENANCE", "TOTAL"],
    ];

    const summaryBody = summaryTable.rows.map((row) => [
      row.terminal,
      row.online,
      row.offline,
      row.rnmsDown,
      row.maintenance,
      row.total,
    ]);

    // TOTAL row
    summaryBody.push([
      "TOTAL",
      summaryTable.totals.online,
      summaryTable.totals.offline,
      summaryTable.totals.rnmsDown,
      summaryTable.totals.maintenance,
      summaryTable.totals.total,
    ]);

    autoTable(doc, {
      startY: dynamicTableStartY,
      head: summaryHead,
      body: summaryBody,

      theme: "grid",

      margin: {
        left: 10,
        right: 10,
      },

      styles: {
        fontSize: 8,
        cellPadding: 2,
        halign: "center",
        valign: "middle",
      },

      headStyles: {
        fillColor: [64, 192, 245],
        textColor: 255,
        fontSize: 7,
        fontStyle: "bold",
        halign: "center",
      },

      bodyStyles: {
        textColor: 30,
      },

      columnStyles: {
        0: {
          halign: "left",
          cellWidth: 45,
        },
        1: {
          halign: "center",
        },
        2: {
          halign: "center",
        },
        3: {
          halign: "center",
        },
        4: {
          halign: "center",
        },
        5: {
          halign: "center",
        },
      },

      didParseCell: (data) => {
        if (
          data.section === "body" &&
          data.row.index === summaryBody.length - 1
        ) {
          data.cell.styles.fontStyle = "bold";
          data.cell.styles.fillColor = [235, 245, 250];
        }
      },
    });

    dynamicTableStartY = doc.lastAutoTable.finalY + 10;

    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 30, 30);

    doc.text("Site Summary:", 10, dynamicTableStartY);

    dynamicTableStartY += 5;
  }

  const startYCharts = 30;
  if (validCharts.length === 1) {
    const chartWidth = 40;
    const chartHeight = 40;
    const chartX = 10;
  
    // LinkCnms gets its own PDF layout.
    const isCnmsLinkReport = reportSummary?.isCnmsLinkTab;
  
    const chartY = isCnmsLinkReport
      ? dynamicTableStartY + 5
      : startYCharts;
  
    doc.addImage(
      validCharts[0],
      "PNG",
      chartX,
      chartY,
      chartWidth,
      chartHeight,
      undefined,
      "FAST"
    );
  
    if (reportSummary) {
      const summaryX = isCnmsLinkReport ? 65 : 90;
      let summaryY = chartY + 5;
  
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 30, 30);
  
      // LinkCnms: show only the four requested fields.
      if (isCnmsLinkReport) {
        [
          ["From Date Time", reportSummary.fromDate],
          ["To Date Time", reportSummary.toDate],
          ["Site ID", reportSummary.siteId],
          ["Link Type", reportSummary.linkTypeName],
        ].forEach(([label, value]) => {
          drawSummaryLine(
            doc,
            label,
            value ?? "N/A",
            summaryX,
            summaryY
          );
  
          summaryY += 7;
        });
      } else {
        // Existing layout for all other reports.
        if (reportSummary.fromDate) {
          drawSummaryLine(
            doc,
            "From Date Time",
            reportSummary.fromDate,
            summaryX,
            summaryY
          );
          summaryY += 6;
        }
  
        if (reportSummary.toDate) {
          drawSummaryLine(
            doc,
            "To Date Time",
            reportSummary.toDate,
            summaryX,
            summaryY
          );
          summaryY += 6;
        }
  
        if (reportSummary.deviceName) {
          drawSummaryLine(
            doc,
            reportSummary.isLinkTab
              ? "Router WAN Interface Type"
              : "Device Name",
            reportSummary.deviceName,
            summaryX,
            summaryY
          );
          summaryY += 6;
        }
  
        if (reportSummary.isSiteMaintenance) {
          drawSummaryLine(
            doc,
            "Terminal Name",
            reportSummary.terminalTypeName,
            summaryX,
            summaryY
          );
          summaryY += 6;
  
          drawSummaryLine(
            doc,
            "Site ID",
            reportSummary.siteId,
            summaryX,
            summaryY
          );
          summaryY += 6;
  
          drawSummaryLine(
            doc,
            "Site Name",
            reportSummary.siteName,
            summaryX,
            summaryY
          );
          summaryY += 6;
        }
  
        if (reportSummary.isLinkTab) {
          reportSummary.linkStatusBreakdown?.forEach((item) => {
            drawSummaryLine(
              doc,
              item.label,
              item.value,
              summaryX,
              summaryY,
              item.color ? hexToRgb(item.color) : [30, 30, 30]
            );
  
            summaryY += 6;
          });
        } else if (reportSummary.isUptimeTab) {
          drawSummaryLine(
            doc,
            "Uptime",
            reportSummary.value1,
            summaryX,
            summaryY,
            hexToRgb(reportSummary.color1)
          );
  
          summaryY += 6;
  
          drawSummaryLine(
            doc,
            "Downtime",
            reportSummary.value2,
            summaryX,
            summaryY,
            hexToRgb(reportSummary.color2)
          );
  
          summaryY += 6;
        } else {
          drawSummaryLine(
            doc,
            reportSummary.label1,
            reportSummary.value1,
            summaryX,
            summaryY,
            hexToRgb(reportSummary.color1)
          );
  
          summaryY += 6;
  
          drawSummaryLine(
            doc,
            reportSummary.label2,
            reportSummary.value2,
            summaryX,
            summaryY,
            hexToRgb(reportSummary.color2)
          );
  
          summaryY += 6;
        }
      }
    }
  
    dynamicTableStartY = chartY + chartHeight + 10;
  }
  
  
  else if (validCharts.length === 2) {
    const chartWidth = 40;
    const chartHeight = 40;
    const gap = 6;

    const totalWidth = chartWidth * 2 + gap;
    const startX = (pageWidth - totalWidth) / 2;

    doc.addImage(
      validCharts[0],
      "PNG",
      startX,
      startYCharts,
      chartWidth,
      chartHeight,
      undefined,
      "FAST"
    );

    doc.addImage(
      validCharts[1],
      "PNG",
      startX + chartWidth + gap,
      startYCharts,
      chartWidth,
      chartHeight,
      undefined,
      "FAST"
    );

    dynamicTableStartY = startYCharts + chartHeight + 10;
  }

  // Data Preparation
  const exportCols = columns.filter(
    (col) => !["actions", "select", "checkbox"].includes(col.uid || col.dataKey)
  );

  const head = [
    exportCols.map((col) => (col.name || col.header || "").toUpperCase()),
  ];

  const body = tableData.map((row, index) =>
    exportCols.map((col) => {
      const key = col.uid || col.dataKey;
      if (key === "sno") return index + 1;

      // if (key === "severity" || key === "auditLogLvl") {
      //   const rawVal = row.severity ?? row.auditLogLvl;
      //   return severityLabels[rawVal] ?? rawVal;
      // }

      if (key === "severity") {
        const rawVal = row.severity;

        // Only use syslog severity mapping when this column
        // is explicitly configured as a syslog severity column.
        if (col.severityType === "syslog") {
          return (
            syslogSeverityConfig[String(rawVal)]?.label ??
            syslogSeverityConfig[rawVal]?.label ??
            rawVal
          );
        }

        // Normal alarm severity
        return severityLabels[rawVal] ?? rawVal;
      }

      if (key === "auditLogLvl") {
        const rawVal = row.auditLogLvl;

        return severityLabels[rawVal] ?? rawVal;
      }
      // if (key === "severity") {
      //   const rawVal = row.severity;

      //   // Syslog severity
      //   if (syslogSeverityConfig[rawVal] !== undefined) {
      //     return syslogSeverityConfig[rawVal].label;
      //   }

      //   return severityLabels[rawVal] ?? rawVal;
      // }

      // if (key === "auditLogLvl") {
      //   const rawVal = row.auditLogLvl;
      //   return severityLabels[rawVal] ?? rawVal;
      // }

      if (key === "facilityString") {
        return row.facilityString || "N/A";
      }

      // if (key === "facility") {
      //   return syslogFacilityMap[row.facility] ?? row.facility;
      // }
      if (key === "workflow")
        return workFlowLabels[row.workflow] ?? row.workflow;
      if (key === "alarmState")
        return alarmStateLabels[row.alarmState] ?? row.alarmState;
      if (key === "currentAlarmState")
        return (
          currentAlarmStateLabels[row.currentAlarmState] ??
          row.currentAlarmState
        );
      if (key === "type") return systemAndRnmsUptime[row.type] ?? row.type;
      if (key === "linkStatus")
        return linkStatusConfig[row.linkStatus]?.label ?? row.linkStatus;
      if (key === "isMaintenance")
        return row.isMaintenance === true ? "Yes" : "No";
      if (key === "statusDisplay")
        return row.statusText || row.statusDisplay || "";
      if (key === "value") return row.repoValue || row.value || "";
      if (key === "available")
        return row.available === true ? "Available" : "Not available";

      const value = row[key];
      if (
        key === "dateTime" ||
        key === "datTimeForm" ||
        key === "backupDateTime" ||
        key === "restoreDateTime"
      )
        return formatDateTime(value);
      if (key === "durationSeconds" || key === "duration") {
        const totalSeconds = Number(value) || 0;
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = Math.floor(totalSeconds % 60);

        // Format: e.g., "0d 2h 30m 15s"
        // You can adjust the spacing or capitalization here if needed
        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
      }
      return value !== null && value !== undefined ? value : "";
    })
  );

  // --- CUSTOM COLUMN WIDTH STYLING ---
  const columnStyles = {};
  exportCols.forEach((col, index) => {
    const key = col.uid || col.dataKey;
    if (key === "sno") {
      columnStyles[index] = { cellWidth: 12, halign: "center" };
    } else if (key === "dateTime" || key === "datTimeForm") {
      columnStyles[index] = { cellWidth: 35, halign: "center" };
    } else if (key === "severity" || key === "auditLogLvl") {
      columnStyles[index] = { cellWidth: 25, halign: "left" }; // Custom width for Severity
    } else if (key === "auditDesc" || key === "description") {
      columnStyles[index] = { cellWidth: 50, halign: "left" }; // Custom width for Description
    } else {
      columnStyles[index] = { halign: "left" };
    }
  });

  // Auto-Table Generation with Custom Severity Dot Hook
  autoTable(doc, {
    startY: dynamicTableStartY,
    head: head,
    body: body,
    theme: "grid",
    margin: { left: 10, right: 10 },
    columnStyles: columnStyles,
    styles: {
      overflow: "linebreak",
      cellPadding: 2,
    },
    headStyles: {
      fillColor: [64, 192, 245],
      textColor: 255,
      fontSize: 7,
      fontStyle: "bold",
      halign: "center",
    },
    bodyStyles: {
      fontSize: 8,
      textColor: 30,
    },
    alternateRowStyles: {
      fillColor: [247, 250, 252],
    },
    didDrawCell: (data) => {
      const colKey =
        exportCols[data.column.index]?.uid ||
        exportCols[data.column.index]?.dataKey;

      if (
        (colKey === "severity" || colKey === "auditLogLvl") &&
        data.section === "body"
      ) {
        const rawRowData = tableData[data.row.index];
        // const severityVal = String(
        //   rawRowData?.severity ?? rawRowData?.auditLogLvl ?? ""
        // ).toUpperCase();
        // const rgb = severityColors[severityVal] || [100, 100, 100];

        const rawSeverity = rawRowData?.severity ?? rawRowData?.auditLogLvl;

        let rgb = [100, 100, 100];

        if (exportCols[data.column.index]?.severityType === "syslog") {
          const gradient = syslogSeverityConfig[String(rawSeverity)]?.gradient;

          if (gradient) {
            const hex = gradient[0].replace("#", "");

            rgb = [
              parseInt(hex.substring(0, 2), 16),
              parseInt(hex.substring(2, 4), 16),
              parseInt(hex.substring(4, 6), 16),
            ];
          }
        } else {
          rgb = severityColors[String(rawSeverity).toUpperCase()] || [
            100, 100, 100,
          ];
        }

        const cell = data.cell;
        const textY = cell.y + cell.height / 2;

        // Clear text region and redraw background to make room for dot
        doc.setFillColor(
          data.row.index % 2 === 0 ? 255 : 247,
          data.row.index % 2 === 0 ? 255 : 250,
          data.row.index % 2 === 0 ? 255 : 252
        );
        doc.rect(cell.x + 2, cell.y + 1, cell.width - 4, cell.height - 2, "F");

        // Draw Color Dot Circle (radius 1.5mm)
        doc.setFillColor(rgb[0], rgb[1], rgb[2]);
        doc.circle(cell.x + 5, textY, 1.5, "F");

        // Draw Text next to the dot
        doc.setTextColor(30, 30, 30);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(8);
        doc.text(String(cell.text), cell.x + 10, textY + 1, {
          baseline: "middle",
        });
      }
    },
    didDrawPage: () => {
      doc.setDrawColor(180);
      doc.setLineWidth(0.3);
      doc.rect(5, 5, pageWidth - 10, pageHeight - 10, "S");

      const footerText = "This is a computer generated report";
      const pageNum = `Page ${doc.internal.getNumberOfPages()}`;

      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100);

      doc.text(footerText, pageWidth / 2, pageHeight - 8, { align: "center" });
      doc.text(pageNum, pageWidth - 15, pageHeight - 8, { align: "right" });
    },
  });

  const safeFileName = (reportName || title).replace(/\s+/g, "_").toLowerCase();
  doc.save(
    `${safeFileName.toUpperCase()}_${moment().format(
      "DD-MM-YYYY_HH-mm-ss"
    )}.pdf`
  );
};

export const exportToCSV = (filename, columns, data) => {
  const tableData = data || [];
  const exportCols = columns.filter((col) => col.uid !== "actions");

  const headers = exportCols.map((col) => col.name).join(",");
  const rows = tableData
    .map((row, index) =>
      exportCols
        .map((col) => {
          let val =
            col.uid === "sno"
              ? index + 1
              : col.uid === "severity"
              ? severityLabels[row.severity]
              : row[col.uid];
          return `"${String(val ?? "").replace(/"/g, '""')}"`;
        })
        .join(",")
    )
    .join("\n");

  const blob = new Blob([headers + "\n" + rows], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}.csv`;
  link.click();
};

export const exportSingleChartWithTable = async (
  title,
  columns,
  data,
  elementId,
  fileName
) => {
  const safeTitle = title ? String(title) : "Report";
  const safeFileName = fileName ? String(fileName) : "report";

  const doc = new jsPDF({
    orientation: "p",
    unit: "mm",
    format: "a4",
    compressPdf: true,
  });

  const element = document.getElementById(elementId);
  if (!element) {
    console.error("Target container not found in DOM");
    return;
  }

  try {
    // 1. FIXED: Targeted '.download-btn-cls' and generic 'button' elements explicitly
    const actionElements = element.querySelectorAll(
      ".download-btn-cls, button, .action-container"
    );

    // Hide them completely from the DOM layout snapshot
    actionElements.forEach((el) => {
      el.style.display = "none";
    });

    // Short delay to let the DOM settle before html2canvas takes the picture
    await new Promise((resolve) => setTimeout(resolve, 150));

    // 2. CAPTURE CHART
    const canvas = await html2canvas(element, {
      scale: 3,
      useCORS: true,
      allowTaint: true,
      backgroundColor: "#FFFFFF",
    });

    // RESTORE UI ELEMENTS immediately after snapshot is captured
    actionElements.forEach((el) => {
      el.style.display = "block"; // Or 'inline-block'/'flex' depending on your styling
    });

    const imgData = canvas.toDataURL("image/png", 1.0);
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;

    // 3. LOGO & HEADER
    try {
      const logo1 = await svgToPngBase64(BELLogo);
      const logo2 = await svgToPngBase64(IndianAirforceLogo);
      if (typeof logo1 === "string" && logo1.startsWith("data:image")) {
        doc.addImage(logo1, "PNG", 10, 7, 30, 12, undefined, "FAST");
      }
      if (typeof logo2 === "string" && logo2.startsWith("data:image")) {
        doc.addImage(logo2, "PNG", 185, 6, 15, 15, undefined, "FAST");
      }
    } catch (e) {
      console.warn("Logos failed", e);
    }

    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.text(safeTitle, pageWidth / 2, 14, { align: "center" });

    const timestamp = `Report generated: ${moment().format(
      "DD-MM-YYYY HH:mm:ss"
    )}`;
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(80);
    doc.text(timestamp, pageWidth - 10, 25, { align: "right" });

    // 4. PLACE CHART (Fixed Width Scaling)
    const chartWidth = 140; // Makes it wide and readable on A4 page
    const chartX = (pageWidth - chartWidth) / 2;
    const chartY = 35;
    const imgProps = doc.getImageProperties(imgData);
    const chartHeight = (imgProps.height * chartWidth) / imgProps.width;
    doc.addImage(
      imgData,
      "PNG",
      chartX,
      chartY,
      chartWidth,
      chartHeight,
      undefined,
      "FAST"
    );

    // 5. FIXED DATA MAPPING
    const exportCols = columns.filter(
      (col) =>
        !["actions", "select", "checkbox"].includes(col.uid || col.dataKey)
    );

    const head = [
      exportCols.map((col) => (col.name || col.header || "").toUpperCase()),
    ];

    const body = (data || []).map((row, index) => {
      return exportCols.map((col) => {
        const key = col.uid || col.dataKey;

        if (key === "sno") return index + 1;
        // if (key === "severity")
        //   return severityLabels[row.severity] ?? row.severity;
        // if (key === "facility") {
        //   return syslogFacilityMap[row.facility] ?? row.facility;
        // }
        if (key === "severity") {
          if (syslogSeverityConfig[row.severity] !== undefined) {
            return syslogSeverityConfig[row.severity].label;
          }

          return severityLabels[row.severity] ?? row.severity;
        }

        if (key === "facilityString") {
          return row.facilityString || "N/A";
        }
        if (key === "syslog")
          return syslogSeverityConfig[row.syslog] ?? row.syslog;
        if (key === "workflow")
          return workFlowLabels[row.workflow] ?? row.workflow;
        if (key === "alarmState")
          return alarmStateLabels[row.alarmState] ?? row.alarmState;
        if (key === "currentAlarmState")
          return (
            currentAlarmStateLabels[row.currentAlarmState] ??
            row.currentAlarmState
          );
        if (key === "linkStatus")
          return linkStatusConfig[row.linkStatus]?.label ?? row.linkStatus;
        if (key === "isMaintenance")
          return row.isMaintenance === true ? "Yes" : "No";
        if (key === "available")
          return row.available === true ? "Available" : "Not available";
        if (key === "faultSeverityString") {
          const rawValue = row.faultSeverityString || row.severity || "";
          const normalizedKey = rawValue ? rawValue.toUpperCase() : "";

          // 1. Ensure the config object itself exists
          if (!severityConfig) {
            return rawValue;
          }

          // 2. Ensure the specific key exists in the config
          const configItem = severityConfig[normalizedKey];

          if (configItem) {
            return configItem.label;
          }

          // 3. Fallback if key mismatch (e.g., data says "warning" but config says "WARNING")
          // Try lowercase just in case
          const lowerKey = rawValue.toLowerCase();
          const lowerConfigItem = severityConfig[lowerKey];
          if (lowerConfigItem) {
            return lowerConfigItem.label;
          }

          return rawValue;
        }

        if (key === "durationSeconds") {
          const totalSeconds = Number(value) || 0;
          const days = Math.floor(totalSeconds / 86400);
          const hours = Math.floor((totalSeconds % 86400) / 3600);
          const minutes = Math.floor((totalSeconds % 3600) / 60);
          const seconds = Math.floor(totalSeconds % 60);

          // Format: e.g., "0d 2h 30m 15s"
          // You can adjust the spacing or capitalization here if needed
          return `${days}d ${hours}h ${minutes}m ${seconds}s`;
        }
        const value = row[key];
        if (value === null || value === undefined) return "";
        if (key === "dateTime" && value)
          return moment(value).format("DD-MM-YYYY HH:mm");

        return String(value);
      });
    });

    // 6. GENERATE TABLE
    const startYTable = chartY + chartHeight + 15;
    autoTable(doc, {
      startY: startYTable,
      head: head,
      body: body,
      theme: "grid",
      margin: { left: 10, right: 10 },
      styles: {
        overflow: "linebreak",
        cellPadding: 2,
        fontSize: 8,
      },
      headStyles: {
        fillColor: [64, 192, 245],
        textColor: [255, 255, 255],
        fontSize: 8.5,
        halign: "center",
      },
      didDrawPage: (dataArg) => {
        doc.setDrawColor(180);
        doc.setLineWidth(0.3);
        doc.rect(5, 5, pageWidth - 10, pageHeight - 10, "S");
        doc.setFontSize(8);
        doc.text(
          "This is a computer generated report",
          pageWidth / 2,
          pageHeight - 8,
          { align: "center" }
        );
        doc.text(
          `Page ${doc.internal.getNumberOfPages()}`,
          pageWidth - 15,
          pageHeight - 8,
          { align: "right" }
        );
      },
    });

    // 7. SAVE
    const finalFileName = `${safeFileName
      .replace(/\s+/g, "_")
      .toUpperCase()}_${moment().format("DD-MM-YYYY_HH-mm-ss")}.pdf`;
    doc.save(finalFileName);
  } catch (error) {
    console.error("Single Chart PDF Export failed:", error);
  }
};
