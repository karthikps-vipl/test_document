// /***********************************************************************************************
//    Project                  : IAF-NMS
//    SubSystem                : Material Dialog
//    File Name                : MDialog.jsx
//    Author                   : ANKITHA - VIPL
//    Package                  : src\components\Reusable\Dialog\MDialog.jsx
//    Purpose                  : A reusable Material UI Dialog wrapper used to standardize
//                               the implementation of modal windows, alerts, and confirmation
//                               dialogs across the application.
//    Created Date             : 16-03-2026
//  ***********************************************************************************************/

import React from "react";
// import { Modal, Box, Typography, Button } from "@mui/material";
import {
  Modal,
  Box,
  Typography,
  CircularProgress,
  Button,
  useTheme,
} from "@mui/material";


export default function MDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  variant = "primary",
  container = null,
  icon,
  grandchildren,
  children,
  isInchildDrawer = false,
  showButtons = true,
  mode = "parent",
  glass = false,
  sx = {},
  confirmDisabled = false,
  isSubmitting = false,
  loading = false,
  isGrandchildFullScreen = false,
  isChildFullScreen = false,

}) {
  const theme = useTheme();
  // const isActuallySubmitting = isSubmitting || loading;

  const leftPadding =
    mode === "child"
      ? isChildFullScreen
        ? 0
        : "55%"
      : mode === "grandchild"
        ? isGrandchildFullScreen
          ? 0
          : "75%"
        : 0;
  return (
    <Modal
      open={open}
      onClose={onClose}
      container={container}
      hideBackdrop={isInchildDrawer}
      sx={{
        zIndex: 2500,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: mode === "parent" ? "100vh" : "100%",
        width: mode === "parent" ? "100vw" : "100%",
        position: mode === "grandchild" ? "absolute" : "fixed",
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,

        //  FIX: no offset when grandchild is fullscreen
        pl: leftPadding,

        outline: "none",
        "& .MuiModal-backdrop": {
          backgroundColor: glass
            ? "rgba(0, 0, 0, 0.3)"
            : theme.palette.mode === "dark"
              ? "rgba(52, 50, 50, 0.67)"
              : "rgba(0,0,0,0.4)",
          backdropFilter: glass ? "blur(5px)" : "none",
        },
        ...sx,
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: isInchildDrawer ? "flex-end" : "center",
          alignItems: "center",
          height: isInchildDrawer ? "100%" : "90vh",
          width: isInchildDrawer ? "100%" : "90vw",
          outline: "none",
          pr: isInchildDrawer ? 5 : 0,
        }}
      >
        <Box
          sx={{
            width: { xs: "90%", sm: "350px" },
            minWidth: "60px",
            minHeight: "230px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "relative",
            bgcolor: "transparent",
            ...sx,

            ...(glass
              ? {
                backdropFilter: "blur(5px)",
                backgroundColor:
                  theme.palette.mode === "dark"
                    ? "rgba(255, 255, 255, 0.05)"
                    : "rgba(255, 255, 255, 0.7)",
                boxShadow: "0 8px 32px 0 rgba(20, 52, 141, 0.15)",
                borderRadius: "16px",
                padding: "32px",
                maxWidth: "750px",
                width: "100%",
                border: `1px solid ${theme.palette.mode === "dark"
                    ? "rgba(255,255,255,0.1)"
                    : "rgba(255,255,255,0.3)"
                  }`,
              }
              : {}),
          }}
        >
          {/* Decorative background box */}
          {!glass && (
            <Box
              sx={{
                position: "absolute",
                height: "100%",
                right: "50%",
                inset: 0,
                zIndex: 0,
                "--r": "20px",
                "--s": "40px",
                "--a": "20deg",
                "--p": "50%",
                background:
                  theme.palette.mode === "dark"
                    ? theme.palette.background.paper
                    : "#fff",
                borderRadius: "20px",
                "--_m": "var(--r), #000 calc(100% - 1px), #0000",
                "--_d": "calc((var(--s) + var(--r)) * cos(var(--a)))",
                WebkitMask: `
              radial-gradient(var(--r) at calc(var(--p) + var(--_d)) var(--_m)),
              radial-gradient(var(--r) at calc(var(--p) - var(--_d)) var(--_m)),
              radial-gradient(
                var(--s) at var(--p) calc(-1 * sin(var(--a)) * var(--s)),
                #0000 100%,
                #000 calc(100% + 1px)
              ) 0 calc(var(--r) * (1 - sin(var(--a)))) no-repeat,
              linear-gradient(
                90deg,
                #000 calc(var(--p) - var(--_d)),
                #0000 0 calc(var(--p) + var(--_d)),
                #000 0
              )
            `,
                margin: "0 auto",
                boxShadow:
                  theme.palette.mode === "dark"
                    ? "0 4px 20px rgba(0,0,0,0.5)"
                    : "0 4px 20px rgba(0,0,0,0.1)",
              }}
            />
          )}

          {/* Icon */}
          {icon && (
            <Box
              sx={{
                position: "absolute",
                top: -40,
                left: "50%",
                transform: "translateX(-50%)",
                width: 100,
                height: 84,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 2,
                mt: 1.5,
              }}
            >
              <img
                src={icon}
                alt="icon"
                style={{ width: "50%", marginBottom: "12px" }}
              />
            </Box>
          )}

          <Box
            sx={{
              mt: icon ? 6 : 2,
              width: "100%",
              textAlign: "center",
              zIndex: 1,
              color: theme.palette.text.primary,
            }}
          >
            <Typography
              variant="h6"
              gutterBottom
              sx={{ fontWeight: "600", color: theme.palette.text.primary }}
            >
              {title}
            </Typography>
            <Typography sx={{ color: theme.palette.text.primary, mb: 2 }}>
              {message}
            </Typography>

            <Box>{children}</Box>
            <Box>{grandchildren}</Box>

            {showButtons && (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  gap: "20px",
                  mt: 3,
                  mb: 3,
                }}
              >
                <Button
                  onClick={onClose}
                  sx={{
                    width: "40%",
                    borderRadius: "10px",
                    border: "1px solid #ccc",
                    color: theme.palette.text.primary,
                    textTransform: "none",
                  }}
                >
                  {cancelText}
                </Button>

                <Button
                  variant="contained"
                  onClick={onConfirm}
                  disabled={confirmDisabled || isSubmitting} // Use isSubmitting here
                  sx={{
                    width: "40%",
                    borderRadius: "10px",
                    textTransform: "none",
                    backgroundColor: variant === "error" ? "#ef4444" : "#14348D",
                    "&:hover": {
                      backgroundColor: variant === "error" ? "#dc2626" : "#0f2870",
                    },
                    minWidth: "120px", // Add minWidth to prevent button jumping when loading
                  }}
                >
                  {isSubmitting ? (
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
                      <CircularProgress size={20} color="inherit" />
                      <span>Loading...</span>
                    </Box>
                  ) : (
                    confirmText
                  )}
                </Button>
              </Box>
            )}
          </Box>
        </Box>
      </Box>
    </Modal>
  );
}
