/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Material Dialog 
   File Name                : MDialog.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Dialog\MDialog.jsx
   Purpose                  : A reusable Material UI Dialog wrapper used to standardize 
                              the implementation of modal windows, alerts, and confirmation 
                              dialogs across the application.
   Created Date             : 16-03-2026
 ***********************************************************************************************/
import React from "react";
import { Modal, Box, Typography, Button } from "@mui/material";

export default function MDialog({
  open,
  onClose,
  onConfirm,
  // title = "Confirm Action",
  title,
  // message = "Are you sure?",
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  variant = "primary",
  container = null,
  icon,
  children,
  grandchildren,
  type,
  mode = "parent", // "parent" | "child" | "grandchild"
}) {
  return (
    <Modal open={open} onClose={onClose} container={container}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",

          // 1. ALWAYS CENTER the content items logically
          // We will use padding to create the "offset" effect
          justifyContent: "center",

          // 2. DIMENSIONS
          height: mode === "parent" ? "90vh" : "100%",
          width: mode === "parent" ? "90vw" : "100%",

          // 3. POSITIONING
          position: mode === "grandchild" ? "absolute" : "fixed",
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,

          pl: mode === "child" ? "55%" : mode === "grandchild" ? "75%" : 0,

          outline: "none",
        }}
      >
        <Box
          style={{
            height: `${type === "addDevice" ? "35%" : "26%"}`,
            width: "20%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "relative",
            left: "40%",
            top: "30%",
          }}
        >
          {/* Decorative background box */}
          <Box
            sx={{
              position: "absolute",
              height: "100%",
              right: "50%",
              inset: 0,
              zIndex: 0,
              "--r": "20px",
              "--s": "40px",
              "--a": "20deg",
              "--p": "50%",
              background: "#fff",
              borderRadius: "20px",
              "--_m": "var(--r), #000 calc(100% - 1px), #0000",
              "--_d": "calc((var(--s) + var(--r)) * cos(var(--a)))",
              WebkitMask: `
                 radial-gradient(var(--r) at calc(var(--p) + var(--_d)) var(--_m)),
                 radial-gradient(var(--r) at calc(var(--p) - var(--_d)) var(--_m)),
                 radial-gradient(
                   var(--s) at var(--p) calc(-1 * sin(var(--a)) * var(--s)),
                   #0000 100%,
                   #000 calc(100% + 1px)
                 ) 0 calc(var(--r) * (1 - sin(var(--a)))) no-repeat,
                 linear-gradient(
                   90deg,
                   #000 calc(var(--p) - var(--_d)),
                   #0000 0 calc(var(--p) + var(--_d)),
                   #000 0
                 )
               `,
            }}
          />

          {/* Icon */}
          {icon && (
            <Box
              sx={{
                position: "absolute",
                top: -40,
                left: "50%",
                transform: "translateX(-50%)",
                width: 100,
                height: 84,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 2,
                mt: 1.5,
                // color:'#14348D'
              }}
            >
              <img src={icon} alt="icon" />
            </Box>
          )}

          <Box
            sx={{
              mt: icon ? 8 : 2,
              width: "100%",
              textAlign: "center",
              zIndex: 3,
            }}
          >
            <Typography
              variant="h6"
              gutterBottom
              sx={{ fontFamily: "Montserrat", fontWeight: "600" }}
            >
              {title}
            </Typography>
            <Typography
              color="text.secondary"
              mb={3}
              // sx={{ fontFamily: "Montserrat" }}
              // className="text-4xl md:text-3xl"

              sx={{
                // Default (Mobile/Smallest)
                fontSize: ".25rem", // (roughly text-xl)

                // Tablet (Medium devices)
                // md = 900px (default MUI breakpoint)
                "@media (min-width: 900px)": { fontSize: ".6rem" }, // (roughly text-2xl)

                // Desktop (Large devices)
                // lg = 1200px
                "@media (min-width: 1200px)": { fontSize: "1rem" }, // (roughly text-4xl)
              }}
            >
              {message}
            </Typography>

            {/* This is where the TextField will live */}
            <Box>{children}</Box>
            <Box>{grandchildren}</Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                gap: "20px",
                mb: 3,
              }}
            >
              <Button
                onClick={onClose}
                sx={{
                  width: "40%",
                  borderRadius: "10px",
                  border: "1px solid #ccc",
                  color: "black",
                  textTransform: "none",
                }}
              >
                {cancelText}
              </Button>
              <Button
                variant="contained"
                color={variant === "error" ? "error" : "primary"}
                onClick={onConfirm}
                sx={{
                  width: "40%",
                  borderRadius: "10px",
                  textTransform: "none",
                  background: "#14348D",
                }}
              >
                {confirmText}
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </Modal>
  );
}
