import { Box } from "@mui/material";
import React from "react";

const CustomCard = ({ style, children }) => {
  return (
    <Box
      {...style}
      className="border border-gray-300 rounded-[12px] bg-white shadow-sm"
    >
      {children}
    </Box>
  );
};

export default CustomCard;
