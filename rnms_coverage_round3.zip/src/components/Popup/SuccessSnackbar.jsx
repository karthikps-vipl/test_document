 /***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : ContextMenu 
   File Name                : SuccessSnackbar.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Popup\SuccessSnackbar.jsx
   Purpose                  : Reusable Popup
   Created Date             : 03-02-2026
 ***********************************************************************************************/
import React from 'react';
 import { Alert } from 'antd';

const SuccessSnackbar = ({ open, message, onClose }) => {
  // Debugging console log to check props
  console.log("SuccessSnackbar props:", { open, message, onClose });

  // Log when the component renders
  console.log("SuccessSnackbar rendering");

  return (
    
    <>
    {open && (
      <Alert
        title="Success!"
        description={message || "Operation completed successfully."}  
        type="success"
        showIcon
        onClose={onClose}
        
      />
    )}
    </>
    
  );
};

export default SuccessSnackbar;