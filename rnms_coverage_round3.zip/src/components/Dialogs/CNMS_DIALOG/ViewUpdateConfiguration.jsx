import React, { useCallback, useEffect, useState } from "react";
import {
  Box,
  Typography,
  Divider,
  TextField,
  useTheme,
  CircularProgress,
} from "@mui/material";
import { Update } from "@mui/icons-material";
import { useFormik, getIn } from "formik";
import * as Yup from "yup";

import { useDispatch, useSelector } from "react-redux";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";

import Toast from "@/components/Reusable/Toast/Toast";

import { FETCH_CNMS_DETAILS } from "../../../RestAPI/url/endpoint";

import { InventoryAxios } from "@/RestAPI/api/axiosApicall";

import DCicon from "@/assets/CNMS/DCicon.png";
import { UPDATE_CNMS_CONFIGURATION } from "@/RestAPI/url/cnmsendpoint";
import CustomSwitch from "@/components/Switch/CustomSwitch";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import { updateCnmsDetailsFromSidebar } from "@/store/features/nodeDetailsSlice";

const UNIT_NAME_REGEX = /^[a-zA-Z0-9 ]*$/;

const Field = ({
  label,
  name,
  formik,
  disabled = false,
  required = false,
  type = "text",
  fieldType,
}) => {
  const value = getIn(formik.values, name);
  const touched = getIn(formik.touched, name);
  const fieldError = getIn(formik.errors, name);

  const error = !disabled && touched && Boolean(fieldError);

  const handleChange = (event) => {
    let newValue = event.target.value;
    // Ensure 'name' is captured correctly from the event
    const name = event.target.name;
    // Ensure 'fieldType' is available in your scope

    /*
     * ---------------------------------------------------------
     * LATITUDE / LONGITUDE
     * ---------------------------------------------------------
     */
    if (fieldType === "latitude" || fieldType === "longitude") {
      // const latLongRegex = /^[-]?\d*\.?\d{0,6}$/;
      const latLongRegex = /^-?\d*\.?\d{0,6}$/; 

      if (!latLongRegex.test(newValue)) {
        return;
      }
      const isNegative = newValue.startsWith("-");

      const cleanValue = isNegative ? newValue.substring(1) : newValue;

      // Split only if there is a decimal point
      const parts = cleanValue.split(".");
      const integerPart = parts[0];
      const decimalPart = parts[1];

      // 3. Validate Integer Part Length (excluding the minus sign)
      // Latitude: Max 3 digits (e.g., 90 or -90)
      // Longitude: Max 3 digits (e.g., 180 or -180)
      if (integerPart.length > 3) {
        return;
      }

      // 4. Validate Decimal Part Length
      if (decimalPart && decimalPart.length > 6) {
        return;
      }

      formik.setFieldValue(name, newValue, true);
      formik.setFieldTouched(name, true, false);

      return;
    }

    if (fieldType === "unitName") {
      if (!/^[a-zA-Z0-9 ]*$/.test(newValue)) {
        return;
      }

      if (newValue.length > 30) {
        return;
      }

      formik.setFieldValue(name, newValue);
      formik.setFieldTouched(name, true, false);

      return;
    }

    formik.handleChange(event);
  };

  return (
    <Box sx={{ flex: 1 }}>
      <Typography
        sx={{
          fontSize: 13,
          mb: 0.6,
          fontWeight: 600,
          color: disabled ? "text.disabled" : "text.primary",
        }}
      >
        {label}

        {required && (
          <Typography
            component="span"
            sx={{
              color: "error.main",
              ml: 0.3,
            }}
          >
            *
          </Typography>
        )}
      </Typography>

      <TextField
        fullWidth
        size="small"
        name={name}
        type={type}
        value={value ?? ""}
        onChange={handleChange}
        onBlur={formik.handleBlur}
        disabled={disabled}
        error={error}
        helperText={error ? fieldError : ""}
        inputProps={
          fieldType === "latitude" || fieldType === "longitude"
            ? {
                inputMode: "decimal",
              }
            : fieldType === "unitName"
            ? {
                maxLength: 30,
              }
            : undefined
        }
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "10px",
          },

          "& .MuiOutlinedInput-root.Mui-disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.025)",
          },
        }}
      />
    </Box>
  );
};

const ConfigurationCard = ({ site, index, formik, editMode }) => {
  const sitePrefix = `site${index}`;
  console.log("sitePrefix:", sitePrefix);

  return (
    <Box
      sx={{
        flex: 1,
        minWidth: 0,
        border: "1px solid",
        borderColor: "divider",
        borderRadius: "16px",
        p: 2.5,
        backgroundColor: "background.paper",
        boxShadow: "0px 2px 8px rgba(0, 0, 0, 0.05)",
      }}
    >
      {/* SITE HEADER */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1.2,
          mb: 2,
        }}
      >
        <Box
          component="img"
          src={DCicon}
          alt="DC"
          sx={{
            width: 28,
            height: 28,
            objectFit: "contain",
          }}
        />

        <Typography
          sx={{
            fontSize: 15,
            fontWeight: 700,
            textTransform: "uppercase",
          }}
        >
          {site?.siteNickName || "-"}
        </Typography>
      </Box>

      <Divider sx={{ mb: 2.5 }} />

      {/* ROW 1 */}
      <Box
        sx={{
          display: "flex",
          gap: 2,
          mb: 2,
        }}
      >
        <Field
          label="Name"
          name={`${sitePrefix}.siteName`}
          formik={formik}
          disabled
        />

        <Field
          label="Unit Name"
          name={`${sitePrefix}.siteNickName`}
          formik={formik}
          disabled={!editMode}
          required
          fieldType="unitName"
        />
      </Box>

      {/* ROW 2 */}
      <Box
        sx={{
          display: "flex",
          gap: 2,
        }}
      >
        <Field
          label="Latitude (Dec)"
          name={`${sitePrefix}.latitude`}
          formik={formik}
          disabled={!editMode}
          required
          type="text"
          fieldType="latitude"
        />

        <Field
          label="Longitude (Dec)"
          name={`${sitePrefix}.longitude`}
          formik={formik}
          disabled={!editMode}
          required
          type="text"
          fieldType="longitude"
        />
      </Box>
    </Box>
  );
};

const ViewUpdateConfiguration = ({ node, onClose }) => {
  const theme = useTheme();

  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [cnmsDetails, setCnmsDetails] = useState([]);

  console.log("jfhucnmsDetails", cnmsDetails?.[0]?.siteName);

  const dispatch = useDispatch();

  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  /*
   * ---------------------------------------------------------
   * FETCH CNMS DETAILS
   * ---------------------------------------------------------
   */

  const fetchNodeDetails = useCallback(async () => {
    try {
      setFetching(true);

      const response = await InventoryAxios(FETCH_CNMS_DETAILS, "get");

      if (response?.data) {
        setCnmsDetails(Array.isArray(response.data) ? response.data : []);
      } else {
        setCnmsDetails([]);
      }
    } catch (error) {
      console.error("CNMS details fetch error:", error);

      Toast("Error", "Failed to fetch CNMS configuration details.", "error");

      setCnmsDetails([]);
    } finally {
      setFetching(false);
    }
  }, []);

  useEffect(() => {
    fetchNodeDetails();
  }, [fetchNodeDetails]);

  /*
   * ---------------------------------------------------------
   * FORMIK
   * ---------------------------------------------------------
   */

  const initialValues = cnmsDetails.reduce((acc, site, index) => {
    acc[`site${index}`] = {
      siteName: site?.siteName || "",
      siteNickName: site?.siteNickName || "",
      latitude: site?.latitude ?? "",
      longitude: site?.longitude ?? "",
    };

    return acc;
  }, {});

  const handleUpdate = async () => {
    const errors = await formik.validateForm();

    if (Object.keys(errors).length > 0) {
      formik.setTouched(
        cnmsDetails.reduce((acc, site, index) => {
          acc[`site${index}`] = {
            siteNickName: true,
            latitude: true,
            longitude: true,
          };

          return acc;
        }, {}),
        true
      );
      return;
    }

    formik.submitForm();
  };

  const validationSchema = Yup.object(
    cnmsDetails.reduce((acc, site, index) => {
      acc[`site${index}`] = Yup.object({
        latitude: Yup.string()
          .required("Latitude is required")
          .matches(
            // FIX: Added [-]? at the start to allow negative numbers
            // /^[-]?\d*\.?\d{0,6}$/,
            /^-?\d*\.?\d{0,6}$/,
            "Latitude must have up to 3 digits before decimal and up to 6 digits after decimal"
          )
          .test(
            "latitude-range",
            "Latitude must be between -90 and 90",
            (value) => {
              if (!value) return true;
              const numVal = parseFloat(value);
              return numVal >= -90 && numVal <= 90;
            }
          ),

        longitude: Yup.string()
          .required("Longitude is required")
          .matches(
            // FIX: Added [-]? at the start to allow negative numbers
            // /^[-]?\d*\.?\d{0,6}$/,
            /^-?\d*\.?\d{0,6}$/,
            "Longitude must have up to 3 digits before decimal and up to 6 digits after decimal"
          )
          .test(
            "longitude-range",
            "Longitude must be between -180 and 180",
            (value) => {
              if (!value) return true;
              const numVal = parseFloat(value);
              return numVal >= -180 && numVal <= 180;
            }
          ),

        siteNickName: Yup.string()
          .required("Unit Name is required")
          .matches(
            UNIT_NAME_REGEX,
            "Unit Name can contain only letters and numbers"
          )
          .max(30, "Unit Name must not exceed 30 characters"),
      });

      return acc;
    }, {})
  );

  const formik = useFormik({
    enableReinitialize: true,
    initialValues,
    validationSchema,
    validateOnChange: true,
    validateOnBlur: true,

    onSubmit: async (values) => {
      try {
        setLoading(true);

        // Make sure validation has completed
        const errors = await formik.validateForm();

        if (Object.keys(errors).length > 0) {
          formik.setTouched(
            cnmsDetails.reduce((acc, site, index) => {
              acc[`site${index}`] = {
                latitude: true,
                longitude: true,
              };

              return acc;
            }, {}),
            true
          );

          return;
        }

        const payload = cnmsDetails.map((site, index) => {
          const formSite = values[`site${index}`];

          return {
            isConfigured: site?.isConfigured ?? true,

            siteName: formSite?.siteName ?? site?.siteName ?? "",

            siteNickName: formSite?.siteNickName ?? site?.siteNickName ?? "",

            latitude: Number(formSite?.latitude),

            longitude: Number(formSite?.longitude),

            remoteNumber: site?.remoteNumber,

            id: site?.id,

            imTerminalType: {
              id: site?.imTerminalType?.id ?? 1,
            },
          };
        });

        console.log("UPDATE CNMS PAYLOAD:", payload);

        const response = await InventoryAxios(
          UPDATE_CNMS_CONFIGURATION,
          "post",
          payload
        );

        if (response?.data) {
          Toast(
            "Success!",
            "CNMS configuration updated successfully.",
            "success"
          );

          setEditMode(false);

          dispatch(updateCnmsDetailsFromSidebar(response?.data));

          await fetchNodeDetails();
        } else {
          Toast("Error!", "Failed to update CNMS configuration.", "error");
        }
      } catch (error) {
        console.error("CNMS configuration update error:", error);

        Toast("Error!", "Failed to update CNMS configuration.", "error");
      } finally {
        setLoading(false);
      }
    },
  });

  const handleToggleEdit = () => {
    if (editMode) {
      formik.resetForm();
    }

    setEditMode((prev) => !prev);
  };

  if (fetching) {
    return (
      <Box
        sx={{
          minHeight: 300,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        p: 3,
        width: "100%",
      }}
    >
      {/* HEADER */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          position: "relative",
          minHeight: 40,
        }}
      >
        <Typography
          sx={{
            fontWeight: 600,
            color: theme.palette.text.TitleTextcolor,
            fontSize: 18,
          }}
        >
          CNMS Configuration Details
        </Typography>

        {/* TOP RIGHT ACTIONS */}
        <Box
          sx={{
            position: "absolute",
            right: 0,
            top: 0,
            display: "flex",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          <CustomeFullscreen
            onClose={onClose}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </Box>
      </Box>

      <Divider sx={{ my: 2 }} />

      {/* VIEW / MODIFY */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          gap: 1.5,
          mb: 2.5,
        }}
      >
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: !editMode ? "primary.main" : "text.secondary",
          }}
        >
          View
        </Typography>

        <CustomSwitch checked={editMode} onChange={handleToggleEdit} />

        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: editMode ? "primary.main" : "text.secondary",
          }}
        >
          Modify
        </Typography>
      </Box>

      {/* CNMS CARDS */}
      {cnmsDetails.length > 0 ? (
        <Box
          sx={{
            display: "flex",
            gap: 2.5,
            width: "100%",
          }}
        >
          {cnmsDetails.map((site, index) => (
            <ConfigurationCard
              key={site?.id || index}
              site={site}
              index={index}
              formik={formik}
              editMode={editMode}
            />
          ))}
        </Box>
      ) : (
        <Box
          sx={{
            py: 6,
            display: "flex",
            justifyContent: "center",
          }}
        >
          <Typography color="text.secondary">
            No CNMS configuration details found.
          </Typography>
        </Box>
      )}

      {/* UPDATE BUTTON */}
      {editMode && cnmsDetails.length > 0 && (
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            mt: 3,
          }}
        >
          <MButtonPrimary
            variant="contained"
            color="primary"
            sx={{
              borderRadius: "8px",
              px: 4,
            }}
            onClick={handleUpdate}
            disabled={loading}
            startIcon={
              loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            {loading ? "Updating..." : "Update"}
          </MButtonPrimary>
        </Box>
      )}
    </Box>
  );
};

export default ViewUpdateConfiguration;
