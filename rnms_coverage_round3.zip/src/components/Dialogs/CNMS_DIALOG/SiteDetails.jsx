import { Box, DialogContent } from "@mui/material";
import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";


import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import MTable from "@/components/Reusable/Table/MTable";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";

const SiteDetails = ({ onClose }) => {
  const fetchSiteDetails = useSelector(
    (state) => state.remoteRepDetails.fetchSiteDetails || []
  );

  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  const [data, setData] = useState([]);
  const dispatch = useDispatch();

  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "70px",
    },
    {
      uid: "terminal",
      name: "Terminal",
      width: "180px",
    },
    {
      uid: "siteId",
      name: "Site ID",
      width: "120px",
    },
    {
      uid: "siteName",
      name: "Site Name",
      width: "180px",
    },
    {
      uid: "ipAddress",
      name: "IP Address",
      width: "180px",
    },
    {
      uid: "latitude",
      name: "Latitude",
      width: "120px",
    },
    {
      uid: "longitude",
      name: "Longitude",
      width: "120px",
    },
    {
      uid: "mode",
      name: "Mode",
      width: "130px",
    },
    {
      uid: "status",
      name: "Status",
      width: "180px",
    },
  ];

  const fillTable = useCallback(() => {
    // API response is an object with numeric keys:
    // {
    //   "0": {...},
    //   "1": {...}
    // }
    //
    // Convert it into an array before mapping.
    const siteDetailsArray = Array.isArray(fetchSiteDetails)
      ? fetchSiteDetails
      : Object.values(fetchSiteDetails);

    const rowData = siteDetailsArray.map((site, index) => {
      // Extract only the number from siteId.
      // Example: MCT-LSV_007 -> 007
      const extractedSiteId =
        site?.siteId?.split("_").pop() || "NA";

      return {
        ...site,

        sno: index + 1,

        terminal:
          site?.imTerminalType?.terminalTypeName || "NA",

        siteId: extractedSiteId,

        siteName: site?.siteName || "NA",

        ipAddress: site?.ipaddress || "NA",

        latitude:
          site?.latitude !== null && site?.latitude !== undefined
            ? site.latitude
            : "NA",

        longitude:
          site?.longitude !== null && site?.longitude !== undefined
            ? site.longitude
            : "NA",

        mode: site?.imTerminalMode?.name || "NA",

        status: site?.healthStatus?.value || "NA",
      };
    });

    setData(rowData);
  }, [fetchSiteDetails]);

  useEffect(() => {
    fillTable();
  }, [fillTable]);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  return (
    <Box>
      <DialogContent>
        <Box sx={{ borderRadius: "20px" }}>
          <MTable
            tableTitle="Site Details"
            columns={columns}
            tableData={data}
            showSearch={true}
            handleDownloadPDF={() => {
              const sanitizedName = "Site_Details".replace(/\s+/g, "_");
              const normalName = "Site_Details";

              exportToPDF(
                `${normalName} Report`,
                columns,
                data,
                `${sanitizedName}_Report`,
                "NMS User"
              );
            }}
            showPagination={true}
            handleClose={onClose}
            closeIcon={true}
            showMaximazed={true}
            isMaximized={isTableMaximized}
            toggleMaximize={handleToggleMaximize}
          />
        </Box>
      </DialogContent>
    </Box>
  );
};

export default SiteDetails;