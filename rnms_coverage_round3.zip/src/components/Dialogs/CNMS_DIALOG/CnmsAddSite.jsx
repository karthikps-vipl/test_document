import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Radio,
  RadioGroup,
  FormControlLabel,
  Divider,
  useTheme,
  CircularProgress,
} from "@mui/material";

import { useDispatch, useSelector } from "react-redux";

import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { CNMS_ADD_SITE } from "@/RestAPI/url/cnmsendpoint";

import Toast from "@/components/Reusable/Toast/Toast";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";

import {
  setCnmsDeleteAddSite,
  setSiteMoveToMaintaiance,
  startBlink,
  stopBlink,
} from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";

import { isValidIpV4 } from "@/utility/FormValidation/YupSchema";

import { Update } from "@mui/icons-material";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import { updateSiteSummarySite } from "@/store/features/Cnms/SiteSummary/siteSummarySlice";

/* =========================================================
   IPv6 VALIDATION
   ========================================================= */

const isValidIPv6 = (value) => {
  if (!value) return false;

  const ip = value.trim();

  // IPv6 must contain at least one colon
  if (!ip.includes(":")) {
    return false;
  }

  // Only hexadecimal characters, colon and dot are allowed
  if (!/^[0-9a-fA-F:.]+$/.test(ip)) {
    return false;
  }

  // IPv4 embedded IPv6
  if (ip.includes(".")) {
    const lastColon = ip.lastIndexOf(":");

    if (lastColon === -1) {
      return false;
    }

    const ipv4Part = ip.substring(lastColon + 1);

    const ipv4Parts = ipv4Part.split(".");

    if (ipv4Parts.length !== 4) {
      return false;
    }

    const validIPv4 = ipv4Parts.every((part) => {
      if (!/^\d+$/.test(part)) return false;

      const number = Number(part);

      return number >= 0 && number <= 255;
    });

    if (!validIPv4) {
      return false;
    }
  }

  // "::" can occur only once
  const doubleColonCount = (ip.match(/::/g) || []).length;

  if (doubleColonCount > 1) {
    return false;
  }

  const hasCompression = ip.includes("::");

  let address = ip;

  /*
   * Temporarily replace IPv4 portion because
   * IPv4 occupies two IPv6 groups.
   */
  if (ip.includes(".")) {
    const lastColon = ip.lastIndexOf(":");

    address = ip.substring(0, lastColon) + ":ipv4";

    // IPv4 = 2 IPv6 groups
  }

  let leftGroups = [];
  let rightGroups = [];

  if (hasCompression) {
    const parts = address.split("::");

    if (parts.length !== 2) {
      return false;
    }

    leftGroups = parts[0] ? parts[0].split(":") : [];

    rightGroups = parts[1] ? parts[1].split(":") : [];
  } else {
    leftGroups = address.split(":");
  }

  const isValidGroup = (group) => {
    if (group === "ipv4") {
      return true;
    }

    return /^[0-9a-fA-F]{1,4}$/.test(group);
  };

  if (!leftGroups.every(isValidGroup) || !rightGroups.every(isValidGroup)) {
    return false;
  }

  /*
   * IPv4 portion represents TWO IPv6 groups.
   */
  const ipv4Groups = address.includes("ipv4") ? 2 : 0;

  const totalGroups = leftGroups.length + rightGroups.length + ipv4Groups;

  if (hasCompression) {
    /*
     * "::" must replace at least one group.
     */
    return totalGroups < 8;
  }

  /*
   * Without "::", exactly 8 groups.
   */
  return totalGroups === 8;
};

/* =========================================================
   COMPONENT
   ========================================================= */

const CnmsAddSite = ({ node, onClose }) => {
  const theme = useTheme();
  const dispatch = useDispatch();

  console.log("nodeaddsite", node);
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const [ipVersion, setIpVersion] = useState("IP V4");

  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    ip: node?.ipaddress || "",
    description: "",
  });

  const [touched, setTouched] = useState({
    ip: false,
    description: false,
  });

  const { ip, description } = formData;

  /* =========================================================
     VALIDATE IP
     ========================================================= */

  const getIpError = () => {
    if (!ip.trim()) {
      return "Should not be empty";
    }

    if (ipVersion === "IP V4") {
      const validIPv4 = isValidIpV4(ip);

      if (!validIPv4) {
        return "Invalid IPv4 Address";
      }
    }

    if (ipVersion === "IP V6") {
      const validIPv6 = isValidIPv6(ip);

      if (!validIPv6) {
        return "Invalid IPv6 Address";
      }
    }

    return "";
  };

  /* =========================================================
     VALIDATE DESCRIPTION
     ========================================================= */

  const getDescriptionError = () => {
    if (!description.trim()) {
      return "Should not be empty";
    }

    if (description.trim().length < 3) {
      return "Must be length of 3";
    }

    if (description.trim().length > 255) {
      return "Must be length of 255";
    }

    return "";
  };

  const ipError = getIpError();
  const descriptionError = getDescriptionError();

  const isFormValid = !ipError && !descriptionError;

  /* =========================================================
     IP VERSION CHANGE
     ========================================================= */

  const handleIpVersionChange = (event) => {
    const newVersion = event.target.value;

    setIpVersion(newVersion);

    /*
     * Don't clear the IP.
     * Revalidate the same IP against the newly selected version.
     */
    setTouched((prev) => ({
      ...prev,
      ip: true,
    }));
  };

  /* =========================================================
     IP CHANGE
     ========================================================= */

  const handleIpChange = (event) => {
    let value = event.target.value;

    if (ipVersion === "IP V4") {
      value = value.replace(/[^\d.]/g, "");

      value = value.replace(/\.{2,}/g, ".");

      const octets = value.split(".").slice(0, 4);

      value = octets.map((octet) => octet.slice(0, 3)).join(".");
    }

    if (ipVersion === "IP V6") {
      /*
       * IPv6 allows:
       * 0-9
       * a-f
       * A-F
       * :
       * .
       */
      value = value.replace(/[^0-9a-fA-F:.]/g, "");
    }

    setFormData((prev) => ({
      ...prev,
      ip: value,
    }));

    setTouched((prev) => ({
      ...prev,
      ip: true,
    }));
  };

  useEffect(() => {
    if (node?.ipaddress) {
      setFormData((prev) => ({
        ...prev,
        ip: node.ipaddress,
      }));
    }
  }, [node?.ipaddress]); // This triggers whenever the incoming IP changes

  /* =========================================================
     DESCRIPTION CHANGE
     ========================================================= */

  const handleDescriptionChange = (event) => {
    const value = event.target.value;

    setFormData((prev) => ({
      ...prev,
      description: value,
    }));

    setTouched((prev) => ({
      ...prev,
      description: true,
    }));
  };

  /* =========================================================
     ADD BUTTON
     ========================================================= */

  const handleAddClick = async () => {
    /*
     * Mark fields as touched.
     */
    setTouched({
      ip: true,
      description: true,
    });

    /*
     * Stop if validation fails.
     */
    if (!isFormValid) {
      return;
    }

    /*
     * Prevent duplicate API calls.
     */
    if (isSubmitting) {
      return;
    }

    try {
      setIsSubmitting(true);

      const payload = {
        ...node,
        discovered: false,
        isMaintainance: true,
        ipaddress: ip.trim(),
        remarks: description.trim(),
      };

      console.log("ADD SITE PAYLOAD:", payload);

      const response = await InventoryAxios(CNMS_ADD_SITE, "post", payload);
      const addSiteMessage = response?.data?.discoverStatus;
      let maintenanceType = response?.data?.maintenanceType;
      let status = -1;
      let statusValue = "";
      if (response?.data?.discovered) {
        status = 1;
        statusValue = "UP";
      } else if (response?.data?.isMaintainance) {
        status = 3;
        statusValue = "MAINTENANCE";
      } else {
        console.log(
          "isMaintainance and discovered both are false or undefined"
        );

        status = response?.data?.healthStatus?.id;
        statusValue = response?.data?.healthStatus?.value;
      }

      onClose();

      dispatch(
        startBlink({
          siteId: payload.siteId,
          maintenanceType: 0, //add site
        })
      );
      setTimeout(() => {
        dispatch(stopBlink(payload.siteId));
        dispatch(
          setSiteMoveToMaintaiance({
            isMaintainance: response?.data.isMaintainance,
            discovered: response?.data.discovered,
            siteId: response?.data.siteId,
            healthStatusId: status,
            maintenanceType: maintenanceType,
            healthStatusValue: statusValue,
          })
        ); // reducer to update data of site on map

        if (response?.data) {
          Toast("Success!", addSiteMessage, "success");
        } else {
          Toast("Error!", "Failed to add device", "error");
        }
      }, 10000);

      dispatch(setCnmsDeleteAddSite(response?.data));
      dispatch(updateSiteSummarySite(response?.data));
    } catch (error) {
      console.error("ADD SITE API ERROR:", error);

      /*
       * ERROR TOAST
       */
      Toast(
        "Error!",
        error?.response?.data?.message || "Failed to add device",
        "error"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  /* =========================================================
     MAXIMIZE
     ========================================================= */

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  /* =========================================================
     UI
     ========================================================= */

  return (
    <Box
      sx={{
        p: 3,
        width: "100%",
      }}
    >
      {/* HEADER */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          position: "relative",
          minHeight: 40,
        }}
      >
        <Typography
          variant="body2"
          sx={{
            fontWeight: 600,
            color: theme.palette.text.TitleTextcolor,
            fontSize: 18,
          }}
        >
          {`ADD SITE - ${node.siteName}`}
        </Typography>

        <Box
          sx={{
            position: "absolute",
            right: 0,
            top: 0,
            display: "flex",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          <CustomeFullscreen
            onClose={onClose}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </Box>
      </Box>

      <Divider />

      {/* IP VERSION */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          mb: 1,
        }}
      >
        <RadioGroup
          value={ipVersion}
          onChange={handleIpVersionChange}
          sx={{
            width: "100%",
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
          }}
        >
          <FormControlLabel
            value="IP V4"
            control={<Radio />}
            label="IP V4"
            sx={{ ml: 0 }}
          />

          <FormControlLabel
            value="IP V6"
            control={<Radio />}
            label="IP V6"
            sx={{ ml: 0 }}
          />
        </RadioGroup>
      </Box>

      {/* IP ADDRESS */}
      <TextField
        fullWidth
        size="small"
        variant="outlined"
        label="IP Address*"
        name="ip"
        value={ip}
        onChange={handleIpChange}
        error={touched.ip && Boolean(ipError)}
        helperText={
          touched.ip && ipError
            ? ipError
            : ipVersion === "IP V4"
            ? "Example: 192.168.1.100"
            : "Example: 2001:db8::1"
        }
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "12px",
          },
          marginBottom: "15px",
        }}
      />

      {/* DESCRIPTION */}
      <TextField
        fullWidth
        size="small"
        variant="outlined"
        label="Description"
        name="description"
        value={description}
        onChange={handleDescriptionChange}
        multiline
        minRows={2}
        maxRows={3}
        error={touched.description && Boolean(descriptionError)}
        helperText={
          touched.description && descriptionError ? descriptionError : ""
        }
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "12px",
          },
          marginBottom: "16px",
        }}
      />

      {/* FOOTER */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          gap: 2,
        }}
      >
        <MButtonSecondary disabled={isSubmitting} onClick={onClose}>
          CANCEL
        </MButtonSecondary>

        <MButtonPrimary
          variant="contained"
          disabled={isSubmitting}
          onClick={handleAddClick}
          startIcon={
            isSubmitting ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              <Update />
            )
          }
        >
          {isSubmitting ? "Adding..." : "ADD"}
        </MButtonPrimary>
      </Box>
    </Box>
  );
};

export default CnmsAddSite;
