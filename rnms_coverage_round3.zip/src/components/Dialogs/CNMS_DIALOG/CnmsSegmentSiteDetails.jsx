import { Box, DialogContent } from "@mui/material";
import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useModalStore } from "@/core/modal/modalStore";

import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MTable from "@/components/Reusable/Table/MTable";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_SITEDETAILS_BY_TERMINALTYPE_ID } from "@/RestAPI/url/cnmsendpoint";

const CnmsSegmentSiteDetails = () => {
  const { modalProps, closeModal } = useModalStore();
  const segment = modalProps?.node;

  const id = segment?.imTerminalType?.id;

  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  const dispatch = useDispatch();

  const [data, setData] = useState([]);

  console.log("RNMSSiteDetails segment", segment);
  console.log("RNMSSiteDetails terminalTypeId", id);

  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "70px",
    },
    {
      uid: "siteID",
      name: "Site ID",
      width: "120px",
    },
    {
      uid: "siteName",
      name: "Site Name",
      width: "200px",
    },
    {
      uid: "groups",
      name: "Groups",
      width: "200px",
    },
    {
      uid: "ipAddress",
      name: "IP Address",
      width: "180px",
    },
    {
      uid: "latitude",
      name: "Latitude",
      width: "130px",
    },
    {
      uid: "longitude",
      name: "Longitude",
      width: "130px",
    },
    {
      uid: "mode",
      name: "Mode",
      width: "130px",
    },
    {
      uid: "status",
      name: "Status",
      width: "180px",
    },
  ];

  const fetchSiteDetails = useCallback(async () => {
    if (!id) {
      console.warn("Terminal Type ID is not available");
      return;
    }

    try {
      await InventoryAxios(
        `${FETCH_SITEDETAILS_BY_TERMINALTYPE_ID}/${id}`,
        "get"
      )
        .then((res) => {
          console.log("Site Details API Response", res?.data);

          const responseData = res?.data || [];

          const rowData = responseData.map((site, index) => {
            // Extract only the numeric portion from siteId
            // Example: MCT-LSV_007 -> 007
            const siteId = site?.siteId ? site.siteId.split("_").pop() : "";

            return {
              ...site,
              index: index + 1,
              siteID: siteId,
              siteName: site?.siteName || "NA",
              groups: Array.isArray(site?.groupList)
                ? site.groupList.map((group) => group.groupName).join(", ")
                : "NA",
              ipAddress: site?.ipaddress || "NA",
              latitude: site?.latitude ?? "NA",
              longitude: site?.longitude ?? "NA",
              mode: site?.imTerminalMode?.name || "NA",
              status: site?.healthStatus?.value || "NA",
            };
          });

          setData(rowData);
        })
        .catch((error) => {
          console.error("Error fetching site details:", error);
          setData([]);
        });
    } catch (error) {
      console.error("Error fetching site details:", error);
      setData([]);
    }
  }, [id]);

  useEffect(() => {
    fetchSiteDetails();
  }, [fetchSiteDetails]);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  return (
    <Box>
      <DialogContent>
        <Box sx={{ borderRadius: "20px" }}>
          <MTable
            tableTitle="RNMS Site Details"
            columns={columns}
            tableData={data}
            showSearch={true}
            handleDownloadPDF={() => {
              const sanitizedName = "RNMS_Site_Details".replace(/\s+/g, "_");
              const normalName = "RNMS Site Details";

              exportToPDF(
                `${normalName} Report`,
                columns,
                data,
                `${sanitizedName}_Report`,
                "NMS User"
              );
            }}
            showPagination={true}
            handleClose={closeModal}
            closeIcon={true}
            showMaximazed={true}
            isMaximized={isTableMaximized}
            toggleMaximize={handleToggleMaximize}
          />
        </Box>
      </DialogContent>
    </Box>
  );
};

export default CnmsSegmentSiteDetails;
