import { useModalStore } from "@/core/modal/modalStore";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID,
  FETCH_SITE_RESOURCE_PORT_INFO,
} from "@/RestAPI/url/cnmsendpoint";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import {
  setCNMSDeviceStats,
  setCurrentViewCnmsTopology,
  setInitialEdges,
} from "@/store/features/Topology/topologyNodesslice";
import {
  Box,
  Divider,
  Typography,
  useTheme,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import LegendStatus from "@/Pages/Rnmsdashboard/PortStatus/LegendStatus";
import { severityConfig } from "@/Pages/Rnmsdashboard/AlarmDrawer/utils";
import TopologyWrapper from "@/Pages/Rnmsdashboard/Topology/TopologyWrapper";
import {
  toTopologyEdges,
  toTopologyNodes,
} from "@/Pages/Rnmsdashboard/Topology/cnmsTopologyAdapter";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import Toast from "@/components/Reusable/Toast/Toast";

const CnmsTopology = ({ onClose }) => {
  const { modalProps } = useModalStore();
  const dispatch = useDispatch();
  const theme = useTheme();
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const cnmsVehicle = modalProps?.node;

  console.log("Cnmsvehicledata", cnmsVehicle);

  const modalHeader =
    cnmsVehicle?.siteId + " : " + cnmsVehicle?.siteName + " - ";

  // CNMS context — drives saved-JSON lookup + engine selection
  const Rnms_TerminalType = cnmsVehicle?.imTerminalType?.terminalTypeName || "";

  const Rnms_siteID = cnmsVehicle?.siteId || "";

  console.log("Rnms_TerminalType", Rnms_TerminalType);
  console.log("Rnms_siteID", Rnms_siteID);

  const [resources, setResources] = useState([]);
  const [resourcesLoading, setResourcesLoading] = useState(false);

  console.log("cnmsresources", resources);

  // -------------------------------------------------------------------
  // DATA LOADING
  // -------------------------------------------------------------------
  useEffect(() => {
    if (!Rnms_siteID) {
      setResources([]);
      return;
    }

    let cancelled = false;

    const loadSiteResourceData = async () => {
      setResourcesLoading(true);

      try {
        const [resourceResponse, portResponse] = await Promise.all([
          InventoryAxios(
            `${FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID}/${Rnms_siteID}`,
            "get"
          ),
          InventoryAxios(
            `${FETCH_SITE_RESOURCE_PORT_INFO}/${Rnms_siteID}`,
            "get"
          ),
        ]);

        if (cancelled) return;

        const resourceData = resourceResponse?.data || [];
        const portData = portResponse?.data || [];

        console.log(
          "FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID response:",
          resourceData
        );
        
        console.log("FETCH_SITE_RESOURCE_PORT_INFO response:", portData);

        // Merge port data into the switch resource (unchanged from your code)
        const mergedResources = resourceData.map((resource) => {
          const resourceId = resource?.resourceId;

          if (resourceId !== "MCT_EP_SWITCH-24PORT") {
            return resource;
          }

          const { lstportResourceInfoBean, ...resourceWithoutOldPortInfo } =
            resource;

          return {
            ...resourceWithoutOldPortInfo,
            lstPortInfoDtl: portData,
          };
        });

        console.log(
          "Final merged resources for FabricTopology:",
          mergedResources
        );

        // ------------------------------------------------------------
        // ADAPTER: CNMS JSON -> Topology node shape
        // ------------------------------------------------------------
        const topologyNodes = toTopologyNodes(mergedResources);
        const topologyEdges = toTopologyEdges(mergedResources);

        console.log("cnmsTopologyNodes", topologyNodes);

        // Push into the shared topology slice — Topology reads from here
        // exactly the same way it does for RNMS.
        dispatch(setCNMSDeviceStats(topologyNodes));

        if (topologyEdges.length > 0) {
          dispatch(setInitialEdges(topologyEdges));
        }

        setResources(mergedResources);
      } catch (error) {
        console.error(
          "Failed to load CNMS site resource / port information:",
          error
        );
        Toast("Error","Failed to load CNMS site resource / port information:","error")
        if (!cancelled) {
          setResources([]);
        }
      } finally {
        if (!cancelled) {
          setResourcesLoading(false);
        }
      }
    };

    loadSiteResourceData();

    return () => {
      cancelled = true;
    };
  }, [Rnms_siteID, dispatch]);

  // -------------------------------------------------------------------
  // CLEANUP ON UNMOUNT
  //
  // CRITICAL: CNMS and RNMS share the same Redux slice
  // (topologyNodesslice). If we don't clear on unmount, CNMS nodes
  // can leak into a subsequent RNMS session (or vice versa).
  // -------------------------------------------------------------------
  useEffect(() => {
    return () => {
      dispatch(setCNMSDeviceStats([]));
      dispatch(setInitialEdges([]));
    };
  }, [dispatch]);

  // -------------------------------------------------------------------
  // HANDLERS
  // -------------------------------------------------------------------
  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };
  

  const handleClose = () => {
    dispatch(setCurrentViewCnmsTopology(true)); // Dispatch your required action
    onClose(); // Call the original onClose prop to actually close the modal/view
  };
  // -------------------------------------------------------------------
  // RENDER
  // -------------------------------------------------------------------
  return (
    <Box
      sx={{
        p: 3,
        width: "100%",
      }}
    >
      {/* HEADER */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          position: "relative",
          minHeight: 40,
        }}
      >
        <Typography
          sx={{
            fontWeight: 600,
            color: theme.palette.text.TitleTextcolor,
            fontSize: 18,
          }}
        >
          {modalHeader}RNMS Topology
        </Typography>

        {/* TOP RIGHT ACTIONS */}
        <Box
          sx={{
            position: "absolute",
            right: 0,
            top: 0,
            display: "flex",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          {/* MAXIMIZE / MINIMIZE */}
          <CustomeFullscreen
            onClose={handleClose}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </Box>
      </Box>

      <Divider sx={{ my: 2 }} />
        <TopologyWrapper
          Rnms_TerminalType={Rnms_TerminalType}
          Rnms_siteID={Rnms_siteID}
          resources={resources}
          resourcesLoading={resourcesLoading}
          forceEngine="reactflow"
          readOnly
          terminalTypeOverride={Rnms_TerminalType}
          skipRackLoad
          loading={resourcesLoading}
        />
      {/* )} */}

      {/* LEGEND */}
      <Box
        className="flex justify-around bg-white"
        sx={{ background: theme.palette.background.alaramdrawer }}
      >
        <Box className="flex gap-3 px-4 legend-label">
          <div className="flex gap-1 items-center">
            <div
              className="w-3 h-3 rounded-full"
              style={{ background: severityConfig.MAJOR.dotGradient }}
            ></div>
            <span className="legend-label">Major</span>
          </div>

          <span className="legend-separator">|</span>

          <div className="flex gap-1 items-center">
            <div
              className="w-3 h-3 rounded-full"
              style={{ background: severityConfig.MINOR.dotGradient }}
            ></div>
            <span className="legend-label">Minor</span>
          </div>

          <span className="legend-separator">|</span>

          <div className="flex gap-1 items-center">
            <div
              className="w-3 h-3 rounded-full"
              style={{ background: severityConfig.WARNING.dotGradient }}
            ></div>
            <span className="legend-label">Warning</span>
          </div>
        </Box>
        <Box>
          <LegendStatus alarmPortLegend={true} />
        </Box>
      </Box>
    </Box>
  );
};

export default CnmsTopology;
