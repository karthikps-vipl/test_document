import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  CircularProgress,
  Divider,
  useTheme, // Imported Divider
} from "@mui/material";
import { useModalStore } from "@/core/modal/modalStore";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import { Update } from "@mui/icons-material";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import { useDispatch, useSelector } from "react-redux";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";

const ConfirmDeleteSite = ({ onSubmit, node }) => {
  const { closeModal } = useModalStore();
  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const theme = useTheme();
  const handleConfirm = async () => {
    if (inputValue.toUpperCase() !== "CONFIRM") return;

    setLoading(true);
    try {
      // Execute the onSubmit function passed from CnmsDeleteSite
      // We pass the 'node' object here as requested for the payload
      if (onSubmit) {
        await onSubmit(node);
      }
      closeModal();
      closeModal();
    } catch (error) {
      console.error("Delete Site API Error:", error);
      // We don't closeModal on error so the user can try again
    } finally {
      setLoading(false);
    }
  };

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  // UPDATED HANDLER: Force Uppercase, Only Alphabets, Max 7 chars
  const handleInputChange = (e) => {
    // 1. Convert input to Uppercase immediately
    let value = e.target.value.toUpperCase();

    // 2. Remove any character that is NOT an uppercase letter (A-Z)
    value = value.replace(/[^A-Z]/g, "");

    // 3. Limit to 7 characters (Length of "CONFIRM")
    if (value.length <= 7) {
      setInputValue(value);
    }
  };

  return (
    <Box
      sx={{
        p: 2,
        textAlign: "center",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {/* Warning Header Section */}
      <Box
        sx={{
          p: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 1,
          width: "100%",
          mb: 0, // Removed margin bottom to keep divider close
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box
            sx={{
              backgroundColor: "#14348d",
              color: "#fff",
              borderRadius: "50%",
              width: 40,
              height: 40,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            !
          </Box>
          <Typography
            variant="h6"
            style={{
              color: theme.palette.mode === "dark" ? "#ffffff" : "#14348d",
            }}
            fontWeight="bold"
          >
            WARNING
          </Typography>
        </Box>
        <Box>
          <CustomeFullscreen
            onClose={closeModal}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
            isFullScreenvisible={false}
          />
        </Box>
      </Box>

      {/* Divider added below the warning header */}
      <Divider sx={{ width: "100%", mb: 2 }} />

      <Typography
        variant="body1"
        color="text.secondary"
        mb={2}
        sx={{ fontSize: "0.95rem" }}
      >
        Before performing REMOVE SITE follow the instructions mentioned in
        REMOVE SITE Now.
      </Typography>

      <Typography variant="h6" fontWeight="bold" mb={2}>
        Do you want to perform REMOVE SITE?
      </Typography>

      <Typography variant="body1" mb={2}>
        Please type{" "}
        <strong
          style={{
            color: theme.palette.mode === "dark" ? "#ffffff" : "#14348d",
          }}
        >
          "CONFIRM"
        </strong>{" "}
        to proceed
      </Typography>

      <TextField
        variant="outlined"
        size="medium"
        placeholder="Type here..."
        value={inputValue}
        onChange={handleInputChange}
        error={inputValue.length > 0 && inputValue.length < 7} // Show error if incomplete
        helperText={
          inputValue.length > 0 && inputValue.length < 7
            ? "Must type 'CONFIRM'"
            : ""
        }
        sx={{
          mb: 1,
          "& .MuiOutlinedInput-root": {
            "& fieldset": {
              borderColor: "red",
            },
          },
        }}
      />

      <Typography
        variant="body2"
        color={inputValue.toUpperCase() === "CONFIRM" ? "green" : "red"}
        fontWeight="bold"
        mb={4}
      >
        {inputValue.toUpperCase() === "CONFIRM"
          ? "Ready to confirm"
          : "Please type CONFIRM"}
      </Typography>

      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent: "center",
        }}
      >
        <MButtonPrimary
          variant="contained"
          type="secondary"
          onClick={handleConfirm}
          disabled={inputValue.toUpperCase() !== "CONFIRM" || loading}
          sx={{
            backgroundColor: "#000051",
            color: "#fff",
          }}
          startIcon={loading ? <CircularProgress size={20} /> : <Update />}
        >
          {loading ? "CONFIRMING..." : "CONFIRM"}
        </MButtonPrimary>
        <MButtonSecondary onClick={closeModal}>CANCEL</MButtonSecondary>
      </Box>
    </Box>
  );
};

export default ConfirmDeleteSite;
