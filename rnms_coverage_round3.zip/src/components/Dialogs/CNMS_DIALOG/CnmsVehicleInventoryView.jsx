import React, { useEffect, useState, useCallback } from "react";
import {
  Box,
  Divider,
  Typography,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useModalStore } from "@/core/modal/modalStore";

import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MTable from "@/components/Reusable/Table/MTable";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import {
  FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID,
  FETCH_SITE_DETAILS_BY_ID,
} from "@/RestAPI/url/cnmsendpoint";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";

const CnmsVehicleInventoryView = ({ onClose }) => {
  const { modalProps, closeModal } = useModalStore();
  const segment = modalProps?.node;
  const id = segment?.siteId;
  console.log("kitbd", segment);

  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );
  const dispatch = useDispatch();

  const [siteData, setSiteData] = useState(null);
  const [resourceData, setResourceData] = useState([]);

  const columns = [
    { uid: "sno", name: "S.No", width: "70px" },
    { uid: "name", name: "Name", width: "150px" },
    { uid: "ipAddress", name: "IP Address", width: "130px" },
    { uid: "serialNo", name: "Serial No.", width: "100px" },
    { uid: "firmwareVersion", name: "Firmware Version", width: "140px" },
    { uid: "make", name: "Make", width: "100px" },
    { uid: "model", name: "Model", width: "180px" },
    { uid: "macAddress", name: "MAC Address", width: "150px" },
    { uid: "isDiscovered", name: "Discovered?", width: "100px" },
    { uid: "isMaintainance", name: "Maintenance?", width: "120px" },
  ];

  // --- Step 1: Fetch Site Details ---
  const fetchSiteDetails = useCallback(async () => {
    if (!id) {
      console.warn("Terminal Type ID is not available");
      return;
    }

    try {
      const res = await InventoryAxios(
        `${FETCH_SITE_DETAILS_BY_ID}/${id}`,
        "get"
      );

      const responseData = res?.data || [];

      console.log("cnmsfv", responseData);

      // Assuming the API returns an array. We take the first one or the one matching the context.
      // If the API returns a single object, ensure we handle it.
      const site = responseData;

      setSiteData(site);
      console.log("Site Data Fetched:", site);

      // --- Step 2: Fetch Resource Info (Dependent on Site ID) ---
      if (site?.siteId) {
        fetchResourceInfo(site?.siteId);
      }
    } catch (error) {
      console.error("Error fetching site details:", error);
      setSiteData(null);
    }
  }, [id]);

  // --- Step 2: Fetch Resource Info ---
  const fetchResourceInfo = useCallback(async (siteId) => {
    try {
      const res = await InventoryAxios(
        `${FETCH_ALL_SITE_RESOURCE_INFO_BY_SITEID}/${siteId}`,
        "get"
      );

      const responseData = res?.data || [];
      setResourceData(responseData);
      console.log("Resource Data Fetched:", responseData);
    } catch (error) {
      console.error("Error fetching resource info:", error);
      setResourceData([]);
    }
  }, []);

  useEffect(() => {
    fetchSiteDetails();
  }, [fetchSiteDetails]);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  // Helper to extract numeric ID from strings like "MCT-LSV_007" -> "007"
  const extractNumericId = (str) => str?.split("_").pop() || "NA";

  // Extract site details for the top header (from screenshot)
  const siteName = siteData?.siteName || "NA";
  const siteIdRaw = siteData?.siteId || "NA";
  const siteId = extractNumericId(siteIdRaw);
  const siteIp = siteData?.ipaddress || "NA";
  const siteLat = siteData?.latitude || "NA";
  const siteLong = siteData?.longitude || "NA";
  const Groups = siteData?.groupList || "NA";

  // Prepare Table Data
  const tableData = resourceData.map((res, index) => {
    // Extract Make and Model from imResourceType
    const resourceType = res?.imResourceType;
    const make = resourceType?.make || "NA";
    const model = resourceType?.model || "NA";

    return {
      sno: index + 1,
      name: resourceType?.resourceTypeName || res.resourceName || "NA",
      ipAddress:
        res?.resourceIp ||
        res.imResourceType?.imResourceType?.ipaddress ||
        "NA",
      serialNo: resourceType?.resourceSerialno || "NA",
      firmwareVersion: resourceType?.firmwareVersion || "NA",
      make: make,
      model: model,
      macAddress: res?.macAddress || "NA",
      isDiscovered: res?.isDiscovered ? "Yes" : "No",
      isMaintainance: res?.isMaintainance ? "Yes" : "No",
    };
  });

  return (
    <Box
      sx={{
        p: 3,
        width: "100%",
      }}
    >
      {/* Title on the left, as per screenshot */}
      <Box sx={{ flex: 1 }}>
        <Typography variant="h6" sx={{ fontWeight: "bold" }}>
          {segment?.siteId} : {siteName} - RNMS INVENTORY
        </Typography>

        {/* TOP RIGHT ACTIONS */}
        <Box
          sx={{
            position: "absolute",
            right: 20,
            top: 12,
            display: "flex",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          <CustomeFullscreen
            onClose={onClose}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </Box>
      </Box>

      <Divider sx={{ my: 0.5 }} />

      <Box
        sx={{ display: "flex", gap: 3, flexWrap: "wrap", marginBottom: "10px" }}
      >
        <Box>
          <Typography variant="caption" color="text.secondary">
            Terminal:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {segment?.imTerminalType?.terminalTypeName || "NA"}
          </Typography>
        </Box>
        <Box>
          <Typography variant="caption" color="text.secondary">
            Site ID:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {siteId}
          </Typography>
        </Box>
        <Box>
          <Typography variant="caption" color="text.secondary">
            Site Name:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {siteName}
          </Typography>
        </Box>
        <Box>
          <Typography variant="caption" color="text.secondary">
            IP Address:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {siteIp}
          </Typography>
        </Box>
        <Box>
          <Typography variant="caption" color="text.secondary">
            Latitude:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {siteLat}
          </Typography>
        </Box>
        <Box>
          <Typography variant="caption" color="text.secondary">
            Longitude:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {siteLong}
          </Typography>
        </Box>
        <Box>
          <Typography variant="caption" color="text.secondary">
            Groups:
          </Typography>
          <Typography variant="body2" fontWeight="bold">
            {Groups}
          </Typography>
        </Box>
      </Box>

      {/* MTable Component */}
      <MTable
        columns={columns}
        tableData={tableData}
        showSearch={true}
        handleDownloadPDF={() => {
          const sanitizedName = "Vehicle_Inventory".replace(/\s+/g, "_");
          const normalName = "Vehicle_Inventory";

          exportToPDF(
            `${normalName} Report`,
            columns,
            tableData,
            `${sanitizedName}_Report`,
            "NMS User"
          );
        }}
        showPagination={true}
        handleClose={closeModal}
        closeIcon={false}
        showMaximazed={false}
        isMaximized={isTableMaximized}
        toggleMaximize={handleToggleMaximize}
      />
    </Box>
  );
};

export default CnmsVehicleInventoryView;
