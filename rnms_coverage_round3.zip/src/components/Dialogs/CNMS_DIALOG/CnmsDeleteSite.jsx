import React from "react";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import {
  Box,
  Typography,
  Grid,
  Divider,
  useTheme,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useModalStore } from "@/core/modal/modalStore";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { DELETE_SITE } from "@/RestAPI/url/cnmsendpoint";
import {
  deleteSite,
  setCnmsDeleteSite,
} from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import Toast from "@/components/Reusable/Toast/Toast";
import {
  removeSiteFromSummary,
} from "@/store/features/Cnms/SiteSummary/siteSummarySlice";

const CnmsDeleteSite = ({ onClose, node }) => {
  const { openModal } = useModalStore();
  const theme = useTheme();
  const dispatch = useDispatch();

  const segment = node;
  const HeadersiteName = segment?.siteName || "UNKNOWN";
  const siteName = segment?.treeNode?.label || "UNKNOWN";

  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  const handleActualDeleteApi = async (payload) => {
    try {
      const response = await InventoryAxios(DELETE_SITE, "post", payload);

      // Normalize response to ensure it is always an array for the reducer
      const deletedData = response?.data;
      const normalizedData = Array.isArray(deletedData)
        ? deletedData
        : deletedData
        ? [deletedData]
        : [];

      if (normalizedData.length > 0) {
        dispatch(setCnmsDeleteSite(normalizedData));
        dispatch(removeSiteFromSummary(response?.data));
        dispatch(deleteSite({ siteId: response?.data?.siteId }));
        Toast("Success!", "Site deleted successfully!", "success");
      } else {
        // This handles cases where API returns 200 OK but no data
        Toast(
          "Warning!",
          "Site deleted, but no confirmation received.",
          "warning"
        );
      }
    } catch (error) {
      console.error("API Error:", error);
      Toast("Error!", "An error occurred during deletion", "error");
      throw error;
    }
  };

  const handleDeleteClick = () => {
    openModal("confirmDeleteSite", {
      node,
      siteName,
      // CHANGE THIS: Change 'handleActualDeleteApi' to 'onSubmit'
      // to match the prop name in ConfirmDeleteSite
      onSubmit: handleActualDeleteApi,
    });
  };

  return (
    <>
      {/* Header Section */}
      <Box sx={{ p: 2, width: "100%" }}>
        <Grid
          container
          spacing={0.5}
          alignItems="center"
          sx={{ display: "flex", justifyContent: "space-between" }}
        >
          <Grid item xs={8}>
            <Typography
              sx={{
                fontWeight: 600,
                color: theme.palette.text.TitleTextcolor,
                fontSize: 18,
                textTransform: "uppercase",
              }}
            >
              DELETE SITE {HeadersiteName}
            </Typography>
          </Grid>
          <Grid item xs={4}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                gap: 0.5,
              }}
            >
              <CustomeFullscreen
                onClose={onClose}
                isFullScreen={isMaximized}
                onToggleFullScreen={handleToggleMaximize}
              />
            </Box>
          </Grid>
        </Grid>
      </Box>

      <Divider />

      {/* Main Content Area */}
      <Box
        sx={{
          p: 4,
          textAlign: "center",
          minHeight: "200px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            color: theme.palette.mode === "dark" ? "#ffffff" : "#000",
            marginBottom: "10px",
            textDecoration: "underline",
          }}
        >
          NOTE:
        </Typography>
        <Typography
          variant="body1"
          sx={{
            color: theme.palette.mode === "dark" ? "#ffffff" : "#000",
            lineHeight: 1.6,
            maxWidth: "80%",
          }}
        >
          All Site data shall get deleted from CNMS. Are you sure you want to
          Delete the Site {siteName}?
        </Typography>
      </Box>

      {/* Footer Section */}
      <Box
        sx={{
          p: 2,
          display: "flex",
          justifyContent: "flex-end",
          gap: 2,
          borderTop: "1px solid #e0e0e0",
        }}
      >
        {/* DELETE Button - Opens the new modal */}
        <MButtonPrimary
          variant="contained"
          type="secondary"
          onClick={handleDeleteClick}
          sx={{
            backgroundColor: "#000051",
            color: "#fff",
          }}
        >
          DELETE
        </MButtonPrimary>

        {/* CANCEL Button */}
        <MButtonSecondary onClick={onClose}>CANCEL</MButtonSecondary>
      </Box>
    </>
  );
};

export default CnmsDeleteSite;
