import React from 'react';
import { fireEvent, render, screen, act } from '@testing-library/react';

const mockDispatch = jest.fn();
const mockCanvasInstances = [];

jest.mock('react-redux', () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector({
    nodeDetails: { isCnms: false, repDetails: null },
    inventory: { resources: [] },
    alarmSlice: { badgeCount: [] },
    topologySlice: {
      past: [], future: [], present: null, terminalTypes: [], linkStatusData: [],
    },
  }),
}));

jest.mock('fabric', () => {
  class MockFabricObject {}
  class MockCanvas {
    constructor(element) {
      this.element = element;
      this.handlers = {};
      this.objects = [];
      this.upperCanvasEl = { addEventListener: jest.fn() };
      this.setDimensions = jest.fn();
      this.on = jest.fn((name, handler) => { this.handlers[name] = handler; });
      this.getObjects = jest.fn(() => this.objects);
      this.calcOffset = jest.fn();
      this.requestRenderAll = jest.fn();
      this.dispose = jest.fn();
      this.toJSON = jest.fn(() => ({ objects: [] }));
      this.getActiveObject = jest.fn(() => null);
      this.remove = jest.fn();
      this.discardActiveObject = jest.fn();
      this.add = jest.fn();
      this.setActiveObject = jest.fn();
      this.getActiveObjects = jest.fn(() => []);
      this.setViewportTransform = jest.fn();
      mockCanvasInstances.push(this);
    }
  }
  return {
    Canvas: MockCanvas,
    Rect: class {}, Circle: class {}, Line: class {}, Triangle: class {},
    Group: class {}, Image: { fromURL: jest.fn().mockResolvedValue({ set: jest.fn() }) },
    FabricObject: MockFabricObject,
    loadSVGFromURL: jest.fn().mockResolvedValue({ objects: [] }),
  };
});

jest.mock('../../src/Pages/Rnmsdashboard/Topology/TopologyEditActions', () => (props) => (
  <div data-testid="topology-actions">
    <button onClick={props.onCanvasUndo}>Undo</button>
    <button onClick={props.onCanvasRedo}>Redo</button>
    <button onClick={props.onPortMappingToggle}>Toggle port mapping</button>
    <button onClick={props.onFabricDeleteAll}>Clear canvas</button>
  </div>
));
jest.mock('../../src/Pages/Rnmsdashboard/Topology/Tooltip/NodeTooltip', () => () => null);
jest.mock('@/components/Reusable/Toast/Toast', () => jest.fn());
jest.mock('@/components/Contextmenu/ContextMenu', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/TopologyFabric/PortMapping', () => () => <div>Port mapping panel</div>);
jest.mock('@/components/Reusable/FullScreen/CustomeFullscreen', () => ({
  __esModule: true,
  CustomeFullscreen: (props) => (
    <button onClick={props.onToggleFullScreen}>Fullscreen</button>
  ),
}));

import FabricTopology from '../../src/Pages/Rnmsdashboard/TopologyFabric/FabricTopology';

describe('FabricTopology component', () => {
  beforeEach(() => {
    mockDispatch.mockClear();
    mockCanvasInstances.length = 0;
    global.ResizeObserver = class {
      observe = jest.fn();
      disconnect = jest.fn();
      unobserve = jest.fn();
    };
  });

  afterEach(() => {
    delete global.ResizeObserver;
  });

  test('renders topology surface, canvas and edit actions', () => {
    render(<FabricTopology />);
    expect(document.querySelector('.topology-surface')).toBeInTheDocument();
    expect(document.querySelector('canvas')).toBeInTheDocument();
    expect(screen.getByTestId('topology-actions')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Fullscreen' })).toBeInTheDocument();
    expect(mockCanvasInstances).toHaveLength(1);
  });

  test('dispatches undo and redo actions from toolbar', () => {
    render(<FabricTopology />);
    fireEvent.click(screen.getByRole('button', { name: 'Undo' }));
    fireEvent.click(screen.getByRole('button', { name: 'Redo' }));
    expect(mockDispatch).toHaveBeenCalledTimes(2);
  });

  test('opens and closes the port mapping panel', () => {
    render(<FabricTopology />);
    fireEvent.click(screen.getByRole('button', { name: 'Toggle port mapping' }));
    expect(screen.getByText('Port mapping panel')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Toggle port mapping' }));
    expect(screen.queryByText('Port mapping panel')).not.toBeInTheDocument();
  });

  test('handles device hover and mouse movement without crashing', () => {
    render(<FabricTopology />);
    const canvas = mockCanvasInstances[0];
    const target = { shapeType: 'deviceCompositeGroup', metadata: { deviceData: { resourceId: 10 } } };
    act(() => {
      canvas.handlers['mouse:over']?.({ target, e: { clientX: 10, clientY: 20 } });
      canvas.handlers['mouse:move']?.({ target, e: { clientX: 15, clientY: 25 } });
      canvas.handlers['mouse:move']?.({ target: null, e: { clientX: 0, clientY: 0 } });
    });
    expect(document.querySelector('.topology-surface')).toBeInTheDocument();
  });

  test('clears an empty canvas through the toolbar action', () => {
    render(<FabricTopology />);
    fireEvent.click(screen.getByRole('button', { name: 'Clear canvas' }));
    expect(mockCanvasInstances[0].requestRenderAll).toHaveBeenCalled();
  });
});
