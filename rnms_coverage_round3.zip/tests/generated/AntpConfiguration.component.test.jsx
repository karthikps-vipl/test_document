import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

jest.mock('react-redux', () => ({
  useSelector: (selector) => selector({ nodeDetails: { isCnms: false } }),
}));
jest.mock('@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23', () => ({
  WIDGET_REGISTRY: {
    circularDialGauge: {
      renderCanvas: (config) => <div data-testid="dial-gauge">{config?.title || 'Gauge'}</div>,
    },
  },
}));
jest.mock('@/RestAPI/api/axiosApicall', () => ({
  ConfigurationAxios: jest.fn().mockResolvedValue({ data: { status: 0 } }),
}));
jest.mock('@/components/Reusable/Toast/Toast', () => jest.fn());
jest.mock('@/components/Reusable/Button/MButtonPrimary', () => ({ children, ...props }) => (
  <button {...props}>{children}</button>
));
jest.mock('@/components/Reusable/Dialog/MDialog', () => ({ open, title, message, onConfirm, onClose }) => (
  open ? <div role="dialog" aria-label={title}>
    <p>{message}</p>
    <button onClick={onConfirm}>Confirm action</button>
    <button onClick={onClose}>Cancel action</button>
  </div> : null
));

import AntpConfiguration from '../../src/components/Dialogs/ANTP/AntpConfiguration';

describe('AntpConfiguration component', () => {
  test('renders antenna controls and both dial gauges', () => {
    render(<AntpConfiguration node={{}} />);
    expect(screen.getByText('Antenna Movement Controls')).toBeInTheDocument();
    expect(screen.getAllByTestId('dial-gauge')).toHaveLength(2);
    expect(screen.getByRole('button', { name: /^Up$/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /^Down$/ })).toBeInTheDocument();
  });

  test('opens confirmation before starting an upward movement', () => {
    render(<AntpConfiguration node={{}} />);
    fireEvent.click(screen.getByRole('button', { name: /^Up$/ }));
    expect(screen.getByRole('dialog', { name: 'Confirm Action' })).toBeInTheDocument();
    expect(screen.getByText('Are you sure you want to move the antenna Up?')).toBeInTheDocument();
  });

  test('closes a pending movement confirmation when cancelled', () => {
    render(<AntpConfiguration node={{}} />);
    fireEvent.click(screen.getByRole('button', { name: /^CW$/ }));
    expect(screen.getByRole('dialog')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Cancel action' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  test('opens confirmation for homing operation', () => {
    render(<AntpConfiguration node={{}} />);
    fireEvent.click(screen.getByRole('button', { name: /Homing/i }));
    expect(screen.getByText('Are you sure you want to perform Homing?')).toBeInTheDocument();
  });
});
