import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider, createTheme } from '@mui/material/styles';

const mockDispatch = jest.fn();
const mockTopologyAxios = jest.fn();
const mockFitView = jest.fn();

jest.mock('react-redux', () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector({
    topologySlice: {
      nodes: [], edges: [], rackNodes: [], currentViewTopology: true,
      undoStack: [], redoStack: [], undoStackRack: [], redoStackRack: [],
      currentNodeView: 'simpleViewNode', switchTopology: 'simpleViewNode',
    },
    nodeDetails: { isCnms: false, siteDetails: null },
  }),
}));
jest.mock('@xyflow/react', () => ({
  ReactFlow: (props) => <div data-testid="react-flow" data-node-count={props.nodes?.length || 0} />,
  Controls: () => <div data-testid="flow-controls" />,
  Background: () => <div data-testid="flow-background" />,
  useReactFlow: () => ({
    getNodesBounds: jest.fn(() => ({ x: 0, y: 0, width: 100, height: 100 })),
    screenToFlowPosition: jest.fn((point) => point),
    fitView: mockFitView,
    getNodes: jest.fn(() => []),
  }),
}));
jest.mock('@/RestAPI/api/axiosApicall', () => ({
  TopologyAxios: (...args) => mockTopologyAxios(...args),
}));
jest.mock('../../src/utility/customHooks/useTopologyUtilityMethods', () => () => ({ onConnect: jest.fn() }));
jest.mock('@/utility/customHooks/useFullscreen', () => () => ({ isFullscreen: false, toggleFullscreen: jest.fn() }));
jest.mock('../../src/Pages/Rnmsdashboard/Topology/TopologyEditActions', () => (props) => (
  <div data-testid="topology-edit-actions">
    <button onClick={props.onPortMappingToggle}>Toggle port mapping</button>
    <button onClick={() => props.setIsDeleteAllConfirm(true)}>Open delete confirmation</button>
    <button onClick={() => props.setIsSaveConfirmOpen(true)}>Open save confirmation</button>
  </div>
));
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodePalette/NodePalette', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/EdgeMenu', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/Tooltip/NodeTooltip', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/ImageNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/GroupNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/RackNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/RackFrameNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/RackResourceName', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/BlankNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/ImageOnly', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/SimpleViewNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/Topology/NodeTypes/UploadedImageNode', () => () => <div />);
jest.mock('../../src/Pages/Rnmsdashboard/TopologyFabric/PortMapping', () => () => <div>Port mapping panel</div>);
jest.mock('@/components/Reusable/Dialog/MDialog', () => () => null);
jest.mock('@/components/Reusable/Modal/MModal', () => () => null);
jest.mock('@/components/Contextmenu/ContextMenu', () => () => null);
jest.mock('@/components/Reusable/Toast/Toast', () => jest.fn());

import Topology from '../../src/Pages/Rnmsdashboard/Topology/Topology';

const topologyTheme = createTheme({ palette: { custom: { reactFlow: { controlsBg: '#fff', controlsIcon: '#111', controlsBorder: '#ddd' } } } });
const renderTopology = (props = {}) => render(<ThemeProvider theme={topologyTheme}><Topology {...props} /></ThemeProvider>);

describe('Topology component', () => {
  beforeEach(() => {
    mockDispatch.mockClear();
    mockFitView.mockClear();
    mockTopologyAxios.mockReset();
    mockTopologyAxios.mockResolvedValue({ data: [] });
    global.ResizeObserver = class {
      observe = jest.fn();
      disconnect = jest.fn();
    };
  });

  afterEach(() => delete global.ResizeObserver);

  test('renders React Flow canvas and topology toolbar', () => {
    renderTopology();
    expect(screen.getByTestId('react-flow')).toBeInTheDocument();
    expect(screen.getByTestId('topology-edit-actions')).toBeInTheDocument();
    expect(mockTopologyAxios).toHaveBeenCalled();
  });

  test('opens and closes port mapping panel', () => {
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Toggle port mapping' }));
    expect(screen.getByText('Port mapping panel')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Toggle port mapping' }));
    expect(screen.queryByText('Port mapping panel')).not.toBeInTheDocument();
  });

  test('accepts read-only and external loading options', () => {
    renderTopology({ readOnly: true, loading: true, terminalTypeOverride: "RNMS", skipRackLoad: true });
    expect(screen.getByTestId('react-flow')).toBeInTheDocument();
  });
});
