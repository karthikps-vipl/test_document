const React = require('react');
module.exports = function MarkerClusterGroup({ children }) {
  return React.createElement('div', { 'data-testid': 'marker-cluster-mock' }, children);
};
module.exports.default = module.exports;
