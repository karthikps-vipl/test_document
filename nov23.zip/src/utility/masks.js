export const formatIPv4 = (value) => {
  // 1. Remove everything that isn't a digit or a dot
  let cleaned = value.replace(/[^0-9.]/g, "");

  // 2. Prevent consecutive dots or a leading dot
  cleaned = cleaned.replace(/\.{2,}/g, ".");
  if (cleaned.startsWith(".")) cleaned = cleaned.substring(1);

  const parts = cleaned.split(".");
  const validatedParts = [];

  // 3. Loop through and validate a maximum of 4 octets
  for (let i = 0; i < Math.min(parts.length, 4); i++) {
    let part = parts[i];

    // Limit each chunk to a maximum of 3 digits
    if (part.length > 3) part = part.substring(0, 3);

    // Prevent numbers greater than 255
    if (parseInt(part, 10) > 255) {
      part = "255";
    }

    // Handle leading zeros (e.g., "05" becomes "5", but allow "0" on its own)
    if (part.length > 1 && part.startsWith("0")) {
      part = String(parseInt(part, 10));
    }

    validatedParts.push(part);
  }

  // 4. Automatically add a trailing dot if a full 3-digit octet is typed
  // (But don't append if we already have all 4 octets)
  if (
    validatedParts.length < 4 && 
    validatedParts[validatedParts.length - 1]?.length === 3 && 
    !cleaned.endsWith(".")
  ) {
    return validatedParts.join(".") + ".";
  }

  return validatedParts.join(".");
};
export const formatIPv6 = (value) => {
  // 1. Remove everything that isn't a hex character (0-9, a-f) or a colon
  let cleaned = value.toLowerCase().replace(/[^0-9a-f:]/g, "");
  
  // 2. Prevent consecutive colons (to avoid issues, though :: is valid in IPv6, 
  // it's safer to prevent accidental triple colons during typing)
  cleaned = cleaned.replace(/:{3,}/g, "::");
  
  // 3. Limit total length (Max IPv6 length is 39 characters)
  if (cleaned.length > 39) {
    cleaned = cleaned.substring(0, 39);
  }
  
  return cleaned;
};

/**
 * Restricts values to valid decimal ranges for Latitude (-90 to 90)
 * with up to 4 decimal places.
 */
export const formatLatitude = (value) => {
  // Allow a single negative sign at the front, numbers, and one decimal point
  let cleaned = value.replace(/[^0-9.-]/g, "");
  
  // Fix multiple negative signs or negative signs in the middle
  if (cleaned.indexOf("-") > 0) cleaned = cleaned.replace(/-/g, "");
  const occurrences = (cleaned.match(/\./g) || []).length;
  if (occurrences > 1) cleaned = cleaned.substring(0, cleaned.lastIndexOf("."));

  // Enforce decimal limit of 4 numbers
  const dotIndex = cleaned.indexOf(".");
  if (dotIndex !== -1 && cleaned.length - dotIndex > 5) {
    cleaned = cleaned.substring(0, dotIndex + 5);
  }

  // Validate numeric scale boundary limits
  const num = parseFloat(cleaned);
  if (!isNaN(num)) {
    if (num > 90) return "90";
    if (num < -90) return "-90";
  }

  return cleaned;
};

/**
 * Restricts values to valid decimal ranges for Longitude (-180 to 180)
 * with up to 4 decimal places.
 */
export const formatLongitude = (value) => {
  let cleaned = value.replace(/[^0-9.-]/g, "");
  
  if (cleaned.indexOf("-") > 0) cleaned = cleaned.replace(/-/g, "");
  const occurrences = (cleaned.match(/\./g) || []).length;
  if (occurrences > 1) cleaned = cleaned.substring(0, cleaned.lastIndexOf("."));

  const dotIndex = cleaned.indexOf(".");
  if (dotIndex !== -1 && cleaned.length - dotIndex > 5) {
    cleaned = cleaned.substring(0, dotIndex + 5);
  }

  const num = parseFloat(cleaned);
  if (!isNaN(num)) {
    if (num > 180) return "180";
    if (num < -180) return "-180";
  }

  return cleaned;
};
