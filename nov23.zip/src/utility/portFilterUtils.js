// // Regex for valid ports
// export const PORT_MATCHING_REGEX = /.*ten-gigabit-ethernet.*|.*GigabitEthernet.*|.*TenGigabitEthernet.*|.*FastEthernet.*|.*GigabiEthernet.*|.*gigabit-ethernet.*/i;

// /**
//  * Filters the ports based on the PORT_MATCHING_REGEX.
//  * Limits have been removed to support any number of ports.
//  * @param {Array} ports - Array of port details
//  * @returns {Array} - Filtered port list matching the regex
//  */
// export const filterSwitchPorts = (ports) => {
//   if (!Array.isArray(ports)) return [];
  
//   // Return only ports where ifdesc matches the regex
//   return ports.filter(
//     (port) => port.ifdesc && PORT_MATCHING_REGEX.test(port.ifdesc)
//   );
// };


import config from "../.././public/config.json";

const PORT_MATCHING_REGEX = new RegExp(
  config.portDescriptionMatchingString,
  "i"
);

const ALWAYS_ALLOWED_PORT_REGEXES = (
  config.alwaysAllowedPortDescriptionMatchingStrings || []
).map((pattern) => new RegExp(pattern, "i"));

const RESOURCE_PORT_REGEXES = Object.fromEntries(
  Object.entries(config.resourcePortDescriptionConstraints || {}).map(
    ([resourceId, patterns]) => [
      resourceId,
      patterns.map((pattern) => new RegExp(pattern, "i"))
    ]
  )
);

/**
 * Filters ports according to global and resource-specific
 * ifdesc constraints configured in public/config.json.
 *
 * @param {Array} ports
 * @returns {Array}
 */
export const filterSwitchPorts = (ports) => {
  if (!Array.isArray(ports)) {
    return [];
  }

  return ports.filter((port) => {
    const { ifdesc, resourceId } = port || {};

    if (typeof ifdesc !== "string") {
      return false;
    }

    // Global constraint
    if (!PORT_MATCHING_REGEX.test(ifdesc)) {
      return false;
    }

    // Global exceptions, e.g. TenGigabitEthernet
    if (
      ALWAYS_ALLOWED_PORT_REGEXES.some((regex) =>
        regex.test(ifdesc)
      )
    ) {
      return true;
    }

    // Resource-specific constraint
    const resourceRegexes = RESOURCE_PORT_REGEXES[resourceId];

    // No resource-specific configuration:
    // use only the global constraint.
    if (!resourceRegexes) {
      return true;
    }

    return resourceRegexes.some((regex) => regex.test(ifdesc));
  });
};