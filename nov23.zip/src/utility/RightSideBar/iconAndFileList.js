/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : RightSideBar
   File Name                : iconAndFileList.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\RightSideBar\iconAndFileList.js
   Purpose                  : Defined the icons and fileList for the entire project from this file. 
   Created Date             : 25-02-2026
 *******************************************************************************************/
import IPwhiteList from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Security/IPwhitelisting/IPwhiteList";
import SecuritySettings from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Security/SecuritySettings";

import security from "@/assets/SVGIcons/security.svg";
import disc from "@/assets/SVGIcons/disc.svg";
import tools from "@/assets/SVGIcons/tools.svg";
// import  alaramRight from "@/assets/SVGIcons/alaramRight.svg";
import configuration from "@/assets/SVGIcons/configuration.svg";
import performance from "@/assets/SVGIcons/performance.svg";
import xcertificate from "@/assets/SVGIcons/x-certificate.svg";
import siteconfig from "@/assets/SVGIcons/siteconfig.svg";
import dbBackup from "@/assets/SVGIcons/dbBackup.svg";
import alarm from "@/assets/SVGIcons/alarm.svg";
import report from "@/assets/SVGIcons/report.svg";
import helpDesk from "@/assets/SVGIcons/helpDesk.svg";
import PerformanceThreshold from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Performance/Threshold/PerformanceThreshold";
import ConfigNetworkAccelerator from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/NetworkAccelerator/ConfigNetworkAccelerator";
import DeviceLoginMgmt from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/DeviceLoginManagement/ConfigDeviceLoginMgmt";
import ConfigRepDetails from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/RepDetails/ConfigRepDetails";
import PerformanceMonitor from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Performance/Monitor/PerformanceMonitor";
import SiteConfigSnmp from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/Snmp/SiteConfigSnmp";
import LinkConfiguration from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/LinkConfiguration/SiteConfigLinkConfiguration";
import ConfigLocation from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/Location/ConfigLocation";
import ToolsPingSettings from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/ToolsPingSettings";
import MiscConfig from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/MiscellaneousConfiguration/SiteConfigMiscConfig";
import ThresholdUpdate from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/DeviceThresholdSetting/ToolsThresholdUpdate";
import MiscellaneousPollingInterval from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/MiscPollInterval/MiscellaneousPollingInterval";
import ToolsDeviceWebConsoleUrl from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/ToolsDeviceWebConsoleUrl/ToolsDeviceWebConsoleUrl";
import ToolsSerialPortConfig from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/ToolsSerialPortConfig/ToolsSerialPortConfig";
import SiteConfigAssignProfile from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/AssignProfile/SiteConfigAssignProfile";
import DBManual from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/DBbackup/DBManual";
import ConfigManualBackup from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/ManualBackup/ConfigManualBackup";
import ConfigScheduleBackup from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/ScheduleBackup/ConfigScheduleBackup";
import AlarmPollingInterval from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/AlarmSettings/AlarmPollingInterval";
import DBbackupView from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/DBbackup/DBbackup/DBbackupView";
import ForiegnIp from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Discovery/ForiegnIp/ForiegnIp";
import LastDiscoverdIp from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Discovery/LastDiscoverdStatus/LastDiscoverdIp";
import DiscoveryOIDCheck from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Discovery/DiscoveryOIDCheck/DiscoveryOIDCheck";
import AlarmNotification from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/AlarmSettings/AlarmNotification";
import DeviceDiscovery from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Discovery/DeviceDiscovery/DeviceDiscovery";
import IpDeviceDiscovery from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Discovery/IpDeviceDiscovery/IpDeviceDiscovery";
import ReportWorkspace from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/ReportWorkspace";
import DBbackupAdd from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/DBbackup/DBbackup/DBbackupAdd";
import ToolsNms from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Tools/NmsTools/ToolsNms";
import HelpDeskDashboard from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskDashboard";
import SNMPDashboard from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/SNMPDashboard";
import syslog from "@/Pages/Rnmsdashboard/Syslog AI/SyslogDashboard";
import SiteConfigLinkStatuSsummary from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/linkStatusSummary/SiteConfigLinkStatuSsummary";
import Xcertificate from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/XCertificate/Xcerificate";
import GroupMgmt from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmt";
import UserMgmt from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/UserManagement/UserMgmt";
import ConfigRemoteRep from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/RemoteRep/ConfigRemoteRep";
import Sos from "@/assets/SVGIcons/cnms/sos.svg";
import Dbstore from "@/assets/SVGIcons/cnms/Dbstore.svg";

import location from "@/assets/SVGIcons/cnms/loction.svg";
import server from "@/assets/SVGIcons/cnms/server-checkmark-icon.svg";

import email2carbon from "@/assets/SVGIcons/cnms/email2carbon.svg";
import version_matrix from "@/assets/SVGIcons/cnms/version_matrix.svg";
import chatbotsvg from "@/assets/SVGIcons/nms_chat_bot.svg";
import ConfigBackupFiles from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsBackup/ConfigBackupFiles";
import RnmsPollingInterval from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/RnmsPollingInterval";
import CnmsDiscovery from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/CnmsDiscovery";
import UpdateRemotesLocation from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/Location/UpdateRemotesLocation";
import CnmsSyslogSettings from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsTools/CnmsSyslogSettings";
import CnmsRoleConfigurator from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/CnmsRoleConfigurator";
import SiteLocationHistory from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/SiteLocationHistory/SiteLocationHistory";
import LdapConfiguration from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/LdapConfiguration/LdapConfiguration";
import ConfigurationUpload from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/Upload/ConfigurationUpload";
import ConfigurationFileComparison from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/FileComparison/ConfigurationFileComparison";
import AlarmConfigurationToggle from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsAlarmSettings/AlarmConfigurationToggle";
import CnmsDbStore from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsDbStore/CnmsDbStore";
import SiteDbStore from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsDbStore/SiteDbStore";
import CnmsRemoteGroup from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/RemoteGroup/CnmsRemoteGroup";
import VersionMatrix from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/VersionMatrix";
import UpdateSiteActiveMode from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/UpdateSiteActiveMode";
import SosLog from "@/Pages/CnmsDashboard/SosLog/SosLog";
import UpdateModeAndEncryptorPassword from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSiteConfigarator/UpdateModeAndEncryptorPassword";

// Mapping of privilege keys to components
export const FileList = {
  security_ip: IPwhiteList,
  security_settings: SecuritySettings,
  configuration_rep: ConfigRepDetails,
  configuration_location: ConfigLocation,
  configuration_manual_backup: ConfigManualBackup,
  configuration_schedule_backup: ConfigScheduleBackup,
  configuration_device_login_management: DeviceLoginMgmt,
  configuration_network_accelerator_api_token: ConfigNetworkAccelerator,
  performance_settings_monitor: PerformanceMonitor,
  performance_settings_threshold: PerformanceThreshold,
  alarm_settings_alarm_config: AlarmConfigurationToggle,
  alarm_settings_poll_interval: AlarmPollingInterval,
  alarm_settings_notification_config: AlarmNotification,
  // alarm_settings_alarm_suppression: SNMPDashboard,
  // alarm_settings_alarm_workflow:,
  site_config_link: LinkConfiguration,
  site_config_snmp: SiteConfigSnmp,
  site_config_assign_profile: SiteConfigAssignProfile,
  im_misc_config: MiscConfig,
  site_link_link_status_summary: SiteConfigLinkStatuSsummary,
  tools_nms: ToolsNms,

  tools_ping_settings: ToolsPingSettings,
  tools_misc_polling: MiscellaneousPollingInterval,
  tools_device_web_console_url: ToolsDeviceWebConsoleUrl,
  tools_device_threshold_setting: ThresholdUpdate,
  tools_discovery_serial: ToolsSerialPortConfig,
  db_tool_backup_manual: DBManual,
  db_tool_view_scheduled_task: DBbackupView,
  db_tool_backup_schedule: DBbackupAdd,
  device_discovery: DeviceDiscovery,
  ip_device_discovery: IpDeviceDiscovery,
  last_discovered_status: LastDiscoverdIp,
  foreign_ip_discovery: ForiegnIp,
  discovery_oid_value_check: DiscoveryOIDCheck,
  help_desk_child: HelpDeskDashboard,
  "x.509_cert_child": Xcertificate,
  db_tool_backup_conf_no_files: ConfigBackupFiles,
  // REPORT FILE
  AuditLogReport: ReportWorkspace,
  userExp: ReportWorkspace,
  user_blocked_logs_rnms: ReportWorkspace,
  AlarmLog: ReportWorkspace,
  foreign_ip_report_rnms: ReportWorkspace,
  DeviceAvailability: ReportWorkspace,
  SystemLogRNMS: ReportWorkspace,
  DeviceMaintenance: ReportWorkspace,
  Link: ReportWorkspace,
  db_BackupStatusLog: ReportWorkspace,
  ACU: ReportWorkspace,
  UptimeReportRNMS: ReportWorkspace,
  // Report cnms
  user_blocked_logs_cnms: ReportWorkspace,
  foreign_ip_report_cnms: ReportWorkspace,
  SiteAvailability:ReportWorkspace,
  SiteReachability:ReportWorkspace,
  SiteMaintenance:ReportWorkspace,
  db_SiteBackupLogReport:ReportWorkspace,
  db_SiteRestoreLogReport:ReportWorkspace,
  db_CnmsRestoreStatusLog: ReportWorkspace,
  LinkSummary: ReportWorkspace,
  SiteRepDetails: ReportWorkspace,
  AlarmReportRNMS: ReportWorkspace,
  SystemLogCNMS: ReportWorkspace,
  LinkCnms: ReportWorkspace,

  // Report -> performance
  RealTimeSystemLevel: ReportWorkspace,
  HistoricalSystemLevel: ReportWorkspace,
  HistoricalInterfaceLevel: ReportWorkspace,
  RealTimeInterfaceLevel: ReportWorkspace,

  DelayAndResponse: ReportWorkspace,
  syslog_ai_child: syslog,
  snmp_config_not_from_db: SNMPDashboard,
  security_group: GroupMgmt,
  security_user: UserMgmt,
  configuration_remote_rep: ConfigRemoteRep,
  ai_syslog_module: syslog,
  site_config_rnms_polling_interval: RnmsPollingInterval,
  // cnms
  db_tool_cnms_restore:CnmsDbStore,
  db_tool_site_restore:SiteDbStore,
  tools_fm_syslog_settings:CnmsSyslogSettings,
  site_config_discovery: CnmsDiscovery,
  update_remotes_location_details: UpdateRemotesLocation,
  site_config_rnms_role_assignment: CnmsRoleConfigurator,
  site_location_history: SiteLocationHistory,
  configuration_ldap_config: LdapConfiguration,
  site_config_remote_group:CnmsRemoteGroup,
  configuration_upload: ConfigurationUpload,
  configuration_file_comparison: ConfigurationFileComparison,
  site_active_mode_of_communication:UpdateSiteActiveMode,
  version_matrix_cnms: VersionMatrix,
  sos_log_cnms:SosLog,
  update_site_modem_encryptor_password:UpdateModeAndEncryptorPassword,
};

// Mapping privileges to icons
export const IconList = {
  security: security,
  configuration: configuration,
  performance: performance,
  alarm_settings: alarm,
  tools: tools,
  discovery: disc,
  "x.509_certificate": xcertificate,
  db_backup: dbBackup,
  db_tool_restore: Dbstore,
  sms_email: email2carbon,
  rnms_device_status_config: server,
  version_matrix: version_matrix,
  site_location: location,
  sos_log: Sos,
  report: report,
  site_config: siteconfig,
  help_desk: helpDesk,
  ai_module: chatbotsvg,

};
