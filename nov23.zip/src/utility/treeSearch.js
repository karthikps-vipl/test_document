/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : utility
   File Name                : treeSearch.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\RightSideBar\treeSearch.js
   Purpose                  : Defined the treeSearch logic used. 
   Created Date             : 27-02-2026
 *******************************************************************************************/
export const searchTree = (node, searchText, options = {}) => {
  if (!searchText) return node;

  const { keys = ["label"], childrenKey = "children" } = options;
  const text = searchText.toLowerCase();

  const isMatch = keys.some((key) => {
    const value = node[key];
    return typeof value === "string" && value.toLowerCase().includes(text);
  });

  if (node[childrenKey]) {
    const filteredChildren = node[childrenKey]
      .map((child) => searchTree(child, searchText, options))
      .filter(Boolean);

    if (filteredChildren.length > 0) {
      return {
        ...node,
        [childrenKey]: filteredChildren,
      };
    }
  }

  if (isMatch) {
    return { ...node };
  }

  return null;
};
