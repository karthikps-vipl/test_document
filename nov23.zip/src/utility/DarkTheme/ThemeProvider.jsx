
import React, { useState, useEffect, useMemo } from 'react';
import { ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { ThemeContext } from './ThemeContext';
import LoginBackgroundImage from "@/assets/SVGIcons/3_image_1.svg";
import loginblacktheme from "@/assets/SVGIcons/loginblacktheme.svg";
import LoginCnmsBackgroundImage from "@/assets/SVGIcons/cnms/cnmslogin.png"
import { useSelector } from 'react-redux';

export const CustomThemeProvider = ({ children }) => {
  const [isdarkmode, setIsDarkMode] = useState(() => {
    // const savedTheme = localStorage.getItem('theme');
  
    // These are commented out as requesteduse
    
    // ADD THIS LINE TO ENSURE LIGHT MODE DEFAULT:
    return false;
  });
  const { isCnms } = useSelector((state) => state.nodeDetails);
  useEffect(() => {
    const root = window.document.documentElement;
    if (isdarkmode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isdarkmode]);

  const toggleTheme = () => setIsDarkMode((prev) => !prev);

  const muiTheme = useMemo(() => createTheme({
    palette: {
      mode: isdarkmode ? 'dark' : 'light',
      primary: { main: "#1677ff" },
      background: {
        default: isdarkmode ? '#121212' : '#a7beec',
        paper: isdarkmode ? ' #121212' : '#ffffff',
        secondary: isdarkmode ? '#1e1e1e' : '#e8e8e8',
        tabs: isdarkmode ? '#2C2C2C' : '#ffffff',
        headerBg: isdarkmode ? '#2c2c2c' : '#D5E0FF', // Dark navy vs light blue
        cardbg: isdarkmode ? '#292929' : '#ffffff',
        alaramdrawer: isdarkmode ? '#292929' : '#ffffff',
        avtar: isdarkmode ? '#292929' : '#D5E0FF',
        avtarColor: isdarkmode ? '#fffff' : '#000000',
        toplogybg: isdarkmode ? '#1e1e1e' : '#ffffff'
      },
      text: {
        primary: isdarkmode ? '#f8fafc' : '#0f172a',
        secondary: isdarkmode ? '#94a3b8' : '#64748b', // Fixed: was #000000
        gray: isdarkmode ? '#e3e3e3' : '#4b5563',       // Fixed: was #000000
        tabcolor: isdarkmode ? '#ffffff' : '#000000',   // Fixed: was #ffffff
        linkstatus: isdarkmode ? '#000000' : '#000000',
        TitleTextcolor: isdarkmode ? '#ffffff' : '#14348d',
        porttextcolor: isdarkmode ? 'hsl(198, 68.40%, 3.70%)' : '#000000',
      },
      custom: {
        landingImage: isCnms 
        ? (isdarkmode ? `url(${LoginCnmsBackgroundImage})` : `url(${LoginCnmsBackgroundImage})`) 
        : (isdarkmode ? `url(${loginblacktheme})` : `url(${LoginBackgroundImage})`),    
            secondheader: isdarkmode ? '#1E1E1E' : '#e8e8e8',
        border: isdarkmode ? ' 1px solid #ffffff' : '1px solid #14348d',
        commonBorder:isdarkmode ? '  ' : '2px solid #eee',
       dashboardBorder:isdarkmode ? ' 1px solid #2e2e2e ' : '1px solid #e0e0e0',
        portImageFilter: isdarkmode ? 'brightness(1) invert(1)' : 'none',
        icon: {
          iconFilter: isdarkmode ? 'brightness(0) invert(1)' : 'none',
          iconColor: isdarkmode ? '#ffffff' : '#14348d',
          scrollcolor: isdarkmode ? '#969696' : 'gray',
        },
        chart: {
          grid: isdarkmode ? '#333333' : '#F0F0F0',
          text: isdarkmode ? '#f8fafc' : '#0f172a',
          chartbg: isdarkmode ? ' #292929' : '#ffffff',
          tooltipBg: isdarkmode ? '#1E1E1E' : '#ffffff',
          tooltipText: isdarkmode ? '#ffffff' : '#000000',
          cursor: isdarkmode ? '#333333' : '#f3f4f6',
        },
        sos: {
          modalBg: isdarkmode ? '#1E1E1E' : '#ffffff',
          titleColor: isdarkmode ? '#ffffff' : '#0f172a',
          descriptionColor: isdarkmode ? '#94a3b8' : '#555555',
          accentColor: isdarkmode ? '#4da3ff' : '#027FDA', // Lightened blue for dark mode
          timerNormal: isdarkmode ? '#4da3ff' : '#027FDA',
          timerAlert: '#ff4d4f', // Red remains red for emergency
        },
        table: {
          headerBg: isdarkmode ? '#2C2C2C' : '#D5E0FF', // Dark navy vs light blue
          headerText: isdarkmode ? '#F8FAFC' : '#14348D', // White vs dark blue
          border: isdarkmode ? '#dbdbdb' : '#e1e1e1',
          borderHeader: isdarkmode ? '#5c5757' : 'rgba(92, 87, 87, 0.41)',
          borderBox: isdarkmode ? '#111' : 'rgba(92, 87, 87, 0.41)',

          headerbg: isdarkmode ? '#e1e1e1' : '#fff',
          headerRight: isdarkmode ? '#5c5757' : '#e1e1e1',
          rowHover: isdarkmode ? '#1E293B' : '#f5f5f5',
          stickyActionBg: isdarkmode ? '#121212' : '#D5E0FF',
          tablebodybg: isdarkmode ? '#1E1E1E' : '#ffffff',
        },
        rightUtilityDrawer: {
          bg: isdarkmode ? '#1e1e1e' : '#ffffff',
          border: isdarkmode ? 'rgba(219, 219, 219, 0.3)' : '#D5E0FF',
          headerBg: isdarkmode ? '#2C2C2C' : '#F5F8FF',
          headerText: isdarkmode ? '#ffffff' : '#14348D',
          itemHover: isdarkmode ? '#333333' : '#E9EFFF',
          itemText: isdarkmode ? '#f8fafc' : '#14348D',
          divider: isdarkmode ? '#ffffff' : '#eee',
          tabsbg: isdarkmode ? '#1E1E1E' : '#E9EFFF',
        },
        reactFlow: {
          controlsBg: isdarkmode ? '#1E1E1E' : '#ffffff',
          controlsBorder: isdarkmode ? '#333333' : '#ccc',
          controlsIcon: isdarkmode ? '#ffffff' : '#000000',
          backgroundDots: isdarkmode ? "#444444" : "#D9D9D9",

        },
        configuration: {
          configmodaltext: isdarkmode ? '#ffffff' : '#14348d',
          configinfo: isdarkmode ? '#878787' : '#D5E0FF',

          configbg: isdarkmode ? '#1e1e1e' : '#fff',
          configmodal: isdarkmode ? '#292929' : '#EEF2FF',
          configcard: isdarkmode ? '#444444' : '#fff',
          configsucess: isdarkmode ? '#3d3d3d' : '#DFFFE8',

        },
        snmp: {
          snmmptitle: isdarkmode ? '#ffffff' : '#14348d',
          snmplegend: isdarkmode ? '#000' : '#14348d',
          border: isdarkmode ? ' 1px solid #ffffff' : '1px solid #eeeeee',

          inputtitle: isdarkmode ? "#fff" : '#444',
          modalbg: isdarkmode ? "#444" : '#E4EBFF', 
          contentbg: isdarkmode ? '#121212' : '#ffffff',
        },
        input: {
          bg: isdarkmode ? '#2C2C2C' : '#ffffff',
          border: isdarkmode ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.23)',
          text: isdarkmode ? '#ffffff' : '#000000',
          label: isdarkmode ? '#94a3b8' : '#64748b',
          borderColorHover: isdarkmode ? '#1677ff' : '#1677ff',
        },
        

      },
      customGradients: {
        landing: isdarkmode
          ? "linear-gradient(135deg, #2c3e50 0%, #000000 100%)"
          : "linear-gradient(to right, #1c2335, #48739f)",
          
      },
      
    },
  }), [isdarkmode,isCnms]);
  return (
    <ThemeContext.Provider value={{ isdarkmode, toggleTheme }}>
      <MuiThemeProvider theme={muiTheme}>
        <CssBaseline />
        {children}
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};