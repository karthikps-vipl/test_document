// src/utility/DarkTheme/ThemeContext.js
import { createContext, useContext } from 'react';

export const ThemeContext = createContext(null);

// Move the hook here
export const useCustomTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useCustomTheme must be used within a CustomThemeProvider");
  }
  return context;
};