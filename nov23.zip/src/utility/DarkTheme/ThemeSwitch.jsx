import React from 'react';
import { Box, Tooltip, styled } from '@mui/material';
import { Moon, Sun } from 'lucide-react';

// 1. Use shouldForwardProp to prevent 'isdarkmode' from reaching the DOM
const SwitchTrack = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'isdarkmode',
})(({ theme, isdarkmode }) => ({
  width: 70,
  height: 36,
  borderRadius: 20,
  display: 'flex',
  alignItems: 'center',
  padding: '4px',
  cursor: 'pointer',
  position: 'relative',
  transition: 'background-color 0.3s ease',
  backgroundColor: isdarkmode ? '#2c2c2c' : '#f8fafc', 
}));

// 2. Apply the same logic to SwitchThumb
const SwitchThumb = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'isdarkmode',
})(({ theme, isdarkmode }) => ({
  width: 28,
  height: 28,
  borderRadius: '50%',
  backgroundColor: isdarkmode ? '#000' : 'rgb(104, 140, 217)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  position: 'absolute',
  left: isdarkmode ? 4 : 38,
  transition: 'left 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  boxShadow: '0px 2px 4px rgba(0,0,0,0.3)',
}));

const IconWrapper = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  width: '100%',
  padding: '0 6px',
  pointerEvents: 'none',
});

const ThemeSwitch = ({ isdarkmode, toggleTheme }) => {
  return (
    <Tooltip title={isdarkmode ? "Switch to Light Mode" : "Switch to Dark Mode"}>
      <Box onClick={toggleTheme} sx={{ display: 'inline-block' }}>
        <SwitchTrack isdarkmode={isdarkmode}>
          <SwitchThumb isdarkmode={isdarkmode}>
             {isdarkmode ? (
               <Moon size={16} color="white" />
             ) : (
               <Sun size={16} color="white" />
             )}
          </SwitchThumb>
          <IconWrapper>
            <Moon size={18} color={isdarkmode ? "transparent" : "#64748b"} />
            <Sun size={18} color={isdarkmode ? "#f1f5f9" : "transparent"} />
          </IconWrapper>
        </SwitchTrack>
      </Box>
    </Tooltip>
  );
};

export default ThemeSwitch;