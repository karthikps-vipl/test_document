
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_ALL_OPEN_ALARM } from "@/RestAPI/url/endpoint";
import { 
  setBadgeCount, 
} from "@/store/features/Fault/alarmSlice";

/**
 * Reusable function to refresh all alarm-related Redux states
 * @param {Function} dispatch - The Redux dispatch function
 * @returns {Promise<Array|null>} - Returns the transformed data or null if failed
 */
export const refreshAlarmData = async (dispatch) => {
  try {
    const res = await FaultAxios(FETCH_ALL_OPEN_ALARM, "get");
    
    if (res.status === 200) {
      const rawData = res?.data || [];
      
      // 1. Transform data
      const transformedData = rawData.map((value, index) => ({
        ...value,
        key: index,
      }));

      console.log(("transformedDatacnms",transformedData));
      

      // 2. Dispatch Badge Count
      dispatch(setBadgeCount(transformedData));
      return transformedData; 
    }else {
      // Handle non-200 status codes
      throw new Error(`Failed to fetch alarms: ${res.status}`);
    }
  } catch (error) {
    console.error("Error in refreshAlarmData service:", error);
    return null;
  }
};