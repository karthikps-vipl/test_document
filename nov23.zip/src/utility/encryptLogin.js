/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : utility
   File Name                : encryptLogin.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\RightSideBar\encryptLogin.js
   Purpose                  : Defined the encryption logic used in Login Page. 
   Created Date             : 26-02-2026
 *******************************************************************************************/
import JSEncrypt from "jsencrypt";

export const encryptData = (params) => {
  const pub_key =
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDdCEJNwWItuLHrG+UYhJMEUp9zCfGgbZnWx1CvZa9MoHEjcOCqVX36rlSyHibSQZY1jpsKYyZ0c51V9XeBRWhpT6dcVFTLoQZEqsWgiHK3HZe63gz2wa2ujwQTpVrsgVkAeBikPbR5k/Gr9xDBZJ99poGxmg0649S2vIa95BmhLQIDAQAB";

  const encrypt = new JSEncrypt();
  encrypt.setPublicKey(pub_key);
  let encryptedData = encrypt.encrypt(params);

  return encryptedData;
};


// import JSEncrypt from 'jsencrypt';

// export const encryptData = (params) => {
//     const pub_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDdCEJNwWItuLHrG+UYhJMEUp9zCfGgbZnWx1CvZa9MoHEjcOCqVX36rlSyHibSQZY1jpsKYyZ0c51V9XeBRWhpT6dcVFTLoQZEqsWgiHK3HZe63gz2wa2ujwQTpVrsgVkAeBikPbR5k/Gr9xDBZJ99poGxmg0649S2vIa95BmhLQIDAQAB";
//     const encrypt = new JSEncrypt();
//     encrypt.setPublicKey(pub_key);

//     if (params === null || params === undefined || params === "") {
//         return null; // Or an empty string, depending on your preference.  Avoid encrypting nulls.
//     }

//     try {
//         let encryptedData = encrypt.encrypt(params);
//         return encryptedData;
//     } catch (error) {
//         console.error("Encryption error:", error);
//         return null; // Or a specific error indicator.  Don't crash the component.
//     }
// };
