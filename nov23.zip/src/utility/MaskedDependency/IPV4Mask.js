import React from "react";
import MaskedInput from "react-masked-input"; // Ensure this dependency is installed

export function IPV4Mask(props) {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      guide
      // Improved Ref Handling for Material UI compatibility
      ref={(ref) => {
        if (!inputRef) return;
        const node = ref?.inputElement || ref;
        if (typeof inputRef === "function") {
          inputRef(node);
        } else {
          inputRef.current = node;
        }
      }}
      pipe={(value) => {
        if (value === "." || value.endsWith("..")) return false;
        const parts = value.split(".");
        // Check if any part is invalid
        if (
          parts.length > 4 ||
          parts.some(
            (part) => part !== "" && (isNaN(part) || part < 0 || part > 255)
          )
        ) {
          return false;
        }
        return value;
      }}
      mask={(value) => {
        let result = [];
        const chunks = value.split(".");
        for (let i = 0; i < 4; ++i) {
          const chunk = (chunks[i] || "").replace(/_/gi, "");

          if (chunk === "") {
            result.push(/\d/, /\d/, /\d/, ".");
            // continue;
          }

          // if (chunks.length < 4 || (chunk.length < 3 && chunks[i].indexOf("_") !== -1)) {
          //    // This logic ensures we don't allow numbers like 300
          //    if ((chunk.length < 2 && +`${chunk}00` > 255) || (chunk.length < 3 && +`${chunk}0` > 255)) {
          //       if (i === 3) result.push(/\d/, ".");
          //       else result.push(/\d/, /\d/, ".");
          //       // continue;
          //    } else {
          //       if (i === 3) result.push(/\d/, ".");
          //       else result.push(/\d/, /\d/, /\d/, ".");
          //       // continue;
          //    }
          // } else {
          //   result.push(...new Array(chunk.length).fill(/\d/), ".");
          //   // continue;
          // }

          const isPartialChunk =
            chunks.length < 4 ||
            (chunk.length < 3 && chunks[i].indexOf("_") !== -1);

          if (isPartialChunk) {
            const isTooLarge =
              (chunk.length < 2 && +`${chunk}00` > 255) ||
              (chunk.length < 3 && +`${chunk}0` > 255);

            // Determine how many digits to allow based on size and position
            let digitCount;
            if (isTooLarge) {
              digitCount = i === 3 ? 1 : 2;
            } else {
              digitCount = i === 3 ? 1 : 3;
            }

            result.push(...new Array(digitCount).fill(/\d/), ".");
          } else {
            result.push(...new Array(chunk.length).fill(/\d/), ".");
          }
        }
        return result.slice(0, -1);
      }}
    />
  );
}
