/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : customHooks
   File Name                : useFullscreen.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\customHooks\useFullscreen.js
   Purpose                  : Defined the custom hook for the minimizing and maximizing the screen. 
   Created Date             : 23-02-2026
 *******************************************************************************************/
import { useState, useEffect, useCallback } from "react";

const useFullscreen = (ref) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = useCallback(() => {
    if (!ref.current) return;

    if (!document.fullscreenElement) {
      ref.current.requestFullscreen().catch((err) => {
        console.error(
          `Error attempting to enable full-screen mode: ${err.message}`
        );
      });
    } else {
      document.exitFullscreen();
    }
  }, [ref]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  return { isFullscreen, toggleFullscreen };
};

export default useFullscreen;
