import {
  Checkbox,
  Popover,
  List,
  ListItem,
  Divider,
  IconButton,
  Box,
  ListItemText,
} from "@mui/material";
import { FilterList } from "@mui/icons-material";
import { useMemo, useState } from "react";
import MInput from "@/components/Reusable/Input/MInput";

// MUI Date & Time imports
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";

export const FilterMenu = ({ column, data, activeFilters, onFilterChange }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [searchValue, setSearchValue] = useState("");
  const [dateValue, setDateValue] = useState(null);

  // 1. Get Unique Options dynamically if not provided (Only run for standard dropdowns)
  const options = useMemo(() => {
    if (column.filterType === "datetime") return []; // Don't compute unique array options for dates
    if (column.filterOptions) return column.filterOptions;

    const uniqueValues = [
      ...new Set(data.map((item) => item[column.uid])),
    ].filter(Boolean);
    return uniqueValues.map((val) => ({ label: val, value: val }));
  }, [column, data]);

  // 2. Filter options based on search inside standard dropdown
  const filteredOptions = options.filter((opt) =>
    String(opt.label).toLowerCase().includes(searchValue.toLowerCase())
  );

  const currentSelected = activeFilters[column.uid] || [];

  const handleToggle = (value) => {
    const next = currentSelected.includes(value)
      ? currentSelected.filter((v) => v !== value)
      : [...currentSelected, value];
    onFilterChange(column.uid, next);
  };

  const handleSelectAll = () => {
    if (currentSelected.length === options.length) {
      onFilterChange(column.uid, []);
    } else {
      onFilterChange(
        column.uid,
        options.map((o) => o.value)
      );
    }
  };

  // 3. Handles continuous changes from your Calendar & Analog clock
  const handleDateChange = (newValue) => {
    setDateValue(newValue);
    // If a valid date selection exists, push its ISO string format up to the filter processor
    // onFilterChange(column.uid, newValue ? [newValue.toISOString()] : []);
    onFilterChange(column.uid, newValue ? {
      value: newValue.toISOString(),
      mode: "eq",
    } : null);
  };

  const isDateType = column.filterType === "datetime";

  return (
    <>
      <IconButton size="small" onClick={(e) => setAnchorEl(e.currentTarget)}>
        <FilterList
          fontSize="inherit"
          sx={{
            color:
              currentSelected.length > 0 || dateValue ? "#14348D" : "inherit",
          }}
        />
      </IconButton>
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      >
        <Box sx={{ p: 2, minWidth: isDateType ? 280 : 200, maxHeight: 450 }}>
          {/* CONDITION A: RENDER TEXT DROPDOWN CHECKS */}
          {!isDateType && (
            <>
              <MInput
                placeholder="Search filters..."
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                size="small"
              />
              <List>
                <ListItem dense button onClick={handleSelectAll}>
                  <Checkbox
                    checked={
                      currentSelected.length === options.length &&
                      options.length > 0
                    }
                    indeterminate={
                      currentSelected.length > 0 &&
                      currentSelected.length < options.length
                    }
                  />
                  <ListItemText primary="Select All" />
                </ListItem>
                <Divider />
                {filteredOptions.map((opt) => (
                  <ListItem
                    key={opt.value}
                    dense
                    button
                    onClick={() => handleToggle(opt.value)}
                  >
                    <Checkbox checked={currentSelected.includes(opt.value)} />
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center" gap={1}>
                          {(opt.color || opt.gradient) && (
                            <span
                              style={{
                                width: 12,
                                height: 12,
                                borderRadius: "50%",
                                background: opt.gradient
                                  ? `linear-gradient(135deg, ${opt.gradient[0]}, ${opt.gradient[1]})`
                                  : opt.color,
                                display: "inline-block",
                                flexShrink: 0,
                              }}
                            />
                          )}
                          {opt.label}
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </>
          )}

          {/* CONDITION B: RENDER DATETIME PICKER WITH ANALOG CLOCK */}
          {isDateType && (
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DateTimePicker
                label="Select Date & Time"
                value={dateValue}
                onChange={handleDateChange}
                ampm={true} // Uses 24h format clock layout
                format="DD/MM/YYYY HH:mm" 
                viewRenderers={{
                  hours: renderTimeViewClock,
                  minutes: renderTimeViewClock,
                  seconds: renderTimeViewClock,
                }}
                slotProps={{
                  textField: {
                    size: "small",
                    fullWidth: true,
                  },
                }}
              />
            </LocalizationProvider>
          )}
        </Box>
      </Popover>
    </>
  );
};
