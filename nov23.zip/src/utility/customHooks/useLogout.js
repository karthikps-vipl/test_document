/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : customHooks
   File Name                : useLogout.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\customHooks\useLogout.js
   Purpose                  : Defined the custom hook for logging out from the main screen. 
   Created Date             : 24-02-2026
 *******************************************************************************************/
import Toast from "@/components/Reusable/Toast/Toast";
import { useModalStore } from "@/core/modal/modalStore";
import { SecurityAxios } from "@/RestAPI/api/axiosApicall";
import { ALARM_LOGOUT } from "@/RestAPI/url/endpoint";
import { useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";

const useLogout = () => {
  const userName = sessionStorage.getItem("userName");
  const { userDetails } = useSelector((state) => state.userSlice);
  const { isCnms } = useSelector((state) => state.nodeDetails);
  const dispatch = useDispatch();

  const logoutHandler = useCallback(async () => {
    try {
      let logoutRes;
      if (isCnms) {
        const payload = {
          userName: userName,
          siteId: userDetails?.data?.rnmsDetailId,
          reason: `user ${userName} logged out manually`,
        };
        logoutRes = await SecurityAxios(ALARM_LOGOUT, "post", payload);
      } else {
        const payload = {
          userName: userName,
          siteId: userDetails?.data?.rnmsDetailId,
          reason: `user ${userName} logged out manually`,
        };
        logoutRes = await SecurityAxios(ALARM_LOGOUT, "post", payload);
      }

      // Clean up regardless of status (or only on 200, up to you)
      sessionStorage.clear();
      dispatch({ type: "socket/disconnect" });
      dispatch({ type: "USER_LOGOUT" }); // Wipes Redux

      useModalStore.getState().resetModal();

      if (logoutRes.status == 200) {
        Toast("Success!", "Logged out successfully", "success");
      } else {
        Toast("", "Something went wrong", "error");
      }
      return logoutRes;
    } catch (error) {
      // Still clear local state so user isn't "stuck" logged in
      sessionStorage.clear();
      dispatch({ type: "USER_LOGOUT" });
      return error.response;
    }
  }, [userName, dispatch]);

  return { logoutHandler };
};

export default useLogout;
