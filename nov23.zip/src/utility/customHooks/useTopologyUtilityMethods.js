/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : customHooks
   File Name                : useTopologyUtilityMethods.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\customHooks\useTopologyUtilityMethods.js
   Purpose                  : Defined the custom hook and can be used as the utility method for the topology. 
   Created Date             : 24-02-2026
 *******************************************************************************************/
/* eslint-disable react-hooks/preserve-manual-memoization */
/* eslint-disable no-unused-vars */
import { useCallback } from "react";
import { generateRandomString } from "../FormValidation/Regex";
import { useDispatch } from "react-redux";
import {
  pushToUndoStack,
  setEdges,
  updateNodeViewType,
} from "../../store/features/Topology/topologyNodesslice";
const useTopologyUtilityMethod = ({ onEdgeCreated } = {}) => {
  const dispatch = useDispatch();

  const onConnect = useCallback((params, event) => {
    // 1. Find the source and target node objects from your state
    // const sourceNode = nodes.find((n) => n.id === params.source);
    // const targetNode = nodes.find((n) => n.id === params.target);

    // 2. Access your custom data fields
    // const sourceData = sourceNode?.data; // e.g., { isSource: true, isTarget: false }
    // const targetData = targetNode?.data;

    // 3. Logic for bidirectional arrows
    // Example: If both devices allow being a source, make it double-sided
    // const isBidirectional =
    //   sourceNode?.data?.imResourceType?.isSource &&
    //   sourceNode?.data?.imResourceType?.isTarget &&
    //   targetNode?.data?.imResourceType?.isSource &&
    //   targetNode?.data?.imResourceType?.isTarget;


    console.log("onConnect triggered", params);
    const newEdge = {
      ...params,
      id: params.source + "-" + generateRandomString(8) + "-" + params.target,

      style: { strokeWidth: 2, stroke: "grey" },
      labelStyle: { fontSize: "25px" },

      // markerEnd: { type: MarkerType.Arrow },
      // Conditionally add arrow to the start
      // ...(isBidirectional && {
      //   markerStart: { type: MarkerType.Arrow },
      // }),
    };
    dispatch(pushToUndoStack());
    dispatch(setEdges([newEdge]));
    onEdgeCreated?.(newEdge,event);
  }, []);

  const handleNodeViewChange = (key) => {
    console.log(key, "key");
    dispatch(updateNodeViewType(key));
  };

  const nodeColor = {
    online: "#C2FFE2",
    offline: "#D75961",
    maintanence: "#FEB5B5",
    undiscovered: "#FFD1B3",
    unmanaged: "#C9C9FB",
    managed: "#C9C9FB",
  };

  return { onConnect, handleNodeViewChange, nodeColor };
};

export default useTopologyUtilityMethod;
