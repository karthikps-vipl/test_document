/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : customHooks
   File Name                : useSessionTimeout.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\customHooks\useSessionTimeout.js
   Purpose                  : Defined the custom hook for logging out from the main screen after the timeout. 
   Created Date             : 24-02-2026
 *******************************************************************************************/
import { useEffect, useRef, useCallback } from "react";

const useSessionTimeout = (
  logoutHandler,
  isAuthenticated,
  timeoutMinutes = 15
) => {
  const timeoutRef = useRef(null);

  const resetTimer = useCallback(() => {
    // Clear existing timer
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    // Set new timer
    timeoutRef.current = setTimeout(() => {
      logoutHandler();
    }, timeoutMinutes * 60 * 1000);
  }, [logoutHandler, timeoutMinutes]);

  useEffect(() => {
    // Only track activity if the user is actually logged in
    if (isAuthenticated) {
      const events = [
        "mousedown",
        "mousemove",
        "keypress",
        "scroll",
        "touchstart",
      ];

      const handleActivity = () => resetTimer();

      // Add listeners for user interaction
      events.forEach((event) => window.addEventListener(event, handleActivity));

      // Initialize the timer on mount
      resetTimer();

      // Cleanup: remove listeners and clear timer on unmount or logout
      return () => {
        events.forEach((event) =>
          window.removeEventListener(event, handleActivity)
        );
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
      };
    }
  }, [isAuthenticated, resetTimer]);
};

export default useSessionTimeout;
