/**
 * Coordinate validation utilities
 *
 * Rules:
 * Latitude:
 *   -90 to 90
 *   Up to 3 digits before decimal
 *   Up to 6 digits after decimal
 *
 * Longitude:
 *   -180 to 180
 *   Up to 3 digits before decimal
 *   Up to 6 digits after decimal
 */

const LATITUDE_REGEX = /^-?(?:\d{1,3})(?:\.\d{0,6})?$/;
const LONGITUDE_REGEX = /^-?(?:\d{1,3})(?:\.\d{0,6})?$/;

const validateCoordinate = (value, min, max, regex, fieldName) => {
  if (value === "" || value === null || value === undefined) {
    return `${fieldName} is required`;
  }

  const stringValue = String(value);

  // Format validation
  if (!regex.test(stringValue)) {
    return `${fieldName} can have up to 3 digits before decimal and up to 6 digits after decimal`;
  }

  const numericValue = Number(stringValue);

  if (Number.isNaN(numericValue)) {
    return `${fieldName} should be a number`;
  }

  // Range validation
  if (numericValue < min || numericValue > max) {
    return `${fieldName} must be between ${min} and ${max}`;
  }

  return "";
};

export const validateLatitude = (value) => {
  return validateCoordinate(value, -90, 90, LATITUDE_REGEX, "Latitude");
};

export const validateLongitude = (value) => {
  return validateCoordinate(value, -180, 180, LONGITUDE_REGEX, "Longitude");
};

/**
 * Allows the user to type a valid intermediate coordinate.
 *
 * Examples allowed while typing:
 * "-"
 * "9"
 * "90"
 * "90."
 * "90.123456"
 *
 * Values outside the coordinate range are rejected.
 */
const sanitizeCoordinate = (value, min, max) => {
  if (value === "") {
    return "";
  }

  let stringValue = String(value);

  // Remove anything except digits, decimal point and minus sign
  stringValue = stringValue.replace(/[^\d.-]/g, "");

  // Minus sign is only allowed at the beginning
  stringValue = stringValue.replace(/(?!^)-/g, "");

  // Only one decimal point
  const decimalIndex = stringValue.indexOf(".");

  if (decimalIndex !== -1) {
    stringValue =
      stringValue.substring(0, decimalIndex + 1) +
      stringValue.substring(decimalIndex + 1).replace(/\./g, "");
  }

  // Maximum 3 digits before decimal
  const [integerPart, decimalPart] = stringValue.split(".");

  if (integerPart) {
    const sign = integerPart.startsWith("-") ? "-" : "";
    const digits = integerPart.replace("-", "").slice(0, 3);

    stringValue =
      sign +
      digits +
      (decimalIndex !== -1 ? `.${decimalPart.slice(0, 6)}` : "");
  }

  // Don't allow values outside the coordinate range.
  //
  // We allow intermediate values such as "9", "90." while typing.
  const numericValue = Number(stringValue);

  if (
    stringValue !== "-" &&
    stringValue !== "." &&
    stringValue !== "-." &&
    !Number.isNaN(numericValue) &&
    (numericValue < min || numericValue > max)
  ) {
    return null;
  }

  return stringValue;
};

export const sanitizeLatitude = (value) => {
  return sanitizeCoordinate(value, -90, 90);
};

export const sanitizeLongitude = (value) => {
  return sanitizeCoordinate(value, -180, 180);
};
