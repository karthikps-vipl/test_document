/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FormValidation
   File Name                : YupSchema.js
   Author                   : Ankitha - VIPL
   Package                  : src\utility\FormValidation\YupSchema.js
   Purpose                  : Defined the validation for the entire project from this file. 
   Created Date             : 25-02-2026
 *******************************************************************************************/
/* eslint-disable no-unused-vars */
import * as Yup from "yup";
import * as yupToFormErrors from "yup";
//import profileRegex from '@/utility/FormValidation/Regex'

export const SiteNumberValidator = Yup.number()
  .required("Site Number is required")
  .min(1, "Site Number must be between 1 and 999")
  .max(999, "Site Number must be less than or equal to 999")
  .integer("Site Number must be a whole number")
  .positive("Site Number must be greater than 0")
  // .matches(/^[0-9]-$/,"No characters is allowed");

  export const SitenameValidator = Yup.string()
  .required("Site Name is required")
  .min(3, "Site Name must be at least 3 characters")
  .max(25, "Site Name must be no more than 25 characters")
  .matches(
    /^[a-zA-Z][a-zA-Z-_ ]{2,24}$/,
    "Site Name must start with a letter and contain only letters, hyphens, underscores, and spaces"
  );

export const SiteNicknameValidator = Yup.string()
  .required("Site UnitName is required")
  .min(3, "Site UnitName must be at least 3 characters")
  .max(25, "Site UnitName must be no more than 25 characters")
  .matches(
    /^[a-zA-Z0-9][a-zA-Z0-9-_ ]{2,24}$/,
    "Site UnitName must start with a letter or number and contain only letters, numbers, hyphens, underscores, and spaces"
  );

export const UnitNameValidator = Yup.string()
  .required("Unit Name is required")
  .min(3, "Unit Name must be at least 3 characters long")
  .max(20, "  Name must be no more than 20 characters")
  .trim() // Apply trim() here
  // .matches(
  //   /^(?=.*[a-zA-Z])([a-zA-Z0-9\d_-\s]{3,25}$)/,
  //   "Site Name must begin with a letter and can only contain letters, spaces, hyphens, and underscores"
  // );
  .matches(
    /^(?=.*[a-zA-Z])[a-zA-Z0-9\s_-]{3,25}$/,
    "Unit Name must contain at least one letter and can only contain letters, numbers, spaces, hyphens, and underscores"
  );

export const UsernameValidator = Yup.string()
  .required("Username is required")
  .min(4, "Username must be at least 4 characters long")
  .max(24, "Username cannot exceed 24 characters")
  .matches(/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/, "Invalid format");

export const PasswordValidator = Yup.string()
  .required("Password is required")
  .min(8, "Password must be at least 8 characters long")
  .max(16, "Password cannot exceed 16 characters")
  .matches(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d^!@#$&_-]{8,16}$/,
    "Password must contain Uppercase, Lowercase, and a Number"
  );
  const passwordComplexityRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d!@#$%&()*+=\-_.$]*$/;
  export const PasswordValidatorAdd = Yup.string()
  .required("Password is required")
  .min(8, "Password must be at least 8 characters long")
  .max(32, "Password cannot exceed 32 characters")
  .matches(passwordComplexityRegex, "Must contain Uppercase, Lowercase, a Number, and allowed special characters")
  .test('no-spaces', 'Spaces are not allowed', (value) => !value?.includes(' '));
  export const Password  = Yup.string()
  .required("Password is required")
  
export const Username = Yup.string()
.required("Username is required")

   
export const CaptchValidator = yupToFormErrors
  .string()
  .required("Captcha is required")
  .min(5, "Captcha must be 5 Characters")
  .max(5, "Captcha must be 5 Characters")
  .test("is-captcha-correct", "Invalid Captcha", function (value) {
    return value === captchData?.key;
  });

export const personnelNameValidation = Yup.string()
  .min(5, "Minimum 5 characters required")
  .max(50, "Maximum 50 characters allowed")
  .required("Personnel Name is required");

export const rankValidation = Yup.string().required("Please select a rank");

export const unitValidation = Yup.string()
  .min(3, "Minimum 3 characters")
  .max(20, "Maximum 20 characters")
  .required("Unit is required");

export const primaryMobileValidation = Yup.string()
  .required("Primary mobile is required")
  .matches(/^[6-9][0-9]{9}$/, "Must be 10 digits starting with 6-9")
  .nullable();

export const afcelPhoneValidation = Yup.string()
  .matches(/^[1-9]\d{7}$/, "Must be 8 digits and cannot start with 0")
  .nullable();

export const ipPhoneValidation = Yup.string()
  .matches(/^[1-9][0-9]{7}$/, "Must be 8 digits and cannot start with 0")
  .nullable();

export const alternateMobileValidation = Yup.string()
  .matches(/^[5-9][0-9]{9}$/, "Must be 10 digits starting with 5-9")
  .nullable();

// 8. Email: Optional, valid email format
export const emailValidation = Yup.string()
  .matches(
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/,
    "Please provide valid email"
  )
  .email("Invalid email format")
  .nullable();

//latitude
export const LatitudeValidator = Yup.number()

  .typeError("Latitude should be a number")
  .min(-90, "Should be between -90 to 90")
  .max(90, "Should be between -90 to 90")
  .required();
//longitude
export const LongitudeValidator = Yup.number()

  .min(-180, "Should be between -180 to 180")
  .max(180, "Should be between -180 to 180")
  .typeError("Longitude should be a number")
  .required();
export const profileNameValidator = Yup.string()
  .required("Profile Name is required")
  .min(3, "Profile Name is greater than 3 charcter")
  .max(24, "Profile Name is less than 24 charcter")
  .matches(/^[a-zA-Z][a-zA-Z0-9]/, "Invalid format")
  .trim();
export const USMuser = Yup.string()
  .required("USM User   is required")
  .min(1, "Usm user is greater than 3 charcter")
  .max(24, "Usm user is less than 24 charcter")
  .matches(/^[a-zA-Z][a-zA-Z0-9]+/, "Invalid format")
  .trim();
export const portValidator = Yup.number()
  .typeError("Port ismust be a number")
  .required("Port is required")
  .min(1, "Port number grater than 1")
  .max(65535, "Port number is lesser than 65535");

export const retryValidator = Yup.number()
  .typeError("Must be a number")
  .required("Retries are required")
  .min(1, "Retries entry number is grater than 1")

  .max(5, "Retries entry number is lesser than 5");
export const timeoutValidator = Yup.number()
  .typeError("Must be a number")
  .required("Timeout is required")
  .positive("Must be a positive number")
  .min(1, "Retries entry number is grater than 1")

  .max(10, "Retries entry number is lesser than 10");
export const versionValidator = Yup.mixed().required("Version is required");

export const communityValidator = Yup.string()
  .required("Community string is required")
  .matches(/^[a-zA-Z][a-zA-Z0-9 !@#$%^&*_-]+/, "Invalid Format")

  .min(1, "Must be at least 1 characters")

  .max(24, "Must be less than 24 characters");
export const ContextMenu = Yup.string()

  .min(3, "Context Menu is greater than 3 charcter")
  .max(24, "Context Menu is less than 24 charcter")
  .matches(/^[a-zA-Z][a-zA-Z0-9]/, "Invalid format")
  .trim();

export const DynamicRangeValidator = (min, max) => {
  return Yup.number()
    .typeError("Must be a number")
    .required("Required")
    .min(min, `Min length should be ${min}`)
    .max(max, `Max length should be ${max}`);
};
export const createDynamicSchema = (deviceData) => {
  const shape = {};

  deviceData.forEach((field) => {
    const dataType = field.dataType || field.type;
    const isNumeric = dataType === "Number" || dataType === "numeric";
    const min = field.minValue;
    const max = field.maxValue;

    if (isNumeric) {
      shape[field.label] = Yup.number()
        .typeError("Must be a valid number")
        .transform((value, originalValue) => {
          // This handles empty strings being treated as 0 by Yup
          return originalValue === "" ? undefined : value;
        })
        .required(`Should be between ${min} to ${max}`)
        .min(min, `Min value should be ${min}`)
        .max(max, `Max value should be ${max}`);
    } else {
      // String/Text validation
      shape[field.label] = Yup.string()
        .required("Required")
        .min(min, `Min length should be ${min}`)
        .max(max, `Max length should be ${max}`);
    }
  });

  return Yup.object().shape(shape);
};
export const NoOfRequests = Yup.number()

  .typeError("Must be a number")
  .min(1, "Must be in 1-10")
  .max(10, "Must be in 1-10")

  .nullable()
  .required();
export const Timeout = Yup.number()
  .typeError("Must be a number")
  .min(1, "Must be in 1-3")
  .max(3, "Must be in 1-3")

  .nullable()
  .required();
export const generateDynamicSchema = (fieldsConfig) => {
  return Yup.object().shape(
    fieldsConfig.reduce((acc, field) => {
      // We use the field.id as the key in the schema
      acc[field.id] = Yup.number()
        .typeError("Must be a number")
        .required(`Required (${field.min}-${field.max})`)
        .min(field.min, `Must be at least ${field.min}`)
        .max(field.max, `Must be at most ${field.max}`);
      return acc;
    }, {})
  );
};
export const DataRate = Yup.number()
  .transform((value, originalValue) => {
    // This converts empty strings "" to undefined
    // so that .required() can trigger properly
    return originalValue === "" ? undefined : value;
  })
  .typeError("Data rate must be a number")
  .min(1, "Data rate must be at least 1")
  .max(99, "Data rate cannot exceed 99")
  .required("Data rate is required");
export const BaudRate = Yup.number()
  .typeError("Baud rate must be a number") // Error if they type letters
  .min(1, "Baud rate must be at least 1") // Minimum boundary
  .max(999999, "Baud rate cannot exceed 999999") // Maximum boundary
  .required("Baud rate is required");

export const StopBits = Yup.number()
  .typeError("Stop bits must be a number") // Handles non-numeric strings
  .oneOf([0, 1], "Stop bits must be either 0 or 1") // Restricts values
  .required("Stop bits is required");

export const ThresholdSchema = Yup.object({
  resourceMasterType: Yup.string().required("Device Type is required"),
  resourceId: Yup.string().when("resourceMasterType", {
    is: (val) => !!val,
    then: (schema) => schema.required("Please select a Device Name"),
  }),
  paramId: Yup.string().when("resourceId", {
    is: (val) => !!val,
    then: (schema) => schema.required("Please select a Parameter"),
  }),
  thresholdComp: Yup.mixed().required("Please select a Comparator"),
  thresholdValue: Yup.string().required("Please enter a value"),
  faultSeverity: Yup.string().when("thresholdValue", {
    is: (val) => !!val,
    then: (schema) => schema.required("Please select severity"),
  }),
});
export const snmpValidationSchema = Yup.object({
  snmpProfileName: Yup.string()
    .required("Profile Name is required")
    // Minimum 3 characters
    .min(3, "Name must be at least 3 characters")
    // Maximum 24 characters
    .max(24, "Name cannot exceed 24 characters")
    // Must start with a letter, then allow letters, numbers, or spaces
    .matches(
      /^[a-zA-Z][a-zA-Z0-9\s]*$/, 
      "Name must start with a letter "
    )
    .trim(),
  port: Yup.number()
    .typeError("Port must be a number")
    .required("Port is required")
    .min(1, "Port number greater than 1")
    .max(65535, "Port number is lesser than 65535"),
  retries: Yup.number()
    .typeError("Must be a number")
    .required("Retries are required")
    .min(1, "Retries entry number is greater than 1")
    .max(5, "Retries entry number is lesser than 5"),
  timeout: Yup.number()
    .typeError("Must be a number")
    .required("Timeout is required")
    .min(1, "Timeout entry number is greater than 1")
    .max(10, "Timeout entry number is lesser than 10"),
  version: Yup.mixed().required("Version is required"),

  // Conditional Community Strings (V1/V2)
  readCommunity: Yup.string().when("version", {
    is: (val) => Number(val) !== 3,
    then: () =>
      Yup.string()
        .required("Required")
        .min(1)
        .max(24)
        .matches(/^[a-zA-Z][a-zA-Z0-9 !@#$%^&*_-]+/, "Invalid Format"),
    otherwise: () => Yup.string().notRequired(),
  }),
  writeCommunity: Yup.string().when("version", {
    is: (val) => Number(val) !== 3,
    then: () =>
      Yup.string()
        .required("Required")
        .min(1)
        .max(24)
        .matches(/^[a-zA-Z][a-zA-Z0-9 !@#$%^&*_-]+/, "Invalid Format"),
    otherwise: () => Yup.string().notRequired(),
  }),

  // SNMP V3 Specifics
  username: Yup.string().when("version", {
    is: 3,
    then: () =>
      Yup.string()
        .required("USM User is required")
        .min(1)
        .max(24)
        .matches(/^[a-zA-Z][a-zA-Z0-9]+/, "Invalid format"),
    otherwise: () => Yup.string().notRequired(),
  }),
  contextName: Yup.string().nullable(),
  authPassword: Yup.string().when(["version", "securityLevel"], {
    is: (v, s) => Number(v) === 3 && (s === "2" || s === "3"),
    then: () =>
      Yup.string()
        .required("Required")
        .min(1)
        .max(24)
        .matches(/^[a-zA-Z][a-zA-Z0-9@]+/, "Invalid format"),
    otherwise: () => Yup.string().notRequired(),
  }),
  privPassword: Yup.string().when(["version", "securityLevel"], {
    is: (v, s) => Number(v) === 3 && s === "3",
    then: () =>
      Yup.string()
        .required("Required")
        .min(1)
        .max(24)
        .matches(/^[a-zA-Z][a-zA-Z0-9@]+/, "Invalid format"),
    otherwise: () => Yup.string().notRequired(),
  }),
});

// export const isValidIpV4 = (ip) => {
//   const ipV4Regx = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
//   const ipV4 = ip.match(ipV4Regx) !== null;
//   const isLocalhost = ip.toLowerCase() === "localhost";
//   const isCS1 = ip.toLowerCase() !== "255.255.255.255";
//   const isCS2 = ip.toLowerCase() !== "0.0.0.0";
//   return (ipV4 || isLocalhost) && isCS1 && isCS2;
// };

export const isValidIpV4 = (ip) => {
  const ipV4Regx =
    /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const isV4 = ipV4Regx.test(ip);
  const isNotBroadcast = ip !== "255.255.255.255";
  const isNotZero = ip !== "0.0.0.0";
  return isV4 && isNotBroadcast && isNotZero;
};

// Converts IP string to a numeric value for easy greater/lesser comparisons
export const ipToLong = (ip) => {
  return (
    ip
      .split(".")
      .reduce((ipInt, octet) => (ipInt << 8) + parseInt(octet, 10), 0) >>> 0
  );
};

export const isValidIpRange = (startIp, endIp) => {
  if (!isValidIpV4(startIp) || !isValidIpV4(endIp)) return false;
  return ipToLong(endIp) >= ipToLong(startIp);
};


export const TicketAlarmDetails = Yup.string()
  .min(3, "Minimum 3 characters required")
  .max(100, "Maximum 100 characters allowed")
  .required(" Ticket Alarm Details is required");
  export const configbackupfiles = Yup.number()

  .typeError("Should not be empty")
  .min(30, "Must be in 30-100")
  .max(100, "Must be in 30-100")

  .nullable()
  .required();
  export const NameValidator = Yup.string()
    .required("Name is required")
    .min(4, "Minimum 4 characters required")
    .max(24, "Maximum 24 characters allowed")
    .matches(/^[a-zA-Z\s]+$/, "Only alphabets are allowed");
    export const GroupNameValidator = Yup.string()
    .required("Group Name is required")