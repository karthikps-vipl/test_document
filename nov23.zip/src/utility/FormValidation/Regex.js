/*************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : FormValidation
   File Name                : Regex.js
   Author                   : SURAJ - VIPL
   Package                  : src\utility\FormValidation\Regex.js
   Purpose                  : Defined the Regular Expression for the entire project from this file. 
   Created Date             : 25-02-2026
 *******************************************************************************************/
export const personnelRegex = {
  name: /^[a-zA-Z\s]*$/,

  primaryMobile: /^[6-9]?[0-9]{0,9}$/,

  altMobile: /^[5-9]?[0-9]{0,9}$/,

  landline: /^[1-9]?[0-9]{0,7}$/,
};
export const validateInput = (value, regex) => {
  if (value === "" || regex.test(value)) {
    return value;
  }
  return undefined;
};

export const remainingText = (textlength, fixedLength) => {
  // const remaining = fixedLength - textlength;
  // const AddedChar = fixedLength - remaining;
  return null;
};

export const usernameRegex = (value) => {
  const regex = /^[a-zA-Z0-9_-]*$/;
  return regex.test(value) ? value : undefined;
};
export const passwordRegex = (pass) => {
  const regex = /^[a-zA-Z0-9^@#$&_-]*$/;
  return regex.test(pass) ? pass : undefined;
};

// export const captchaRegex = (captcha) => {
//   if (typeof captcha !== "string" || captcha.length > 20) {
//     return null;
//   }
//   const regexCaptch = /[^a-zA-Z0-9]+$/;
//   const regex = new RegExp(regexCaptch).test(captcha).valueOf();
//   if (regex) {
//     return captcha;
//   }
// };

// Safe method protects from DOS
export const captchaRegex = (captcha) => {
  if (typeof captcha !== "string" || captcha.length > 20) {
    return null;
  }

  const validPattern = /^[a-zA-Z0-9]+$/;

  return validPattern.test(captcha) ? captcha : null;
};
export const siteNumRegex = (num) => {
  // Matches numbers from 1 to 999 (inclusive)
  const regex = /^\d{1,3}$/;
  const regexNum = /^(?:999|[1-9][0-9]{0,2})$/; 
  
  if (regex.test(num) && regexNum.test(num)) {
    return num;
  }
  return null;
};
export const SitenameRegex = (name) => {
  const regexName = /^([a-zA-Z][a-zA-Z-_ ]*)?$/;
  const regex = new RegExp(regexName).test(name).valueOf();
  if (regex) {
    return name;
  }
};
export const SiteNicknameRegex = (name) => {
  const regexName = /^([a-zA-Z0-9][a-zA-Z0-9-_ ]*)?$/;
  const regex = new RegExp(regexName).test(name).valueOf();
  if (regex) {
    return name;
  }
};

export const descriptionRegex = (description) => {
  const regexDesc = /^([a-zA-Z0-9\s.,?!()-]*)?$/;
  const regex = new RegExp(regexDesc).test(description).valueOf();
  if (regex) {
    return description;
  }
};

export const PortRegex = (port) => {
  const regexDesc = /^([a-zA-Z0-9\s./-]*)?$/;
  const regex = new RegExp(regexDesc).test(port).valueOf();
  if (regex) {
    return port;
  }
};

export const isValidIPV4Regex = (ipAddress) => {
  const regexIP =
    /^((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){0,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])?$/;
  const regex = new RegExp(regexIP).test(ipAddress).valueOf();
  if (regex) {
    return ipAddress;
  }
};

export const idValidLatitudeRegex = (latitude) => {
  const regexLatitude = /^[-+]?((([0-8]?\d(\.\d{0,4})?)|90(\.0{0,6})?))?$/;
  const regex = new RegExp(regexLatitude).test(latitude).valueOf();
  if (regex) {
    return latitude;
  }
};

export const idValidLongitudeRegex = (latitude) => {
  const regexLatitude = /^[-+]?((([0-9]?\d(\.\d{0,4})?)|180(\.0{0,6})?))?$/;
  const regex = new RegExp(regexLatitude).test(latitude).valueOf();
  if (regex) {
    return latitude;
  }
};

export const isValidIPV6Regex = (ip) => {
  const regexIP = /^([\da-fA-F]{0,4}:){0,8}::?([\da-fA-F]{0,4}:){0,7}$/;
  const regex = new RegExp(regexIP).test(ip).valueOf();
  if (regex) {
    return ip;
  }
};

export const extractStringValue = (inputString, id = false) => {
  const parts = inputString.split("_");
  if (id) return parts[1];
  if (parts.length > 1) {
    return parts[0] + "_" + parts[1]; // Return the string up to and including the first underscore
  } else {
    return inputString; // Return the original string if no underscore is found.
  }
};

export const isValidIpV4 = (ip) => {
  const ipV4Regx =
    /^((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){0,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])?$/;

  const isCS1 = ip.toLowerCase() !== "255.255.255.255";
  const isCS2 = ip.toLowerCase() !== "0.0.0.0";

  const regex = new RegExp(ipV4Regx).test(ip).valueOf();
  if (regex && isCS1 && isCS2) {
    return ip;
  }
};

export function generateRandomString(length = 8) {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  const base62Chars =
    "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += base62Chars[array[i] % base62Chars.length];
  }
  return result;
}

export const profileRegex = {
  name: /^[a-zA-Z\s]*$/,
  numeric: /^[0-9]*$/,
  password: /^[a-zA-Z0-9@]*$/,
  community: /^[a-zA-Z][a-zA-Z0-9 !@#$%^&*_-]*$/,

  usmUser: /^[a-zA-Z0-9]*$/,
};
// export const miscRegex = {
//   numeric: /^[0-9]*\.?[0-9]+$/, // Matches numbers with optional decimal
// };
// export const miscRegexNumeric = {
//   // Allows: empty, "-", "5", "-5", "5.", "-5.5", ".5"
//   // This is used for the onChange character blocking
//   numericInput: /^-?\d*\.?\d*$/,
//   // Standard numeric check for validation logic
//   numeric: /^-?\d+(\.\d+)?$/,
// };
export const miscRegex = {
  // Fix ReDoS: Linear matching structure
  numeric: /^(?:\d+|\d*\.\d+)$/,

  isSafeNumeric: (val) => {
    if (typeof val !== "string" || val.length > 20) return false;
    return miscRegex.numeric.test(val);
  },
};
export const miscRegexNumeric = {
  // Fix ReDoS: structured without overlapping wildcards
  numericInput: /^-?\d*(?:\.\d*)?$/,

  // Fix ReDoS: separate whole numbers and decimals into an explicit OR path
  numeric: /^-?(?:\d+(?:\.\d+)?|\.\d+)$/,

  isSafeInput: (val) => {
    if (typeof val !== "string") return false;
    if (val.length > 32) return false;
    return miscRegexNumeric.numericInput.test(val);
  },
};
