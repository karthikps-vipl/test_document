import React, { useState } from "react";

import { Box, Typography, TextField } from "@mui/material";
import BaseMaintenanceDialog from "./deviceMaintenance/BaseMaintenanceDialog";
import { MOVE_TO_MAINTANANCE } from "@/RestAPI/url/endpoint";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "../Reusable/Toast/Toast";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useDispatch } from "react-redux";
import { updateNodeStatus } from "@/store/features/Topology/topologyNodesslice";
import { updateResourceStatus } from "@/store/features/Inventory/inventorySlice";
import MDialog from "../Reusable/Dialog/MDialog";

const DeleteDeviceDialog = ({ node, onClose }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [formData, setFormData] = useState({
    remark: "",
  });

  const dispatch = useDispatch();

  const isValid = formData.remark.trim().length >= 5;

  // 1. Handle opening the confirmation dialog
  const handleConfirmClick = () => {
    if (!isValid) return;
    setIsConfirmOpen(true);
  };

  const handleConfirmAction = () => {
    setIsConfirmOpen(false);
    handleSubmit();
  };

  const handleCancelConfirm = () => {
    setIsConfirmOpen(false);

    if (onClose) onClose();
  };

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);

      const resourceId = node?.resourceId;
      const url = `${MOVE_TO_MAINTANANCE}/${resourceId}`;

      const payload = {
        remarks: formData.remark,
        resourceId,
      };

      const response = await TopologyAxios(url, "post", payload);

      console.log("etyhtdgh", response?.data);

      if (response?.data) {
        Toast("Success!", "Device deleted successfully.", "success");
        dispatch(updateNodeStatus(response?.data));
        dispatch(
          updateResourceStatus({
            resourceId: resourceId,
            isDiscovered: response.data.isDiscovered,
            isMaintainance: response.data.isMaintainance,
            lstPortInfoDtl: response.data.lstPortInfoDtl || null,
          })
        );
        onClose();
      } else {
        Toast("Error!", "Failed to delete device.", "error");
      }
    } catch (error) {
      console.error("API Error:", error);
      Toast("Error!", "Server error", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Box>
      <MDialog
        open={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        deviceName={node?.resourceName || "Unknown Device"}
        onConfirm={handleConfirmAction}
        onCancel={handleCancelConfirm}
        title="CONFIRM!"
        message={<>Are you sure want to Delete {node.resourceName}?</>}
        confirmText="Delete"
        cancelText="Cancel"
        variant="error"
        icon={Delete_Icon_}
      />

      <BaseMaintenanceDialog
        open
        title="Delete Device"
        variant="error"
        icon={Delete_Icon_}
        onClose={onClose}
        onConfirm={handleConfirmClick}
        confirmDisabled={!isValid}
        isSubmitting={isSubmitting}
        type="deleteDevice"
      >
        <Box sx={{ mt: 2.5 }}>
          <Typography
            variant="body2"
            sx={{ fontWeight: "600", mb: 0.9, textAlign: "center" }}
          >
            {`DELETING ${node.resourceName}`}
          </Typography>

          <Typography
            variant="body2"
            sx={{ fontWeight: "600", mb: 0.5, textAlign: "left" }}
          >
            Remarks*
          </Typography>

          <TextField
            fullWidth
            multiline
            minRows={2}
            maxRows={3}
            placeholder="Add your remarks here"
            variant="outlined"
            value={formData.remark}
            onChange={(e) =>
              setFormData({ ...formData, remark: e.target.value })
            }
            error={formData.remark.length > 0 && formData.remark.length < 5}
            helperText={
              formData.remark.length > 0 && formData.remark.length < 5
                ? "Min 5 characters"
                : ""
            }
            sx={{
              "& .MuiOutlinedInput-root": { borderRadius: "12px" },
              marginBottom: "16px",
            }}
          />
        </Box>
      </BaseMaintenanceDialog>
    </Box>
  );
};

export default DeleteDeviceDialog;
