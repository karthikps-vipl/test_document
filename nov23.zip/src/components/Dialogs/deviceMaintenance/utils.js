export const formatIPMask = (value = "") => {
  let digits = value.replace(/\D/g, "").slice(0, 12);

  let parts = [];

  for (let i = 0; i < 4; i++) {
    let segment = digits.slice(i * 3, i * 3 + 3);
    parts.push(segment.padEnd(3, "_"));
  }

  return parts.join(".");
};

export const isValidIpV4 = (ip) => {
  const cleanIp = ip.replace(/_/g, "");

  // The regex must be on one continuous line without physical line breaks
  const ipRegex =
    /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  return ipRegex.test(cleanIp);

//   const regex =
//   /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;

// return regex.test(ip);
};
