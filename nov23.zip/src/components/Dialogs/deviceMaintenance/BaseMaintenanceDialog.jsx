import React from "react";

import {
  Box
} from "@mui/material";
import MDialog from "@/components/Reusable/Dialog/MDialog";


// const BaseMaintenanceDialog = ({
//   open,
//   icon,
//   variant,
//   children,
//   onClose,
//   onConfirm,
//   confirmDisabled,
//   isSubmitting,
//   type
// }) => {
//   return (
//     <MDialog
//     open={open}
//     type={type}
//     icon={icon}
//     variant={variant}
//     onClose={onClose}
//     onConfirm={onConfirm}
//     confirmDisabled={confirmDisabled}
//   >
//       <Box
//         sx={{
//           width: "100%",
//           mt: -4,
//           px: 1,
//           display: "flex",
//           flexDirection: "column",
//           gap: 2,
//         }}
//       >
//         {children}
//       </Box>
//     </MDialog>
//   );
// };

const BaseMaintenanceDialog = ({
  open,
  icon,
  variant,
  children,
  onClose,
  onConfirm,
  confirmDisabled,
  isSubmitting,
  type
}) => {
  return (
    <MDialog
      open={open}
      type={type}
      icon={icon}
      variant={variant}
      onClose={onClose}
      onConfirm={onConfirm}
      confirmDisabled={confirmDisabled}
      isSubmitting={isSubmitting}
    >
      <Box
        sx={{
          width: "100%",
          mt: -4,
          px: 1,
          display: "flex",
          flexDirection: "column",
          gap: 2,
        }}
      >
        {children}
      </Box>
    </MDialog>
  );
};

export default BaseMaintenanceDialog;