import React, { useState } from "react";

import { Box, Typography, TextField } from "@mui/material";

import { useDispatch } from "react-redux";

import Add_Icon from "@/assets/SVGIcons/Ack_Tick_Icon.svg";

import { isValidIpV4 } from "./deviceMaintenance/utils";
import BaseMaintenanceDialog from "./deviceMaintenance/BaseMaintenanceDialog";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import { ADD_DEVICE } from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";
import { updateNodeStatus } from "@/store/features/Topology/topologyNodesslice";
import {
  setInventoryData,
  updateAddDeviceIP,
  updateResourceStatus,
} from "@/store/features/Inventory/inventorySlice";
import MDialog from "../Reusable/Dialog/MDialog";

const AddDeviceDialog = ({ node, onClose }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const placeHolderIp = "___.___.___";
  
  const [formData, setFormData] = useState({
    remark: "",
    resourceIp: node?.resourceIp || "",
  });

 const dispatch = useDispatch();

  // Validation Logic
  const rawIpForValidation = formData.resourceIp;
  const isIpValid = isValidIpV4(rawIpForValidation);
  const isRemarkValid = formData.remark.trim().length >= 5;
  
  const isFormFilled = isIpValid && isRemarkValid;

  const handleIpChange = (e) => {
    let value = e.target.value;
    value = value.replace(/[^\d.]/g, "");
    value = value.replace(/\.{2,}/g, ".");
    const octets = value.split(".");
    const limitedOctets = octets.slice(0, 4);
    const formattedOctets = limitedOctets.map((octet) => octet.slice(0, 3));
    const formattedIp = formattedOctets.join(".");

    setFormData((prev) => ({
      ...prev,
      resourceIp: formattedIp,
    }));
  };

  const ipError = rawIpForValidation.length > 0 && !isIpValid;

 
  const handleConfirmClick = () => {
    if (!isFormFilled) return;
    setIsConfirmOpen(true);
  };

 
  const handleConfirmAction = () => {
    setIsConfirmOpen(false);
    handleSubmit();
  };

 
  const handleCancelConfirm = () => {
    setIsConfirmOpen(false);
 
    if (onClose) onClose(); 
  };

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      const resourceId = node?.resourceId;
      const url = `${ADD_DEVICE}/${resourceId}`;

      const payload = {
        resourceId,
        resourceIp: formData.resourceIp,
        remarks: formData.remark,
      };

      const response = await TopologyAxios(url, "post", payload);

      console.log("rjhgjrhg", response?.data);

      if (
        response?.data &&
        response?.data.isDiscovered &&
        !response?.data.isMaintainance
      ) {
        Toast("Success!", "Device added successfully!", "success");
        dispatch(updateNodeStatus(response?.data));
        dispatch(
          updateResourceStatus({
            resourceId: resourceId,
            isDiscovered: response.data.isDiscovered,
            isMaintainance: response.data.isMaintainance,
            lstPortInfoDtl: response.data.lstPortInfoDtl
          })
        );
        dispatch(updateAddDeviceIP(response?.data))
        onClose(); // Close after successful add
      } else if (
        response?.data &&
        !response?.data.isDiscovered &&
        response?.data.isMaintainance
      ) {
        Toast("Info!", response?.data.discoveredstatusMessage);
        // Optional: onClose(); // Uncomment if you want to close on Info too
      } else {
        Toast("Error!", "Failed to add device.", "error");
      }
    } catch (error) {
      console.error("API Error:", error);
      Toast("Error!", "Server error", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Box>
      {/* 1. Render the Custom Confirmation Dialog (MDialog) */}
      <MDialog
        open={isConfirmOpen}
        onClose={handleCancelConfirm} // Pass the handler that closes the main form
        onConfirm={handleConfirmAction}
        title="CONFIRM!"
        message={
          <>
            Are you sure want to Add <strong>{node.resourceName}</strong>?
          </>
        }
        confirmText="Add"
        cancelText="Cancel"
        icon={Add_Icon}
        variant="primary"
        showButtons={true}
      />

      {/* 2. Render the Main Form Dialog */}
      <BaseMaintenanceDialog
        open
        variant="primary"
        icon={Add_Icon}
        onClose={onClose}
        onConfirm={handleConfirmClick} // This opens the MDialog above
        confirmDisabled={!isFormFilled}
        isSubmitting={isSubmitting}
        type="addDevice"
      >
        <Box sx={{ mt: 2.5 }}>
          <Typography
            variant="body2"
            sx={{ fontWeight: "600", mb: 0.5, textAlign: "center" }}
          >
            {`ADDING ${node.resourceName}`}
          </Typography>

          <Typography
            variant="body2"
            sx={{ fontWeight: "600", mb: 0.5, textAlign: "left" }}
          >
            IP Address*
          </Typography>
          <TextField
            fullWidth
            size="small"
            variant="outlined"
            placeholder={placeHolderIp}
            value={formData.resourceIp}
            onChange={handleIpChange}
            error={ipError}
            helperText={
              ipError
                ? "Please enter a valid IPv4 address (e.g. 192.168.1.1)"
                : ""
            }
            inputProps={{
              maxLength: 15,
              inputMode: "numeric",
            }}
            sx={{
              "& .MuiOutlinedInput-root": {
                borderRadius: "12px",
              },
            }}
          />
        </Box>

        <Box>
          <Typography
            variant="body2"
            sx={{ fontWeight: "600", mb: 0.5, textAlign: "left" }}
          >
            Remarks*
          </Typography>

          <TextField
            fullWidth
            multiline
            minRows={2}
            maxRows={3}
            placeholder="Add your remarks here"
            variant="outlined"
            value={formData.remark}
            onChange={(e) => setFormData({ ...formData, remark: e.target.value })}
            error={formData.remark.length > 0 && formData.remark.length < 5}
            helperText={
              formData.remark.length > 0 && formData.remark.length < 5
                ? "Min 5 characters"
                : ""
            }
            sx={{
              "& .MuiOutlinedInput-root": { borderRadius: "12px" },
              marginBottom: "16px",
            }}
          />
        </Box>
      </BaseMaintenanceDialog>
    </Box>
  );
};

export default AddDeviceDialog;


// const AddDeviceDialog = ({ node, onClose }) => {
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const placeHolderIp = "___.___.___";
//   const [formData, setFormData] = useState({
//     remark: "",
//     // resourceIp: formatIPMask(node?.resourceIp || ""),
//     resourceIp: node?.resourceIp || "",
//   });

//   const dispatch = useDispatch();

//   // const rawIpForValidation = useMemo(() => {
//   //   return formData.resourceIp.replace(/_/g, "");
//   // }, [formData.resourceIp]);

//   const rawIpForValidation = formData.resourceIp;

//   const isIpValid = isValidIpV4(rawIpForValidation);

//   const isRemarkValid = formData.remark.trim().length >= 5;

//   const isAddValid = isIpValid && isRemarkValid;

//   const handleIpChange = (e) => {
//     let value = e.target.value;

//     // Allow only digits and dots
//     value = value.replace(/[^\d.]/g, "");

//     // Prevent consecutive dots
//     value = value.replace(/\.{2,}/g, ".");

//     // Split into octets
//     const octets = value.split(".");

//     // Limit to 4 octets
//     const limitedOctets = octets.slice(0, 4);

//     // Limit each octet to 3 digits
//     const formattedOctets = limitedOctets.map((octet) => octet.slice(0, 3));

//     const formattedIp = formattedOctets.join(".");

//     setFormData((prev) => ({
//       ...prev,
//       resourceIp: formattedIp,
//     }));
//   };

//   const ipError = rawIpForValidation.length > 0 && !isIpValid;

//   const handleSubmit = async () => {
//     try {
//       setIsSubmitting(true);

//       const resourceId = node?.resourceId;

//       const url = `${ADD_DEVICE}/${resourceId}`;

//       const payload = {
//         resourceId,
//         resourceIp: formData.resourceIp,
//         remarks: formData.remark,
//       };

//       const response = await TopologyAxios(url, "post", payload);

//       console.log("rjhgjrhg", response?.data);

//       if (
//         response?.data &&
//         response?.data.isDiscovered &&
//         !response?.data.isMaintainance
//       ) {
//         Toast("Success!","Device added successfully!", "success");
//         dispatch(updateNodeStatus(response?.data));
//         dispatch(
//           updateResourceStatus({
//             resourceId: resourceId,
//             isDiscovered: response.data.isDiscovered,
//             isMaintainance: response.data.isMaintainance,
//           })
//         );
//         onClose();
//       } else if (
//         response?.data &&
//         !response?.data.isDiscovered &&
//         response?.data.isMaintainance
//       ) {
//         Toast("Info!",response?.data.discoveredstatusMessage);
//       } else {
//         Toast("Error!", "Failed to add device.", "error");
//       }
//     } catch (error) {
//       console.error("API Error:", error);

//       Toast("Error!", "server error", "error");
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <BaseMaintenanceDialog
//       open
//       variant="primary"
//       icon={Add_Icon}
//       onClose={onClose}
//       onConfirm={handleSubmit}
//       confirmDisabled={!isAddValid}
//       isSubmitting={isSubmitting}
//       type="addDevice"
//     >
//       <Box  sx={{mt:2.5}}>

//       <Typography
//           variant="body2"
//           sx={{ fontWeight: "600", mb: 0.5, textAlign: "center" }}
//         >
//          {`ADDING  ${node.resourceName}`}
//         </Typography>

//         <Typography
//           variant="body2"
//           sx={{ fontWeight: "600", mb: 0.5, textAlign: "left" }}
//         >
//           IP Address*
//         </Typography>
//         <TextField
//           fullWidth
//           size="small"
//           variant="outlined"
//           placeholder={placeHolderIp}
//           value={formData.resourceIp}
//           onChange={handleIpChange}
//           error={ipError}
//           helperText={
//             ipError
//               ? "Please enter a valid IPv4 address (e.g. 192.168.1.1)"
//               : ""
//           }
//           inputProps={{
//             maxLength: 15,
//             inputMode: "numeric",
//           }}
//           sx={{
//             "& .MuiOutlinedInput-root": {
//               borderRadius: "12px",
//             },
//           }}
//         />
//       </Box>

//       <Box>
//         <Typography
//           variant="body2"
//           sx={{ fontWeight: "600", mb: 0.5, textAlign: "left" }}
//         >
//           Remarks*
//         </Typography>

//         <TextField
//           fullWidth
//           multiline
//           minRows={2}
//           maxRows={3}
//           placeholder="Add your remarks here"
//           variant="outlined"
//           value={formData.remark}
//           onChange={(e) => setFormData({ ...formData, remark: e.target.value })}
//           error={formData.remark.length > 0 && formData.remark.length < 5}
//           helperText={
//             formData.remark.length > 0 && formData.remark.length < 5
//               ? "Min 5 characters"
//               : ""
//           }
//           sx={{
//             "& .MuiOutlinedInput-root": { borderRadius: "12px" },
//             marginBottom: "16px",
//           }}
//         />
//       </Box>
//     </BaseMaintenanceDialog>
//   );
// };

// export default AddDeviceDialog;

