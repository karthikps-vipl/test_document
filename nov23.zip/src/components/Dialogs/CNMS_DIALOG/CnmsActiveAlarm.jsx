import { Box, DialogContent } from "@mui/material";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { severityConfig, workflowConfig } from "@/lib/utils";
import { useModalStore } from "@/core/modal/modalStore";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MTable from "@/components/Reusable/Table/MTable";

const CnmsActiveAlarm = () => {
  const { modalProps, closeModal } = useModalStore();
  const segment = modalProps?.node;

  const { cnmsOpenAlarm } = useSelector(
    (state) => state.remoteRepDetails || {}
  );

  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  const dispatch = useDispatch();

  const [activeAlarm, setActiveAlarm] = useState([]);

  const id = segment?.imTerminalType?.id;

  console.log("CnmsActiveAlarm segment", segment);
  console.log("CnmsActiveAlarm terminalTypeId", id);
  console.log("cnmsOpenAlarm", cnmsOpenAlarm);
  console.log("activeAlarmvvv", activeAlarm);

  useEffect(() => {
    if (!id || !Array.isArray(cnmsOpenAlarm)) {
      setActiveAlarm([]);
      return;
    }

    const filteredData = cnmsOpenAlarm
      .filter((alarm) => Number(alarm?.terminalType) === Number(id))
      .map((alarm, index) => {
        return {
          ...alarm,
          sno: index + 1,

          siteID: alarm?.siteId || "NA",

          siteName: alarm?.siteName || "NA",
          device: alarm?.segmentName || "NA",

          alarmName: alarm?.alarmName || "NA",

          alarmDescription: alarm?.alarmDescription || "NA",

          severity: alarm?.severity ?? "NA",

          workflow: alarm?.workflow ?? "NA",

          dateTime: alarm?.dateTime || null,

          alarmCount: alarm?.alarmCount ?? 0,
        };
      });

    console.log("Filtered CNMS Active Alarms", filteredData);

    setActiveAlarm(filteredData);
  }, [cnmsOpenAlarm, id]);

  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "60px",
    },
    {
      uid: "siteID",
      name: "Site ID",
      width: "150px",
    },
    {
      uid: "siteName",
      name: "Site Name",
      width: "220px",
    },
    {
      uid: "device",
      name: "Device",
      width: "180px",
    },
    {
      uid: "alarmName",
      name: "Alarm Name",
      width: "200px",
    },
    {
      uid: "alarmDescription",
      name: "Description",
      width: "300px",
    },
    {
      uid: "severity",
      name: "Severity",
      width: "120px",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      filterOptions: Object.keys(severityConfig).map((key) => {
        const numericKey = Number(key);

        return {
          label: severityConfig[key].label,
          value: numericKey,
          gradient: severityConfig[key].gradient,
        };
      }),
    },
    {
      uid: "workflow",
      name: "Workflow",
      width: "120px",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      uid: "dateTime",
      name: "Date and Time",
      width: "190px",
      sortable: true,
      filterType: "datetime",
      renderCell: (params) => {
        const val = params?.row?.dateTime || params?.dateTime;

        return val ? moment(val).format("YYYY-MM-DD HH:mm:ss") : "N/A";
      },
    },
    {
      uid: "alarmCount",
      name: "Count",
      width: "100px",
      filterType: "textS",
    },
  ];

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  const active_Title = "CNMS - Active Alarms";

  return (
    <Box>
      <DialogContent>
        <Box sx={{ borderRadius: "20px" }}>
          <MTable
            tableTitle={active_Title}
            columns={columns}
            tableData={activeAlarm}
            showSearch={true}
            handleDownloadPDF={() => {
              const sanitizedName = "CNMS_Active_Alarms".replace(/\s+/g, "_");
              const normalName = "CNMS Active Alarms";

              exportToPDF(
                `${normalName} Report`,
                columns,
                activeAlarm,
                `${sanitizedName}_Report`,
                "NMS User"
              );
            }}
            showPagination={true}
            handleClose={closeModal}
            closeIcon={true}
            showMaximazed={true}
            isMaximized={isTableMaximized}
            toggleMaximize={handleToggleMaximize}
          />
        </Box>
      </DialogContent>
    </Box>
  );
};

export default CnmsActiveAlarm;
