
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { Update } from "@mui/icons-material";
import {
  Box,
  Typography,
  TextField,
  Grid,
  Switch,
  FormControlLabel,
  Divider,
  useTheme,
  CircularProgress, // Added for loader
} from "@mui/material";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useModalStore } from "@/core/modal/modalStore";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { CNMS_DELETE_SITE } from "@/RestAPI/url/cnmsendpoint";
import {
  setCnmsDeleteAddSite,
  setSiteMoveToMaintaiance,
  startBlink,
  stopBlink,
} from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MButtonSecondary from "@/components/Reusable/Button/MButtonSecondary";
import { CustomeFullscreen } from "@/components/Reusable/FullScreen/CustomeFullscreen";
import Toast from "@/components/Reusable/Toast/Toast";
import { updateSiteSummarySite } from "@/store/features/Cnms/SiteSummary/siteSummarySlice";

const CnmsMoveToMaintenance = ({ onClose, onSubmit }) => {
  const { modalProps } = useModalStore();
  const segment = modalProps?.node;
  const theme = useTheme();
  const siteId = segment?.siteId;

  console.log("modalPropssegment",modalProps);
  

  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false); // Added state for loader

  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);
  const dispatch = useDispatch();

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  // Move site to maintenance
  const handleMaintenance = async () => {
    // Validation
    if (description.length < 3 || description.length > 255) {
      return;
    }

    try {
      setIsSubmitting(true); // Start Loader

      // maintenanceMode false => 1
      // maintenanceMode true  => 2
      const payload = {
        remarks: description,
        maintenanceType: maintenanceMode ? 2 : 1,
        siteId: siteId,
      };

      console.log("Maintenance Payload:", payload);
      const response = await InventoryAxios(CNMS_DELETE_SITE, "post", payload);

      console.log("Maintenance API Response:", response?.data);
      dispatch(setCnmsDeleteAddSite(response?.data));

      dispatch(updateSiteSummarySite(response?.data));

      let maintenanceType = response?.data?.maintenanceType;

      let status = -1;
      let statusValue = "";
      if (response?.data?.discovered) {
        status = 1;
        statusValue = "UP";
      } else if (response?.data?.isMaintainance) {
        status = 3;
        statusValue = "MAINTENANCE";
      } else {
        console.log(
          "isMaintainance and discovered both are false or undefined"
        );

        status = response?.data?.healthStatus?.id;
        statusValue = response?.data?.healthStatus?.value;
      }

      dispatch(
        startBlink({
          siteId,
          maintenanceType,
        })
      );

      setTimeout(() => {
        dispatch(stopBlink(siteId));
        dispatch(
          setSiteMoveToMaintaiance({
            isMaintainance: response?.data.isMaintainance,
            discovered: response?.data.discovered,
            siteId: response?.data.siteId,
            healthStatusId: status,
            maintenanceType: maintenanceType,
            healthStatusValue: statusValue,
          })
        ); // reducer to update data of site on map

        // SUCCESS TOAST
        Toast("Success", "Site moved to maintenance successfully.", "success");
      }, 10000);

      // If parent component needs the information
      onSubmit?.({
        maintenanceMode,
        description,
        response,
      });

      onClose();
    } catch (error) {
      console.error("Maintenance API Error:", error);

      // ERROR TOAST
      Toast(
        "Error",
        "Failed to move site to maintenance. Please try again.",
        "error"
      );
    } finally {
      setIsSubmitting(false); // Stop Loader
    }
  };

  return (
    <>
      {/* Header Section */}
      <Box
        sx={{
          p: 3,
          width: "100%",
        }}
      >
        <Grid container spacing={0.5}>
          <Grid size={{ xs: 6 }} sx={{ minWidth: 0 }}>
            <Typography
              sx={{
                fontWeight: 600,
                color: theme.palette.text.TitleTextcolor,
                fontSize: 18,
                whiteSpace: "nowrap",
              }}
            >
              MOVE TO MAINTENANCE SITE - {segment?.siteName}
            </Typography>
          </Grid>
          <Grid size={{ xs: 6 }}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center",
                gap: 0.5,
              }}
            >
              {/* MAXIMIZE / MINIMIZE */}
              <CustomeFullscreen
                onClose={onClose}
                isFullScreen={isMaximized}
                onToggleFullScreen={handleToggleMaximize}
              />
            </Box>
          </Grid>
        </Grid>
        <Divider sx={{ my: 0.5 }} />
      </Box>

      {/* Content Area */}
      <Box sx={{ padding: "0px 20px" }}>
        {/* Moving To Section */}
        <Box
          sx={{
            marginBottom: "20px",
            display: "flex",
            alignItems: "center",
          }}
        >
          <Box sx={{ minWidth: "120px" }}>
            <Typography variant="body1" sx={{ fontWeight: 600 }}>
              Moving To :
            </Typography>
          </Box>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
            }}
          >
            <Typography variant="body1" sx={{ fontWeight: 500 }}>
              Non-OPS
            </Typography>
            <FormControlLabel
              control={
                <Switch
                  checked={maintenanceMode}
                  onChange={(e) => setMaintenanceMode(e.target.checked)}
                  color="success"
                  inputProps={{
                    "aria-label": "maintenance switch",
                  }}
                />
              }
              label="R-OPS"
              labelPosition="end"
              sx={{
                "& .MuiSwitch-switchBase.Mui-checked": {
                  color: "#14348d",
                },
                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                  backgroundColor: "#14348d",
                },
              }}
            />
          </Box>
        </Box>

        {/* Description Field */}
        <Box>
          <Typography variant="body1" sx={{ fontWeight: 600 }}>
            Description :
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={3}
            placeholder="Enter description..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            error={
              description.length > 0 &&
              (description.length < 3 || description.length > 255)
            }
            helperText={
              description.length > 0 &&
              (description.length < 3 || description.length > 255)
                ? "Must be length of 3 - 255"
                : ""
            }
            sx={{
              "& .MuiOutlinedInput-root": {
                "& fieldset": {
                  borderColor:
                    description.length > 0 &&
                    (description.length < 3 || description.length > 255)
                      ? "#ff4d4f"
                      : undefined,
                },
                "&:hover fieldset": {
                  borderColor:
                    description.length > 0 &&
                    (description.length < 3 || description.length > 255)
                      ? "#ff4d4f"
                      : undefined,
                },
                "&.Mui-focused fieldset": {
                  borderColor:
                    description.length > 0 &&
                    (description.length < 3 || description.length > 255)
                      ? "#ff4d4f"
                      : undefined,
                },
                "& .MuiInputBase-input": {
                  color: "#757575",
                },
              },
              "& .MuiInputBase-input": {
                color: "#757575",
              },
              "& .MuiFormHelperText-root": {
                color: "#ff4d4f",
              },
            }}
          />
        </Box>
      </Box>

      {/* Footer */}
      <Box
        sx={{
          padding: "10px 20px",
          display: "flex",
          justifyContent: "flex-end",
          gap: "10px",
          alignItems: "flex-start", // Changed to flex-start to align with input alignment style
        }}
      >
        {/* MAINTENANCE Button with Loader Logic */}
        <Box>
          {" "}
          {/* Added pt to align with input field bottom */}
          <MButtonPrimary
            variant="contained"
            color="primary"
            onClick={handleMaintenance}
            disabled={
              description.length < 3 || description.length > 255 || isSubmitting // Disable button while loading
            }
            sx={{ borderRadius: "8px", px: 4 }}
            startIcon={
              isSubmitting ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            {isSubmitting ? "Updating..." : "MAINTENANCE"}
          </MButtonPrimary>
        </Box>

        {/* CANCEL Button */}
        <MButtonSecondary onClick={onClose}>CANCEL</MButtonSecondary>
      </Box>
    </>
  );
};

export default CnmsMoveToMaintenance;
