import React, { useCallback, useMemo } from "react";
import { Box, DialogContent } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { useModalStore } from "@/core/modal/modalStore";
import MTable from "@/components/Reusable/Table/MTable";
import { severityConfig } from "@/lib/utils";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";

/**
 * VehicleActiveAlarm Component
 * Designed for displaying active alarms related to specific vehicles.
 */

const VehicleActiveAlarm = () => {
  const dispatch = useDispatch();
  const { modalProps, closeModal } = useModalStore();

  // Extracting vehicle info from modalProps (passed when opening the dialog)
  const vehicle = modalProps?.node;

  console.log("vehicleActivealarm", vehicle);

  const VehicleSiteId = vehicle?.siteId;
  const VehicleSiteName = vehicle?.siteName;

  // Redux Selectors
  // Note: We will update these paths once the vehicle alarm API integration is ready
  // const vehicleAlarmData = useSelector((state) => state.alarmSlice.vehicleAlarms || []);
  const { cnmsOpenAlarm } = useSelector(
    (state) => state.remoteRepDetails || {}
  );
  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  console.log("cnmsOpenAlarmvehivlealarm", cnmsOpenAlarm);

  /**
   * Helper to handle NULL/Undefined/Empty values for the table UI
   */
  const formatValue = (val) => {
    if (val === null || val === undefined || val === "") {
      return "NA";
    }
    return val;
  };

  // Dynamic Title based on selected vehicle
  //   const titlePrefix = vehicle?.vehicleName ? `${vehicle.vehicleName} Active Alarms` : "Vehicle Active Alarms";
  const headerTitle =
    VehicleSiteId && VehicleSiteName
      ? `${VehicleSiteId} : ${VehicleSiteName} - RNMS ACTIVE ALARMS`
      : "LOADING ALARMS...";

  /**
   * Data Transformation
   * Filters the global alarm list to only show alarms belonging to the specific vehicle selected.
   */
  const processedAlarmData = useMemo(() => {
    if (!VehicleSiteId) return [];

    return cnmsOpenAlarm
      .filter((alarm) => alarm.siteId === VehicleSiteId)
      .map((alarm) => ({
        ...alarm,
        // Ensuring fields show "NA" for a clean UI
        vehicleName: formatValue(alarm.vehicleName),
        device: formatValue(alarm.deviceName),
        ipAddress: formatValue(alarm.ipAddress),
        alarmName: formatValue(alarm.alarmName),
        description: formatValue(alarm.alarmDescription),
        severity: formatValue(alarm.severity),
        workflow: formatValue(alarm.workflow),
        dateTime: formatValue(alarm.dateTime),
        count: formatValue(alarm.alarmCount),
      }));
  }, [cnmsOpenAlarm, vehicle]);


  console.log("cnmsvehicleactiveAlarmvvv ",processedAlarmData );
  
  /**
   * Column Definitions matching the provided UI Design
   */
  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "60px",
    },
    {
      name: "Device",
      uid: "device",
      sortable: true,
      filterType: "text", // Search bar in UI
    },
    {
      name: "Alarm Name",
      uid: "alarmName",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Description",
      uid: "description",
      width: "244px",
      sortable: true,
      filterType: "text",
    },
    {
      name: "Severity",
      uid: "severity",
      sortable: true,
      filterType: "dropdown",
      width: "115px",
      filterOptions: Object.keys(severityConfig).map((key) => ({
        label: severityConfig[key].label,
        value: key,
        gradient: severityConfig[key].gradient,
      })),
    },
    {
      name: "Workflow",
      uid: "workflow",
      sortable: true,
      filterType: "dropdown",
      width: "125px",
      filterOptions: [
        { label: "ACK", value: 1 },
        { label: "NOT_ACK", value: 0 },
      ],
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      filterType: "datetime",
    },
    {
      name: "Count",
      uid: "count",
      sortable: true,
      width: "80px",
    },
  ];

  /**
   * Handlers
   */
  const handleToggleMaximize = useCallback(() => {
    dispatch(toggleTableMaximize());
  }, [dispatch]);

  const handleClose = () => {
    if (closeModal) closeModal();
  };

  const handleDownloadPDF = () => {
    const sanitizedName = headerTitle.replace(/\s+/g, "_");
    const fileName = `${sanitizedName}_Report`;

    exportToPDF(
      `${headerTitle} Report`,
      columns,
      processedAlarmData,
      fileName,
      "NMS User"
    );
  };

  return (
    <Box>
      <DialogContent>
        <Box sx={{ borderRadius: "20px", overflow: "hidden", padding: "3px" }}>
          <MTable
            columns={columns}
            tableData={processedAlarmData}
            tableTitle={headerTitle.toUpperCase()}
            showPagination
            showSearch
            showVisibleContent
            handleClose={handleClose}
            closeIcon={true}
            showMaximazed={true}
            isMaximized={isTableMaximized}
            toggleMaximize={handleToggleMaximize}
            handleDownloadPDF={handleDownloadPDF}
          />
        </Box>
      </DialogContent>
    </Box>
  );
};

export default VehicleActiveAlarm;
