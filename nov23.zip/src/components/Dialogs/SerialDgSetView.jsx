import React, { useMemo } from "react";
import { Box, Typography, Grid, Paper, } from "@mui/material";
import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";
import MTextAreaAntD from "../Reusable/Texarea/MTextArea";
import {  PowerSettingsNewOutlined } from "@mui/icons-material";

const SerialDgSetView = ({ liveData }) => {
  const data = liveData || {};

  console.log(liveData, "lsklskdls");

  // Extract canvas renderers from your existing registry definitions
  const ScaleWidget = WIDGET_REGISTRY.scale?.renderCanvas;
  // const VoltageWidget = WIDGET_REGISTRY.voltageGauge?.renderCanvas;
  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  // Define configurations with appropriate bounds and units
  const speedWidgetConfig = useMemo(
    () => ({
      gridTitle: "Engine Speed",
      minVal: 0,
      maxVal: 6000,
      unit: "RPM",
      innerRange:6,
      data: [{ currentValue: data?.engineSpeed ?? 0 }],
    }),
    [data?.engineSpeed]
  );

  const batteryWidgetConfig = useMemo(
    () => ({
      gridTitle: "Engine Battery Voltage",
      minVal: 0,
      maxVal: 75,
      unit: "V",
      innerRange:10,
      data: [{ currentValue: data?.engineBatteryVoltage ?? 0 }],
    }),
    [data?.engineBatteryVoltage]
  );

  const runHoursWidgetConfig = useMemo(
    () => ({
      gridTitle: "Engine Run Hours",
      minVal: 0,
      maxVal: 10000,
      unit: "Hrs",
      innerRange:5,
      data: [{ currentValue: data?.engineRunHourHR ?? 0 }],
      displayValue: data?.engineRunHours || "0hrs 0min",
      dgSet: true,
    }),
    [data?.engineRunHourHR]
  );
  // Helper mock widget objects that match your exact registry expected structures
  const fuelWidget = useMemo(
    () => ({
      tableTitle: "Fuel Level",
      minVal: 0,
      maxVal: 130,
      data: [{ name: "Fuel Level (%)", currentValue: data?.fuelLevel ?? 0 }],
    }),
    [data?.fuelLevel]
  );

  // const coolantWidget = {
  //   tableTitle: "Coolant Temperature",
  //   minVal: 0,
  //   maxVal: 100,
  //   data: [
  //     {
  //       name: "Coolant Temperature (deg C)",
  //       currentValue: data?.coolantTemperature ?? 0,
  //     },
  //   ],
  // };

  // const batteryVoltageWidget = {
  //   gridTitle: "Engine Battery Voltage",
  //   data: [
  //     { name: "Battery Voltage Name" },
  //     {
  //       name: "Battery Status",
  //       currentValue: data?.dgRunning ? "Running" : "Stopped",
  //     },
  //     {
  //       name: "Battery Voltage Value",
  //       currentValue: data?.engineBatteryVoltage ?? 0,
  //       oid: "engineBatteryVoltage",
  //     },
  //   ],
  // };

  // const engineSpeedWidget = {
  //   gridTitle: "Engine Speed",
  //   data: [
  //     { name: "Engine Speed Name" },
  //     {
  //       name: "Speed Status",
  //       currentValue: data?.dgRunning ? "Running" : "Stopped",
  //     },
  //     {
  //       name: "Engine Speed Value",
  //       currentValue: data?.engineSpeed ?? 0,
  //       oid: "engineSpeed",
  //     },
  //   ],
  // };

  // const engineRunHoursWidget = {
  //   gridTitle: "Engine Run Hours",
  //   data: [
  //     { name: "Run Hours Name" },
  //     {
  //       name: "Run Hours Status",
  //       currentValue: data?.dgRunning ? "Running" : "Stopped",
  //     },
  //     {
  //       name: "Run Hours Value",
  //       currentValue: data?.engineRunHourHR ?? 0,
  //       oid: "engineRunHourHR",
  //     },
  //   ],
  // };

  return (
    <Box sx={{ p: 3, backgroundColor: "#f4f6f8", minHeight: "100vh" }}>
      {/* SECTION 1: General Status with Registry Scale Widgets */}
      <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={2}
        >
          <Typography variant="h6">Note:</Typography>
          <Typography variant="body2" p={1}>
            Ensure the Toggle switch (Auto/Bypass) to be in Auto mode, then
            select Manual mode button on the DSE controller, press the start
            button and select the load on Generator button from DSE controller.
          </Typography>
          {/* <Chip
            label={data?.dgRunning ? "DG Running" : "DG Stopped"}
            color={data?.dgRunning ? "success" : "default"}
            sx={{ fontWeight: "bold" }}
          /> */}
        </Box>
        <Grid spacing={3} className="grid grid-cols-2 gap-4">
          <Grid className="flex flex-col gap-2">
            <Typography
              variant="h6"
              fontWeight="bold"
              mb={2}
              display="flex"
              alignItems="center"
              gap={1}
            >
              Generator
              <PowerSettingsNewOutlined
                color={data?.dgRunning ? "success" : "error"}
                fontSize="medium"
              />
              <span style={{ color: data?.dgRunning ? "#2e7d32" : "#d32f2f" }}>
                {data?.dgRunning ? "ON" : "OFF"}
              </span>
            </Typography>
            <Grid className="flex flex-col gap-2">
              <Grid item xs={12} md={6}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Fuel Level (%)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.fuelLevel ?? ""}
                    showUnit={true}
                    unit="%"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} md={6}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Coolant Temperature (deg C)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.coolantTemperature ?? ""}
                    showUnit={true}
                    unit="°C"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
            </Grid>

            <Grid item xs={12} md={6}>
              <Box
                sx={{
                  height: "220px",
                  border: "1px solid #e0e0e0",
                  borderRadius: 2,
                  backgroundColor: "#fff",
                  overflow: "hidden",
                }}
              >
                {ScaleWidget && ScaleWidget(fuelWidget)}
              </Box>
            </Grid>
          </Grid>

          <Grid item xs={12} md={6} className="flex flex-col gap-2">
            <Paper sx={{ p: 1, height: "100%", borderRadius: 2 }}>
              <Typography variant="h6" fontWeight="bold" mb={2}>
                Mains Information
              </Typography>
              <Grid className="grid grid-cols-2 gap-3" spacing={2}>
                <Grid item xs={6}>
                  <Box
                    sx={{
                      p: 1.5,
                      backgroundColor: "#fafafa",
                      border: "1px solid #e0e0e0",
                      borderRadius: 1,
                    }}
                  >
                    <Typography
                      sx={{
                        mb: 0.3,
                        fontSize: "13px",
                        fontWeight: 500,
                        color: "#555",
                      }}
                    >
                      Mains Frequency
                    </Typography>
                    <MTextAreaAntD
                      autoSize={{ minRows: 1, maxRows: 3 }}
                      value={data?.mainsFrequency ?? ""}
                      showUnit={true}
                      unit="Hz"
                      onChange={(e) => console.log(e.target.value)}
                    />
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box
                    sx={{
                      p: 1.5,
                      backgroundColor: "#fafafa",
                      border: "1px solid #e0e0e0",
                      borderRadius: 1,
                    }}
                  >
                    <Typography
                      sx={{
                        mb: 0.3,
                        fontSize: "13px",
                        fontWeight: 500,
                        color: "#555",
                      }}
                    >
                      Mains L1-N Voltage
                    </Typography>
                    <MTextAreaAntD
                      autoSize={{ minRows: 1, maxRows: 3 }}
                      value={data?.mainsL1_NVoltage ?? ""}
                      showUnit={true}
                      unit="V"
                      onChange={(e) => console.log(e.target.value)}
                    />
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  {/* <Box
                    sx={{
                      p: 1.5,
                      backgroundColor: "#fafafa",
                      border: "1px solid #e0e0e0",
                      borderRadius: 1,
                    }}
                  >
                    <Typography
                      sx={{
                        mb: 0.3,
                        fontSize: "13px",
                        fontWeight: 500,
                        color: "#555",
                      }}
                    >
                      Mains L1 Current
                    </Typography>
                    <MTextAreaAntD
                      autoSize={{ minRows: 1, maxRows: 3 }}
                      value={data?.mainsL1Current ?? ""}
                      showUnit={true}
                      unit="A"
                      onChange={(e) => console.log(e.target.value)}
                    />
                  </Box> */}
                </Grid>
                <Grid item xs={6}>
                  <Box
                    sx={{
                      p: 1.5,
                      backgroundColor: "#fafafa",
                      border: "1px solid #e0e0e0",
                      borderRadius: 1,
                    }}
                  >
                    <Typography
                      sx={{
                        mb: 0.3,
                        fontSize: "13px",
                        fontWeight: 500,
                        color: "#555",
                      }}
                    >
                      Mains Earth Current
                    </Typography>
                    <MTextAreaAntD
                      autoSize={{ minRows: 1, maxRows: 3 }}
                      value={data?.mainsEarthCurrent ?? ""}
                      showUnit={true}
                      unit="A"
                      onChange={(e) => console.log(e.target.value)}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Paper>

      <Grid spacing={3}>
        {/* SECTION 3: Engine Information with Inputs & Voltage Widgets */}
        <Grid item xs={12} md={6} mb={2}>
          <Paper sx={{ p: 3, height: "100%", borderRadius: 2 }}>
            <Typography variant="h6" fontWeight="bold" mb={2}>
              Engine Information
            </Typography>
            <Grid spacing={2} className="grid grid-cols-3 gap-3">
            <Grid item xs={12}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Engine Speed (RPM)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.engineSpeed ?? ""}
                    showUnit={true}
                    unit="RPM"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Engine Battery Voltage (V)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.engineBatteryVoltage ?? ""}
                    showUnit={true}
                    unit="V"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>

  

              <Grid item xs={12}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Engine Run Hours 
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.engineRunHours ?? ""}
                    showUnit={true}
                    unit=""
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
            </Grid>
            <Grid className="grid grid-cols-3 gap-3">
              <Box
                sx={{
                  mt: 2,
                  border: "1px solid #e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                }}
              >
                {/* {VoltageWidget && VoltageWidget(engineSpeedWidget)} */}
                {DialGaugeWidget && DialGaugeWidget(speedWidgetConfig)}
              </Box>
              <Box
                sx={{
                  mt: 2,
                  border: "1px solid #e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                }}
              >
                {/* {VoltageWidget && VoltageWidget(batteryVoltageWidget)} */}
                {DialGaugeWidget && DialGaugeWidget(batteryWidgetConfig)}
              </Box>
              <Box
                sx={{
                  mt: 2,
                  border: "1px solid #e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                }}
              >
                {/* {VoltageWidget && VoltageWidget(engineRunHoursWidget)} */}
                {DialGaugeWidget && DialGaugeWidget(runHoursWidgetConfig)}
              </Box>
            </Grid>
            <Grid className="grid grid-cols-2 gap-3 mt-3">
              <Grid item xs={12}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Engine Oil Pressure (Kpa)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    // Change engineOilPressure if some other name
                    value={data?.engineOilPressue ?? ""}
                    showUnit={true}
                    unit="Kpa"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Box
                  sx={{
                    p: 2,
                    border: "1px solid #e0e0e0",
                    borderRadius: 2,
                    backgroundColor: "#fafafa",
                  }}
                >
                  <Typography
                    sx={{
                      mb: 1,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Engine Charge alternator voltage (V)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    // Change engineChargeAltVolts if some other name
                    value={data?.engineChargeAltVolts ?? ""}
                    showUnit={true}
                    unit="V"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* SECTION 4: Generator Information */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" fontWeight="bold" mb={2}>
              Generator Information
            </Typography>
            <Grid className="grid grid-cols-3 gap-3" spacing={2}>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    // backgroundColor: "#f0f0f0",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator(Output) Frequency
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorFrequency ?? ""}
                    showUnit={true}
                    unit="Hz"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator L1-N(Output) Voltage
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorL1_NVoltage ?? ""}
                    showUnit={true}
                    unit="V"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator L1 Current
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorL1Current ?? ""}
                    showUnit={true}
                    unit="A"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator L1 Watts
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorL1Watts ?? ""}
                    showUnit={true}
                    unit="W"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Power Factor (L1)
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorPowerFactorL1 ?? ""}
                    showUnit={true}
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Average Power Factor
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorAveragePowerFactor ?? ""}
                    showUnit={true}
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator L1 VA
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorL1_VA ?? ""}
                    showUnit={true}
                    unit="VA"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator L1 Var
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorL1Var ?? ""}
                    showUnit={true}
                    unit="Var"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>

              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator L2 Var
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorL2Var ?? ""}
                    showUnit={true}
                    unit="Var"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Generator Total Var
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorTotalVar ?? ""}
                    showUnit={true}
                    unit="Var"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    KVA Hours
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorKVAHours ?? ""}
                    showUnit={true}
                    unit="kVAh"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    KVAr Hours
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorKVArHours ?? ""}
                    showUnit={true}
                    unit="kVArh"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box
                  sx={{
                    p: 1.5,
                    backgroundColor: "#fafafa",
                    border: "1px solid #e0e0e0",
                    borderRadius: 1,
                  }}
                >
                  <Typography
                    sx={{
                      mb: 0.3,
                      fontSize: "13px",
                      fontWeight: 500,
                      color: "#555",
                    }}
                  >
                    Positive KW Hours
                  </Typography>
                  <MTextAreaAntD
                    autoSize={{ minRows: 1, maxRows: 3 }}
                    value={data?.generatorPositiveKWHours ?? ""}
                    showUnit={true}
                    unit="kWh"
                    onChange={(e) => console.log(e.target.value)}
                  />
                </Box>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SerialDgSetView;
