import React from "react";
import {
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { CustomeFullscreen } from "../Reusable/FullScreen/CustomeFullscreen";

const BaseDialogLayout = ({ title, children, onClose }) => {
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);
  const dispatch = useDispatch();
  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  return (
    <>
      <DialogTitle>{title}</DialogTitle>
       <Box sx={{ position: "absolute", right: 30, top: 16 }}>
        {/* <Tooltip title={isMaximized ? "Exit Full Screen" : "Enter Full Screen"}>
          <IconButton onClick={handleToggleMaximize}>
            {isMaximized ? <FullscreenExit /> : <Fullscreen />}
          </IconButton>
        </Tooltip>
        <SquareIconButton onClick={onClose}>
          <CloseIcon />
        </SquareIconButton> */}
       <CustomeFullscreen onClose={onClose} isFullScreen={isMaximized}  onToggleFullScreen={handleToggleMaximize}/>

      </Box> 
      <DialogContent dividers>{children}</DialogContent>

      <DialogActions>
        <Button onClick={onClose} sx={{ position: "relative",width:"7%",borderRadius:"8px", right: 15 ,backgroundColor:"#14348d",color:'white'}}>
          Close
        </Button>
      </DialogActions>
    </>
  );
};

export default BaseDialogLayout;
