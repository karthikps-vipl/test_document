import React, { useCallback, useEffect, useState } from "react";
import {
  Box,
  Typography,
  Divider,
  TextField,
  useTheme,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import CustomSwitch from "../Switch/CustomSwitch";
import { CircularProgress } from "@mui/material";
import { Update } from "@mui/icons-material";
import MButtonPrimary from "../Reusable/Button/MButtonPrimary";
import {
  FETCH_RESOURCE_INFO_DEVICEID,
  INVENTORY_UPDATE_RESOURCEINFO,
} from "@/RestAPI/url/endpoint";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import { useDispatch, useSelector } from "react-redux";
import { toggleTableMaximize, updateInventoryDetails } from "@/store/features/Inventory/inventorySlice";
import { CustomeFullscreen } from "../Reusable/FullScreen/CustomeFullscreen";
import { refreshAlarmData } from "@/utility/alarmService";

const Field = ({
  label,
  name,
  disabled,
  formik,
  multiline,
  minRows,
  maxRows,
  maxLength,
  isCnms,
  ...props
}) => {
  const charCount = formik.values[name]?.length || 0;

  const enableCNMSText = isCnms ? !disabled : disabled
  return (
    <Box sx={{ mb: 1 }}>
      <Typography
        sx={{
          fontSize: 13,
          mb: 0.5,
          fontWeight: 600,
          color: enableCNMSText ? "text.disabled" : "text.primary",
        }}
      >
        {label}
      </Typography>

      <TextField
        fullWidth
        name={name}
        value={formik.values[name]}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        disabled={isCnms ? !disabled : disabled}
        error={!disabled && Boolean(formik.errors[name])}
        helperText=""
        multiline={multiline}
        minRows={minRows}
        maxRows={maxRows}
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "12px",
          },
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: disabled ? "divider" : "rgba(0, 0, 0, 0.23)",
          },
        }}
        {...props}
      />
      {!disabled && (
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mt: 0.5,
            px: 0.5,
          }}
        >
          <Typography sx={{ fontSize: 11, color: "text.secondary" }}>
            {maxLength ? `${charCount}/${maxLength} characters` : ""}
          </Typography>

          <Typography
            sx={{
              fontSize: 11,
              color: formik.errors[name] ? "error.main" : "transparent",
              fontWeight: 500,
              textAlign: "right",
              visibility: formik.errors[name] ? "visible" : "hidden",
            }}
          >
            {formik.errors[name] || ""}
          </Typography>
        </Box>
      )}
    </Box>
  );
};

const InventoryDialog = ({ node, onClose }) => {
  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resourceInfo, setResourceInfo] = useState();
  // const [inventory, setInventoryData] = useState({});
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);
  const dispatch = useDispatch();
  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  console.log("cnmsinventory", node);

  const { isCnms } = useSelector((state) => state.nodeDetails);

  const segment = node?.imSegmentInfo?.segmentName;
  const resourceId = node?.resourceId;

  useEffect(() => {
    if (!isCnms) {
      fetchResourceInfo();
    }
  }, [resourceId]);

  const fetchResourceInfo = useCallback(async () => {
    try {
      const url = `${FETCH_RESOURCE_INFO_DEVICEID}/${resourceId}`;
      const response = await InventoryAxios(url, "get");
      // setInputValue(`${response.data.pollingInterval}`);
      setResourceInfo(response?.data);
    } catch (error) {
      Toast("Error", "server error", "error");
    }
  }, [resourceId]);

  const formik = useFormik({
    enableReinitialize: true, // This is crucial
    initialValues: {
      // We check resourceInfo first, then fallback to node, then fallback to empty string
      make:
        resourceInfo?.imResourceType?.make || node?.imResourceType?.make || "",
      deviceIp: resourceInfo?.resourceIp || node?.resourceIp || "",
      serialNumber:
        resourceInfo?.resourceSerialno || node?.resourceSerialno || "",
      description: resourceInfo?.resourceDesc || node?.resourceDesc || "",
      model:
        resourceInfo?.imResourceType?.model ||
        node?.imResourceType?.model ||
        "",
      terminalName:
        resourceInfo?.imResourceType?.terminalId?.terminalTypeName ||
        node?.imResourceType?.terminalId?.terminalTypeName ||
        "",
      firmwareVersion:
        resourceInfo?.firmwareVersion || node?.firmwareVersion || "",
    },
    // ... validationSchema and onSubmit remain the same

    validationSchema: Yup.object({
      serialNumber: Yup.string()
        .min(5, "Must be at least 5 characters")
        .required("Required"),
      description: Yup.string()
        .min(5, "Must be at least 5 characters")
        .max(250, "Must be at most 250 characters") // Added max
        .required("Required"),
      firmwareVersion: Yup.string()
        .min(3, "Must be at least 3 characters")
        .required("Required"),
    }),
    onSubmit: async (values) => {
      try {
        setLoading(true);
        const resourceId = node?.resourceId;
        const url = `${INVENTORY_UPDATE_RESOURCEINFO}/${resourceId}`;

        const payload = {
          ...node,
          resourceSerialno: values.serialNumber,
          resourceDesc: values.description,
          firmwareVersion: values.firmwareVersion,
        };

        // Using TopologyAxios pattern
        const response = await InventoryAxios(url, "post", payload);

        // setInventoryData(response?.data);
        console.log("inventoryyyyy",response?.data);
        
        dispatch(updateInventoryDetails(response?.data))

        if (response?.data) {
          await refreshAlarmData(dispatch);
          Toast(
            "Success!",
            "Resource information updated successfully.",
            "success"
          );
          onClose();
        } else {
          Toast("Error!", "Failed to update resource information.", "error");
        }
      } catch (error) {
        console.error("API Error:", error);
        Toast("Error!", "server error", "error");
      } finally {
        setLoading(false);
      }
    },
  });

  // Reset Formik so it reverts to the original data passed in initialValues
  const toggleEditMode = () => {
    if (editMode) {
      formik.resetForm();
    }
    setEditMode(!editMode);
  };
  const theme = useTheme();

  return (
    <Box sx={{ p: 3, minWidth: 600 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          position: "relative",
        }}
      >
        <Typography
          sx={{ fontWeight: 600, color: theme.palette.text.TitleTextcolor }}
        >
          {segment} : {node?.resourceName}
        </Typography>
        <Box sx={{ position: "absolute", right: 0 }}>
          <CustomeFullscreen
            onClose={onClose}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </Box>
      </Box>

      <Divider sx={{ my: 2 }} />

      {/* VIEW/EDIT TOGGLE */}
      {!isCnms && (
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            gap: 2,
            mb: 2,
          }}
          onClick={toggleEditMode}
        >
          <Typography sx={{ fontWeight: 600, fontSize: 14 }}>
            View Mode
          </Typography>
          <CustomSwitch
            checked={editMode}
            onChange={() => setEditMode(!editMode)}
          />
          <Typography sx={{ fontWeight: 600, fontSize: 14 }}>
            Edit Mode
          </Typography>
        </Box>
      )}
      {/* FORM BODY */}
      <Box display="flex" gap={3}>
        {/* LEFT COLUMN */}
        <Box flex={1} display="flex" flexDirection="column" gap={2}>
          {/* FIX 2: Pass formik as a prop to the Field component */}
          <Field label="Make" name="make" disabled formik={formik} isCnms={isCnms}/>
          <Field
            label="Device IP Address"
            name="deviceIp"
            disabled
            formik={formik}
            isCnms={isCnms}
          />
          <Field
            label="Device Serial No*"
            name="serialNumber"
            disabled={!editMode}
            formik={formik}
            isCnms={isCnms}
          />
          <Field
            label="Device Description*"
            name="description"
            disabled={!editMode}
            multiline
            minRows={3}
            maxRows={6}
            formik={formik}
            maxLength={250}
            isCnms={isCnms}
          />
        </Box>

        {/* RIGHT COLUMN */}
        <Box flex={1} display="flex" flexDirection="column" gap={2}>
          <Field label="Model" name="model" disabled formik={formik} isCnms={isCnms}/>
          <Field
            label="Terminal Name"
            name="terminalName"
            disabled
            formik={formik}
            isCnms={isCnms}
          />
          <Field
            label="Firmware Version*"
            name="firmwareVersion"
            disabled={!editMode}
            formik={formik}
            isCnms={isCnms}
          />
        </Box>
      </Box>

      {/* BOTTOM UPDATE BUTTON */}
      {editMode && (
        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 3 }}>
          <MButtonPrimary
            variant="contained"
            color="primary"
            sx={{ borderRadius: "8px", px: 4 }}
            onClick={formik.handleSubmit}
            disabled={loading}
            startIcon={
              loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            {loading ? "Updating..." : "Update"}
          </MButtonPrimary>
        </Box>
      )}
    </Box>
  );
};

export default InventoryDialog;
