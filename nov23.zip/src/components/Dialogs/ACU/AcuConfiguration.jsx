import React, { useMemo, useState, useEffect, useRef } from "react";
import {
  Box,
  Typography,
  Grid,
  Paper,
  CircularProgress,
  Divider,
  useTheme,
} from "@mui/material";
import { LocationOnRounded, PanToolRounded } from "@mui/icons-material";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import MAlarmSelect from "@/components/Reusable/Select/MAlarmSelect";

import {
  JOG_ANTENNA,
  LOCATE_ANTENNA,
  MISC_MOVEMENT,
  STOP_ANTENNA,
  GET_POSITION,
  GET_STATUS_FOR_CONFIGURATION_ACU,
} from "@/RestAPI/url/endpoint";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Confirmation_icon from "../../../assets/SVGIcons/question_mark.svg";
import {
  GET_POSITION_CNMS,
  GET_STATUS_FOR_CONFIGURATION_ACU_CNMS,
  JOG_ANTENNA_CNMS,
  LOCATE_ANTENNA_CNMS,
  MISC_MOVEMENT_CNMS,
  STOP_ANTENNA_CNMS,
} from "@/RestAPI/url/cnmsEndPoint";
import { useSelector } from "react-redux";

/* ============================================================================
 * ACU BACKEND VALUE MAPPINGS
 *
 * Change ONLY these values when you get the actual values from the device.
 * ========================================================================== */

const ACU_VALUES = {
  jogAxis: {
    AZIMUTH: "0",
    ELEVATION: "1",
    POLARIZATION: "2",
  },

  jogDirection: {
    NEGATIVE: "0",
    POSITIVE: "1",
  },

  jogSpeed: {
    SLOW: "0",
    FAST: "1",
  },

  jogDuration: {
    MIN: 1,
    MAX: 9,
  },

  /*
   * Values returned in GET_POSITION
   *
   * IMPORTANT:
   * Replace these when actual ACU values are confirmed.
   */
  statusMode: {
    STOP: "0",
    MOVE: "1",
    LOCATE: "5",
    STOW: "17",
    DEPLOY: "19",
  },

  /*
   * Completion state values.
   *
   * Replace these when actual ACU values are confirmed.
   */
  statusState: {
    STOPPED: "39",
    MOVE_COMPLETED: "39",
    LOCATE_COMPLETED: "39",
    STOW_COMPLETED: "39",
    DEPLOY_COMPLETED: "39",
  },
};

/* ============================================================================
 * OPERATION MESSAGES
 * ========================================================================== */

const OPERATION_MESSAGES = {
  stow: {
    started: "Antenna stowing in progress",
    completed: "Antenna stowing completed",
    stopped: "Antenna stowing stopped",
    failed: "Antenna stowing failed",
  },

  deploy: {
    started: "Antenna deployment in progress",
    completed: "Antenna deployment completed",
    stopped: "Antenna deployment stopped",
    failed: "Antenna deployment failed",
  },

  locate: {
    started: "Antenna locating in progress",
    completed: "Antenna locating completed",
    stopped: "Antenna locating stopped",
    failed: "Antenna locating failed",
  },

  move: {
    started: "Antenna movement in progress",
    completed: "Antenna movement completed",
    stopped: "Antenna movement stopped",
    failed: "Antenna movement failed",
  },
};

const getAcuColors = (isDark) => ({
  // Main backgrounds
  pageBg: isDark ? "#121212" : "#f4f6f8",
  paperBg: isDark ? "#1e1e1e" : "#ffffff",
  cardBg: isDark ? "#252525" : "#ffffff",

  // Borders
  border: isDark ? "#3a3a3a" : "#e0e0e0",
  innerBorder: isDark ? "#404040" : "#e5e7eb",

  // Text
  heading: isDark ? "#3e3e3e" : "#1f2937",
  text: isDark ? "#747e8c" : "#4b5563",
  muted: isDark ? "#9ca3af" : "#6b7280",

  // Inputs and dropdowns
  inputBg: isDark ? "#252525" : "#ffffff",
  inputText: isDark ? "#f3f4f6" : "#1f2937",
  placeholder: isDark ? "#9ca3af" : "#aaaaaa",
  inputBorder: isDark ? "#555555" : "#c4c4c4",
  dropdownHover: isDark ? "#333333" : "#f5f5f5",

  // Status
  successBg: isDark ? "#14291e" : "#f0fdf4",
  successBorder: isDark ? "#285b3b" : "#bbf7d0",
  successText: isDark ? "#86efac" : "#15803d",

  warningBg: isDark ? "#332417" : "#fff7ed",
  warningBorder: isDark ? "#75451e" : "#fed7aa",
  warningText: isDark ? "#fdba74" : "#c2410c",

  // Buttons
  primary: "#14348D",
  primaryHover: "#1e40af",
  danger: "#dc2626",
  dangerHover: "#b91c1c",
});

/* ============================================================================
 * COMPONENT
 * ========================================================================== */

const AcuConfiguration = ({ node }) => {
  const resId = node?.resourceId;
  const siteId = node?.siteId;
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const colors = getAcuColors(isDark);
  console.log("NodeNode", node);
  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;
  const [confirmationDialog, setConfirmationDialog] = useState({
    open: false,
    operation: "",
    message: "",
  });
  /* ==========================================================================
   * STATE
   * ======================================================================== */

  const [position, setPosition] = useState({
    azimuth: 0,
    elevation: 0,
    polarization: 0,
  });

  const [movement, setMovement] = useState({
    jog: "",
    speed: "",
    direction: "",
    duration: "",
  });

  const [satellitePrelist, setSatellitePrelist] = useState("");

  /*
   * Which button is currently showing loader.
   *
   * move
   * stow
   * deploy
   * locate
   * stop
   */
  const [activeButton, setActiveButton] = useState("");

  /*
   * Which antenna operation is currently running.
   *
   * move
   * stow
   * deploy
   * locate
   * ""
   */
  const [activeOperation, setActiveOperation] = useState("");

  const [antennaStatus, setAntennaStatus] = useState({
    mode: "",
    state: "",
    message: "Ready",
  });

  const [isInitialLoading, setIsInitialLoading] = useState(true);

  /* ==========================================================================
   * REFS
   * ======================================================================== */

  const pollIntervalRef = useRef(null);

  const isMountedRef = useRef(false);

  /*
   * This ref is the source of truth for the polling operation.
   *
   * It avoids stale state inside setInterval.
   */
  const activeOperationRef = useRef("");

  /*
   * Prevents multiple completion handling for the same operation.
   */
  const completionHandledRef = useRef(false);

  /* ==========================================================================
   * OPTIONS
   * ======================================================================== */

  const jogAxisOptions = useMemo(
    () => [
      {
        value: ACU_VALUES.jogAxis.AZIMUTH,
        label: "Azimuth",
      },
      {
        value: ACU_VALUES.jogAxis.ELEVATION,
        label: "Elevation",
      },
      {
        value: ACU_VALUES.jogAxis.POLARIZATION,
        label: "Polarization",
      },
    ],
    []
  );

  const directionOptions = useMemo(() => {
    if (
      movement.jog === "" ||
      movement.jog === undefined ||
      movement.jog === null
    ) {
      return [];
    }

    /*
     * Elevation:
     * 0 = Down
     * 1 = Up
     *
     * Azimuth / Polarization:
     * 0 = CW
     * 1 = CCW
     */

    if (String(movement.jog) === ACU_VALUES.jogAxis.ELEVATION) {
      return [
        {
          value: ACU_VALUES.jogDirection.POSITIVE,
          label: "Up",
        },
        {
          value: ACU_VALUES.jogDirection.NEGATIVE,
          label: "Down",
        },
      ];
    }

    return [
      {
        value: ACU_VALUES.jogDirection.NEGATIVE,
        label: "CW",
      },
      {
        value: ACU_VALUES.jogDirection.POSITIVE,
        label: "CCW",
      },
    ];
  }, [movement.jog]);

  const speedOptions = useMemo(
    () => [
      {
        value: ACU_VALUES.jogSpeed.SLOW,
        label: "Slow",
      },
      {
        value: ACU_VALUES.jogSpeed.FAST,
        label: "Fast",
      },
    ],
    []
  );

  const durationOptions = useMemo(() => {
    return Array.from(
      {
        length: ACU_VALUES.jogDuration.MAX - ACU_VALUES.jogDuration.MIN + 1,
      },
      (_, index) => {
        const value = ACU_VALUES.jogDuration.MIN + index;

        return {
          value: String(value),
          label: `${value} Sec${value > 1 ? "s" : ""}`,
        };
      }
    );
  }, []);

  const satelliteOptions = useMemo(() => {
    return Array.from({ length: 20 }, (_, index) => ({
      value: String(index + 1),
      label: `${index + 1}`,
    }));
  }, []);

  /* ==========================================================================
   * GAUGES
   * ======================================================================== */

  const azimuthWidgetConfig = useMemo(
    () => ({
      gridTitle: "Azimuth",
      minVal: -180,
      maxVal: 180,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(position.azimuth) || 0,
        },
      ],
    }),
    [position.azimuth]
  );

  const elevationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Elevation",
      minVal: -75,
      maxVal: 95,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(position.elevation) || 0,
        },
      ],
    }),
    [position.elevation]
  );

  const polarizationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Polarization",
      minVal: -100,
      maxVal: 100,
      unit: "Degree",
      innerRange: 10,
      data: [
        {
          currentValue: Number(position.polarization) || 0,
        },
      ],
    }),
    [position.polarization]
  );

  /* ==========================================================================
   * HELPERS
   * ======================================================================== */

  const getOperationLabel = (operation) => {
    switch (operation) {
      case "stow":
        return "Stowing";

      case "deploy":
        return "Deploying";

      case "locate":
        return "Locating";

      case "move":
        return "Moving";

      default:
        return "Ready";
    }
  };

  /* ==========================================================================
   * STOP POLLING
   * ======================================================================== */

  const stopPolling = () => {
    if (pollIntervalRef.current !== null) {
      clearInterval(pollIntervalRef.current);
      pollIntervalRef.current = null;
    }
  };

  /* ==========================================================================
   * COMPLETE OPERATION
   * ======================================================================== */

  const completeOperation = (operation, statusMode, statusState) => {
    if (!operation) {
      return;
    }

    /*
     * Prevent duplicate completion handling.
     */
    if (completionHandledRef.current) {
      return;
    }

    completionHandledRef.current = true;

    const completedMessage =
      OPERATION_MESSAGES[operation]?.completed ||
      `${getOperationLabel(operation)} completed`;

    /* ------------------------------------------------------------------------
     * Stop polling first
     * ---------------------------------------------------------------------- */

    stopPolling();

    /* ------------------------------------------------------------------------
     * Update status
     * ---------------------------------------------------------------------- */

    setAntennaStatus({
      mode: statusMode,
      state: statusState,
      message: completedMessage,
    });

    /* ------------------------------------------------------------------------
     * Toast ONLY when completed
     * ---------------------------------------------------------------------- */

    Toast("Success", completedMessage, "success");

    /* ------------------------------------------------------------------------
     * Clear operation
     * ---------------------------------------------------------------------- */

    activeOperationRef.current = "";

    setActiveOperation("");

    setActiveButton("");
  };

  /* ==========================================================================
   * CHECK COMPLETION
   *
   * Keep this function separate so changing backend values is easy.
   * ======================================================================== */

  const checkOperationCompletion = (operation, statusMode, statusState) => {
    if (!operation) {
      return false;
    }

    /*
     * For now we check both statusMode and statusState.
     *
     * If your actual device tells you that only statusState is enough,
     * you can simplify these conditions later.
     */

    switch (operation) {
      case "stow":
        return (
          statusMode === ACU_VALUES.statusMode.STOW ||
          statusState === ACU_VALUES.statusState.STOW_COMPLETED
        );

      case "deploy":
        return (
          statusMode === ACU_VALUES.statusMode.DEPLOY ||
          statusState === ACU_VALUES.statusState.DEPLOY_COMPLETED ||
          statusMode === "1" ||
          statusState === "1"
        );

      case "locate":
        return (
          statusMode === ACU_VALUES.statusMode.LOCATE ||
          statusState === ACU_VALUES.statusState.LOCATE_COMPLETED
        );

      case "move":
        return (
          statusMode === ACU_VALUES.statusMode.MOVE ||
          statusState === ACU_VALUES.statusState.MOVE_COMPLETED
        );

      default:
        return false;
    }
  };

  /* ==========================================================================
   * GET POSITION
   *
   * IMPORTANT:
   * This is NEVER called on initial page load.
   *
   * It is only called after:
   * - Move
   * - Stow
   * - Deploy
   * - Locate
   *
   * and then every 1 second.
   * ======================================================================== */

  const fetchPosition = async (operation) => {
    if (!resId || !isMountedRef.current || !operation) {
      return;
    }

    try {
      const response = await ConfigurationAxios(
        `${isCnms ? GET_POSITION_CNMS : GET_POSITION}/${resId}`,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : undefined
      );

      if (!isMountedRef.current || response?.data?.status !== 1) {
        return;
      }

      const data = response?.data?.data;

      /* ----------------------------------------------------------------------
       * UPDATE GAUGES
       * -------------------------------------------------------------------- */

      setPosition({
        azimuth: Number(data?.azimuth) || 0,

        elevation: Number(data?.elevation) || 0,

        polarization: Number(data?.polarization) || 0,
      });

      /* ----------------------------------------------------------------------
       * READ STATUS
       * -------------------------------------------------------------------- */

      const statusMode =
        data?.statusMode !== null && data?.statusMode !== undefined
          ? String(data.statusMode)
          : "";

      const statusState =
        data?.statusState !== null && data?.statusState !== undefined
          ? String(data.statusState)
          : "";

      /* ----------------------------------------------------------------------
       * Always update status mode/state while polling.
       * -------------------------------------------------------------------- */

      setAntennaStatus((prev) => ({
        ...prev,
        mode: statusMode,
        state: statusState,
      }));

      /* ----------------------------------------------------------------------
       * CHECK WHETHER THIS OPERATION COMPLETED
       * -------------------------------------------------------------------- */

      const isCompleted = checkOperationCompletion(
        operation,
        statusMode,
        statusState
      );

      if (isCompleted) {
        completeOperation(operation, statusMode, statusState);
      }
    } catch (error) {
      console.error("Failed to fetch ACU position", error);
    }
  };

  /* ==========================================================================
   * START POLLING
   * ======================================================================== */

  const startFastPolling = (operation) => {
    /*
     * Clear any previous polling.
     */
    stopPolling();

    /*
     * Reset completion guard for the new operation.
     */
    completionHandledRef.current = false;

    /*
     * Store operation BEFORE starting API calls.
     */
    activeOperationRef.current = operation;

    setActiveOperation(operation);

    /*
     * Immediately call GET_POSITION.
     */
    fetchPosition(operation);

    /*
     * Then call every 1 second.
     */
    pollIntervalRef.current = setInterval(() => {
      /*
       * Read operation from ref so that this callback
       * never depends on stale React state.
       */
      const currentOperation = activeOperationRef.current;

      if (!currentOperation) {
        stopPolling();
        return;
      }

      fetchPosition(currentOperation);
    }, 1000);
  };

  /* ==========================================================================
   * INITIAL CONFIGURATION
   *
   * GET_STATUS_FOR_CONFIGURATION_ACU
   *
   * ONLY CALLED ONCE.
   * ======================================================================== */

  const fetchInitialConfiguration = async () => {
    if (!resId) {
      return;
    }

    setIsInitialLoading(true);
    // const payload = {
    //   siteId: String(siteId),
    // };
    try {
      const response = await ConfigurationAxios(
        `${
          isCnms
            ? GET_STATUS_FOR_CONFIGURATION_ACU_CNMS
            : GET_STATUS_FOR_CONFIGURATION_ACU
        }/${resId}`,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : undefined
      );
      // const response = await ConfigurationAxios(
      //   `${GET_STATUS_FOR_CONFIGURATION_ACU_CNMS}/${resId}`,
      //   "post",
      //   payload
      // );

      if (response?.data?.status === 1 && response?.data?.data) {
        const data = response.data.data;

        /* --------------------------------------------------------------------
         * GAUGES
         * ------------------------------------------------------------------ */

        setPosition({
          azimuth: Number(data?.azimuth) || 0,

          elevation: Number(data?.elevation) || 0,

          polarization: Number(data?.polarization) || 0,
        });

        /* --------------------------------------------------------------------
         * JOG AXIS
         *
         * Backend:
         * "0" -> Azimuth
         * "1" -> Elevation
         * "2" -> Polarization
         * ------------------------------------------------------------------ */

        setMovement({
          jog:
            data?.jogAxis !== null && data?.jogAxis !== undefined
              ? String(data.jogAxis)
              : "",

          direction:
            data?.jogMovDirection !== null &&
            data?.jogMovDirection !== undefined
              ? String(data.jogMovDirection)
              : "",

          speed:
            data?.jogMovSpeed !== null && data?.jogMovSpeed !== undefined
              ? String(data.jogMovSpeed)
              : "",

          duration:
            data?.jogMovDuration !== null && data?.jogMovDuration !== undefined
              ? String(data.jogMovDuration)
              : "",
        });

        /* --------------------------------------------------------------------
         * SATELLITE INDEX
         * ------------------------------------------------------------------ */

        setSatellitePrelist(
          data?.satelliteIndex !== null && data?.satelliteIndex !== undefined
            ? String(data.satelliteIndex)
            : ""
        );

        setAntennaStatus({
          mode: "",
          state: "",
          message: "Ready",
        });
      } else {
        Toast(
          "Error",
          response?.data?.message || "Failed to fetch ACU configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("Failed to fetch ACU configuration", error);

      Toast(
        "Error",
        error?.message || "Failed to fetch ACU configuration",
        "error"
      );
    } finally {
      setIsInitialLoading(false);
    }
  };

  /* ==========================================================================
   * INITIAL API CALL
   * ======================================================================== */

  useEffect(() => {
    if (!resId) {
      return;
    }

    isMountedRef.current = true;

    /*
     * ONLY initial API.
     *
     * GET_POSITION is NOT called here.
     */
    fetchInitialConfiguration();

    return () => {
      isMountedRef.current = false;

      stopPolling();

      activeOperationRef.current = "";

      completionHandledRef.current = false;
    };
  }, [resId]);

  /* ==========================================================================
   * MOVE
   * ======================================================================== */
  const getConfirmationMessage = (operation) => {
    switch (operation) {
      case "stow":
        return "Are you sure you want to perform stowing?";

      case "deploy":
        return "Are you sure you want to perform deployment?";

      case "locate":
        return "Are you sure you want to locate the antenna?";

      case "move":
        return "Are you sure you want to move the antenna?";

      default:
        return "Are you sure you want to perform this operation?";
    }
  };

  const openConfirmationDialog = (operation) => {
    setConfirmationDialog({
      open: true,
      operation,
      message: getConfirmationMessage(operation),
    });
  };

  const closeConfirmationDialog = () => {
    setConfirmationDialog({
      open: false,
      operation: "",
      message: "",
    });
  };

  const handleConfirmationYes = () => {
    const operation = confirmationDialog.operation;

    closeConfirmationDialog();

    /*
     * IMPORTANT:
     * Only after clicking YES do we call the
     * existing operation handlers.
     */
    if (operation === "move") {
      handleMove();
    } else if (operation === "locate") {
      handleLocate();
    } else if (operation === "stow" || operation === "deploy") {
      handleAntennaAction(operation);
    }
  };
  const handleMove = async () => {
    if (!resId || activeOperationRef.current) {
      return;
    }

    setActiveButton("move");

    const payload = {
      jogAxis: String(movement.jog),
      jogMovSpeed: String(movement.speed),
      jogMovDirection: String(movement.direction),
      jogMovDuration: String(movement.duration),
    };

    try {
      const response = await ConfigurationAxios(
        `${isCnms ? JOG_ANTENNA_CNMS : JOG_ANTENNA}/${resId}`,
        "post",
        isCnms ? { ...payload, siteId: String(siteId) } : payload
      );

      if (response?.data?.status === 1) {
        /*
         * NO TOAST HERE.
         */

        setAntennaStatus({
          mode: ACU_VALUES.statusMode.MOVE,
          state: "",
          message: OPERATION_MESSAGES.move.started,
        });

        /*
         * Start polling.
         */
        startFastPolling("move");
      } else {
        Toast(
          "Error",
          response?.data?.message || "Jog antenna failed",
          "error"
        );

        setActiveButton("");
      }
    } catch (error) {
      console.error("Jog antenna failed", error);

      Toast("Error", error?.message || "Jog antenna failed", "error");

      setActiveButton("");
    }
  };

  /* ==========================================================================
   * STOW / DEPLOY / STOP
   * ======================================================================== */

  const handleAntennaAction = async (action) => {
    if (!resId) {
      return;
    }

    /*
     * STOP is allowed whenever an operation is running.
     *
     * STOW/DEPLOY cannot be started if another operation
     * is already running.
     */
    if (action !== "stop" && activeOperationRef.current) {
      return;
    }

    setActiveButton(action);

    /*
     * Remember the current operation before STOP.
     */
    const previousOperation = activeOperationRef.current;

    try {
      let response = null;

      /* ----------------------------------------------------------------------
       * STOP
       * -------------------------------------------------------------------- */

      if (action === "stop") {
        response = await ConfigurationAxios(
          `${isCnms ? STOP_ANTENNA_CNMS : STOP_ANTENNA}/${resId}`,
          isCnms ? "post" : "get",
          isCnms ? { siteId: String(siteId) } : undefined
        );
      } else if (action === "stow" || action === "deploy") {
        /* ----------------------------------------------------------------------
         * STOW / DEPLOY
         * -------------------------------------------------------------------- */
        const miscVal = action === "stow" ? "0" : "1";

        response = await ConfigurationAxios(
          `${isCnms ? MISC_MOVEMENT_CNMS : MISC_MOVEMENT}/${resId}/${miscVal}`,
          isCnms ? "post" : "get",
          isCnms ? { siteId: String(siteId) } : undefined
        );
      }

      /* ----------------------------------------------------------------------
       * API SUCCESS
       * -------------------------------------------------------------------- */

      if (response?.data?.status === 1) {
        /* ====================================================================
         * STOP
         * ================================================================== */

        if (action === "stop") {
          /*
           * Stop polling immediately.
           */
          stopPolling();

          /*
           * Clear operation.
           */
          activeOperationRef.current = "";

          setActiveOperation("");

          setActiveButton("");

          /*
           * Show stopped status.
           */
          const stoppedMessage =
            OPERATION_MESSAGES[previousOperation]?.stopped || "Antenna stopped";

          setAntennaStatus({
            mode: ACU_VALUES.statusMode.STOP,

            state: ACU_VALUES.statusState.STOPPED,

            message: stoppedMessage,
          });

          /*
           * STOP is one of the only places
           * where we show a toast.
           */
          Toast("Success", stoppedMessage, "success");

          return;
        }

        /* ====================================================================
         * STOW / DEPLOY
         * ================================================================== */

        setAntennaStatus({
          mode:
            action === "stow"
              ? ACU_VALUES.statusMode.STOW
              : ACU_VALUES.statusMode.DEPLOY,

          state: "",

          message: OPERATION_MESSAGES[action]?.started || `${action} started`,
        });

        /*
         * NO TOAST HERE.
         */

        /*
         * Start polling.
         */
        startFastPolling(action);
      } else {
        /*
         * API failed.
         */
        const errorMessage =
          response?.data?.message || `${action} antenna failed`;

        Toast("Error", errorMessage, "error");

        setAntennaStatus((prev) => ({
          ...prev,
          message: OPERATION_MESSAGES[action]?.failed || `${action} failed`,
        }));

        setActiveButton("");
      }
    } catch (error) {
      console.error(`Antenna action ${action} failed`, error);

      Toast(
        "Error",
        error?.message || `Antenna action ${action} failed`,
        "error"
      );

      setAntennaStatus((prev) => ({
        ...prev,
        message: OPERATION_MESSAGES[action]?.failed || `${action} failed`,
      }));

      /*
       * If STOP fails, we still stop polling.
       */
      if (action === "stop") {
        stopPolling();

        activeOperationRef.current = "";

        setActiveOperation("");
      }

      setActiveButton("");
    }
  };

  /* ==========================================================================
   * LOCATE
   * ======================================================================== */

  const handleLocate = async () => {
    if (!resId || activeOperationRef.current || !satellitePrelist) {
      return;
    }

    setActiveButton("locate");

    try {
      const response = await ConfigurationAxios(
        `${
          isCnms ? LOCATE_ANTENNA_CNMS : LOCATE_ANTENNA
        }/${resId}/${satellitePrelist}`,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : undefined
      );

      if (response?.data?.status === 1) {
        /*
         * NO TOAST HERE.
         */

        setAntennaStatus({
          mode: ACU_VALUES.statusMode.LOCATE,

          state: "",

          message: OPERATION_MESSAGES.locate.started,
        });

        /*
         * Start polling.
         */
        startFastPolling("locate");
      } else {
        Toast(
          "Error",
          response?.data?.message || "Locate antenna failed",
          "error"
        );

        setActiveButton("");
      }
    } catch (error) {
      console.error("Locate antenna failed", error);

      Toast("Error", error?.message || "Locate antenna failed", "error");

      setActiveButton("");
    }
  };

  /* ==========================================================================
   * OPERATION STATE
   * ======================================================================== */

  const isOperationRunning = activeOperation !== "";

  /* ==========================================================================
   * RENDER
   * ======================================================================== */

  return (
    <Box
      sx={{
        p: 2,
        minHeight: "auto",
        backgroundColor: colors.pageBg,
        color: colors.heading,
      }}
    >
      {/* ======================================================================
       * INITIAL LOADING
       * ==================================================================== */}

      {isInitialLoading ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "400px",
            backgroundColor: colors.paperBg,
            borderRadius: 2,
            border: `1px solid ${colors.border}`,
            color: colors.heading,
          }}
        >
          <CircularProgress size={45} />

          <Typography variant="body1" sx={{ ml: 2 }}>
            Loading ACU Configuration...
          </Typography>
        </Box>
      ) : (
        <>
          {/* ==================================================================
           * POSITION GAUGES
           * ================================================================== */}

          <Paper
            elevation={0}
            sx={{
              p: 2,
              mb: 2,
              borderRadius: 2,
              border: "1px solid #e0e0e0",
              backgroundColor: "#ffffff",
            }}
          >
            <Box
              mb={1}
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Typography
                variant="subtitle1"
                fontWeight={700}
                sx={{
                  color: colors.heading,
                }}
              >
                Azimuth, Elevation and Polarization
              </Typography>
            </Box>

            <Grid
              spacing={3}
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(3, 1fr)",
                gap: "15px",
              }}
            >
              <Grid item xs={12} md={4}>
                <Box
                  sx={{
                    height: "100%",
                    border: `1px solid ${colors.innerBorder}`,
                    borderRadius: 2,
                    p: 1,
                    backgroundColor: colors.cardBg,
                    color: colors.heading,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {DialGaugeWidget && DialGaugeWidget(azimuthWidgetConfig)}
                </Box>
              </Grid>

              <Grid item xs={12} md={4}>
                <Box
                  sx={{
                    height: "100%",
                    border: `1px solid ${colors.innerBorder}`,
                    borderRadius: 2,
                    p: 1,
                    backgroundColor: colors.cardBg,
                    color: colors.heading,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {DialGaugeWidget && DialGaugeWidget(elevationWidgetConfig)}
                </Box>
              </Grid>

              <Grid item xs={12} md={4}>
                <Box
                  sx={{
                    height: "100%",
                    border: `1px solid ${colors.innerBorder}`,
                    borderRadius: 2,
                    p: 1,
                    backgroundColor: colors.cardBg,
                    color: colors.heading,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {DialGaugeWidget && DialGaugeWidget(polarizationWidgetConfig)}
                </Box>
              </Grid>
            </Grid>
          </Paper>

          {/* ==================================================================
           * ANTENNA STATUS
           * ================================================================== */}

          <Paper
            elevation={0}
            sx={{
              p: 0,
              mb: 1,
              borderRadius: 2,
              border: "1px solid #e0e0e0",
              backgroundColor: "#ffffff",
            }}
          >
            <Box
              sx={{
                pl: 1,
                borderRadius: 1.5,
                backgroundColor: isOperationRunning ? "#fff7ed" : "#f0fdf4",
                border: "1px solid",
                borderColor: isOperationRunning ? "#fed7aa" : "#bbf7d0",
                // backgroundColor: isOperationRunning
                //   ? colors.warningBg
                //   : colors.successBg,

                // border: "1px solid",
                // borderColor: isOperationRunning
                //   ? colors.warningBorder
                //   : colors.successBorder,
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  // justifyContent:'center',
                  alignItems: "center",
                }}
              >
                <Typography
                  variant="subtitle1"
                  fontWeight={700}
                  sx={{
                    color: colors.heading,
                  }}
                >
                  Antenna Status:
                </Typography>

                <Typography
                  variant="body1"
                  fontWeight={700}
                  sx={{
                    color: isOperationRunning ? "#c2410c" : "#15803d",
                    pl: 1,
                  }}
                >
                  {antennaStatus.message}
                </Typography>
              </Box>
              {/* {isOperationRunning && (
                <Typography
                  variant="caption"
                  fontWeight={700}
                  sx={{
                    color: "#c2410c",
                  }}
                >
                  {getOperationLabel(activeOperation)}
                </Typography>
              )} */}
            </Box>
          </Paper>

          {/* ==================================================================
           * MOVEMENT + LOCATE
           * ================================================================== */}

          <Paper
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "10px",
              p: "14px 14px 0px 14px",
            }}
          >
            {/* ================================================================
             * MOVEMENT
             * ============================================================== */}

            <Paper
              elevation={0}
              sx={{
                p: 2,
                mb: 1,
                borderRadius: 2,
                border: "1px solid #e0e0e0",
                backgroundColor: "#ffffff",
              }}
            >
              <Box
                mb={1}
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Typography
                  variant="subtitle1"
                  fontWeight={700}
                  sx={{
                    color: colors.heading,
                  }}
                >
                  Antenna Movement
                </Typography>
              </Box>

              <Divider sx={{ mb: 1 }} />

              <Grid
                spacing={2}
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "15px",
                  flexWrap: "wrap",
                }}
              >
                {/* JOG AXIS */}

                <Grid item xs={12} sm={6} md={3}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{
                      color: colors.text,
                      display: "block",
                    }}
                  >
                    Jog Axis
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={movement.jog}
                    onChange={(val) =>
                      setMovement((prev) => ({
                        ...prev,
                        jog: val !== "" ? String(val) : "",
                        direction: "",
                      }))
                    }
                    options={jogAxisOptions}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* DIRECTION */}

                <Grid item xs={12} sm={6} md={3}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{
                      color: colors.text,
                      display: "block",
                    }}
                  >
                    Jog Direction
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={movement.direction}
                    onChange={(val) =>
                      setMovement((prev) => ({
                        ...prev,
                        direction: val !== "" ? String(val) : "",
                      }))
                    }
                    options={directionOptions}
                    disabled={isOperationRunning || movement.jog === ""}
                    multiple={false}
                    isDark={isDark}
                  />
                </Grid>

                {/* SPEED */}

                <Grid item xs={12} sm={6} md={3}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{
                      color: colors.text,
                      display: "block",
                    }}
                  >
                    Jog Speed
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={movement.speed}
                    onChange={(val) =>
                      setMovement((prev) => ({
                        ...prev,
                        speed: val !== "" ? String(val) : "",
                      }))
                    }
                    options={speedOptions}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* DURATION */}

                <Grid item xs={12} sm={6} md={3}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{
                      color: colors.text,
                      display: "block",
                    }}
                  >
                    Jog Duration
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={movement.duration}
                    onChange={(val) =>
                      setMovement((prev) => ({
                        ...prev,
                        duration: val !== "" ? String(val) : "",
                      }))
                    }
                    options={durationOptions}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* MOVE */}

                <Grid item xs={12} sm={6} md={3} mt={2.7}>
                  <MButtonPrimary
                    variant="contained"
                    color="primary"
                    fullWidth
                    disabled={
                      isOperationRunning ||
                      movement.jog === "" ||
                      movement.speed === "" ||
                      movement.direction === "" ||
                      movement.duration === ""
                    }
                    // onClick={handleMove}
                    onClick={() => openConfirmationDialog("move")}
                    sx={{
                      height: 40,
                      borderRadius: "8px",
                    }}
                  >
                    {activeButton === "move" ? (
                      <CircularProgress size={21} color="inherit" />
                    ) : (
                      "Move"
                    )}
                  </MButtonPrimary>
                </Grid>
              </Grid>

              {/* STOW / DEPLOY / STOP */}

              <Box
                sx={{
                  mt: 3,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 2,
                  flexWrap: "wrap",
                }}
              >
                {/* STOW */}

                <MButtonPrimary
                  variant="contained"
                  color="primary"
                  disabled={isOperationRunning}
                  // onClick={() => handleAntennaAction("stow")}
                  onClick={() => openConfirmationDialog("stow")}
                  sx={{
                    minWidth: 130,
                    borderRadius: "8px",
                  }}
                >
                  {activeButton === "stow" ? (
                    <CircularProgress size={21} color="inherit" />
                  ) : (
                    "STOW"
                  )}
                </MButtonPrimary>

                {/* DEPLOY */}

                <MButtonPrimary
                  variant="contained"
                  color="primary"
                  disabled={isOperationRunning}
                  // onClick={() => handleAntennaAction("deploy")}
                  onClick={() => openConfirmationDialog("deploy")}
                  sx={{
                    minWidth: 130,
                    borderRadius: "8px",
                  }}
                >
                  {activeButton === "deploy" ? (
                    <CircularProgress size={21} color="inherit" />
                  ) : (
                    "DEPLOY"
                  )}
                </MButtonPrimary>

                {/* STOP - ALWAYS ENABLED */}

                <MButtonPrimary
                  variant="contained"
                  color="primary"
                  disabled={false}
                  onClick={() => handleAntennaAction("stop")}
                  style={{
                    minWidth: 130,
                    borderRadius: "8px",
                    backgroundColor: "#dc2626",
                    "&:hover": {
                      backgroundColor: "#b91c1c",
                    },
                  }}
                >
                  {activeButton === "stop" ? (
                    <CircularProgress size={21} color="inherit" />
                  ) : (
                    <>
                      <PanToolRounded
                        sx={{
                          mr: 1,
                        }}
                      />
                      STOP
                    </>
                  )}
                </MButtonPrimary>
              </Box>
            </Paper>

            {/* ================================================================
             * LOCATE
             * ============================================================== */}

            <Paper
              elevation={0}
              sx={{
                p: 2,
                borderRadius: 2,
                border: "1px solid #e0e0e0",
                backgroundColor: "#ffffff",
                mb: 2,
              }}
            >
              <Box
                mb={1}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexWrap: "wrap",
                }}
              >
                <Typography
                  variant="subtitle1"
                  fontWeight={700}
                  sx={{
                    color: colors.heading,
                  }}
                >
                  Locate
                </Typography>
              </Box>

              <Divider sx={{ mb: 3 }} />

              <Grid
                container
                spacing={2}
                alignItems="center"
                justifyContent="center"
              >
                {/* SATELLITE */}

                <Grid item xs={12} md={8}>
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    sx={{
                      color: colors.text,
                      display: "block",
                    }}
                  >
                    Satellite Index:
                  </Typography>

                  <MAlarmSelect
                    label=""
                    value={satellitePrelist}
                    onChange={(val) =>
                      setSatellitePrelist(val !== "" ? String(val) : "")
                    }
                    options={satelliteOptions}
                    multiple={false}
                    disabled={isOperationRunning}
                    isDark={isDark}
                  />
                </Grid>

                {/* LOCATE */}

                <Grid item xs={12} md={4} mt={3}>
                  <MButtonPrimary
                    variant="contained"
                    color="primary"
                    fullWidth
                    disabled={isOperationRunning || !satellitePrelist}
                    // onClick={handleLocate}
                    onClick={() => openConfirmationDialog("locate")}
                    sx={{
                      height: 40,
                      borderRadius: "8px",
                    }}
                    startIcon={
                      activeButton === "locate" ? (
                        <CircularProgress size={20} color="inherit" />
                      ) : (
                        <LocationOnRounded />
                      )
                    }
                  >
                    {activeButton === "locate" ? "Locating..." : "Locate"}
                  </MButtonPrimary>
                </Grid>
              </Grid>
            </Paper>
          </Paper>
        </>
      )}

      <MDialog
        open={confirmationDialog.open}
        title="Confirm Operation"
        message={confirmationDialog.message}
        onConfirm={handleConfirmationYes}
        onClose={closeConfirmationDialog}
        variant="warning" // Or "info"/"danger" depending on your theme
        icon={Confirmation_icon} // Ensure this icon is imported in your file
        mode="parent" // As per your requirement
      />
    </Box>
  );
};

export default AcuConfiguration;
