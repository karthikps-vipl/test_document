import React from "react";

import useNetworkAcceleratorRttMode from "@/core/hooks/useNetworkAcceleratorRttMode";
import DynamicDeviceLayout from "./DyanmicDeviceLayout";
import NetworkAcceleratorSystemParameter from "./NetworkAcceleratorSystemParameter";

const NetworkAcceleratorStatus = ({
  node,
  source,
  mode,
}) => {
  const deviceId = node?.resourceId;

  const {
    data,
    loading,
  } = useNetworkAcceleratorRttMode(
    deviceId,
    mode === "status"
  );

  return (
    <>
      <NetworkAcceleratorSystemParameter
        data={data}
        loading={loading}
      />

      <DynamicDeviceLayout
        node={node}
        source={source}
        mode={mode}
      />
    </>
  );
};

export default NetworkAcceleratorStatus;