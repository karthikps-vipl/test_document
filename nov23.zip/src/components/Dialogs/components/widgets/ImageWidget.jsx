import React from "react";

const ImageWidget = () => {
  return <div></div>;
};

export default ImageWidget;
