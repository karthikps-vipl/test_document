import React from 'react'

const VerticalTable = () => {
  return (
    <div>
      
    </div>
  )
}

export default VerticalTable
