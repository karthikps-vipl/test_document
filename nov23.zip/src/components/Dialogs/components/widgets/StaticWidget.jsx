import React from "react";
import { Card, Typography } from "@mui/material";

const StaticWidget = ({ widget, oidValueMap }) => {
  return (
    <Card sx={{ p: 2 }}>
      <Typography variant="h6">{widget.tableTitle}</Typography>

      {widget.data.map((item, i) => (
        <Typography key={i}>
          {item.name}: {oidValueMap?.[item.oid]?.operator_map ?? "--"}
        </Typography>
      ))}
    </Card>
  );
};

export default StaticWidget;
