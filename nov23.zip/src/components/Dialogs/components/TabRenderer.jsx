// import React, { useState } from "react";

// import { Tabs, Tab, Box } from "@mui/material";
// import GridRenderer from "./GridRenderer";

// const TabRenderer = ({
//   tabs,
//   node,
//   oidValueMap,
//   loading,
//   activeTab,
//   onTabChange,
// }) => {
//   return (
//     <Box>
//       <Tabs value={activeTab} onChange={(e, val) => onTabChange(val)}>
//         {tabs.map((tab, i) => (
//           <Tab key={i} label={tab.name} />
//         ))}
//       </Tabs>

//       <Box mt={2}>
//         <GridRenderer
//           widgets={tabs[activeTab]?.widget || []}
//           node={node}
//           oidValueMap={oidValueMap}
//           loading={loading}
//         />
//       </Box>
//     </Box>
//   );
// };

// export default TabRenderer;

// import React from "react";

// import { Tabs, Tab, Box } from "@mui/material";

// import GridRenderer from "./GridRenderer";

// const TabRenderer = ({
//   tabs,
//   activeTab,
//   onTabChange,
//   node,
//   loading,
//   liveData,
// }) => {
//   return (
//     <Box>
//       {tabs.length > 1 && (
//         <Tabs value={activeTab} onChange={(e, value) => onTabChange(value)}>
//           {tabs.map((tab, index) => (
//             <Tab key={index} label={tab.name} />
//           ))}
//         </Tabs>
//       )}

//       <Box >
//         <GridRenderer
//           widgets={tabs[activeTab]?.widget || []}
//           layout={tabs[activeTab]?.layout || []}
//           node={node}
//           liveData={liveData}
//         />
//       </Box>
//     </Box>
//   );
// };

// export default TabRenderer;
import React from "react";
import { Tabs, Tab, Box } from "@mui/material";
import GridRenderer from "./GridRenderer";

const TabRenderer = ({
  tabs,
  activeTab,
  onTabChange,
  node,
  loading,
  saving,
  liveData,
}) => {
  return (
    <Box>
      {tabs.length > 1 && (
        <Tabs
          value={activeTab}
          onChange={(e, value) => onTabChange(value)}
        >
          {tabs.map((tab, index) => (
            <Tab
              key={index}
              label={tab.name}
            />
          ))}
        </Tabs>
      )}

      <Box>
        <GridRenderer
          widgets={tabs[activeTab]?.widget || []}
          layout={tabs[activeTab]?.layout || []}
          node={node}
          liveData={liveData}
          saving={saving}
        />
      </Box>
    </Box>
  );
};

export default TabRenderer;

