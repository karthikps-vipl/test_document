// import React from "react";

// import { Box, Typography } from "@mui/material";
// import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

// const WidgetRenderer = ({  widget, widgetIndex, node,liveData }) => {
//   if (!widget) return null;
//   if (widget.type === "hybrid") {
//     return (
//       <Box
//         sx={{
//           height: "100%",
//           width: "100%",
//           backgroundColor: "#fafafa",
//           border: "1px solid #ddd",
//           borderRadius: 2,
//           p: 1.5,
//           overflowY: "auto",
//           boxSizing: "border-box",
//         }}
//       >
//         {widget.tableTitle && (
//           <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: "bold" }}>
//             {widget.tableTitle}
//           </Typography>
//         )}
//         <Box display="flex" flexDirection="column" gap={1.5}>
//           {(widget.children || []).map((childWidget, idx) => (
//             <WidgetRenderer
//               key={childWidget.oid || idx}
//               widget={childWidget}
//               widgetIndex={idx}
//               node={node}
//               liveData={liveData}
//             />
//           ))}
//         </Box>
//       </Box>
//     );
//   }
//   const registryItem = WIDGET_REGISTRY[widget.type];

//   if (!registryItem) {
//     return (
//       <Box p={2}>
//         <Typography color="error">Unknown Widget :{widget.type}</Typography>
//       </Box>
//     );
//   }

//   console.log("yhnwidget", widget);

//   return (
//     <Box
//       sx={{
//         height: "100%",
//         width: "100%",
//         background: registryItem.backgroundColor || "#fff",
//         border: `1px solid ${registryItem.borderColor || "#ddd"}`,
//         borderRadius: 2,
//         overflow: "hidden",
//       }}
//     >
//       {registryItem.renderCanvas(
//         widget,
//         () => {},
//         widgetIndex,
//         () => {},
//         "",
//         node.resourceId,
//         liveData
//       )}
//     </Box>
//   );
// };

// export default WidgetRenderer;
import React from "react";

import { Box, Typography } from "@mui/material";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

const WidgetRenderer = ({ widget, widgetIndex, node, liveData, saving }) => {
  if (!widget) {
    return null;
  }

  /*
   * Hybrid widget
   */
  if (widget.type === "hybrid") {
    return (
      <Box
        sx={{
          height: "100%",
          width: "100%",
          backgroundColor: "#fafafa",
          border: "1px solid #ddd",
          borderRadius: 2,
          p: 1.5,
          overflowY: "auto",
          boxSizing: "border-box",
        }}
      >
        {widget.tableTitle && (
          <Typography
            variant="subtitle2"
            sx={{
              mb: 1,
              fontWeight: "bold",
            }}
          >
            {widget.tableTitle}
          </Typography>
        )}

        <Box display="flex" flexDirection="column" gap={1.5}>
          {(widget.children || []).map((childWidget, idx) => (
            <WidgetRenderer
              key={childWidget.oid || idx}
              widget={childWidget}
              widgetIndex={idx}
              node={node}
              liveData={liveData}
              saving={saving}
            />
          ))}
        </Box>
      </Box>
    );
  }

  const registryItem = WIDGET_REGISTRY[widget.type];

  if (!registryItem) {
    return (
      <Box p={2}>
        <Typography color="error">Unknown Widget: {widget.type}</Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        height: "100%",
        width: "100%",
        background: registryItem.backgroundColor || "#fff",
        border: `1px solid ${registryItem.borderColor || "#ddd"}`,
        borderRadius: 2,
        overflow: "hidden",
      }}
    >
      {
      registryItem.renderCanvas(
        widget,
        widget.inputChangeHandler || (() => {}),
        widgetIndex,
        widget.saveConfigHandler || (() => {}),
        "",
        node?.resourceId,
        liveData,
        saving,
        widget.validationErrors || {},
        widget.setValidationErrors || (() => {})
      )
      }
    </Box>
  );
};

export default WidgetRenderer;
