// import React from "react";

// import { Box } from "@mui/material";
// import WidgetRenderer from "./WidgetRenderer";

// const GridRenderer = ({
//   widgets,
//   node,
//   oidValueMap,
// }) => {
//   return (
//     <Box
//       display="grid"
//       gridTemplateColumns="repeat(12, 1fr)"
//       gap={2}
//     >
//       {widgets.map((widget, index) => (
//         <Box
//           key={index}
//           gridColumn={`span ${
//             widget?.cols || 12
//           }`}
//         >
//           <WidgetRenderer
//             widget={widget}
//             node={node}
//             oidValueMap={oidValueMap}
//           />
//         </Box>
//       ))}
//     </Box>
//   );
// };

// export default GridRenderer;

import React, { useEffect, useRef, useState } from "react";

import GridLayout from "react-grid-layout";

import WidgetRenderer from "./WidgetRenderer";
import { Box } from "@mui/material";

const GridRenderer = ({ widgets = [], layout = [], node, liveData, saving }) => {


  const canvasRef = useRef(null);
  const [canvasWidth, setCanvasWidth] = useState(1200);

  useEffect(() => {
      if (!canvasRef.current) return;
  
      const observer = new ResizeObserver((entries) => {
        for (let entry of entries) {
          setCanvasWidth(entry.contentRect.width);
        }
      });
  
      observer.observe(canvasRef.current);
  
      return () => observer.disconnect();
    }, []);
  
  const fullyConstructedLayout = widgets.map((widget, index) => ({
    i: layout[index]?.i || `widget-${index}`,
    x: layout[index]?.x,
    y: layout[index]?.y,
    w: layout[index]?.w,
    h: layout[index]?.h,
    static: true, // Guarantees no moving parts
  }));

  return (
    <Box ref={canvasRef}>
      <GridLayout
        
        className="layout"
        gridConfig={{
          rowHeight: 10,
          cols: 36,
        }}
        width={canvasWidth}
        layout={fullyConstructedLayout}

      >
        {/* <Box> */}
        {widgets.map((widget, index) => {
          const layoutNode = layout[index] || {
            i: `widget-${index}`,

            x: 0,

            y: index * 5,

            w: 12,

            h: 6,
          };

          return (
            <div key={layoutNode.i} >
              <WidgetRenderer
                widget={widget}
                widgetIndex={index}
                node={node}
                liveData={liveData}
                saving={saving}
              />
            </div>
          );
        })}
        {/* </Box> */}
      </GridLayout>
    </Box>
  );
};

export default GridRenderer;
