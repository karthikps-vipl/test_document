import React from "react";
import BaseDialogLayout from "./BaseDialogLayout";
import DynamicDeviceLayout from "./DyanmicDeviceLayout";
import SerialDgSetViewApi from "./SerialDgSetViewApi";
import AcuConfiguration from "./ACU/AcuConfiguration";
import AntpConfiguration from "./ANTP/AntpConfiguration";
import NetworkAcceleratorStatus from "./NetworkAcceleratorStatus";
import GilatSatcomModuleStatus from "@/Pages/Rnmsdashboard/GilatSatcomModule/GilatSatcomModuleStatus";
import BucStatus from "@/Pages/Rnmsdashboard/BucLnbcStatusAndConfig/BucStatus";
import LnbcStatus from "@/Pages/Rnmsdashboard/BucLnbcStatusAndConfig/LnbcStatus";
import BucConfig from "@/Pages/Rnmsdashboard/BucLnbcStatusAndConfig/BucConfig";
import LnbcConfig from "@/Pages/Rnmsdashboard/BucLnbcStatusAndConfig/LnbcConfig";
import AcuStatusMK from "@/Pages/Rnmsdashboard/MK-II/ACU/AcuStatusMK";
import AntpStatusMK from "@/Pages/Rnmsdashboard/MK-II/ANTP/AntpStatusMK";
import BtrStatusMK from "@/Pages/Rnmsdashboard/MK-II/BTR/BtrStatusMK";
import BtrConfigMK from "@/Pages/Rnmsdashboard/MK-II/BTR/BtrConfigMK";
import AcuConfigurationMK from "@/Pages/Rnmsdashboard/MK-II/ACU/AcuConfigurationMK";
import NetworkAcceleratorStatusMk from "@/Pages/Rnmsdashboard/MK-II/Network Accelerator/NetworkAcceleratorStatusMk";
import AntpControlMK from "@/Pages/Rnmsdashboard/MK-II/ANTP/AntpControlMK";
import LosRadioMain from "@/Pages/Rnmsdashboard/MK-II/LOS Radio/LosRadioMain";
import AntpConfigurationMKI from "@/Pages/Rnmsdashboard/MK-I/ANTP/AntpConfigurationMKI";

const DeviceDialog = ({ node, source, onClose, mode = "status" }) => {
  // Turn "status" into "Device Status" or "configuration" into "Device Configuration"
  const titleMode = mode === "status" ? "Status" : "Configuration";
  const resourceTypeId = node?.imResourceType?.resourceTypeId;
  console.log(node?.resourceId, "bvvvhffhvbhfbvhb");
  console.log(node?.resourceId, "bvvvhffhvbhfbvhb");

  console.log("cnmsdevicelayoutdata", node);

  const renderContent = () => {
    // 1. Serial DG Set (Resource ID: 901) for MCT-EP and (Resource ID: 721) for MCT-LSV
    if (resourceTypeId === 901 || resourceTypeId === 721) {
      return <SerialDgSetViewApi node={node} source={source} mode={mode} />;
    }

    // 2. Configuration-specific checks for ANTP and ACU
    if (mode === "configuration") {
      if (resourceTypeId === 920) {
        return <AcuConfiguration node={node} source={source} mode={mode} />;
      }

      if (resourceTypeId === 923) {
        return <AntpConfiguration node={node} source={source} mode={mode} />;
      }
      if (resourceTypeId === 208) {
        return (
          <BucConfig
            node={node}
            source={source}
            mode={mode}
            resourceId={node?.resourceId}
          />
        );
      }
      if (resourceTypeId === 212) {
        return (
          <LnbcConfig
            node={node}
            source={source}
            mode={mode}
            resourceId={node?.resourceId}
          />
        );
      }
      // 506 MK-II and 321 MK-I
      if (resourceTypeId === 506 || resourceTypeId === 321) {
        return (
          <BtrConfigMK
            node={node}
            source={source}
            mode={mode}
            resourceId={node?.resourceId}
          />
        );
      }
      // 505 MK-II and 313 MK-I
      if (resourceTypeId === 505 || resourceTypeId === 313) {
        return (
          <AcuConfigurationMK
            node={node}
            source={source}
            mode={mode}
            resourceId={node?.resourceId}
          />
        );
      }
      if (resourceTypeId === 514) {
        return (
          <AntpControlMK
            node={node}
            source={source}
            mode={mode}
            resourceId={node?.resourceId}
          />
        );
      }
      if (resourceTypeId === 310) {
        return (
          <AntpConfigurationMKI
            node={node}
            source={source}
            mode={mode}
          />
        );
      }
    }
    // Network Accelerator
    if (resourceTypeId === 915) {
      return (
        <NetworkAcceleratorStatus node={node} source={source} mode={mode} />
      );
    }
    if (resourceTypeId === 214) {
      return (
        <GilatSatcomModuleStatus
          node={node}
          source={source}
          mode={mode}
          resourceId={node?.resourceId}
        />
      );
    }
    // BUC (Hub -NMS)
    if (resourceTypeId === 208) {
      return (
        <BucStatus
          node={node}
          source={source}
          mode={mode}
          resourceId={node?.resourceId}
        />
      );
    }
    // LNBC 215
    if (resourceTypeId === 212) {
      return (
        <LnbcStatus
          node={node}
          source={source}
          mode={mode}
          resourceId={node?.resourceId}
        />
      );
    }
    // ACU STATUS MK-II(505) MK-I(313)
    if (resourceTypeId === 505 || resourceTypeId === 313) {
      return (
        <AcuStatusMK
          node={node}
          source={source}
          mode={mode}
          resourceId={node?.resourceId}
        />
      );
    }

    // BTR STATUS MK-II(506) MK-I(321)
    if (resourceTypeId === 506 || resourceTypeId === 321) {
      return <BtrStatusMK node={node} source={source} mode={mode} />;
    }
    // ANTP STATUS MK-II

    if (resourceTypeId === 514) {
      return <AntpStatusMK node={node} source={source} mode={mode} />;
    }

    // Network Accelerator STATUS MK-II
    if (resourceTypeId === 503) {
      return (
        <NetworkAcceleratorStatusMk
          node={node}
          source={source}
          mode={mode}
          resourceId={node?.resourceId}
        />
      );
    }
    // LOS RADIO (GRID & PDA) STATUS MK-II (512) and MK-I (318)
    if (resourceTypeId === 512 || resourceTypeId === 318) {
      return (
        <LosRadioMain
          node={node}
          source={source}
          mode={mode}
          resourceId={node?.resourceId}
        />
      );
    }

    // 3. Default fallback for Status mode (and any other unhandled devices)
    return <DynamicDeviceLayout node={node} source={source} mode={mode} />;
  };

  return (
    <BaseDialogLayout
      title={`${node?.resourceName || "Device"} - Device ${titleMode}`}
      onClose={onClose}
    >
      {renderContent()}
    </BaseDialogLayout>
  );
};

export default DeviceDialog;
