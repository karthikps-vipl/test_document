import React from "react";

import DynamicStatusLayout from "./DynamicStatusLayout";
import BaseDialogLayout from "./BaseDialogLayout";

const StatusDialog = ({ node, source, onClose }) => {
  console.log("nodenodecnms1",node);
  return (
    <BaseDialogLayout
      title={`${node?.resourceName} - Device Status`}
      onClose={onClose}
    >
      <DynamicStatusLayout
        node={node}
        source={source}
      />
    </BaseDialogLayout>
  );
};

export default StatusDialog;
