
import React, { useState, useEffect, useCallback } from "react";
import { Box, Typography, Divider, TextField, CircularProgress } from "@mui/material";
import { Update } from "@mui/icons-material"; 
import { SquareIconButton } from "../../Reusable/Modal/MModal";
import CloseIcon from "@mui/icons-material/Close";
import Toast from "../../Reusable/Toast/Toast";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { GET_DEVICE_POLLING_INTERVAL, INVENTORY_UPDATE_POLLING_INTERVAL } from "@/RestAPI/url/endpoint";
import MButtonPrimary from "../../Reusable/Button/MButtonPrimary";

const PollingIntervalComponent = ({ node, onClose }) => {
  const [inputValue, setInputValue] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [fullDeviceData, setFullDeviceData] = useState(null);
  const resourceId = node?.resourceId;

  useEffect(() => {
    fetchDevicePollInterval();
  }, [resourceId]);

  const fetchDevicePollInterval = useCallback(async () => {
    try {
      const url = `${GET_DEVICE_POLLING_INTERVAL}/${resourceId}`;
      const response = await FaultAxios(url, "get");
      setInputValue(`${response.data.pollingInterval}`);
      setFullDeviceData(response?.data);
    } catch (error) {
      Toast("Error","server error","error");
    }
  }, [resourceId]);

  const handleInputChange = (e) => {
    // FIX 2: Only allow digits (numbers only)
    const value = e.target.value;
    if (value === "" || /^[0-9\b]+$/.test(value)) {
      setInputValue(value);
    }
  };

  const numericValue = parseInt(inputValue, 10);
  const isValidRange = !isNaN(numericValue) && numericValue >= 5 && numericValue <= 60;

  const isUpdateDisabled =
    String(inputValue).trim() === "" || 
    isNaN(Number(inputValue)) || 
    !isValidRange || // Added this to ensure they can't click update if out of range
    isSubmitting;

  const handleUpdatePolling = async () => {
    if (!isValidRange) return;
    try {
      setIsSubmitting(true);
      const url = `${INVENTORY_UPDATE_POLLING_INTERVAL}/${resourceId}`;
      const finalPayload = {
        ...fullDeviceData,
        pollingInterval: numericValue,
      };

      const response = await FaultAxios(url, "post", finalPayload);

      if (response?.data) {
        Toast("Success!", "Polling interval updated successfully.", "success");
        onClose();
      } else {
        Toast("Error!", "Failed to update polling interval.", "error");
      }
    } catch (error) {
      Toast("Error!", "Server error", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Box sx={{ mt: 2, px: 1 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "left",
          alignItems: "center",
          position: "relative",
          ml: 2,
        }}
      >
        <Typography
          variant="subtitle1"
          sx={{ textAlign: "left", fontWeight: 700, color: "text.TitleTextcolor", mb: 1 }}
        >
          {node?.resourceName || "Device"} - Polling Interval
        </Typography>

        <Box sx={{ position: "absolute", right: 0, mb: 1 }}>
          <SquareIconButton onClick={onClose}>
            <CloseIcon />
          </SquareIconButton>
        </Box>
      </Box>
      <Divider sx={{ mb: 3 }} />

      {/* FIX 1: Container for Input and Button */}
      <Box
        sx={{
          display: "flex",
          alignItems: "flex-start", // Changed from flex-end to flex-start
          gap: 2,
          justifyContent: "flex-start",
          ml: 2,
        }}
      >
        {/* Input Container */}
        <Box sx={{ width: 300 }}>
          <Typography
            sx={{
              fontSize: 13,
              mb: 0.5,
              fontWeight: 600,
              color: "text.primary",
            }}
          >
            Interval Sec
          </Typography>
          <TextField
            fullWidth
            size="small"
            // Changed type to "text" to have better control over numeric regex
            type="text" 
            placeholder="e.g. 30"
            value={inputValue}
            onChange={handleInputChange}
            error={inputValue !== "" && !isValidRange}
            helperText={inputValue !== "" && !isValidRange ? "Value must be between 5 and 60" : ""}
            sx={{
              "& .MuiOutlinedInput-root": {
                borderRadius: "8px",
              },
            }}
          />
        </Box>

        {/* Button Container */}
        {/* We wrap the button in a Box with a specific top margin to align it with the Input field 
            instead of the HelperText. This prevents the button from jumping. */}
        <Box sx={{ pt: 2.5 }}> 
          <MButtonPrimary
            variant="contained"
            color="primary"
            sx={{ borderRadius: "8px", px: 4 }}
            onClick={handleUpdatePolling}
            disabled={isUpdateDisabled}
            startIcon={
              isSubmitting ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                <Update />
              )
            }
          >
            {isSubmitting ? "Updating..." : "Update"}
          </MButtonPrimary>
        </Box>
      </Box>
    </Box>
  );
};

export default PollingIntervalComponent;


// import React, { useState, useEffect, useCallback } from "react";
// import { Box, Typography, Divider, TextField, Button, CircularProgress } from "@mui/material";
// import { Update } from "@mui/icons-material"; 
// import { SquareIconButton } from "../Reusable/Modal/MModal";
// import CloseIcon from "@mui/icons-material/Close";
// import Toast from "../Reusable/Toast/Toast";
// import { FaultAxios, InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import { GET_DEVICE_POLLING_INTERVAL, INVENTORY_UPDATE_POLLING_INTERVAL } from "@/RestAPI/url/endpoint";
// import MButtonPrimary from "../Reusable/Button/MButtonPrimary";

// const PollingIntervalComponent = ({ node, onClose, onRefresh }) => {

//   // const interval = node?.nePollingInfo?.pollingInterval;
//   const [inputValue, setInputValue] = useState( "");
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [fullDeviceData, setFullDeviceData] = useState(null);

//   const resourceId = node?.resourceId;

//   useEffect(()=>{
//     fetchDevicePollInterval();
//   },[resourceId])


//   const fetchDevicePollInterval = useCallback(async () => {
//     try {
//       const url = `${GET_DEVICE_POLLING_INTERVAL}/${resourceId}`; 
//       const response = await FaultAxios(url,"get");
//       setInputValue(`${response.data.pollingInterval}`);
//       setFullDeviceData(response?.data)
//     } catch(error) {
//       Toast(error);
//     }
//   }, [resourceId]);


//   const handleInputChange = (e) => {
//     setInputValue(e.target.value.toString());
//   };

//     const numericValue = parseInt(inputValue, 10);
//   const isValidRange = !isNaN(numericValue) && numericValue >= 5 && numericValue <= 60;
  

//   const isUpdateDisabled = 
//   String(inputValue).trim() === "" || 
//   isNaN(Number(inputValue)) || 
//   isSubmitting;


//   const handleUpdatePolling = async () => {
//     try {
//       if (!isValidRange) return;
//       setIsSubmitting(true);
  
//       const resourceId = node?.resourceId;
//       const url = `${INVENTORY_UPDATE_POLLING_INTERVAL}/${resourceId}`; 
  
     
//       const finalPayload = {
//         ...fullDeviceData,        
//         pollingInterval: numericValue, 
//       };
  
//       console.log("Sending Payload:", finalPayload);
  
//       const response = await FaultAxios(url, "post", finalPayload);
      
//       if (response?.data) {
//         Toast("Success!", "Polling interval updated successfully.", "success");
      
//         onClose(); 
//       } else {
//         Toast("Error!", "Failed to update polling interval.", "error");
//       }
//     } catch (error) {
//       console.error("API Error:", error);
//       const errorMessage = error?.response?.data?.message || "An error occurred.";
//       Toast("Error!", errorMessage, "error");
//     } finally {
//       setIsSubmitting(false);
//     }
//   };
//   return (
//     <Box sx={{ mt: 2, px: 1 }}>
//       {/* Header Section */}
//       <Box
//         sx={{
//           display: "flex",
//           justifyContent: "left",
//           alignItems: "center",
//           position: "relative",
//           ml: 2
//         }}
//       >
//         <Typography
//           variant="subtitle1"
//           sx={{
//             textAlign: "left",
//             fontWeight: 700,
//             color: "#14348D",
//             mb: 1,
//           }}
//         >
//           {node?.resourceName || "Device"} - Polling Interval
//         </Typography>
        
//         <Box sx={{ position: "absolute", right: 0, mb: 1 }}>
//           <SquareIconButton onClick={onClose}>
//             <CloseIcon />
//           </SquareIconButton>
//         </Box>
//       </Box>

//       <Divider sx={{ mb: 3 }} />

//       <Box
//         sx={{
//           display: "flex",
//           alignItems: "flex-end", 
//           gap: 2,
//           justifyContent: "flex-start",
//           ml: 2
//         }}
//       >
//         <Box sx={{ width: 300}}>
//           <Typography
//             sx={{
//               fontSize: 13,
//               mb: 0.5,
//               fontWeight: 600,
//               color: "text.primary",
//             }}
//           >
//             Interval Sec
//           </Typography>
//           <TextField
//             fullWidth
//             size="small"
//             type="number"
//             placeholder="e.g. 30"
//             value={inputValue}
//             onChange={handleInputChange} 
//             error={inputValue !== "" && !isValidRange}
//             helperText={inputValue !== "" && !isValidRange ? "Value must be between 5 and 60" : ""}
//             sx={{
//               "& .MuiOutlinedInput-root": {
//                 borderRadius: "8px",
//               },
              
//             }}
//           />
//         </Box>
//         <Box sx={{ display: "flex", justifyContent: "flex-end", }}>
//           <MButtonPrimary
//             variant="contained"
//             color="primary"
//             sx={{ borderRadius: "8px", px: 4 }}
//             onClick={handleUpdatePolling}
//             disabled={isUpdateDisabled}
//             startIcon={
//                 isSubmitting ? (
//                 <CircularProgress size={20} color="inherit" />
//               ) : (
//                 <Update />
//               )
//             }
//           >
//             {isSubmitting ? "Updating..." : "Update"}
//           </MButtonPrimary>
//         </Box>
//         </Box>

//     </Box>
//   );
// };

// export default PollingIntervalComponent;


// // import { SquareIconButton } from "../Reusable/Modal/MModal";
// // import CloseIcon from "@mui/icons-material/Close";

// // import { FaultAxios } from "@/RestAPI/api/axiosApicall";
// // import { GET_DEVICE_POLLING_INTERVAL, INVENTORY_UPDATE_POLLING_INTERVAL } from "@/RestAPI/url/endpoint";
// // import MButtonPrimary from "../Reusable/Button/MButtonPrimary";
// // import Toast from "../Reusable/Toast/Toast";

// // const PollingIntervalComponent = ({ node, onClose, onRefresh }) => {

// //   const resourceId = node?.resourceId;

// //   const [inputValue, setInputValue] = useState("");
// //   const [isSubmitting, setIsSubmitting] = useState(false);
// //   const [fullDeviceData, setFullDeviceData] = useState(null);


// //   const handleInputChange = (e) => {
// //     setInputValue(e.target.value);
// //   };

// //   useEffect(()=>{
// //     fetchDevicePollInterval();
// //   },[resourceId])


// //   const fetchDevicePollInterval = useCallback(async () => {
// //     try {
// //       const url = `${GET_DEVICE_POLLING_INTERVAL}/${resourceId}`; 
// //       const response = await FaultAxios(url,"get");
// //       console.log("hdbdatapollimnh",response?.data); 
// //       setInputValue(`${response.data.pollingInterval}`);
// //       setFullDeviceData(response?.data)
// //     } catch(error) {
// //       Toast(error);
// //     }
// //   }, [resourceId]);

// //   // 2. Validation Logic (Checks for between 5 and 60 seconds inclusive)
// //   const numericValue = parseInt(inputValue, 10);
// //   const isValidRange = !isNaN(numericValue) && numericValue >= 5 && numericValue <= 60;
  
// //   const isUpdateDisabled = 
// //     String(inputValue).trim() === "" || 
// //     !isValidRange || 
// //     isSubmitting;

// //     const handleUpdatePolling = async () => {
// //       try {
// //         if (!isValidRange) return;
// //         setIsSubmitting(true);
    
// //         const resourceId = node?.resourceId;
// //         const url = `${INVENTORY_UPDATE_POLLING_INTERVAL}/${resourceId}`; 
    
       
// //         const finalPayload = {
// //           ...fullDeviceData,        
// //           pollingInterval: numericValue, 
// //         };
    
// //         console.log("Sending Payload:", finalPayload);
    
// //         const response = await FaultAxios(url, "post", finalPayload);
        
// //         if (response?.data) {
// //           Toast("Success!", "Polling interval updated successfully.", "success");
        
// //           onClose(); 
// //         } else {
// //           Toast("Error!", "Failed to update polling interval.", "error");
// //         }
// //       } catch (error) {
// //         console.error("API Error:", error);
// //         const errorMessage = error?.response?.data?.message || "An error occurred.";
// //         Toast("Error!", errorMessage, "error");
// //       } finally {
// //         setIsSubmitting(false);
// //       }
// //     };


// //   return (
// //     <Box sx={{ mt: 2, px: 1 }}>
// //       {/* Header Section */}
// //       <Box
// //         sx={{
// //           display: "flex",
// //           justifyContent: "left",
// //           alignItems: "center",
// //           position: "relative",
// //           ml: 2
// //         }}
// //       >
// //         <Typography
// //           variant="subtitle1"
// //           sx={{
// //             textAlign: "left",
// //             fontWeight: 700,
// //             color: "#14348D",
// //             mb: 1,
// //           }}
// //         >
// //           {node?.imResourceInfo?.resourceName || "Device"} - Polling Interval
// //         </Typography>
        
// //         <Box sx={{ position: "absolute", right: 0, mb: 1 }}>
// //           <SquareIconButton onClick={onClose}>
// //             <CloseIcon />
// //           </SquareIconButton>
// //         </Box>
// //       </Box>

// //       <Divider sx={{ mb: 3 }} />

// //       <Box
// //         sx={{
// //           display: "flex",
// //           alignItems: "flex-start", 
// //           gap: 2,
// //           justifyContent: "flex-start",
// //           ml: 2
// //         }}
// //       >
// //         <Box sx={{ width: 300 }}>
// //           <Typography
// //             sx={{
// //               fontSize: 13,
// //               mb: 0.5,
// //               fontWeight: 600,
// //               color: "text.primary",
// //             }}
// //           >
// //             Interval Sec
// //           </Typography>
// //           <TextField
// //             fullWidth
// //             size="small"
// //             type="number"
// //             placeholder="e.g. 30"
// //             value={inputValue}
// //             onChange={handleInputChange} 
// //             error={inputValue !== "" && !isValidRange}
// //             helperText={inputValue !== "" && !isValidRange ? "Value must be between 5 and 60" : ""}
// //             sx={{
// //               "& .MuiOutlinedInput-root": {
// //                 borderRadius: "8px",
// //               },
// //               // 3. Remove native browser up and down spin arrows
// //               "& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button": {
// //                 "-webkit-appearance": "none",
// //                 margin: 0,
// //               },
// //               "& input[type=number]": {
// //                 "-moz-appearance": "textfield",
// //               },
// //             }}
// //           />
// //         </Box>
// //         <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2.5 }}>
// //           <MButtonPrimary
// //             variant="contained"
// //             color="primary"
// //             sx={{ borderRadius: "8px", px: 4 }}
// //             onClick={handleUpdatePolling}
// //             disabled={isUpdateDisabled}
// //             startIcon={
// //               isSubmitting ? (
// //                 <CircularProgress size={20} color="inherit" />
// //               ) : (
// //                 <Update />
// //               )
// //             }
// //           >
// //             {isSubmitting ? "Updating..." : "Update"}
// //           </MButtonPrimary>
// //         </Box>
// //       </Box>
// //     </Box>
// //   );
// // };

// // export default PollingIntervalComponent;