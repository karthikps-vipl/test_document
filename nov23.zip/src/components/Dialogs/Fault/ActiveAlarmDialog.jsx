import { Box, DialogContent } from "@mui/material";
import { useEffect, useState } from "react";
import { FAULT_GET_VIEW_ACTIVE_ALARM } from "@/RestAPI/url/endpoint";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import { severityConfig, workflowConfig } from "@/lib/utils";
import moment from "moment";
import { exportToPDF } from "../../Reusable/Pdf/downloadPdf";
import MTable from "@/components/Reusable/Table/MTable";
import { useDispatch, useSelector } from "react-redux";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";

const InventoryDetails = ({ node, onClose }) => {
  const resourceId = node?.resourceId;
  const segment = node?.imSegmentInfo?.segmentName;
  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  const active_Title = `${segment} : ${node?.resourceName} - Active Alarms`;

  //   const [isOpen, setIsOpen] = useState(false);
  const [activeAlarm, setActiveAlarm] = useState([]);
  const fetchActiveAlarm = async () => {
    try {
      const url = `${FAULT_GET_VIEW_ACTIVE_ALARM}/${resourceId}`;
      const active_response = await FaultAxios(url, "get");
      console.log("active_response", active_response);
      setActiveAlarm(active_response?.data);
      // setActiveAllAlarms(active_response)
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchActiveAlarm();
  }, []);

  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "60px",
    },
    {
      uid: "alarmName",
      name: "Alarm Name",
      width: "200px",
    },
    {
      uid: "alarmDescription",
      name: "Description",
      width: "350px",
    },
    {
      uid: "resourceIp",
      name: "IP Address",
      width: "200px",
    },
    {
      uid: "severity",
      name: "Severity",
      width: "120px",
      sortable: true,
      searchSeverity: true,
      filterType: "dropdown",
      filterOptions: Object.keys(severityConfig).map((key) => {
        const numericKey = Number(key);

        return {
          label: severityConfig[key].label,
          value: numericKey,
          gradient: severityConfig[key].gradient,
        };
      }),
    },
    {
      uid: "workflow",
      name: "Workflow",
      width: "120px",
      sortable: true,
      filterType: "dropdown",
      filterOptions: workflowConfig,
    },
    {
      uid: "alarmCount",
      name: "Count",
      width: "100px",
      filterType: "textS",
    },
    {
      name: "Date and Time",
      uid: "dateTime",
      sortable: true,
      width: "190px",
      filterType: "datetime",
      renderCell: (params) => {
        const val = params?.row?.dateTime || params?.dateTime;
        return val ? moment(val).format("YYYY-MM-DD HH:mm:ss") : "N/A";
      },
    },
  ];
  const dispatch = useDispatch();
   const handleToggleMaximize = () => {
      dispatch(toggleTableMaximize());
    };

  return (
      <Box>
        <DialogContent>
          <Box sx={{   borderRadius: "20px" }}>
            <MTable
              tableTitle={active_Title}
              columns={columns}
              tableData={activeAlarm}
              showSearch={true}
              handleDownloadPDF={() => {
                const sanitizedName = "Active Alarms".replace(/\s+/g, "_");
                const normalName = "Active Alarms";
                exportToPDF(
                  `${normalName} Report`,
                  columns,
                  activeAlarm,
                  `${sanitizedName}_Report`,
                  "NMS User"
                );
              }}
              showPagination={true}
              handleClose={onClose}
              closeIcon={true}
              showMaximazed={true}
              // 3. Pass the BOOLEAN value here
            isMaximized={isTableMaximized}
            // 4. Pass the FUNCTION to handle the click
            toggleMaximize={handleToggleMaximize}
            />
          </Box>
        </DialogContent>
      </Box>
    
  );
};
export default InventoryDetails;