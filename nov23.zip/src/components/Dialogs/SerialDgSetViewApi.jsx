import React, { useEffect, useState } from "react";
import { CircularProgress, Box, Alert } from "@mui/material";

import SerialDgSetView from "./SerialDgSetView";
import { FETCH_DG_SET_PARAMS } from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "../Reusable/Toast/Toast";

const INTERVAL = 30000; // 30 seconds

const SerialDgSetViewApi = ({ node }) => {
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  // const [terminalDetails, setTerminalDetails] = useState(null); // Assuming this comes from a context or Redux

  useEffect(() => {
    const fetchData = async () => {
      try {
        let response;

        response = await ConfigurationAxios(
          `${FETCH_DG_SET_PARAMS}/${node?.resourceId}`,
          "get"
        );

        if (response?.data) {
          // setData(response.data);

          setData(response?.data?.data || response?.data);
          setError(null);
        } else {
          Toast("Error", "Something went wrong!!", "error");
        }
      } catch (err) {
        console.error("Polling Error:", err);
        // We don't show a toast error on every poll to avoid annoying the user,
        // only if it's the initial load.
        if (!data) setError("Failed to fetch initial status.");
      } finally {
        setLoading(false);
      }
    };
    // Initial fetch
    fetchData();

    // Set up polling
    const pollingId = setInterval(() => {
      fetchData();
    }, INTERVAL);

    // Cleanup on unmount
    return () => clearInterval(pollingId);
  }, [node?.resourceId]);

  if (loading && !data) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "400px",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error && !data) {
    return <Alert severity="error">{error}</Alert>;
  }

  return <SerialDgSetView liveData={data} />;
};

export default SerialDgSetViewApi;
