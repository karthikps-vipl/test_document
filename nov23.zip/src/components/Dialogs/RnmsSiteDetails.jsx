import React from "react";
import {
  Box,
  Typography,
  DialogTitle,
  Divider,
  Grid,
  useTheme,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import MInput from "../Reusable/Input/MInput";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { CustomeFullscreen } from "../Reusable/FullScreen/CustomeFullscreen";

const FormField = ({ label, value }) => (
  <Box sx={{ width: "100%" }}>
    <Typography
      sx={{
        display: "block",
        mb: 0.5,
        ml: 0.5,
      }}
    >
      {label}
    </Typography>
    <MInput value={value} readOnly={true} fullWidth={true} />
  </Box>
);

const RnmsSiteDetails = ({ onClose }) => {
  const theme = useTheme();
  const { repDetails } = useSelector((state) => state.nodeDetails);
  // repDetails - 1;
  console.log("", repDetails);
  const isMaximized = useSelector((state) => state.inventory?.isTableMaximized);
  const dispatch = useDispatch();
  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  const getValue = (path) => {
    try {
      const value = path
        .split(".")
        .reduce(
          (obj, key) => (obj && obj[key] !== undefined ? obj[key] : ""),
          repDetails
        );
      console.log(`Path: ${path} | Found Value:`, value);
      return value;
    } catch (e) {
      console.error(`Error fetching path: ${path}`, e);
      return "";
    }
  };

  return (
    <Box sx={{ p: 2, width: "100%" }}>
      <DialogTitle
        sx={{
          m: 0,
          p: 0,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          color: theme.palette.text.TitleTextcolor,
          fontWeight: "bold",
          fontSize: "1.1rem",
        }}
      >
        RNMS Site Details
        <Box sx={{ position: "absolute", right: 10 }}>
          <CustomeFullscreen
            onClose={onClose}
            isFullScreen={isMaximized}
            onToggleFullScreen={handleToggleMaximize}
          />
        </Box>
      </DialogTitle>

      <Divider sx={{ my: 1.5 }} />

      <Grid container spacing={2} sx={{ color: theme.palette.text.primary }}>
        <Grid item xs={6}>
          <FormField label="Type" value={getValue("id")} />
        </Grid>

        <Grid item xs={6}>
          <FormField label="Number" value={getValue("remoteNumber")} />
        </Grid>

        <Grid item xs={6}>
          <FormField label="Name" value={getValue("siteName")} />
        </Grid>

        <Grid item xs={6}>
          <FormField label="Unit Name" value={getValue("siteNickName")} />
        </Grid>
      </Grid>
    </Box>
  );
};

export default RnmsSiteDetails;
