import React from "react";
import { Box, Typography } from "@mui/material";
import MTextAreaAntD from "../Reusable/Texarea/MTextArea";

const NetworkAcceleratorSystemParameter = ({ data, loading }) => {
  return (
    <Box
      sx={{
        border: "1px solid #ddd",
        borderRadius: 2,
        backgroundColor: "#fff",
        overflow: "hidden",
        ml: 1,
        mr: 1,
      }}
    >
      {/* Header */}
      <Box
        sx={{
          backgroundColor: "#E4EBFF",
          p: 1,
          display: "flex",
          alignItems: "center",
        }}
      >
        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: "bold",
            color: "#14348d",
          }}
        >
          System Parameter
        </Typography>
      </Box>

      <Box sx={{ p: 1 }}>
        <Box
          sx={{
            display: "flex",
            gap: 1,
            flexWrap: "wrap",
            minHeight: "60px", // Ensures height consistency even if one is empty
          }}
        >
          {/* Mode Card */}
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              minWidth: "120px",
            }}
          >
            <Typography
              sx={{
                mb: 0.5,
                fontSize: "13px",
                fontWeight: 500,
                color: "#0f172a",
              }}
            >
              Mode
            </Typography>

            <MTextAreaAntD
              value={loading ? "" : data?.mode ?? ""}
              autoSize={{
                minRows: 1,
                maxRows: 3,
              }}
            />
          </Box>

          {/* RTT Card */}
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              minWidth: "120px",
            }}
          >
            <Typography
              sx={{
                mb: 0.5,
                fontSize: "13px",
                fontWeight: 500,
                color: "#0f172a",
              }}
            >
              RTT (Round Trip Time msec)
            </Typography>

            <MTextAreaAntD
              value={loading ? "" : data?.rtt ?? ""}
              autoSize={{
                minRows: 1,
                maxRows: 3,
              }}
              showUnit={true}
              unit="msec"
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default NetworkAcceleratorSystemParameter;
