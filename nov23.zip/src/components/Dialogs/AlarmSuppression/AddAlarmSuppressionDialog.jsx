import React, { useEffect, useState } from "react";
import { Grid, Box, Typography, Button, FormHelperText,DialogContent } from "@mui/material";
import * as Yup from "yup";
import { useFormik } from "formik";
import MInput from "@/components/Reusable/Input/MInput";
import Toast from "@/components/Reusable/Toast/Toast";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import {
  FAULT_ADD_ALARMSUPRESSION,
  FAULT_ALARMSUPRESSION_FETCH_ALARMTYPE,
  FAULT_ALARMSUPRESSION_UPDATE,
} from "@/RestAPI/url/endpoint";
import MAlarmSelect from "./MAlarmSelect";

import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
import dayjs from "dayjs";

const validationSchema = Yup.object({
  deviceName: Yup.string().required("Device Name is required"),
  selectedAlarms: Yup.array()
    .min(1, "Please select at least one alarm")
    .required("Alarm Name is required"),
  fromDate: Yup.string().required("From Date Time is required"),
  toDate: Yup.string().required("To Date Time is required"),
});

const AddAlarmSuppressionDialog = ({
  open,
  onClose,
  resourceId,
  refreshTable,
  node,
  mode,
  editData,
}) => {
  const [alarmOptions, setAlarmOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const editRecord = Array.isArray(editData)
  ? editData[0]
  : editData;

  const isEditMode = mode === "edit";

  console.log("isEditMode", isEditMode);

  const fetchAlarmTypes = async () => {
    try {
      const url = `${FAULT_ALARMSUPRESSION_FETCH_ALARMTYPE}/${resourceId}`;
      const response = await FaultAxios(url, "get");
      const rawData = response?.data;
      const dataArray = Array.isArray(rawData) ? rawData : rawData?.data || [];

      const formatted = dataArray.map((alarm) => ({
        label: alarm?.alarmName || "Unknown Alarm",
        value: alarm?.alarmTypeId,
      }));

      setAlarmOptions(formatted);

      if (isEditMode && editRecord?.alarmTypeList) {
        console.log("Added!");
      }
    } catch (err) {
      console.error("Error fetching alarms:", err);
    }
  };

  useEffect(() => {
    if (resourceId) {
      fetchAlarmTypes();
    }
  }, [resourceId]);

  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      deviceName: isEditMode
        ? editData[0]?.imResourceInfo?.resourceName || ""
        : node?.resourceName || "",
      selectedAlarms: [],
      fromDate: editData?.fromDate || "",
      toDate: editData?.toDate || "",
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        setLoading(true);

        const fromDate = new Date(values.fromDate);
        const toDate = new Date(values.toDate);

        const payload = {
          deviceId: resourceId,
          fromDate: fromDate.toISOString(),
          toDate: toDate.toISOString(),
          alarmTypeList: values.selectedAlarms
            .map((id) => {
              const alarm = alarmOptions.find((a) => a.value === id);
              return alarm?.label || "";
            })
            .join(", "),
          imResourceInfo: {
            devicePosition: node?.devicePosition || null,
            discoveredstatusMessage: node?.discoveredstatusMessage || null,
            discoveryMode: node?.discoveryMode || "MANUAL",
            firmwareVersion: node?.firmwareVersion || null,
            imResourceType: node?.imResourceType || {},
            imSegmentInfo: node?.imSegmentInfo || {},
            isDiscovered: node?.isDiscovered || true,
            isMaintainance: node?.isMaintainance || false,
            lstPortInfoDtl: node?.lstPortInfoDtl || [],
            macAddress: node?.macAddress || null,
            nePollingInfo: node?.nePollingInfo || {},
            portNumber: node?.portNumber || null,
            remarks: node?.remarks || null,
            remoteNum: node?.remoteNum || null,
            resourceDesc: node?.resourceDesc || "",
            resourceId: resourceId,
            resourceIp: node?.resourceIp || "",
            resourceName: node?.resourceName || "",
            resourceSerialno: node?.resourceSerialno || "",
            status: node.status || "Success",
            timestamp: new Date().toLocaleString(),
            tmSnmpProfile: node?.tmSnmpProfile || {},
          },
        };

        // 3. API INTEGRATION LOGIC (Add vs Update)
        // let response;
        if (isEditMode) {
          const url = `${FAULT_ALARMSUPRESSION_UPDATE}/${resourceId}`; // Ensure this is imported
          await FaultAxios(url, "post", payload);
        } else {
          const url = `${FAULT_ADD_ALARMSUPRESSION}/${resourceId}`;
          await FaultAxios(url, "post", payload);
        }

        const successMsg = isEditMode
          ? "Alarm suppression updated successfully."
          : "Alarm suppression added successfully.";
        Toast("Success!", successMsg, "success");

        refreshTable?.();
        onClose();
        formik.resetForm();
      } catch (error) {
        console.error("API Error:", error);
        Toast("Error!", "Something went wrong.", "error");
      } finally {
        setLoading(false);
      }
    },
  });

  useEffect(() => {
    if (isEditMode && editRecord?.alarmTypeList && alarmOptions.length > 0) {
      const namesArray = editData.alarmTypeList
        .split(",")
        .map((name) => name.trim());
      const matchedIds = alarmOptions
        .filter((opt) => namesArray.includes(opt.label))
        .map((opt) => opt.value);

      if (
        JSON.stringify(matchedIds) !==
        JSON.stringify(formik.values.selectedAlarms)
      ) {
        formik.setFieldValue("selectedAlarms", matchedIds);
      }
    }
  }, [alarmOptions, editData, isEditMode]);

  const handleResetForm = () => {
    setSearchTerm("");
  
    formik.resetForm({
      values: {
        deviceName: isEditMode
          ? editRecord?.imResourceInfo?.resourceName ||
            node?.resourceName ||
            ""
          : node?.resourceName || "",
  
        selectedAlarms: [],
        fromDate: "",
        toDate: "",
      },
    });
  };

  const filteredSelectedAlarms = formik.values.selectedAlarms
    .map((val) => alarmOptions.find((opt) => opt.value === val))
    .filter(
      (opt) => opt && opt.label.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DialogContent
          sx={{
            color: "text.primary",
            overflowY: "auto",
            px: 3,
            py: 2,
          }}
        >
        <form onSubmit={formik.handleSubmit}>
          <Grid container spacing={6} sx={{ ml: 1 }}>
            <Grid item xs={12} md={6}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
                <Box>
                  <Typography
                    sx={{ mb: 0.3, fontSize: "14px", fontWeight: 500 }}
                  >
                    Device Name
                  </Typography>
                  <MInput
                    fullWidth
                    name="deviceName"
                    value={formik.values.deviceName}
                    readOnly={true}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    placeholder="Enter Device Name"
                    sx={{ width: "270px" }}
                  />
                  {formik.touched.deviceName && formik.errors.deviceName && (
                    <FormHelperText error>
                      {formik.errors.deviceName}
                    </FormHelperText>
                  )}
                </Box>

                <Box sx={{ minWidth: "270px", maxWidth: "270px" }}>
                  <MAlarmSelect
                    label="Alarm Name"
                    options={alarmOptions}
                    value={formik.values.selectedAlarms}
                    onChange={(vals) =>
                      formik.setFieldValue("selectedAlarms", vals)
                    }
                    placeholder="type here"
                    onSearchChange={(val) => setSearchTerm(val)}
                  />
                  {formik.touched.selectedAlarms &&
                    formik.errors.selectedAlarms && (
                      <FormHelperText error>
                        {formik.errors.selectedAlarms}
                      </FormHelperText>
                    )}
                </Box>

                <Box>
                  <Typography
                    sx={{ mb: 0.3, fontSize: "14px", fontWeight: 500 }}
                  >
                    Selected Alarms
                  </Typography>
                  <Box
                    sx={{
                      minHeight: "120px",
                      maxHeight: "120px",
                      minWidth: "270px",
                      maxWidth: "270px",
                      overflowY: "auto",
                      border: "1px solid #d1d5db",
                      borderRadius: "8px",
                      p: 1.5,
                      backgroundColor: "#fff",
                    }}
                  >
                    {filteredSelectedAlarms.length > 0 ? (
                      filteredSelectedAlarms.map((opt, index) => (
                        <Typography
                          key={index}
                          sx={{ fontSize: "14px", mb: 0.5 }}
                        >
                          {opt.label}
                          {index !== filteredSelectedAlarms.length - 1
                            ? ","
                            : ""}
                        </Typography>
                      ))
                    ) : (
                      <Typography sx={{ color: "#999", fontSize: "13px" }}>
                        No alarms selected
                      </Typography>
                    )}
                  </Box>
                </Box>
                
              </Box>
            </Grid>

            {/* RIGHT SECTION */}
            <Grid item xs={12} md={6}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
                <Box>
                  <Typography
                    sx={{ mb: 0.3, fontSize: "14px", fontWeight: 500 }}
                  >
                    From Date Time
                  </Typography>
                  <DateTimePicker
                    value={
                      formik.values.fromDate
                        ? dayjs(formik.values.fromDate)
                        : null
                    }
                    onChange={(newValue) => {
                      formik.setFieldValue(
                        "fromDate",
                        newValue ? newValue.toISOString() : ""
                      );
                    }}
                    format="DD/MM/YYYY HH:mm"
                    slotProps={{
                      popper: {
                        sx: {
                          zIndex: 1701,
                        },
                      },
                      textField: {
                        size: "small",
                        onBlur: () => formik.setFieldTouched("fromDate", true),
                        error:
                          formik.touched.fromDate &&
                          Boolean(formik.errors.fromDate),
                        sx: {
                          width: "270px",
                          "& .MuiOutlinedInput-root": { borderRadius: "8px" },
                        },
                      },
                    }}
                    viewRenderers={{
                      hours: renderTimeViewClock,
                      minutes: renderTimeViewClock,
                      seconds: renderTimeViewClock,
                    }}
                  />
                  {formik.touched.fromDate && formik.errors.fromDate && (
                    <FormHelperText error>
                      {formik.errors.fromDate}
                    </FormHelperText>
                  )}
                </Box>

                <Box>
                  <Typography
                    sx={{ mb: 0.3, fontSize: "14px", fontWeight: 500 }}
                  >
                    To Date Time
                  </Typography>
                  <DateTimePicker
                    value={
                      formik.values.toDate ? dayjs(formik.values.toDate) : null
                    }
                    onChange={(newValue) => {
                      formik.setFieldValue(
                        "toDate",
                        newValue ? newValue.toISOString() : ""
                      );
                    }}
                    format="DD/MM/YYYY HH:mm"
                    slotProps={{
                      popper: {
                        sx: {
                          zIndex: 1701,
                        },
                      },
                      textField: {
                        size: "small",
                        onBlur: () => formik.setFieldTouched("toDate", true),
                        error:
                          formik.touched.toDate &&
                          Boolean(formik.errors.toDate),
                        sx: {
                          width: "270px",
                          "& .MuiOutlinedInput-root": { borderRadius: "8px" },
                        },
                      },
                    }}
                    viewRenderers={{
                      hours: renderTimeViewClock,
                      minutes: renderTimeViewClock,
                      seconds: renderTimeViewClock,
                    }}
                  />
                  {formik.touched.toDate && formik.errors.toDate && (
                    <FormHelperText error>
                      {formik.errors.toDate}
                    </FormHelperText>
                  )}
                </Box>
              </Box>
            </Grid>
          </Grid>

          <Box
            sx={{ display: "flex", justifyContent: "flex-end", gap: 2, mt: 4 }}
          >
            <Button
              variant="outlined"
              onClick={handleResetForm}
              sx={{
                border: "1px solid #14348D",
                borderRadius: "10px",
                color: "#14348D",
              }}
            >
              Clear
            </Button>

            <Button
              variant="contained"
              type="submit"
              disabled={loading}
              sx={{
                display: "flex",
                borderRadius: "10px",
                backgroundColor: "#14348D",
                fontFamily: "Montserrat",
                fontWeight: "Medium",
                color: "white",
                px: "20px",
                textTransform: "none",
              }}
            >
              {loading
                ? isEditMode
                  ? "Updating..."
                  : "Adding..."
                : isEditMode
                ? "Update"
                : "Add"}
            </Button>
          </Box>
        </form>
        </DialogContent>
      </LocalizationProvider>
  );
};

export default AddAlarmSuppressionDialog;