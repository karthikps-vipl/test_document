import React, { useEffect, useState } from "react";
import { DialogContent, Box, Divider } from "@mui/material";
import MTable from "@/components/Reusable/Table/MTable";
import {
  FAULT_ALARMSUPRESSION_DELETE,
  FAULT_GET_ALARMSUPRESSION_INFO,
} from "@/RestAPI/url/endpoint";
import { FaultAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import Delete_Icon_ from "@/assets/SVGIcons/Delete_Icon_.svg";
import { useModalStore } from "@/core/modal/modalStore";

const AlarmSuppressionDialog = ({ node }) => {
  const [tableData, setTableData] = useState([]);

  const [editRow, setEditRow] = useState(null);

  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deleteRow, setDeleteRow] = useState(null);

  const openModal = useModalStore((state) => state.openModal);


  const shouldHideAddButton = tableData.length >= 1;

  const resourceId = node?.resourceId;
  const resourceName = node?.resourceName || "Device";

  const handleAddClick = () => {
    openModal("addAlarmSuppression", {
      resourceId,
      node,
      mode: "add",
      refreshTable: fetchAlarms,
    });
  };

  const handleEditClick = (row) => {
    openModal("editAlarmSuppression", {
      resourceId,
      node,
      editData: row,
      mode: "edit",
      refreshTable: fetchAlarms,
    });
  };

  const handleDeleteClick = (row) => {
    console.log("deletewow", row);
    setDeleteRow(row);
    setIsDeleteOpen(true);
  };

  console.log("editRow", editRow);

  const fetchAlarms = async () => {
    try {
      const url = `${FAULT_GET_ALARMSUPRESSION_INFO}/${resourceId}`;
      const response = await FaultAxios(url, "get");

      console.log("1. Full API Response:", response.data);

      let rawData = [];

      if (Array.isArray(response.data)) {
        rawData = response.data;
      } else if (response.data && typeof response.data === "object") {
        const keys = Object.keys(response.data);
        const arrayKey = keys.find((key) => Array.isArray(response.data[key]));

        if (arrayKey) {
          rawData = response.data[arrayKey];
          console.log(`2. Found array inside key: "${arrayKey}"`);
        } else {
          console.log("2. Response is a single object, wrapping in array");
          rawData = [response.data];
        }
      }

      console.log("3. Raw data extracted:", rawData);

      const normalized = rawData.map((item) => ({
        ...rawData,
        id: item?.id,
        alarmTypeList: item?.alarmTypeList || "N/A",
        fromDate: item?.fromDate || "N/A",
        toDate: item?.toDate || "N/A",
      }));

      // const normalized = rawData.map((item) => ({
      //   ...item,
      //   id: item?.id,
      //   alarmTypeList: item?.alarmTypeList || "N/A",
      //   fromDate: item?.fromDate || "N/A",
      //   toDate: item?.toDate || "N/A",
      // }));

      console.log("4. Final Normalized Data:", normalized);
      setTableData(normalized);
    } catch (err) {
      console.error("Error fetching alarms:", err);
    }
  };

  console.log("deleteRow", deleteRow);

  useEffect(() => {
    if (resourceId) {
      fetchAlarms();
    }
  }, [resourceId]);

  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "80px",
    },
    {
      uid: "alarmTypeList",
      name: "Suppressed Alarm",
      width: "350px",
    },
    {
      uid: "fromDate",
      name: "From Date & Time",
      width: "180px",
    },
    {
      uid: "toDate",
      name: "To Date & Time",
      width: "180px",
    },
    {
      uid: "actions",
      name: "Actions",
      width: "140px",
    },
  ];

  const handleConfirmDelete = async () => {
    try {
      const url = `${FAULT_ALARMSUPRESSION_DELETE}/${deleteRow[0]?.imResourceInfo?.resourceId}`;

      const response = await FaultAxios(url, "post", deleteRow[0]);

      if (response?.data) {
        Toast("Success!", "Alarm suppression deleted successfully.", "success");

        fetchAlarms();

        setIsDeleteOpen(false);
        setDeleteRow(null);
      }
    } catch (error) {
      console.error(error);

      Toast("Error!", "Delete failed", "error");
    }
  };

  console.log("tableDatay", tableData);

  return (
    <>
      <Box>
        <Divider sx={{ mb: 3 }} />
        <DialogContent>
          <Box sx={{ borderRadius: "20px" }}>
            <MTable
              tableTitle="Alarm Suppression"
              columns={columns}
              tableData={tableData}
              showSearch={true}
              AddText="Add"
              handleAdd={handleAddClick}
              showPagination={true}
              showSelect={false}
              alarmSearch={true}
              hideAdd={shouldHideAddButton}
              handleEdit={handleEditClick}
              handleDelete={handleDeleteClick}
            />
          </Box>
        </DialogContent>
      </Box>



      {isDeleteOpen && (
        <MDialog
          open={isDeleteOpen}
          onClose={() => {
            setIsDeleteOpen(false);
            setDeleteRow(null);
          }}
          onConfirm={handleConfirmDelete}
          title="Delete Alarm Suppression"
          message={
            <>
              This action will Delete Alarm suppression Configuration of{" "}
              <strong>{resourceName}</strong>.
              <br />
              Do you want to continue?
            </>
          }
          confirmText="Delete"
          cancelText="Cancel"
          variant="error"
          icon={Delete_Icon_}
        />
      )}
    </>
  );
};

export default AlarmSuppressionDialog;
