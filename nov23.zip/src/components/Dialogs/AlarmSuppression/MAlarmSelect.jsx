import { Done } from "@mui/icons-material";
import {
  Box,
  Checkbox,
  Divider,
  FormControl,
  ListItemText,
  MenuItem,
  TextField,
  Typography,
  Select,
  useTheme,
} from "@mui/material";
import { useState } from "react";

const MAlarmSelect = ({ options = [], value = [], onChange, label }) => {
  const [search, setSearch] = useState("");

  const theme = useTheme();

  // ================= FILTER OPTIONS =================
  const filteredOptions = options.filter((item) =>
    item.label.toLowerCase().includes(search.toLowerCase())
  );

  // ================= HANDLE ITEM TOGGLE =================
  const handleItemToggle = (itemValue) => {
    const updated = value.includes(itemValue)
      ? value.filter((v) => v !== itemValue)
      : [...value, itemValue];

    onChange(updated);
  };

  // ================= SELECT ALL =================
  const allValues = options.map((item) => item.value);

  const isAllSelected = value.length === allValues.length;

  const isIndeterminate = value.length > 0 && value.length < allValues.length;

  const handleSelectAll = (e) => {
    e.stopPropagation();
    onChange(value.length > 0 ? [] : allValues);
  };

  // ================= COMMON CHECKBOX ICON =================
  const checkboxIcons = {
    icon: (
      <Box
        sx={{
          width: 18,
          height: 18,
          bgcolor: "white",
          borderRadius: "2px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "2px solid #c4c4c4",
          marginLeft: "8px",
        }}
      />
    ),

    checkedIcon: (
      <Box
        sx={{
          width: 18,
          height: 18,
          bgcolor: "white",
          borderRadius: "2px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "2px solid #14348D",
          marginLeft: "8px",
        }}
      >
        <Done
          sx={{
            color: "#14348D",
            width: 18,
            fontWeight: 900,
          }}
        />
      </Box>
    ),

    indeterminateIcon: (
      <Box
        sx={{
          width: 18,
          height: 18,
          bgcolor: "white",
          borderRadius: "2px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "2px solid #14348D",
          marginLeft: "8px",
        }}
      >
        <Box
          sx={{
            width: 12,
            height: 2,
            bgcolor: "#14348D",
          }}
        />
      </Box>
    ),
  };

  // ================= COMMON CHECKBOX STYLE =================
  const checkboxStyle = {
    padding: 0,

    "&:hover": {
      backgroundColor: "transparent",
    },
  };

  return (
    <FormControl fullWidth>
      {/* LABEL */}
      <Typography
        sx={{
          mb: 0.3,
          fontSize: "14px",
          fontWeight: 500,
          color:
            theme.palette.mode === "dark" ? "#ffffff" : "rgba(0, 0, 0, 0.88)",
        }}
      >
        {label}
      </Typography>

      <Select
        multiple
        value={value}
        // ================= FIXED WIDTH + ELLIPSIS =================
        renderValue={(selected) => {
          const selectedLabels = options
            .filter((opt) => selected.includes(opt.value))
            .map((opt) => opt.label)
            .join(", ");

          return (
            <Box
              sx={{
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                width: "100%",
                display: "block",
              }}
            >
              {selectedLabels}
            </Box>
          );
        }}
        sx={{
          borderRadius: "10px",
          height: "38px",
          width: "100%",

          "& .MuiSelect-select": {
            display: "flex",
            alignItems: "center",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            width: "100%",
            minWidth: 0,
          },
        }}
        MenuProps={{
          sx: {
            zIndex: 1701,
          },
          PaperProps: {
            style: {
              maxHeight: 250,
              width: 260,
            },
          },
        }}
      >
        {/* SEARCH */}
        <Box
          sx={{
            p: 1,
            position: "sticky",
            top: 0,
            bgcolor: "background.paper",
            zIndex: 1,
          }}
        >
          <TextField
            size="small"
            placeholder="Type here..."
            fullWidth
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => e.stopPropagation()}
          />
        </Box>

        <Divider />

        {/* SELECT ALL */}
        <MenuItem
          onClick={handleSelectAll}
          sx={{
            p: 0,
            minHeight: "34px",
            mt: 1,
          }}
        >
          <Checkbox
            checked={isAllSelected}
            indeterminate={isIndeterminate}
            disableRipple
            {...checkboxIcons}
            sx={checkboxStyle}
          />

          <ListItemText primary="Select All" sx={{ ml: 1 }} />
        </MenuItem>

        <Divider />

        {/* OPTIONS */}
        {filteredOptions.map((item) => (
          <MenuItem
            key={item.value}
            onClick={() => handleItemToggle(item.value)}
            sx={{
              p: 0,
              mb: 1,
              minHeight: "34px",
            }}
          >
            <Checkbox
              checked={value.includes(item.value)}
              disableRipple
              {...checkboxIcons}
              sx={checkboxStyle}
            />

            <ListItemText
              primary={item.label}
              sx={{
                ml: 1,

                "& .MuiTypography-root": {
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                },
              }}
            />
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default MAlarmSelect;
