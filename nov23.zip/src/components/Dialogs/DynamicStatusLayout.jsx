import React, { useMemo, useState } from "react";
import { CircularProgress, Box, Typography } from "@mui/material";

import useDeviceLayout from "@/core/hooks/useDeviceLayout";
import useDeviceStatus from "@/core/hooks/useDeviceStatus";

import TabRenderer from "./components/TabRenderer";

const DynamicStatusLayout = ({ node }) => {
  console.log("nodenodecnms", node);

  const [activeTab, setActiveTab] = useState(0);

  const activeScreen = 1;

  const terminalType = node?.resourceId;

  const deviceId = node?.resourceId;

  const { layout, loading: layoutLoading } = useDeviceLayout(terminalType);

  const { statusData, loading: statusLoading } = useDeviceStatus(
    deviceId,
    activeScreen,
    activeTab
  );

  const tabs = useMemo(() => {
    return layout?.status || [];
  }, [layout]);

  const hydratedTabs = useMemo(() => {
    if (!tabs.length) return [];

    const staticValues = statusData?.static || {};
    const tableValues = statusData?.table || {};

    return tabs.map((tab) => ({
      ...tab,

      widget: (tab.widget || []).map((widget) => ({
        ...widget,

        data: (widget.data || []).map((item) => {
          let value = staticValues[item.oid];

          // if not found in static,
          // search inside table rows
          if (value === undefined) {
            Object.values(tableValues).some((rows) => {
              return rows.some((row) => {
                if (row[item.oid] !== undefined) {
                  value = row[item.oid];
                  return true;
                }
                return false;
              });
            });
          }

          return {
            ...item,
            currentValue: value ?? "--",
          };
        }),
      })),
    }));
  }, [tabs, statusData]);

  if (layoutLoading) {
    return (
      <Box textAlign="center" p={3}>
        <CircularProgress />
      </Box>
    );
  }

  if (!hydratedTabs.length) {
    return <Typography>No layout found</Typography>;
  }

  return (
    <TabRenderer
      tabs={hydratedTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      loading={statusLoading}
      node={node}
    />
  );
};

export default DynamicStatusLayout;
