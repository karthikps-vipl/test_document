// import React, { useMemo, useState } from "react";
// import { CircularProgress, Box, Typography } from "@mui/material";

// import useDeviceLayout from "@/core/hooks/useDeviceLayout";
// import useDeviceStatus from "@/core/hooks/useDeviceStatus";
// import useDeviceConfig from "@/core/hooks/useDeviceConfig"; // New hook

// import TabRenderer from "./components/TabRenderer";
// import { sanitizeLayoutKeys } from "@/lib/utils";
// const hydrateWidget = (widget, activeValues, tableValues, saveConfig) => {
//   if (widget.type === "widgetGroup") {
//     return {
//       ...widget,
//       saveConfigHandler: saveConfig,
//       children: (widget.children || []).map((child) => {
//         // If children are raw fields with their own OID directly on them:
//         let value = activeValues[child.oid];

//         if (value === undefined) {
//           Object.values(tableValues).some((rows) => {
//             return rows.some((row) => {
//               if (row[child.oid] !== undefined) {
//                 value = row[child.oid];
//                 return true;
//               }
//               return false;
//             });
//           });
//         }

//         return {
//           ...child,
//           currentValue: value ?? "",
//         };
//       }),
//     };
//   }

//   // Standard widget hydration logic for normal widgets...
//   return {
//     ...widget,
//     saveConfigHandler: saveConfig,
//     data: (widget.data || []).map((item) => {
//       let value = activeValues[item.oid];
//       if (value === undefined) {
//         Object.values(tableValues).some((rows) => {
//           return rows.some((row) => {
//             if (row[item.oid] !== undefined) {
//               value = row[item.oid];
//               return true;
//             }
//             return false;
//           });
//         });
//       }
//       return { ...item, currentValue: value ?? "" };
//     }),
//     hybrid: (widget.hybrid || []).map((hybridWidget) => ({
//       ...hybridWidget,
//       data: (hybridWidget.data || []).map((item) => ({
//         ...item,
//         currentValue: activeValues[item.oid] ?? "",
//       })),
//     })),
//   };
// };

// // const DynamicDeviceLayout = ({ node, mode = "status" }) => {
// //   const [activeTab, setActiveTab] = useState(0);
// //   const activeScreen = 1;
// //   const terminalType = node?.resourceId;
// //   const deviceId = node?.resourceId;

// //   // 1. Fetch layout schema
// //   const { layout, loading: layoutLoading } = useDeviceLayout(terminalType);

// //   // 2. Fetch appropriate data hook based on 'mode'
// //   const { statusData, loading: statusLoading } = useDeviceStatus(
// //     deviceId,
// //     activeScreen,
// //     activeTab,
// //     mode==="status"
// //   );

// //   const {
// //     configData,
// //     loading: configLoading,
// //     saveConfig,
// //   } = useDeviceConfig(deviceId, activeScreen, activeTab, mode === "configuration");

// //   // 3. Sanitize and Extract tabs based on the requested mode
// //   const tabs = useMemo(() => {
// //     if (!layout) return [];
// //     const sanitized = sanitizeLayoutKeys(layout);
// //     return sanitized[mode] || [];
// //   }, [layout, mode]);

// //   // 4. Hydrate widgets with either status or configuration dynamic values
// //   const hydratedTabs = useMemo(() => {
// //     if (!tabs.length) return [];

// //     // Combine any data maps
// //     const activeValues =
// //       mode === "configuration"
// //         ? configData?.static || {}
// //         : statusData?.static || {};

// //     const tableValues =
// //       mode === "configuration"
// //         ? configData?.table || {}
// //         : statusData?.table || {};

// //     return tabs.map((tab) => ({
// //       ...tab,
// //       widget: (tab.widget || []).map((widget) => ({
// //         ...widget,
// //         // Forward configuration updater callback down to widget tree
// //         saveConfigHandler: saveConfig,
// //         data: (widget.data || []).map((item) => {
// //           let value = activeValues[item.oid];

// //           if (value === undefined) {
// //             Object.values(tableValues).some((rows) => {
// //               return rows.some((row) => {
// //                 if (row[item.oid] !== undefined) {
// //                   value = row[item.oid];
// //                   return true;
// //                 }
// //                 return false;
// //               });
// //             });
// //           }

// //           return {
// //             ...item,
// //             currentValue: value ?? "",
// //           };
// //         }),
// //         // Map hybrid/select inputs similarly if present
// //         hybrid: (widget.hybrid || []).map((hybridWidget) => ({
// //           ...hybridWidget,
// //           data: (hybridWidget.data || []).map((item) => {
// //             const val = activeValues[item.oid] ?? "";
// //             return {
// //               ...item,
// //               currentValue: val,
// //             };
// //           }),
// //         })),
// //       })),
// //     }));
// //   }, [tabs, statusData, configData, mode, saveConfig]);

// //   if (layoutLoading) {
// //     return (
// //       <Box display="flex" justifyContent="center" alignItems="center" p={6}>
// //         <CircularProgress />
// //       </Box>
// //     );
// //   }

// //   if (!hydratedTabs.length) {
// //     return <Typography sx={{ p: 3 }}>No schema found for {mode}</Typography>;
// //   }

// //   console.log(statusData,"statusDatastatffffusDatastatusData");

// //   return (
// //     <TabRenderer
// //       tabs={hydratedTabs}
// //       activeTab={activeTab}
// //       onTabChange={setActiveTab}
// //       loading={mode === "configuration" ? configLoading : statusLoading}
// //       node={node}
// //       liveData={statusData}
// //     />
// //   );
// // };
// const DynamicDeviceLayout = ({ node, mode = "status" }) => {
//   const [activeTab, setActiveTab] = useState(0);
//   const activeScreen = 1;
//   const terminalType = node?.resourceId;
//   const deviceId = node?.resourceId;

//   const { layout, loading: layoutLoading } = useDeviceLayout(terminalType);

//   const { statusData, loading: statusLoading } = useDeviceStatus(
//     deviceId,
//     activeScreen,
//     activeTab,
//     mode === "status"
//   );

//   const {
//     configData,
//     loading: configLoading,
//     saveConfig,
//   } = useDeviceConfig(deviceId, activeScreen, activeTab, mode === "configuration");

//   const tabs = useMemo(() => {
//     if (!layout) return [];
//     const sanitized = sanitizeLayoutKeys(layout);
//     return sanitized[mode] || [];
//   }, [layout, mode]);

//   // 4. Hydrated tabs updated with recursive helper
//   const hydratedTabs = useMemo(() => {
//     if (!tabs.length) return [];

//     const activeValues =
//       mode === "configuration"
//         ? configData?.static || {}
//         : statusData?.static || {};

//     const tableValues =
//       mode === "configuration"
//         ? configData?.table || {}
//         : statusData?.table || {};

//     return tabs.map((tab) => ({
//       ...tab,
//       widget: (tab.widget || []).map((widget) =>
//         hydrateWidget(widget, activeValues, tableValues, saveConfig)
//       ),
//     }));
//   }, [tabs, statusData, configData, mode, saveConfig]);

//   if (layoutLoading) {
//     return (
//       <Box display="flex" justifyContent="center" alignItems="center" p={6}>
//         <CircularProgress />
//       </Box>
//     );
//   }

//   if (!hydratedTabs.length) {
//     return <Typography sx={{ p: 3 }}>No schema found for {mode}</Typography>;
//   }

//   return (
//     <TabRenderer
//       tabs={hydratedTabs}
//       activeTab={activeTab}
//       onTabChange={setActiveTab}
//       loading={mode === "configuration" ? configLoading : statusLoading}
//       node={node}
//       liveData={statusData}
//     />
//   );
// };

// export default DynamicDeviceLayout;

// import React, { useMemo, useState } from "react";
// import { CircularProgress, Box, Typography } from "@mui/material";

// import useDeviceLayout from "@/core/hooks/useDeviceLayout";
// import useDeviceStatus from "@/core/hooks/useDeviceStatus";
// import useDeviceConfig from "@/core/hooks/useDeviceConfig";

// import TabRenderer from "./components/TabRenderer";
// import { sanitizeLayoutKeys } from "@/lib/utils";

// // 1. Recursive helper to hydrate standard widgets OR nested widgetGroup children
// const hydrateWidget = (widget, activeValues, tableValues, saveConfig) => {
//   if (widget.type === "hybrid") {
//     return {
//       ...widget,
//       saveConfigHandler: saveConfig,
//       children: (widget.children || []).map((child) =>
//         hydrateWidget(child, activeValues, tableValues, saveConfig)
//       ),
//     };
//   }

//   return {
//     ...widget,
//     saveConfigHandler: saveConfig,
//     data: (widget.data || []).map((item) => {
//       let value = activeValues[item.oid];

//       if (value === undefined) {
//         Object.values(tableValues).some((rows) => {
//           return rows.some((row) => {
//             if (row[item.oid] !== undefined) {
//               value = row[item.oid];
//               return true;
//             }
//             return false;
//           });
//         });
//       }

//       return {
//         ...item,
//         currentValue: value ?? "",
//       };
//     }),
//     hybrid: (widget.hybrid || []).map((hybridWidget) => ({
//       ...hybridWidget,
//       data: (hybridWidget.data || []).map((item) => {
//         const val = activeValues[item.oid] ?? "";
//         return {
//           ...item,
//           currentValue: val,
//         };
//       }),
//     })),
//   };
// };

// const DynamicDeviceLayout = ({ node, mode = "status" }) => {
//   const [activeTab, setActiveTab] = useState(0);
//   const activeScreen = 1;
//   const terminalType = node?.resourceId;
//   const deviceId = node?.resourceId;

//   const { layout, loading: layoutLoading } = useDeviceLayout(terminalType);

//   const { statusData, loading: statusLoading } = useDeviceStatus(
//     deviceId,
//     activeScreen,
//     activeTab,
//     mode === "status"
//   );

//   const {
//     configData,
//     loading: configLoading,
//     saveConfig,
//   } = useDeviceConfig(deviceId, activeScreen, activeTab, mode === "configuration");

//   const tabs = useMemo(() => {
//     if (!layout) return [];
//     const sanitized = sanitizeLayoutKeys(layout);
//     return sanitized[mode] || [];
//   }, [layout, mode]);

//   // 2. Hydrate tabs recursively so nested children get their data mapped
//   const hydratedTabs = useMemo(() => {
//     if (!tabs.length) return [];

//     const activeValues =
//       mode === "configuration"
//         ? configData?.static || {}
//         : statusData?.static || {};

//     const tableValues =
//       mode === "configuration"
//         ? configData?.table || {}
//         : statusData?.table || {};

//     return tabs.map((tab) => ({
//       ...tab,
//       widget: (tab.widget || []).map((widget) =>
//         hydrateWidget(widget, activeValues, tableValues, saveConfig)
//       ),
//     }));
//   }, [tabs, statusData, configData, mode, saveConfig]);

//   if (layoutLoading || (mode === "status" && statusLoading && !statusData)){
//     return (
//       <Box display="flex" justifyContent="center" alignItems="center" p={6}>
//         <CircularProgress />
//       </Box>
//     );
//   }

//   if (!hydratedTabs.length) {
//     return <Typography sx={{ p: 3 }}>No schema found for {mode}</Typography>;
//   }

//   return (
//     <TabRenderer
//       tabs={hydratedTabs}
//       activeTab={activeTab}
//       onTabChange={setActiveTab}
//       loading={mode === "configuration" ? configLoading : (statusLoading && !statusData)}
//       node={node}
//       liveData={statusData}
//     />
//   );
// };

// export default DynamicDeviceLayout;
import React, { useMemo, useState, useCallback } from "react";

import { CircularProgress, Box, Typography } from "@mui/material";

import useDeviceLayout from "@/core/hooks/useDeviceLayout";
import useDeviceStatus from "@/core/hooks/useDeviceStatus";
import useDeviceConfig from "@/core/hooks/useDeviceConfig";

import TabRenderer from "./components/TabRenderer";
import { sanitizeLayoutKeys } from "@/lib/utils";
import Toast from "@/components/Reusable/Toast/Toast";

/* ============================================================
   HELPERS
============================================================ */

const clean = (value) => String(value ?? "").trim();

const parseOperatorMap = (operatorMap) => {
  if (!operatorMap) return {};

  return String(operatorMap)
    .split(",")
    .reduce((acc, item) => {
      const [value, ...labelParts] = item.split(":");

      if (!value || labelParts.length === 0) {
        return acc;
      }

      acc[String(value).trim()] = labelParts.join(":").trim();

      return acc;
    }, {});
};
const getSelectWidgetMap = (widget, oidMapping) => {
  const existingMap = widget?.selectWidgetMap || {};
  const result = { ...existingMap };

  (widget?.data || []).forEach((item) => {
    const oid = clean(item?.oid);

    if (!oid) return;

    const mapping = oidMapping?.[oid];

    if (
      mapping &&
      clean(mapping.operation).toLowerCase() === "map" &&
      mapping.operator_map
    ) {
      result[oid] = parseOperatorMap(mapping.operator_map);
    }
  });

  return result;
};

const getMappedValue = (oid, apiValue, oidMapping) => {
  const cleanOid = clean(oid);
  const value = clean(apiValue);

  if (!value) return "";

  const mapping = oidMapping?.[cleanOid];

  if (!mapping) {
    return value;
  }

  if (clean(mapping.operation).toLowerCase() !== "map") {
    return value;
  }

  const parsedMap = parseOperatorMap(mapping.operator_map);

  const found = Object.entries(parsedMap).find(
    ([numericValue, label]) =>
      clean(label).toLowerCase() === value.toLowerCase()
  );

  return found ? found[0] : value;
};


const normalizeOidMapping = (mappingResponse) => {
  const result = {};

  if (!mappingResponse) {
    return result;
  }

  const mappings = Array.isArray(mappingResponse)
    ? mappingResponse
    : Object.values(mappingResponse);

  mappings.forEach((mapping) => {
    if (!mapping?.oidName) return;

    const oid = clean(mapping.oidName);

    result[oid] = mapping;
  });

  return result;
};

/* ============================================================
   HYDRATE WIDGET
============================================================ */


const hydrateWidget = (
  widget,
  activeValues,
  tableValues,
  editedValues,
  oidMapping,
  handleInputValueChange,
  handleSaveConfigurationWidget,
  validationErrors,
  setValidationErrors
) => {
  if (!widget) return widget;

  /*
   * ============================================================
   * HYBRID WIDGET
   * ============================================================
   */
  if (widget.type === "hybrid") {
    return {
      ...widget,

      saveConfigHandler: handleSaveConfigurationWidget,
      inputChangeHandler: handleInputValueChange,
      validationErrors,
      setValidationErrors,
      children: (widget.children || []).map((child) =>
        hydrateWidget(
          child,
          activeValues,
          tableValues,
          editedValues,
          oidMapping,
          handleInputValueChange,
          handleSaveConfigurationWidget,
          validationErrors,
          setValidationErrors
        )
      ),
    };
  }

  /*
   * ============================================================
   * NORMAL EDITABLE / EDITABLE SELECT
   * ============================================================
   */

  const hydratedWidget = {
    ...widget,

    saveConfigHandler: handleSaveConfigurationWidget,
    // inputChangeHandler: handleInputValueChange,
    inputChangeHandler: (wIdx, key, val) => {
      const itemConfig = (widget.data || []).find((d) => clean(d.oid) === clean(key));
      handleInputValueChange(wIdx, key, val, itemConfig);
    },
    validationErrors,
    data: (widget.data || []).map((item) => {
      const oid = clean(item?.oid);
      let value;

      /*
       * 1. Local edited value
       */
      if (editedValues[oid] !== undefined) {
        value = editedValues[oid];
      }

      /*
       * 2. Backend value
       */
      if (value === undefined) {
        value = activeValues?.[oid];
      }

      /*
       * 3. Table value
       */
      if (value === undefined) {
        Object.values(tableValues || {}).some((rows) => {
          return (rows || []).some((row) => {
            if (row?.[oid] !== undefined) {
              value = row[oid];
              return true;
            }

            return false;
          });
        });
      }
      // if (value === undefined) {
      //   Object.values(tableValues || {}).forEach((rows) => {
      //     (rows || []).forEach((row) => {
      //       if (row?.[oid] !== undefined) value = row[oid];
      //     });
      //   });
      // }


      if (widget.type === "editableSelect") {
        value = getMappedValue(
          oid,
          value ?? "",
          oidMapping
        );
      }

      return {
        ...item,
        oid,
        currentValue: value ?? "",
      };
    }),
  };

  /*
   * ============================================================
   * NORMAL EDITABLE WIDGET -> HYBRID DROPDOWNS
   * ============================================================
   */

  if (widget.type === "editable") {
    hydratedWidget.hybrid = (widget.hybrid || []).map(
      (hybridWidget) => {
        const hydratedHybrid = {
          ...hybridWidget,

          saveConfigHandler: handleSaveConfigurationWidget,
          inputChangeHandler: handleInputValueChange,

          /*
           * IMPORTANT:
           * Replace the layout selectWidgetMap with
           * FETCH_OID_MAPPING response where available.
           */
          selectWidgetMap: getSelectWidgetMap(
            hybridWidget,
            oidMapping
          ),

          data: (hybridWidget.data || []).map((item) => {
            const oid = clean(item?.oid);

            let value;

            /*
             * Local edited value
             */
            if (editedValues[oid] !== undefined) {
              value = editedValues[oid];
            }

            /*
             * Backend value
             */
            if (value === undefined) {
              value = activeValues?.[oid];
            }

            /*
             * Convert backend display value
             * into dropdown numeric value.
             */
            value = getMappedValue(
              oid,
              value ?? "",
              oidMapping
            );

            return {
              ...item,
              oid,
              currentValue: value,
            };
          }),
        };

        return hydratedHybrid;
      }
    );
  }

  /*
   * ============================================================
   * STANDALONE EDITABLE SELECT
   * ============================================================
   */

  if (widget.type === "editableSelect") {
    hydratedWidget.selectWidgetMap =
      getSelectWidgetMap(widget, oidMapping);
  }

  return hydratedWidget;
};

/* ============================================================
   MAIN COMPONENT
============================================================ */

const DynamicDeviceLayout = ({ node, mode = "status" }) => {
  const [activeTab, setActiveTab] = useState(0);
  const [editedValues, setEditedValues] = useState({});
  const [validationErrors, setValidationErrors] = useState({});
  const activeScreen = mode === "configuration" ? 2 : 1;

  const terminalType = node?.resourceId;
  const deviceId = node?.resourceId;

  const { layout, loading: layoutLoading } = useDeviceLayout(terminalType,node);

  const { statusData, loading: statusLoading } = useDeviceStatus(
    deviceId,
    activeScreen,
    activeTab,
    mode === "status",
    node
  );
  /* ============================================================
     TABS
  ============================================================ */

  const tabs = useMemo(() => {
    if (!layout) {
      return [];
    }

    const sanitized = sanitizeLayoutKeys(layout);

    return sanitized[mode] || [];
  }, [layout, mode]);
 
  const {
    configData,
    oidMapping,
    loading: configLoading,
    saving,
    saveConfig,
  } = useDeviceConfig(
    deviceId,
    activeScreen,
    activeTab,
    mode === "configuration",
    mode === "configuration" ? tabs : []
  );

  /* ============================================================
     INPUT CHANGE
  ============================================================ */

  // const handleInputValueChange = useCallback(
  //   (widgetIdx, fieldKey, value) => {
  //     if (mode !== "configuration") {
  //       return;
  //     }

  //     let oid = clean(fieldKey);


  //     if (oid.startsWith("val_")) {
  //       oid = clean(oid.substring(4));
  //     }

  //     if (!oid) return;

  //     setEditedValues((prev) => ({
  //       ...prev,
  //       [oid]: value,
  //     }));
  //   },
  //   [mode]
  // );
  const handleInputValueChange = useCallback(
    (widgetIdx, fieldKey, value, itemConfig) => {
      if (mode !== "configuration") return;
  
      let oid = clean(fieldKey);
      if (oid.startsWith("val_")) oid = clean(oid.substring(4));
      if (!oid) return;
  
      // --- Validation Logic ---
      let errorMessage = "";
      const numVal = parseFloat(value);
  
      if (value !== "" && !isNaN(numVal)) {
        if (itemConfig?.min !== undefined && numVal < Number(itemConfig.min)) {
          errorMessage = `Value must be greater than or equal to ${itemConfig.min}`;
        } else if (itemConfig?.max !== undefined && numVal > Number(itemConfig.max)) {
          errorMessage = `Value must be less than or equal to ${itemConfig.max}`;
        } else if (itemConfig?.step !== undefined) {
          const step = Number(itemConfig.step);
          const min = itemConfig.min !== undefined ? Number(itemConfig.min) : 0;
          // Check step alignment precision
          if (Math.abs((numVal - min) % step) > 1e-5) {
            errorMessage = `Value must be in increments of ${step}`;
          }
        }
      }
  
      if (!errorMessage && itemConfig?.regex && value !== "") {
        const regex = new RegExp(itemConfig.regex);
        if (!regex.test(value)) {
          errorMessage = "Invalid format";
        }
      }
  
      setValidationErrors((prev) => ({
        ...prev,
        [oid]: errorMessage,
      }));
  
      setEditedValues((prev) => ({
        ...prev,
        [oid]: value,
      }));
    },
    [mode]
  );
  
  /* ============================================================
     SAVE
  ============================================================ */

  const handleSaveConfigurationWidget = useCallback(
    async (widget) => {
      if (mode !== "configuration") {
        return;
      }
      const hasValidationErrors = Object.values(
        validationErrors
      ).some(Boolean);
      
      if (hasValidationErrors) {
        Toast(
          "Error",
          "Please fix the validation errors before saving",
          "error"
        );
      
        return;
      }
      const payloadMap = new Map();

      const addField = (item) => {
        const oid = clean(item?.oid);

        if (!oid) {
          return;
        }


        let value =
          editedValues[oid] !== undefined
            ? editedValues[oid]
            : item?.currentValue;
        

        if (value === undefined || value === null || clean(value) === "") {
          return;
        }

        value = clean(value);

        payloadMap.set(oid, {
          oid,
          value,
        });
      };


      (widget?.data || []).forEach(addField);


      (widget?.hybrid || []).forEach((hybridWidget) => {
        (hybridWidget?.data || []).forEach(addField);
      });
 
      // const payload = Array.from(payloadMap.values());
      const payload = Object.entries(editedValues)
      .map(([oid, value]) => ({
        oid: clean(oid),
        value: clean(value),
      }))
      .filter(
        (item) =>
          item.oid &&
          item.value !== ""
      );

    if (!payload.length) {
      Toast(
        "Warning",
        "No configuration values were changed",
        "warning"
      );

      return;
    }
      if (!payload.length) {
        Toast("Warning", "No configuration values to save", "warning");

        return;
      }

      const result = await saveConfig(payload);

      if (result?.success) {
        setEditedValues({});
        setValidationErrors({});
      
        Toast(
          "Success",
          "Configuration saved successfully",
          "success"
        );
      }
       else {
        Toast(
          "Error",
          result?.message || "Failed to save configuration",
          "error"
        );
      }
    },
    [editedValues, mode, saveConfig, validationErrors]
  );


  /* ============================================================
     HYDRATE
  ============================================================ */

  const normalizedOidMapping = useMemo(
    () => normalizeOidMapping(oidMapping),
    [oidMapping]
  );

  const hydratedTabs = useMemo(() => {
    if (!tabs.length) {
      return [];
    }

    const activeValues =
      mode === "configuration"
        ? configData?.static || {}
        : statusData?.static || {};

    const tableValues =
      mode === "configuration"
        ? configData?.table || {}
        : statusData?.table || {};

    /*
     * Normalize API OID keys.
     */
    const normalizedActiveValues = Object.entries(activeValues || {}).reduce(
      (acc, [key, value]) => {
        acc[clean(key)] = value;
        return acc;
      },
      {}
    );

    return tabs.map((tab) => ({
      ...tab,

      widget: (tab.widget || []).map((widget) =>
        hydrateWidget(
          widget,
          normalizedActiveValues,
          tableValues,
          mode === "configuration" ? editedValues : {},
          normalizedOidMapping,
          handleInputValueChange,
          handleSaveConfigurationWidget,
          validationErrors,
          setValidationErrors
        )
      ),
    }));
  }, [
    tabs,
    statusData,
    configData,
    mode,
    editedValues,
    normalizedOidMapping,
    handleInputValueChange,
    handleSaveConfigurationWidget,
  ]);

  /* ============================================================
     LOADING
  ============================================================ */

  if (layoutLoading || (mode === "status" && statusLoading && !statusData)) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" p={6}>
        <CircularProgress />
      </Box>
    );
  }

  if (!hydratedTabs.length) {
    return <Typography sx={{ p: 3 }}>No schema found for {mode}</Typography>;
  }

  /* ============================================================
     RENDER
  ============================================================ */

  return (
    <TabRenderer
      tabs={hydratedTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      loading={
        mode === "configuration" ? configLoading : statusLoading && !statusData
      }
      saving={saving}
      node={node}
      liveData={statusData}
      
    />
  );
};

export default DynamicDeviceLayout;
