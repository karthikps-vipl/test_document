import { useEffect, useState, } from "react";
import { Box, CircularProgress, DialogContent } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useModalStore } from "@/core/modal/modalStore";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { FETCH_ALL_RESOURCES_OF_GIVEN_SEGMENT } from "@/RestAPI/url/endpoint";

import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";
import { exportToPDF } from "@/components/Reusable/Pdf/downloadPdf";
import MTable from "@/components/Reusable/Table/MTable";

const SegmentDetailsDialog = () => {
  const dispatch = useDispatch();
  const { modalProps, closeModal } = useModalStore(); 
  const segment = modalProps?.node;
  const segmentId = segment?.segmentId;
  const segmentName = `${segment?.segmentName + " segment"}` || "Segment Details";

  // Redux state for Maximized view
  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  const handleClose = () => {
    if (closeModal) {
      closeModal();
    } else {
      console.warn("closeModal function not found in useModalStore");
    }
  };

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);

  // Column Definitions based on your attached image
  const columns = [
    { uid: "index", name: "S.No.", width: "70px" },
    { uid: "resourceName", name: "Name", width: "200px" },
    { uid: "resourceIp", name: "IP Address", width: "150px" },
    { uid: "make", name: "Make", width: "150px" },
    { uid: "model", name: "Model", width: "150px" },
    { uid: "resourceSerialno", name: "Serial No", width: "150px" },
    { uid: "resourceDesc", name: "Description", width: "250px" },
    { uid: "firmwareVersion", name: "Firmware Version", width: "150px" },
  ];

  useEffect(() => {
    if (!segmentId) return;
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await InventoryAxios(
          `${FETCH_ALL_RESOURCES_OF_GIVEN_SEGMENT}/${segmentId}`
        );

        // Helper function to handle NULL/Undefined/Empty values
        const formatValue = (val) => {
          if (val === null || val === undefined || val === "") {
            return "NA";
          }
          return val;
        };

        const transformedData = response.data.map((item, index) => {
          // Safely extract nested properties to avoid "cannot read property of null" errors
          const resType = item.imResourceType || {};
          
          return {
            ...item, // Keep original data
            index: index + 1,
            resourceName: formatValue(item.resourceName),
            resourceIp: formatValue(item.resourceIp),
            make: formatValue(resType.make),
            model: formatValue(resType.model),
            resourceSerialno: formatValue(item.resourceSerialno),
            resourceDesc: formatValue(item.resourceDesc),
            firmwareVersion: formatValue(item.firmwareVersion),
          };
        });

        setData(transformedData);
        console.log("Transformed Segment Data:", transformedData);
      } catch (err) {
        console.error("Error fetching segment details:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [segmentId]);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  const handleDownloadPDF = () => {
    const fileName = `${segmentName}_Report`.replace(/\s+/g, "_");
    exportToPDF(
      `${segmentName} Report`,
      columns,
      data,
      `${fileName}_Report`,
      "NMS User"
    );
  };

  if (loading) {
    return (
      <Box p={4} textAlign="center" width="100%">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <DialogContent>
        <Box sx={{   borderRadius: "20px", overflow: "hidden" }}>
          <MTable
            tableTitle={segmentName.toUpperCase()} // Matches the header style in your image
            columns={columns}
            tableData={data}
            showSearch={true} // Enables the search box
            handleDownloadPDF={handleDownloadPDF}
            showPagination={true}
            handleClose={handleClose} 
            closeIcon={true} // Shows the X icon
            showMaximazed={true} // Enables the fullscreen icon logic
            isMaximized={isTableMaximized}
            toggleMaximize={handleToggleMaximize}
          />
        </Box>
      </DialogContent>
    </Box>
  );
};

export default SegmentDetailsDialog;



// import { useEffect, useState } from "react";
// import { Box, CircularProgress } from "@mui/material";
// import { useModalStore } from "@/core/modal/modalStore";
// import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
// import { FETCH_ALL_RESOURCES_OF_GIVEN_SEGMENT } from "@/RestAPI/url/endpoint";


// const SegmentDetailsDialog = () => {
//   const { modalProps } = useModalStore();

//   const segment = modalProps?.node;

//   const segmentId = segment?.segmentId;
//   console.log("yysegment",segmentId);
//   const [loading, setLoading] = useState(false);

//   const [data, setData] = useState([]);

//   useEffect(() => {
//     if (!segmentId) return;

//     const fetchData = async () => {
//       setLoading(true);

//       try {
//         const response = await InventoryAxios(
//           `${FETCH_ALL_RESOURCES_OF_GIVEN_SEGMENT}/${segmentId}`,
//         );

//         const transformedData = response.data.map((item, index) => ({
//           index: index + 1,

//           ...item,

//           make: item.imResourceType?.make,

//           model: item.imResourceType?.model,

//           terminalName:
//             item.imResourceType?.terminalId?.terminalTypeName,
//         }));

//         setData(transformedData);

//         console.log("Segment Details", transformedData);
//       } catch (err) {
//         console.error(err);
//       }

//       setLoading(false);
//     };

//     fetchData();
//   }, [segmentId]);

//   if (loading)
//     return (
//       <Box p={4} textAlign="center">
//         <CircularProgress />
//       </Box>
//     );

//   return (
//     <Box p={2}>
//       {/*
//           data is ready

//           pass to your MTable

//           data={data}
//       */}
//     </Box>
//   );
// };

// export default SegmentDetailsDialog;