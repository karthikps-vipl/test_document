import { Box, DialogContent } from "@mui/material";
import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import MTable from "../Reusable/Table/MTable";
import { exportToPDF } from "../Reusable/Pdf/downloadPdf";
import { toggleTableMaximize } from "@/store/features/Inventory/inventorySlice";

const ActiveAlarmDialog = ({ onClose }) => {
  const { allResourceInfo } = useSelector((state) => state.topologySlice);
  console.log("allResourceInfo", allResourceInfo);
  const { repDetails } = useSelector((state) => state.nodeDetails);
  const isTableMaximized = useSelector(
    (state) => state.inventory.isTableMaximized
  );

  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  console.log("repDetailsitemmmmm", repDetails);

  const active_Title = `Inventory Details - ${repDetails?.id}`;

  const columns = [
    {
      uid: "sno",
      name: "S.No",
      width: "60px",
    },
    {
      uid: "name",
      name: "Name",
      width: "260px",
    },
    {
      uid: "ipAddress",
      name: "IP Address",
      width: "190px",
    },
    {
      uid: "make",
      name: "Make",
      width: "180px",
    },
    {
      uid: "model",
      name: "Model",
      width: "200px",
    },
    {
      uid: "serialNo",
      name: "Serial No.",
      width: "120px",
    },
    {
      uid: "description",
      name: "Description",
      width: "270px",
    },
    {
      uid: "firmwareVersion",
      name: "Firmware Version",
      width: "190px",
    },
    {
      uid: "macAddress",
      name: "Mac Address",
      width: "190px",
    },
    {
      uid: "isMaintainance",
      name: "Under Maintenance",
      width: "190px",
    },
    {
      uid: "discoveredTime",
      name: "Discovered Time",
      width: "190px",
    },
  ];

  const fillTable = useCallback(async () => {
    const rowData = allResourceInfo.map((r, index) => {
      return {
        ...r,
        index: index + 1,
        name: r.resourceName || "",
        make: r.imResourceType.make,
        model: r.imResourceType.model,
        firmwareVersion: r.firmwareVersion || "NA",
        macAddress: r.macAddress || "NA",
        ipAddress: r.resourceIp || "NA",
        description: r.resourceDesc || "NA",
        serialNo: r.resourceSerialno || "NA",
        discoveredTime: r.timestamp || "NA",
        isMaintainance: r.isMaintainance ? "Yes" : "No",
      };
    });
    setData(rowData);
  }, [allResourceInfo]);

  useEffect(() => {
    fillTable();
  }, [fillTable]);

  const handleToggleMaximize = () => {
    dispatch(toggleTableMaximize());
  };

  return (
    <Box>
      <DialogContent>
        <Box sx={{   borderRadius: "20px" }}>
          <MTable
            tableTitle={active_Title}
            columns={columns}
            tableData={data}
            showSearch={true}
            handleDownloadPDF={() => {
              const sanitizedName = "Inventory_Details".replace(/\s+/g, "_");
              const normalName = "Inventory_Details";
              exportToPDF(
                `${normalName} Report`,
                columns,
                data,
                `${sanitizedName}_Report`,
                "NMS User"
              );
            }}
            showPagination={true}
            handleClose={onClose}
            closeIcon={true}
            showMaximazed={true}
            // 3. Pass the BOOLEAN value here
            isMaximized={isTableMaximized}
            // 4. Pass the FUNCTION to handle the click
            toggleMaximize={handleToggleMaximize}
          />
        </Box>
      </DialogContent>
    </Box>
  );
};
export default ActiveAlarmDialog;
