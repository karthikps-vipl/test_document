import React, { useState, useEffect, useMemo, useRef } from "react";

import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";

import {
  GET_STATUS_FOR_CONFIGURATION,
  FETCH_CURRENT_AZ_EL,
  SAVE_MANUAL_GPS,
  SAVE_TARGET_GPS,
  SAVE_HOMING,
  SAVE_AUTO_STOW,
  SAVE_MANUAL_STOW,
  SAVE_ELEVATION_MOVEMENT,
  SAVE_AZIMUTH_MOVEMENT,
  PERFORM_STAND_BY_MODE,
  GO_TO_AZIMUTH_ELEVATION_POSITION,
} from "@/RestAPI/url/endpoint";

import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import MButtonPrimary from "@/components/Reusable/Button/MButtonPrimary";
import Confirmation_icon from "../../../assets/SVGIcons/question_mark.svg";
import {
  Box,
  Paper,
  Grid,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  FormHelperText,
  Switch,
} from "@mui/material";

import {
  ArrowDownwardRounded,
  ArrowUpward,
  PauseCircleFilled,
  Rotate90DegreesCcw,
  Rotate90DegreesCw,
} from "@mui/icons-material";
import MDialog from "@/components/Reusable/Dialog/MDialog";
import { useSelector } from "react-redux";
import {
  FETCH_CURRENT_AZ_EL_CNMS,
  GET_STATUS_FOR_CONFIGURATION_CNMS,
  GO_TO_AZIMUTH_ELEVATION_POSITION_CNMS,
  PERFORM_STAND_BY_MODE_CNMS,
  SAVE_AUTO_STOW_CNMS,
  SAVE_AZIMUTH_MOVEMENT_CNMS,
  SAVE_ELEVATION_MOVEMENT_CNMS,
  SAVE_HOMING_CNMS,
  SAVE_MANUAL_GPS_CNMS,
  SAVE_MANUAL_STOW_CNMS,
  SAVE_TARGET_GPS_CNMS,
} from "@/RestAPI/url/cnmsEndPoint";

const OPERATION_ACK = {
  /* Movement START acknowledgements */
  UP_STARTED: "EL MANUAL UP STARTED",
  DOWN_STARTED: "EL MANUAL DOWN STARTED",
  CW_STARTED: "AZ MANUAL CW STARTED",
  CCW_STARTED: "AZ MANUAL CCW STARTED",

  /* Movement STOP acknowledgements */
  UP_STOPPED: "EL MANUAL UP STOP",
  DOWN_STOPPED: "EL MANUAL DOWN STOP",
  CW_STOPPED: "AZ MANUAL CW STOP",
  CCW_STOPPED: "AZ MANUAL CCW STOP",

  /* Movement automatically reached position */
  ELEVATION_POSITION_REACHED: "EL POSITION REACHED",
  AZIMUTH_POSITION_REACHED: "AZ POSITION REACHED",

  /* Homing */
  HOMING_IN_PROGRESS: "HOMING IN PROGRESS",
  HOMING_COMPLETED: "HOMING COMPLETED",

  /* LOS */
  LOS_IN_PROGRESS: "LOS MODE IN PROGRESS",
  LOS_COMPLETED: "LOS MODE COMPLETED",

  /* Auto Stow */
  AUTO_STOW_IN_PROGRESS: "AUTO STOW MODE IN PROGRESS",
  AUTO_STOW_POSITION_REACHED: "AUTO STOW POSITION REACHED",

  /* Target Azimuth / Elevation movement */
  AZIMUTH_POSITION_IN_PROGRESS: "AZ POSITION MODE IN PROGRESS",
  ELEVATION_POSITION_IN_PROGRESS: "EL POSITION MODE IN PROGRESS",
  AZIMUTH_POSITION_REACHED_END: "AZ POSITION REACHED",
  ELEVATION_POSITION_REACHED_END: "EL POSITION REACHED",
};

const OPERATION_MESSAGES = {
  up: {
    started: OPERATION_ACK.UP_STARTED,
    completed: OPERATION_ACK.ELEVATION_POSITION_REACHED,
    stopped: OPERATION_ACK.UP_STOPPED,
    failed: "EL MANUAL UP FAILED",
  },

  down: {
    started: OPERATION_ACK.DOWN_STARTED,
    completed: OPERATION_ACK.ELEVATION_POSITION_REACHED,
    stopped: OPERATION_ACK.DOWN_STOPPED,
    failed: "EL MANUAL DOWN FAILED",
  },

  cw: {
    started: OPERATION_ACK.CW_STARTED,
    completed: OPERATION_ACK.AZIMUTH_POSITION_REACHED,
    stopped: OPERATION_ACK.CW_STOPPED,
    failed: "AZ MANUAL CW FAILED",
  },

  ccw: {
    started: OPERATION_ACK.CCW_STARTED,
    completed: OPERATION_ACK.AZIMUTH_POSITION_REACHED,
    stopped: OPERATION_ACK.CCW_STOPPED,
    failed: "AZ MANUAL CCW FAILED",
  },

  homing: {
    started: OPERATION_ACK.HOMING_IN_PROGRESS,
    completed: OPERATION_ACK.HOMING_COMPLETED,
    stopped: "HOMING MODE STOP",
    failed: "HOMING MODE FAILED",
  },

  los: {
    started: OPERATION_ACK.LOS_IN_PROGRESS,
    completed: OPERATION_ACK.LOS_COMPLETED,
    stopped: "LOS MODE STOP",
    failed: "LOS MODE FAILED",
  },

  autostow: {
    started: OPERATION_ACK.AUTO_STOW_IN_PROGRESS,
    completed: OPERATION_ACK.AUTO_STOW_POSITION_REACHED,
    stopped: "AUTO STOW MODE STOP",
    failed: "AUTO STOW MODE FAILED",
  },

  azimuth: {
    started: OPERATION_ACK.AZIMUTH_POSITION_IN_PROGRESS,
    completed: OPERATION_ACK.AZIMUTH_POSITION_REACHED,
    stopped: OPERATION_ACK.AZIMUTH_POSITION_REACHED,
    failed: "AZ POSITION MOVEMENT FAILED",
  },

  elevation: {
    started: OPERATION_ACK.ELEVATION_POSITION_IN_PROGRESS,
    completed: OPERATION_ACK.ELEVATION_POSITION_REACHED,
    stopped: OPERATION_ACK.ELEVATION_POSITION_REACHED,
    failed: "EL POSITION MOVEMENT FAILED",
  },
};
const SPEED_OPTIONS = [
  {
    value: "01",
    label: "0.1 deg/sec",
  },
  {
    value: "02",
    label: "0.5 deg/sec",
  },
  {
    value: "03",
    label: "7 deg/sec",
  },
  {
    value: "04",
    label: "15 deg/sec",
  },
];
const CONFIRM_MESSAGES = {
  homing: "Are you sure you want to perform Homing?",
  los: "Are you sure you want to perform LOS?",
  auto_stow: "Are you sure you want to perform Auto Stow?",

  up: "Are you sure you want to move the antenna Up?",
  down: "Are you sure you want to move the antenna Down?",
  cw: "Are you sure you want to rotate the antenna clockwise (CW)?",
  ccw: "Are you sure you want to rotate the antenna counterclockwise (CCW)?",

  azimuth:
    "Are you sure you want to move the antenna to the selected Azimuth position?",
  elevation:
    "Are you sure you want to move the antenna to the selected Elevation position?",
};

const AntpConfiguration = ({ node }) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);
  const [confirmMessage, setConfirmMessage] = useState("");

  const resourceId = node?.resourceId;

  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  // const [elements, setElements] = useState({});

  const [disabledButton, setDisabledButton] = useState(false);

  const [currentBtn, setCurrentBtn] = useState("");
  const [movementLoading, setMovementLoading] = useState(false);
  const [activeMovement, setActiveMovement] = useState(null);
  const [activeOperation, setActiveOperation] = useState(null);
  const activeOperationRef = useRef(null);
  const completionHandledRef = useRef(false);
  const pollTimeoutRef = useRef(null);
  const isMountedRef = useRef(false);
  const [configurationLoading, setConfigurationLoading] = useState(false);
  const [azele, setAzele] = useState({
    azimuth: "",
    elevation: "",
  });
  const [stopBtnDetails, setStopBtnDetails] = useState({
    disable: true,
  });

  const [antennaStatus, setAntennaStatus] = useState({
    message: "Ready",
  });
  const [localEdit, setLocalEdit] = useState(false);

  const [remoteEdit, setRemoteEdit] = useState(false);
  const [localDataArr, setLocalDataArr] = useState(Array(10).fill(""));

  const [remoteDataArr, setRemoteDataArr] = useState(Array(9).fill(""));
  const [targetAzimuth, setTargetAzimuth] = useState("");

  const [targetElevation, setTargetElevation] = useState("");
  const [speed, setSpeed] = useState("");

  const [autoStowAzimuth, setAutoStowAzimuth] = useState("");
  const [autoStowElevation, setAutoStowElevation] = useState("");
  const [targetErrors, setTargetErrors] = useState({
    azimuth: "",
    elevation: "",
  });
  const [autoStowErrors, setAutoStowErrors] = useState({
    azimuth: "",
    elevation: "",
  });

  const [localErrors, setLocalErrors] = useState({});

  const [remoteErrors, setRemoteErrors] = useState({});
  const siteId = node?.siteId;
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const openConfirmation = (action, message) => {
    setPendingAction(action);
    setConfirmMessage(message);
    setShowConfirm(true);
  };

  const handleConfirmAction = async () => {
    const action = pendingAction;

    setShowConfirm(false);
    setPendingAction(null);
    setConfirmMessage("");

    if (!action) {
      return;
    }

    if (["up", "down", "cw", "ccw"].includes(action)) {
      await handleMovementClick(action);
      return;
    }

    if (["azimuth", "elevation"].includes(action)) {
      await handleTargetMovement(action);
      return;
    }

    if (["homing", "los", "auto_stow"].includes(action)) {
      await handleButtonClick(action);
    }
  };

  const handleCancelConfirmation = () => {
    setShowConfirm(false);
    setPendingAction(null);
    setConfirmMessage("");
  };
  const POSITION_TOLERANCE = 0.2;
  const getSpeedCodeFromResponse = (responseSpeed) => {
    if (!responseSpeed) {
      return "";
    }

    const speedMap = {
      "0.1 deg/sec": "01",
      "0.5 deg/sec": "02",
      "7 deg/sec": "03",
      "15 deg/sec": "04",
    };

    return speedMap[String(responseSpeed).trim()] || "";
  };
  const movementConfig = useMemo(
    () => ({
      up: {
        endpoint: isCnms
          ? SAVE_ELEVATION_MOVEMENT_CNMS
          : SAVE_ELEVATION_MOVEMENT,
        startAction: "UP_START",
        stopAction: "UP_STOP",
        label: "Up",
      },

      down: {
        endpoint: isCnms
          ? SAVE_ELEVATION_MOVEMENT_CNMS
          : SAVE_ELEVATION_MOVEMENT,
        startAction: "DOWN_START",
        stopAction: "DOWN_STOP",
        label: "Down",
      },

      cw: {
        endpoint: isCnms ? SAVE_AZIMUTH_MOVEMENT_CNMS : SAVE_AZIMUTH_MOVEMENT,
        startAction: "CW_START",
        stopAction: "CW_STOP",
        label: "CW",
      },

      ccw: {
        endpoint: isCnms ? SAVE_AZIMUTH_MOVEMENT_CNMS : SAVE_AZIMUTH_MOVEMENT,
        startAction: "CCW_START",
        stopAction: "CCW_STOP",
        label: "CCW",
      },
    }),
    []
  );

  const azimuthWidgetConfig = useMemo(
    () => ({
      gridTitle: "Azimuth",
      minVal: -180,
      maxVal: 180,
      unit: "Deg",
      innerRange: 10,
      data: [
        {
          currentValue: Number(azele.azimuth) || 0,
        },
      ],
    }),
    [azele.azimuth]
  );

  const elevationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Elevation",
      minVal: -15,
      maxVal: 15,
      unit: "Deg",
      innerRange: 14,
      data: [
        {
          currentValue: Number(azele.elevation) || 0,
        },
      ],
    }),
    [azele.elevation]
  );

  const INTEGER_INPUT_REGEX = /^\d*$/;

  const DECIMAL_INPUT_REGEX = /^\d*(?:\.\d{0,3})?$/;

  const LONGITUDE_DEG_REGEX = /^(?:\d|[1-9]\d|1[0-7]\d|180)$/;

  const LATITUDE_DEG_REGEX = /^(?:\d|[1-8]\d|90)$/;

  const MINUTE_REGEX = /^(?:[0-5]?\d)$/;

  // const SECOND_REGEX = /^(?:[0-5]?\d)(?:\.\d{0,3})?$/;
  const SECOND_REGEX = /^(?:(?:[0-5]?\d)(?:\.\d{0,3})?)?$/;

  const HEADING_REGEX = /^(?:\d|[1-9]\d|[12]\d{2}|3[0-5]\d|360)(?:\.\d{1,3})?$/;

  const ALTITUDE_REGEX = /^(?:\d{1,4})(?:\.\d{1,3})?$/;

  const TARGET_ANGLE_REGEX = /^-?\d{0,3}(?:\.\d{0,3})?$/;

  const isEmpty = (value) => {
    return value === undefined || value === null || String(value).trim() === "";
  };

  const sanitizeInput = (value, regex, maxLength) => {
    let sanitizedValue = value;

    if (maxLength && sanitizedValue.length > maxLength) {
      sanitizedValue = sanitizedValue.slice(0, maxLength);
    }

    if (!regex.test(sanitizedValue)) {
      return null;
    }

    return sanitizedValue;
  };

  const isWithinTolerance = (value, target, tolerance = POSITION_TOLERANCE) => {
    const numericValue = Number(value);

    const numericTarget = Number(target);

    if (!Number.isFinite(numericValue) || !Number.isFinite(numericTarget)) {
      return false;
    }

    return Math.abs(numericValue - numericTarget) <= tolerance;
  };

  // const isNearZero = (value) => {
  //   return isWithinTolerance(value, 0);
  // };

  const validateLongitude = (data) => {
    const errors = {};

    const longitudeDeg = String(data[0] ?? "").trim();

    const longitudeMin = String(data[1] ?? "").trim();

    const longitudeSec = String(data[2] ?? "").trim();

    const longitudeDir = String(data[3] ?? "").trim();

    if (isEmpty(longitudeDeg)) {
      errors[0] = "Longitude degree is required";
    } else if (!LONGITUDE_DEG_REGEX.test(longitudeDeg)) {
      errors[0] = "Enter degree between 0 and 180";
    }

    if (isEmpty(longitudeMin)) {
      errors[1] = "Longitude minute is required";
    } else if (!MINUTE_REGEX.test(longitudeMin)) {
      errors[1] = "Enter minute between 0 and 59";
    }

    if (isEmpty(longitudeSec)) {
      errors[2] = "Longitude second is required";
    } else if (!SECOND_REGEX.test(longitudeSec)) {
      errors[2] = "Enter seconds between 0 and 59.999";
    }

    if (isEmpty(longitudeDir)) {
      errors[3] = "Select longitude direction";
    } else if (!["E", "W"].includes(longitudeDir)) {
      errors[3] = "Invalid longitude direction";
    }

    if (
      longitudeDeg === "180" &&
      (!isEmpty(longitudeMin) || !isEmpty(longitudeSec))
    ) {
      const min = Number(longitudeMin || 0);

      const sec = Number(longitudeSec || 0);

      if (min !== 0 || sec !== 0) {
        errors[0] = "For 180°, minutes and seconds must be 0";

        errors[1] = "Must be 0 when degree is 180";

        errors[2] = "Must be 0 when degree is 180";
      }
    }

    return errors;
  };

  const validateLatitude = (data, startIndex = 4) => {
    const errors = {};

    const latitudeDeg = String(data[startIndex] ?? "").trim();

    const latitudeMin = String(data[startIndex + 1] ?? "").trim();

    const latitudeSec = String(data[startIndex + 2] ?? "").trim();

    const latitudeDir = String(data[startIndex + 3] ?? "").trim();

    if (isEmpty(latitudeDeg)) {
      errors[startIndex] = "Latitude degree is required";
    } else if (!LATITUDE_DEG_REGEX.test(latitudeDeg)) {
      errors[startIndex] = "Enter degree between 0 and 90";
    }

    if (isEmpty(latitudeMin)) {
      errors[startIndex + 1] = "Latitude minute is required";
    } else if (!MINUTE_REGEX.test(latitudeMin)) {
      errors[startIndex + 1] = "Enter minute between 0 and 59";
    }

    if (isEmpty(latitudeSec)) {
      errors[startIndex + 2] = "Latitude second is required";
    } else if (!SECOND_REGEX.test(latitudeSec)) {
      errors[startIndex + 2] = "Enter seconds between 0 and 59.999";
    }

    if (isEmpty(latitudeDir)) {
      errors[startIndex + 3] = "Select latitude direction";
    } else if (!["N", "S"].includes(latitudeDir)) {
      errors[startIndex + 3] = "Invalid latitude direction";
    }

    if (
      latitudeDeg === "90" &&
      (!isEmpty(latitudeMin) || !isEmpty(latitudeSec))
    ) {
      const min = Number(latitudeMin || 0);

      const sec = Number(latitudeSec || 0);

      if (min !== 0 || sec !== 0) {
        errors[startIndex] = "For 90°, minutes and seconds must be 0";

        errors[startIndex + 1] = "Must be 0 when degree is 90";

        errors[startIndex + 2] = "Must be 0 when degree is 90";
      }
    }

    return errors;
  };

  const validateHeading = (value) => {
    const heading = String(value ?? "").trim();

    if (isEmpty(heading)) {
      return "Vehicle heading is required";
    }

    if (!HEADING_REGEX.test(heading)) {
      return "Enter heading between 0 and 360";
    }

    const numericHeading = Number(heading);

    if (
      !Number.isFinite(numericHeading) ||
      numericHeading < 0 ||
      numericHeading > 360
    ) {
      return "Heading must be between 0 and 360";
    }

    return "";
  };

  const validateAltitude = (value) => {
    const altitude = String(value ?? "").trim();

    if (isEmpty(altitude)) {
      return "Altitude is required";
    }

    if (!ALTITUDE_REGEX.test(altitude)) {
      return "Enter altitude between 0 and 9999";
    }

    const numericAltitude = Number(altitude);

    if (
      !Number.isFinite(numericAltitude) ||
      numericAltitude < 0 ||
      numericAltitude > 9999
    ) {
      return "Altitude must be between 0 and 9999";
    }

    return "";
  };

  const validateLocalData = (data) => {
    const errors = {
      ...validateLongitude(data),
      ...validateLatitude(data, 4),
    };

    const headingError = validateHeading(data[8]);

    const altitudeError = validateAltitude(data[9]);

    if (headingError) {
      errors[8] = headingError;
    }

    if (altitudeError) {
      errors[9] = altitudeError;
    }

    return errors;
  };

  const validateRemoteData = (data) => {
    const errors = {
      ...validateLongitude(data),
      ...validateLatitude(data, 4),
    };

    const altitudeError = validateAltitude(data[8]);

    if (altitudeError) {
      errors[8] = altitudeError;
    }

    return errors;
  };

  const validateTargetAzimuth = (value) => {
    const azimuth = String(value ?? "").trim();

    if (isEmpty(azimuth)) {
      return "Azimuth is required";
    }

    if (!TARGET_ANGLE_REGEX.test(azimuth)) {
      return "Enter azimuth between -180 and 180";
    }

    const numericAzimuth = Number(azimuth);

    if (
      !Number.isFinite(numericAzimuth) ||
      numericAzimuth < -180 ||
      numericAzimuth > 180
    ) {
      return "Azimuth must be between -180 and 180";
    }

    return "";
  };

  const validateTargetElevation = (value) => {
    const elevation = String(value ?? "").trim();

    if (isEmpty(elevation)) {
      return "Elevation is required";
    }

    if (!TARGET_ANGLE_REGEX.test(elevation)) {
      return "Enter elevation between -15 and 15";
    }

    const numericElevation = Number(elevation);

    if (
      !Number.isFinite(numericElevation) ||
      numericElevation < -15 ||
      numericElevation > 15
    ) {
      return "Elevation must be between -15 and 15";
    }

    return "";
  };

  const validateLocalBeforeSave = () => {
    const errors = validateLocalData(localDataArr);

    setLocalErrors(errors);

    if (Object.keys(errors).length > 0) {
      Toast(
        "Warning",
        "Please correct the Local Site validation errors",
        "warning"
      );

      return false;
    }

    return true;
  };

  const validateRemoteBeforeSave = () => {
    const errors = validateRemoteData(remoteDataArr);

    setRemoteErrors(errors);

    if (Object.keys(errors).length > 0) {
      Toast(
        "Warning",
        "Please correct the Remote Site validation errors",
        "warning"
      );

      return false;
    }

    return true;
  };
  const validateAutoStowAzimuth = (value) => {
    const azimuth = String(value ?? "").trim();

    if (isEmpty(azimuth)) {
      return "Azimuth stow angle is required";
    }

    if (!TARGET_ANGLE_REGEX.test(azimuth)) {
      return "Enter azimuth between -180 and 180";
    }

    const numericAzimuth = Number(azimuth);

    if (
      !Number.isFinite(numericAzimuth) ||
      numericAzimuth < -180 ||
      numericAzimuth > 180
    ) {
      return "Azimuth stow must be between -180 and 180";
    }

    return "";
  };

  const validateAutoStowElevation = (value) => {
    const elevation = String(value ?? "").trim();

    if (isEmpty(elevation)) {
      return "Elevation stow angle is required";
    }

    if (!TARGET_ANGLE_REGEX.test(elevation)) {
      return "Enter elevation between -15 and 15";
    }

    const numericElevation = Number(elevation);

    if (
      !Number.isFinite(numericElevation) ||
      numericElevation < -15 ||
      numericElevation > 15
    ) {
      return "Elevation stow must be between -15 and 15";
    }

    return "";
  };
  const fetchStatus = async () => {
    if (!resourceId) {
      return;
    }

    // const fullUrl = `${GET_STATUS_FOR_CONFIGURATION}/${resourceId}`;
    const fullUrl = `${
      isCnms ? GET_STATUS_FOR_CONFIGURATION_CNMS : GET_STATUS_FOR_CONFIGURATION
    }/${resourceId}`;

    try {
      setConfigurationLoading(true);

      const response = await ConfigurationAxios(
        fullUrl,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId) } : {}
      );

      const responseBody = response?.data;

      if (responseBody && responseBody.status === 1 && responseBody.data) {
        const data = responseBody.data;

        // setElements(data);

        setAzele({
          azimuth: data.azimuth ?? "",
          elevation: data.elevation ?? "",
        });
        setTargetAzimuth(data.azimuth ?? "");
        setTargetElevation(data.elevation ?? "");

        setSpeed(getSpeedCodeFromResponse(data.velocity));
        // setSpeed(getSpeedCodeFromResponse("15 deg/sec"));

        setAutoStowAzimuth(data.autoStowAzimuthAngle ?? "");
        setAutoStowElevation(data.autoStowElevationAngle ?? "");

        const newLocalArr = [
          data.stationLongDeg ?? "",
          data.stationLongMin ?? "",
          data.stationLongSec ?? "",
          data.stationLongHemi ?? "",

          data.stationLatDeg ?? "",
          data.stationLatMin ?? "",
          data.stationLatSec ?? "",
          data.stationLatHemi ?? "",

          data.heading ?? "",
          data.stationAltitude ?? "",
        ];

        setLocalDataArr(newLocalArr);

        const newRemoteArr = [
          data.targetLongDeg ?? "",
          data.targetLongMin ?? "",
          data.targetLongSec ?? "",
          data.targetLongHemi ?? "",

          data.targetLatDeg ?? "",
          data.targetLatMin ?? "",
          data.targetLatSec ?? "",
          data.targetLatHemi ?? "",

          data.targetAltitude ?? "",
        ];

        setRemoteDataArr(newRemoteArr);

        setLocalErrors({});
        setRemoteErrors({});

        setAntennaStatus({
          message: "Ready",
        });
      } else {
        Toast(
          "Error",
          responseBody?.message || "Failed to fetch configuration",
          "error"
        );
      }
    } catch (error) {
      console.error("Configuration status error:", error);

      Toast("Error", "Failed to fetch configuration", "error");
    } finally {
      setConfigurationLoading(false);
    }
  };

  const fetchCurrentAzEl = async (operation) => {
    if (!resourceId || !isMountedRef.current || !operation) {
      return null;
    }

    const actionTypeMap = {
      homing: "homing",
      los: "los",
      autostow: "autostow",

      up: "azimuth",
      down: "azimuth",
      cw: "azimuth",
      ccw: "azimuth",

      azimuth: "azimuth",
      elevation: "elevation",
    };

    const actionType = actionTypeMap[operation] || "azimuth";
    const basePath = isCnms ? FETCH_CURRENT_AZ_EL_CNMS : FETCH_CURRENT_AZ_EL;

    const fullUrl =
      // `${FETCH_CURRENT_AZ_EL}/${resourceId}` +
      `${basePath}/${resourceId}` +
      `?actionType=${encodeURIComponent(actionType)}`;

    try {
      const response = await ConfigurationAxios(
        fullUrl,
        isCnms ? "post" : "get",
        isCnms ? { siteId: String(siteId), actionType: actionType } : {}
      );

      if (!isMountedRef.current) {
        return null;
      }

      const responseBody = response?.data;

      if (responseBody?.status === 1 && responseBody?.data) {
        const {
          azimuth,
          elevation,
          autoStowAzimuthAngle,
          autoStowElevationAngle,
          operationAck,
        } = responseBody.data;

        setAzele({
          azimuth: azimuth ?? "",
          elevation: elevation ?? "",
        });
        if (operationAck) {
          setAntennaStatus({
            message: String(operationAck).trim(),
          });
        }

        return {
          azimuth,
          elevation,
          autoStowAzimuthAngle,
          autoStowElevationAngle,
          operationAck,
        };
      }

      console.warn("Failed to fetch Current Az/El:", responseBody?.message);

      return null;
    } catch (error) {
      console.error("Fetch Current Az/El Error:", error);
      return null;
    }
  };

  useEffect(() => {
    if (!resourceId) {
      return;
    }

    isMountedRef.current = true;

    fetchStatus();

    return () => {
      isMountedRef.current = false;

      if (pollTimeoutRef.current) {
        clearTimeout(pollTimeoutRef.current);

        pollTimeoutRef.current = null;
      }

      activeOperationRef.current = null;

      completionHandledRef.current = false;
    };
  }, [resourceId]);

  const getOperationLabel = (operation) => {
    switch (operation) {
      case "up":
        return "Up";

      case "down":
        return "Down";

      case "cw":
        return "CW";

      case "ccw":
        return "CCW";

      case "homing":
        return "Homing";

      case "los":
        return "LOS";

      case "autostow":
        return "Auto Stow";

      case "azimuth":
        return "Azimuth";

      case "elevation":
        return "Elevation";

      default:
        return "Ready";
    }
  };

  const stopPolling = () => {
    if (pollTimeoutRef.current) {
      clearTimeout(pollTimeoutRef.current);

      pollTimeoutRef.current = null;
    }
  };

  const clearMovementOperation = () => {
    stopPolling();
    activeOperationRef.current = null;
    completionHandledRef.current = false;
    setActiveOperation(null);

    setActiveMovement(null);
  };

  const checkOperationCompletion = (operation, result) => {
    if (!operation || !result) {
      return false;
    }

    const operationAck = String(result.operationAck ?? "")
      .trim()
      .toUpperCase();

    if (!operationAck) {
      return false;
    }

    switch (operation) {
      case "up":
        return [
          OPERATION_ACK.UP_STOPPED,
          OPERATION_ACK.ELEVATION_POSITION_REACHED,
        ].includes(operationAck);

      case "down":
        return [
          OPERATION_ACK.DOWN_STOPPED,
          OPERATION_ACK.ELEVATION_POSITION_REACHED,
        ].includes(operationAck);

      case "cw":
        return [
          OPERATION_ACK.CW_STOPPED,
          OPERATION_ACK.AZIMUTH_POSITION_REACHED,
        ].includes(operationAck);

      case "ccw":
        return [
          OPERATION_ACK.CCW_STOPPED,
          OPERATION_ACK.AZIMUTH_POSITION_REACHED,
        ].includes(operationAck);
      case "homing":
        return operationAck === OPERATION_ACK.HOMING_COMPLETED;

      case "los":
        return operationAck === OPERATION_ACK.LOS_COMPLETED;

      case "autostow":
        return operationAck === OPERATION_ACK.AUTO_STOW_POSITION_REACHED;

      case "azimuth":
        return operationAck === OPERATION_ACK.AZIMUTH_POSITION_REACHED;

      case "elevation":
        return operationAck === OPERATION_ACK.ELEVATION_POSITION_REACHED;

      default:
        return false;
    }
  };

  const getCompletionMessage = (operation, result) => {
    const operationAck = String(result?.operationAck ?? "").trim();

    if (operationAck) {
      return operationAck;
    }

    return (
      OPERATION_MESSAGES[operation]?.completed ||
      `${getOperationLabel(operation)} completed`
    );
  };

  const completeOperation = async (operation, result) => {
    if (!operation) {
      return;
    }

    if (completionHandledRef.current) {
      return;
    }

    completionHandledRef.current = true;

    stopPolling();

    const completedMessage = getCompletionMessage(operation, result);

    setAntennaStatus({
      message: completedMessage,
    });

    /*
     * Clear active operation.
     */
    activeOperationRef.current = null;

    setActiveOperation(null);
    setActiveMovement(null);
    setCurrentBtn("");
    setMovementLoading(false);

    /*
     * Put antenna into Standby after physical operation.
     */
    if (
      ["homing", "los", "autostow", "up", "down", "cw", "ccw"].includes(
        operation
      )
    ) {
      await performStandByMode();
    }

    await new Promise((resolve) => setTimeout(resolve, 1000));

    if (isMountedRef.current) {
      await refreshFinalPosition(operation);
    }

    Toast("Success", completedMessage, "success");
  };

  const performStandByMode = async () => {
    if (!resourceId) {
      return false;
    }
    const basePath = isCnms
      ? PERFORM_STAND_BY_MODE_CNMS
      : PERFORM_STAND_BY_MODE;

    const fullUrl = `${basePath}/${resourceId}`;

    try {
      // const response = await ConfigurationAxios(fullUrl, "post", {});

      const response = await ConfigurationAxios(
        fullUrl,
        "post",
        isCnms ? { siteId: String(siteId) } : {}
      );

      const responseBody = response?.data;

      if (responseBody?.status !== 1) {
        throw new Error(
          responseBody?.message || "Failed to perform Standby Mode"
        );
      }

      return true;
    } catch (error) {
      console.error("Standby Mode API Error:", error);

      Toast(
        "Error",
        error?.message || "Failed to perform Standby Mode",
        "error"
      );

      return false;
    }
  };

  const startPolling = (operation) => {
    stopPolling();
    completionHandledRef.current = false;
    activeOperationRef.current = operation;

    setActiveOperation(operation);
    const poll = async () => {
      if (!isMountedRef.current) {
        return;
      }

      const currentOperation = activeOperationRef.current;

      if (!currentOperation) {
        stopPolling();

        return;
      }

      const result = await fetchCurrentAzEl(currentOperation);

      if (
        !isMountedRef.current ||
        activeOperationRef.current !== currentOperation
      ) {
        return;
      }

      if (result) {
        const completed = checkOperationCompletion(currentOperation, result);

        if (completed) {
          await completeOperation(currentOperation, result);

          return;
        }
      }
      if (activeOperationRef.current === currentOperation) {
        pollTimeoutRef.current = setTimeout(poll, 1000);
      }
    };

    poll();
  };

  const handleMovementClick = async (movementKey) => {
    const config = movementConfig[movementKey];

    if (!config) {
      Toast("Error", "Invalid movement command", "error");

      return;
    }
    if (movementLoading) {
      return;
    }
    if (
      activeOperationRef.current &&
      activeOperationRef.current !== movementKey
    ) {
      const activeLabel = getOperationLabel(activeOperationRef.current);

      Toast(
        "Warning",
        `Please wait for ${activeLabel} operation to complete`,
        "warning"
      );

      return;
    }

    const isStopping = activeMovement === movementKey;

    const actionType = isStopping ? config.stopAction : config.startAction;

    const fullUrl =
      `${config.endpoint}/${resourceId}` +
      `?actionType=${encodeURIComponent(actionType)}`;

    setMovementLoading(true);

    setCurrentBtn(movementKey);

    try {
      // const response = await ConfigurationAxios(fullUrl, "post", {});
      const response = await ConfigurationAxios(
        fullUrl,
        "post",
        isCnms ? { siteId: String(siteId), actionType: actionType } : {}
      );
      const responseBody = response?.data;

      if (responseBody?.status !== 1) {
        throw new Error(
          responseBody?.message ||
            `Failed to ${isStopping ? "stop" : "start"} ${
              config.label
            } movement`
        );
      }

      if (isStopping) {
        clearMovementOperation();

        setAntennaStatus({
          message:
            OPERATION_MESSAGES[movementKey]?.stopped ||
            `${config.label} movement stopped`,
        });

        await refreshFinalPosition(movementKey);

        Toast("Success", `${config.label} movement stopped`, "success");

        return;
      }

      setActiveMovement(movementKey);

      setAntennaStatus({
        message:
          OPERATION_MESSAGES[movementKey]?.started ||
          `${config.label} movement in progress`,
      });
      startPolling(movementKey);
    } catch (error) {
      console.error("Movement API Error:", error);
      stopPolling();

      activeOperationRef.current = null;

      setActiveOperation(null);

      setActiveMovement(null);

      setAntennaStatus({
        message:
          OPERATION_MESSAGES[movementKey]?.failed ||
          `${config.label} movement failed`,
      });

      Toast(
        "Error",
        error?.message ||
          `Failed to ${isStopping ? "stop" : "start"} ${config.label} movement`,
        "error"
      );
    } finally {
      setMovementLoading(false);

      setCurrentBtn("");
    }
  };

  const handleTargetMovement = async (type) => {
    /*
     * Prevent another operation.
     */
    if (activeOperationRef.current || movementLoading || disabledButton) {
      if (activeOperationRef.current) {
        Toast(
          "Warning",
          `Please wait for ${getOperationLabel(
            activeOperationRef.current
          )} operation to complete`,
          "warning"
        );
      }

      return;
    }

    let value;

    let validationError;

    if (type === "azimuth") {
      value = targetAzimuth;

      validationError = validateTargetAzimuth(value);

      setTargetErrors((prev) => ({
        ...prev,
        azimuth: validationError,
      }));
    } else if (type === "elevation") {
      value = targetElevation;

      validationError = validateTargetElevation(value);

      setTargetErrors((prev) => ({
        ...prev,
        elevation: validationError,
      }));
    } else {
      Toast("Error", "Invalid target movement type", "error");

      return;
    }

    if (validationError) {
      Toast("Warning", validationError, "warning");

      return;
    }
    const basePath = isCnms
      ? GO_TO_AZIMUTH_ELEVATION_POSITION_CNMS
      : GO_TO_AZIMUTH_ELEVATION_POSITION;

    const fullUrl =
      `${basePath}/${resourceId}` + `?actionType=${encodeURIComponent(type)}`;
    // const fullUrl =
    //   `${GO_TO_AZIMUTH_ELEVATION_POSITION}/${resourceId}` +
    //   `?actionType=${encodeURIComponent(type)}`;

    const sendData =
      type === "azimuth"
        ? {
            azimuth: Number(value),
          }
        : {
            elevation: Number(value),
          };

    setMovementLoading(true);

    setCurrentBtn(type);

    try {
      // const response = await ConfigurationAxios(fullUrl, "post", sendData);
      const response = await ConfigurationAxios(fullUrl, "post", {
        ...sendData,
        ...(isCnms && { siteId: String(siteId), actionType: type }),
      });

      const responseBody = response?.data;

      if (responseBody?.status !== 1) {
        throw new Error(
          responseBody?.message || `Failed to move ${getOperationLabel(type)}`
        );
      }

      setAntennaStatus({
        message:
          OPERATION_MESSAGES[type]?.started ||
          `${getOperationLabel(type)} movement in progress`,
      });

      /*
       * Target movement completion is still operationAck based.
       */
      startPolling(type);
    } catch (error) {
      console.error(`${getOperationLabel(type)} Movement API Error:`, error);

      setAntennaStatus({
        message:
          OPERATION_MESSAGES[type]?.failed ||
          `${getOperationLabel(type)} movement failed`,
      });

      Toast(
        "Error",
        error?.message || `Failed to move ${getOperationLabel(type)}`,
        "error"
      );
    } finally {
      setMovementLoading(false);

      setCurrentBtn("");
    }
  };
  const handleSpeedChange = async () => {
    if (activeOperationRef.current || movementLoading || disabledButton) {
      if (activeOperationRef.current) {
        Toast(
          "Warning",
          `Please wait for ${getOperationLabel(
            activeOperationRef.current
          )} operation to complete`,
          "warning"
        );
      }

      return;
    }

    if (!speed) {
      Toast("Warning", "Please select a speed", "warning");
      return;
    }
    const basePath = isCnms
      ? GO_TO_AZIMUTH_ELEVATION_POSITION_CNMS
      : GO_TO_AZIMUTH_ELEVATION_POSITION;

    const fullUrl = `${basePath}/${resourceId}?actionType=speed`;
    // const fullUrl =
    //   `${GO_TO_AZIMUTH_ELEVATION_POSITION}/${resourceId}` + `?actionType=speed`;

    const sendData = {
      velocity: speed,
    };

    setMovementLoading(true);
    setCurrentBtn("speed");

    try {
      // const response = await ConfigurationAxios(fullUrl, "post", sendData);
      const response = await ConfigurationAxios(fullUrl, "post", {
        ...sendData,
        ...(isCnms && { siteId: String(siteId), actionType: "speed" }),
      });

      const responseBody = response?.data;

      if (responseBody?.status !== 1) {
        throw new Error(responseBody?.message || "Failed to set speed");
      }

      setAntennaStatus({
        message: "Speed setting completed",
      });

      Toast("Success", "Speed updated successfully", "success");
    } catch (error) {
      console.error("Speed API Error:", error);

      setAntennaStatus({
        message: "SPEED SETTING FAILED",
      });

      Toast("Error", error?.message || "Failed to set speed", "error");
    } finally {
      setMovementLoading(false);
      setCurrentBtn("");
    }
  };
  const handleSetAutoStow = async () => {
    if (activeOperationRef.current || movementLoading || disabledButton) {
      if (activeOperationRef.current) {
        Toast(
          "Warning",
          `Please wait for ${getOperationLabel(
            activeOperationRef.current
          )} operation to complete`,
          "warning"
        );
      }

      return;
    }

    const azimuthError = validateAutoStowAzimuth(autoStowAzimuth);
    const elevationError = validateAutoStowElevation(autoStowElevation);

    setAutoStowErrors({
      azimuth: azimuthError,
      elevation: elevationError,
    });

    if (azimuthError || elevationError) {
      Toast(
        "Warning",
        "Please correct the Auto Stow angle validation errors",
        "warning"
      );

      return;
    }

    // const fullUrl =
    //   `${GO_TO_AZIMUTH_ELEVATION_POSITION}/${resourceId}` +
    //   `?actionType=setautostowangle`;
    const basePath = isCnms
      ? GO_TO_AZIMUTH_ELEVATION_POSITION_CNMS
      : GO_TO_AZIMUTH_ELEVATION_POSITION;

    const fullUrl =
      `${basePath}/${resourceId}` + `?actionType=setautostowangle`;
    const sendData = {
      autoStowAzimuthAngle: autoStowAzimuth,
      autoStowElevationAngle: autoStowElevation,
    };

    setMovementLoading(true);
    setCurrentBtn("setAutoStow");

    try {
      // const response = await ConfigurationAxios(fullUrl, "post", sendData);
      const response = await ConfigurationAxios(fullUrl, "post", {
        ...sendData,
        ...(isCnms && {
          siteId: String(siteId),
          actionType: "setautostowangle",
        }),
      });
      const responseBody = response?.data;

      if (responseBody?.status !== 1) {
        throw new Error(
          responseBody?.message || "Failed to set Auto Stow angles"
        );
      }

      setAntennaStatus({
        message: "AUTO STOW ANGLES UPDATED",
      });

      Toast("Success", "Auto Stow angles updated successfully", "success");
    } catch (error) {
      console.error("Auto Stow Angle API Error:", error);

      setAntennaStatus({
        message: "AUTO STOW ANGLE SETTING FAILED",
      });

      Toast(
        "Error",
        error?.message || "Failed to set Auto Stow angles",
        "error"
      );
    } finally {
      setMovementLoading(false);
      setCurrentBtn("");
    }
  };

  const handleButtonClick = async (key, dataPayload) => {
    /*
     * Any physical operation running?
     */
    if (activeOperationRef.current) {
      const currentOperation = activeOperationRef.current;

      const label = getOperationLabel(currentOperation);

      Toast(
        "Warning",
        `Please wait for ${label} operation to complete`,
        "warning"
      );

      return;
    }

    /*
     * Local validation.
     */
    if (key === "loadLocal") {
      const valid = validateLocalBeforeSave();

      if (!valid) {
        return;
      }
    }

    /*
     * Remote validation.
     */
    if (key === "remoteSet") {
      const valid = validateRemoteBeforeSave();

      if (!valid) {
        return;
      }
    }

    let fullUrl;

    let sendData;

    setDisabledButton(true);

    setCurrentBtn(key);

    try {
      switch (key) {
        /* -------------------------------------------------
         * LOAD LOCAL
         * ------------------------------------------------- */

        case "loadLocal": {
          const basePath = isCnms ? SAVE_MANUAL_GPS_CNMS : SAVE_MANUAL_GPS;
          fullUrl = `${basePath}/${resourceId}`;
          // fullUrl = `${SAVE_MANUAL_GPS}/${resourceId}`;

          sendData = {
            stationLongDeg: dataPayload[0],
            stationLongMin: dataPayload[1],
            stationLongSec: dataPayload[2],
            stationLongHemi: dataPayload[3],

            stationLatDeg: dataPayload[4],
            stationLatMin: dataPayload[5],
            stationLatSec: dataPayload[6],
            stationLatHemi: dataPayload[7],

            stationAltitude: dataPayload[9],
            heading: dataPayload[8],
            ...(isCnms && { siteId: String(siteId) }),
          };

          setStopBtnDetails({
            disable: true,
          });

          break;
        }

        /* -------------------------------------------------
         * REMOTE SET
         * ------------------------------------------------- */

        case "remoteSet": {
          const basePath = isCnms ? SAVE_TARGET_GPS_CNMS : SAVE_TARGET_GPS;
          fullUrl = `${basePath}/${resourceId}`;

          sendData = {
            targetLongDeg: dataPayload[0],
            targetLongMin: dataPayload[1],
            targetLongSec: dataPayload[2],
            targetLongHemi: dataPayload[3],

            targetLatDeg: dataPayload[4],
            targetLatMin: dataPayload[5],
            targetLatSec: dataPayload[6],
            targetLatHemi: dataPayload[7],

            targetAltitude: dataPayload[8],
            ...(isCnms && { siteId: String(siteId) }),
          };

          setStopBtnDetails({
            disable: true,
          });

          break;
        }

        /* -------------------------------------------------
         * HOMING
         * ------------------------------------------------- */

        case "homing": {
          // fullUrl = `${SAVE_HOMING}/${resourceId}`;

          // sendData = {};
          const basePath = isCnms ? SAVE_HOMING_CNMS : SAVE_HOMING;
          fullUrl = `${basePath}/${resourceId}`;

          sendData = {
            // CONDITIONAL: Add siteId ONLY for CNMS
            ...(isCnms && { siteId: String(siteId) }),
          };
          setStopBtnDetails({
            disable: true,
          });

          break;
        }

        /* -------------------------------------------------
         * AUTO STOW
         * ------------------------------------------------- */

        case "auto_stow": {
          // fullUrl = `${SAVE_AUTO_STOW}/${resourceId}`;

          // sendData = {};
          const basePath = isCnms ? SAVE_AUTO_STOW_CNMS : SAVE_AUTO_STOW;
          fullUrl = `${basePath}/${resourceId}`;

          sendData = {
            // CONDITIONAL: Add siteId ONLY for CNMS
            ...(isCnms && { siteId: String(siteId) }),
          };
          setStopBtnDetails({
            disable: true,
          });

          break;
        }

        /* -------------------------------------------------
         * LOS
         * ------------------------------------------------- */

        case "los": {
          // fullUrl = `${SAVE_MANUAL_STOW}/${resourceId}`;

          // sendData = {};
          const basePath = isCnms ? SAVE_MANUAL_STOW_CNMS : SAVE_MANUAL_STOW;
          fullUrl = `${basePath}/${resourceId}`;

          sendData = {
            // CONDITIONAL: Add siteId ONLY for CNMS
            ...(isCnms && { siteId: String(siteId) }),
          };
          setStopBtnDetails({
            disable: true,
          });

          break;
        }

        default:
          throw new Error(`Unsupported button action: ${key}`);
      }

      if (!fullUrl) {
        throw new Error("API URL was not configured");
      }

      const response = await ConfigurationAxios(fullUrl, "post", sendData);

      const responseBody = response?.data;

      if (responseBody?.status !== 1) {
        throw new Error(responseBody?.message || "Configuration update failed");
      }

      /* -------------------------------------------------
       * LOCAL SUCCESS
       * ------------------------------------------------- */

      if (key === "loadLocal") {
        setLocalEdit(false);

        setLocalErrors({});

        Toast("Success", "Load Local updated successfully", "success");
      }

      /* -------------------------------------------------
       * REMOTE SUCCESS
       * ------------------------------------------------- */

      if (key === "remoteSet") {
        setRemoteEdit(false);

        setRemoteErrors({});

        Toast("Success", "Remote Set updated successfully", "success");
      }

      /* -------------------------------------------------
       * HOMING
       * ------------------------------------------------- */

      if (key === "homing") {
        setAntennaStatus({
          message: OPERATION_ACK.HOMING_IN_PROGRESS,
        });

        startPolling("homing");
      }

      /* -------------------------------------------------
       * LOS
       * ------------------------------------------------- */

      if (key === "los") {
        setAntennaStatus({
          message: OPERATION_ACK.LOS_IN_PROGRESS,
        });

        startPolling("los");
      }

      /* -------------------------------------------------
       * AUTO STOW
       * ------------------------------------------------- */

      if (key === "auto_stow") {
        setAntennaStatus({
          message: OPERATION_ACK.AUTO_STOW_IN_PROGRESS,
        });

        startPolling("autostow");
      }
    } catch (error) {
      console.error("Configuration API Error:", error);

      setStopBtnDetails({
        disable: true,
      });

      /*
       * Set failed status only for physical operations.
       */
      if (["homing", "los", "auto_stow"].includes(key)) {
        const operation = key === "auto_stow" ? "autostow" : key;

        setAntennaStatus({
          message:
            OPERATION_MESSAGES[operation]?.failed ||
            `${getOperationLabel(operation)} failed`,
        });
      }

      Toast("Error", error?.message || "Error updating configuration", "error");
    } finally {
      setDisabledButton(false);

      setCurrentBtn("");
    }
  };

  const operationActive = activeOperation !== null;

  const localFieldsDisabled =
    !localEdit || movementLoading || operationActive || disabledButton;

  const remoteFieldsDisabled =
    !remoteEdit || movementLoading || operationActive || disabledButton;

  const configurationOperationDisabled =
    disabledButton || movementLoading || operationActive;

  const targetMovementDisabled =
    disabledButton || movementLoading || operationActive;

  const statusInProgress = operationActive;
  const refreshFinalPosition = async (operation) => {
    if (!resourceId || !isMountedRef.current) {
      return;
    }

    try {
      // If you want to poll more than once then uncomment this line
      await fetchCurrentAzEl(operation);
      // await fetchCurrentAzEl(operation);
      // await fetchCurrentAzEl(operation);
      // await fetchCurrentAzEl(operation);
    } catch (error) {
      console.error("Final position refresh error:", error);
    }
  };

  return (
    <Box
      sx={{
        p: 1,
        backgroundColor: "#f4f6f8",
        height: "auto",
      }}
    >
      {configurationLoading && (
        <Box
          sx={{
            position: "fixed",
            inset: 0,
            zIndex: 9999,
            backgroundColor: "rgba(255,255,255,0.55)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            pointerEvents: "none",
          }}
        >
          <Box
            sx={{
              backgroundColor: "#fff",
              borderRadius: 2,
              p: 2,
              boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <CircularProgress size={28} />

            <Typography>Loading configuration...</Typography>
          </Box>
        </Box>
      )}

      <Paper
        elevation={0}
        sx={{
          p: 1,
          borderRadius: 2,
          border: "1px solid #e0e0e0",
          backgroundColor: "#fff",
        }}
      >
        <Grid
          spacing={2}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: 2,
          }}
        >
          {/* AZIMUTH GAUGE */}

          <Grid item xs={12} md={4}>
            <Box
              sx={{
                height: "100%",
                minHeight: 320,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                overflow: "hidden",
                p: 1,
                backgroundColor: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {DialGaugeWidget && DialGaugeWidget(azimuthWidgetConfig)}
            </Box>
          </Grid>

          {/* ELEVATION GAUGE */}

          <Grid item xs={12} md={4}>
            <Box
              sx={{
                height: "100%",
                minHeight: 320,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                overflow: "hidden",
                p: 1,
                backgroundColor: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {DialGaugeWidget && DialGaugeWidget(elevationWidgetConfig)}
            </Box>
          </Grid>

          {/* MOVEMENT CONTROLS */}

          <Grid item xs={12} md={4}>
            <Box
              sx={{
                height: "100%",
                minHeight: 320,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                p: 2,
                backgroundColor: "#fafafa",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Typography
                variant="subtitle1"
                fontWeight={700}
                sx={{
                  alignSelf: "center",
                  mb: 1,
                }}
              >
                Antenna Movement Controls
              </Typography>
              {/* UP */}

              <MButtonPrimary
                variant="contained"
                disabled={
                  movementLoading ||
                  (activeOperation !== null && activeOperation !== "up")
                }
                // onClick={() => handleMovementClick("up")}
                onClick={() => openConfirmation("up", CONFIRM_MESSAGES.up)}
                startIcon={
                  movementLoading && currentBtn === "up" ? (
                    <CircularProgress size={20} color="inherit" />
                  ) : activeMovement === "up" ? (
                    <PauseCircleFilled />
                  ) : (
                    <ArrowUpward />
                  )
                }
                style={{
                  minWidth: 110,
                  borderRadius: "8px",
                  backgroundColor:
                    activeMovement === "up" ? "#d70000" : "#14348D",
                  color: "#fff",
                  boxShadow:
                    activeMovement === "up"
                      ? "0 4px 10px rgba(211,47,47,0.3)"
                      : "none",
                }}
              >
                {movementLoading && currentBtn === "up"
                  ? "Updating..."
                  : activeMovement === "up"
                  ? "Up Stop"
                  : "Up"}
              </MButtonPrimary>

              {/* CCW / CW */}

              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 2,
                  mt: 1.5,
                }}
              >
                {/* CCW */}

                <MButtonPrimary
                  variant="contained"
                  disabled={
                    movementLoading ||
                    (activeOperation !== null && activeOperation !== "ccw")
                  }
                  onClick={() => openConfirmation("ccw", CONFIRM_MESSAGES.ccw)}
                  startIcon={
                    movementLoading && currentBtn === "ccw" ? (
                      <CircularProgress size={20} color="inherit" />
                    ) : activeMovement === "ccw" ? (
                      <PauseCircleFilled />
                    ) : (
                      <Rotate90DegreesCcw />
                    )
                  }
                  style={{
                    minWidth: 110,
                    borderRadius: "8px",
                    backgroundColor:
                      activeMovement === "ccw" ? "#d70000" : "#14348D",
                    color: "#fff",
                    boxShadow:
                      activeMovement === "ccw"
                        ? "0 4px 10px rgba(211,47,47,0.3)"
                        : "none",
                  }}
                >
                  {movementLoading && currentBtn === "ccw"
                    ? "Updating..."
                    : activeMovement === "ccw"
                    ? "CCW Stop"
                    : "CCW"}
                </MButtonPrimary>

                {/* CW */}

                <MButtonPrimary
                  variant="contained"
                  disabled={
                    movementLoading ||
                    (activeOperation !== null && activeOperation !== "cw")
                  }
                  onClick={() => openConfirmation("cw", CONFIRM_MESSAGES.cw)}
                  startIcon={
                    movementLoading && currentBtn === "cw" ? (
                      <CircularProgress size={20} color="inherit" />
                    ) : activeMovement === "cw" ? (
                      <PauseCircleFilled />
                    ) : (
                      <Rotate90DegreesCw />
                    )
                  }
                  style={{
                    minWidth: 110,
                    borderRadius: "8px",
                    backgroundColor:
                      activeMovement === "cw" ? "#d70000" : "#14348D",
                    color: "#fff",
                    boxShadow:
                      activeMovement === "cw"
                        ? "0 4px 10px rgba(211,47,47,0.3)"
                        : "none",
                  }}
                >
                  {movementLoading && currentBtn === "cw"
                    ? "Updating..."
                    : activeMovement === "cw"
                    ? "CW Stop"
                    : "CW"}
                </MButtonPrimary>
              </Box>

              {/* DOWN */}

              <MButtonPrimary
                variant="contained"
                disabled={
                  movementLoading ||
                  (activeOperation !== null && activeOperation !== "down")
                }
                onClick={() => openConfirmation("down", CONFIRM_MESSAGES.down)}
                startIcon={
                  movementLoading && currentBtn === "down" ? (
                    <CircularProgress size={20} color="inherit" />
                  ) : activeMovement === "down" ? (
                    <PauseCircleFilled />
                  ) : (
                    <ArrowDownwardRounded />
                  )
                }
                style={{
                  minWidth: 110,
                  borderRadius: "8px",
                  backgroundColor:
                    activeMovement === "down" ? "#d70000" : "#14348D",
                  color: "#fff",
                  boxShadow:
                    activeMovement === "down"
                      ? "0 4px 10px rgba(211,47,47,0.3)"
                      : "none",
                  marginTop: 2,
                }}
              >
                {movementLoading && currentBtn === "down"
                  ? "Updating..."
                  : activeMovement === "down"
                  ? "Down Stop"
                  : "Down"}
              </MButtonPrimary>

              {/* HOMING / LOS / AUTO STOW */}

              <Box
                sx={{
                  mt: 2,
                  display: "flex",
                  gap: 1,
                  justifyContent: "center",
                  flexWrap: "wrap",
                }}
              >
                {/* HOMING */}

                <MButtonPrimary
                  variant="contained"
                  color="primary"
                  disabled={configurationOperationDisabled}
                  // onClick={() => handleButtonClick("homing")}
                  onClick={() =>
                    openConfirmation("homing", CONFIRM_MESSAGES.homing)
                  }
                >
                  {activeOperation === "homing" ? (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                      }}
                    >
                      <CircularProgress size={20} color="inherit" />
                      Homing...
                    </Box>
                  ) : (
                    "Homing"
                  )}
                </MButtonPrimary>

                {/* LOS */}

                <MButtonPrimary
                  variant="contained"
                  color="primary"
                  disabled={configurationOperationDisabled}
                  // onClick={() => handleButtonClick("los")}
                  onClick={() => openConfirmation("los", CONFIRM_MESSAGES.los)}
                >
                  {activeOperation === "los" ? (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                      }}
                    >
                      <CircularProgress size={20} color="inherit" />
                      LOS...
                    </Box>
                  ) : (
                    "LOS"
                  )}
                </MButtonPrimary>

                {/* AUTO STOW */}

                <MButtonPrimary
                  variant="contained"
                  color="primary"
                  disabled={configurationOperationDisabled}
                  // onClick={() => handleButtonClick("auto_stow")}
                  onClick={() =>
                    openConfirmation("auto_stow", CONFIRM_MESSAGES.auto_stow)
                  }
                >
                  {activeOperation === "autostow" ? (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                      }}
                    >
                      <CircularProgress size={20} color="inherit" />
                      Auto Stow...
                    </Box>
                  ) : (
                    "Auto Stow"
                  )}
                </MButtonPrimary>
              </Box>

              {/* DIRECT AZIMUTH / ELEVATION MOVEMENT */}

              <Box
                sx={{
                  display: "flex",
                  gap: "15px",
                  flexDirection: "column",
                  flexWrap: "wrap",
                  mt: 5,
                  width: "100%",
                }}
              >
                {/* AZIMUTH TARGET */}

                <Box
                  sx={{
                    display: "flex",
                    gap: "15px",
                    width: "100%",
                  }}
                >
                  <TextField
                    size="small"
                    fullWidth
                    disabled={targetMovementDisabled}
                    label="Azimuth(Deg)"
                    placeholder="-180 to +180"
                    value={targetAzimuth}
                    onChange={(e) => {
                      const value = sanitizeInput(
                        e.target.value,
                        TARGET_ANGLE_REGEX,
                        8
                      );

                      if (value !== null) {
                        setTargetAzimuth(value);

                        if (targetErrors.azimuth) {
                          setTargetErrors((prev) => ({
                            ...prev,
                            azimuth: "",
                          }));
                        }
                      }
                    }}
                    error={Boolean(targetErrors.azimuth)}
                    helperText={targetErrors.azimuth || "-180 to +180"}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />

                  <MButtonPrimary
                    variant="contained"
                    color="primary"
                    disabled={targetMovementDisabled}
                    // onClick={() => handleTargetMovement("azimuth")}
                    onClick={() =>
                      openConfirmation("azimuth", CONFIRM_MESSAGES.azimuth)
                    }
                    style={{
                      height: "40px",
                      minWidth: 70,
                    }}
                  >
                    {movementLoading && currentBtn === "azimuth" ? (
                      <CircularProgress size={20} color="inherit" />
                    ) : activeOperation === "azimuth" ? (
                      "GO..."
                    ) : (
                      "GO"
                    )}
                  </MButtonPrimary>
                </Box>

                {/* ELEVATION TARGET */}

                <Box
                  sx={{
                    display: "flex",
                    gap: "15px",
                    width: "100%",
                  }}
                >
                  <TextField
                    size="small"
                    fullWidth
                    disabled={targetMovementDisabled}
                    label="Elevation(Deg)"
                    placeholder="-15 to +15"
                    value={targetElevation}
                    onChange={(e) => {
                      const value = sanitizeInput(
                        e.target.value,
                        TARGET_ANGLE_REGEX,
                        8
                      );

                      if (value !== null) {
                        setTargetElevation(value);

                        if (targetErrors.elevation) {
                          setTargetErrors((prev) => ({
                            ...prev,
                            elevation: "",
                          }));
                        }
                      }
                    }}
                    error={Boolean(targetErrors.elevation)}
                    helperText={targetErrors.elevation || "-15 to +15"}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />

                  <MButtonPrimary
                    variant="contained"
                    color="primary"
                    disabled={targetMovementDisabled}
                    // onClick={() => handleTargetMovement("elevation")}
                    onClick={() =>
                      openConfirmation("elevation", CONFIRM_MESSAGES.elevation)
                    }
                    style={{
                      height: "40px",
                      minWidth: 70,
                    }}
                  >
                    {movementLoading && currentBtn === "elevation" ? (
                      <CircularProgress size={20} color="inherit" />
                    ) : activeOperation === "elevation" ? (
                      "GO..."
                    ) : (
                      "GO"
                    )}
                  </MButtonPrimary>
                </Box>
              </Box>
            </Box>
          </Grid>

          <Grid
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: "8px",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Grid item xs={12} md={4}>
              <Box
                sx={{
                  height: "100%",
                  minHeight: 315,
                  border: "1px solid #e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                  p: 1,
                  backgroundColor: "#fff",
                  display: "flex",
                  flexDirection: "column",
                  gap: 1,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {/* AUTO STOW ANGLE SETTINGS */}

                <Box
                  sx={{
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    fontWeight={700}
                    sx={{
                      alignSelf: "center",
                    }}
                  >
                    Auto Stow Angle
                  </Typography>

                  {/* AZIMUTH STOW */}

                  <TextField
                    size="small"
                    fullWidth
                    disabled={
                      disabledButton || movementLoading || operationActive
                    }
                    label="Azimuth(Deg)"
                    placeholder="-180 to +180"
                    value={autoStowAzimuth}
                    onChange={(e) => {
                      const value = sanitizeInput(
                        e.target.value,
                        TARGET_ANGLE_REGEX,
                        8
                      );

                      if (value !== null) {
                        setAutoStowAzimuth(value);

                        if (autoStowErrors.azimuth) {
                          setAutoStowErrors((prev) => ({
                            ...prev,
                            azimuth: "",
                          }));
                        }
                      }
                    }}
                    error={Boolean(autoStowErrors.azimuth)}
                    helperText={autoStowErrors.azimuth || "-180 to +180"}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />

                  {/* ELEVATION STOW */}

                  <TextField
                    size="small"
                    fullWidth
                    disabled={
                      disabledButton || movementLoading || operationActive
                    }
                    label="Elevation (Deg)"
                    placeholder="-15 to +15"
                    value={autoStowElevation}
                    onChange={(e) => {
                      const value = sanitizeInput(
                        e.target.value,
                        TARGET_ANGLE_REGEX,
                        8
                      );

                      if (value !== null) {
                        setAutoStowElevation(value);

                        if (autoStowErrors.elevation) {
                          setAutoStowErrors((prev) => ({
                            ...prev,
                            elevation: "",
                          }));
                        }
                      }
                    }}
                    error={Boolean(autoStowErrors.elevation)}
                    helperText={autoStowErrors.elevation || "-15 to +15"}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />

                  {/* SET */}

                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <MButtonPrimary
                      variant="contained"
                      color="primary"
                      disabled={
                        disabledButton ||
                        movementLoading ||
                        operationActive ||
                        isEmpty(autoStowAzimuth) ||
                        isEmpty(autoStowElevation)
                      }
                      onClick={handleSetAutoStow}
                      style={{
                        height: "40px",
                        minWidth: 90,
                      }}
                    >
                      {movementLoading && currentBtn === "setAutoStow" ? (
                        <CircularProgress size={20} color="inherit" />
                      ) : (
                        "SET"
                      )}
                    </MButtonPrimary>
                  </Box>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} md={4}>
              <Box
                sx={{
                  height: "100%",
                  minHeight: 120,
                  minWidth: 280,
                  border: "1px solid #e0e0e0",
                  borderRadius: 2,
                  overflow: "hidden",
                  p: 1,
                  backgroundColor: "#fff",
                  display: "flex",
                  flexDirection: "column",
                  gap: 2,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Box
                  sx={{
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                  }}
                >
                  <Typography
                    variant="subtitle1"
                    fontWeight={700}
                    sx={{
                      alignSelf: "center",
                    }}
                  >
                    Speed
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      gap: "11px",
                      width: "100%",
                    }}
                  >
                    <FormControl
                      size="small"
                      fullWidth
                      disabled={targetMovementDisabled}
                    >
                      <InputLabel id="speed-select-label">Speed</InputLabel>

                      <Select
                        labelId="speed-select-label"
                        value={speed}
                        label="Speed"
                        onChange={(e) => {
                          setSpeed(e.target.value);
                        }}
                        MenuProps={{
                          sx: {
                            zIndex: 2000,
                          },
                          PaperProps: {
                            sx: {
                              zIndex: 2000,
                            },
                          },
                        }}
                      >
                        {SPEED_OPTIONS.map((option) => (
                          <MenuItem key={option.value} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>

                    <MButtonPrimary
                      variant="contained"
                      color="primary"
                      disabled={targetMovementDisabled || !speed}
                      onClick={handleSpeedChange}
                      style={{
                        height: "40px",
                        minWidth: 70,
                      }}
                    >
                      {movementLoading && currentBtn === "speed" ? (
                        <CircularProgress size={20} color="inherit" />
                      ) : (
                        "SET"
                      )}
                    </MButtonPrimary>
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Paper>

      <Paper
        elevation={0}
        sx={{
          p: 0,
          mt: 0.5,
          mb: 0.5,
          borderRadius: 2,
          border: "1px solid #e0e0e0",
          backgroundColor: "#ffffff",
        }}
      >
        <Box
          sx={{
            pl: 1,
            borderRadius: 1.5,
            backgroundColor: statusInProgress ? "#fff7ed" : "#f0fdf4",
            border: "1px solid",
            borderColor: statusInProgress ? "#fed7aa" : "#bbf7d0",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <Typography
              variant="subtitle1"
              fontWeight={700}
              sx={{
                color: "#1f2937",
              }}
            >
              Antenna Status:
            </Typography>

            <Typography
              variant="body1"
              fontWeight={700}
              sx={{
                color: statusInProgress ? "#c2410c" : "#15803d",
                pl: 1,
              }}
            >
              {antennaStatus.message}
            </Typography>
          </Box>
        </Box>
      </Paper>

      <Paper
        sx={{
          p: 1,
          mb: 0,
          borderRadius: 2,
          mt: 0,
        }}
      >
        <Grid
          spacing={2}
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "15px",
          }}
        >
          <Grid item xs={12} md={6}>
            <Box
              sx={{
                p: 1.5,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                backgroundColor: "#fafafa",
              }}
            >
              {/* HEADER + EDIT SWITCH */}

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="subtitle1" fontWeight="bold">
                  Local Site Information
                </Typography>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5,
                  }}
                >
                  <Typography
                    variant="body2"
                    fontWeight={600}
                    color="text.secondary"
                  >
                    Edit
                  </Typography>

                  <Switch
                    checked={localEdit}
                    onChange={(event) => {
                      const checked = event.target.checked;

                      if (
                        operationActive ||
                        movementLoading ||
                        disabledButton
                      ) {
                        return;
                      }

                      setLocalEdit(checked);

                      if (!checked) {
                        setLocalErrors({});
                      }
                    }}
                    disabled={
                      operationActive || movementLoading || disabledButton
                    }
                    color="primary"
                  />
                </Box>
              </Box>

              {/* LATITUDE */}

              <Typography variant="body2" fontWeight={500} mb={1}>
                Latitude
              </Typography>

              <Grid
                sx={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
                  gap: 1.5,
                  width: "100%",
                  mb: 1,
                }}
              >
                {/* LAT DEG */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Deg"
                  placeholder="0-90"
                  value={localDataArr[4] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      2
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[4] = value;

                      setLocalDataArr(updated);

                      if (localErrors[4]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          4: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[4])}
                  helperText={localErrors[4] || "0-90"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* LAT MIN */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Min"
                  placeholder="0-59"
                  value={localDataArr[5] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      2
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[5] = value;

                      setLocalDataArr(updated);

                      if (localErrors[5]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          5: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[5])}
                  helperText={localErrors[5] || "0-59"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* LAT SEC */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Sec"
                  placeholder="0-59.999"
                  value={localDataArr[6] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      SECOND_REGEX,
                      7
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[6] = value;

                      setLocalDataArr(updated);

                      if (localErrors[6]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          6: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[6])}
                  helperText={localErrors[6] || "0-59.999"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* LAT DIR */}

                <FormControl
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  error={Boolean(localErrors[7])}
                  sx={{ zIndex: 2800 }}
                >
                  <InputLabel shrink>Dir</InputLabel>

                  <Select
                    label="Dir"
                    value={localDataArr[7] ?? ""}
                    onChange={(e) => {
                      const updated = [...localDataArr];

                      updated[7] = e.target.value;

                      setLocalDataArr(updated);

                      if (localErrors[7]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          7: "",
                        }));
                      }
                    }}
                    MenuProps={{
                      sx: {
                        zIndex: 2000,
                      },
                      PaperProps: {
                        sx: {
                          zIndex: 2000,
                        },
                      },
                    }}
                  >
                    <MenuItem value="N">North</MenuItem>

                    <MenuItem value="S">South</MenuItem>
                  </Select>

                  <FormHelperText>{localErrors[7] || "N / S"}</FormHelperText>
                </FormControl>
              </Grid>

              {/* LONGITUDE */}

              <Typography variant="body2" fontWeight={500} mb={1}>
                Longitude
              </Typography>

              <Grid
                sx={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
                  gap: 1.5,
                  width: "100%",
                  mb: 2,
                }}
              >
                {/* LONG DEG */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Deg"
                  placeholder="0-180"
                  value={localDataArr[0] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      3
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[0] = value;

                      setLocalDataArr(updated);

                      if (localErrors[0]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          0: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[0])}
                  helperText={localErrors[0] || "0-180"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* LONG MIN */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Min"
                  placeholder="0-59"
                  value={localDataArr[1] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      2
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[1] = value;

                      setLocalDataArr(updated);

                      if (localErrors[1]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          1: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[1])}
                  helperText={localErrors[1] || "0-59"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* LONG SEC */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Sec"
                  placeholder="0-59.999"
                  value={localDataArr[2] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      SECOND_REGEX,
                      7
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[2] = value;

                      setLocalDataArr(updated);

                      if (localErrors[2]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          2: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[2])}
                  helperText={localErrors[2] || "0-59.999"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* LONG DIR */}

                <FormControl
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  error={Boolean(localErrors[3])}
                >
                  <InputLabel shrink>Dir</InputLabel>

                  <Select
                    label="Dir"
                    value={localDataArr[3] ?? ""}
                    onChange={(e) => {
                      const updated = [...localDataArr];

                      updated[3] = e.target.value;

                      setLocalDataArr(updated);

                      if (localErrors[3]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          3: "",
                        }));
                      }
                    }}
                    MenuProps={{
                      sx: {
                        zIndex: 2000,
                      },
                      PaperProps: {
                        sx: {
                          zIndex: 2000,
                        },
                      },
                    }}
                  >
                    <MenuItem value="E">East</MenuItem>

                    <MenuItem value="W">West</MenuItem>
                  </Select>

                  <FormHelperText>{localErrors[3] || "E / W"}</FormHelperText>
                </FormControl>
              </Grid>

              <Grid
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  gap: "12px",
                }}
              >
                {/* HEADING */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Vehicle Heading (Deg)"
                  placeholder="0-360"
                  value={localDataArr[8] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      DECIMAL_INPUT_REGEX,
                      7
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[8] = value;

                      setLocalDataArr(updated);

                      if (localErrors[8]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          8: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[8])}
                  helperText={localErrors[8] || "Enter 0-360"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                  sx={{
                    mb: 2,
                  }}
                />

                {/* ALTITUDE */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={localFieldsDisabled}
                  label="Altitude (Meters)"
                  placeholder="0-9999"
                  value={localDataArr[9] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      DECIMAL_INPUT_REGEX,
                      8
                    );

                    if (value !== null) {
                      const updated = [...localDataArr];

                      updated[9] = value;

                      setLocalDataArr(updated);

                      if (localErrors[9]) {
                        setLocalErrors((prev) => ({
                          ...prev,
                          9: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(localErrors[9])}
                  helperText={localErrors[9] || "Enter 0-9999"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </Grid>

              {/* LOCAL SAVE */}

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  mt: 0,
                }}
              >
                <MButtonPrimary
                  variant="contained"
                  color="success"
                  disabled={
                    !localEdit ||
                    disabledButton ||
                    movementLoading ||
                    operationActive
                  }
                  onClick={() => handleButtonClick("loadLocal", localDataArr)}
                  sx={{
                    minWidth: 140,
                    borderRadius: "8px",
                  }}
                >
                  {currentBtn === "loadLocal" ? (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 1,
                      }}
                    >
                      <CircularProgress size={20} color="inherit" />
                      Saving...
                    </Box>
                  ) : (
                    "Save"
                  )}
                </MButtonPrimary>
              </Box>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box
              sx={{
                p: 1.5,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                backgroundColor: "#fafafa",
              }}
            >
              {/* HEADER + EDIT SWITCH */}

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="subtitle1" fontWeight="bold">
                  Remote Site Information
                </Typography>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5,
                  }}
                >
                  <Typography
                    variant="body2"
                    fontWeight={600}
                    color="text.secondary"
                  >
                    Edit
                  </Typography>

                  <Switch
                    checked={remoteEdit}
                    onChange={(event) => {
                      const checked = event.target.checked;

                      if (
                        operationActive ||
                        movementLoading ||
                        disabledButton
                      ) {
                        return;
                      }

                      setRemoteEdit(checked);

                      if (!checked) {
                        setRemoteErrors({});
                      }
                    }}
                    disabled={
                      operationActive || movementLoading || disabledButton
                    }
                    color="primary"
                  />
                </Box>
              </Box>

              {/* LATITUDE */}

              <Typography variant="body2" fontWeight={500} mb={1}>
                Latitude
              </Typography>

              <Grid
                sx={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
                  gap: 1.5,
                  width: "100%",
                  mb: 1,
                }}
              >
                {/* DEG */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  label="Deg"
                  placeholder="0-90"
                  value={remoteDataArr[4] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      2
                    );

                    if (value !== null) {
                      const updated = [...remoteDataArr];

                      updated[4] = value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[4]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          4: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(remoteErrors[4])}
                  helperText={remoteErrors[4] || "0-90"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* MIN */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  label="Min"
                  placeholder="0-59"
                  value={remoteDataArr[5] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      2
                    );

                    if (value !== null) {
                      const updated = [...remoteDataArr];

                      updated[5] = value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[5]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          5: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(remoteErrors[5])}
                  helperText={remoteErrors[5] || "0-59"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* SEC */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  label="Sec"
                  placeholder="0-59.999"
                  value={remoteDataArr[6] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      SECOND_REGEX,
                      7
                    );

                    if (value !== null) {
                      const updated = [...remoteDataArr];

                      updated[6] = value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[6]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          6: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(remoteErrors[6])}
                  helperText={remoteErrors[6] || "0-59.999"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* DIR */}

                <FormControl
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  error={Boolean(remoteErrors[7])}
                >
                  <InputLabel shrink>Dir</InputLabel>

                  <Select
                    label="Dir"
                    value={remoteDataArr[7] ?? ""}
                    onChange={(e) => {
                      const updated = [...remoteDataArr];

                      updated[7] = e.target.value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[7]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          7: "",
                        }));
                      }
                    }}
                    MenuProps={{
                      sx: {
                        zIndex: 2000,
                      },
                      PaperProps: {
                        sx: {
                          zIndex: 2000,
                        },
                      },
                    }}
                  >
                    <MenuItem value="N">North</MenuItem>

                    <MenuItem value="S">South</MenuItem>
                  </Select>

                  <FormHelperText>{remoteErrors[7] || "N / S"}</FormHelperText>
                </FormControl>
              </Grid>

              {/* LONGITUDE */}

              <Typography variant="body2" fontWeight={500} mb={1}>
                Longitude
              </Typography>

              <Grid
                sx={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
                  gap: 1.5,
                  width: "100%",
                  mb: 2,
                }}
              >
                {/* DEG */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  label="Deg"
                  placeholder="0-180"
                  value={remoteDataArr[0] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      3
                    );

                    if (value !== null) {
                      const updated = [...remoteDataArr];

                      updated[0] = value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[0]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          0: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(remoteErrors[0])}
                  helperText={remoteErrors[0] || "0-180"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* MIN */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  label="Min"
                  placeholder="0-59"
                  value={remoteDataArr[1] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      INTEGER_INPUT_REGEX,
                      2
                    );

                    if (value !== null) {
                      const updated = [...remoteDataArr];

                      updated[1] = value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[1]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          1: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(remoteErrors[1])}
                  helperText={remoteErrors[1] || "0-59"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* SEC */}

                <TextField
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  label="Sec"
                  placeholder="0-59.999"
                  value={remoteDataArr[2] || ""}
                  onChange={(e) => {
                    const value = sanitizeInput(
                      e.target.value,
                      SECOND_REGEX,
                      7
                    );

                    if (value !== null) {
                      const updated = [...remoteDataArr];

                      updated[2] = value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[2]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          2: "",
                        }));
                      }
                    }
                  }}
                  error={Boolean(remoteErrors[2])}
                  helperText={remoteErrors[2] || "0-59.999"}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />

                {/* DIR */}

                <FormControl
                  size="small"
                  fullWidth
                  disabled={remoteFieldsDisabled}
                  error={Boolean(remoteErrors[3])}
                >
                  <InputLabel shrink>Dir</InputLabel>

                  <Select
                    label="Dir"
                    value={remoteDataArr[3] ?? ""}
                    onChange={(e) => {
                      const updated = [...remoteDataArr];

                      updated[3] = e.target.value;

                      setRemoteDataArr(updated);

                      if (remoteErrors[3]) {
                        setRemoteErrors((prev) => ({
                          ...prev,
                          3: "",
                        }));
                      }
                    }}
                    MenuProps={{
                      sx: {
                        zIndex: 2000,
                      },
                      PaperProps: {
                        sx: {
                          zIndex: 2000,
                        },
                      },
                    }}
                  >
                    <MenuItem value="E">East</MenuItem>

                    <MenuItem value="W">West</MenuItem>
                  </Select>

                  <FormHelperText>{remoteErrors[3] || "E / W"}</FormHelperText>
                </FormControl>
              </Grid>

              {/* ALTITUDE */}

              <TextField
                size="small"
                fullWidth
                disabled={remoteFieldsDisabled}
                label="Altitude (Meters)"
                placeholder="0-9999"
                value={remoteDataArr[8] || ""}
                onChange={(e) => {
                  const value = sanitizeInput(
                    e.target.value,
                    DECIMAL_INPUT_REGEX,
                    8
                  );

                  if (value !== null) {
                    const updated = [...remoteDataArr];

                    updated[8] = value;

                    setRemoteDataArr(updated);

                    if (remoteErrors[8]) {
                      setRemoteErrors((prev) => ({
                        ...prev,
                        8: "",
                      }));
                    }
                  }
                }}
                error={Boolean(remoteErrors[8])}
                helperText={remoteErrors[8] || "Enter 0-9999"}
                InputLabelProps={{
                  shrink: true,
                }}
                sx={{
                  width: "50%",
                }}
              />

              {/* REMOTE SAVE */}

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  mt: 2,
                }}
              >
                <MButtonPrimary
                  variant="contained"
                  color="success"
                  disabled={
                    !remoteEdit ||
                    disabledButton ||
                    movementLoading ||
                    operationActive
                  }
                  onClick={() => handleButtonClick("remoteSet", remoteDataArr)}
                  sx={{
                    minWidth: 140,
                    borderRadius: "8px",
                  }}
                >
                  {currentBtn === "remoteSet" ? (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 1,
                      }}
                    >
                      <CircularProgress size={20} color="inherit" />
                      Saving...
                    </Box>
                  ) : (
                    "Save"
                  )}
                </MButtonPrimary>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Paper>
      <MDialog
        open={showConfirm}
        variant="warning"
        title="Confirm Action"
        icon={Confirmation_icon}
        message={confirmMessage}
        onConfirm={handleConfirmAction}
        onClose={handleCancelConfirmation}
        mode="parent"
      />
    </Box>
  );
};

export default AntpConfiguration;
