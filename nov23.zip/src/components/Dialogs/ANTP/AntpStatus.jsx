import React, { useMemo, useState, useEffect } from "react";
import { Box, Typography, Grid, Paper, TextField } from "@mui/material";
import { WIDGET_REGISTRY } from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23";
import { AntpConfig } from "./AntpConfig";
import moment from "moment";
import { GET_STATUS_BY_DEVICE_AND_TAB } from "@/RestAPI/url/endpoint";
import { ConfigurationAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";

const AntpStatus = ({ resourceId = "MCT_EP_ANTP" }) => {
  const [date, setDate] = useState({});
  const [elements, setElements] = useState({});
  const [azele, setAzele] = useState({ azimuth: "", elevation: "" });

  // Status Arrays for Local and Remote Site
  const [localDataArr, setLocalDataArr] = useState(Array(10).fill(""));
  const [remoteDataArr, setRemoteDataArr] = useState(Array(9).fill(""));

  // Extract canvas renderers from the registry for modern dials
  const DialGaugeWidget = WIDGET_REGISTRY.circularDialGauge?.renderCanvas;

  const azimuthWidgetConfig = useMemo(
    () => ({
      gridTitle: "Azimuth Position",
      minVal: -180,
      maxVal: 180,
      unit: "deg",
      data: [{ currentValue: Number(azele.azimuth) || 0 }],
    }),
    [azele.azimuth]
  );

  const elevationWidgetConfig = useMemo(
    () => ({
      gridTitle: "Elevation Position",
      minVal: -180,
      maxVal: 180,
      unit: "deg",
      data: [{ currentValue: Number(azele.elevation) || 0 }],
    }),
    [azele.elevation]
  );

  const fetchStatus = () => {
    const fullUrl = `${GET_STATUS_BY_DEVICE_AND_TAB}/${resourceId}/2/0`;

    ConfigurationAxios(fullUrl, "get")
      .then((response) => {
        const data = response.data;

        if (data && data.status) {
          let obj = {};
          if (data.data && data.data.static) {
            Object.keys(data.data.static).forEach((el) => {
              obj[el] = data.data.static[el];
            });

            setElements(obj);
            setDate(data.data.date);

            // Populate local data array (includes GPS & Vehicle Info)
            if (obj[AntpConfig["Local GPS"]]) {
              setLocalDataArr(obj[AntpConfig["Local GPS"]].split(" "));
            }
            // Populate remote data array (GPS & Altitude only)
            if (obj[AntpConfig["Remote GPS Location RW"]]) {
              setRemoteDataArr(
                obj[AntpConfig["Remote GPS Location RW"]].split(" ")
              );
            }

            setAzele({
              azimuth: data.data.static[AntpConfig["Azimuth"]],
              elevation: data.data.static[AntpConfig["Elevation"]],
            });
          }
        } else {
          Toast("Error", data.message, "error");
        }
      })
      .catch((err) => {
        console.error("Status fetch error", err);
      });
  };

  useEffect(() => {
    fetchStatus();
    const polling = setInterval(fetchStatus, 5000);
    return () => clearInterval(polling);
  }, [resourceId]);

  return (
    <Box sx={{ p: 3, backgroundColor: "#f4f6f8", minHeight: "100vh" }}>
      {/* Header Info */}
      <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={2}
        >
          <Typography variant="h6" fontWeight="bold">
            ANTENNA Status Panel
          </Typography>
          <Typography variant="body2" sx={{ color: "red", fontWeight: 500 }}>
            Last Updated - {moment(date).format("DD-MM-YYYY HH:mm:ss")}
          </Typography>
        </Box>

        <Box display="flex" justifyContent="center" mb={3}>
          <Typography variant="subtitle1">
            <b>Source Mode:</b> {elements[AntpConfig["Mode"]] || "N/A"}
          </Typography>
        </Box>

        {/* DEVICE & VEHICLE METADATA BLOCK */}
        <Grid container spacing={3} mb={3}>
          <Grid item xs={12} md={6}>
            <Box
              sx={{
                p: 2,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                backgroundColor: "#fafafa",
              }}
            >
              <Typography variant="subtitle1" fontWeight="bold" mb={2}>
                Device Information
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Device Name"
                    disabled
                    value={elements[AntpConfig["Device Name"]] || "N/A"}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Model No"
                    disabled
                    value={elements[AntpConfig["Model No"]] || "N/A"}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Serial No"
                    disabled
                    value={elements[AntpConfig["Serial No"]] || "N/A"}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Mode"
                    disabled
                    value={elements[AntpConfig["Mode"]] || "N/A"}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
              </Grid>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box
              sx={{
                p: 2,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                backgroundColor: "#fafafa",
              }}
            >
              <Typography variant="subtitle1" fontWeight="bold" mb={2}>
                Vehicle Information
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Vehicle Heading (deg)"
                    disabled
                    value={localDataArr[8] || "N/A"}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Altitude (mts)"
                    disabled
                    value={localDataArr[9] || "N/A"}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
              </Grid>
            </Box>
          </Grid>
        </Grid>

        {/* SECTION 1: Local & Remote Site Status Display Panels */}
        <Grid container spacing={3}>
          {/* Local Site Status (Includes GPS + Vehicle Heading + Altitude) */}
          <Grid item xs={12} md={6}>
            <Box
              sx={{
                p: 2,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                backgroundColor: "#fafafa",
              }}
            >
              <Typography variant="subtitle1" fontWeight="bold" mb={2}>
                Local Site Status
              </Typography>

              <Grid container spacing={2}>
                {/* Longitude */}
                <Grid item xs={12}>
                  <Typography variant="body2" fontWeight={500} mb={1}>
                    Longitude
                  </Typography>
                  <Grid container spacing={1}>
                    {["deg", "min", "sec", "Dir"].map((lbl, idx) => (
                      <Grid item xs={3} key={`local-lon-${idx}`}>
                        <TextField
                          size="small"
                          fullWidth
                          label={lbl}
                          disabled
                          value={localDataArr[idx] || ""}
                          InputLabelProps={{ shrink: true }}
                        />
                      </Grid>
                    ))}
                  </Grid>
                </Grid>

                {/* Latitude */}
                <Grid item xs={12}>
                  <Typography variant="body2" fontWeight={500} mb={1}>
                    Latitude
                  </Typography>
                  <Grid container spacing={1}>
                    {["deg", "min", "sec", "Dir"].map((lbl, idx) => (
                      <Grid item xs={3} key={`local-lat-${idx}`}>
                        <TextField
                          size="small"
                          fullWidth
                          label={lbl}
                          disabled
                          value={localDataArr[idx + 4] || ""}
                          InputLabelProps={{ shrink: true }}
                        />
                      </Grid>
                    ))}
                  </Grid>
                </Grid>

                {/* Vehicle Heading & Altitude fields */}
                <Grid item xs={12}>
                  <Grid container spacing={2} alignItems="center">
                    <Grid item xs={6}>
                      <TextField
                        size="small"
                        fullWidth
                        label="Vehicle Heading (deg)"
                        disabled
                        value={localDataArr[8] || ""}
                        InputLabelProps={{ shrink: true }}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField
                        size="small"
                        fullWidth
                        label="Altitude (mts)"
                        disabled
                        value={localDataArr[9] || ""}
                        InputLabelProps={{ shrink: true }}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Box>
          </Grid>

          {/* Remote Site Status (Includes GPS + Altitude only, No Vehicle Block) */}
          <Grid item xs={12} md={6}>
            <Box
              sx={{
                p: 2,
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                backgroundColor: "#fafafa",
              }}
            >
              <Typography variant="subtitle1" fontWeight="bold" mb={2}>
                Remote Site Status
              </Typography>

              <Grid container spacing={2}>
                {/* Longitude */}
                <Grid item xs={12}>
                  <Typography variant="body2" fontWeight={500} mb={1}>
                    Longitude
                  </Typography>
                  <Grid container spacing={1}>
                    {["deg", "min", "sec", "Dir"].map((lbl, idx) => (
                      <Grid item xs={3} key={`remote-lon-${idx}`}>
                        <TextField
                          size="small"
                          fullWidth
                          label={lbl}
                          disabled
                          value={remoteDataArr[idx] || ""}
                          InputLabelProps={{ shrink: true }}
                        />
                      </Grid>
                    ))}
                  </Grid>
                </Grid>

                {/* Latitude */}
                <Grid item xs={12}>
                  <Typography variant="body2" fontWeight={500} mb={1}>
                    Latitude
                  </Typography>
                  <Grid container spacing={1}>
                    {["deg", "min", "sec", "Dir"].map((lbl, idx) => (
                      <Grid item xs={3} key={`remote-lat-${idx}`}>
                        <TextField
                          size="small"
                          fullWidth
                          label={lbl}
                          disabled
                          value={remoteDataArr[idx + 4] || ""}
                          InputLabelProps={{ shrink: true }}
                        />
                      </Grid>
                    ))}
                  </Grid>
                </Grid>

                {/* Altitude only */}
                <Grid item xs={12}>
                  <TextField
                    size="small"
                    fullWidth
                    label="Altitude (mts)"
                    disabled
                    value={remoteDataArr[8] || ""}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
              </Grid>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* SECTION 2: Modernized Dial Gauges for Azimuth and Elevation */}
      <Paper sx={{ p: 3, borderRadius: 2 }}>
        <Typography variant="h6" fontWeight="bold" mb={3}>
          Antenna Position Metrics
        </Typography>
        <Grid container spacing={3} justifyContent="space-evenly">
          <Grid item xs={12} md={5}>
            <Box
              sx={{
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                overflow: "hidden",
                p: 1,
                backgroundColor: "#fff",
              }}
            >
              {DialGaugeWidget && DialGaugeWidget(azimuthWidgetConfig)}
            </Box>
          </Grid>
          <Grid item xs={12} md={5}>
            <Box
              sx={{
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                overflow: "hidden",
                p: 1,
                backgroundColor: "#fff",
              }}
            >
              {DialGaugeWidget && DialGaugeWidget(elevationWidgetConfig)}
            </Box>
          </Grid>
        </Grid>
      </Paper>
    </Box>
  );
};

export default AntpStatus;
