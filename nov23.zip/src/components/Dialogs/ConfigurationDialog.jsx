import React from "react";
import DynamicStatusLayout from "./DynamicStatusLayout";
import BaseDialogLayout from "./BaseDialogLayout";

const ConfigurationDialog = ({ node, source, onClose }) => {
  return (
    <BaseDialogLayout
      title={`${
        node?.resourceName || node?.label || "Device"
      } - Device Configuration Panel`}
      onClose={onClose}
      customWidth="1150px"
    >
      <DynamicStatusLayout
        node={node}
        source={source}
        mode="configuration" // Signals layout pipeline to search configuration profile rules mappings instead
      />
    </BaseDialogLayout>
  );
};

export default ConfigurationDialog;
