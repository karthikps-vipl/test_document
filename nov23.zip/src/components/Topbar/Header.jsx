/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DashBoard Header
   File Name                : Header.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Topbar\Header.jsx
   Purpose                  : A reusable component used to display consistent page titles,LOGO, 
                               Profile, and SOS at the top of different views.
   Created Date             : 20-01-2026
 ***********************************************************************************************/
import React, {
  useState,
} from "react";

import Typography from "@mui/material/Typography";
import logoLeftDark from "@/assets/SVGIcons/bel-logo-white.svg";

import logoLeftwhite from "@/assets/SVGIcons/bel-logo-black.svg";
import logoRight from "../../assets/svg/AirforceLogo.svg";
import { Box, Divider, Popover, Tooltip } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useSelector } from "react-redux";
import SosModal from "./SoSModal";
import SosButton from "./SosButton";
import sos from "../../assets/svg/sos.svg";
import { Avatar } from "antd";
import DateTime from "./DateTime";
import Loader from "../Reusable/Loader/Loader";
import { Person } from "@mui/icons-material";
import MDialog from "../Reusable/Dialog/MDialog";
import useLogout from "@/utility/customHooks/useLogout";
import logout from "@/assets/SVGIcons/Logout.svg";
import { LogOut } from "lucide-react";
import { useCustomTheme } from "@/utility/DarkTheme/ThemeContext";
import ThemeSwitch from "@/utility/DarkTheme/ThemeSwitch";
import ChangePasswordModal from "./ChangePasswordModal";

const Header = () => {
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';
  const { isUserLoggedIn, userDetails } = useSelector(
    (state) => state.userSlice
  );
  const { isCnms } = useSelector((state) => state.nodeDetails);

  const { siteDetails } = useSelector((state) => state.nodeDetails);
  const repDetails = useSelector((state) => state.nodeDetails?.repDetails);
  console.log(repDetails, "repDetailsrepDetails")
  const [loading, setLoading] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const { logoutHandler } = useLogout();

  const confirmLogout = async () => {
    // Separate function for the actual logout
    setShowLogoutConfirm(false);
    setLoading(true);
    await logoutHandler();
    // try {
    //   await AuthAxios(LOGOUT, "post", { userName: userDetails.data.userName })
    //     .then((res) => {
    //       console.log(res, "logout res");
    //       sessionStorage.clear();
    //       dispatch(setIsUserLoggedIn(false));
    //       Toast("Success", "Logout successful", "success");
    //       dispatch({
    //         type: "socket/disconnect",
    //       });
    //       navigate("/signin");
    //     })
    //     .catch((error) => {
    //       console.error("Logout error", error);
    //       Toast("Failed!", "Failed to logout ", "error");
    //     });
    // } finally {
    //   setLoading(false); // Ensure loading is set to false even on errors
    // }
    setLoading(false); // Ensure loading is set to false even on errors

    setShowLogoutConfirm(false); // Hide the dialog after logout (success or failure)
  };

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const handleOpenPopover = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClosePopover = () => {
    setAnchorEl(null);
  };

  const openPopover = Boolean(anchorEl);
  const { isdarkmode, toggleTheme } = useCustomTheme();
  // Helper function to handle the logic cleanly
const getFormattedLat = (val) => {
  if (val == null) return "";
  
  // Convert to string and split by dot
  const parts = String(val).split('.');
  
  // If there is no decimal part (e.g., "34"), return as is
  if (parts.length === 1) return val;

  const integerPart = parts[0];
  const decimalPart = parts[1];
  
  // Check length of decimal part
  if (decimalPart.length > 6) {
    // Too much data: Cut to 6
    return `${integerPart}.${decimalPart.substring(0, 6)}`;
  } else {
    // Not too much data: Keep original (e.g., 4 digits stays 4)
    return val;
  }
};
  return (
    <>
      <Box
        sx={{
          height: 60,
          bgcolor: "background.default",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: { xs: 1, sm: 2 },
          width: "100%",
          position: "sticky",
          top: 0,
          zIndex: 2,
          boxShadow: "0px 2px 4px rgba(0,0,0,0.1)",
        }}
      >

        <Box
          sx={{
            flex: 2,
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
          }}
        >

          {isDark ? (
            <Box
              component="img"
              src={logoLeftDark}
              alt="Left Logo (Dark Mode)"
              sx={{ height: '50px' }}
            />
          ) : (
            <Box
              component="img"
              src={logoLeftwhite}
              alt="Left Logo (Light Mode)"
              sx={{

                height: '50px',

              }}
            />
          )}
        </Box>

        {/* --- CENTER SECTION --- */}
        <Box
          sx={{
            flex: 1, // Takes more space to keep center aligned
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",

          }}
        >
          <Typography
            sx={{
              fontWeight: 600,
              color: "text.primary",
              fontSize: { xs: "14px", sm: "18px", md: "22px" },
            }}
          >
            {/* {siteDetails?.terminalNickname || "Terminal"} - {String(repDetails?.remoteNumber || "").padStart(3, "")} */}
            {`${siteDetails?.terminalNickname || "Terminal"}${repDetails?.remoteNumber ? ` - ${String(repDetails?.remoteNumber).padStart(3, "0")}` : ""}`}
          </Typography>

          <Tooltip
            title={`Version: ${document.getElementById("about_Version")?.innerHTML || "N/A"} | Lat: ${repDetails?.latitude} | Long: ${repDetails?.longitude}`}
            arrow
          >
            {!isCnms && (
              <Typography
                sx={{
                  fontSize: { xs: "9px", sm: "11px", md: "13px" },
                  color: "text.primary",
                }}
              >
                Version: {document.getElementById("about_Version")?.innerHTML || "N/A"},
                &nbsp;Lat: {getFormattedLat(repDetails?.latitude)},
                &nbsp;Long: {getFormattedLat(repDetails?.longitude)}
              </Typography>
            )}



            {isCnms && (
              <Typography
                sx={{
                  fontSize: { xs: "9px", sm: "11px", md: "13px" },
                  color: "text.primary",
                }}
              >
                Version: {document.getElementById("about_Version")?.innerHTML || "N/A"}

              </Typography>
            )}
          </Tooltip>
        </Box>

        {/* --- RIGHT SECTION --- */}
        <Box
          sx={{
            flex: 2,
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            gap: 1,
          }}
        >


          {isUserLoggedIn ? (
            <>
              <Box sx={{ display: "flex", alignItems: "center", gap: { xs: 0.5, sm: 1 } }}>
                <Tooltip title="Current Date and Time" arrow>
                  <Box>
                    <DateTime />
                  </Box>
                </Tooltip>

                {/* SOS Logic: Only show if NOT CNMS */}
                {!isCnms && (
                  <Box sx={{ mr: 7 }}>
                    <SosButton src={sos} alt="SOS" onOpenModal={handleOpenModal} />
                    <SosModal isOpen={isModalOpen} onClose={handleCloseModal} />
                  </Box>
                )}

                {/* Avatar + Username */}
                <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                  <Tooltip title="View Profile Menu" arrow>
                    <Box
                      onClick={handleOpenPopover}
                      sx={{
                        cursor: "pointer",
                        display: "inline-flex",
                        borderRadius: "50%",
                        "&:hover": {
                          opacity: 0.8,
                        },
                      }}
                    >
                      <Avatar
                        style={{
                          width: "45px",
                          height: "45px",
                          background: theme.palette.background.avtar,
                        }}
                      >
                        <Person size={40} sx={{ color: theme.palette.background.avtarColor }} />
                      </Avatar>
                    </Box>
                  </Tooltip>
                </Box>
              </Box>

              {/* Popover Menu (remains unchanged) */}
              <Popover
                open={openPopover}
                anchorEl={anchorEl}
                onClose={handleClosePopover}
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                transformOrigin={{ vertical: "top", horizontal: "right" }}
                PaperProps={{
                  elevation: 3,
                  sx: {
                    mt: 1.5,
                    borderRadius: "12px",
                    minWidth: "180px",
                    border: "1px solid",
                    borderColor: "divider",
                    overflow: "hidden",
                  },
                }}
              >
                <Box sx={{ p: 1.5 }}>
                  <Box sx={{ py: 0.5 }}>
                    <Typography
                      sx={{
                        color: "text.secondary",
                        display: "block",
                        fontSize: "10px",
                        textTransform: "uppercase",
                        letterSpacing: 1,
                        mb: 1,
                      }}
                    >
                      Logged in as
                    </Typography>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, color: "text.primary" }}>
                      {userDetails?.data?.userName}
                    </Typography>
                  </Box>
                  <Divider />
                  {isCnms && (
                    <Box
                      onClick={() => {
                        handleClosePopover();
                        setIsPasswordModalOpen(true); // This opens the modal
                      }}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1.5,
                        py: 1,
                        cursor: "pointer",
                        "&:hover": { backgroundColor: "rgba(0, 0, 255, 0.05)" },
                      }}
                    >
                      <Typography sx={{ fontSize: "14px", fontWeight: 500 }}>Change Password</Typography>
                    </Box>
                  )}
                  <Tooltip title="Logout" arrow>
                    <Box
                      onClick={() => {
                        handleClosePopover();
                        setShowLogoutConfirm(true);
                      }}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1.5,
                        py: 1,
                        borderRadius: "8px",
                        cursor: "pointer",
                        transition: "background-color 0.2s",
                        "&:hover": {
                          backgroundColor: "rgba(255, 0, 0, 0.08)",
                        },
                      }}
                    >
                      <LogOut color="red" size={20} />
                      <Typography sx={{ color: "red", fontSize: "14px", fontWeight: 500 }}>
                        Logout
                      </Typography>
                    </Box>
                  </Tooltip>
                </Box>

              </Popover>
            </>
          ) : (
            /* This is the ELSE branch (User NOT logged in) */
            <>
              {/* SOS Logic: Only show if NOT CNMS */}
              {!isCnms && (
                <Box sx={{ mr: 8 }}>
                  <Tooltip title="Emergency SOS" arrow>
                    <SosButton src={sos} alt="SOS" onOpenModal={handleOpenModal} />
                  </Tooltip>
                  <SosModal isOpen={isModalOpen} onClose={handleCloseModal} />
                </Box>
              )}
            </>
          )}

          <Tooltip title={isdarkmode ? "Switch to Light Mode" : "Switch to Dark Mode"}>
            <ThemeSwitch isdarkmode={isdarkmode} toggleTheme={toggleTheme} />
          </Tooltip>
          <Box style={{
            height: "59px",
            width: "75px",


          }}
            component="img"
            src={logoRight}
            alt="Right Logo"

          />
        </Box>
      </Box>

      {loading && <Loader />}

      <MDialog
        open={showLogoutConfirm}
        icon={logout}
        onClose={() => setShowLogoutConfirm(false)}
        title="Confirmation"
        message="Are you are sure you want to logout?"
        confirmText="Yes"
        onConfirm={confirmLogout}
        variant="error"
      />
      <ChangePasswordModal
        open={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        userDetails={userDetails?.data}
        // nmsDetails={nmsDetails}         // Make sure this is defined in your Header via useSelector
        defaultPassword={false}         // Set logic here if needed
        handleLogout={logoutHandler}
      />
    </>
  );
};




export default Header;
