/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Emergency Alert
   File Name                : SOSModal.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Topbar\SOSModal.jsx
   Purpose                  : A modal used to confirm activation from SOS Button 
                               
   Created Date             : 31-03-2026
 ***********************************************************************************************/
import { styled } from "@mui/material/styles";
import {
  IconButton,
  Box,
  Modal,
  Typography,
  CircularProgress,
  Backdrop,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import sos from "@/assets/SVGIcons/SOS.svg";
import { SecurityAxios } from "@/RestAPI/api/axiosApicall";
import { Toast } from "@/components/Reusable/Toast/Toast";
import { ALARM_LOGOUT, CALL_SOS } from "@/RestAPI/url/endpoint";
import { useEffect, useRef, useState } from "react";

// Styled Components
export const SquareIconButton = styled(IconButton)(({ theme }) => ({
  // Light mode: light blue | Dark mode: dark blue/grey
  backgroundColor: theme.palette.mode === 'light' ? "#D7EEFF" : "rgb(62, 59, 59)",
  borderRadius: "20%",
  width: "30px",
  height: "30px",
  padding: "0",
  margin: "0",
  color: theme.palette.text.primary, // Ensures the X icon is visible
  "& .MuiIconButton-root": {
    borderRadius: "0",
  },
  "& .MuiIconButton-icon": {
    fontSize: "12px",
  },
  "&:hover": {
    // Add a slight hover effect for better UX
    backgroundColor: theme.palette.mode === 'light' ? "#BEE3F8" : "#3D3D3D",
  }
}));

const SosModal = ({ isOpen, onClose }) => {
  const [timer, setTimer] = useState(10);
  const [loading, setLoading] = useState(false);
  const canCallRef = useRef(true);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  const { userDetails } = useSelector((state) => state.userSlice);
  const siteDetails = useSelector((state) => state.nodeDetails?.siteDetails);
  const { repDetails } = useSelector((state) => state.nodeDetails);

const siteId=repDetails?.id

  const handleActivate = async () => {
    if (!canCallRef.current) return;
    canCallRef.current = false;
    setLoading(true);

    try {
      const sosPayload = {
        siteId: siteId,
        alertTime: new Date().toISOString(),
      };

      // 1. Call SOS API
      const response = await SecurityAxios(CALL_SOS, "post", sosPayload);

      if (response?.data) {
        Toast("Success", "SOS alarm raised", "success");

        if (location.pathname !== "/") {
          const logoutPayload = {
            userName: userDetails?.data?.userName,
            siteId: userDetails?.data?.rnmsDetailId,
            reason: `user ${userDetails?.data?.userName} logged out due to SOS Alarm raised.`,
          };

          try {
            await SecurityAxios(ALARM_LOGOUT, "post", logoutPayload);
          } catch (err) {
            console.error("Logout API failed", err);
          }

          dispatch({ type: "LOG_OUT" });
          navigate("/");
        }
        onClose();
      } else {
        Toast("Error!", "Failed to raise SOS alarm", "error");
        canCallRef.current = true;
      }
    } catch (error) {
      Toast("Error!", "Failed to raise SOS alarm (Network Error)", "error");
      console.error(error);

      canCallRef.current = true;
    } finally {
      setLoading(false);
    }
  };

  // --- Logic: Countdown Timer ---
  useEffect(() => {
    let interval;
    if (isOpen) {
      setTimer(15);
      canCallRef.current = true;
      interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            onClose(); // Close modal if time runs out without key press
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isOpen, onClose]);

  // --- Logic: Keydown Listener (Ctrl + Shift + Y) ---
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (isOpen && e.ctrlKey && e.shiftKey && e.key === "Y") {
        handleActivate();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, siteDetails, userDetails]);

  return (
    <Modal
    open={isOpen}
    onClose={onClose}
    sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
  >
    <Box
      sx={{
        width: "280px",
        // Applied Theme Color
        backgroundColor: (theme) => theme.palette.custom.sos.modalBg,
        borderRadius: "10px",
        padding: "20px",
        position: "relative",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        // Add a shadow/border for dark mode visibility
        boxShadow: (theme) => theme.palette.mode === 'dark' ? '0 8px 32px rgba(0,0,0,0.5)' : '0 4px 12px rgba(0,0,0,0.1)',
      }}
    >
      {/* Close Button */}
      <Box sx={{ position: "absolute", top: "10px", right: "10px" }}>
        <SquareIconButton onClick={onClose}>
          <span style={{ color: (theme) => theme.palette.custom.sos.accentColor }}>
            &#x2715;
          </span>
        </SquareIconButton>
      </Box>

      <img
        src={sos}
        alt="sos"
        style={{ width: "50px", marginBottom: "10px" }}
      />

      <Typography 
        sx={{ 
          fontWeight: "600", 
          mb: 1, 
          color: (theme) => theme.palette.custom.sos.titleColor 
        }}
      >
        Generate SOS Alarm
      </Typography>

      <Typography 
        sx={{ 
          fontSize: "14px", 
          mb: 2,
          color: (theme) => theme.palette.custom.sos.descriptionColor 
        }}
      >
        Are you sure you want to generate SOS alarm? <br />
        <b style={{ color: (theme) => theme.palette.text.primary }}>Enter the key combination to initiate</b>
      </Typography>

      <Typography
        sx={{
          fontSize: "24px",
          fontWeight: "bold",
          color: (theme) => (timer <= 10 ? theme.palette.custom.sos.timerAlert : theme.palette.custom.sos.timerNormal),
        }}
      >
        00:{String(timer).padStart(2, "0")}
      </Typography>

      <Backdrop
        sx={{
          color: "#fff",
          zIndex: (theme) => theme.zIndex.modal + 1,
          position: "absolute",
          borderRadius: "10px",
        }}
        open={loading}
      >
        <CircularProgress color="inherit" size={30} />
      </Backdrop>
    </Box>
  </Modal>
  );
};

export default SosModal;
