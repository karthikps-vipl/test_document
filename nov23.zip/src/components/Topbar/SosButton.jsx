 /***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : Emergency Trigger
   File Name                : SOSButton.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Reusable\Topbar\SOSButton.jsx
   Purpose                  : A high-priority component designed to trigger emergency protocols 
                               and alert the system when activated by the user.
   Created Date             : 03-03-2026
 ***********************************************************************************************/
import React from 'react';
import { Button } from '@mui/material';

const SosButton = ({ src, alt, onOpenModal }) => {
  // No need for navigate here, we're opening a modal, not navigating
  const handleSos = () => {
    //Call onOpenModal when the component gets clicked
    onOpenModal();
  };

  return (
    <Button
      onClick={handleSos}
      sx={{
        width: '60px',
        height: '80px',
        borderRadius: '50%',
        position: 'absolute',
        top: '50%',
        transform: 'translateY(-50%)',
        img: {
          width: '100%',
          height: '100%',
        },
       
        border: 'none',
        backgroundColor: 'transparent',
      }}
    >
      <img src={src} alt={alt} />
    </Button>
  );
};

export default SosButton;