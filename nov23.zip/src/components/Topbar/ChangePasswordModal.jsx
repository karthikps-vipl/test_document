import React, { useState, useEffect } from "react";

import {
  Visibility,
  VisibilityOff,
  Close as CloseIcon,
} from "@mui/icons-material";
import { encryptData } from "@/utility/encryptLogin";
import MModal from "../Reusable/Modal/MModal";
import MInput from "../Reusable/Input/MInput";
import MButtonSecondary from "../Reusable/Button/MButtonSecondary";
import { SecurityAxios } from "@/RestAPI/api/axiosApicall";
import {
  ALARM_LOGOUT,
  CHANGED_PASSWORD_DEFAULT_SELF_URL,
  CHANGED_PASSWORD_SELF_URL,
} from "@/RestAPI/url/endpoint";
import { Box, Typography } from "@mui/material";
import MDialog from "../Reusable/Dialog/MDialog";
import Toast from "../Reusable/Toast/Toast";
import question_mark from "@/assets/SVGIcons/question_mark.svg";
import { AUTH_URL } from "@/RestAPI/url/baseUrl";

const passwordReg =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#&_^~-])[a-zA-Z\d@#&_^~-]{8,16}$/;

const initialPasswords = {
  password: "",
  confirmPassword: "",
  oldPassword: "",
};

const initialErrors = {
  error: false,
  helperText: "",
  errorOld: false,
  helperTextOld: "",
  errorNew: false,
  helperTextNew: "",
};

const ChangePasswordModal = ({
  open,
  onClose,
  userDetails,
  cnmsStatus,
  nmsDetails,
  defaultPassword,
  handleLogout,
  showCloseButton = true,
}) => {
  const [validatePass, setValidatePass] = useState(initialPasswords);
  const [error, setError] = useState(initialErrors);
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [loading, setLoading] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Reset form whenever the modal is closed.
  useEffect(() => {
    if (!open && !loading) {
      resetForm();
      setShowLogoutConfirm(false);
      setShowOld(false);
      setShowNew(false);
      setShowConfirm(false);
    }
  }, [open, loading]);

  const resetForm = () => {
    setValidatePass({ ...initialPasswords });
    setError({ ...initialErrors });
  };

  // Close the modal and reset the form (triggered by X button, backdrop, or escape)
  const handleClose = () => {
    if (loading) return;

    resetForm();
    setShowLogoutConfirm(false);
    onClose();
  };

  // Validate fields dynamically as the user types
  const handleChange = (e, key) => {
    const value = e.target.value;

    const updated = {
      ...validatePass,
      [key]: value,
    };

    setValidatePass(updated);

    const nextError = { ...initialErrors };

    if (key === "oldPassword" && !value.trim()) {
      nextError.errorOld = true;
      nextError.helperTextOld = "Current Password is required";
    }

    if (key === "password") {
      if (!value) {
        nextError.errorNew = true;
        nextError.helperTextNew = "New Password is required";
      } else if (updated.oldPassword && value === updated.oldPassword) {
        nextError.errorNew = true;
        nextError.helperTextNew =
          "New Password cannot be same as Current Password";
      } else if (!passwordReg.test(value)) {
        nextError.errorNew = true;
        nextError.helperTextNew =
          "Use 8-16 characters with uppercase, lowercase, number, and an allowed special character";
      }
    }

    if (key === "confirmPassword" || key === "password") {
      if (key === "confirmPassword" && !value) {
        nextError.error = true;
        nextError.helperText = "Confirm Password is required";
      } else if (
        updated.confirmPassword &&
        updated.password !== updated.confirmPassword
      ) {
        nextError.error = true;
        nextError.helperText = "Passwords do not match";
      }
    }

    setError((prev) => ({
      ...prev,
      [key === "oldPassword"
        ? "errorOld"
        : key === "password"
        ? "errorNew"
        : "error"]:
        nextError[
          key === "oldPassword"
            ? "errorOld"
            : key === "password"
            ? "errorNew"
            : "error"
        ],
      [key === "oldPassword"
        ? "helperTextOld"
        : key === "password"
        ? "helperTextNew"
        : "helperText"]:
        nextError[
          key === "oldPassword"
            ? "helperTextOld"
            : key === "password"
            ? "helperTextNew"
            : "helperText"
        ],
    }));
  };

  const isSaveDisabled =
    loading ||
    !validatePass.oldPassword.trim() ||
    !validatePass.password ||
    !validatePass.confirmPassword ||
    !passwordReg.test(validatePass.password) ||
    validatePass.password === validatePass.oldPassword ||
    validatePass.password !== validatePass.confirmPassword;

  const handleClear = () => {
    if (loading) return;
    resetForm();
    setShowOld(false);
    setShowNew(false);
    setShowConfirm(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isSaveDisabled) return;
    setShowLogoutConfirm(true);
  };

  const handleConfirmLogout = async () => {
    setShowLogoutConfirm(false);
    setLoading(true);
    const targetUrl = AUTH_URL;
    if (!targetUrl) {
      Toast("Error!", "Auth URL configuration is missing", "error");
      setLoading(false);
      return;
    }

    const payload = {
      userName: userDetails?.userName,
      password: encryptData(validatePass.oldPassword),
      newPassword: encryptData(validatePass.password),
      url: targetUrl,
      rnmsDetailId: nmsDetails?.siteId,
    };

    if (!defaultPassword) {
      payload.id = userDetails?.id;
    }

    try {
      let res;

      if (defaultPassword) {
        res = await SecurityAxios(
          CHANGED_PASSWORD_DEFAULT_SELF_URL,
          "post",
          payload
        );
      } else {
        res = await SecurityAxios(CHANGED_PASSWORD_SELF_URL, "post", payload);
      }

      const responseStatus = res?.data?.status;

      // Handle API status = 0 or explicit failure
      if (
        responseStatus === 0 ||
        responseStatus === false ||
        responseStatus === "0"
      ) {
        // Check if the error message specifically mentions the current password
        const errorMsg = res?.data?.message || "Failed to change password";
        console.log("Error Message:", errorMsg);

        Toast("Error!", errorMsg, "error");
        return;
      }

      Toast(
        "Success!",
        res?.data?.message || "Password changed successfully",
        "success"
      );
      const payload4 = {
        userName: userDetails?.userName,
        siteId: userDetails?.data?.rnmsDetailId,
        reason: `user ${userDetails?.userName} logged out manually`,
      };
      try {
        await SecurityAxios(ALARM_LOGOUT, "post", payload4);
      } catch (logoutError) {
        console.error("Logout API failed:", logoutError);
      }

      resetForm();
      onClose();
      handleLogout();
    } catch (err) {
      console.error("Password change failed:", err);
      Toast(
        "Error!",
        err?.response?.data?.message || "Failed to change the password",
        "error"
      );
    } finally {
      setLoading(false);
    }
  };

  // Helper text styling to enable text-wrapping over multiple lines cleanly
  const helperTextStyleProps = {
    FormHelperTextProps: {
      sx: {
        whiteSpace: "normal",
        wordBreak: "break-word",
        lineHeight: "1.2rem",
        mx: 0,
      },
    },
  };

  return (
    <>
      <MModal
        open={open}
        handleClose={handleClose}
        maxWidth="xs"
        enableFullScreen
        fullWidth
        title="Change Password"
        customWidth={"25%"}
        showCloseButton={showCloseButton}
      >
        <form onSubmit={handleSubmit}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 3,
            }}
          >
            {/* Username */}
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ mb: 0.5 }}>User Name</Typography>
              <MInput
                label="User Name"
                value={userDetails?.userName || ""}
                fullWidth
                disabled
                size="small"
              />
            </Box>

            {/* Current Password */}
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ mb: 0.5 }}>Current Password</Typography>
              <MInput
                label="Current Password"
                type={showOld ? "text" : "password"}
                value={validatePass.oldPassword}
                onChange={(e) => handleChange(e, "oldPassword")}
                error={error.errorOld}
                helperText={error.helperTextOld}
                fullWidth
                required
                size="small"
                autoComplete="current-password"
                {...helperTextStyleProps}
                InputProps={{
                  endAdornment: showOld ? (
                    <Visibility
                      fontSize="small"
                      onClick={() => setShowOld(false)}
                      sx={{ cursor: "pointer" }}
                    />
                  ) : (
                    <VisibilityOff
                      fontSize="small"
                      onClick={() => setShowOld(true)}
                      sx={{ cursor: "pointer" }}
                    />
                  ),
                }}
              />
            </Box>

            {/* New Password */}
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ mb: 0.5 }}>New Password</Typography>
              <MInput
                label="New Password"
                type={showNew ? "text" : "password"}
                value={validatePass.password}
                onChange={(e) => handleChange(e, "password")}
                error={error.errorNew}
                helperText={error.helperTextNew}
                fullWidth
                required
                size="small"
                autoComplete="new-password"
                {...helperTextStyleProps}
                InputProps={{
                  endAdornment: showNew ? (
                    <Visibility
                      fontSize="small"
                      onClick={() => setShowNew(false)}
                      sx={{ cursor: "pointer" }}
                    />
                  ) : (
                    <VisibilityOff
                      fontSize="small"
                      onClick={() => setShowNew(true)}
                      sx={{ cursor: "pointer" }}
                    />
                  ),
                }}
              />
            </Box>

            {/* Confirm New Password */}
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Typography sx={{ mb: 0.5 }}>Confirm New Password</Typography>
              <MInput
                label="Confirm New Password"
                type={showConfirm ? "text" : "password"}
                value={validatePass.confirmPassword}
                onChange={(e) => handleChange(e, "confirmPassword")}
                error={error.error}
                helperText={error.helperText}
                fullWidth
                required
                size="small"
                autoComplete="new-password"
                {...helperTextStyleProps}
                InputProps={{
                  endAdornment: showConfirm ? (
                    <Visibility
                      fontSize="small"
                      onClick={() => setShowConfirm(false)}
                      sx={{ cursor: "pointer" }}
                    />
                  ) : (
                    <VisibilityOff
                      fontSize="small"
                      onClick={() => setShowConfirm(true)}
                      sx={{ cursor: "pointer" }}
                    />
                  ),
                }}
              />
            </Box>
          </Box>

          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              gap: 2,
              mt: 3,
            }}
          >
            <MButtonSecondary
              type="button"
              onClick={handleClear}
              disabled={loading}
              color="secondary"
              startIcon={<CloseIcon />}
            >
              Clear
            </MButtonSecondary>

            <button
              type="submit"
              disabled={isSaveDisabled}
              style={{
                padding: "10px 20px",
                background: isSaveDisabled ? "#9e9e9e" : "#14348d",
                color: "white",
                border: "none",
                borderRadius: "10px",
                cursor: isSaveDisabled ? "not-allowed" : "pointer",
                opacity: isSaveDisabled ? 0.7 : 1,
              }}
            >
              Save
            </button>
          </Box>
        </form>
      </MModal>

      <MDialog
        open={showLogoutConfirm}
        onClose={() => {
          if (!loading) {
            setShowLogoutConfirm(false);
          }
        }}
        title="Confirmation"
        message="Changing your password will require you to log in again. Are you sure you want to proceed?"
        confirmText="Yes"
        onConfirm={handleConfirmLogout}
        variant="warning"
        icon={question_mark} // Ensure question_mark is imported
      />
    </>
  );
};

export default ChangePasswordModal;
