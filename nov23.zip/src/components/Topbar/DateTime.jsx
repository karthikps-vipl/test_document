/***********************************************************************************************
   Project                  : IAF-NMS
   SubSystem                : DateTime Picker
   File Name                : DateTime.jsx
   Author                   : ANKITHA - VIPL
   Package                  : src\components\Topbar\DateTime.jsx
   Purpose                  : A reusable component providing a standardized interface for 
                               users to select and input date and time values.
   Created Date             : 03-03-2026
 ***********************************************************************************************/
   import { useState, useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import { useTheme } from '@mui/system';

const DateTime = () => {
  const [dateTime, setDateTime] = useState(new Date());
  const theme = useTheme();

  useEffect(() => {
    const interval = setInterval(() => {
      setDateTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // 1. Format Date: 01 Jan 2024 format
  const formattedDate = dateTime.toLocaleDateString("en-GB", {
    day: "2-digit",   // Ensures 01 instead of 1
    month: "short",   // Keeps "Jan", "Feb" etc.
    year: "numeric",
  });

  // 2. Format Time: 01:02:03 PM format
  const formattedTime = dateTime.toLocaleTimeString("en-US", {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,      // Enables AM/PM
  });

  return (
    <Box sx={{
      padding: 1,
      display: 'flex',
      width: '100%',
      alignItems: 'center',
      flexWrap: 'wrap'
    }}>
      <Typography sx={{
        color: 'text.primary',
        fontSize: '16px',
        [theme.breakpoints.down('sm')]: {
          fontSize: '0.7rem', // Increased from 0.2rem as 0.2 is nearly invisible
        },
      }}>
        {formattedDate}
      </Typography>
      <Typography sx={{
        color: 'text.primary',
        ml: 2,
        fontSize: '16px',
        [theme.breakpoints.down('sm')]: {
          fontSize: '0.7rem', // Increased from 0.2rem
        },
      }}>
        {formattedTime}
      </Typography>
    </Box>
  );
};

export default DateTime;