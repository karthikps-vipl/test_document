import React, { useState, useMemo, useCallback, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  Pagination,
  Select,
  MenuItem,
  Box,
  Typography,
  Stack,
  Menu,
  ListItemIcon,
  ListItemText,
  Checkbox,
  InputAdornment,
  useTheme,
  Popover,
} from "@mui/material";
import {
  // Search as SearchIcon,
  // Visibility as ViewIcon,
  // History as HistoryIcon,
  // VpnKey as KeyIcon,
  PictureAsPdf as PdfIcon,
  TableChart as CsvIcon,
  // GetApp as DownloadIcon,
  Fullscreen,
  FullscreenExit,
  Done,
  Block,
  TrendingUp,
  Refresh,
} from "@mui/icons-material";
import MButtonPrimary from "../Button/MButtonPrimary";
import MInput from "../Input/MInput";
import End_Icon from "@/assets/SVGIcons/End_Icon.svg";
import Ack_Tick_Icon from "@/assets/SVGIcons/Ack_Tick_Icon_org.svg";
import Raise_Ticket_Icon from "@/assets/SVGIcons/Raise_Ticket_Icon.svg";
import Disable_Password_b from "@/assets/SVGIcons/Disable_Password_b.svg";
import ContextMenuAlarm from "@/Pages/Rnmsdashboard/FAult/components/AlarmContextMenu";
import AckTable from "@/Pages/Rnmsdashboard/FAult/components/AckTable";
import ViewAugmentation from "@/Pages/Rnmsdashboard/FAult/components/VIewAugmentation";
import download from "@/assets/SVGIcons/download.svg";
import delete_r from "@/assets/SVGIcons/delete.svg";
import Edit_Icon_g from "@/assets/SVGIcons/Edit_Icon_g.svg";
import History_action from "@/assets/SVGIcons/History_action.svg";
import Help_Desk_Closed_action from "@/assets/SVGIcons/Help_Desk_Closed_action.svg";
import Help_Desk_Reopen_action from "@/assets/SVGIcons/Help_Desk_Reopen_action.svg";
import change_password from "@/assets/SVGIcons/cnms/change_password.svg";
import Reset_password from "@/assets/SVGIcons/cnms/password.svg";

import Help_Desk_View from "@/assets/SVGIcons/Help_Desk_View.svg";
import Help_Desk_View_rotate from "@/assets/SVGIcons/Help_Desk_View_rotate.svg";
import Confirmation_icon from "@/assets/SVGIcons/question_mark.svg";
import Certificate_Download from "@/assets/SVGIcons/Certificate_Download.svg";
import { Close as CloseIcon } from "@mui/icons-material";
import ProgressIcon from "@/assets/SVGIcons/Help_Desk_Ongoing.svg";

import EndTable from "@/Pages/Rnmsdashboard/FAult/components/EndTable";
import { FilterMenu } from "@/utility/customHooks/FilterMenu";
import { FilterIcon, Search } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import dayjs from "dayjs";
import {
  auditSeverityMap,
  formatDateTime,
  networkStatusConfig,
  severityConfig,
  syslogSeverityConfig,
} from "@/lib/utils";
import { SquareIconButton } from "../Modal/MModal";
import Collapse from "@mui/material/Collapse";
import ScrollContainer from "../Scrollbar/ScrollContainer";
import useUniversalSearch from "../Search/useUniversalSearch";
import MDialog from "../Dialog/MDialog";
import Toast from "../Toast/Toast";
import PendingIcon from "@/assets/SVGIcons/Help_Desk_Pending.svg";
import ResolvedIcon from "@/assets/SVGIcons/Help_Desk_Resolved.svg";

import {
  CREATE_TICKET,
  FETCH_CNMS_ADDRESS_DETAILS,
  UPDATE_HD_TICKET_STATUS,
} from "@/RestAPI/url/endpoint";
import {
  FaultAxios,
  HelpDeskAxios,
  InventAxios,
} from "@/RestAPI/api/axiosApicall";
import { updateSingleAlarm } from "@/store/features/Fault/alarmSlice";

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

const MTable = ({
  tableTitle = "",
  privilegeKey,
  columns = [],
  tableData = [],
  showSearch = false,
  showExportButton = false,
  // Show it for this specific table
  onExportClick, // The function you wrote earlier
  exportIcon,
  AddText = "",
  handleAdd,
  showRemove = false,
  removeText = "",
  onRemoveClick,
  removeDisabled = true,
  isRemoveDisabled,
  handleDownloadPDF,
  handleDownloadCSV,
  handleView,
  handleEdit,
  handleDelete,
  handleDownload,
  handleRefresh = false,
  onRefreshClick,
  handleHistory,
  handleChangePasswordClick,
  handleBlock,
  addDisable,
  showOptions,
  hideAdd = true,
  showPagination = false,
  addIcon = false,
  showVisibleContent = false,
  showMaximazed = false,
  showSelect = false,
  alarmSearch = false,
  VisibleContent,
  customDropdown,
  customDropdown1,
  customButton,
  isMaximized,
  handleClose,
  closeIcon,
  toggleMaximize,
  handleCloseAction,
  handleReopenAction,
  handleResetPasswordClick,
  data,
  typeHeight,
  deleteDisable,
  editDisable,
  configHeight,
  // NEW GENERIC SELECTION
  enableRowSelection = false,
  selectedRowsNew = new Set(),
  onRowSelect,
  onSelectAll,
  rowIdKey = "id",
  isCollapsible = false,
  renderCollapseContent, // Function prop: (row) => JSX (if you want custom content)
  collapseColumns = [], // Columns structure for the sub-table
  collapseDataKey = "subRows", // The key in your row data containing the API array
  advancedSearch = false,
  // NEW
  enableColumnSearch = false,
  blockDisable,
  blockColor,
  onRowContextMenu,
  // Generic header actions (CNMS)
  headerActions,
  showHeaderActions = false,
  handleInProgressAction,
  handlePendingAction,
  handleResolvedAction,
  tableHeader = <></>,
  handleFilter = false,
  filterMenu,
  disabled = false
}) => {
  const [filterValue, setFilterValue] = useState("");
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [anchorEl, setAnchorEl] = useState(null);
  const openMenu = Boolean(anchorEl);
  const [columnFilters, setColumnFilters] = useState({});
  const [filteredAdvancedData, setFilteredAdvancedData] = useState(tableData);

  const [selectedKeys, setSelectedKeys] = React.useState(new Set());
  const [selectedAlarmId, setSelectedAlarmId] = useState([]);
  const { isReadOnlyMode, isUserLoggedIn } = useSelector(
    (state) => state.userSlice
  );
  const isDisabled =
    disabled || (isUserLoggedIn && isReadOnlyMode);
  // const [editRow, setEditRow] = useState(null); // Row being edited
  // const [isEditOpen, setIsEditOpen] = useState(false);
  const [isFilterVisible, setIsFilterVisible] = useState(false);

  // const [deleteRow, setDeleteRow] = useState(null); // Row being deleted
  // const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [expandedRows, setExpandedRows] = useState({});
  const [columnSearchValues, setColumnSearchValues] = useState({});
  const dispatch = useDispatch();
  const toggleRow = (id) =>
    setExpandedRows((prev) => ({ ...prev, [id]: !prev[id] }));

  const [contextMenu, setContextMenu] = useState({
    open: false,
    x: 0,
    y: 0,
    node: null,
  });
  // const toggleFilter = () => {
  //   setIsFilterVisible(!isFilterVisible);
  // };

  const [isOpen, setIsOpen] = useState(false);
  const [Key, setKey] = useState(false);

  const [showTicketConfirm, setShowTicketConfirm] = useState(false);
  const [ticketAlarm, setTicketAlarm] = useState(null);
  const [raisingTicket, setRaisingTicket] = useState(false);
  const [ackData, setAckData] = useState([]);

  const handleOpenMenu = (event) => setAnchorEl(event.currentTarget);
  const handleCloseMenu = () => setAnchorEl(null);
  const handleFilterClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const workflowMap = { 2: "END", 1: "ACK", 0: "NOT_ACK" };
  const alarmStateMap = { 0: "CLEARED", 1: "RAISED" };

  // Filter
  const handleFilterChange = (columnUid, selectedValues) => {
    setColumnFilters((prev) => ({
      ...prev,
      [columnUid]: selectedValues,
    }));
    setPage(1);
  };
  const sourceData = advancedSearch ? filteredAdvancedData : tableData;
  const debouncedSearchValue = useDebounce(filterValue, 100);
  const universalSearchData = useUniversalSearch(
    sourceData,
    debouncedSearchValue,
    columns
  );

  // Sync internal table state if parent tableData shifts/refreshes out-of-band
  useEffect(() => {
    setFilteredAdvancedData(tableData);
  }, [tableData]);

  const handleColumnSearchChange = useCallback((columnUid, value) => {
    setColumnSearchValues((prev) => ({
      ...prev,
      [columnUid]: value,
    }));

    // Always go back to first page when filtering
    setPage(1);
  }, []);

  const finalFilteredData = useMemo(() => {
    return universalSearchData.filter((row) => {
      // --------------------------------
      // COLUMN-WISE TEXT SEARCH
      // --------------------------------
      if (enableColumnSearch) {
        const matchesColumnSearch = Object.entries(columnSearchValues).every(
          ([columnUid, searchValue]) => {
            if (!searchValue?.trim()) {
              return true;
            }

            const column = columns.find((col) => col.uid === columnUid);

            if (!column) {
              return true;
            }

            const rawValue =
              row[columnUid] ?? row[column.oid] ?? row[column.name] ?? "";

            const searchText = searchValue.trim().toLowerCase();

            // --------------------------------
            // Severity display value
            // --------------------------------
            if (columnUid === "severity") {
              const severityMap = {
                1: "minor",
                2: "major",
                0: "warning",
                "-1": "normal",
              };

              const displayValue =
                severityMap[String(rawValue)] || String(rawValue);

              return displayValue.toLowerCase().includes(searchText);
            }

            // --------------------------------
            // Workflow display value
            // --------------------------------
            if (columnUid === "workflow") {
              const workflowMap = {
                0: "not_ack",
                1: "ack",
                2: "end",
              };

              const displayValue =
                workflowMap[String(rawValue)] || String(rawValue);

              return displayValue.toLowerCase().includes(searchText);
            }

            // --------------------------------
            // Alarm State display value
            // --------------------------------
            if (
              columnUid === "alarmState" ||
              columnUid === "currentAlarmState"
            ) {
              const stateMap = {
                0: "cleared",
                1: "raised",
              };

              const displayValue =
                stateMap[String(rawValue)] || String(rawValue);

              return displayValue.toLowerCase().includes(searchText);
            }

            // --------------------------------
            // Normal text search
            // --------------------------------
            return String(rawValue).toLowerCase().includes(searchText);
          }
        );

        if (!matchesColumnSearch) {
          return false;
        }
      }
      const matchesColumnFilters = Object.keys(columnFilters).every((field) => {
        let selectedValues = columnFilters[field];

        // No filter
        if (!selectedValues) {
          return true;
        }

        // Make sure it is always an array
        if (!Array.isArray(selectedValues)) {
          selectedValues = [selectedValues];
        }

        // Empty filter
        if (selectedValues.length === 0) {
          return true;
        }

        const rawValue = row[field];

        // --------------------------------
        // Direct match
        // --------------------------------
        if (selectedValues.includes(rawValue)) {
          return true;
        }

        // --------------------------------
        // Severity
        // --------------------------------
        if (field === "severity") {
          const severityMap = {
            Minor: 1,
            Major: 2,
            Warning: 0,
            Normal: -1,
          };

          return selectedValues.some(
            (val) =>
              rawValue === severityMap[val] || String(rawValue) === String(val)
          );
        }

        // --------------------------------
        // Workflow
        // --------------------------------
        if (field === "workflow") {
          const workLabel = {
            NOT_ACK: 0,
            ACK: 1,
            END: 2,
          };

          return selectedValues.some(
            (val) =>
              rawValue === workLabel[val] || String(rawValue) === String(val)
          );
        }

        // --------------------------------
        // Alarm State
        // --------------------------------
        if (field === "alarmState" || field === "currentAlarmState") {
          const stateLabel = {
            CLEARED: 0,
            RAISED: 1,
          };

          return selectedValues.some(
            (val) =>
              rawValue === stateLabel[val] || String(rawValue) === String(val)
          );
        }

        // --------------------------------
        // Status
        // --------------------------------
        if (field === "status") {
          const statusLabel = {
            Open: 1,
            "In-Progress": 2,
            Pending: 3,
            Resolved: 4,
            Closed: 5,
            Reopen: 6,
          };

          return selectedValues.some(
            (val) =>
              rawValue === statusLabel[val] ||
              String(rawValue).toLowerCase() === String(val).toLowerCase()
          );
        }

        // --------------------------------
        // Boolean fields
        // --------------------------------
        if (field === "isForwardHigherNms" || field === "isLocalProcessing") {
          return selectedValues.some((val) => rawValue === (val === "Yes"));
        }

        // --------------------------------
        // Priority
        // --------------------------------
        if (field === "priority") {
          const priorityString =
            row.hdTicketPriority?.priority || row.priority || "";

          return selectedValues.some(
            (val) =>
              String(priorityString).toUpperCase() === String(val).toUpperCase()
          );
        }

        // --------------------------------
        // Date / Time
        // --------------------------------
        if (
          field === "dateTime" ||
          field === "CreatedAt" ||
          field === "createdAt"
        ) {
          return selectedValues.some((val) => {
            if (!rawValue) {
              return false;
            }

            return (
              dayjs(rawValue).format("YYYY-MM-DD") ===
                dayjs(val).format("YYYY-MM-DD") ||
              String(rawValue).startsWith(String(val))
            );
          });
        }

        // --------------------------------
        // Generic fallback
        // --------------------------------
        const cellValueStr = String(rawValue ?? "").toLowerCase();

        return selectedValues.some((val) =>
          cellValueStr.includes(String(val).toLowerCase())
        );
      });

      return matchesColumnFilters;
    });
  }, [
    universalSearchData,
    columnFilters,
    enableColumnSearch,
    columnSearchValues,
    columns,
  ]);

  const filteredItems = useMemo(() => {
    return tableData.filter((row) => {
      // Loop over each column filter object state
      for (const key in columnFilters) {
        const filterValues = columnFilters[key];
        if (!filterValues || filterValues.length === 0) continue;

        // Find the structural settings for this column
        const targetColumn = columns.find((col) => col.uid === key);

        if (targetColumn?.filterType === "datetime") {
          // If the user selected a target date, capture it using Dayjs
          const selectedDateStr = filterValues[0];
          const rowDateValue = row[key];

          if (!rowDateValue) return false;

          // Check if the row date lands on the exact calendar day selected by user
          const isSameDay = dayjs(rowDateValue).isSame(
            dayjs(selectedDateStr),
            "day"
          );

          if (!isSameDay) return false;
        } else if (!filterValues.includes(row[key])) {
          // Standard dropdown string array behavior
          // if (!filterValues.includes(row[key])) {
          //   return false;
          // }
          return false;
        }
      }
      return true;
    });
  }, [tableData, columnFilters, columns]);

  const paginatedItems = useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    return finalFilteredData.slice(start, start + rowsPerPage);
  }, [page, rowsPerPage, finalFilteredData]);
  // GENERIC SELECT ALL
  const isAllRowsSelected =
    finalFilteredData.length > 0 &&
    finalFilteredData.every((row) =>
      selectedRowsNew.has(String(row[rowIdKey]))
    );

  // const isIndeterminateRows =
  //   selectedRowsNew.size > 0 && selectedRowsNew.size < finalFilteredData.length;
  const selectedVisibleRowCount = finalFilteredData.filter((row) =>
    selectedRowsNew.has(String(row[rowIdKey]))
  ).length;

  const isIndeterminateRows =
    selectedVisibleRowCount > 0 &&
    selectedVisibleRowCount < finalFilteredData.length;
  const onSearchChange = useCallback((event) => {
    setFilterValue(event.target.value);
    setPage(1);
  }, []);

  const getColumnStyle = (col) => {
    return {
      width: col.width || "auto",
      minWidth: col.width || "150px",
      maxWidth: col.width || "auto",
    };
  };
  const renderActions = (row) => {
    // 1. Define the condition: only allow if status is 'Resolved'
    // We use .toLowerCase() to ensure it works even if the API returns 'resolved'
    const isBlockedUser = row?.isBlocked;
    const tooltipTitle = isBlockedUser ? "Unblock User" : "Block User";
    const getStatusText = (r) =>
      (r?.hdTicketStatus?.statusName || r?.status || "").toLowerCase().trim();
    const status = getStatusText(row);
    const isClosed = status === "closed";
    const isOpen = status === "open";
    const isPending = status === "pending";
    const isInProgress = status === "in-progress";
    const isResolved = status === "resolved";

    const colorState =
      blockDisable && blockDisable(row)
        ? "default"
        : blockColor
        ? blockColor(row)
        : "success";
    const getFilter = (isDisabled) =>
      isDisabled ? "grayscale(1) opacity(0.5)" : "none";

    return (
      <Stack direction="row">
        {handleView && (
          <Tooltip title="View">
            <IconButton onClick={() => handleView(row)}>
              <img
                src={Disable_Password_b}
                style={{ width: "23px", height: "23px", objectFit: "contain" }}
                alt="view"
              />
            </IconButton>
          </Tooltip>
        )}

        {showOptions && (
          <Tooltip title="Actions">
            <IconButton onClick={() => showOptions(row)}>
              <img
                src={Disable_Password_b}
                style={{ width: "23px", height: "23px", objectFit: "contain" }}
                alt="view"
              />
            </IconButton>
          </Tooltip>
        )}
{handleEdit && (
  <Tooltip title="Edit">
    <IconButton
      onClick={() => handleEdit(row)}
      disabled={
        disabled || 
        (isUserLoggedIn && isReadOnlyMode) || 
        (typeof editDisable === "function" ? editDisable(row) : !!editDisable)
      }
    >
      <img
        src={Edit_Icon_g}
        style={{
          width: "23px",
          height: "23px",
          objectFit: "contain",
          filter:
            disabled || 
            (isUserLoggedIn && isReadOnlyMode) || 
            (typeof editDisable === "function" ? editDisable(row) : !!editDisable)
              ? "grayscale(1) opacity(0.5)"
              : "none",
        }}
        alt="edit"
      />
    </IconButton>
  </Tooltip>
)}

        {/* {handleEdit && (
          <Tooltip title="Edit">
            <IconButton
              onClick={() => handleEdit(row)}
               
              disabled={
                typeof editDisable === "function"
                  ? editDisable(row)
                  : !!editDisable
              }
            >
              <img
                src={Edit_Icon_g}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                
                  filter: (
                    typeof editDisable === "function"
                      ? editDisable(row)
                      : !!editDisable
                  )
                    ? "grayscale(1) opacity(0.5)"
                    : "none",
                }}
                alt="edit"
              />
            </IconButton>
          </Tooltip>
        )} */}
        {handleHistory && (
          <Tooltip title="History">
            <IconButton onClick={() => handleHistory(row)}>
              <img
                src={History_action}
                style={{
                  width: " 23px",
                  height: " 23px",
                  objectFit: "contain",
                }}
                alt="edit"
              />
            </IconButton>
          </Tooltip>
        )}

        {/* UPDATED REOPEN ACTION */}
        {handleReopenAction && (
          <Tooltip
            title={
              !isClosed && !isResolved
                ? "Only Closed/Resolved tickets can be reopened"
                : "Reopen"
            }
          >
            <IconButton
              onClick={() => handleReopenAction(row)}
              // ENABLED if Closed OR Resolved
              disabled={!isClosed && !isResolved}
            >
              <img
                src={Help_Desk_Reopen_action}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                  filter:
                    !isClosed && !isResolved
                      ? "grayscale(1) opacity(0.5)"
                      : "none",
                }}
                alt="reopen"
              />
            </IconButton>
          </Tooltip>
        )}

        {handleCloseAction && (
          <Tooltip title={isOpen ? "Cannot close an open ticket" : "Close"}>
            <IconButton
              onClick={() => handleCloseAction(row)}
              disabled={isOpen || !isResolved} // Only enabled when status is Resolved
            >
              <img
                src={Help_Desk_Closed_action}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                  filter: getFilter(isOpen || !isResolved),
                }}
                alt="close"
              />
            </IconButton>
          </Tooltip>
        )}

        {/* 5. IN-PROGRESS: Enabled only if Open */}
        {handleInProgressAction && (
          <Tooltip title="In Progress">
            <IconButton
              onClick={() => handleInProgressAction(row)}
              disabled={!isOpen}
            >
              <img
                src={ProgressIcon}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                  filter: getFilter(!isOpen),
                }}
                alt="in-progress"
              />
            </IconButton>
          </Tooltip>
        )}

        {/* 6. PENDING: Enabled only if Open */}
        {handlePendingAction && (
          <Tooltip title="Pending">
            <IconButton
              onClick={() => handlePendingAction(row)}
              disabled={!isOpen}
            >
              <img
                src={PendingIcon}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                  filter: getFilter(!isOpen || isResolved),
                }}
                alt="pending"
              />
            </IconButton>
          </Tooltip>
        )}

        {/* 7. RESOLVED: Enabled if Open, Pending, or In-Progress */}
        {handleResolvedAction && (
          <Tooltip title="Resolve">
            <IconButton
              onClick={() => handleResolvedAction(row)}
              disabled={!(isOpen || isPending || isInProgress)}
            >
              <img
                src={ResolvedIcon}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                  filter: getFilter(!(isOpen || isPending || isInProgress)),
                }}
                alt="resolved"
              />
            </IconButton>
          </Tooltip>
        )}
        {handleResetPasswordClick && (
          <Tooltip title="Reset Password">
            <IconButton
              onClick={() => handleResetPasswordClick(row)}
              sx={{ p: 1 }}
            >
              <img
                src={Reset_password}
                style={{
                  width: " 23px",
                  height: " 23px",
                  objectFit: "contain",
                  filter: isDark ? "invert(1)" : "none",
                }}
                alt="close"
              />
            </IconButton>
          </Tooltip>
        )}

        {handleChangePasswordClick && (
          <Tooltip title="Change Password">
            <IconButton
              onClick={() => handleChangePasswordClick(row)}
              sx={{ p: 1 }}
            >
              <img
                src={change_password}
                style={{
                  width: " 23px",
                  height: " 23px",
                  objectFit: "contain",
                  filter: isDark ? "invert(1)" : "none",
                }}
              />
            </IconButton>
          </Tooltip>
        )}
        {handleBlock && (
          <Tooltip title={tooltipTitle} arrow>
            <span>
              {" "}
              {/* Span is required to allow Tooltip on disabled elements */}
              <IconButton
                disabled={blockDisable ? blockDisable(row) : false}
                color={colorState}
                onClick={() => handleBlock && handleBlock(row)}
                size="small"
              >
                <Block />
              </IconButton>
            </span>
          </Tooltip>
        )}
{handleDelete && (
  <Tooltip title="Delete">
    <IconButton
      color="error"
      onClick={() => handleDelete(row)}
      disabled={
        disabled || 
        (isUserLoggedIn && isReadOnlyMode) || 
        (typeof deleteDisable === "function" ? deleteDisable(row) : !!deleteDisable)
      }
    >
      <img
        src={delete_r}
        style={{
          width: "23px",
          height: "23px",
          objectFit: "contain",
          filter:
            disabled || 
            (isUserLoggedIn && isReadOnlyMode) || 
            (typeof deleteDisable === "function" ? deleteDisable(row) : !!deleteDisable)
              ? "grayscale(1) opacity(0.5)"
              : "none",
        }}
        alt="delete"
      />
    </IconButton>
  </Tooltip>
)}

     
{/* 
        {handleDelete && (
          <Tooltip title="Delete">
            <IconButton
              color="error"
              onClick={() => handleDelete(row)}
         
              disabled={
                typeof deleteDisable === "function"
                  ? deleteDisable(row)
                  : !!deleteDisable
              }
            >
              <img
                src={delete_r}
                style={{
                  width: "23px",
                  height: "23px",
                  objectFit: "contain",
                  filter: (
                    typeof deleteDisable === "function"
                      ? deleteDisable(row)
                      : !!deleteDisable
                  )
                    ? "grayscale(1) opacity(0.5)"
                    : "none",
                }}
                alt="delete"
              />
            </IconButton>
          </Tooltip>
        )} */}
        {handleDownload && (
          <IconButton onClick={() => handleDownload(row)}>
            <img
              src={Certificate_Download} // Ensure this icon is imported
              style={{ width: "23px", height: "23px", objectFit: "contain" }}
              alt="download"
            />
          </IconButton>
        )}
      </Stack>
    );
  };
  const renderCellValue = (col, row) => {
    if (typeof col.render === "function") {
      return col.render(row[col.uid], row);
    }
    if (typeof col.cell === "function") {
      return col.cell(row);
    }

    if (col.uid === "severity") {
      const sevKey =
        row.severity !== undefined && row.severity !== null
          ? String(row.severity)
          : "";

      const config =
        col.severityType === "syslog"
          ? syslogSeverityConfig[sevKey]
          : severityConfig[sevKey];

      if (!config) {
        return <div>{row.severity ?? "N/A"}</div>;
      }

      const backgroundStyle = `linear-gradient(
        135deg,
        ${config.gradient[0]},
        ${config.gradient[1]}
      )`;

      return (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <span
            style={{
              background: backgroundStyle,
              width: 12,
              height: 12,
              borderRadius: "50%",
              display: "inline-block",
              flexShrink: 0,
            }}
          />

          <span>{config.label}</span>
        </div>
      );
    }

    const isStatusColumn =
      col.oid === ".1.3.6.1.2.1.2.2.1.7" ||
      col.oid === ".1.3.6.1.2.1.2.2.1.8" ||
      col.name?.trim() === "Admin status" ||
      col.name?.trim() === "Admin Status" ||
      col.name?.trim() === "Op Status" ||
      col.name?.trim() === "Operational Status" ||
      col.name?.trim() === "Operational status" ||
      col.name?.trim() === "Op status";

    if (isStatusColumn) {
      // Extract the value dynamically matching the column key or OID mapping
      const rawValue = row[col.uid] || row[col.name] || row[col.oid];

      const statusKey =
        rawValue !== undefined && rawValue !== null
          ? String(rawValue).toLowerCase().trim()
          : "";

      const statusConfig = networkStatusConfig[statusKey];

      // Fallback if the value doesn't match known states
      if (!statusConfig) return <div>{rawValue}</div>;

      const backgroundStyle = `linear-gradient(135deg, ${statusConfig.gradient[0]}, ${statusConfig.gradient[1]})`;

      return (
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span
            style={{
              background: backgroundStyle,
              width: 12,
              height: 12,
              borderRadius: "50%",
              display: "inline-block",
              flexShrink: 0,
            }}
          />
          <span>{statusConfig.label}</span>
        </div>
      );
    }

    if (col.uid === "auditLogLvl") {
      // Uses the global auditSeverityMap mapped out above
      const sev = auditSeverityMap[row.auditLogLvl];

      if (!sev) return <div>Unknown Severity ({row.auditLogLvl})</div>;

      return (
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span
            style={{
              background: `linear-gradient(135deg, ${sev.gradient[0]}, ${sev.gradient[1]})`,
              // background: sev.color,
              width: 10,
              height: 10,
              borderRadius: "50%",
              display: "inline-block",
            }}
          />
          {sev.label}
        </div>
      );
    }
    if (col.uid === "facilityString") {
      return <div>{row.facilityString || "N/A"}</div>;
    }
    if (col.uid === "forward" || col.uid === "process") {
      const val = row[col.uid];
      const labelMap = {
        forward: "CNMS",
        process: "RNMS",
      };
      return <span>{labelMap[val] || val}</span>;
    }
    if (col.uid === "workflow") {
      return workflowMap[row[col.uid]] || "Unknown";
    }
    if (col.uid === "alarmState" || col.uid === "currentAlarmState") {
      return alarmStateMap[row[col.uid]] || "Unknown";
    }

    const value = row[col.uid];
    if (col.uid === "dateTime" || col.searchDate === true) {
      return formatDateTime(value);
    }
    if (col.render) {
      return col.render(row[col.uid], row);
    }

    if (col.uid === "sno") {
      return (page - 1) * rowsPerPage + 1; // (Simplified for example)
    }
    return row[col.uid];
  };

  const handleContextMenu = useCallback(
    (e, item) => {
      e.preventDefault();

      if (selectedKeys.size === 0) return;
      console.log(selectedKeys, "selectedKeys");
      if (!selectedKeys.has(item.alarmId)) return;

      setContextMenu({
        open: true,
        x: e.clientX,
        y: e.clientY,
        node: item,
      });
    },
    [selectedKeys]
  );

  const selectedRows = useMemo(() => {
    return filteredItems.filter((row) => selectedKeys.has(row.alarmId));
  }, [filteredItems, selectedKeys]);

  // const selectionMeta = useMemo(() => {
  //   if (selectedRows.length === 0) return null;

  //   const workflows = selectedRows.map((r) => r.workflow);

  //   const hasAck = workflows.includes(1);
  //   const hasNotAck = workflows.includes(0);
  //   const alarmCount = selectedRows[0]?.alarmCount > 1;
  //   console.log("selectedRows", selectedRows[0]?.alarmCount);
  //   return {
  //     count: alarmCount,
  //     isSingle: selectedRows.length === 1,
  //     isMultiSelect: selectedRows.length > 1,
  //     hasAck, // Pass these flags directly
  //     hasNotAck,
  //   };
  // }, [selectedRows]);
  const selectionMeta = useMemo(() => {
    if (selectedRows.length === 0) return null;

    const workflows = selectedRows.map((r) => r.workflow);

    const hasAck = workflows.includes(1);
    const hasNotAck = workflows.includes(0);
    const alarmCount = selectedRows[0]?.alarmCount > 1;

    const isSingle = selectedRows.length === 1;

    const isTicketRaised = isSingle
      ? Boolean(selectedRows[0]?.isTicketRaised)
      : false;

    return {
      count: alarmCount,
      isSingle,
      isMultiSelect: selectedRows.length > 1,
      hasAck,
      hasNotAck,
      isTicketRaised,
    };
  }, [selectedRows]);
  const finalSelectedRows = useMemo(() => {
    return selectedRows;
  }, [selectedRows]);
  const onAction = useCallback(
    (action) => {
      let targetRows = [];

      if (action === "ACK") {
        targetRows = finalSelectedRows.filter((r) => r.workflow === 0);
      } else if (action === "END") {
        targetRows = finalSelectedRows.filter((r) => r.workflow === 1);
      } else {
        targetRows = finalSelectedRows;
      }

      const selectedIds = targetRows.map((r) => r.alarmId);

      switch (action) {
        case "ACK":
          setIsOpen(true);
          setKey("ALARM1");
          setAckData(targetRows);
          break;
        case "END":
          setIsOpen(true);
          setKey("ALARM2");
          setAckData(targetRows);
          setSelectedAlarmId(selectedIds);
          break;
        case "VIEW":
          setIsOpen(true);
          setKey("ALARM3");
          setAckData(targetRows);
          break;
        case "TICKET":
          if (targetRows.length === 1 && !targetRows[0]?.isTicketRaised) {
            setTicketAlarm(targetRows[0]);
            setShowTicketConfirm(true);
          }
          break;
        default:
          break;
      }
    },
    [finalSelectedRows]
  );
  const handleCloseModal = () => {
    setIsOpen(false);
    setAckData(null);
    setKey("");
  };
  const closeMenu = () => setContextMenu((m) => ({ ...m, open: false }));

  const handleSelectRow = (row, checked) => {
    setSelectedKeys((prev) => {
      const newSet = new Set(prev);
      if (checked) {
        newSet.add(row.alarmId); // or row.alarmId if that's your key
      } else {
        newSet.delete(row.alarmId);
      }
      return newSet;
    });
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      const allIds = filteredItems.map((row) => row.alarmId);
      setSelectedKeys(new Set(allIds));
    } else {
      setSelectedKeys(new Set());
    }
  };

  useEffect(() => {
    const handleClick = () => closeMenu();
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);

  useEffect(() => {
    setSelectedKeys(new Set());
  }, [tableData]);

  const userDetails = useSelector((state) => state.userSlice.userDetails?.data);

  const userName = userDetails?.userName || "NA";

  const privileges = userDetails?.group?.privileges || [];

  // 1. Find the raw title
  const reduxTitleRaw = privileges.find(
    (p) => p.key === privilegeKey
  )?.privilegeName;

  // 2. Helper function to handle the specific uppercase requirements
  // This uses a Regex with the 'gi' flag (global, case-insensitive)
  const formatSpecialTerms = (str) => {
    if (!str) return str;
    return str.replace(/url/gi, "URL").replace(/ip/gi, "IP");
  };

  // 3. Apply the formatting to the final title logic
  const reduxTitle = formatSpecialTerms(reduxTitleRaw);
  const finalTitle = formatSpecialTerms(tableTitle || reduxTitle || " ");

  const isExportDisabled = tableData.length <= 0;
  const displayItems = showPagination ? paginatedItems : finalFilteredData;
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";

  // const config_Height =
  //   typeHeight === "configuration" ? "240px" : "calc(100vh - 610px)";

  // -----------------WORKING ONE---------
  // const config_Height =
  // typeHeight === "configuration"
  //   ? configHeight ?? "240px"
  //   : "calc(100vh - 610px)";
  // ===================
  // Calculate the height based on typeHeight
  const config_Height =
    typeHeight === "configuration"
      ? configHeight ?? "240px"
      : typeHeight === "siteSummaryTable"
      ? " 280px"
      : typeHeight === "hubTable"
      ? "auto"
      : "calc(100vh - 610px)"; // Default fallback
  const port = import.meta.env.PROD ? "9012" : "8786";

  // const config_Height = typeHeight === 'configuration' ? '203px' : 'calc(100vh - 610px)'
  const handleRaiseTicketConfirm = async () => {
    if (!ticketAlarm) return;

    const alarm = ticketAlarm;

    setShowTicketConfirm(false);
    setRaisingTicket(true);

    try {
      // --------------------------------------------------
      // 1. FETCH CNMS DETAILS
      // --------------------------------------------------
      const cnmsResponse = await InventAxios(FETCH_CNMS_ADDRESS_DETAILS, "get");

      const fetchedAddress = cnmsResponse?.data?.address;

      if (!fetchedAddress) {
        throw new Error("CNMS address not found");
      }

      const targetHost = fetchedAddress.includes(":")
        ? fetchedAddress
        : `${fetchedAddress}:${port}`;

      console.log("CNMS Address:", fetchedAddress);
      console.log("Target Host:", targetHost);

      // --------------------------------------------------
      // 2. CREATE TICKET
      // --------------------------------------------------

      const createTicketPayload = {
        remoteId: alarm.siteId || "",
        remoteName: alarm.siteId || "",
        nmsType:
          alarm.terminalType !== undefined && alarm.terminalType !== null
            ? Number(alarm.terminalType)
            : null,

        ticketAlarmDetail: alarm.alarmName || "",

        ticketedDevice: alarm.resourceName || "",

        hdTicketPriority: {
          id:
            alarm.severity !== undefined && alarm.severity !== null
              ? Number(alarm.severity)
              : null,
        },

        hdTicketSubDetails: [
          {
            loggedinUser: userName,
            statement: alarm.alarmDescription || "",
          },
        ],
      };

      console.log("CREATE_TICKET payload:", createTicketPayload);

      const createTicketResponse = await HelpDeskAxios(
        CREATE_TICKET,
        "post",
        createTicketPayload,
        null,
        targetHost
      );

      console.log("CREATE_TICKET response:", createTicketResponse?.data);

      if (
        createTicketResponse?.status !== 200 &&
        createTicketResponse?.status !== 201
      ) {
        throw new Error("Ticket creation failed");
      }

      // --------------------------------------------------
      // 3. UPDATE HD TICKET STATUS
      // --------------------------------------------------

      const updateTicketPayload = {
        ...alarm,
        isTicketRaised: true,
      };

      console.log("UPDATE_HD_TICKET_STATUS payload:", updateTicketPayload);

      const updateTicketResponse = await FaultAxios(
        UPDATE_HD_TICKET_STATUS,
        "post",
        updateTicketPayload
      );

      console.log(
        "UPDATE_HD_TICKET_STATUS response:",
        updateTicketResponse?.data
      );

      if (
        updateTicketResponse?.status !== 200 &&
        updateTicketResponse?.status !== 201
      ) {
        throw new Error("Failed to update ticket status");
      }

      // --------------------------------------------------
      // SUCCESS
      // --------------------------------------------------

      const updatedAlarm = {
        ...alarm,
        isTicketRaised: true,
      };

      // Update Redux immediately
      dispatch(updateSingleAlarm(updatedAlarm));

      Toast("Success!", "Ticket raised successfully!", "success");

      // Clear selected row/menu
      setTicketAlarm(null);
      setSelectedAlarmId([]);
      setSelectedKeys(new Set());
    } catch (error) {
      console.error("Raise Ticket failed:", error);

      Toast("Error!", error?.message || "Failed to raise ticket", "error");
    } finally {
      setRaisingTicket(false);
    }
  };

  return (
    <Box
      sx={{
        width: "100%",
        // mt: 2.56,
        // m:1,
        border: (theme) => `1px solid ${theme.palette.custom.table.borderBox}`,
        borderRadius: "12px",
        zIndex: 9999,
      }}
    >
      {/* {
        advancedSearch &&
        <ReportAdvancedSearch

          data={tableData}

          setFilteredData={setFilteredAdvancedData}

        />
      } */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {/* MAIN INNER BOX */}
        <Box
          sx={{
            display: "flex",

            alignItems: "center",
            justifyContent: "space-between",
            width: "100%",
            borderRadius: "12px 12px 0px 0px",
            background: (theme) => theme.palette.custom.chart.chartbg,
          }}
        >
          {/* TABLE TITflowLE -> LEFT*/}
          <Typography
            variant="subtitle1"
            sx={{
              color: (theme) => theme.palette.custom.table.headerText,

              p: 1,
              ml: 4,
            }}
          >
            {finalTitle}
          </Typography>

          <Box>{tableHeader}</Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 1,
              p: 1,
              // ENABLED: Allows scrolling only horizontally
              overflowX: "auto",
              overflowY: "hidden", // Explicitly hides vertical scroll
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              {/* --- GROUP 1: LEFT SIDE (Dropdowns & Custom Buttons) --- */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                }}
              >
                {customDropdown}
                {customDropdown1}
                {customButton}
              </Box>

              {/* --- GROUP 2: RIGHT SIDE (Search, Add, Maximize, Download) --- */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  flexShrink: 0,
                }}
              >
               {showHeaderActions && headerActions} 
                {!hideAdd && (
                  <MButtonPrimary
                    onClick={handleAdd}
                    disabled={addDisable}
                    startIcon={addIcon}
                  >
                    {AddText}
                  </MButtonPrimary>
                )}

                {showSearch && (
                  <MInput
                    value={filterValue}
                    placeholder="Search..."
                    onChange={onSearchChange}
                    sx={{ width: "150px" }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Search size={20} className="text-gray-500" />
                        </InputAdornment>
                      ),
                    }}
                  />
                )}

                {showExportButton && (
                  <Tooltip title="Export Certificate">
                    <Box
                      onClick={onExportClick}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        borderRadius: "10px",
                        padding: 0.8,
                        background: "#14348d",
                      }}
                    >
                      <img
                        src={exportIcon}
                        alt="export"
                        style={{ width: "20px", height: "20px" }}
                      />
                    </Box>
                  </Tooltip>
                )}
                {handleRefresh && (
                  <Tooltip title="Refresh">
                    <Box
                      onClick={onRefreshClick}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        borderRadius: "10px",
                        padding: 0.8,
                        color: "#14348d",
                      }}
                    >
                      <Refresh sx={{ filter: isDark ? "invert(1)" : "none" }} />
                    </Box>
                  </Tooltip>
                )}
                {handleFilter && (
                  <Box
                    sx={{ display: "flex", alignItems: "center", gap: "10px" }}
                  >
                    <Tooltip
                      title={isFilterVisible ? "Close Filter" : "Filter"}
                    >
                      <Box
                        onClick={(e) => {
                          // If already open, close it; otherwise, open it
                          isFilterVisible
                            ? handleCloseMenu()
                            : handleFilterClick(e);
                        }}
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          cursor: "pointer",
                          borderRadius: "10px",
                          padding: 0.8,
                          // Dynamic color based on state
                          color: isFilterVisible ? "#ffffff" : "#14348d",
                          backgroundColor: isFilterVisible
                            ? "#14348d"
                            : "#eef2ff",
                        }}
                      >
                        <FilterIcon />
                      </Box>
                    </Tooltip>
                  </Box>
                )}

                {/* The Popover Fix */}
                <Popover
                  open={openMenu}
                  anchorEl={anchorEl} // CRITICAL: This tells the popover where to show up
                  onClose={handleCloseMenu}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "left",
                  }}
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "left",
                  }}
                  // This prevents clicks inside the popover from closing it automatically
                  onClick={(e) => e.stopPropagation()}
                >
                  <Box sx={{ p: 2, display: "flex", flexDirection: "column" }}>
                    {filterMenu}
                  </Box>
                </Popover>

                {showVisibleContent && VisibleContent}

                {/* Alarm Action buttons */}
                {selectedKeys.size > 0 && (
                  <div className="flex items-center gap-3">
                    {selectionMeta?.hasNotAck && (
                      <Tooltip title="Ack">
                        <button
                          onClick={() => onAction("ACK")}
                          className="p-1 rounded-md w-9 h-9 border border-gray-300 text-blue-700 flex items-center gap-1 transition-colors"
                        >
                          <img
                            src={Ack_Tick_Icon}
                            alt="ACK"
                            style={{
                              filter: theme.palette.custom.icon.iconFilter,
                            }}
                          />
                        </button>
                      </Tooltip>
                    )}

                    {selectionMeta?.hasAck && (
                      <Tooltip title="End">
                        <button
                          onClick={() => onAction("END")}
                          className="pl-3 w-9 h-9 rounded-md border border-gray-300 text-blue-700 flex items-center gap-1 transition-colors"
                        >
                          <img
                            src={End_Icon}
                            alt="END"
                            style={{
                              filter: theme.palette.custom.icon.iconFilter,
                            }}
                          />
                        </button>
                      </Tooltip>
                    )}

                    {selectionMeta?.count && selectionMeta?.isSingle && (
                      <Tooltip title="Alarm Timeline">
                        <button
                          className="pl-1 w-9 h-9 rounded-md border border-gray-300 text-blue-700 flex items-center gap-1 transition-colors"
                          onClick={() => onAction("VIEW")}
                        >
                          {/* <img
                            src={RnmsDownIcon}
                            alt="VIEW"
                            style={{
                              color:'blue',
                              filter: theme.palette.custom.icon.iconFilter,
                            }}
                          /> */}
                          <TrendingUp
                            style={{
                              filter: theme.palette.custom.icon.iconFilter,
                              color: "#344d96",
                            }}
                          />
                        </button>
                      </Tooltip>
                    )}

                    {selectionMeta?.isSingle && (
                      <Tooltip
                        title={
                          selectionMeta?.isTicketRaised
                            ? "Ticket already created"
                            : "Raise Ticket"
                        }
                      >
                        <button
                          onClick={() => {
                            if (selectionMeta?.isTicketRaised) {
                              Toast("Info", "Ticket already created", "info");
                              return;
                            }

                            onAction("TICKET");
                          }}
                          disabled={raisingTicket}
                          className="p-1 rounded-md border border-gray-300 text-blue-700 flex items-center gap-1 transition-colors"
                          style={{
                            cursor: selectionMeta?.isTicketRaised
                              ? "not-allowed"
                              : "pointer",
                          }}
                        >
                          <img
                            src={Raise_Ticket_Icon}
                            alt="TICKET"
                            style={{
                              width: "23px",
                              height: "23px",
                              objectFit: "contain",
                              filter: selectionMeta?.isTicketRaised
                                ? "grayscale(1) opacity(0.45)"
                                : theme.palette.custom.icon.iconFilter,
                            }}
                          />
                        </button>
                      </Tooltip>
                    )}
                  </div>
                )}

                {showMaximazed && (
                  <div className="flex items-center gap-5">
                    <button
                      onClick={toggleMaximize}
                      className="p-1 rounded-md border border-[#d9d9d9] flex items-center justify-center"
                      style={{
                        color: isDark
                          ? theme.palette.custom.icon.iconFilter
                          : "#14348d",
                        filter: isDark
                          ? theme.palette.custom.icon.iconFilter
                          : "none",
                        background: "transparent",
                      }}
                    >
                      {isMaximized ? (
                        <Tooltip title="Exit Full Screen">
                          <FullscreenExit
                            size="20"
                            style={{ color: "inherit" }}
                          />
                        </Tooltip>
                      ) : (
                        <Tooltip title="Enter Full Screen">
                          <Fullscreen size="20" style={{ color: "inherit" }} />
                        </Tooltip>
                      )}
                    </button>
                  </div>
                )}

                {/* 
        MOVED: Download Button logic here 
        Previously it was nested inside the 'Alarm Action' div, which broke the flow 
        when the alarm buttons were hidden or scrolled.
      */}
                <Tooltip title="Download">
                  <Box>
                    {(handleDownloadPDF || handleDownloadCSV) && (
                      <>
                        <Box
                          sx={{
                            border: (theme) =>
                              `1px solid ${theme.palette.custom.table.border}`,
                            display: "flex",
                            alignItems: "center",
                            cursor: isExportDisabled
                              ? "not-allowed"
                              : "pointer",
                            borderRadius: "10px",
                            padding: 0.8,
                            backgroundColor: isExportDisabled
                              ? "#f0f0f0"
                              : (theme) =>
                                  theme.palette.mode === "dark"
                                    ? "transparent"
                                    : "transparent",
                            opacity: isExportDisabled ? 0.5 : 1,
                            "&:hover": {
                              background: isExportDisabled
                                ? "#f0f0f0"
                                : (theme) =>
                                    theme.palette.mode === "dark"
                                      ? "#1e21a3"
                                      : "#B8C9FF",
                            },
                          }}
                          onClick={(e) => {
                            if (!isExportDisabled) {
                              handleOpenMenu(e);
                            }
                          }}
                        >
                          <img
                            src={download}
                            alt="download"
                            style={{
                              filter: isExportDisabled
                                ? "grayscale(1)"
                                : isDark
                                ? "invert(1) brightness(2)"
                                : "none",
                            }}
                          />
                        </Box>

                        <Menu
                          anchorEl={anchorEl}
                          open={openMenu}
                          onClose={handleCloseMenu}
                        >
                          {handleDownloadPDF && (
                            <MenuItem
                              onClick={() => {
                                handleDownloadPDF();
                                handleCloseMenu();
                              }}
                            >
                              <ListItemIcon>
                                <PdfIcon
                                  sx={{ color: "#ff5757" }}
                                  fontSize="small"
                                />
                              </ListItemIcon>
                              <ListItemText primary="Export as PDF" />
                            </MenuItem>
                          )}
                          {handleDownloadCSV && (
                            <MenuItem
                              onClick={() => {
                                handleDownloadCSV();
                                handleCloseMenu();
                              }}
                            >
                              <ListItemIcon>
                                <CsvIcon
                                  sx={{ color: "#28a745" }}
                                  fontSize="small"
                                />
                              </ListItemIcon>
                              <ListItemText primary="Export as CSV" />
                            </MenuItem>
                          )}
                        </Menu>
                      </>
                    )}
                  </Box>
                </Tooltip>

                <Box>
                  {closeIcon && (
                    <SquareIconButton onClick={handleClose}>
                      <CloseIcon sx={{ color: theme.palette.text.primary }} />
                    </SquareIconButton>
                  )}
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>

      <ScrollContainer
        style={{
          height: config_Height,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <TableContainer
          component={Paper}
          sx={{
            // border: (theme) => `1px solid ${theme.palette.custom.table.border}`,
            maxWidth: "100%",
            //overflow: "visible",
            height: "100%",
            display: "flex",
            overflow: "hidden",
            flexDirection: "column",
            //maxHeight: "calc(100vh - 350px)",
            // overflowY: "auto",
            // overflowX: "auto",
            position: "relative",
            bgcolor: "background.paper",
            zIndex: 1,
            width: "100%",
            maxHeight: "none",
            // background: (theme) => theme.palette.custom.chart.chartbg,
          }}
        >
          <ScrollContainer
            style={{
              height: "100%", // Use full height of the TableContainer
              width: "100%",
              overflow: "auto", // Ensures scrollbars appear here
            }}
          >
            <Table
              size="small"
              sx={{ width: "100%", tableLayout: "auto", fontSize: "0.25rem" }}
            >
              <TableHead>
                <TableRow sx={{ bgcolor: "#D5E0FF" }}>
                  {(showSelect || enableRowSelection) && (
                    <TableCell
                      sx={{
                        position: "sticky",
                        top: 0, // Stick to the top of TableContainer
                        left: 0, // If you want it to stick when scrolling horizontally
                        zIndex: 30, // Higher than body cells (5) and other header cells (10)
                        bgcolor: (theme) => theme.palette.custom.table.headerBg,
                        color: (theme) => theme.palette.custom.table.headerText,
                        width: "50px",
                        borderTop: (theme) =>
                          `1px solid ${theme.palette.custom.table.borderHeader}`,

                        borderRight: (theme) =>
                          `1px solid ${theme.palette.custom.table.borderHeader}`,
                        // border:"1px solid #5c5757"
                      }}
                    >
                      {enableRowSelection ? (
                        <Checkbox
                          checked={isAllRowsSelected}
                          indeterminate={isIndeterminateRows}
                          onChange={(e) => onSelectAll?.(e.target.checked)}
                          icon={
                            <Box
                              sx={{
                                width: 24,
                                height: 24,
                                bgcolor: "white",
                                borderRadius: "2px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                border: "2px solid #c4c4c4",
                                marginLeft: "8px",
                              }}
                            />
                          }
                          checkedIcon={
                            <Box
                              sx={{
                                width: 24,
                                height: 24,
                                bgcolor: "white",
                                borderRadius: "2px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                border: "2px solid #c4c4c4",
                                marginLeft: "8px",
                              }}
                            >
                              <Done sx={{ color: "#14348D" }} />
                            </Box>
                          }
                          indeterminateIcon={
                            <Box
                              sx={{
                                width: 24,
                                height: 24,
                                bgcolor: "white",
                                borderRadius: "2px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                border: "2px solid #c4c4c4",

                                marginLeft: "8px",
                              }}
                            >
                              <Box
                                sx={{
                                  width: 14,
                                  height: 2,
                                  bgcolor: "#14348D",
                                }}
                              />
                            </Box>
                          }
                          disableRipple
                          sx={{
                            padding: 0,
                            "&:hover": {
                              backgroundColor: "transparent",
                            },
                          }}
                        />
                      ) : (
                        <Checkbox
                          checked={
                            filteredItems.length > 0 &&
                            selectedKeys.size === filteredItems.length
                          }
                          indeterminate={
                            selectedKeys.size > 0 &&
                            selectedKeys.size < filteredItems.length
                          }
                          onChange={(e) => handleSelectAll(e.target.checked)}
                          icon={
                            <Box
                              sx={{
                                width: 24,
                                height: 24,
                                bgcolor: "white",
                                borderRadius: "2px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                border: "2px solid #c4c4c4",
                                marginLeft: "8px",
                              }}
                            />
                          }
                          checkedIcon={
                            <Box
                              sx={{
                                width: 24,
                                height: 24,
                                bgcolor: "white",
                                borderRadius: "2px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                border: "2px solid #c4c4c4",
                                marginLeft: "8px",
                              }}
                            >
                              <Done sx={{ color: "#14348D" }} />
                            </Box>
                          }
                          indeterminateIcon={
                            <Box
                              sx={{
                                width: 24,
                                height: 24,
                                bgcolor: "white",
                                borderRadius: "2px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                border: "2px solid #c4c4c4",
                                marginLeft: "8px",
                              }}
                            >
                              <Box
                                sx={{
                                  width: 14,
                                  height: 2,
                                  bgcolor: "#14348D",
                                }}
                              />
                            </Box>
                          }
                          disableRipple
                          sx={{
                            padding: 0,
                            "&:hover": {
                              backgroundColor: "transparent",
                            },
                          }}
                        />
                      )}
                    </TableCell>
                  )}

                  {columns.map((col, index) => (
                    <TableCell
                      key={col.uid}
                      sx={{
                        ...getColumnStyle(col),
                        borderTop: (theme) =>
                          `1px solid ${theme.palette.custom.table.borderHeader}`,
                        // borderBottom: (theme) => `1px solid ${theme.palette.custom.table.headerBottom}`,
                        borderRight: (theme) =>
                          `1px solid ${theme.palette.custom.table.borderHeader}`,
                        // borderRight:"1px solid #5c5757",
                        // border:"2px solid blue",
                        color: (theme) => theme.palette.custom.table.headerText,
                        bgcolor: (theme) => theme.palette.custom.table.headerBg,
                        fontWeight: "bold",
                        position: "sticky",
                        top: 0,
                        zIndex: 10,
                        whiteSpace: "normal",
                        overflow: "hidden",

                        ...(col.uid === "actions" && {
                          position: "sticky",
                          right: 0,
                          zIndex: 25,
                          border: (theme) => theme.palette.custom.table.border,
                          bgcolor: (theme) =>
                            theme.palette.custom.table.headerBg,
                          boxShadow:
                            "-5px 0px 10px -5px rgba(0,0,0,0.5), -2px 0px 5px rgba(0,0,0,0.1)",
                        }),
                      }}
                    >
                      {/* <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                        }}
                      >
                        {col.name}
                        {(col.filterType === "dropdown" ||
                          col.filterType === "datetime") && (
                            <FilterMenu
                              column={col}
                              data={tableData}
                              activeFilters={columnFilters}
                              onFilterChange={handleFilterChange}
                            />
                          )}
                      </Box> */}
                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: enableColumnSearch ? "column" : "row",
                          alignItems: enableColumnSearch ? "stretch" : "center",
                          justifyContent: "space-between",
                          gap: enableColumnSearch ? 0.5 : 0,
                          py: enableColumnSearch ? 0.5 : 0,
                        }}
                      >
                        {/* COLUMN TITLE */}
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            minHeight: "24px",
                          }}
                        >
                          <span>{col.name}</span>

                          {/* Existing dropdown/date filter remains */}
                          {(col.filterType === "dropdown" ||
                            col.filterType === "datetime") && (
                            <FilterMenu
                              column={col}
                              data={tableData}
                              activeFilters={columnFilters}
                              onFilterChange={handleFilterChange}
                            />
                          )}
                        </Box>

                        {/* NEW COLUMN SEARCH */}
                        {enableColumnSearch &&
                          col.uid !== "sno" &&
                          col.uid !== "actions" && (
                            <MInput
                              value={columnSearchValues[col.uid] || ""}
                              onChange={(e) =>
                                handleColumnSearchChange(
                                  col.uid,
                                  e.target.value
                                )
                              }
                              placeholder={`Search ${col.name}`}
                              size="small"
                              sx={{
                                width: "100%",
                                minWidth: 0,

                                "& .MuiInputBase-root": {
                                  height: "30px",
                                  fontSize: "12px",
                                  backgroundColor: (theme) =>
                                    theme.palette.background.paper,
                                },

                                "& input": {
                                  padding: "5px 8px",
                                },
                              }}
                              onClick={(e) => e.stopPropagation()}
                            />
                          )}
                      </Box>
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>

              <TableBody
                sx={{
                  fontSize: "0.75rem",
                  background: (theme) => theme.palette.custom.table.tablebodybg,
                }}
              >
                {displayItems.length > 0 ? (
                  displayItems.map((row, index) => (
                    <React.Fragment key={row.id || index}>
                      <TableRow
                        hover
                        sx={{
                          "&:hover": {
                            bgcolor: (theme) =>
                              theme.palette.custom.table.rowHover,
                          },
                        }}
                        onContextMenu={(e) => {
                          if (enableRowSelection) {
                            e.preventDefault();

                            const rowId = String(row[rowIdKey]);

                            // Right-click is only allowed on a selected row.
                            if (!selectedRowsNew.has(rowId)) {
                              return;
                            }

                            onRowContextMenu?.(e, row);
                            return;
                          }

                          // Existing RNMS behavior remains untouched.
                          handleContextMenu(e, row);
                        }}
                      >
                        {(showSelect || enableRowSelection) && (
                          <TableCell
                            sx={{
                              //
                              // borderRight: (theme) => `1px solid ${theme.palette.custom.table.border}`,
                              // borderBottom: (theme) => `1px solid ${theme.palette.custom.table.border}`,
                              width: "50px",
                              borderRight: (theme) =>
                                `1px solid ${theme.palette.custom.table.headerRight}`,
                            }}
                          >
                            {enableRowSelection ? (
                              <Checkbox
                                checked={selectedRowsNew.has(
                                  String(row[rowIdKey])
                                )}
                                onChange={(e) =>
                                  onRowSelect?.(row[rowIdKey], e.target.checked)
                                }
                                icon={
                                  <Box
                                    sx={{
                                      width: 24,
                                      height: 24,
                                      bgcolor: "white",
                                      borderRadius: "2px",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      border: "2px solid #eee",
                                    }}
                                  />
                                }
                                checkedIcon={
                                  <Box
                                    sx={{
                                      width: 24,
                                      height: 24,
                                      bgcolor: "white",
                                      borderRadius: "2px",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      border: "2px solid #c4c4c4",
                                    }}
                                  >
                                    <Done sx={{ color: "#14348D" }} />
                                  </Box>
                                }
                                disableRipple
                                sx={{
                                  "&:hover": { backgroundColor: "transparent" },
                                  "& .MuiSvgIcon-root": { fontSize: "24px" },
                                }}
                              />
                            ) : (
                              <Checkbox
                                checked={selectedKeys.has(row.alarmId)}
                                onChange={(e) =>
                                  handleSelectRow(row, e.target.checked)
                                }
                                icon={
                                  <Box
                                    sx={{
                                      width: 24,
                                      height: 24,
                                      bgcolor: "white",
                                      borderRadius: "2px",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      border: "2px solid #eee",
                                    }}
                                  />
                                }
                                checkedIcon={
                                  <Box
                                    sx={{
                                      width: 24,
                                      height: 24,
                                      bgcolor: "white",
                                      borderRadius: "2px",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      border: "2px solid #c4c4c4",
                                    }}
                                  >
                                    <Done sx={{ color: "#14348D" }} />
                                  </Box>
                                }
                                disableRipple
                                sx={{
                                  "&:hover": { backgroundColor: "transparent" },
                                  "& .MuiSvgIcon-root": { fontSize: "24px" },
                                }}
                              />
                            )}
                          </TableCell>
                        )}
                        {columns.map((col) => (
                          <TableCell
                            key={col.uid}
                            sx={{
                              ...getColumnStyle(col),
                              borderRight: (theme) =>
                                `1px solid ${theme.palette.custom.table.headerRight}`,
                              // border:"2px solid purple",
                              // borderRight: (theme) => `1px solid ${theme.palette.custom.table.border}`,
                              // borderBottom: (theme) => `1px solid ${theme.palette.custom.table.border}`,
                              wordBreak: "break-word",
                              ...(col.uid === "actions" && {
                                position: "sticky",
                                right: 0,
                                zIndex: 5,

                                boxShadow: "-2px 0px 5px rgba(0,0,0,0.1)",
                                bgcolor: (theme) =>
                                  theme.palette.custom.table.tablebodybg,
                              }),
                            }}
                          >
                            {/* UPDATED SECTION START */}
                            {col.uid === "sno" ? (
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  position: "relative",
                                }}
                              >
                                {isCollapsible && (
                                  <IconButton
                                    size="small"
                                    onClick={() => toggleRow(row.id)}
                                    sx={{
                                      position: "absolute",
                                      left: "-12px",
                                      zIndex: 2,
                                      backgroundColor: "white",
                                      "&:hover": {
                                        backgroundColor: "#f0f0f0",
                                      },
                                    }}
                                  >
                                    {expandedRows[row.id] ? (
                                      // <KeyboardArrowUpIcon fontSize="small" />
                                      <img src={Help_Desk_View_rotate}></img>
                                    ) : (
                                      <img src={Help_Desk_View}></img>
                                    )}
                                  </IconButton>
                                )}
                                <Box
                                  sx={{
                                    marginLeft: isCollapsible ? "20px" : 0,
                                  }}
                                >
                                  {(page - 1) * rowsPerPage + (index + 1)}
                                </Box>
                              </Box>
                            ) : col.uid === "actions" ? (
                              renderActions(row)
                            ) : (
                              renderCellValue(col, row)
                            )}
                            {/* UPDATED SECTION END */}
                          </TableCell>
                        ))}
                      </TableRow>
                      {isCollapsible && expandedRows[row.id] && (
                        <TableRow>
                          <TableCell
                            colSpan={
                              columns.length +
                              (showSelect || enableRowSelection ? 2 : 1) +
                              1
                            }
                            style={{ paddingBottom: 0, paddingTop: 0 }}
                          >
                            <Collapse
                              in={expandedRows[row.id]}
                              timeout="auto"
                              unmountOnExit
                            >
                              <Box
                                sx={{
                                  // border: (theme) => `1px solid ${theme.palette.custom.table.border}`,
                                  bgcolor: (theme) =>
                                    theme.palette.background.default,
                                  ml: -2,
                                  mr: -2,
                                }}
                              >
                                <Table size="small" fontSize="0.25rem">
                                  <TableHead>
                                    <TableRow
                                      sx={{
                                        bgcolor: (theme) =>
                                          theme.palette.custom.table.headerBg,
                                      }}
                                    >
                                      {collapseColumns.map((subCol) => (
                                        <TableCell
                                          key={subCol.uid}
                                          sx={{
                                            color: (theme) =>
                                              theme.palette.custom.table
                                                .headerText,
                                          }}
                                        >
                                          {subCol.name}
                                        </TableCell>
                                      ))}
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {row[collapseDataKey]?.length > 0 ? (
                                      row[collapseDataKey].map(
                                        (subRow, subIdx) => (
                                          <TableRow key={subIdx}>
                                            {collapseColumns.map((subCol) => (
                                              <TableCell
                                                key={subCol.uid}
                                                sx={{
                                                  ...getColumnStyle(subCol),
                                                  borderBottom: (theme) =>
                                                    `1px solid ${theme.palette.custom.table.border}`,
                                                }}
                                              >
                                                {subRow[subCol.uid]}
                                              </TableCell>
                                            ))}
                                          </TableRow>
                                        )
                                      )
                                    ) : (
                                      <TableRow>
                                        <TableCell
                                          colSpan={collapseColumns.length}
                                          align="center"
                                          sx={{ py: 2, color: "gray" }}
                                        >
                                          No details available
                                        </TableCell>
                                      </TableRow>
                                    )}
                                  </TableBody>
                                </Table>
                              </Box>
                            </Collapse>
                          </TableCell>
                        </TableRow>
                      )}
                    </React.Fragment>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length + (showSelect ? 1 : 0)}
                      align="center"
                    >
                      No records found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </ScrollContainer>
        </TableContainer>
      </ScrollContainer>

      {showPagination && (
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            p: 1,
            background: (theme) => theme.palette.custom.chart.chartbg,
            borderRadius: "0px 0px 12px 12px",
          }}
        >
          <Typography variant="body2" color="text.primary">
            Total {filteredItems.length} Records
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography sx={{ color: "text.primary" }} variant="body2">
                Rows per page:
              </Typography>
              <Select
                value={rowsPerPage}
                onChange={(e) => {
                  setRowsPerPage(e.target.value);
                  setPage(1);
                }}
                // size="small"
                variant="standard"
                disableUnderline
                sx={{ color: "text.primary", fontSize: "16px" }}
              >
                {[5, 10, 15, 50].map((v) => (
                  <MenuItem key={v} value={v} sx={{ fontSize: "14px" }}>
                    {v}
                  </MenuItem>
                ))}
              </Select>
            </Stack>
            <Pagination
              count={Math.ceil(filteredItems.length / rowsPerPage)}
              page={page}
              onChange={(e, p) => setPage(p)}
              sx={{
                "& .Mui-selected": {
                  backgroundColor: "#D5E0FF !important",
                  color: "#14348D !important",
                },
              }}
            />
          </Box>
        </Box>
      )}
      {showRemove && (
        <Box
          sx={{
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "flex-end",
            p: 1,
          }}
        >
          <MButtonPrimary
            onClick={onRemoveClick}
            disabled={isRemoveDisabled}
            color="error" // Make it red if it's a remove action
          >
            {removeText}
          </MButtonPrimary>
        </Box>
      )}
      {Key === "ALARM1" ? (
        <AckTable
          isOpen={isOpen}
          onCancel={handleCloseModal}
          ackdata={ackData}
          alarmId={selectedAlarmId}
          Key={Key}
        />
      ) : (
        " "
      )}

      {Key === "ALARM2" ? (
        <EndTable
          isOpen={isOpen}
          onCancel={handleCloseModal}
          ackdata={ackData}
          alarmId={selectedAlarmId}
          Key={Key}
        />
      ) : (
        " "
      )}

      {Key === "ALARM3" ? (
        <ViewAugmentation
          isOpen={isOpen}
          onCancel={handleCloseModal}
          ackdata={ackData}
          alarmId={selectedAlarmId}
          Key={Key}
        />
      ) : (
        ""
      )}
      <MDialog
        open={showTicketConfirm}
        variant="info"
        icon={Confirmation_icon}
        title="Confirm Action"
        message="Are you sure you want to raise the ticket?"
        onConfirm={handleRaiseTicketConfirm}
        onClose={() => {
          if (!raisingTicket) {
            setShowTicketConfirm(false);
            setTicketAlarm(null);
          }
        }}
        mode="parent"
      />
      <ContextMenuAlarm
        contextMenu={contextMenu}
        selectedKeys={selectedKeys}
        selectionMeta={selectionMeta}
        ackdata={ackData}
        onClose={closeMenu}
        onAction={onAction}
        finalSelectedRows={finalSelectedRows}
      />
    </Box>
  );
};

export default MTable;
