package org.bel.location.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.List;
import org.bel.location.dto.UserCreatedSyncEvent;
import org.bel.location.dto.UserSyncAck;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Auth-only transport relay. It does not read, transform, or process location payloads.
 * node_registry points to this Node Service port; the Auth Service itself uses server.port=0.
 */
@RestController
@RequestMapping("/internal/sync/users")
@RequiredArgsConstructor
@Slf4j
public class UserSyncRelayController {
    private final DiscoveryClient discoveryClient;
    private final RestClient restClient;
    @Value("${sync.internal-token:}") private String internalToken;

    @PostMapping
    public UserSyncAck relayUserCreated(
            @RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
            @RequestBody UserCreatedSyncEvent event) {
        validateToken(token);
        if (event == null || event.eventId() == null || event.serviceId() == null || event.serviceId().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid USER_CREATED event");
        }

        List<String> serviceNames = discoveryClient.getServices().stream()
                .filter(name -> "authService".equalsIgnoreCase(name)).toList();
        if (serviceNames.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "Local authService is not registered in this node's Eureka registry");
        }
        List<ServiceInstance> instances = discoveryClient.getInstances(serviceNames.get(0));
        if (instances == null || instances.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "No local authService instance is available");
        }

        // This node's Eureka is local to this node; select one local authService instance.
        ServiceInstance instance = instances.get(0);
        String url = instance.getUri().resolve("/internal/sync/users/receive").toString();
        try {
            UserSyncAck ack = restClient.post().uri(url)
                    .header("X-Node-Sync-Token", internalToken)
                    .contentType(MediaType.APPLICATION_JSON).body(event)
                    .retrieve().body(UserSyncAck.class);
            if (ack == null || !event.eventId().equals(ack.eventId())) {
                throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Local Auth Service returned an invalid ACK");
            }
            return ack;
        } catch (ResponseStatusException ex) {
            throw ex;
        } catch (Exception ex) {
            log.warn("Unable to relay USER_CREATED event {} to local authService: {}", event.eventId(), ex.getMessage());
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Local Auth Service is unavailable", ex);
        }
    }

    private void validateToken(String token) {
        if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
    }
}
