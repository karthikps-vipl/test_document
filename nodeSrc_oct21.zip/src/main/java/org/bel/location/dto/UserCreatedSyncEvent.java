package org.bel.location.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/** Auth-only event payload. It is separate from LocationSyncEvent. */
public record UserCreatedSyncEvent(
        UUID eventId, String sourceNodeId, Integer sourceUserId, String serviceId,
        Integer mdmNodeId, Integer mdmRoleId, Integer mdmUserTypeId, Integer mdmLevelId,
        Integer mdmRankId, String usrName, Integer userStats, Integer failedLoginCount,
        boolean signupStatus, String createdBy, String email, LocalDate dateOfJoining,
        LocalDate passwordChangedAt, LocalDateTime createdAt, LocalDateTime updatedAt,
        LocalDateTime lastLogin, LocalDateTime loginTime) {}
