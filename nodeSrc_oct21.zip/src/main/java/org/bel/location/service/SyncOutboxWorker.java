package org.bel.location.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.entity.SyncOutbox;
import org.bel.location.entity.SyncOutboxDelivery;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.bel.location.repository.SyncOutboxRepository;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class SyncOutboxWorker {
    private final SyncOutboxRepository outboxRepo;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final NodeRegistryService nodeRegistryService;
    private final NodeSyncService nodeSyncService;
    private final NodeHealthMonitor nodeHealthMonitor;
    private final ObjectProvider<SyncOutboxWorker> selfProvider;

    private final AtomicInteger reconciliationPage = new AtomicInteger(0);

    @Value("${sync.outbox.batch-size:100}")
    private int batchSize;

    @Value("${sync.outbox.stale-sending-seconds:120}")
    private long staleSendingSeconds;

    @Scheduled(fixedDelayString = "${sync.outbox.fixed-delay-ms:10000}")
    public void processOutbox() {
        LocalDateTime now = LocalDateTime.now();
        deliveryRepo.resetStaleSendingRows(now.minusSeconds(staleSendingSeconds));

        // One registry read per worker cycle. Inactive peers remain required recipients,
        // but dispatch is blocked until their registry status is ACTIVE and health is UP.
        List<NodeRegistry> targets = nodeRegistryService.getOtherRegisteredNodes();
        Map<String, NodeRegistry> targetsById = targets.stream().collect(
                Collectors.toMap(NodeRegistry::getNodeId, Function.identity(), (first, ignored) -> first));

        // Compact any backlog that existed before this version was deployed. For each
        // user, retain the newest pending location event plus any event already in flight.
        for (Integer userId : outboxRepo.findDistinctUserIdsByStatusAndEventType("PENDING", "LOCATION_UPDATED")) {
            selfProvider.getObject().compactPendingLocationEvents(userId);
        }

        // Reconcile existing PENDING events too, not just events with zero delivery rows.
        // Rotate through pages so a large set of old pending events cannot starve later ones.
        long pendingCount = outboxRepo.countByStatus("PENDING");
        int pageSize = Math.max(1, batchSize);
        int totalPages = (int) Math.max(1, (pendingCount + pageSize - 1) / pageSize);
        int pageIndex = Math.floorMod(reconciliationPage.getAndIncrement(), totalPages);
        Page<SyncOutbox> pendingPage = outboxRepo.findByStatusOrderByCreatedAtAsc(
                "PENDING", PageRequest.of(pageIndex, pageSize));

        for (SyncOutbox event : pendingPage.getContent()) {
            selfProvider.getObject().reconcileEvent(event.getEventId(), targets);
        }

        deliveryRepo.findDispatchable(now).stream().limit(batchSize)
                .forEach(delivery -> dispatchDelivery(delivery, targetsById, now));
    }

    /**
     * Ensures each currently registered peer has a durable delivery row, then refreshes
     * the parent status from fresh database state. Inactive/unhealthy peers still have a
     * delivery row, but that row will not be sent until the peer becomes eligible.
     */
    /**
     * Coalesces an existing location backlog. The newest pending location is kept,
     * along with any older event whose delivery is already SENDING. Older events that
     * are not in flight are obsolete for latest-location replication and are deleted.
     */
    @Transactional
    public void compactPendingLocationEvents(Integer userId) {
        List<SyncOutbox> pending = outboxRepo.findByUserIdAndStatusAndEventTypeOrderByCreatedAtAscIdAsc(
                userId, "PENDING", "LOCATION_UPDATED");
        if (pending.size() <= 1) {
            return;
        }

        UUID newestEventId = pending.get(pending.size() - 1).getEventId();
        for (SyncOutbox event : pending) {
            boolean inFlight = deliveryRepo.existsByEventIdAndStatus(event.getEventId(), "SENDING");
            if (inFlight || event.getEventId().equals(newestEventId)) {
                continue;
            }
            deliveryRepo.deleteByEventId(event.getEventId());
            outboxRepo.delete(event);
        }
    }

    @Transactional
    public void reconcileEvent(UUID eventId, List<NodeRegistry> targets) {
        SyncOutbox event = outboxRepo.findByEventId(eventId).orElse(null);
        if (event == null) {
            log.warn("Cannot reconcile missing sync_outbox event {}", eventId);
            return;
        }

        ensureDeliveryRows(eventId, targets);
        refreshOutboxStatus(eventId, targets, event);
    }

    private void dispatchDelivery(SyncOutboxDelivery candidate, Map<String, NodeRegistry> targetsById,
                                  LocalDateTime now) {
        NodeRegistry target = targetsById.get(candidate.getTargetNodeId());
        if (target == null) {
            deliveryRepo.markWaitingIfDispatchable(candidate.getId(), now,
                    "Target node is not present in node_registry");
            return;
        }

        // Sync service health is held by NodeHealthMonitor, not a node_registry DB column.
        // Only ACTIVE + UP peers are eligible for an HTTP sync request.
        if (!"ACTIVE".equalsIgnoreCase(target.getStatus())
                || !"UP".equalsIgnoreCase(nodeHealthMonitor.getState(target.getNodeId()).state())) {
            deliveryRepo.markWaitingIfDispatchable(candidate.getId(), now,
                    "Target node must be ACTIVE and syncServiceStatus UP");
            return;
        }

        // Atomic claim prevents two workers from dispatching the same row concurrently.
        if (deliveryRepo.claimDispatchable(candidate.getId(), now) != 1) {
            return;
        }

        SyncOutboxDelivery claimed = deliveryRepo.findById(candidate.getId()).orElse(null);
        if (claimed == null) {
            log.error("Claimed sync delivery {} disappeared", candidate.getId());
            return;
        }
        SyncOutbox event = outboxRepo.findByEventId(claimed.getEventId()).orElse(null);
        if (event == null) {
            log.error("No sync_outbox event found for delivery {}", claimed.getId());
            return;
        }
        nodeSyncService.send(event, claimed, target);
    }

    /**
     * Re-reads the parent and delivery statuses after ACK persistence. This avoids
     * saving a stale detached SyncOutbox object passed through the async send path.
     */
    @Transactional
    public void refreshOutboxStatus(UUID eventId) {
        SyncOutbox event = outboxRepo.findByEventId(eventId).orElse(null);
        if (event == null) {
            log.warn("Cannot refresh status for missing sync_outbox event {}", eventId);
            return;
        }
        List<NodeRegistry> targets = nodeRegistryService.getOtherRegisteredNodes();
        // A registry entry may have been added since the last worker cycle. Create its
        // delivery row before evaluating all-ACK so the parent cannot be acknowledged early.
        ensureDeliveryRows(eventId, targets);
        refreshOutboxStatus(eventId, targets, event);
    }

    private void ensureDeliveryRows(UUID eventId, List<NodeRegistry> targets) {
        for (NodeRegistry target : targets) {
            deliveryRepo.findByEventIdAndTargetNodeId(eventId, target.getNodeId())
                    .orElseGet(() -> deliveryRepo.save(SyncOutboxDelivery.builder()
                            .eventId(eventId)
                            .targetNodeId(target.getNodeId())
                            .status("PENDING")
                            .retryCount(0)
                            .createdAt(LocalDateTime.now())
                            .build()));
        }
    }

    private void refreshOutboxStatus(UUID eventId, List<NodeRegistry> targets, SyncOutbox event) {
        boolean allAcknowledged = targets.stream().allMatch(target -> deliveryRepo
                .findByEventIdAndTargetNodeId(eventId, target.getNodeId())
                .map(d -> "ACKNOWLEDGED".equalsIgnoreCase(d.getStatus())).orElse(false));

        if (allAcknowledged) {
            event.setStatus("ACKNOWLEDGED");
            event.setSentAt(LocalDateTime.now());
            event.setLastError(null);
            event.setNextRetryAt(null);
        } else {
            event.setStatus("PENDING");
        }
        outboxRepo.save(event);
    }
}
