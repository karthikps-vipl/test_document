import {
  personnelRegex, validateInput, remainingText, usernameRegex, passwordRegex,
  captchaRegex, siteNumRegex, SitenameRegex, SiteNicknameRegex, descriptionRegex,
  PortRegex, isValidIPV4Regex, idValidLatitudeRegex, idValidLongitudeRegex,
  isValidIPV6Regex, extractStringValue, isValidIpV4, generateRandomString,
  profileRegex, miscRegex, miscRegexNumeric,
} from "../../src/utility/FormValidation/Regex";

describe("personnel and profile regex helpers", () => {
  test("exposes the expected personnel patterns", () => {
    expect(personnelRegex.name.test("John Doe")).toBe(true);
    expect(personnelRegex.primaryMobile.test("9876543210")).toBe(true);
    expect(personnelRegex.altMobile.test("876543210")).toBe(true);
    expect(personnelRegex.landline.test("1234567")).toBe(true);
  });
  test("validateInput returns accepted input and rejects invalid input", () => {
    const regex = /^[a-z]+$/;
    expect(validateInput("", regex)).toBe("");
    expect(validateInput("abc", regex)).toBe("abc");
    expect(validateInput("abc1", regex)).toBeUndefined();
  });
  test("remainingText currently returns null", () => {
    expect(remainingText(2, 10)).toBeNull();
  });
  test("validates usernames and passwords", () => {
    expect(usernameRegex("user_01-abc")).toBe("user_01-abc");
    expect(usernameRegex("bad user")).toBeUndefined();
    expect(passwordRegex("Abc@123")).toBe("Abc@123");
    expect(passwordRegex("bad!pass")).toBeUndefined();
  });
  test("validates captcha strings and rejects unsafe input", () => {
    expect(captchaRegex("A12b")).toBe("A12b");
    expect(captchaRegex("A 12")).toBeNull();
    expect(captchaRegex("x".repeat(21))).toBeNull();
    expect(captchaRegex(123)).toBeNull();
  });
  test("validates site numbers from 1 through 999", () => {
    expect(siteNumRegex("1")).toBe("1");
    expect(siteNumRegex("999")).toBe("999");
    expect(siteNumRegex("0")).toBeNull();
    expect(siteNumRegex("1000")).toBeNull();
    expect(siteNumRegex("01")).toBeNull();
  });
  test("validates site names, nicknames, descriptions and ports", () => {
    expect(SitenameRegex("Main-Site Name")).toBe("Main-Site Name");
    expect(SitenameRegex("Site@1")).toBeUndefined();
    expect(SiteNicknameRegex("Site_01")).toBe("Site_01");
    expect(SiteNicknameRegex("@site")).toBeUndefined();
    expect(descriptionRegex("Router, active (north).")).toBe("Router, active (north).");
    expect(descriptionRegex("bad@description")).toBeUndefined();
    expect(PortRegex("GigabitEthernet 0/1")).toBe("GigabitEthernet 0/1");
    expect(PortRegex("port@1")).toBeUndefined();
  });
});

describe("network and coordinate validators", () => {
  test("accepts partial IPv4 entry patterns and rejects invalid characters", () => {
    expect(isValidIPV4Regex("192.168.1")).toBe("192.168.1");
    expect(isValidIPV4Regex("192.168.1.999")).toBeUndefined();
    expect(isValidIPV4Regex("abc")).toBeUndefined();
  });
  test("validates latitude and longitude input formats", () => {
    expect(idValidLatitudeRegex("-90.000000")).toBe("-90.000000");
    expect(idValidLatitudeRegex("91")).toBeUndefined();
    expect(idValidLongitudeRegex("180.000000")).toBe("180.000000");
    expect(idValidLongitudeRegex("181")).toBeUndefined();
  });
  test("validates IPv6 pattern input", () => {
    expect(isValidIPV6Regex("abcd::")).toBe("abcd::");
    expect(isValidIPV6Regex("xyz")).toBeUndefined();
  });
  test("excludes unspecified and broadcast IPv4 addresses", () => {
    expect(isValidIpV4("192.168.1.10")).toBe("192.168.1.10");
    expect(isValidIpV4("0.0.0.0")).toBeUndefined();
    expect(isValidIpV4("255.255.255.255")).toBeUndefined();
  });
  test("extracts values before and after the first underscore", () => {
    expect(extractStringValue("device_123_extra")).toBe("device_123");
    expect(extractStringValue("device_123_extra", true)).toBe("123");
    expect(extractStringValue("device")).toBe("device");
  });
  test("generates a random string of the requested length", () => {
    expect(generateRandomString(12)).toHaveLength(12);
    expect(generateRandomString()).toHaveLength(8);
    expect(generateRandomString(0)).toBe("");
  });
});

describe("regex maps", () => {
  test("profile regex patterns accept and reject representative values", () => {
    expect(profileRegex.name.test("Jane Doe")).toBe(true);
    expect(profileRegex.numeric.test("12345")).toBe(true);
    expect(profileRegex.password.test("Abc@12")).toBe(true);
    expect(profileRegex.community.test("public community")).toBe(true);
    expect(profileRegex.usmUser.test("user01")).toBe(true);
  });
  test("safe numeric helpers enforce type and length limits", () => {
    expect(miscRegex.isSafeNumeric("12.5")).toBe(true);
    expect(miscRegex.isSafeNumeric("abc")).toBe(false);
    expect(miscRegex.isSafeNumeric(12)).toBe(false);
    expect(miscRegex.isSafeNumeric("1".repeat(21))).toBe(false);
    expect(miscRegexNumeric.isSafeInput("-12.5")).toBe(true);
    expect(miscRegexNumeric.isSafeInput("1.2.3")).toBe(false);
    expect(miscRegexNumeric.isSafeInput(12)).toBe(false);
    expect(miscRegexNumeric.isSafeInput("1".repeat(33))).toBe(false);
  });
});
