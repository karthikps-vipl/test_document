import L from "leaflet";
import {
  colorMapUsingId,
  healthStatusMap,
  getCnmsIcon,
  getCommaSeparatedGroupNames,
  getSiteIcon,
} from "../../src/Pages/CnmsDashboard/CnmsMap/components/maputils";

jest.mock("leaflet", () => ({
  divIcon: jest.fn((options) => options),
}));

jest.mock("@/assets/CNMS/DCicon.png", () => "dc-icon.png");

describe("maputils", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("colorMapUsingId", () => {
    test("contains all expected status colors", () => {
      expect(colorMapUsingId).toEqual({
        0: "#d32f2f",
        1: "#2e7d32",
        2: "#f3c106",
        3: "#b8860b",
        4: "#34b8b8",
      });
    });
  });

  describe("healthStatusMap", () => {
    test("contains all expected health statuses", () => {
      expect(healthStatusMap).toEqual({
        UP: 1,
        DOWN: 0,
        OPERATIONAL_DOWN: 2,
        MAINTENANCE: 3,
        "R-OPS": 4,
      });
    });
  });

  describe("getCnmsIcon", () => {
    test("creates CNMS icon with terminal type and site name", () => {
      const cnms = {
        imTerminalType: {
          terminalTypeName: "CNMS",
        },
        siteName: "Mumbai",
      };

      const result = getCnmsIcon(cnms);

      expect(L.divIcon).toHaveBeenCalledTimes(1);

      expect(result.className).toBe("custom-cnms-svg-icon");
      expect(result.html).toContain("CNMS");
      expect(result.html).toContain("Mumbai");
      expect(result.html).toContain("dc-icon.png");
      expect(result.iconSize).toEqual([36, 36]);
      expect(result.iconAnchor).toEqual([18, 18]);
    });

    test("uses CNMS as default terminal type", () => {
      const result = getCnmsIcon({
        siteName: "Delhi",
      });

      expect(result.html).toContain("CNMS");
      expect(result.html).toContain("Delhi");
    });

    test("handles missing site name", () => {
      const result = getCnmsIcon({
        imTerminalType: {
          terminalTypeName: "RNMS",
        },
      });

      expect(result.html).toContain("RNMS");
    });

    test("handles missing terminal details", () => {
      const result = getCnmsIcon({});

      expect(result.html).toContain("CNMS");
    });
  });

  describe("getCommaSeparatedGroupNames", () => {
    test("returns comma-separated group names", () => {
      const groups = [
        { groupName: "North" },
        { groupName: "South" },
        { groupName: "East" },
      ];

      expect(getCommaSeparatedGroupNames(groups)).toBe("North, South, East");
    });

    test("returns empty string for null", () => {
      expect(getCommaSeparatedGroupNames(null)).toBe("");
    });

    test("returns empty string for undefined", () => {
      expect(getCommaSeparatedGroupNames(undefined)).toBe("");
    });

    test("returns empty string for non-array input", () => {
      expect(getCommaSeparatedGroupNames("North")).toBe("");
    });

    test("removes empty and whitespace-only group names", () => {
      const groups = [
        { groupName: "North" },
        { groupName: "" },
        { groupName: "   " },
        { groupName: "South" },
        {},
        { groupName: null },
      ];

      expect(getCommaSeparatedGroupNames(groups)).toBe("North, South");
    });

    test("returns empty string for empty array", () => {
      expect(getCommaSeparatedGroupNames([])).toBe("");
    });
  });

  describe("getSiteIcon", () => {
    test("creates online site icon", () => {
      const result = getSiteIcon({}, 1);

      expect(result.className).toBe("custom-site-svg-icon");
      expect(result.html).toContain("#2e7d32");
      expect(result.iconSize).toEqual([32, 32]);
      expect(result.iconAnchor).toEqual([16, 32]);
    });

    test("creates offline site icon", () => {
      const result = getSiteIcon({}, 0);

      expect(result.html).toContain("#d32f2f");
    });

    test("creates RNMS down site icon", () => {
      const result = getSiteIcon({}, 2);

      expect(result.html).toContain("#f3c106");
    });

    test("creates maintenance non-OPS icon", () => {
      const result = getSiteIcon({ maintenanceType: 1 }, 3);

      expect(result.html).toContain("#b8860b");
    });

    test("creates maintenance R-OPS icon", () => {
      const result = getSiteIcon({ maintenanceType: 2 }, 3);

      expect(result.html).toContain("#34b8b8");
    });

    test("uses fallback color for unknown status", () => {
      const result = getSiteIcon({}, 99);

      expect(result.html).toContain("#757575");
    });

    test("uses blinking ring when isBlinking is true", () => {
      const result = getSiteIcon({}, 1, true, 1);

      expect(result.html).toContain("maintenance-blink-ring");
      expect(result.html).toContain("--blink-color: #b8860b");
    });

    test("does not use blinking ring when isBlinking is false", () => {
      const result = getSiteIcon({}, 1, false, 1);

      expect(result.html).not.toContain("maintenance-blink-ring");
    });

    test("uses R-OPS blink color", () => {
      const result = getSiteIcon({}, 1, true, 2);

      expect(result.html).toContain("--blink-color: #34b8b8");
    });

    test("uses online blink color for maintenance type zero", () => {
      const result = getSiteIcon({}, 1, true, 0);

      expect(result.html).toContain("--blink-color: #2e7d32");
    });

    test("uses online blink color for UP status", () => {
      const result = getSiteIcon({}, 1, true, "UP");

      expect(result.html).toContain("--blink-color: #2e7d32");
    });

    test("uses offline blink color for DOWN status", () => {
      const result = getSiteIcon({}, 1, true, "DOWN");

      expect(result.html).toContain("--blink-color: #d32f2f");
    });

    test("uses RNMS down blink color", () => {
      const result = getSiteIcon({}, 1, true, "NMSDOWN");

      expect(result.html).toContain("--blink-color: #f3c106");
    });

    test("uses default blink color for unknown maintenance type", () => {
      const result = getSiteIcon({}, 1, true, 99);

      expect(result.html).toContain("--blink-color: #f3c108");
    });

    test("handles maintenance without a valid maintenance type", () => {
      const result = getSiteIcon({}, 3);

      expect(result.html).toContain('fill="undefined"');
    });

    test("calls Leaflet divIcon", () => {
      getSiteIcon({}, 1);

      expect(L.divIcon).toHaveBeenCalledTimes(1);
    });
  });
});
