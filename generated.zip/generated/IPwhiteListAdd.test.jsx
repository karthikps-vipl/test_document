
import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";

import IPwhiteListAdd from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Security/IPwhitelisting/IPwhiteListAdd";

import { SecurityAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import { useSelector } from "react-redux";

/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  SecurityAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  ADD_ALLOWED_IP: "/add-allowed-ip",
}));

jest.mock("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.mock("react-redux", () => ({
  ...jest.requireActual("react-redux"),
  useSelector: jest.fn(),
}));

jest.mock("@/components/Reusable/Input/MInput", () => ({
  __esModule: true,
  default: ({ value, onChange, error, helperText, placeholder }) => (
    <div>
      <input
        aria-label="IP Address"
        data-testid="ip-input"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />
      {error && <span data-testid="ip-error">{helperText}</span>}
    </div>
  ),
}));

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <>
      <button
        data-testid="add-button"
        onClick={onClick}
        disabled={disabled}
      >
        {children}
      </button>

      {/* Calls the same handler without an event argument */}
      <button
        data-testid="add-without-event"
        onClick={() => onClick()}
        disabled={disabled}
      >
        Add without event
      </button>
    </>
  ),
}));

let mockDialogConfirm;
let mockDialogClose;
let mockDialogProps;

jest.mock("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => {
    mockDialogConfirm = props.onConfirm;
    mockDialogClose = props.onClose;
    mockDialogProps = props;

    return props.open ? (
      <div data-testid="confirm-dialog">
        <span>{props.title}</span>
        <span>{props.message}</span>
        <button
          data-testid="confirm-button"
          onClick={props.onConfirm}
        >
          Confirm
        </button>
        <button
          data-testid="cancel-button"
          onClick={props.onClose}
        >
          Cancel
        </button>
      </div>
    ) : null;
  },
}));

jest.mock("@/assets/SVGIcons/question_mark.svg", () => "question.svg");

/* -------------------------------------------------------
   HELPERS
------------------------------------------------------- */

const defaultProps = (overrides = {}) => ({
  data: {},
  selectedIp: "",
  onChangeSuccess: jest.fn(),
  selectedTerminalId: 10,
  onClose: jest.fn(),
  onRefresh: jest.fn(),
  isGrandchildFullScreen: false,
  ...overrides,
});

const validIPv4 = "192.168.1.10";
const validIPv6 = "2001:db8::1";

const enterIP = (value) => {
  fireEvent.change(screen.getByTestId("ip-input"), {
    target: { value },
  });
};

const selectIPv6 = () => {
  fireEvent.click(screen.getByLabelText("IPv6"));
};

const openConfirmation = () => {
  enterIP(validIPv4);
  fireEvent.click(screen.getByTestId("add-button"));
  expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();
};

const confirmAndWait = async () => {
  fireEvent.click(screen.getByTestId("confirm-button"));
};

const renderComponent = (props = {}, siteDetails = { id: 20 }) => {
  useSelector.mockImplementation((selector) =>
    selector({
      nodeDetails: { siteDetails },
    })
  );

  return render(<IPwhiteListAdd {...defaultProps(props)} />);
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("IPwhiteListAdd Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockDialogConfirm = undefined;
    mockDialogClose = undefined;
    mockDialogProps = undefined;

    useSelector.mockImplementation((selector) =>
      selector({
        nodeDetails: {
          siteDetails: { id: 20 },
        },
      })
    );

    SecurityAxios.mockResolvedValue({
      data: {
        status: 1,
        message: "IP added successfully",
      },
    });

    jest.spyOn(console, "log").mockImplementation(() => {});
    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIAL RENDER
  ------------------------------------------------------- */

  describe("Initial rendering", () => {
    it("renders IPv4 as the default selection", () => {
      renderComponent();

      expect(screen.getByLabelText("IPv4")).toBeChecked();
      expect(screen.getByLabelText("IPv6")).not.toBeChecked();
    });

    it("renders empty IP input when selectedIp is empty", () => {
      renderComponent();

      expect(screen.getByTestId("ip-input")).toHaveValue("");
    });

    it("initializes IP input with selectedIp", () => {
      renderComponent({
        selectedIp: validIPv4,
      });

      expect(screen.getByTestId("ip-input")).toHaveValue(validIPv4);
    });

    it("renders the IPv4 placeholder by default", () => {
      renderComponent();

      expect(screen.getByTestId("ip-input")).toHaveAttribute(
        "placeholder",
        "___.___.___.___"
      );
    });

    it("passes fullscreen prop to MDialog", () => {
      renderComponent({
        isGrandchildFullScreen: true,
      });

      expect(mockDialogProps.isGrandchildFullScreen).toBe(true);
      expect(mockDialogProps.mode).toBe("grandchild");
      expect(mockDialogProps.variant).toBe("warning");
    });

    it("renders Add button disabled initially", () => {
      renderComponent();

      expect(screen.getByTestId("add-button")).toBeDisabled();
    });
  });

  /* -------------------------------------------------------
     IP VERSION CHANGE
  ------------------------------------------------------- */

  describe("IP version selection", () => {
    it("switches from IPv4 to IPv6 and clears existing IP", () => {
      renderComponent({
        selectedIp: validIPv4,
      });

      selectIPv6();

      expect(screen.getByLabelText("IPv6")).toBeChecked();
      expect(screen.getByTestId("ip-input")).toHaveValue("");
      expect(screen.getByTestId("ip-input")).toHaveAttribute(
        "placeholder",
        "e.g. 2001:0db8::1"
      );
    });

    it("switches from IPv6 back to IPv4", () => {
      renderComponent();

      selectIPv6();

      fireEvent.click(screen.getByLabelText("IPv4"));

      expect(screen.getByLabelText("IPv4")).toBeChecked();
      expect(screen.getByTestId("ip-input")).toHaveValue("");
      expect(screen.getByTestId("ip-input")).toHaveAttribute(
        "placeholder",
        "___.___.___.___"
      );
    });

    it("clears the validation error when IP version changes", () => {
      renderComponent();

      enterIP("192.168.1");

      expect(screen.getByTestId("ip-error")).toBeInTheDocument();

      selectIPv6();

      expect(screen.queryByTestId("ip-error")).not.toBeInTheDocument();
    });
  });

  /* -------------------------------------------------------
     IPV4 INPUT SANITIZATION
  ------------------------------------------------------- */

  describe("IPv4 input handling", () => {
    it("removes alphabetic and special characters", () => {
      renderComponent();

      enterIP("abc192.168.1.10xyz");

      expect(screen.getByTestId("ip-input")).toHaveValue(validIPv4);
    });

    it("removes repeated consecutive dots", () => {
      renderComponent();

      enterIP("192..168...1.10");

      expect(screen.getByTestId("ip-input")).toHaveValue(validIPv4);
    });

    it("allows empty segments while typing", () => {
      renderComponent();

      enterIP("192.168.1.");

      expect(screen.getByTestId("ip-input")).toHaveValue("192.168.1.");
      expect(screen.getByTestId("ip-error")).toBeInTheDocument();
    });

    it("ignores input containing more than four segments", () => {
      renderComponent();

      enterIP("1.2.3.4");

      enterIP("1.2.3.4.5");

      expect(screen.getByTestId("ip-input")).toHaveValue("1.2.3.4");
    });

    it("ignores IPv4 octets greater than 255", () => {
      renderComponent();

      enterIP("192.168.1.10");

      enterIP("192.168.1.256");

      expect(screen.getByTestId("ip-input")).toHaveValue(validIPv4);
    });

    it.each([
      "01.1.1.1",
      "001.2.3.4",
      "192.168.01.1",
      "10.0.0.01",
    ])("rejects leading zero octets: %s", (value) => {
      renderComponent();

      enterIP(value);

      expect(screen.getByTestId("ip-input")).toHaveValue("");
    });

    it("allows a single zero octet", () => {
      renderComponent();

      enterIP("0.168.1.10");

      expect(screen.getByTestId("ip-input")).toHaveValue("0.168.1.10");
    });

    it("allows octet value 255", () => {
      renderComponent();

      enterIP("255.255.255.255");

      expect(screen.getByTestId("ip-input")).toHaveValue(
        "255.255.255.255"
      );

      expect(screen.queryByTestId("ip-error")).not.toBeInTheDocument();
    });

    it("rejects incomplete IPv4 addresses", () => {
      renderComponent();

      enterIP("192.168.1");

      expect(screen.getByTestId("ip-error")).toHaveTextContent(
        "Invalid IPv4 Address format"
      );
    });

    it("rejects empty IPv4 input", () => {
      renderComponent();

      enterIP("");

      expect(screen.getByTestId("ip-error")).toHaveTextContent(
        "IP Address cannot be empty"
      );
    });

    it("clears IPv4 validation error after entering a valid IP", () => {
      renderComponent();

      enterIP("192.168.1");

      expect(screen.getByTestId("ip-error")).toBeInTheDocument();

      enterIP(validIPv4);

      expect(screen.queryByTestId("ip-error")).not.toBeInTheDocument();
    });
  });

  /* -------------------------------------------------------
     IPV6 INPUT HANDLING
  ------------------------------------------------------- */

  describe("IPv6 input handling", () => {
    beforeEach(() => {
      renderComponent();
      selectIPv6();
    });

    it("converts IPv6 input to lowercase", () => {
      enterIP("2001:DB8::A");

      expect(screen.getByTestId("ip-input")).toHaveValue("2001:db8::a");
    });

    it("removes unsupported IPv6 characters", () => {
      enterIP("2001:db8::g1");

      expect(screen.getByTestId("ip-input")).toHaveValue("2001:db8::1");
    });

    it("accepts a valid IPv6 address", () => {
      enterIP(validIPv6);

      expect(screen.getByTestId("ip-input")).toHaveValue(validIPv6);
      expect(screen.queryByTestId("ip-error")).not.toBeInTheDocument();
    });

    it("rejects IPv6 input without a colon", () => {
      enterIP("abcd");

      expect(screen.getByTestId("ip-error")).toHaveTextContent(
        "Invalid IPv6 Address format"
      );
    });

    it("rejects empty IPv6 input", () => {
      enterIP("");

      expect(screen.getByTestId("ip-error")).toHaveTextContent(
        "IP Address cannot be empty"
      );
    });

    it("clears IPv6 error after valid input", () => {
      enterIP("abcd");

      expect(screen.getByTestId("ip-error")).toBeInTheDocument();

      enterIP(validIPv6);

      expect(screen.queryByTestId("ip-error")).not.toBeInTheDocument();
    });
  });

  /* -------------------------------------------------------
     ADD SUBMISSION
  ------------------------------------------------------- */

  describe("Add submission", () => {
    it("opens confirmation dialog for valid IPv4", () => {
      renderComponent();

      enterIP(validIPv4);

      fireEvent.click(screen.getByTestId("add-button"));

      expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();
    });

    it("opens confirmation dialog for valid IPv6", () => {
      renderComponent();

      selectIPv6();
      enterIP(validIPv6);

      fireEvent.click(screen.getByTestId("add-button"));

      expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();
    });

    it("calls submit handler without an event argument", () => {
      renderComponent();

      enterIP(validIPv4);

      fireEvent.click(screen.getByTestId("add-without-event"));

      expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();
    });

    it("does not open dialog for invalid IP", () => {
      renderComponent();

      enterIP("192.168.1");

      expect(screen.getByTestId("add-button")).toBeDisabled();
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
    });

    it("closes confirmation dialog when cancelled", () => {
      renderComponent();

      openConfirmation();

      fireEvent.click(screen.getByTestId("cancel-button"));

      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
      expect(SecurityAxios).not.toHaveBeenCalled();
    });
  });

  /* -------------------------------------------------------
     TERMINAL ID RESOLUTION
  ------------------------------------------------------- */

  describe("Terminal ID resolution", () => {
    it("uses selectedTerminalId when supplied", async () => {
      renderComponent(
        {
          selectedTerminalId: 10,
          data: { selectedTerminalId: 30 },
        },
        { id: 20 }
      );

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(
          "/add-allowed-ip",
          "post",
          {
            ipAddress: validIPv4,
            terminalTypeId: 10,
          }
        );
      });
    });

    it("uses data.selectedTerminalId when selectedTerminalId is null", async () => {
      renderComponent(
        {
          selectedTerminalId: null,
          data: { selectedTerminalId: 30 },
        },
        { id: 20 }
      );

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(
          "/add-allowed-ip",
          "post",
          {
            ipAddress: validIPv4,
            terminalTypeId: 30,
          }
        );
      });
    });

    it("uses siteDetails.id when both supplied terminal IDs are null", async () => {
      renderComponent(
        {
          selectedTerminalId: null,
          data: {},
        },
        { id: 20 }
      );

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(
          "/add-allowed-ip",
          "post",
          {
            ipAddress: validIPv4,
            terminalTypeId: 20,
          }
        );
      });
    });

    it("shows an error when no terminal ID is available", () => {
      renderComponent(
        {
          selectedTerminalId: null,
          data: {},
        },
        {}
      );

      openConfirmation();

      fireEvent.click(screen.getByTestId("confirm-button"));

      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Terminal Type ID is missing.",
        "error"
      );

      expect(SecurityAxios).not.toHaveBeenCalled();
    });
  });

  /* -------------------------------------------------------
     SUCCESS API RESPONSE
  ------------------------------------------------------- */

  describe("Successful IP addition", () => {
    it("saves IP successfully and calls onRefresh", async () => {
      const props = defaultProps();

      renderComponent(props);

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(SecurityAxios).toHaveBeenCalledWith(
          "/add-allowed-ip",
          "post",
          {
            ipAddress: validIPv4,
            terminalTypeId: 10,
          }
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success!",
        "IP added successfully",
        "success"
      );

      expect(props.onRefresh).toHaveBeenCalledTimes(1);
      expect(props.onChangeSuccess).not.toHaveBeenCalled();
      expect(props.onClose).toHaveBeenCalledTimes(1);

      expect(screen.getByTestId("ip-input")).toHaveValue("");
    });

    it("uses default success message when API message is missing", async () => {
      SecurityAxios.mockResolvedValueOnce({
        data: { status: 1 },
      });

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Success!",
          "IP Address added successfully!",
          "success"
        );
      });
    });

    it("calls onChangeSuccess when onRefresh is not provided", async () => {
      const onChangeSuccess = jest.fn();

      renderComponent({
        onRefresh: undefined,
        onChangeSuccess,
      });

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(onChangeSuccess).toHaveBeenCalledTimes(1);
      });
    });

    it("does not call refresh callbacks when neither is provided", async () => {
      renderComponent({
        onRefresh: undefined,
        onChangeSuccess: undefined,
      });

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Success!",
          "IP added successfully",
          "success"
        );
      });
    });

    it("does not call onClose when onClose is not provided", async () => {
      renderComponent({
        onClose: undefined,
      });

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Success!",
          "IP added successfully",
          "success"
        );
      });
    });
  });

  /* -------------------------------------------------------
     API FAILURE RESPONSE
  ------------------------------------------------------- */

  describe("API failure responses", () => {
    it("shows API error message when status is not 1", async () => {
      SecurityAxios.mockResolvedValueOnce({
        data: {
          status: 0,
          message: "IP already exists",
        },
      });

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "IP already exists",
          "error"
        );
      });
    });

    it("uses default failure message when API message is missing", async () => {
      SecurityAxios.mockResolvedValueOnce({
        data: {
          status: 0,
        },
      });

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to save IP Address.",
          "error"
        );
      });
    });

    it("handles undefined response data", async () => {
      SecurityAxios.mockResolvedValueOnce({});

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to save IP Address.",
          "error"
        );
      });
    });
  });

  /* -------------------------------------------------------
     API EXCEPTION HANDLING
  ------------------------------------------------------- */

  describe("API exception handling", () => {
    it("shows server error message from rejected response", async () => {
      SecurityAxios.mockRejectedValueOnce({
        response: {
          data: {
            message: "Server unavailable",
          },
        },
      });

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Server unavailable",
          "error"
        );
      });
    });

    it("uses default error message when response data is unavailable", async () => {
      SecurityAxios.mockRejectedValueOnce(new Error("Network error"));

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to save IP Address. Please try again.",
          "error"
        );
      });
    });

    it("uses default error message when server message is empty", async () => {
      SecurityAxios.mockRejectedValueOnce({
        response: {
          data: {
            message: "",
          },
        },
      });

      renderComponent();

      openConfirmation();
      await confirmAndWait();

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to save IP Address. Please try again.",
          "error"
        );
      });
    });
  });

  /* -------------------------------------------------------
     SAVING STATE AND FINALLY
  ------------------------------------------------------- */

  describe("Saving state", () => {
    it("disables Add button while API request is pending", async () => {
      let resolveRequest;

      SecurityAxios.mockReturnValueOnce(
        new Promise((resolve) => {
          resolveRequest = resolve;
        })
      );

      renderComponent();

      openConfirmation();

      await act(async () => {
        fireEvent.click(screen.getByTestId("confirm-button"));
      });

      expect(screen.getByTestId("add-button")).toBeDisabled();

      await act(async () => {
        resolveRequest({
          data: {
            status: 1,
            message: "Saved",
          },
        });
      });

      await waitFor(() => {
        expect(screen.getByTestId("add-button")).toBeDisabled();
      });
    });

    it("ignores a second confirmation while saving", async () => {
      let resolveRequest;

      SecurityAxios.mockReturnValueOnce(
        new Promise((resolve) => {
          resolveRequest = resolve;
        })
      );

      renderComponent();

      openConfirmation();

      await act(async () => {
        mockDialogConfirm();
      });

      // Capture the latest callback after saving becomes true.
      await waitFor(() => {
        expect(screen.getByTestId("add-button")).toBeDisabled();
      });

      await act(async () => {
        mockDialogConfirm();
      });

      expect(SecurityAxios).toHaveBeenCalledTimes(1);

      await act(async () => {
        resolveRequest({
          data: { status: 1 },
        });
      });
    });

    it("re-enables Add button after API failure", async () => {
      SecurityAxios.mockRejectedValueOnce(new Error("failure"));

      renderComponent();

      openConfirmation();

      fireEvent.click(screen.getByTestId("confirm-button"));

      await waitFor(() => {
        expect(
          screen.getByTestId("add-button")
        ).toBeEnabled();
      });
    });
  });
});
 