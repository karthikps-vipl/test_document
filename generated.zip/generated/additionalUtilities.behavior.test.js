const mockFaultAxios = jest.fn();
const mockPerformanceAxios = jest.fn();
jest.mock('@/RestAPI/api/axiosApicall', () => ({
  FaultAxios: (...args) => mockFaultAxios(...args),
  PerformanceAxios: (...args) => mockPerformanceAxios(...args),
}));

import { determineStatus, mapNodeDetails, mapResourceType, mapSegmentInfo, mapSnmpProfile, mapPollingInfo, mergeSavedRackWithReduxNodes } from '../../src/store/features/Topology/utils';
import { dispatchContextAction } from '../../src/core/actions/contextActionDispatcher';
import { useModalStore } from '../../src/core/modal/modalStore';

import { refreshAlarmData } from '../../src/utility/alarmService';
import { startRealTimeStream, stopRealTimeStream } from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/Reports/realtimeService';

beforeEach(() => {
  mockFaultAxios.mockReset();
  mockPerformanceAxios.mockReset();
  jest.spyOn(console, 'log').mockImplementation(() => {});
  jest.spyOn(console, 'error').mockImplementation(() => {});
});

describe('topology data mapping helpers', () => {
  test.each([
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 1 } }, isMaintainance: true }, { resourceStateName: 'maintainance', maxSeverity: null }],
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 1 } }, isDiscovered: true, nePollingInfo: { isReachable: true, maxSeverity: 2 } }, { resourceStateName: 'up', maxSeverity: 2 }],
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 1 } }, isDiscovered: true, nePollingInfo: { isReachable: false } }, { resourceStateName: 'down', maxSeverity: null }],
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 1 } }, isDiscovered: true, nePollingInfo: {} }, { resourceStateName: 'up', maxSeverity: null }],
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 1, resourceStateName: 'Unknown' } }, isDiscovered: false, maxSeverity: 3 }, { resourceStateName: 'Unknown', maxSeverity: 3 }],
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } }, { resourceStateName: 'unmanaged', maxSeverity: null }],
    [{ imResourceType: { imResourceStateInfo: { resourceStateId: 99 } } }, {}],
  ])('determines device status from backend state %#', (input, expected) => {
    expect(determineStatus(input)).toEqual(expected);
  });

  test('maps nested device, resource, segment, SNMP and polling structures safely', () => {
    expect(mapResourceType({ resourceTypeId: 1, imResourceStateInfo: { resourceStateId: 2 }, data: { ssh: true } })).toMatchObject({ resourceTypeId: 1, imResourceStateInfo: { resourceStateId: 2 }, data: { ssh: true } });
    expect(mapResourceType(null)).toMatchObject({ imResourceStateInfo: {}, imCommunicationType: {}, nodeType: {}, data: {} });
    expect(mapSegmentInfo({ segmentId: 3, segmentName: 'Core' })).toMatchObject({ segmentId: 3, segmentName: 'Core' });
    expect(mapSnmpProfile({ snmpProfileId: 4, version: 'v3' })).toMatchObject({ snmpProfileId: 4, version: 'v3' });
    expect(mapPollingInfo({ id: 5, pollingInterval: 30 })).toMatchObject({ id: 5, pollingInterval: 30 });
    const mapped = mapNodeDetails({ id: 7, resourceIp: '10.0.0.7', imResourceType: {}, imSegmentInfo: {}, tmSnmpProfile: {}, nePollingInfo: {} });
    expect(mapped).toMatchObject({ ids: 7, resourceIp: '10.0.0.7' });
  });

  test('merges saved rack layout with current Redux device data and handles invalid inputs', () => {
    const saved = [
      { id: 'a', position: { x: 1, y: 2 }, data: { resourceId: 1, label: 'Saved' } },
      { id: 'b', position: { x: 3, y: 4 }, data: { resourceId: 2, label: 'Removed' } },
      { id: 'c', position: { x: 5, y: 6 }, data: { label: 'No resource ID' } },
    ];
    const redux = [{ id: 'latest', data: { resourceId: 1, label: 'Live', status: 'up' } }];
    const merged = mergeSavedRackWithReduxNodes(saved, redux);
    expect(merged[0]).toMatchObject({ id: 'a', position: { x: 1, y: 2 }, data: { resourceId: 1, label: 'Live', status: 'up' } });
    expect(merged[1].data.label).toBe('Removed');
    expect(merged[2].type).toBe('rackNode');
    expect(mergeSavedRackWithReduxNodes(null, redux)).toEqual([]);
    expect(mergeSavedRackWithReduxNodes(saved, null)).toEqual(saved);
  });
});

describe('alarm refresh service', () => {
  test('transforms successful alarm data and dispatches badge counts', async () => {
    mockFaultAxios.mockResolvedValue({ status: 200, data: [{ alarmName: 'A' }, { alarmName: 'B' }] });
    const dispatch = jest.fn();
    const result = await refreshAlarmData(dispatch);
    expect(result).toEqual([{ alarmName: 'A', key: 0 }, { alarmName: 'B', key: 1 }]);
    expect(dispatch).toHaveBeenCalledTimes(1);
  });

  test('returns null for non-200 responses and rejected requests', async () => {
    mockFaultAxios.mockResolvedValueOnce({ status: 503 }).mockRejectedValueOnce(new Error('offline'));
    expect(await refreshAlarmData(jest.fn())).toBeNull();
    expect(await refreshAlarmData(jest.fn())).toBeNull();
  });
});

describe('real-time performance stream service', () => {
  test('starts and stops a stream with numeric parameter and default interval', async () => {
    mockPerformanceAxios.mockResolvedValue({ status: 200 });
    const form = { performanceDevice: 'R1', performanceParameter: '1400' };
    await startRealTimeStream(form);
    expect(mockPerformanceAxios.mock.calls[0][1]).toBe('post');
    expect(mockPerformanceAxios.mock.calls[0][2]).toMatchObject({ resourceInfoBean: { resourceId: 'R1' }, perfParamInfoBean: { paramId: 1400 }, interval: '30' });
    await stopRealTimeStream({ ...form, interval: '10' });
    expect(mockPerformanceAxios.mock.calls[1][2]).toMatchObject({ perfParamInfoBean: { preporaramId: 1400 }, interval: '10' });
  });
});

describe('context action dispatcher', () => {
  test('opens modal using terminal type from the supported node shapes', () => {
    const openModal = jest.fn();
    const originalGetState = useModalStore.getState;
    useModalStore.getState = () => ({ openModal });
    try {
      const node = { data: { terminalTypeName: 'MK-II' } };
      dispatchContextAction({ action: 'edit', node, source: 'topology' });
      expect(openModal).toHaveBeenCalledWith('edit', { node, source: 'topology', terminalType: 'MK-II' });
      dispatchContextAction({ action: 'view', node: { data: { imTerminalType: { terminalTypeName: 'CNMS' } } } });
      expect(openModal).toHaveBeenLastCalledWith('view', expect.objectContaining({ terminalType: 'CNMS' }));
    } finally {
      useModalStore.getState = originalGetState;
    }
  });
});
