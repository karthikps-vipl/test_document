import reducer, {
  setSiteDetails, setTerminalTypes, setDiscoveryResults, setDiscoveryProgress,
  resetDiscoveryProgress, clearSiteDiscoveryData,
} from '../../src/store/features/Cnms/CnmsDiscovery/siteDiscoverySlice';

describe('CNMS site discovery slice', () => {
  test('initializes empty discovery collections and progress', () => {
    expect(reducer(undefined, { type: '@@INIT' })).toMatchObject({ siteDetails: [], terminalTypes: [], discoveryResults: [], discoveryProgress: { activeStep: 0, percentage: 0, isRunning: false } });
  });
  test('stores arrays and safely replaces non-array payloads with empty arrays', () => {
    let state = reducer(undefined, setSiteDetails([{ siteId: 1 }]));
    state = reducer(state, setTerminalTypes([{ id: 2 }]));
    state = reducer(state, setDiscoveryResults([{ ip: '10.0.0.1' }]));
    expect(state.siteDetails).toHaveLength(1);
    expect(state.terminalTypes).toHaveLength(1);
    expect(state.discoveryResults).toHaveLength(1);
    state = reducer(state, setSiteDetails({ invalid: true }));
    expect(state.siteDetails).toEqual([]);
  });
  test('merges partial progress and resets to defaults', () => {
    let state = reducer(undefined, setDiscoveryProgress({ activeStep: 2, percentage: 50, isRunning: true }));
    expect(state.discoveryProgress).toMatchObject({ activeStep: 2, percentage: 50, isRunning: true, message: '' });
    state = reducer(state, resetDiscoveryProgress());
    expect(state.discoveryProgress).toEqual({ activeStep: 0, message: '', percentage: 0, isRunning: false, socketStage: null });
  });
  test('clears discovery data collections without changing progress', () => {
    let state = reducer(undefined, setSiteDetails([{ id: 1 }]));
    state = reducer(state, setDiscoveryProgress({ percentage: 70 }));
    state = reducer(state, clearSiteDiscoveryData());
    expect(state.siteDetails).toEqual([]);
    expect(state.discoveryProgress.percentage).toBe(70);
  });
});
