import React from "react";
import { jest } from "@jest/globals";
import { render, screen, act, cleanup } from "@testing-library/react";
import DateTime from "../../src/components/Topbar/DateTime";

const getExpectedDate = (date) =>
  date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

const getExpectedTime = (date) =>
  date.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

describe("DateTime", () => {
  beforeEach(() => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date(2026, 0, 15, 10, 20, 30));
  });

  afterEach(() => {
    cleanup();
    jest.useRealTimers();
  });

  test("renders the current date and time in the configured formats", () => {
    const now = new Date();

    render(<DateTime />);

    expect(screen.getByText(getExpectedDate(now))).toBeInTheDocument();
    expect(screen.getByText(getExpectedTime(now))).toBeInTheDocument();
  });

  test("updates the displayed time every second", () => {
    render(<DateTime />);

    const initialTime = getExpectedTime(new Date());

    act(() => {
      jest.advanceTimersByTime(1000);
    });

    const updatedTime = getExpectedTime(new Date());

    expect(updatedTime).not.toBe(initialTime);
    expect(screen.getByText(updatedTime)).toBeInTheDocument();
  });

  test("updates the displayed date when the clock crosses midnight", () => {
    jest.setSystemTime(new Date(2026, 0, 15, 23, 59, 59));

    render(<DateTime />);

    expect(
      screen.getByText(getExpectedDate(new Date()))
    ).toBeInTheDocument();

    act(() => {
      jest.advanceTimersByTime(1000);
    });

    expect(
      screen.getByText(getExpectedDate(new Date()))
    ).toBeInTheDocument();
  });

  test("starts one interval and clears it when unmounted", () => {
    const { unmount } = render(<DateTime />);

    expect(jest.getTimerCount()).toBe(1);

    unmount();

    expect(jest.getTimerCount()).toBe(0);
  });
});
