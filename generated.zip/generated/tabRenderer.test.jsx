jest.mock('../../src/components/Dialogs/components/GridRenderer', () => ({
  __esModule: true,
  default: ({ widgets, layout, node, liveData, saving }) => (
    <div data-testid="grid-renderer" data-widget-count={widgets.length} data-layout-count={layout.length} data-node={node?.id} data-live={liveData?.value} data-saving={String(Boolean(saving))} />
  ),
}));
import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import TabRenderer from '../../src/components/Dialogs/components/TabRenderer';

describe('TabRenderer', () => {
  test('renders selected tab content and passes layout/data props to grid renderer', () => {
    render(<TabRenderer
      tabs={[{ name: 'General', widget: [{ id: 1 }], layout: [{ i: 'w1' }] }]}
      activeTab={0}
      onTabChange={jest.fn()}
      node={{ id: 'R1' }}
      liveData={{ value: 'online' }}
      saving
    />);
    expect(screen.queryByRole('tab')).not.toBeInTheDocument();
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-widget-count', '1');
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-layout-count', '1');
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-node', 'R1');
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-live', 'online');
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-saving', 'true');
  });

  test('renders tabs and reports selected tab changes', () => {
    const onTabChange = jest.fn();
    render(<TabRenderer
      tabs={[{ name: 'General', widget: [], layout: [] }, { name: 'Network', widget: [], layout: [] }]}
      activeTab={0}
      onTabChange={onTabChange}
      node={{ id: 'R1' }}
    />);
    expect(screen.getByRole('tab', { name: 'General' })).toBeInTheDocument();
    expect(screen.getByRole('tab', { name: 'Network' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('tab', { name: 'Network' }));
    expect(onTabChange).toHaveBeenCalled();
  });

  test('uses empty widget and layout defaults when active tab has no arrays', () => {
    render(<TabRenderer tabs={[{ name: 'Empty' }]} activeTab={0} onTabChange={jest.fn()} />);
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-widget-count', '0');
    expect(screen.getByTestId('grid-renderer')).toHaveAttribute('data-layout-count', '0');
  });
});
