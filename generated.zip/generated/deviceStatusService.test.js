jest.mock('@/RestAPI/api/axiosApicall', () => ({ ConfigurationAxios: jest.fn() }));
import { ConfigurationAxios } from '@/RestAPI/api/axiosApicall';
import { GET_STATUS_BY_DEVICE_AND_TAB_CNMS } from '@/RestAPI/url/cnmsEndPoint';
import { FETCH_OID_MAPPING, GET_STATUS_BY_DEVICE_AND_TAB, SAVE_SNMP_DATA_FOR_DEVICE } from '@/RestAPI/url/endpoint';
import { fetchOidMapping, getDeviceStatusByTab, getDeviceStatusByTabForCnms, saveSnmpDataForDevice } from '../../src/core/services/deviceStatus.service';

describe('device status service', () => {
  beforeEach(() => jest.clearAllMocks());
  test('posts OID mapping payload and defaults missing data to empty list', async () => {
    const payload = ['1.2.3'];
    ConfigurationAxios.mockResolvedValueOnce({ data: [{ oidName: '1.2.3' }] });
    await expect(fetchOidMapping(payload)).resolves.toEqual([{ oidName: '1.2.3' }]);
    expect(ConfigurationAxios).toHaveBeenCalledWith(FETCH_OID_MAPPING, 'post', payload);
    ConfigurationAxios.mockResolvedValueOnce({});
    await expect(fetchOidMapping(payload)).resolves.toEqual([]);
  });
  test('gets RNMS status by device, screen and tab', async () => {
    ConfigurationAxios.mockResolvedValue({ data: { status: 'up' } });
    await expect(getDeviceStatusByTab('R1', 'status', 'general')).resolves.toEqual({ status: 'up' });
    expect(ConfigurationAxios).toHaveBeenCalledWith(`${GET_STATUS_BY_DEVICE_AND_TAB}/R1/status/general`, 'get');
  });
  test('gets CNMS status by terminal, site, resource, screen and tab', async () => {
    ConfigurationAxios.mockResolvedValue({ data: { status: 'down' } });
    await expect(getDeviceStatusByTabForCnms(1, 2, 3, 'status', 'ports')).resolves.toEqual({ status: 'down' });
    expect(ConfigurationAxios).toHaveBeenCalledWith(`${GET_STATUS_BY_DEVICE_AND_TAB_CNMS}/1/2/3/status/ports`, 'get');
  });
  test('posts SNMP data and returns API response data', async () => {
    const payload = { oid: '1.2.3', value: '10' };
    ConfigurationAxios.mockResolvedValue({ data: { saved: true } });
    await expect(saveSnmpDataForDevice('R1', payload)).resolves.toEqual({ saved: true });
    expect(ConfigurationAxios).toHaveBeenCalledWith(`${SAVE_SNMP_DATA_FOR_DEVICE}/R1/0`, 'post', payload);
  });
});
