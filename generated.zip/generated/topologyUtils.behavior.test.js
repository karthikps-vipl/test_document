import {
  mapNodeData,
  SWITCH_TEMPLATE_CONFIGS,
  createTopologyNodeId,
  getSwitchTemplateConfig,
  getPortStatusKey,
  SEVERITY_COLOR,
  getBadgeStyles,
  buildSwitchPorts,
  isSwitchPortNode,
  normalizeSwitchPorts,
  createSwitchPaletteNode,
  getTemplateKeyByResource,
  createDynamicSwitchNode,
  transformResourceToNode,
  normalizeTopologyNode,
  getEdgeColor,
  getSuperAdminDeviceStatus,
  getDeviceStatus,
  getDeviceStatusCnms,
  filterSwitchPortsImageNode,
  getPortStatus,
} from '../../src/Pages/Rnmsdashboard/Topology/utils';

describe('Topology utility functions', () => {
  test('maps resource, segment, SNMP and polling fields into a topology node', () => {
    const mapped = mapNodeData({
      id: 12,
      resourceName: 'Router',
      imResourceType: {
        resourceTypeId: 3,
        resourceTypeName: 'Router',
        imResourceStateInfo: { resourceStateId: 1 },
        imCommunicationType: { id: 2, protoTypeName: 'SNMP' },
        nodeType: { id: 4, name: 'network', description: 'Network node' },
        data: { ssh: true },
      },
      imSegmentInfo: { segmentId: 7, segmentName: 'Core', segmentDesc: 'Core segment' },
      tmSnmpProfile: { snmpProfileId: 9, version: 'v3', port: 161 },
      nePollingInfo: { id: 10, pollingInterval: 30, isDefaultPolling: false },
    }, 'online', 2);

    expect(mapped).toMatchObject({
      ids: 12,
      label: 'Router',
      resourceStateName: 'online',
      maxSeverity: 2,
      imResourceType: {
        resourceTypeId: 3,
        resourceTypeName: 'Router',
        imResourceStateInfo: { resourceStateId: 1 },
        imCommunicationType: { id: 2, protoTypeName: 'SNMP' },
        nodeType: { id: 4, name: 'network', description: 'Network node' },
        data: { ssh: true },
      },
      imSegmentInfo: { segmentId: 7, segmentName: 'Core', segmentDesc: 'Core segment' },
      tmSnmpProfile: { snmpProfileId: 9, version: 'v3', port: 161 },
      nePollingInfo: { id: 10, pollingInterval: 30, isDefaultPolling: false },
    });
  });

  test('exposes known switch templates and returns null for unknown templates', () => {
    expect(getSwitchTemplateConfig('MCT_EP_SWITCH-24PORT')).toEqual(
      SWITCH_TEMPLATE_CONFIGS['MCT_EP_SWITCH-24PORT']
    );
    expect(getSwitchTemplateConfig('missing')).toBeNull();
    expect(getSwitchTemplateConfig('MCT_EP_SWITCH-6PORT').portCount).toBe(6);
  });

  test.each([
    [' UP ', 'up'],
    ['Down', 'down'],
    ['admin down', 'adminDown'],
    ['ADMIN_DOWN', 'adminDown'],
    ['not configured', 'notConfigured'],
    ['not_configured', 'notConfigured'],
    [1, 'up'],
    [2, 'down'],
    [3, 'testing'],
    ['unknown', 'notConfigured'],
    [null, 'notConfigured'],
  ])('normalizes port status %s', (input, expected) => {
    expect(getPortStatusKey(input)).toBe(expected);
  });

  test('returns severity badge styles for supported and fallback values', () => {
    expect(getBadgeStyles('minor')).toEqual({
      backgroundColor: SEVERITY_COLOR.minor,
      color: '#000',
    });
    expect(getBadgeStyles('MAJOR')).toEqual({
      backgroundColor: SEVERITY_COLOR.major,
      color: '#fff',
    });
    expect(getBadgeStyles('warning').backgroundColor).toBe(SEVERITY_COLOR.warning);
    expect(getBadgeStyles('unknown')).toEqual({
      backgroundColor: '#D9D9D9',
      color: '#666',
    });
    expect(getBadgeStyles(undefined).backgroundColor).toBe('#D9D9D9');
  });

  test('builds the requested number of switch ports and maps initial statuses', () => {
    expect(buildSwitchPorts(3, ['up', 'admin down', 'not configured'])).toEqual([
      { id: 'port-1', name: 'GigabitEthernet0/1', portNumber: 1, status: 'up' },
      { id: 'port-2', name: 'GigabitEthernet0/2', portNumber: 2, status: 'adminDown' },
      { id: 'port-3', name: 'GigabitEthernet0/3', portNumber: 3, status: 'notConfigured' },
    ]);
  });

  test('detects switch port nodes and normalizes missing and supplied ports', () => {
    expect(isSwitchPortNode({ switchTemplateKey: 'switch6' })).toBe(true);
    expect(isSwitchPortNode({})).toBe(false);
    expect(normalizeSwitchPorts({ switchTemplateKey: 'unknown' })).toEqual([]);

    const defaults = normalizeSwitchPorts({ switchTemplateKey: 'switch6' });
    expect(defaults).toHaveLength(6);
    expect(defaults[0]).toMatchObject({
      id: 'port-1',
      name: 'GigabitEthernet0/1',
      portNumber: 1,
      status: 'notConfigured',
    });

    const supplied = normalizeSwitchPorts({
      switchTemplateKey: 'switch6',
      ports: [
        { id: 'custom-1', name: 'uplink', portNumber: 5, portStatus: 'up' },
        { state: 'admin_down' },
      ],
    });
    expect(supplied).toEqual([
      { id: 'custom-1', name: 'uplink', portNumber: 5, status: 'up' },
      { id: 'port-2', name: 'GigabitEthernet0/2', portNumber: 2, status: 'adminDown' },
    ]);
  });

  test('creates a palette node using its switch template', () => {
    const originalCrypto = global.crypto;
    Object.defineProperty(global, 'crypto', {
      configurable: true,
      value: { getRandomValues: (array) => { array.fill(1); return array; } },
    });
    try {
      const node = createSwitchPaletteNode('MCT_EP_SWITCH-6PORT');
      expect(node).toMatchObject({
        resourceName: '6 Port Switch',
        type: 'switchPortNode',
        switchTemplateKey: 'switch6',
        style: { width: 720, height: 232 },
      });
      expect(node.resourceId).toMatch(/^MCT_EP_SWITCH-6PORT-/);
      expect(node.ports).toHaveLength(6);
      expect(createSwitchPaletteNode('missing')).toBeNull();
    } finally {
      Object.defineProperty(global, 'crypto', {
        configurable: true,
        value: originalCrypto,
      });
    }
  });

  test('chooses a template from resource type and creates dynamic switch ports', () => {
    expect(getTemplateKeyByResource({
      imResourceType: { resourceTypeName: '24 Port Switch' },
    })).toBe('switch24');
    expect(getTemplateKeyByResource({
      imResourceType: { resourceTypeName: '6 Port Switch' },
    })).toBe('switch6');
    expect(getTemplateKeyByResource({ imResourceType: { resourceTypeName: 'Other' } })).toBe('switch24');

    const dynamic = createDynamicSwitchNode({
      resourceId: 'R1',
      imResourceType: { resourceTypeName: '6 Port Switch' },
      lstPortInfoDtl: [
        { id: 'p1', portName: 'WAN', portNumber: 1, adminStatus: 1 },
        { id: 'p2', portName: 'LAN', portNumber: 2, adminStatus: 2 },
      ],
    });
    expect(dynamic).toMatchObject({
      type: 'switchPortNode',
      switchTemplateKey: 'switch6',
      ports: [
        { id: 'p1', name: 'WAN', portNumber: 1, status: 'up' },
        { id: 'p2', name: 'LAN', portNumber: 2, status: 'down' },
      ],
      style: { width: 720, height: 232 },
    });
  });

  test('transforms switch resources but leaves non-switch resources unchanged', () => {
    const switchResource = {
      resourceId: 'R1',
      imResourceType: { resourceTypeName: '24 Port Switch' },
    };
    expect(transformResourceToNode(switchResource)).toMatchObject({
      resourceId: 'R1',
      type: 'switchPortNode',
      switchTemplateKey: 'switch24',
      style: { width: 920, height: 232 },
    });
    const router = { resourceId: 'R2', imResourceType: { resourceTypeName: 'Router' } };
    expect(transformResourceToNode(router)).toBe(router);
  });

  test('normalizes topology node fields without mutating the input', () => {
    const input = { id: 'n1', position: { x: 1, y: 2 }, data: { label: 'Router' } };
    expect(normalizeTopologyNode(input)).toEqual({
      id: 'n1',
      position: { x: 1, y: 2 },
      data: { label: 'Router', type: undefined, switchTemplateKey: null, lstPortInfoDtl: [] },
      type: 'commonNode',
    });
    expect(input.data).toEqual({ label: 'Router' });
    expect(normalizeTopologyNode({
      type: 'switchPortNode',
      data: { type: 'switchPortNode', switchTemplateKey: 'switch6', lstPortInfoDtl: [{ id: 1 }] },
    }).data.lstPortInfoDtl).toEqual([{ id: 1 }]);
  });

  test.each([
    [0, 'red'],
    [1, 'green'],
    [2, '#ff9800'],
    [99, 'gray'],
  ])('maps edge status %s to a color', (status, color) => {
    expect(getEdgeColor(status)).toBe(color);
  });

  test('determines super-admin, RNMS and CNMS device states', () => {
    expect(getSuperAdminDeviceStatus({ imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } })).toBe('unmanaged');
    expect(getSuperAdminDeviceStatus({ imResourceType: { imResourceStateInfo: { resourceStateId: 1 } } })).toBe('managed');

    expect(getDeviceStatus({ imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } })).toBe('unmanaged');
    expect(getDeviceStatus({ isDiscovered: true })).toBe('online');
    expect(getDeviceStatus({ isDiscovered: true, nePollingInfo: { isReachable: false } })).toBe('offline');
    expect(getDeviceStatus({ isDiscovered: false, isMaintainance: true })).toBe('maintenance');
    expect(getDeviceStatus({ isDiscovered: false, isMaintainance: false })).toBe('undiscovered');

    expect(getDeviceStatusCnms({ imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } })).toBe('unmanaged');
    expect(getDeviceStatusCnms({ isDiscovered: true })).toBe('online');
    expect(getDeviceStatusCnms({ isDiscovered: true, isReachable: false })).toBe('offline');
    expect(getDeviceStatusCnms({ isDiscovered: false, isMaintainance: true })).toBe('maintenance');
    expect(getDeviceStatusCnms({ isDiscovered: false, isMaintainance: false })).toBe('undiscovered');
  });

  test('filters and orders valid image-node switch ports', () => {
    const result = filterSwitchPortsImageNode([
      { ifdesc: 'GigabitEthernet0/2', resourceId: 1, ifindex: 2 },
      { ifdesc: 'TenGigabitEthernet0/1', resourceId: 1, ifindex: 25 },
      { ifdesc: 'GigabitEthernet0/1', resourceId: 1, ifindex: 1 },
      { ifdesc: 'Loopback0', resourceId: 1, ifindex: 99 },
      { ifdesc: 'GigabitEthernet0/25', resourceId: 1, ifindex: 25 },
    ]);
    expect(result.map((port) => port.indexPosition)).toEqual([1, 2, 25]);
    expect(filterSwitchPortsImageNode(null)).toEqual([]);
  });

  test('maps raw admin and operational port states', () => {
    expect(getPortStatus(null)).toBe('NotConfigured');
    expect(getPortStatus({ adminstatus: 3, opstatus: 1 })).toBe('NotConfigured');
    expect(getPortStatus({ adminstatus: 0, opstatus: 1 })).toBe('NotConfigured');
    expect(getPortStatus({ adminstatus: 2, opstatus: 1 })).toBe('AdminDown');
    expect(getPortStatus({ adminstatus: 1, opstatus: 1 })).toBe('Up');
    expect(getPortStatus({ adminstatus: 1, opstatus: 2 })).toBe('OperationalDown');
    expect(getPortStatus({ adminstatus: 1, opstatus: 6 })).toBe('NotConfigured');
    expect(getPortStatus({ adminstatus: 8, opstatus: 8 })).toBe('NotConfigured');
  });

  test('generates a unique prefixed node id', () => {
    const id = createTopologyNodeId('test-node');
    expect(id).toMatch(/^test-node-[a-z0-9]+$/);
  });
});
