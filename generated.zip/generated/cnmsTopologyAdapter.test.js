import { toTopologyNodes, toTopologyEdges } from "../../src/Pages/Rnmsdashboard/Topology/cnmsTopologyAdapter";

describe("toTopologyNodes", () => {
  test("maps resource IDs to node IDs and retains resource data", () => {
    const nodes = toTopologyNodes([{
      resourceId: "R-1",
      resourceName: "Router",
      siteId: "S-1",
      imSiteDetail: { siteName: "Site One" },
      isDiscovered: 1,
      isMaintainance: 0,
      lstPortInfoDtl: [{ port: 1 }],
    }]);
    expect(nodes).toHaveLength(1);
    expect(nodes[0].id).toBe("R-1");
    expect(nodes[0].data.resourceName).toBe("Router");
    expect(nodes[0].data.siteName).toBe("Site One");
    expect(nodes[0].data.isDiscovered).toBe(true);
    expect(nodes[0].data.isMaintainance).toBe(false);
    expect(nodes[0].data.lstPortInfoDtl).toEqual([{ port: 1 }]);
  });

  test("supplies defensive defaults for missing resource fields", () => {
    const [node] = toTopologyNodes([{}]);
    expect(node.data.resourceName).toBe("");
    expect(node.data.siteId).toBe("");
    expect(node.data.siteName).toBe("");
    expect(node.data.nePollingInfo).toBeNull();
    expect(node.data.imResourceType.imResourceStateInfo).toEqual({
      resourceStateId: 2,
      resourceStateName: "Unmanaged",
    });
    expect(node.data.lstPortInfoDtl).toEqual([]);
  });

  test("returns an empty array for invalid input", () => {
    expect(toTopologyNodes(null)).toEqual([]);
    expect(toTopologyNodes({})).toEqual([]);
    expect(toTopologyNodes()).toEqual([]);
  });

  test("preserves existing nested resource state information", () => {
    const stateInfo = { resourceStateId: 1, resourceStateName: "Managed" };
    const [node] = toTopologyNodes([{ imResourceType: { imResourceStateInfo: stateInfo } }]);
    expect(node.data.imResourceType.imResourceStateInfo).toBe(stateInfo);
  });
});

test("toTopologyEdges is currently a no-op and returns an empty array", () => {
  expect(toTopologyEdges()).toEqual([]);
  expect(toTopologyEdges([{ id: 1 }])).toEqual([]);
});
