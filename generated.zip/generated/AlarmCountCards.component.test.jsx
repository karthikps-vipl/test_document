import React from "react";
import { render, screen, within } from "@testing-library/react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import AlarmCountCards from "../../src/Pages/CnmsDashboard/CnmsAlarmSummary/components/AlarmCountCards";

const testTheme = createTheme({
  palette: {
    background: {
      cardbg: "#f5f5f5",
    },
    custom: {
      commonBorder: "1px solid #cccccc",
    },
    text: {
      tabcolor: "#666666",
      primary: "#222222",
    },
  },
});

const renderCards = (summary) =>
  render(
    <ThemeProvider theme={testTheme}>
      <AlarmCountCards summary={summary} />
    </ThemeProvider>
  );

describe("AlarmCountCards", () => {
  test("renders all four alarm cards", () => {
    renderCards({ total: 25, major: 5, minor: 8, warning: 12 });

    expect(screen.getByText("Total Alarms:")).toBeInTheDocument();
    expect(screen.getByText("Major:")).toBeInTheDocument();
    expect(screen.getByText("Minor:")).toBeInTheDocument();
    expect(screen.getByText("Warning:")).toBeInTheDocument();

    expect(screen.getByText("25")).toBeInTheDocument();
    expect(screen.getByText("5")).toBeInTheDocument();
    expect(screen.getByText("8")).toBeInTheDocument();
    expect(screen.getByText("12")).toBeInTheDocument();
  });

  test("renders one icon for each alarm category with the category as alt text", () => {
    renderCards({ total: 10, major: 2, minor: 3, warning: 5 });

    expect(screen.getByRole("img", { name: "Total Alarms" })).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "Major" })).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "Minor" })).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "Warning" })).toBeInTheDocument();
    expect(screen.getAllByRole("img")).toHaveLength(4);
  });

  test("defaults every count to zero when summary is omitted", () => {
    renderCards(undefined);

    expect(screen.getAllByText("0")).toHaveLength(4);
  });

  test("defaults every count to zero when summary is null", () => {
    renderCards(null);

    expect(screen.getAllByText("0")).toHaveLength(4);
  });

  test("defaults missing individual summary properties to zero", () => {
    renderCards({ total: 7 });

    expect(screen.getByText("7")).toBeInTheDocument();
    expect(screen.getAllByText("0")).toHaveLength(3);
  });

  test("defaults null and zero-valued counts to zero", () => {
    renderCards({
      total: null,
      major: 0,
      minor: undefined,
      warning: 4,
    });

    expect(screen.getAllByText("0")).toHaveLength(3);
    expect(screen.getByText("4")).toBeInTheDocument();
  });

  test("preserves non-zero numeric and string count values", () => {
    renderCards({
      total: 123,
      major: "09",
      minor: 2.5,
      warning: "7",
    });

    expect(screen.getByText("123")).toBeInTheDocument();
    expect(screen.getByText("09")).toBeInTheDocument();
    expect(screen.getByText("2.5")).toBeInTheDocument();
    expect(screen.getByText("7")).toBeInTheDocument();
  });

  test("uses the configured theme colors for card text", () => {
    renderCards({ total: 1, major: 2, minor: 3, warning: 4 });

    const title = screen.getByText("Total Alarms:");
    const value = screen.getByText("1");

    expect(title).toHaveStyle({ color: "#666666" });
    expect(value).toHaveStyle({ color: "#222222" });
  });

  test("applies the category background colors to the corresponding icons", () => {
    renderCards({ total: 1, major: 2, minor: 3, warning: 4 });

    expect(screen.getByRole("img", { name: "Total Alarms" })).toHaveStyle({
      backgroundColor: "#DBFFEE",
    });
    expect(screen.getByRole("img", { name: "Major" })).toHaveStyle({
      backgroundColor: "#FFEBEC",
    });
    expect(screen.getByRole("img", { name: "Minor" })).toHaveStyle({
      backgroundColor: "#FFFFC9",
    });
    expect(screen.getByRole("img", { name: "Warning" })).toHaveStyle({
      backgroundColor: "#D0FFFF",
    });
  });

  test("renders the supplied counts in their matching category cards", () => {
    renderCards({ total: 41, major: 11, minor: 17, warning: 13 });

    const totalTitle = screen.getByText("Total Alarms:");
    const totalCard = totalTitle.parentElement.parentElement.parentElement;
    expect(within(totalCard).getByText("41")).toBeInTheDocument();

    const majorTitle = screen.getByText("Major:");
    const majorCard = majorTitle.parentElement.parentElement.parentElement;
    expect(within(majorCard).getByText("11")).toBeInTheDocument();

    const minorTitle = screen.getByText("Minor:");
    const minorCard = minorTitle.parentElement.parentElement.parentElement;
    expect(within(minorCard).getByText("17")).toBeInTheDocument();

    const warningTitle = screen.getByText("Warning:");
    const warningCard = warningTitle.parentElement.parentElement.parentElement;
    expect(within(warningCard).getByText("13")).toBeInTheDocument();
  });
});
