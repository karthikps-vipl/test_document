import React from "react";
import { jest } from "@jest/globals";
import { fireEvent, render, screen } from "@testing-library/react";
import dayjs from "dayjs";

jest.unstable_mockModule(
  "@mui/x-date-pickers/DateTimePicker",
  () => {
    const ReactModule = React;

    const MockDateTimePicker = (props) => {
      const {
        open,
        value,
        onChange,
        onAccept,
        onClose,
        disableFuture,
        disablePast,
        ampm,
        views,
        format,
        slotProps,
      } = props;

      const valueText =
        value && value.isValid()
          ? value.format("YYYY-MM-DDTHH:mm:ss")
          : "Invalid date";

      return ReactModule.createElement(
        "div",
        {
          "data-testid": "mui-datetime-picker",
          "data-open": String(open),
          "data-value": valueText,
          "data-disable-future": String(disableFuture),
          "data-disable-past": String(disablePast),
          "data-ampm": String(ampm),
          "data-views": JSON.stringify(views),
          "data-format": format,
          "data-text-field-size": slotProps?.textField?.size,
          "data-text-field-full-width": String(
            slotProps?.textField?.fullWidth
          ),
          "data-action-bar": JSON.stringify(slotProps?.actionBar?.actions),
        },
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: () => onChange(dayjs("2025-02-03T04:05:06")),
          },
          "Change to valid date"
        ),
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: () => onChange(dayjs("not-a-valid-date")),
          },
          "Change to invalid date"
        ),
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: () => onChange(null),
          },
          "Clear date"
        ),
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: () => onAccept(dayjs("2025-03-04T05:06:07")),
          },
          "Accept explicit date"
        ),
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: () => onAccept(null),
          },
          "Accept current selection"
        ),
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: () => onAccept(dayjs("invalid")),
          },
          "Accept invalid date"
        ),
        ReactModule.createElement(
          "button",
          {
            type: "button",
            onClick: onClose,
          },
          "Close picker"
        )
      );
    };

    return { DateTimePicker: MockDateTimePicker };
  }
);

jest.unstable_mockModule(
  "@mui/x-date-pickers/LocalizationProvider",
  () => {
    const ReactModule = React;
    return {
      LocalizationProvider: ({ children }) =>
        ReactModule.createElement(
          ReactModule.Fragment,
          null,
          children
        ),
    };
  }
);

jest.unstable_mockModule("@mui/x-date-pickers/AdapterDayjs", () => ({
  AdapterDayjs: class AdapterDayjs {},
}));

jest.unstable_mockModule(
  "@mui/x-date-pickers/timeViewRenderers",
  () => ({
    renderTimeViewClock: jest.fn(),
  })
);

const { default: DateTimePicker } = await import(
  "../../src/components/Reusable/DateTime/DateTimePicker"
);

const renderPicker = (props = {}) =>
  render(<DateTimePicker open={true} {...props} />);

describe("DateTimePicker", () => {
  test("renders the MUI date-time picker with its default configuration", () => {
    renderPicker();

    const picker = screen.getByTestId("mui-datetime-picker");
    expect(picker).toHaveAttribute("data-open", "true");
    expect(picker).toHaveAttribute("data-disable-future", "true");
    expect(picker).toHaveAttribute("data-disable-past", "false");
    expect(picker).toHaveAttribute("data-ampm", "true");
    expect(picker).toHaveAttribute(
      "data-views",
      JSON.stringify(["year", "month", "day", "hours", "minutes"])
    );
    expect(picker).toHaveAttribute("data-format", "DD/MM/YYYY HH:mm");
  });

  test("initializes the selected value from a valid value prop", () => {
    renderPicker({ value: "2024-06-15T10:20:30" });

    expect(screen.getByTestId("mui-datetime-picker")).toHaveAttribute(
      "data-value",
      "2024-06-15T10:20:30"
    );
  });

  test("uses the current date when the initial value is missing or invalid", () => {
    const { rerender } = renderPicker();

    expect(screen.getByTestId("mui-datetime-picker")).not.toHaveAttribute(
      "data-value",
      "Invalid date"
    );

    rerender(<DateTimePicker open value="not-a-date" />);

    expect(screen.getByTestId("mui-datetime-picker")).not.toHaveAttribute(
      "data-value",
      "Invalid date"
    );
  });

  test("synchronizes the selected value when the picker opens and the parent value changes", () => {
    const { rerender } = renderPicker({
      open: false,
      value: "2024-01-01T01:02:03",
    });

    expect(screen.getByTestId("mui-datetime-picker")).toHaveAttribute(
      "data-value",
      "2024-01-01T01:02:03"
    );

    rerender(
      <DateTimePicker open value="2024-08-09T11:12:13" />
    );

    expect(screen.getByTestId("mui-datetime-picker")).toHaveAttribute(
      "data-value",
      "2024-08-09T11:12:13"
    );
  });

  test("calls onChange with a JavaScript Date for a valid selection", () => {
    const onChange = jest.fn();
    renderPicker({ onChange });

    fireEvent.click(screen.getByRole("button", { name: "Change to valid date" }));

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange.mock.calls[0][0]).toBeInstanceOf(Date);
    expect(onChange.mock.calls[0][0]).toEqual(
      dayjs("2025-02-03T04:05:06").toDate()
    );
    expect(screen.getByTestId("mui-datetime-picker")).toHaveAttribute(
      "data-value",
      "2025-02-03T04:05:06"
    );
  });

  test("calls onChange with null for an invalid date", () => {
    const onChange = jest.fn();
    renderPicker({ onChange });

    fireEvent.click(
      screen.getByRole("button", { name: "Change to invalid date" })
    );

    expect(onChange).toHaveBeenCalledWith(null);
  });

  test("calls onChange with null when the selected value is cleared", () => {
    const onChange = jest.fn();
    renderPicker({ onChange });

    fireEvent.click(screen.getByRole("button", { name: "Clear date" }));

    expect(onChange).toHaveBeenCalledWith(null);
    expect(screen.getByTestId("mui-datetime-picker")).toHaveAttribute(
      "data-value",
      "Invalid date"
    );
  });

  test("submits an explicitly accepted valid date and closes the picker", () => {
    const onSubmit = jest.fn();
    const onClose = jest.fn();
    renderPicker({ onSubmit, onClose });

    fireEvent.click(
      screen.getByRole("button", { name: "Accept explicit date" })
    );

    expect(onSubmit).toHaveBeenCalledTimes(1);
    expect(onSubmit.mock.calls[0][0]).toBeInstanceOf(Date);
    expect(onSubmit.mock.calls[0][0]).toEqual(
      dayjs("2025-03-04T05:06:07").toDate()
    );
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("submits the current selected date when accept receives null", () => {
    const onSubmit = jest.fn();
    const onClose = jest.fn();
    renderPicker({
      value: "2024-07-08T09:10:11",
      onSubmit,
      onClose,
    });

    fireEvent.click(
      screen.getByRole("button", { name: "Accept current selection" })
    );

    expect(onSubmit).toHaveBeenCalledTimes(1);
    expect(onSubmit.mock.calls[0][0]).toEqual(
      dayjs("2024-07-08T09:10:11").toDate()
    );
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("does not submit an invalid accepted date but still closes the picker", () => {
    const onSubmit = jest.fn();
    const onClose = jest.fn();
    renderPicker({ onSubmit, onClose });

    fireEvent.click(
      screen.getByRole("button", { name: "Accept invalid date" })
    );

    expect(onSubmit).not.toHaveBeenCalled();
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("calls onClose when the picker closes", () => {
    const onClose = jest.fn();
    renderPicker({ onClose });

    fireEvent.click(screen.getByRole("button", { name: "Close picker" }));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("supports disabling past dates and configuring 24-hour time", () => {
    renderPicker({
      disableFuture: false,
      disablePast: true,
      ampm: false,
    });

    const picker = screen.getByTestId("mui-datetime-picker");
    expect(picker).toHaveAttribute("data-disable-future", "false");
    expect(picker).toHaveAttribute("data-disable-past", "true");
    expect(picker).toHaveAttribute("data-ampm", "false");
  });

  test("includes seconds in the views and date-time format when seconds is enabled", () => {
    renderPicker({ seconds: true });

    const picker = screen.getByTestId("mui-datetime-picker");
    expect(picker).toHaveAttribute(
      "data-views",
      JSON.stringify([
        "year",
        "month",
        "day",
        "hours",
        "minutes",
        "seconds",
      ])
    );
    expect(picker).toHaveAttribute("data-format", "DD/MM/YYYY HH:mm:ss");
  });

  test("configures the action bar and text field slots", () => {
    renderPicker();

    const picker = screen.getByTestId("mui-datetime-picker");
    expect(picker).toHaveAttribute(
      "data-action-bar",
      JSON.stringify(["cancel", "accept"])
    );
    expect(picker).toHaveAttribute("data-text-field-size", "small");
    expect(picker).toHaveAttribute("data-text-field-full-width", "true");
  });

  test("allows optional callbacks to be omitted", () => {
    renderPicker();

    expect(() =>
      fireEvent.click(
        screen.getByRole("button", { name: "Change to valid date" })
      )
    ).not.toThrow();

    expect(() =>
      fireEvent.click(
        screen.getByRole("button", { name: "Accept explicit date" })
      )
    ).not.toThrow();
  });
});
