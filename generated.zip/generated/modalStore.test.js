import { useModalStore } from '../../src/core/modal/modalStore';

describe('global modal Zustand store', () => {
  beforeEach(() => useModalStore.getState().resetModal());
  test('opens a modal and pushes it onto the stack', () => {
    const props = { resourceId: 'R1' };
    useModalStore.getState().openModal('inventory', props);
    expect(useModalStore.getState()).toMatchObject({ isOpen: true, modalType: 'inventory', modalProps: props, modalStack: [{ modalType: 'inventory', modalProps: props }] });
  });
  test('supports nested modal stack and restores previous modal on close', () => {
    useModalStore.getState().openModal('inventory', { id: 1 });
    useModalStore.getState().openModal('status', { id: 2 });
    useModalStore.getState().closeModal();
    expect(useModalStore.getState()).toMatchObject({ isOpen: true, modalType: 'inventory', modalProps: { id: 1 } });
    expect(useModalStore.getState().modalStack).toHaveLength(1);
  });
  test('closing the last modal resets current modal fields', () => {
    useModalStore.getState().openModal('inventory');
    useModalStore.getState().closeModal();
    expect(useModalStore.getState()).toMatchObject({ isOpen: false, modalType: null, modalProps: {}, modalStack: [] });
  });
  test('reset clears all nested modal state', () => {
    useModalStore.getState().openModal('one');
    useModalStore.getState().openModal('two');
    useModalStore.getState().resetModal();
    expect(useModalStore.getState()).toMatchObject({ isOpen: false, modalType: null, modalProps: {}, modalStack: [] });
  });
});
