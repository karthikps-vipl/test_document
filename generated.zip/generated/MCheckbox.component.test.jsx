import React from "react";
import { jest } from "@jest/globals";
import { fireEvent, render, screen } from "@testing-library/react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import MCheckbox from "../../src/components/Reusable/Checkbox/MCheckbox";

const theme = createTheme();

const renderCheckbox = (props = {}) =>
  render(
    <ThemeProvider theme={theme}>
      <MCheckbox label="Enable notifications" {...props} />
    </ThemeProvider>
  );

describe("MCheckbox", () => {
  test("renders the checkbox with its label", () => {
    renderCheckbox();

    expect(
      screen.getByRole("checkbox", { name: "Enable notifications" })
    ).toBeInTheDocument();
  });

  test("reflects the checked prop", () => {
    const { rerender } = renderCheckbox({ checked: false });

    const checkbox = screen.getByRole("checkbox", {
      name: "Enable notifications",
    });
    expect(checkbox).not.toBeChecked();

    rerender(
      <ThemeProvider theme={theme}>
        <MCheckbox checked label="Enable notifications" />
      </ThemeProvider>
    );

    expect(checkbox).toBeChecked();
  });

  test("calls onChange when the checkbox is clicked", () => {
    const onChange = jest.fn();
    renderCheckbox({ checked: false, onChange });

    fireEvent.click(
      screen.getByRole("checkbox", { name: "Enable notifications" })
    );

    expect(onChange).toHaveBeenCalledTimes(1);
    // MUI Checkbox calls onChange(event, checked); use the second argument
    // because this is a controlled checkbox and React restores checked={false}.
    expect(onChange.mock.calls[0][1]).toBe(true);
  });

  test("renders a disabled checkbox when disabled is true", () => {
    renderCheckbox({ disabled: true });

    expect(
      screen.getByRole("checkbox", { name: "Enable notifications" })
    ).toBeDisabled();
  });

  test("forwards the selected color and size to the MUI checkbox", () => {
    renderCheckbox({ color: "secondary", size: "small" });

    const checkbox = screen.getByRole("checkbox", {
      name: "Enable notifications",
    });
    const checkboxRoot = checkbox.closest(".MuiCheckbox-root");

    expect(checkboxRoot).toHaveClass("MuiCheckbox-colorSecondary");
    expect(checkboxRoot).toHaveClass("MuiCheckbox-sizeSmall");
  });

  test("uses the default primary color and medium size", () => {
    renderCheckbox();

    const checkbox = screen.getByRole("checkbox", {
      name: "Enable notifications",
    });
    const checkboxRoot = checkbox.closest(".MuiCheckbox-root");

    expect(checkboxRoot).toHaveClass("MuiCheckbox-colorPrimary");
    expect(checkboxRoot).toHaveClass("MuiCheckbox-sizeMedium");
  });

  test("forwards additional standard checkbox props", () => {
    renderCheckbox({
      checked: true,
      name: "notificationPreference",
      value: "enabled",
      inputProps: { "aria-label": "Notification preference checkbox" },
    });

    const checkbox = screen.getByRole("checkbox", {
      name: "Notification preference checkbox",
    });
    expect(checkbox).toBeChecked();
    expect(checkbox).toHaveAttribute("name", "notificationPreference");
    expect(checkbox).toHaveAttribute("value", "enabled");
  });

  test("allows the parent to override the label styling through sx", () => {
    renderCheckbox({
      sx: {
        "& .MuiFormControlLabel-label": {
          fontSize: "1.25rem",
          fontWeight: 700,
        },
      },
    });

    const label = screen.getByText("Enable notifications");
    expect(label).toHaveStyle({
      fontSize: "1.25rem",
      fontWeight: "700",
    });
  });

  test("keeps the label text and checkbox associated when a custom label is supplied", () => {
    renderCheckbox({ label: "Enable alarm notifications" });

    expect(
      screen.getByRole("checkbox", {
        name: "Enable alarm notifications",
      })
    ).toBeInTheDocument();
  });
});
