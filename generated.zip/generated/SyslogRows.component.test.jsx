import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import { MemoryRouter, Routes, Route } from "react-router-dom";
import syslogReducer from "../../src/store/features/SyslogAI/syslogSlice";

jest.unstable_mockModule("../../src/RestAPI/api/axiosApicall", () => ({
  SyslogAiAxios: jest.fn(),
}));

const { SyslogAiAxios } = await import("../../src/RestAPI/api/axiosApicall");
const { default: SyslogRows } = await import(
  "../../src/Pages/Rnmsdashboard/Syslog AI/SyslogRows"
);

const DATE = "2026-11-20";
const BATCH = {
  id: "batch-1",
  batch: "Night Batch",
  records: 8,
  crit: 2,
  mod: 2,
  low: 3,
};

const makeLog = (id, risk, extra = {}) => ({
  id,
  risk,
  timestamp: `2026-11-20 10:0${id}:00`,
  hostname: `host-${id}`,
  facility_label: "daemon",
  severity_val: 3,
  message: `Message ${id}`,
  ai_insight: `Insight ${id}`,
  ...extra,
});

const renderRows = ({
  routeState = {},
  reduxDate = DATE,
  initialEntries,
} = {}) => {
  const store = configureStore({
    reducer: { syslog: syslogReducer },
    preloadedState: { syslog: { selectedDate: reduxDate } },
  });

  const entries = initialEntries || [
    { pathname: "/previous" },
    { pathname: "/syslog/rows", state: routeState },
  ];

  return render(
    <Provider store={store}>
      <MemoryRouter initialEntries={entries} initialIndex={entries.length - 1}>
        <Routes>
          <Route path="/previous" element={<div>Previous page</div>} />
          <Route path="/syslog/rows" element={<SyslogRows />} />
        </Routes>
      </MemoryRouter>
    </Provider>
  );
};

beforeEach(() => {
  SyslogAiAxios.mockReset();
  SyslogAiAxios.mockResolvedValue({ data: { logs: [] } });
});

afterEach(() => {
  jest.restoreAllMocks();
});

describe("SyslogRows component", () => {
  describe("initial rendering and loading", () => {
    test("renders the batch heading, selected model and date", async () => {
      renderRows({
        routeState: {
          batchData: BATCH,
          model: "production_model_v2",
          selectedDate: DATE,
        },
      });

      expect(screen.getByText("SYSLOG ANOMALY DETECTOR")).toBeInTheDocument();
      expect(screen.getByText("Night Batch")).toBeInTheDocument();
      expect(screen.getByText("production model v2")).toBeInTheDocument();
      expect(screen.getByText(/DATE:/)).toBeInTheDocument();
      await screen.findByText(/GENERAL LOG STREAM/);
    });

    test("does not call the API when there is no selected date", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: "" }, reduxDate: null });

      expect(await screen.findByText(/GENERAL LOG STREAM/)).toBeInTheDocument();
      expect(SyslogAiAxios).not.toHaveBeenCalled();
      expect(screen.queryByRole("progressbar")).not.toBeInTheDocument();
    });

    test("fetches completed batch logs and normalises spaces in the batch query", async () => {
      SyslogAiAxios.mockResolvedValue({
        data: { logs: [makeLog(1, 8)] },
      });

      renderRows({
        routeState: {
          batchData: { ...BATCH, batch: "Night Batch 1" },
          selectedDate: DATE,
        },
      });

      expect(await screen.findByText("Message 1")).toBeInTheDocument();
      expect(SyslogAiAxios).toHaveBeenCalledTimes(1);
      const [url, method] = SyslogAiAxios.mock.calls[0];
      expect(method).toBe("get");
      expect(url).toContain("selected_date=2026-11-20");
      expect(url).toContain("batch_name=Night_Batch_1");
    });

    test("uses Redux selectedDate when route state does not contain a date", async () => {
      SyslogAiAxios.mockResolvedValue({ data: { logs: [makeLog(2, 4)] } });

      renderRows({ routeState: { batchData: BATCH }, reduxDate: DATE });

      expect(await screen.findByText("Message 2")).toBeInTheDocument();
      expect(SyslogAiAxios.mock.calls[0][0]).toContain("selected_date=2026-11-20");
    });

    test("uses live rows from dashboard without calling the API", async () => {
      const liveRows = [makeLog("live-1", 9, { message: "Live audit record" })];

      renderRows({
        routeState: {
          batchData: BATCH,
          selectedDate: DATE,
          live: true,
          liveRows,
        },
      });

      expect(await screen.findByText("Live audit record")).toBeInTheDocument();
      expect(screen.getAllByText("LIVE").length).toBeGreaterThan(0);
      expect(SyslogAiAxios).not.toHaveBeenCalled();
    });

    test("falls back to the API when a live batch has no live rows", async () => {
      SyslogAiAxios.mockResolvedValue({ data: { logs: [makeLog(3, 6)] } });

      renderRows({
        routeState: {
          batchData: BATCH,
          selectedDate: DATE,
          live: true,
          liveRows: [],
        },
      });

      expect(await screen.findByText("Message 3")).toBeInTheDocument();
      expect(SyslogAiAxios).toHaveBeenCalledTimes(1);
    });

    test("shows a fetch error in the snackbar and clears the rows", async () => {
      const consoleError = jest.spyOn(console, "error").mockImplementation(() => {});
      SyslogAiAxios.mockRejectedValue(new Error("service unavailable"));

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });

      expect(await screen.findByRole("alert")).toHaveTextContent(
        "Unable to load logs: service unavailable"
      );
      expect(consoleError).toHaveBeenCalled();
      expect(screen.getByText(/GENERAL LOG STREAM/)).toBeInTheDocument();
    });

    test("handles a successful response with a missing logs array", async () => {
      SyslogAiAxios.mockResolvedValue({ data: { logs: null } });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });

      expect(await screen.findByText(/GENERAL LOG STREAM/)).toBeInTheDocument();
      expect(screen.queryByRole("progressbar")).not.toBeInTheDocument();
    });
  });

  describe("log rendering and risk filters", () => {
    const logs = [
      makeLog(1, 9),
      makeLog(2, 8),
      makeLog(3, 7),
      makeLog(4, 5),
      makeLog(5, 4),
      makeLog(6, 2),
      makeLog(7, 1),
      makeLog(8, 0),
    ];

    beforeEach(() => {
      SyslogAiAxios.mockResolvedValue({ data: { logs } });
    });

    test("sorts by risk and separates the top four priority alerts", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });

      expect(await screen.findByText("PRIORITY ALERTS (TOP 4 HIGHEST RISK)")).toBeInTheDocument();
      expect(screen.getByText("RISK: 9/10")).toBeInTheDocument();
      expect(screen.getByText("RISK: 8/10")).toBeInTheDocument();
      expect(screen.getByText("RISK: 7/10")).toBeInTheDocument();
      expect(screen.getByText("RISK: 5/10")).toBeInTheDocument();
      expect(screen.getByText("GENERAL LOG STREAM (4 ITEMS)")).toBeInTheDocument();
    });

    test("filters critical logs at risk 8 and above", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText("Message 1");

      fireEvent.click(screen.getByRole("button", { name: /CRITICAL/ }));

      expect(screen.getByText("CRIT LOG STREAM (2 ITEMS)")).toBeInTheDocument();
      expect(screen.getByText("Message 1")).toBeInTheDocument();
      expect(screen.getByText("Message 2")).toBeInTheDocument();
      expect(screen.queryByText("Message 3")).not.toBeInTheDocument();
    });

    test("filters moderate logs from risk 5 through 7", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText("Message 1");

      fireEvent.click(screen.getByRole("button", { name: /MODERATE/ }));

      expect(screen.getByText("MOD LOG STREAM (2 ITEMS)")).toBeInTheDocument();
      expect(screen.getByText("Message 3")).toBeInTheDocument();
      expect(screen.getByText("Message 4")).toBeInTheDocument();
      expect(screen.queryByText("Message 5")).not.toBeInTheDocument();
    });

    test("filters low logs from risk 1 through 4", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText("Message 1");

      fireEvent.click(screen.getByRole("button", { name: /LOW/ }));

      expect(screen.getByText("LOW LOG STREAM (3 ITEMS)")).toBeInTheDocument();
      expect(screen.getByText("Message 5")).toBeInTheDocument();
      expect(screen.getByText("Message 6")).toBeInTheDocument();
      expect(screen.getByText("Message 7")).toBeInTheDocument();
      expect(screen.queryByText("Message 8")).not.toBeInTheDocument();
    });

    test("returns to all logs when ALL is selected", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText("Message 1");
      fireEvent.click(screen.getByRole("button", { name: /LOW/ }));
      fireEvent.click(screen.getByRole("button", { name: "ALL" }));

      expect(screen.getByText("PRIORITY ALERTS (TOP 4 HIGHEST RISK)")).toBeInTheDocument();
      expect(screen.getByText("GENERAL LOG STREAM (4 ITEMS)")).toBeInTheDocument();
    });

    test("normalises risk_score and derives AI risk levels when not supplied", async () => {
      SyslogAiAxios.mockResolvedValue({
        data: {
          logs: [
            makeLog("score", undefined, { risk_score: "9", ai_risk_level: "" }),
            makeLog("named", 3, { ai_risk_level: "CUSTOM LEVEL", severity_label: "CUSTOM SEVERITY" }),
          ],
        },
      });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });

      expect(await screen.findByText("RISK: 9/10")).toBeInTheDocument();
      expect(screen.getByText("EMERGENCY")).toBeInTheDocument();
      expect(screen.getByText("CUSTOM LEVEL")).toBeInTheDocument();
      expect(screen.getByText(/CUSTOM SEVERITY/)).toBeInTheDocument();
    });

    test("renders fallback values for optional log fields", async () => {
      SyslogAiAxios.mockResolvedValue({
        data: { logs: [{ id: "fallback", risk: 0, severity_val: 99 }] },
      });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });

      expect(await screen.findByText("UNKNOWN")).toBeInTheDocument();
      expect(screen.getAllByText("N/A").length).toBeGreaterThanOrEqual(2);
      expect(screen.getByText("Original Message", { exact: false })).toBeInTheDocument();
      expect(screen.getByText("No AI insight available.")).toBeInTheDocument();
      expect(screen.getByText("LOG (99)")).toBeInTheDocument();
    });
  });

  describe("navigation and export workflow", () => {
    const openExportDialog = async (type = "PDF") => {
      fireEvent.click(screen.getByRole("button", { name: "EXPORT" }));
      fireEvent.click(await screen.findByRole("menuitem", {
        name: type === "PDF" ? /Export to PDF/ : /Export to Excel/,
      }));
      expect(await screen.findByText(`Export ${type}`)).toBeInTheDocument();
    };

    test("navigates back to the previous route", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      fireEvent.click(screen.getAllByRole("button")[0]);
      expect(await screen.findByText("Previous page")).toBeInTheDocument();
    });

    test("opens and cancels the PDF export confirmation dialog", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE, model: "local_model" } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      expect(screen.getByText(/Engine:/)).toBeInTheDocument();
      expect(screen.getAllByText(/local model/).length).toBeGreaterThan(0);
      fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
      await waitFor(() => expect(screen.queryByText("Export PDF")).not.toBeInTheDocument());
      expect(SyslogAiAxios).not.toHaveBeenCalledWith(expect.any(String), "getBlob");
    });

    test("downloads a PDF and shows a success message", async () => {
      const blob = new Blob(["pdf-content"], { type: "application/pdf" });
      SyslogAiAxios.mockResolvedValueOnce({ data: { logs: [] } }).mockResolvedValueOnce({
        status: 200,
        data: blob,
      });
      const createObjectURL = jest.fn(() => "blob:test-pdf");
      const revokeObjectURL = jest.fn();
      Object.defineProperty(window.URL, "createObjectURL", { configurable: true, value: createObjectURL });
      Object.defineProperty(window.URL, "revokeObjectURL", { configurable: true, value: revokeObjectURL });
      const anchorClick = jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByRole("alert")).toHaveTextContent("PDF downloaded successfully!");
      const exportCall = SyslogAiAxios.mock.calls.find((call) => call[1] === "getBlob");
      expect(exportCall[0]).toContain("type=pdf");
      expect(exportCall[0]).toContain("severity=all");
      expect(exportCall[0]).toContain("selected_date=2026-11-20");
      expect(createObjectURL).toHaveBeenCalledWith(blob);
      expect(anchorClick).toHaveBeenCalled();
    });

    test("downloads an Excel file using the currently selected severity filter", async () => {
      const blob = new Blob(["xlsx-content"], { type: "application/octet-stream" });
      SyslogAiAxios.mockResolvedValueOnce({ data: { logs: [makeLog(1, 9)] } }).mockResolvedValueOnce({
        status: 200,
        data: blob,
      });
      Object.defineProperty(window.URL, "createObjectURL", { configurable: true, value: jest.fn(() => "blob:test-xlsx") });
      Object.defineProperty(window.URL, "revokeObjectURL", { configurable: true, value: jest.fn() });
      jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText("Message 1");
      fireEvent.click(screen.getByRole("button", { name: /CRITICAL/ }));
      await openExportDialog("Excel");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByRole("alert")).toHaveTextContent("Excel downloaded successfully!");
      const exportCall = SyslogAiAxios.mock.calls.find((call) => call[1] === "getBlob");
      expect(exportCall[0]).toContain("type=xlsx");
      expect(exportCall[0]).toContain("severity=crit");
    });

    test("shows a warning when exporting without a selected date", async () => {
      renderRows({ routeState: { batchData: BATCH, selectedDate: "" }, reduxDate: null });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText("Please select a date first.")).toBeInTheDocument();
      expect(SyslogAiAxios).not.toHaveBeenCalledWith(expect.any(String), "getBlob");
    });

    test("shows a warning when exporting without a batch", async () => {
      renderRows({ routeState: { batchData: { ...BATCH, batch: "" }, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("Excel");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText("No batch selected for download.")).toBeInTheDocument();
      expect(SyslogAiAxios).not.toHaveBeenCalledWith(expect.any(String), "getBlob");
    });

    test("shows the server error when the export endpoint returns a non-200 response", async () => {
      SyslogAiAxios.mockResolvedValueOnce({ data: { logs: [] } }).mockResolvedValueOnce({
        status: 500,
        json: jest.fn().mockResolvedValue({ detail: "export service failed" }),
      });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText("PDF failed: export service failed")).toBeInTheDocument();
    });

    test("rejects an empty export blob", async () => {
      SyslogAiAxios.mockResolvedValueOnce({ data: { logs: [] } }).mockResolvedValueOnce({
        status: 200,
        data: new Blob([]),
      });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText(
        "PDF failed: Server returned an empty download file."
      )).toBeInTheDocument();
    });
  });

  describe("remaining uncovered paths", () => {
    const openExportDialog = async (type = "PDF") => {
      fireEvent.click(screen.getByRole("button", { name: "EXPORT" }));
      fireEvent.click(await screen.findByRole("menuitem", {
        name: type === "PDF" ? /Export to PDF/ : /Export to Excel/,
      }));
      expect(await screen.findByText(`Export ${type}`)).toBeInTheDocument();
    };

    test("uses default Manual Entry batch details when route state has no batchData", async () => {
      renderRows({ routeState: { selectedDate: DATE } });

      expect(await screen.findByText("Manual Entry")).toBeInTheDocument();
      expect(SyslogAiAxios).toHaveBeenCalledTimes(1);
      expect(SyslogAiAxios.mock.calls[0][0]).toContain("batch_name=Manual_Entry");
    });

    test("keeps the HTTP status when a non-200 response body cannot be parsed", async () => {
      const consoleError = jest.spyOn(console, "error").mockImplementation(() => {});
      SyslogAiAxios
        .mockResolvedValueOnce({ data: { logs: [] } })
        .mockResolvedValueOnce({
          status: 502,
          json: jest.fn().mockRejectedValue(new Error("invalid response JSON")),
        });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText("PDF failed: HTTP 502")).toBeInTheDocument();
      expect(consoleError).toHaveBeenCalled();
    });

    test("reads the detail message from a Blob export error response", async () => {
      const consoleError = jest.spyOn(console, "error").mockImplementation(() => {});
      const errorBlob = new Blob(
        [JSON.stringify({ detail: "Export rejected by server" })],
        { type: "application/json" }
      );
      // jsdom's Blob implementation may not expose Blob.text(); provide the
      // browser API used by SyslogRows so this test exercises JSON parsing.
      Object.defineProperty(errorBlob, "text", {
        configurable: true,
        value: jest.fn().mockResolvedValue(
          JSON.stringify({ detail: "Export rejected by server" })
        ),
      });
      SyslogAiAxios
        .mockResolvedValueOnce({ data: { logs: [] } })
        .mockRejectedValueOnce({ response: { data: errorBlob } });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      // Wait until the initial GET request has finished so the next mocked
      // response is consumed by the export request, not the initial fetch.
      await waitFor(() => {
        expect(screen.queryByRole("progressbar")).not.toBeInTheDocument();
      });
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText(
        "PDF failed: Export rejected by server"
      )).toBeInTheDocument();
      expect(errorBlob.text).toHaveBeenCalledTimes(1);
      expect(consoleError).toHaveBeenCalled();
    });

    test("uses the default export error when a Blob error response contains invalid JSON", async () => {
      const consoleError = jest.spyOn(console, "error").mockImplementation(() => {});
      const errorBlob = new Blob(["not-json"], { type: "application/json" });
      SyslogAiAxios
        .mockResolvedValueOnce({ data: { logs: [] } })
        .mockRejectedValueOnce({ response: { data: errorBlob } });

      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });
      await screen.findByText(/GENERAL LOG STREAM/);
      await openExportDialog("PDF");
      fireEvent.click(screen.getByRole("button", { name: "Download" }));

      expect(await screen.findByText(
        "PDF failed: Download failed"
      )).toBeInTheDocument();
      expect(consoleError).toHaveBeenCalled();
    });

    test("ignores Snackbar clickaway and closes it on an explicit close action", async () => {
      SyslogAiAxios.mockRejectedValue(new Error("service unavailable"));
      renderRows({ routeState: { batchData: BATCH, selectedDate: DATE } });

      const alert = await screen.findByRole("alert");
      expect(alert).toHaveTextContent("Unable to load logs: service unavailable");

      fireEvent.click(document.body);
      expect(screen.getByRole("alert")).toBeInTheDocument();

      fireEvent.click(screen.getByRole("button", { name: /close/i }));
      await waitFor(() => expect(screen.queryByRole("alert")).not.toBeInTheDocument());
    });
  });

});
