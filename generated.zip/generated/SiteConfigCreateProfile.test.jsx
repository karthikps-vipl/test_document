import React from "react";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";
import SiteConfigCreateProfile from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/SiteConfiguator/Snmp/SiteConfigCreateProfile";
import { TopologyAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import { validateInput } from "@/utility/FormValidation/Regex";

// ---- Mocks ----
jest.mock("@/RestAPI/api/axiosApicall", () => ({
  TopologyAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  SAVE_SNMP_PROFILE_DETAILS: "/api/snmp/save",
}));

jest.mock("@/components/Reusable/Toast/Toast", () => jest.fn());

jest.mock("@/assets/SVGIcons/question_mark.svg", () => "confirm-icon.svg");

jest.mock("@/utility/FormValidation/Regex", () => ({
  profileRegex: {
    numeric: /^[0-9]*$/,
  },
  validateInput: jest.fn((val, regex) => (regex.test(val) ? val : undefined)),
}));

// Schema that validates required fields based on version & securityLevel
jest.mock("@/utility/FormValidation/YupSchema", () => {
  const Yup = jest.requireActual("yup");
  return {
    snmpValidationSchema: Yup.object().shape({
      snmpProfileName: Yup.string().required("Profile Name required"),
      port: Yup.string().required("Port required"),
      retries: Yup.string().required("Retries required"),
      timeout: Yup.string().required("Timeout required"),
      version: Yup.mixed().test(
        "has-version",
        "Version required",
        (val) => val !== "" && val !== undefined && val !== null
      ),
      readCommunity: Yup.string().when("version", {
        is: (v) => v === 0 || v === 1,
        then: (s) => s.required("Read Community required"),
        otherwise: (s) => s.notRequired(),
      }),
      writeCommunity: Yup.string().when("version", {
        is: (v) => v === 0 || v === 1,
        then: (s) => s.required("Write Community required"),
        otherwise: (s) => s.notRequired(),
      }),
      username: Yup.string().when("version", {
        is: 3,
        then: (s) => s.required("Username required"),
        otherwise: (s) => s.notRequired(),
      }),
      contextName: Yup.string().notRequired(),
      securityLevel: Yup.string().when("version", {
        is: 3,
        then: (s) => s.required("Security Level required"),
        otherwise: (s) => s.notRequired(),
      }),
      authProtocol: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec !== "" && sec !== "1",
        then: (s) => s.required("Auth Protocol required"),
        otherwise: (s) => s.notRequired(),
      }),
      authPassword: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec !== "" && sec !== "1",
        then: (s) => s.required("Auth Password required"),
        otherwise: (s) => s.notRequired(),
      }),
      privProtocol: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec === "3",
        then: (s) => s.required("Priv Protocol required"),
        otherwise: (s) => s.notRequired(),
      }),
      privPassword: Yup.string().when(["version", "securityLevel"], {
        is: (v, sec) => v === 3 && sec === "3",
        then: (s) => s.required("Priv Password required"),
        otherwise: (s) => s.notRequired(),
      }),
    }),
  };
});

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => {
  return function MockMButtonPrimary({ children, onClick, disabled }) {
    return (
      <button type="button" onClick={onClick} disabled={disabled}>
        {children}
      </button>
    );
  };
});

jest.mock("@/components/Reusable/Input/MInput", () => {
  return function MockMInput({
    value,
    onChange,
    onBlur,
    errorMessage,
    type = "text",
    InputProps,
  }) {
    return (
      <div>
        <input
          type={type}
          value={value ?? ""}
          onChange={onChange}
          onBlur={onBlur}
        />
        {InputProps?.endAdornment}
        {errorMessage ? <span>{errorMessage}</span> : null}
      </div>
    );
  };
});

jest.mock("@/components/Reusable/Select/MSelect", () => {
  return function MockMSelect({
    placeholder,
    options = [],
    value,
    onChange,
    getOptionValue,
    getOptionLabel,
  }) {
    return (
      <select
        aria-label={placeholder}
        value={value === "" || value === undefined ? "" : String(value)}
        onChange={(e) => {
          const raw = e.target.value;
          const found = options.find((opt) => String(getOptionValue(opt)) === raw);
          // Test both object and primitive option return paths
          onChange(found ? found : raw);
        }}
      >
        <option value="">{placeholder}</option>
        {options.map((opt) => {
          const val = String(getOptionValue(opt));
          return (
            <option key={val} value={val}>
              {getOptionLabel(opt)}
            </option>
          );
        })}
      </select>
    );
  };
});

jest.mock("@/components/Reusable/Dialog/MDialog", () => {
  return function MockMDialog({ open, title, message, onConfirm, onClose }) {
    if (!open) return null;
    return (
      <div role="dialog" aria-label={title}>
        <p>{message}</p>
        <button type="button" onClick={onConfirm}>
          Confirm Create
        </button>
        <button type="button" onClick={onClose}>
          Cancel Create
        </button>
      </div>
    );
  };
});

// ---- Helpers ----
const getFieldInput = (labelSubstring) => {
  const label = screen.getByText((text) => text.includes(labelSubstring));
  return label.parentElement.querySelector("input");
};

const getFieldSelect = (labelSubstring) => {
  const label = screen.getByText((text) => text.includes(labelSubstring));
  return label.parentElement.querySelector('[role="combobox"]');
};

describe("SiteConfigCreateProfile", () => {
  const onSuccess = jest.fn();
  const onClose = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    validateInput.mockImplementation((val, regex) =>
      regex.test(val) ? val : undefined
    );
  });

  test("renders initial defaults and keeps Save disabled until form is valid & dirty", () => {
    render(
      <SiteConfigCreateProfile
        onSuccess={onSuccess}
        onClose={onClose}
        isGrandchildFullScreen={false}
      />
    );

    expect(getFieldInput("Profile Name")).toHaveValue("");
    expect(getFieldInput("Port")).toHaveValue("161");
    expect(getFieldInput("No of Retries")).toHaveValue("1");
    expect(getFieldInput("Timeout (Sec)")).toHaveValue("1");
    expect(screen.getByRole("button", { name: "Save" })).toBeDisabled();
  });

  test("enforces numeric validation on Port, Retries, and Timeout and shows blur errors", async () => {
    jest.useFakeTimers();
    render(<SiteConfigCreateProfile onSuccess={onSuccess} onClose={onClose} />);

    const portInput = getFieldInput("Port");
    fireEvent.change(portInput, { target: { value: "162" } });
    act(() => jest.advanceTimersByTime(10));
    expect(portInput).toHaveValue("162");

    // Reject invalid input when validateInput returns undefined
    validateInput.mockReturnValueOnce(undefined);
    fireEvent.change(portInput, { target: { value: "bad" } });
    expect(portInput).toHaveValue("162");

    const retriesInput = getFieldInput("No of Retries");
    fireEvent.change(retriesInput, { target: { value: "3" } });
    act(() => jest.advanceTimersByTime(10));
    expect(retriesInput).toHaveValue("3");

    const timeoutInput = getFieldInput("Timeout (Sec)");
    fireEvent.change(timeoutInput, { target: { value: "5" } });
    act(() => jest.advanceTimersByTime(10));
    expect(timeoutInput).toHaveValue("5");

    const nameInput = getFieldInput("Profile Name");
    fireEvent.blur(nameInput);
    expect(await screen.findByText("Profile Name required")).toBeInTheDocument();

    jest.useRealTimers();
  });

  test("handles SNMP v1/v2c fields, password visibility toggles, confirmation dialog, and successful submit", async () => {
    jest.useFakeTimers();
    TopologyAxios.mockResolvedValueOnce({ status: 200 });

    render(<SiteConfigCreateProfile onSuccess={onSuccess} onClose={onClose} />);

    fireEvent.change(getFieldInput("Profile Name"), {
      target: { value: "Switch_V2C" },
    });
    fireEvent.change(screen.getByLabelText("Select version"), {
      target: { value: "1" },
    });

    act(() => jest.advanceTimersByTime(10));

    const readInput = getFieldInput("Read Community");
    const writeInput = getFieldInput("Write Community");
    expect(readInput).toHaveAttribute("type", "password");
    expect(writeInput).toHaveAttribute("type", "password");

    // Toggle visibility on Read & Write community
    const toggleButtons = screen.getAllByRole("button");
    const readToggle = readInput.parentElement.querySelector("button");
    const writeToggle = writeInput.parentElement.querySelector("button");
    fireEvent.click(readToggle);
    fireEvent.click(writeToggle);
    expect(readInput).toHaveAttribute("type", "text");
    expect(writeInput).toHaveAttribute("type", "text");

    fireEvent.change(readInput, { target: { value: "public_ro" } });
    fireEvent.change(writeInput, { target: { value: "private_rw" } });
    act(() => jest.advanceTimersByTime(10));

    const saveBtn = screen.getByRole("button", { name: "Save" });
    await waitFor(() => expect(saveBtn).toBeEnabled());

    // Open confirm dialog, close it once, then reopen and confirm
    fireEvent.click(saveBtn);
    expect(screen.getByRole("dialog", { name: "Confirm Action" })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Cancel Create" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();

    fireEvent.click(saveBtn);
    fireEvent.click(screen.getByRole("button", { name: "Confirm Create" }));

    await waitFor(() => {
      expect(TopologyAxios).toHaveBeenCalledWith("/api/snmp/save", "post", {
        snmpProfileName: "Switch_V2C",
        port: "161",
        retries: "1",
        timeout: "1",
        version: "1",
        readCommunity: "public_ro",
        writeCommunity: "private_rw",
      });
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Successfully saved SNMP Profile",
      "success"
    );
    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);

    // Avoid unused variable warning
    expect(toggleButtons.length).toBeGreaterThan(0);

    jest.useRealTimers();
  });

  test("handles SNMP v3 security levels 1, 2, and 3 and submits full v3 payload", async () => {
    jest.useFakeTimers();
    TopologyAxios.mockResolvedValueOnce({ status: 200 });

    render(
      <SiteConfigCreateProfile
        onSuccess={onSuccess}
        onClose={onClose}
        isGrandchildFullScreen={true}
      />
    );

    fireEvent.change(getFieldInput("Profile Name"), {
      target: { value: "Router_V3" },
    });
    fireEvent.change(screen.getByLabelText("Select version"), {
      target: { value: "3" },
    });
    act(() => jest.advanceTimersByTime(10));

    fireEvent.change(getFieldInput("USM User"), {
      target: { value: "v3user" },
    });
    fireEvent.change(getFieldInput("Context Name"), {
      target: { value: "ctx1" },
    });

    // Security Level 1: No Auth / No Privacy -> hides Auth & Priv
    fireEvent.change(screen.getByLabelText("Select security level"), {
      target: { value: "1" },
    });
    expect(screen.queryByText("Auth Protocol *")).not.toBeInTheDocument();
    expect(screen.queryByText("Priv Protocol *")).not.toBeInTheDocument();

    // Security Level 2: Auth / No Privacy -> shows Auth, hides Priv
    fireEvent.change(screen.getByLabelText("Select security level"), {
      target: { value: "2" },
    });
    expect(screen.getByText("Auth Protocol *")).toBeInTheDocument();
    expect(screen.queryByText("Priv Protocol *")).not.toBeInTheDocument();

    // Security Level 3: Auth / Privacy -> shows both Auth & Priv
    fireEvent.change(screen.getByLabelText("Select security level"), {
      target: { value: "3" },
    });
    expect(screen.getByText("Auth Protocol *")).toBeInTheDocument();
    expect(screen.getByText("Priv Protocol *")).toBeInTheDocument();

    // Select Auth Protocol (SHA256 -> "4")
    fireEvent.mouseDown(getFieldSelect("Auth Protocol"));
    fireEvent.click(screen.getByRole("option", { name: "SHA256" }));

    const authPass = getFieldInput("Auth Password");
    fireEvent.click(authPass.parentElement.querySelector("button"));
    expect(authPass).toHaveAttribute("type", "text");
    fireEvent.change(authPass, { target: { value: "authPass123" } });

    // Select Priv Protocol (AES256 -> "4")
    fireEvent.mouseDown(getFieldSelect("Priv Protocol"));
    fireEvent.click(screen.getByRole("option", { name: "AES256" }));

    const privPass = getFieldInput("Private Password");
    fireEvent.click(privPass.parentElement.querySelector("button"));
    expect(privPass).toHaveAttribute("type", "text");
    fireEvent.change(privPass, { target: { value: "privPass123" } });

    act(() => jest.advanceTimersByTime(10));

    const saveBtn = screen.getByRole("button", { name: "Save" });
    await waitFor(() => expect(saveBtn).toBeEnabled());

    fireEvent.click(saveBtn);
    fireEvent.click(screen.getByRole("button", { name: "Confirm Create" }));

    await waitFor(() => {
      expect(TopologyAxios).toHaveBeenCalledWith("/api/snmp/save", "post", {
        snmpProfileName: "Router_V3",
        port: "161",
        retries: "1",
        timeout: "1",
        version: "3",
        username: "v3user",
        contextName: "ctx1",
        securityLevel: "3",
        authProtocol: "4",
        authPassword: "authPass123",
        privProtocol: "4",
        privPassword: "privPass123",
      });
    });

    jest.useRealTimers();
  });

  test("handles API error without calling onSuccess or onClose", async () => {
    jest.useFakeTimers();
    TopologyAxios.mockRejectedValueOnce(new Error("Request failed"));

    render(<SiteConfigCreateProfile onSuccess={onSuccess} onClose={onClose} />);

    fireEvent.change(getFieldInput("Profile Name"), {
      target: { value: "Error_Profile" },
    });
    fireEvent.change(screen.getByLabelText("Select version"), {
      target: { value: "0" },
    });
    fireEvent.change(getFieldInput("Read Community"), {
      target: { value: "ro" },
    });
    fireEvent.change(getFieldInput("Write Community"), {
      target: { value: "rw" },
    });
    act(() => jest.advanceTimersByTime(10));

    const saveBtn = screen.getByRole("button", { name: "Save" });
    await waitFor(() => expect(saveBtn).toBeEnabled());

    fireEvent.click(saveBtn);
    fireEvent.click(screen.getByRole("button", { name: "Confirm Create" }));

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "An error occurred",
        "error"
      );
    });

    expect(onSuccess).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();

    jest.useRealTimers();
  });
});