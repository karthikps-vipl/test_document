import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import ConfigurationFileComparison from "../../src/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/FileComparison/ConfigurationFileComparison";

describe("ConfigurationFileComparison", () => {
  test("renders without crashing", () => {
    render(<ConfigurationFileComparison />);
  });

  test("runs useEffect on mount", () => {
    render(<ConfigurationFileComparison />);
    // TODO improve based on real effect
    expect(true).toBe(true);
  });
});
