import React from 'react';
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';

const mockDispatch = jest.fn();
const mockCanvasInstances = [];
const mockToast = jest.fn();
let mockImageFromURL;
let mockLoadFromJSONError = null;
let mockInitialCanvasObjects = [];
let mockObjectsAfterLoad = null;
const mockState = {
  nodeDetails: { isCnms: false, repDetails: null },
  inventory: { resources: [] },
  alarmSlice: { badgeCount: [] },
  topologySlice: {
    past: [],
    future: [],
    present: null,
    terminalTypes: [],
    linkStatusData: [],
  },
};

const makeFabricObject = (type, options = {}) => ({
  type,
  ...options,
  set: jest.fn(function set(values) { Object.assign(this, values); }),
  setCoords: jest.fn(),
  getObjects: jest.fn(() => options.objects || []),
});

jest.mock('react-redux', () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector(mockState),
}));

jest.mock('fabric', () => {
  class MockFabricObject {}
  class MockShape {
    constructor(...args) {
      this.args = args;
      this.options = args[args.length - 1] || {};
      Object.assign(this, this.options);
      this.set = jest.fn((values) => Object.assign(this, values));
      this.setCoords = jest.fn();
      this.getObjects = jest.fn(() => this.objects || []);
      if (Array.isArray(args[0])) this.points = args[0];
    }
  }
  class MockGroup extends MockShape {
    constructor(objects, options = {}) {
      super(objects, options);
      this.objects = objects;
      this.getObjects = jest.fn(() => this.objects);
    }
  }
  class MockCanvas {
    constructor(element) {
      this.element = element;
      this.handlers = {};
      this.objects = [...mockInitialCanvasObjects];
      this.activeObjects = [];
      this.activeObject = null;
      this.upperCanvasEl = { addEventListener: jest.fn() };
      this.setDimensions = jest.fn();
      this.getWidth = jest.fn(() => 800);
      this.getHeight = jest.fn(() => 600);
      this.on = jest.fn((name, handler) => { this.handlers[name] = handler; });
      this.getObjects = jest.fn(() => this.objects);
      this.calcOffset = jest.fn();
      this.requestRenderAll = jest.fn();
      this.dispose = jest.fn();
      this.toJSON = jest.fn(() => ({ objects: this.objects.map((obj) => ({ ...obj })) }));
      this.getActiveObject = jest.fn(() => this.activeObject);
      this.getActiveObjects = jest.fn(() => this.activeObjects);
      this.remove = jest.fn((obj) => { this.objects = this.objects.filter((item) => item !== obj); });
      this.discardActiveObject = jest.fn(() => { this.activeObject = null; this.activeObjects = []; });
      this.add = jest.fn((obj) => { this.objects.push(obj); });
      this.setActiveObject = jest.fn((obj) => { this.activeObject = obj; this.activeObjects = [obj]; });
      this.setViewportTransform = jest.fn();
      this.loadFromJSON = jest.fn(async () => {
        if (mockLoadFromJSONError) throw mockLoadFromJSONError;
        if (mockObjectsAfterLoad) this.objects = [...mockObjectsAfterLoad];
        return this;
      });
      mockCanvasInstances.push(this);
    }
  }
  return {
    Canvas: MockCanvas,
    Rect: MockShape,
    Circle: MockShape,
    Line: MockShape,
    Triangle: MockShape,
    Group: MockGroup,
    Image: { fromURL: (mockImageFromURL = jest.fn().mockResolvedValue({
      width: 100,
      height: 100,
      left: 0,
      top: 0,
      scaleX: 1,
      scaleY: 1,
      set: jest.fn(),
    })) },
    FabricObject: MockFabricObject,
    loadSVGFromURL: jest.fn().mockResolvedValue({ objects: [] }),
  };
});

jest.mock('@/lib/utils', () => ({
  getDeviceReachabilityColor: jest.fn(() => '#00aa00'),
  getDeviceReachabilityColorCnms: jest.fn(() => '#00aa00'),
  getDeviceStatusIndicator: jest.fn(() => '#00aa00'),
  getDeviceStatusIndicatorCnms: jest.fn(() => '#00aa00'),
}));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/utils', () => ({
  getEdgeColor: jest.fn(() => '#123456'),
}));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/topologyConstants', () => ({
  mapOpStatus: jest.fn(() => 'up'),
}));

jest.mock('../../src/store/features/Topology/topologyNodesslice', () => ({
  redoTopologyState: () => ({ type: 'topology/redo' }),
  saveTopologyState: (payload) => ({ type: 'topology/save', payload }),
  selectCanRedo: () => true,
  selectCanUndo: () => true,
  undoTopologyState: () => ({ type: 'topology/undo' }),
}));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/TopologyEditActions', () => (props) => (
  <div data-testid="topology-actions">
    <button onClick={props.onCanvasUndo}>Undo</button>
    <button onClick={props.onCanvasRedo}>Redo</button>
    <button onClick={props.onPortMappingToggle}>Toggle port mapping</button>
    <button onClick={props.onFabricDeleteAll}>Clear canvas</button>
    <button onClick={props.onFabricDeleteSelected}>Delete selected</button>
    <button onClick={() => props.onFabricAddLine('line')}>Add line</button>
    <button onClick={() => props.onFabricAddLine('arrow')}>Add arrow</button>
    <button onClick={props.onFabricSave}>Save topology</button>
    <button onClick={() => props.onFabricFieldChange('terminalId', 'terminal-1')}>Set terminal</button>
    <button onClick={() => props.onFabricFieldChange('segment', 'LAN')}>Set segment</button>
    <button onClick={() => props.onFabricFieldChange('linkStatusData', [
      { linkId: 11, linkName: 'LAN', linkStatus: 'UP' },
    ])}>Set link data</button>
    <button onClick={() => props.onFabricFieldChange('commitCanvasState')}>Commit state</button>
    <button onClick={() => props.onFabricFieldChange('radioWidth', '55')}>Set radius</button>
    <button onClick={() => props.onFabricFieldChange('deleteCanvas')}>Delete canvas</button>
    <button onClick={() => props.onFabricFieldChange('customField', 'custom-value')}>Set custom field</button>
    <button onClick={() => props.onFabricFieldChange('loadTopology', 'missing-terminal')}>Load missing topology</button>
    <button onClick={() => props.onFabricFieldChange('loadTopology', 'unknown-terminal')}>Load unknown terminal</button>
    <button onClick={() => props.onFabricFieldChange('createDeviceMarker', { deviceId: 'Router-01', selectedDeviceData: { resourceId: 'Router-01', resourceName: 'Router 01', status: 'UP' } })}>Create device marker</button>
    <button onClick={() => props.onFabricFieldChange('radioWidth', '65')}>Set associated radius</button>
    <button onClick={() => props.onFabricFieldChange('radioWidth', '')}>Clear radius</button>
    <input aria-label="Topology image" type="file" onChange={props.onFabricUpload} />
    <output data-testid="form-state">{JSON.stringify(props.fabricForm)}</output>
    <output data-testid="read-only-state">{String(props.svgReadOnly)}</output>
  </div>
));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/Tooltip/NodeTooltip', () => (props) => (
  <div data-testid="node-tooltip">{props.activeNode?.data?.resourceName || ''}</div>
));
jest.mock('@/components/Reusable/Toast/Toast', () => (...args) => mockToast(...args));
jest.mock('@/components/Contextmenu/ContextMenu', () => (props) => (
  <div data-testid="context-menu" data-view-only={String(!!props.viewOnly)}>
    {props.node?.data?.resourceName || ''}
    {props.anchor && <button onClick={props.onClose}>Close context menu</button>}
  </div>
));
jest.mock('../../src/Pages/Rnmsdashboard/TopologyFabric/PortMapping', () => () => (
  <div data-testid="port-mapping-panel">Port mapping panel</div>
));
jest.mock('@/components/Reusable/FullScreen/CustomeFullscreen', () => ({
  __esModule: true,
  CustomeFullscreen: (props) => <button onClick={props.onToggleFullScreen}>Fullscreen</button>,
}));
jest.mock('@mui/material', () => ({
  Backdrop: ({ open, children }) => open ? <div data-testid="loading-backdrop">{children}</div> : null,
  CircularProgress: () => <span>Loading</span>,
}));

window.isSuperAdmin = false;

import FabricTopology from '../../src/Pages/Rnmsdashboard/TopologyFabric/FabricTopology';

describe('FabricTopology component', () => {
  beforeEach(() => {
    mockDispatch.mockClear();
    mockImageFromURL.mockReset().mockResolvedValue({
      width: 100, height: 100, left: 0, top: 0, scaleX: 1, scaleY: 1, set: jest.fn(),
    });
    mockToast.mockClear();
    mockLoadFromJSONError = null;
    mockInitialCanvasObjects = [];
    mockObjectsAfterLoad = null;
    mockCanvasInstances.length = 0;
    mockState.nodeDetails = { isCnms: false, repDetails: null };
    mockState.inventory = { resources: [] };
    mockState.alarmSlice = { badgeCount: [] };
    mockState.topologySlice = {
      past: [], future: [], present: null, terminalTypes: [], linkStatusData: [],
    };
    global.ResizeObserver = class {
      constructor(callback) {
        this.callback = callback;
        global.__fabricResizeObserver = this;
      }
      observe = jest.fn();
      disconnect = jest.fn();
      unobserve = jest.fn();
    };
    window.isSuperAdmin = false;
  });

  afterEach(() => {
    delete global.ResizeObserver;
    delete global.__fabricResizeObserver;
    delete global.fetch;
    jest.restoreAllMocks();
  });

  const renderTopology = (props = {}) => render(<FabricTopology {...props} />);
  const canvas = () => mockCanvasInstances[mockCanvasInstances.length - 1];

  test('renders the canvas surface, toolbar and fullscreen action', () => {
    renderTopology();
    expect(document.querySelector('.topology-surface')).toBeInTheDocument();
    expect(document.querySelector('canvas')).toBeInTheDocument();
    expect(screen.getByTestId('topology-actions')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Fullscreen' })).toBeInTheDocument();
    expect(canvas().setDimensions).toHaveBeenCalled();
  });

  test('dispatches undo and redo history actions', () => {
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Undo' }));
    fireEvent.click(screen.getByRole('button', { name: 'Redo' }));
    expect(mockDispatch).toHaveBeenNthCalledWith(1, { type: 'topology/undo' });
    expect(mockDispatch).toHaveBeenNthCalledWith(2, { type: 'topology/redo' });
  });

  test('opens and closes the port mapping panel', () => {
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Toggle port mapping' }));
    expect(screen.getByTestId('port-mapping-panel')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Toggle port mapping' }));
    expect(screen.queryByTestId('port-mapping-panel')).not.toBeInTheDocument();
  });

  test('shows a device tooltip on hover and clears it on mouse out', () => {
    renderTopology();
    const target = {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceData: { resourceName: 'Router A', resourceId: 10 } },
    };
    act(() => canvas().handlers['mouse:over']({ target, e: { clientX: 10, clientY: 20 } }));
    expect(screen.getByTestId('node-tooltip')).toHaveTextContent('Router A');
    act(() => canvas().handlers['mouse:out']());
    expect(screen.getByTestId('node-tooltip')).toBeEmptyDOMElement();
  });

  test('shows a hardware-port tooltip in preference to a device tooltip', () => {
    renderTopology();
    const port = {
      shapeType: 'hardwarePort',
      metadata: {
        kind: 'port-node',
        ifindex: 3,
        details: { ifdesc: 'GigabitEthernet0/3' },
        portState: 'up',
      },
    };
    act(() => canvas().handlers['mouse:over']({
      target: { shapeType: 'deviceCompositeGroup', metadata: { deviceData: { resourceName: 'Router A' } } },
      subTargets: [port],
      e: { clientX: 30, clientY: 40 },
    }));
    expect(screen.getByText('GigabitEthernet0/3 - up')).toBeInTheDocument();
  });

  test('ignores non-right-click canvas mouse-down events', () => {
    renderTopology();
    const preventDefault = jest.fn();
    const stopPropagation = jest.fn();
    act(() => canvas().handlers['mouse:down']({
      target: { shapeType: 'deviceCompositeGroup', metadata: { deviceData: { resourceName: 'Router A' } } },
      e: { button: 0, preventDefault, stopPropagation },
    }));
    expect(preventDefault).not.toHaveBeenCalled();
    expect(screen.queryByRole('button', { name: 'Close context menu' })).not.toBeInTheDocument();
  });

  test('opens and closes the context menu for a right-clicked device', () => {
    mockState.inventory.resources = [{ resourceId: 10, resourceName: 'Router A' }];
    renderTopology();
    const preventDefault = jest.fn();
    const stopPropagation = jest.fn();
    act(() => canvas().handlers['mouse:down']({
      target: { shapeType: 'deviceCompositeGroup', metadata: { deviceId: 10 } },
      e: { button: 2, clientX: 40, clientY: 50, preventDefault, stopPropagation },
    }));
    expect(screen.getByTestId('context-menu')).toHaveTextContent('Router A');
    fireEvent.click(screen.getByRole('button', { name: 'Close context menu' }));
    expect(screen.queryByRole('button', { name: 'Close context menu' })).not.toBeInTheDocument();
    expect(preventDefault).toHaveBeenCalled();
    expect(stopPropagation).toHaveBeenCalled();
  });

  test('deletes all canvas objects and records the empty canvas state', () => {
    renderTopology();
    const first = { shapeType: 'deviceCompositeGroup' };
    const second = { shapeType: 'connector' };
    canvas().objects.push(first, second);
    fireEvent.click(screen.getByRole('button', { name: 'Clear canvas' }));
    expect(canvas().remove).toHaveBeenCalledWith(first);
    expect(canvas().remove).toHaveBeenCalledWith(second);
    expect(canvas().objects).toHaveLength(0);
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: 'topology/save' }));
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('deletes selected objects and clears the active selection', () => {
    renderTopology();
    const selected = { shapeType: 'deviceCompositeGroup' };
    canvas().objects.push(selected);
    canvas().activeObjects = [selected];
    fireEvent.click(screen.getByRole('button', { name: 'Delete selected' }));
    expect(canvas().remove).toHaveBeenCalledWith(selected);
    expect(canvas().discardActiveObject).toHaveBeenCalled();
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('warns when adding a connector without selecting a segment', () => {
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Add line' }));
    expect(mockToast).toHaveBeenCalledWith('warning', 'Please select a segment', 'warning');
    expect(canvas().add).not.toHaveBeenCalled();
  });

  test('adds a connector after segment and link data are selected', () => {
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Set segment' }));
    fireEvent.click(screen.getByRole('button', { name: 'Set link data' }));
    fireEvent.click(screen.getByRole('button', { name: 'Add arrow' }));
    expect(canvas().add).toHaveBeenCalledTimes(1);
    expect(canvas().setActiveObject).toHaveBeenCalled();
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: 'topology/save' }));
  });

  test('handles an unsupported background image file without loading it', () => {
    renderTopology();
    const input = screen.getByLabelText('Topology image');
    const invalidFile = new File(['not-an-image'], 'floorplan.png', { type: 'image/png' });
    fireEvent.change(input, { target: { files: [invalidFile] } });
    expect(canvas().add).not.toHaveBeenCalled();
  });

  test('commits canvas state and supports generic form-field updates', () => {
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Set custom field' }));
    expect(screen.getByTestId('form-state')).toHaveTextContent('custom-value');
    fireEvent.click(screen.getByRole('button', { name: 'Commit state' }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: 'topology/save' }));
  });

  test('clears the canvas through the form deleteCanvas action', () => {
    renderTopology();
    canvas().objects.push({ shapeType: 'connector' });
    fireEvent.click(screen.getByRole('button', { name: 'Delete canvas' }));
    expect(canvas().objects).toHaveLength(0);
    expect(mockToast).toHaveBeenCalledWith('Success', 'Canvas cleared successfully', 'success');
  });

  test('updates the radius of an active status indicator', () => {
    renderTopology();
    const indicator = makeFabricObject('circle', { shapeType: 'deviceStatus', radius: 40 });
    canvas().activeObject = indicator;
    fireEvent.click(screen.getByRole('button', { name: 'Set radius' }));
    expect(indicator.set).toHaveBeenCalledWith(expect.objectContaining({ radius: 55, width: 110, height: 110 }));
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('shows an informational message when a selected terminal has no saved topology', async () => {
    mockState.topologySlice.terminalTypes = [
      { subTypeId: 'missing-terminal', subTypeName: 'Test Terminal' },
    ];
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    renderTopology();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Load missing topology' }));
      await Promise.resolve();
    });
    expect(global.fetch).toHaveBeenCalledWith('/saveTopology/Test_Terminal.json');
    expect(mockToast).toHaveBeenCalledWith(
      'Info',
      'No topology found. Upload image to create topology.',
      'info',
    );
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('exports the current canvas as a sanitized terminal JSON filename', () => {
    mockState.topologySlice.terminalTypes = [
      { subTypeId: 'terminal-1', terminalTypeName: 'Main-Terminal North' },
    ];
    const createObjectURL = jest.fn(() => 'blob:test-topology');
    const revokeObjectURL = jest.fn();
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: revokeObjectURL });
    const clickSpy = jest.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {});
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));
    expect(createObjectURL).toHaveBeenCalledWith(expect.any(Blob));
    expect(clickSpy).toHaveBeenCalled();
    expect(revokeObjectURL).toHaveBeenCalledWith('blob:test-topology');
    expect(mockToast).toHaveBeenCalledWith('Success', 'Main_Terminal_North.json saved successfully', 'success');
  });

  test('hides the fullscreen action for CNMS mode', () => {
    mockState.nodeDetails.isCnms = true;
    renderTopology();
    expect(screen.queryByRole('button', { name: 'Fullscreen' })).not.toBeInTheDocument();
  });

  test('passes read-only mode to the context menu', () => {
    renderTopology({ readOnly: true });
    expect(screen.getByTestId('context-menu')).toHaveAttribute('data-view-only', 'true');
  });



  test('loads and restores a saved topology for the selected terminal', async () => {
    mockState.topologySlice.terminalTypes = [
      { subTypeId: 'terminal-1', subTypeName: 'Main Terminal' },
    ];
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ canvas: { objects: [] } }),
    });

    renderTopology();

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith('/saveTopology/Main_Terminal.json');
      expect(mockToast).toHaveBeenCalledWith('Success', 'Main Terminal topology loaded', 'success');
      expect(screen.getByTestId('read-only-state')).toHaveTextContent('false');
    });
    expect(canvas().loadFromJSON).toHaveBeenCalledWith({ objects: [] });
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('logs an error when loading a saved terminal topology fails', async () => {
    mockState.topologySlice.terminalTypes = [
      { subTypeId: 'terminal-1', subTypeName: 'Main Terminal' },
    ];
    global.fetch = jest.fn().mockRejectedValue(new Error('network unavailable'));
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Set terminal' }));

    await waitFor(() => {
      expect(errorSpy).toHaveBeenCalledWith(expect.any(Error));
    });
    expect(mockToast).not.toHaveBeenCalledWith(
      'Success', 'Main Terminal topology loaded', 'success'
    );
  });

  test('applies a Redux topology history snapshot to the Fabric canvas', async () => {
    mockState.topologySlice.present = { objects: [] };
    renderTopology();

    await waitFor(() => {
      expect(canvas().loadFromJSON).toHaveBeenCalledWith({ objects: [] });
      expect(canvas().requestRenderAll).toHaveBeenCalled();
    });
  });

  test('logs a Redux topology history restoration error and completes loading', async () => {
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    mockState.topologySlice.present = { objects: [{ type: 'circle' }] };
    mockLoadFromJSONError = new Error('invalid history snapshot');

    renderTopology();

    await waitFor(() => {
      expect(errorSpy).toHaveBeenCalledWith(
        'Failed applying Redux topology history:',
        expect.any(Error),
      );
    });
  });

  test('recursively removes private device and resource fields when saving topology JSON', async () => {
    const createObjectURL = jest.fn(() => 'blob:clean-topology');
    const revokeObjectURL = jest.fn();
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: revokeObjectURL });

    renderTopology();
    canvas().objects.push({
      type: 'group',
      shapeType: 'deviceCompositeGroup',
      metadata: {
        deviceData: {
          resourceName: 'Router A',
          resourceIp: '10.0.0.1',
          keepThisField: 'preserved',
          imResourceType: {
            model: 'private-model',
            data: 'private-data',
            keepTypeField: 'preserved-type',
          },
        },
      },
      objects: [{
        type: 'group',
        metadata: {
          deviceData: {
            serialNumOid: 'private-oid',
            keepNestedField: 'preserved-nested',
          },
        },
      }],
    });

    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));
    expect(createObjectURL).toHaveBeenCalledWith(expect.any(Blob));
    const blob = createObjectURL.mock.calls[0][0];
    const blobText = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(blob);
    });
    const payload = JSON.parse(blobText);
    const savedDevice = payload.canvas.objects[0];
    const savedDeviceData = savedDevice.metadata.deviceData;

    expect(savedDeviceData).not.toHaveProperty('resourceName');
    expect(savedDeviceData).not.toHaveProperty('resourceIp');
    expect(savedDeviceData.keepThisField).toBe('preserved');
    expect(savedDeviceData.imResourceType).not.toHaveProperty('model');
    expect(savedDeviceData.imResourceType).not.toHaveProperty('data');
    expect(savedDeviceData.imResourceType.keepTypeField).toBe('preserved-type');
    expect(savedDevice.objects[0].metadata.deviceData).not.toHaveProperty('serialNumOid');
    expect(savedDevice.objects[0].metadata.deviceData.keepNestedField).toBe('preserved-nested');
    expect(revokeObjectURL).toHaveBeenCalledWith('blob:clean-topology');
  });

  test('disposes the Fabric canvas and disconnects ResizeObserver on unmount', () => {
    const { unmount } = renderTopology();
    const instance = canvas();
    unmount();
    expect(instance.dispose).toHaveBeenCalled();
  });

  test('does not request topology when the selected terminal id is unknown', async () => {
    global.fetch = jest.fn();
    renderTopology();
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Load unknown terminal' }));
      await Promise.resolve();
    });
    expect(global.fetch).not.toHaveBeenCalled();
  });

  test('loads CNMS topology and enables its read-only view mode', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ canvas: { objects: [] } }),
    });
    renderTopology({ Rnms_TerminalType: 'Core-Site', Rnms_siteID: 'site-01' });
    await waitFor(() => expect(global.fetch).toHaveBeenCalledTimes(1));
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Load missing topology' }));
      await Promise.resolve();
    });

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith('/saveTopology/Core_Site.json');
      expect(canvas().loadFromJSON).toHaveBeenCalledWith({ objects: [] });
      expect(mockToast).toHaveBeenCalledWith('Success', 'Core-Site topology loaded', 'success');
      expect(screen.getByTestId('read-only-state')).toHaveTextContent('true');
    });
  });

  test('clears CNMS canvas and reports missing topology when the file is unavailable', async () => {
    const existing = makeFabricObject('rect', { shapeType: 'deviceRectangle' });
    mockInitialCanvasObjects = [existing];
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    renderTopology({ Rnms_TerminalType: 'Core-Site', Rnms_siteID: 'site-01' });
    await waitFor(() => expect(global.fetch).toHaveBeenCalledTimes(1));
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Load missing topology' }));
      await Promise.resolve();
    });

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledTimes(2);
      expect(global.fetch).toHaveBeenCalledWith('/saveTopology/Core_Site.json');
      expect(canvas().remove).toHaveBeenCalledWith(existing);
      expect(mockToast).toHaveBeenCalledWith(
        'Info',
        'No topology found. Upload image to create topology.',
        'info',
      );
      expect(screen.getByTestId('read-only-state')).toHaveTextContent('false');
    });
  });

  test('logs an error when the CNMS topology endpoint fails', async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error('CNMS network failure'));
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    renderTopology({ Rnms_TerminalType: 'Core-Site', Rnms_siteID: 'site-01' });
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Load missing topology' }));
      await Promise.resolve();
    });

    await waitFor(() => {
      expect(errorSpy).toHaveBeenCalledWith(
        'Failed to load CNMS topology:',
        expect.any(Error),
      );
    });
  });

  test('auto-loads the logged-in terminal topology when rep details are available', async () => {
    mockState.nodeDetails.repDetails = {
      imTerminalType: { terminalTypeName: 'Logged-In Terminal' },
    };
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ canvas: { objects: [] } }),
    });

    renderTopology();

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith('/saveTopology/Logged_In_Terminal.json');
      expect(canvas().loadFromJSON).toHaveBeenCalledWith({ objects: [] });
      expect(screen.getByTestId('read-only-state')).toHaveTextContent('true');
    });
  });

  test('logs an error when auto-loading the logged-in CNMS topology fails', async () => {
    mockState.nodeDetails.repDetails = {
      imTerminalType: { terminalTypeName: 'Logged-In Terminal' },
    };
    global.fetch = jest.fn().mockRejectedValue(new Error('auto-load failure'));
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    renderTopology();

    await waitFor(() => {
      expect(errorSpy).toHaveBeenCalledWith(
        'Failed to auto-load CNMS topology:',
        expect.any(Error),
      );
    });
  });

  test('creates a device marker and records the updated canvas state', async () => {
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Set terminal' }));

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Create device marker' }));
      await Promise.resolve();
    });

    expect(canvas().add).toHaveBeenCalledTimes(2);
    expect(canvas().setActiveObject).toHaveBeenCalled();
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: 'topology/save' }));
  });

  test('updates the status indicator associated with the selected device group', () => {
    renderTopology();
    const selectedDevice = makeFabricObject('group', {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceId: 'device-77' },
    });
    const indicator = makeFabricObject('circle', {
      shapeType: 'deviceStatus',
      metadata: { deviceId: 'device-77' },
      radius: 40,
    });
    canvas().objects.push(selectedDevice, indicator);
    canvas().activeObject = selectedDevice;

    fireEvent.click(screen.getByRole('button', { name: 'Set associated radius' }));

    expect(indicator.set).toHaveBeenCalledWith(
      expect.objectContaining({ radius: 65, width: 130, height: 130, dirty: true }),
    );
    expect(indicator.setCoords).toHaveBeenCalled();
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('ignores an empty or invalid radius value for canvas objects', () => {
    renderTopology();
    const indicator = makeFabricObject('circle', { shapeType: 'deviceStatus', radius: 40 });
    canvas().activeObject = indicator;

    fireEvent.click(screen.getByRole('button', { name: 'Clear radius' }));

    expect(indicator.set).not.toHaveBeenCalled();
    expect(canvas().requestRenderAll).not.toHaveBeenCalled();
  });

  test('restores Redux history connector colors and nested device-port interaction settings', async () => {
    const line = makeFabricObject('line');
    const triangle = makeFabricObject('triangle');
    const connector = makeFabricObject('group', {
      metadata: { kind: 'connector', linkId: 11, linkName: 'LAN', linkStatus: 'DOWN' },
      objects: [line, triangle],
    });
    const svgState = makeFabricObject('group', { metadata: { portState: 'up' } });
    const stateContainer = makeFabricObject('group', { objects: [svgState] });
    const hardwarePort = makeFabricObject('group', {
      shapeType: 'hardwarePort',
      metadata: { kind: 'port-node', ifindex: 1, portState: 'up' },
      objects: [stateContainer],
    });
    const device = makeFabricObject('group', {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceId: 'device-77' },
      objects: [hardwarePort],
    });
    mockInitialCanvasObjects = [connector, device];
    mockState.topologySlice.present = { objects: [{ type: 'group' }] };
    mockState.topologySlice.linkStatusData = [
      { linkId: 11, linkName: 'LAN', linkStatus: 'UP' },
    ];

    renderTopology();

    await waitFor(() => {
      expect(connector.metadata.linkStatus).toBe('UP');
      expect(line.set).toHaveBeenCalledWith(expect.objectContaining({ stroke: '#123456' }));
      expect(triangle.set).toHaveBeenCalledWith(expect.objectContaining({ fill: '#123456' }));
      expect(device.set).toHaveBeenCalledWith({ subTargetCheck: true });
      expect(hardwarePort.set).toHaveBeenCalledWith({
        subTargetCheck: true,
        evented: true,
        selectable: false,
      });
      expect(stateContainer.set).toHaveBeenCalledWith({ subTargetCheck: true, evented: true });
      expect(hardwarePort.setCoords).toHaveBeenCalled();
      expect(device.setCoords).toHaveBeenCalled();
    });
  });

  test('handles connectors without a matching live link status during Redux restoration', async () => {
    const connector = makeFabricObject('group', {
      metadata: { kind: 'connector', linkId: 999 },
      objects: [],
    });
    mockInitialCanvasObjects = [connector];
    mockState.topologySlice.present = { objects: [{ type: 'group' }] };
    mockState.topologySlice.linkStatusData = [];
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    renderTopology();

    await waitFor(() => {
      expect(warnSpy).toHaveBeenCalledWith(
        'No live link status found for connector linkId: 999',
      );
    });
  });

  test('ignores Redux history restoration when there is no topology snapshot', () => {
    mockState.topologySlice.present = null;
    renderTopology();
    expect(canvas().loadFromJSON).not.toHaveBeenCalled();
  });


  test('does not auto-load CNMS topology while resources are still loading', () => {
    global.fetch = jest.fn();
    renderTopology({ Rnms_TerminalType: 'Core-Site', resourcesLoading: true });
    expect(global.fetch).not.toHaveBeenCalled();
  });

  test('uses the default Topology filename when no terminal is selected for export', () => {
    const createObjectURL = jest.fn(() => 'blob:default-topology');
    const revokeObjectURL = jest.fn();
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: revokeObjectURL });
    renderTopology();

    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));

    expect(createObjectURL).toHaveBeenCalledWith(expect.any(Blob));
    expect(revokeObjectURL).toHaveBeenCalledWith('blob:default-topology');
    expect(mockToast).toHaveBeenCalledWith('Success', 'Topology.json saved successfully', 'success');
  });

  test('preserves null device data and metadata-free objects during recursive export cleaning', async () => {
    const createObjectURL = jest.fn(() => 'blob:null-safe-topology');
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: jest.fn() });
    renderTopology();
    canvas().objects.push(
      { type: 'rect' },
      { type: 'group', metadata: { deviceData: null } },
      { type: 'group', metadata: null, objects: [{ type: 'circle' }] },
    );

    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));
    const blob = createObjectURL.mock.calls[0][0];
    const text = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(blob);
    });
    const payload = JSON.parse(text);

    expect(payload.canvas.objects[0]).toEqual({ type: 'rect', fill: 'transparent' });
    expect(payload.canvas.objects[1].metadata.deviceData).toBeNull();
    expect(payload.canvas.objects[2].metadata).toBeNull();
    expect(payload.canvas.objects[2].objects[0].type).toBe('circle');
  });



  test('applies canvas read-only properties to restored Fabric objects', async () => {
    mockObjectsAfterLoad = [
      makeFabricObject('rect', { shapeType: 'deviceRectangle' }),
      makeFabricObject('circle', { shapeType: 'deviceStatus' }),
    ];
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ canvas: { objects: [] } }),
    });

    renderTopology({ Rnms_TerminalType: 'Core-Site', Rnms_siteID: 'site-01' });

    await waitFor(() => {
      expect(canvas().objects).toHaveLength(2);
      for (const object of canvas().objects) {
        expect(object.set).toHaveBeenCalledWith({
          selectable: false,
          evented: true,
          lockMovementX: true,
          lockMovementY: true,
          lockScalingX: true,
          lockScalingY: true,
          lockRotation: true,
          hasControls: false,
          hasBorders: false,
        });
      }
    });
    expect(canvas().discardActiveObject).toHaveBeenCalled();
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });

  test('updates matching restored devices from non-empty Redux resources', async () => {
    const rectangle = makeFabricObject('rect', { shapeType: 'deviceRectangle' });
    const device = makeFabricObject('group', {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceId: 'device-77' },
      objects: [rectangle],
    });
    mockInitialCanvasObjects = [];
    mockObjectsAfterLoad = [device];
    mockState.topologySlice.present = { objects: [{ type: 'group' }] };
    mockState.inventory.resources = [{
      resourceId: 'device-77', status: 'UP', resourceIp: '10.0.0.77',
    }];

    renderTopology();

    await waitFor(() => {
      expect(device.metadata.status).toBe('UP');
      expect(device.metadata.ipAddress).toBe('10.0.0.77');
      expect(device.metadata.deviceData.resourceId).toBe('device-77');
      expect(rectangle.set).toHaveBeenCalledWith(
        expect.objectContaining({ stroke: '#00aa00', dirty: true }),
      );
    });
  });

  test('skips non-hardware children while restoring Redux device port interactions', async () => {
    const unrelatedChild = makeFabricObject('rect', { shapeType: 'unrelatedChild' });
    const hardwarePort = makeFabricObject('group', {
      shapeType: 'hardwarePort',
      metadata: { kind: 'port-node', ifindex: 2 },
      objects: [],
    });
    const device = makeFabricObject('group', {
      shapeType: 'deviceCompositeGroup',
      objects: [unrelatedChild, hardwarePort],
    });
    mockInitialCanvasObjects = [device];
    mockState.topologySlice.present = { objects: [{ type: 'group' }] };

    renderTopology();

    await waitFor(() => {
      expect(device.set).toHaveBeenCalledWith({ subTargetCheck: true });
      expect(hardwarePort.set).toHaveBeenCalledWith({
        subTargetCheck: true, evented: true, selectable: false,
      });
    });
    expect(unrelatedChild.set).not.toHaveBeenCalledWith(
      expect.objectContaining({ subTargetCheck: true }),
    );
  });

  test('handles non-object metadata, device data, resource types and nested Fabric entries during export', async () => {
    const createObjectURL = jest.fn(() => 'blob:non-object-export');
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: jest.fn() });
    renderTopology();
    canvas().objects.push(
      { type: 'group', metadata: 'legacy-metadata' },
      { type: 'group', metadata: { deviceData: 'legacy-device-data' } },
      { type: 'group', metadata: { deviceData: { imResourceType: 'legacy-resource-type' } } },
      { type: 'group', objects: [null, 'legacy-child'] },
    );

    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));
    const blob = createObjectURL.mock.calls[0][0];
    const exportedText = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(blob);
    });
    const exported = JSON.parse(exportedText);

    expect(exported.canvas.objects[0].metadata).toBe('legacy-metadata');
    expect(exported.canvas.objects[1].metadata.deviceData).toBe('legacy-device-data');
    expect(exported.canvas.objects[2].metadata.deviceData.imResourceType).toBe('legacy-resource-type');
    expect(exported.canvas.objects[3].objects).toEqual([null, 'legacy-child']);
  });

  test('exports an empty objects array when Fabric returns a non-array objects value', async () => {
    const createObjectURL = jest.fn(() => 'blob:empty-objects-export');
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: jest.fn() });
    renderTopology();
    canvas().toJSON.mockReturnValue({ objects: null, version: 'test' });

    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));
    const blob = createObjectURL.mock.calls[0][0];
    const exportedText = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(blob);
    });
    const exported = JSON.parse(exportedText);

    expect(exported.canvas.objects).toEqual([]);
  });


  test('warns when a right-clicked device has no matching device data', () => {
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    renderTopology();
    const preventDefault = jest.fn();
    const stopPropagation = jest.fn();

    act(() => canvas().handlers['mouse:down']({
      target: { shapeType: 'deviceCompositeGroup', metadata: { deviceId: 'missing-device' } },
      e: { button: 2, clientX: 10, clientY: 20, preventDefault, stopPropagation },
    }));

    expect(warnSpy).toHaveBeenCalledWith(
      'Context menu: device data not found',
      expect.objectContaining({ deviceId: 'missing-device', latestResources: [] }),
    );
    expect(screen.queryByRole('button', { name: 'Close context menu' })).not.toBeInTheDocument();
  });

  test('handles canvas context menu suppression and mouse move tooltip branches', () => {
    renderTopology();

    const contextMenuHandler = canvas().upperCanvasEl.addEventListener.mock.calls
      .find(([eventName]) => eventName === 'contextmenu')[1];
    const preventDefault = jest.fn();
    contextMenuHandler({ preventDefault });
    expect(preventDefault).toHaveBeenCalled();

    const device = {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceData: { resourceName: 'Move Device' } },
    };
    act(() => canvas().handlers['mouse:move']({
      target: device,
      e: { clientX: 31, clientY: 42 },
    }));
    expect(screen.getByTestId('node-tooltip')).toHaveTextContent('Move Device');

    act(() => canvas().handlers['mouse:move']({
      target: { shapeType: 'rect' },
      e: { clientX: 50, clientY: 60 },
    }));
    expect(screen.getByTestId('node-tooltip')).toBeEmptyDOMElement();

    const port = {
      shapeType: 'hardwarePort',
      metadata: { kind: 'port-node', ifindex: 7, details: { ifdesc: 'xe-0/0/7' }, currentState: 'up' },
    };
    act(() => canvas().handlers['mouse:move']({
      target: device,
      subTargets: [port],
      e: { clientX: 70, clientY: 80 },
    }));
    expect(screen.getByText('xe-0/0/7 - up')).toBeInTheDocument();
  });

  test('handles object modification and selection create/update/clear events', async () => {
    const background = {
      width: 200, height: 100, left: 10, top: 20, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(background);
    renderTopology();
    fireEvent.change(screen.getByLabelText('Topology image'), {
      target: { files: [new File(['jpeg'], 'layout.jpg', { type: 'image/jpeg' })] },
    });
    await waitFor(() => expect(canvas().backgroundImage).toBe(background));

    const modified = {
      left: 50, top: 40, scaleX: 10, scaleY: 5, id: 'move-1', metadata: {},
    };
    act(() => canvas().handlers['object:modified']({ target: modified }));
    expect(modified.metadata).toEqual(expect.objectContaining({
      imageX: 0.2, imageY: 0.2, imageScaleX: 0.05, imageScaleY: 0.05,
    }));

    const indicator = { shapeType: 'deviceStatus', radius: 18, metadata: { deviceId: 'd-1' } };
    const device = { shapeType: 'deviceCompositeGroup', metadata: { deviceId: 'd-1' } };
    canvas().objects.push(indicator);
    act(() => canvas().handlers['selection:created']({ selected: [indicator] }));
    expect(screen.getByTestId('form-state')).toHaveTextContent('"radioWidth":"18"');

    act(() => canvas().handlers['selection:updated']({ selected: [device] }));
    expect(screen.getByTestId('form-state')).toHaveTextContent('"radioWidth":"18"');

    act(() => canvas().handlers['selection:updated']({ selected: [{ shapeType: 'rect' }] }));
    act(() => canvas().handlers['selection:cleared']());
  });

  test('toggles fullscreen, exits another fullscreen element first, and handles API rejection', async () => {
    const requestFullscreen = jest.fn().mockResolvedValue(undefined);
    const exitFullscreen = jest.fn().mockResolvedValue(undefined);
    Object.defineProperty(HTMLElement.prototype, 'requestFullscreen', {
      configurable: true, value: requestFullscreen,
    });
    Object.defineProperty(document, 'exitFullscreen', {
      configurable: true, value: exitFullscreen,
    });
    renderTopology();
    const fullscreenButton = screen.getByRole('button', { name: 'Fullscreen' });

    await act(async () => { fireEvent.click(fullscreenButton); });
    expect(requestFullscreen).toHaveBeenCalledTimes(1);

    const otherElement = document.createElement('div');
    Object.defineProperty(document, 'fullscreenElement', {
      configurable: true, value: otherElement,
    });
    await act(async () => { fireEvent.click(fullscreenButton); });
    expect(exitFullscreen).toHaveBeenCalled();
    expect(requestFullscreen).toHaveBeenCalledTimes(2);

    requestFullscreen.mockRejectedValueOnce(new Error('fullscreen denied'));
    const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    await act(async () => { fireEvent.click(fullscreenButton); });
    expect(errorSpy).toHaveBeenCalledWith(
      'Failed to toggle topology fullscreen:', expect.any(Error),
    );
  });

  test('handles right-click resource matching through alternate identifier fields', () => {
    mockState.inventory.resources = [{ nodeId: '  node-88  ', resourceName: 'Node 88' }];
    renderTopology();
    const preventDefault = jest.fn();
    const stopPropagation = jest.fn();

    act(() => canvas().handlers['mouse:down']({
      target: { shapeType: 'deviceCompositeGroup', metadata: { deviceId: 'node-88' } },
      e: { button: 2, clientX: 12, clientY: 34, preventDefault, stopPropagation },
    }));
    expect(preventDefault).toHaveBeenCalled();
    expect(stopPropagation).toHaveBeenCalled();
    expect(screen.getByTestId('context-menu')).toHaveTextContent('Node 88');
  });

  test('loads a JPEG background image and applies it to the canvas', async () => {
    const image = {
      width: 1200, height: 800, left: 0, top: 0, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(image);
    renderTopology();
    const file = new File(['jpeg-content'], 'floor-plan.jpg', { type: 'image/jpeg' });

    fireEvent.change(screen.getByLabelText('Topology image'), {
      target: { files: [file] },
    });

    await waitFor(() => expect(mockImageFromURL).toHaveBeenCalledWith(
      expect.stringMatching(/^data:image\/jpeg/),
      { crossOrigin: 'anonymous' },
    ));
    await waitFor(() => expect(canvas().backgroundImage).toBe(image));

    expect(image.set).toHaveBeenCalledWith(expect.objectContaining({
      objectCaching: false, noScaleCache: true, dirty: true,
    }));
    expect(canvas().setViewportTransform).toHaveBeenCalledWith(
      expect.arrayContaining([expect.any(Number), 0, 0, expect.any(Number), 0, 0]),
    );
  });

  test('stores connector coordinates relative to the uploaded background image', async () => {
    const image = {
      width: 100, height: 50, left: 0, top: 0, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(image);
    renderTopology();

    fireEvent.change(screen.getByLabelText('Topology image'), {
      target: { files: [new File(['jpeg'], 'map.jpeg', { type: 'image/jpeg' })] },
    });
    await waitFor(() => expect(canvas().backgroundImage).toBe(image));

    fireEvent.click(screen.getByRole('button', { name: 'Set segment' }));
    fireEvent.click(screen.getByRole('button', { name: 'Set link data' }));
    fireEvent.click(screen.getByRole('button', { name: 'Add arrow' }));

    const connector = canvas().add.mock.calls.at(-1)[0];
    expect(connector.metadata).toEqual(expect.objectContaining({
      kind: 'connector', linkName: 'LAN', imageX: 1.2, imageY: 2.4,
      imageScaleX: expect.any(Number), imageScaleY: expect.any(Number),
    }));
  });

  test('stores created device coordinates relative to the uploaded background image', async () => {
    const image = {
      width: 100, height: 100, left: 0, top: 0, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(image);
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    renderTopology();

    fireEvent.change(screen.getByLabelText('Topology image'), {
      target: { files: [new File(['jpeg'], 'map.jpg', { type: 'image/jpeg' })] },
    });
    await waitFor(() => expect(canvas().backgroundImage).toBe(image));

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Create device marker' }));
      await Promise.resolve();
    });

    const createdObjects = canvas().add.mock.calls.map(([object]) => object);
    expect(createdObjects).toHaveLength(2);
    expect(createdObjects[0].metadata).toEqual(expect.objectContaining({
      imageX: expect.any(Number), imageY: expect.any(Number),
      imageScaleX: expect.any(Number), imageScaleY: expect.any(Number),
    }));
    expect(createdObjects[1].metadata).toEqual(expect.objectContaining({
      imageX: expect.any(Number), imageY: expect.any(Number),
      imageScaleX: expect.any(Number), imageScaleY: expect.any(Number),
    }));
  });

  test('restores saved background, migrates legacy ports and applies live resource updates', async () => {
    const image = {
      width: 1000, height: 500, left: 0, top: 0, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(image);

    const svgUp = makeFabricObject('group', { metadata: { portState: 'up' } });
    const svgNotConfigured = makeFabricObject('group', {
      metadata: { portState: 'notConfigured' },
    });
    const stateContainer = makeFabricObject('group', {
      objects: [svgUp, svgNotConfigured],
    });
    const legacyPort = makeFabricObject('group', {
      metadata: { kind: 'port-node', ifindex: 4, portState: 'up', currentState: 'up' },
      objects: [stateContainer],
    });
    const hardwarePort = makeFabricObject('group', {
      shapeType: 'hardwarePort',
      metadata: { ifindex: 5, portState: 'up', currentState: 'up' },
      objects: [stateContainer],
    });
    const unrelatedChild = makeFabricObject('rect', { shapeType: 'unrelatedChild' });
    const deviceRectangle = makeFabricObject('rect', { shapeType: 'deviceRectangle' });
    const device = makeFabricObject('group', {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceId: 'device-77' },
      objects: [legacyPort, hardwarePort, unrelatedChild, deviceRectangle],
    });
    const indicator = makeFabricObject('circle', {
      shapeType: 'deviceStatus', metadata: { deviceId: 'device-77' },
    });
    mockObjectsAfterLoad = [device, indicator];
    mockState.inventory.resources = [{
      resourceId: 'device-77', status: 'UP', resourceIp: '10.0.0.77',
    }];
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({
        backgroundImage: 'data:image/jpeg;base64,ZmFrZQ==',
        canvas: { objects: [] },
      }),
    });

    renderTopology({ Rnms_TerminalType: 'Core-Site', Rnms_siteID: 'site-01' });

    await waitFor(() => {
      expect(canvas().backgroundImage).toBe(image);
      expect(legacyPort.shapeType).toBe('hardwarePort');
      expect(legacyPort.metadata).toEqual(expect.objectContaining({
        portState: 'up', currentState: 'up',
      }));
      expect(legacyPort.set).toHaveBeenCalledWith(expect.objectContaining({
        subTargetCheck: true, evented: true, selectable: false,
      }));
      expect(hardwarePort.set).toHaveBeenCalledWith(expect.objectContaining({
        subTargetCheck: true, evented: true, selectable: false,
      }));
      expect(stateContainer.set).toHaveBeenCalledWith({ subTargetCheck: true, evented: true });
      expect(device.set).toHaveBeenCalledWith({ subTargetCheck: true });
      expect(deviceRectangle.set).toHaveBeenCalledWith(
        expect.objectContaining({ stroke: '#00aa00', dirty: true }),
      );
      expect(device.metadata.status).toBe('UP');
      expect(device.metadata.ipAddress).toBe('10.0.0.77');
    });

    expect(image.set).toHaveBeenCalledWith(expect.objectContaining({ objectCaching: false }));
    expect(legacyPort.setCoords).toHaveBeenCalled();
    expect(hardwarePort.setCoords).toHaveBeenCalled();
    expect(device.setCoords).toHaveBeenCalled();
    expect(svgUp.set).toHaveBeenCalledWith(expect.objectContaining({ visible: true, dirty: true }));
    expect(canvas().requestRenderAll).toHaveBeenCalled();
  });


  test('resizes the canvas for positive host dimensions and skips zero dimensions', () => {
    renderTopology();
    const host = document.querySelector('.fabric-canvas-host');
    const bounds = jest.spyOn(host, 'getBoundingClientRect');

    bounds.mockReturnValue({ width: 640, height: 360 });
    act(() => global.__fabricResizeObserver.callback());
    expect(canvas().setDimensions).toHaveBeenCalledWith({ width: 640, height: 360 });
    expect(canvas().calcOffset).toHaveBeenCalled();
    expect(canvas().requestRenderAll).toHaveBeenCalled();

    canvas().setDimensions.mockClear();
    bounds.mockReturnValue({ width: 0, height: 360 });
    act(() => global.__fabricResizeObserver.callback());
    expect(canvas().setDimensions).not.toHaveBeenCalled();
  });

  test('resizes the canvas against its background image and syncs image-relative objects', async () => {
    const background = {
      width: 200, height: 100, left: 0, top: 0, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(background);
    renderTopology();
    fireEvent.change(screen.getByLabelText('Topology image'), {
      target: { files: [new File(['jpeg'], 'resize.jpg', { type: 'image/jpeg' })] },
    });
    await waitFor(() => expect(canvas().backgroundImage).toBe(background));

    const positioned = makeFabricObject('rect', {
      left: 20, top: 10, scaleX: 1, scaleY: 1,
      metadata: { imageX: 0.25, imageY: 0.5, imageScaleX: 0.1, imageScaleY: 0.2 },
    });
    canvas().objects.push(positioned);
    const host = document.querySelector('.fabric-canvas-host');
    jest.spyOn(host, 'getBoundingClientRect').mockReturnValue({ width: 400, height: 300 });

    act(() => global.__fabricResizeObserver.callback());
    expect(canvas().setViewportTransform).toHaveBeenCalledWith([2, 0, 0, 3, 0, 0]);
    expect(positioned.set).toHaveBeenCalledWith({
      left: 50, top: 50, scaleX: 20, scaleY: 20,
    });
    expect(positioned.setCoords).toHaveBeenCalled();
  });

  test('handles mouse move over a device and then over empty canvas', () => {
    renderTopology();
    const device = {
      shapeType: 'deviceCompositeGroup',
      metadata: { deviceData: { resourceName: 'Move Device' } },
    };
    act(() => canvas().handlers['mouse:move']({
      target: device,
      e: { clientX: 44, clientY: 55 },
    }));
    expect(screen.getByTestId('node-tooltip')).toHaveTextContent('Move Device');

    act(() => canvas().handlers['mouse:move']({
      target: { shapeType: 'rect' },
      e: { clientX: 50, clientY: 60 },
    }));
    expect(screen.getByTestId('node-tooltip')).toBeEmptyDOMElement();
  });

  test('records device marker coordinates relative to an existing background image', async () => {
    const background = {
      width: 500, height: 250, left: 10, top: 20, scaleX: 1, scaleY: 1,
      set: jest.fn(),
    };
    mockImageFromURL.mockResolvedValue(background);
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    renderTopology();
    fireEvent.change(screen.getByLabelText('Topology image'), {
      target: { files: [new File(['jpeg'], 'device-layout.jpg', { type: 'image/jpeg' })] },
    });
    await waitFor(() => expect(canvas().backgroundImage).toBe(background));

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'Create device marker' }));
      await Promise.resolve();
    });

    const placedObjects = canvas().add.mock.calls.map(([obj]) => obj);
    expect(placedObjects).toHaveLength(2);
    placedObjects.forEach((obj) => {
      expect(obj.metadata).toEqual(expect.objectContaining({
        imageX: expect.any(Number), imageY: expect.any(Number),
        imageScaleX: expect.any(Number), imageScaleY: expect.any(Number),
      }));
    });
  });

});
