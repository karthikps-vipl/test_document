jest.mock('react-redux', () => ({
  useDispatch: () => globalThis.__mockDispatch,
  useSelector: (selector) => selector({ inventory: { isTableMaximized: true } }),
}));
jest.mock('@/utility/portFilterUtils', () => ({ filterSwitchPorts: (ports) => ports }));
jest.mock('../../src/components/Reusable/FullScreen/CustomeFullscreen', () => ({
  __esModule: true,
  CustomeFullscreen: ({ isFullScreen, onToggleFullScreen }) => (
    <button type="button" onClick={onToggleFullScreen} data-testid="fullscreen" data-fullscreen={String(isFullScreen)}>Toggle</button>
  ),
}));
import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import BaseDialogLayout from '../../src/components/Dialogs/BaseDialogLayout';
import { toggleTableMaximize } from '../../src/store/features/Inventory/inventorySlice';

const mockDispatch = jest.fn();

describe('BaseDialogLayout', () => {
  beforeEach(() => { globalThis.__mockDispatch = mockDispatch; mockDispatch.mockClear(); });
  test('renders title, child content and close action', () => {
    const onClose = jest.fn();
    render(<BaseDialogLayout title="Device details" onClose={onClose}><p>Device content</p></BaseDialogLayout>);
    expect(screen.getByText('Device details')).toBeInTheDocument();
    expect(screen.getByText('Device content')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Close' }));
    expect(onClose).toHaveBeenCalledTimes(1);
  });
  test('passes maximize state to fullscreen control and dispatches toggle action', () => {
    render(<BaseDialogLayout title="Status" onClose={jest.fn()} />);
    expect(screen.getByTestId('fullscreen')).toHaveAttribute('data-fullscreen', 'true');
    fireEvent.click(screen.getByTestId('fullscreen'));
    expect(mockDispatch).toHaveBeenCalledWith(toggleTableMaximize());
  });
});
