import reducer, {
  determineStatusRedux,
  normalizeReactFlowNode,
  setNodes,
  setRackLayout,
  setIsCnmsMode,
  setCurrentViewTopology,
  updateNodeLabel,
  setImageNodePortStatusLive,
  pushToUndoStack,
  performUndo,
  performRedo,
  selectRackNodes,
  selectCanUndo,
  selectCanRedo,
} from '../../src/store/features/Topology/topologyNodesslice';

const resource = (overrides = {}) => ({
  resourceId: 1,
  imResourceType: { imResourceStateInfo: { resourceStateId: 1 } },
  isDiscovered: true,
  isMaintainance: false,
  nePollingInfo: { isReachable: true },
  ...overrides,
});

describe('topology node slice behaviour', () => {
  test('normalizes missing node fields and numeric positions', () => {
    expect(normalizeReactFlowNode({ id: 'n1', position: { x: '12', y: 'bad' } })).toEqual({
      id: 'n1', type: 'rackNode', position: { x: 12, y: 0 }, data: {},
    });
    expect(normalizeReactFlowNode({ id: 'n2', type: 'custom', data: { label: 'A' } }, 'commonNode')).toEqual(expect.objectContaining({
      type: 'custom', position: { x: 0, y: 0 }, data: { label: 'A' },
    }));
  });

  test('determines unmanaged, online, offline, maintenance and undiscovered states', () => {
    expect(determineStatusRedux(resource({ imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } }))).toBe('unmanaged');
    expect(determineStatusRedux(resource())).toBe('online');
    expect(determineStatusRedux(resource({ nePollingInfo: { isReachable: false } }))).toBe('offline');
    expect(determineStatusRedux(resource({ isDiscovered: false, isMaintainance: true }))).toBe('maintenance');
    expect(determineStatusRedux(resource({ isDiscovered: false, isMaintainance: false }))).toBe('undiscovered');
  });

  test('uses CNMS reachability instead of RNMS polling data', () => {
    expect(determineStatusRedux(resource({ isReachable: true, nePollingInfo: { isReachable: false } }), true)).toBe('online');
    expect(determineStatusRedux(resource({ isReachable: false, nePollingInfo: { isReachable: true } }), true)).toBe('offline');
  });

  test('sets nodes and recalculates device statistics', () => {
    let state = reducer(undefined, { type: '@@init' });
    state = reducer(state, setNodes([
      { id: '1', data: resource() },
      { id: '2', data: resource({ resourceId: 2, nePollingInfo: { isReachable: false } }) },
      { id: '3', data: resource({ resourceId: 3, isDiscovered: false }) },
      { id: '4', data: resource({ resourceId: 4, imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } }) },
    ]));
    expect(state.nodes).toHaveLength(4);
    expect(state.deviceStats).toEqual({ online: 1, offline: 1, maintenance: 0, undiscovered: 1, unmanaged: 1 });
  });

  test('recalculates stats when switching CNMS mode', () => {
    let state = reducer(undefined, setNodes([{ id: '1', data: resource({ isReachable: false }) }]));
    state = reducer(state, setIsCnmsMode(true));
    expect(state.isCnms).toBe(true);
    expect(state.deviceStats.offline).toBe(1);
  });

  test('normalizes rack layout nodes', () => {
    const state = reducer(undefined, setRackLayout([{ id: 'r1', position: { x: '4', y: '8' } }]));
    expect(state.rackLayout[0]).toEqual(expect.objectContaining({
      id: 'r1', type: 'rackNode', position: { x: 4, y: 8 }, data: {},
    }));
  });

  test('toggles the current topology view', () => {
    let state = reducer(undefined, { type: '@@init' });
    expect(state.currentViewTopology).toBe(true);
    state = reducer(state, setCurrentViewTopology());
    expect(state.currentViewTopology).toBe(false);
    state = reducer(state, setCurrentViewTopology());
    expect(state.currentViewTopology).toBe(true);
  });

  test('updates matching node labels in both topology and rack layout', () => {
    let state = reducer(undefined, setNodes([{ id: 'n1', data: { resourceId: 101, label: 'Old' }, style: {} }]));
    state = reducer(state, setRackLayout([{ id: 'r1', data: { resourceId: 202 }, style: {} }]));
    state = reducer(state, updateNodeLabel({ id: 101, label: 'New node', color: '#123456', borderColor: '#654321' }));
    state = reducer(state, updateNodeLabel({ id: 202, label: 'Rack node', color: '#abcdef', borderColor: '#fedcba' }));
    expect(state.nodes[0].data).toEqual(expect.objectContaining({ label: 'New node', text: 'New node', color: '#123456' }));
    expect(state.rackLayout[0].data).toEqual(expect.objectContaining({ label: 'Rack node', text: 'Rack node' }));
  });

  test('updates live port status for matching resources', () => {
    let state = reducer(undefined, setNodes([{ id: 'n1', data: { resourceId: 5 } }]));
    const ports = [{ portNumber: 1, status: 'up' }];
    state = reducer(state, setImageNodePortStatusLive({ resourceId: 5, lstPortInfoDtl: ports }));
    expect(state.nodes[0].data.lstPortInfoDtl).toEqual(ports);
  });

  test('supports undo and redo history transitions', () => {
    let state = reducer(undefined, setNodes([{ id: 'first', data: {} }]));
    state = reducer(state, pushToUndoStack());
    state = reducer(state, setNodes([{ id: 'second', data: {} }]));
    state = reducer(state, performUndo());
    expect(state.nodes[0].id).toBe('first');
    expect(state.redoStack).toHaveLength(1);
    state = reducer(state, performRedo());
    expect(state.nodes[0].id).toBe('second');
  });

  test('exposes rack and history selectors', () => {
    const state = reducer(undefined, { type: '@@init' });
    const root = { topologySlice: state };
    expect(selectRackNodes(root)).toEqual(state.rackNodes);
    expect(selectCanUndo(root)).toBe(false);
    expect(selectCanRedo(root)).toBe(false);
  });
});
