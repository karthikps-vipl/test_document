import React from 'react';
import { render, screen } from '@testing-library/react';
import StaticWidget from '../../src/components/Dialogs/components/widgets/StaticWidget';

describe('StaticWidget', () => {
  test('renders title and mapped OID values', () => {
    render(<StaticWidget widget={{ tableTitle: 'Device details', data: [
      { name: 'Serial', oid: '1.2.3' }, { name: 'Firmware', oid: '1.2.4' },
    ] }} oidValueMap={{ '1.2.3': { operator_map: 'SN-01' }, '1.2.4': { operator_map: 'v2.1' } }} />);
    expect(screen.getByText('Device details')).toBeInTheDocument();
    expect(screen.getByText('Serial: SN-01')).toBeInTheDocument();
    expect(screen.getByText('Firmware: v2.1')).toBeInTheDocument();
  });
  test('shows placeholder when OID mapping is missing', () => {
    render(<StaticWidget widget={{ tableTitle: 'Status', data: [{ name: 'Reachability', oid: 'missing' }] }} oidValueMap={{}} />);
    expect(screen.getByText('Reachability: --')).toBeInTheDocument();
  });
});
