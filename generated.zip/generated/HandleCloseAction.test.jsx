import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { useSelector } from "react-redux";
import { useTheme } from "@mui/material";
import HandleCloseAction from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleCloseAction"; 
import Toast from "@/components/Reusable/Toast/Toast";

// ---- Mocks ----
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.mock("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");
  return {
    ...actual,
    useTheme: jest.fn(() => ({
      palette: { mode: "light" },
    })),
  };
});

jest.mock("antd/es/input/TextArea", () => {
  return function MockTextArea({
    value,
    onChange,
    placeholder,
    rows,
    className,
    style,
  }) {
    return (
      <textarea
        data-testid="description-textarea"
        rows={rows}
        value={value}
        placeholder={placeholder}
        className={className}
        style={style}
        onChange={onChange}
      />
    );
  };
});

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  HelpDeskAxios: jest.fn(),
  InventAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  FETCH_CNMS_ADDRESS_DETAILS: "/api/cnms/address",
  UPDATE_TICKET: "/api/ticket/update",
}));

jest.mock("@/components/Reusable/Toast/Toast", () => jest.fn());

jest.mock("@/assets/SVGIcons/question_mark.svg", () => "confirm-icon.svg");

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => {
  return function MockMButtonPrimary({ children, onClick, disabled }) {
    return (
      <button type="button" onClick={onClick} disabled={disabled}>
        {children}
      </button>
    );
  };
});

jest.mock("@/components/Reusable/Dialog/MDialog", () => {
  return function MockMDialog({
    open,
    title,
    message,
    onConfirm,
    onClose,
    isChildFullScreen,
  }) {
    if (!open) return null;
    return (
      <div
        role="dialog"
        aria-label={title}
        data-fullscreen={String(Boolean(isChildFullScreen))}
      >
        <p>{message}</p>
        <button type="button" onClick={onConfirm}>
          Confirm Action
        </button>
        <button type="button" onClick={onClose}>
          Close Dialog
        </button>
      </div>
    );
  };
});

describe("HandleCloseAction", () => {
  const onClose = jest.fn();
  const onSuccess = jest.fn();
  const onRefresh = jest.fn();

  const defaultState = {
    userSlice: {
      userDetails: {
        data: {
          userName: "john.doe",
        },
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    useSelector.mockImplementation((selectorFn) => selectorFn(defaultState));
    useTheme.mockReturnValue({ palette: { mode: "light" } });
    InventAxios.mockResolvedValue({ data: {} });
    HelpDeskAxios.mockResolvedValue({ status: 200 });
  });

  test("renders initial state with Confirm disabled and character counter at 0/255", () => {
    render(<HandleCloseAction id="T-101" onClose={onClose} />);

    expect(screen.getByText("Ticket Closed Statement *")).toBeInTheDocument();
    expect(screen.getByText("0/255")).toBeInTheDocument();

    const textarea = screen.getByTestId("description-textarea");
    expect(textarea).toHaveValue("");
    expect(textarea).toHaveAttribute("placeholder", "Enter comments...");

    expect(screen.getByRole("button", { name: "Confirm" })).toBeDisabled();
  });

  test("validates description: strips disallowed chars, enforces first 2 letters, caps at 255, and clears on empty", () => {
    render(<HandleCloseAction id="T-101" />);
    const textarea = screen.getByTestId("description-textarea");

    // Single non-letter -> length < 2 -> "First 2 characters must be text (letters)"
    fireEvent.change(textarea, { target: { value: "1" } });
    expect(textarea).toHaveValue("");
    expect(screen.getByText("0/255")).toBeInTheDocument();

    // Single letter -> length 1 (< 2)
    fireEvent.change(textarea, { target: { value: "a" } });
    expect(textarea).toHaveValue("a");
    expect(
      screen.getByText("First 2 characters must be text (letters)")
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Confirm" })).toBeDisabled();

    // 2 chars where second is not a letter -> "Must start with 2 letters"
    fireEvent.change(textarea, { target: { value: "a1" } });
    expect(textarea).toHaveValue("a1");
    expect(screen.getByText("Must start with 2 letters")).toBeInTheDocument();

    // Valid start + allowed punctuation (., _, -, space, comma) + disallowed chars ($@#)
    fireEvent.change(textarea, {
      target: { value: "Resolved_issue-1.0, ok$@#!" },
    });
    expect(textarea).toHaveValue("Resolved_issue-1.0, ok!");
    expect(screen.queryByText(/Must start with 2 letters/i)).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Confirm" })).toBeEnabled();

    // Exceeds 255 characters -> sliced to 255
    const over255 = "Ab" + "x".repeat(260);
    fireEvent.change(textarea, { target: { value: over255 } });
    expect(textarea.value).toHaveLength(255);
    expect(screen.getByText("255/255")).toBeInTheDocument();

    // Clearing text resets error and counter to 0/255
    fireEvent.change(textarea, { target: { value: "" } });
    expect(textarea).toHaveValue("");
    expect(screen.getByText("0/255")).toBeInTheDocument();
  });

  test("applies dark theme styles and passes isChildFullScreen to dialog", () => {
    useTheme.mockReturnValue({ palette: { mode: "dark" } });

    render(
      <HandleCloseAction
        id="T-102"
        actionType="REOPEN"
        isChildFullScreen={true}
      />
    );

    const textarea = screen.getByTestId("description-textarea");
    expect(textarea).toHaveClass("dark-ant-textarea");
    expect(textarea.style.background).toBe("rgb(51, 51, 51)");
    expect(textarea.style.color).toBe("rgb(255, 255, 255)");

    fireEvent.change(textarea, { target: { value: "Reopening ticket now" } });
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));

    const dialog = screen.getByRole("dialog", { name: "Confirm Action" });
    expect(dialog).toHaveAttribute("data-fullscreen", "true");
    expect(
      screen.getByText("Are you sure you want to proceed with reopen?")
    ).toBeInTheDocument();

    // Close dialog via cancel/close handler
    fireEvent.click(screen.getByRole("button", { name: "Close Dialog" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  test("submits CLOSE action with subDetail sequenceNum/loggedinUser and host without port", async () => {
    InventAxios.mockResolvedValueOnce({
      data: { address: "10.0.0.50" },
    });
    HelpDeskAxios.mockResolvedValueOnce({ status: 201 });

    const ticketData = {
      hdTicketSubDetails: [
        { sequenceNum: 1, loggedinUser: "first.user" },
        { sequenceNum: 4, loggedinUser: "last.agent" },
      ],
    };

    render(
      <HandleCloseAction
        id="999"
        actionType="CLOSE"
        ticketData={ticketData}
        onClose={onClose}
        onSuccess={onSuccess}
        onRefresh={onRefresh}
      />
    );

    const textarea = screen.getByTestId("description-textarea");
    fireEvent.change(textarea, { target: { value: "Fixed network loop" } });
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Action" }));

    await waitFor(() => {
      expect(InventAxios).toHaveBeenCalledWith("/api/cnms/address", "get");
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        {
          hdTicketStatus: { id: "5" },
          hdTicketDetail: { id: "999" },
          sequenceNum: 4,
          statement: "Fixed network loop",
          loggedinUser: "last.agent",
        },
        null,
        expect.stringMatching(/^10\.0\.0\.50:(9012|8786)$/)
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket closed successfully!",
      "success"
    );
    expect(onRefresh).toHaveBeenCalledTimes(1);
    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("submits REOPEN action with address already containing port and fallback userName", async () => {
    InventAxios.mockResolvedValueOnce({
      data: { address: "cnms.internal:9443" },
    });
    HelpDeskAxios.mockResolvedValueOnce({ status: 200 });

    render(
      <HandleCloseAction
        id="500"
        actionType="REOPEN"
        ticketData={{ hdTicketSubDetails: [] }}
        onClose={onClose}
        onSuccess={onSuccess}
      />
    );

    fireEvent.change(screen.getByTestId("description-textarea"), {
      target: { value: "Issue recurred on site" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Action" }));

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        {
          hdTicketStatus: { id: "6" },
          hdTicketDetail: { id: "500" },
          sequenceNum: 1,
          statement: "Issue recurred on site",
          loggedinUser: "john.doe",
        },
        null,
        "cnms.internal:9443"
      );
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket closed successfully!",
      "success"
    );
    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("falls back to 'system' loggedinUser when userName is empty and handles non-200/201 response", async () => {
    useSelector.mockImplementation((selectorFn) =>
      selectorFn({
        userSlice: { userDetails: { data: { userName: "" } } },
      })
    );
    HelpDeskAxios.mockResolvedValueOnce({ status: 500 });

    render(<HandleCloseAction id="777" onClose={onClose} onSuccess={onSuccess} />);

    fireEvent.change(screen.getByTestId("description-textarea"), {
      target: { value: "Closing via fallback user" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Action" }));

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        expect.objectContaining({
          loggedinUser: "system",
        }),
        null,
        null
      );
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Failed to update",
        "error"
      );
    });

    expect(onSuccess).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });

  test("handles API rejection cleanly without crashing", async () => {
    const consoleSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    InventAxios.mockRejectedValueOnce({
      response: { data: { message: "Address lookup failed" } },
    });

    render(<HandleCloseAction id="888" onClose={onClose} onSuccess={onSuccess} />);

    fireEvent.change(screen.getByTestId("description-textarea"), {
      target: { value: "Triggering error branch" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Action" }));

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalledWith(
        "API Error:",
        { message: "Address lookup failed" }
      );
    });

    expect(onSuccess).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
    consoleSpy.mockRestore();
  });

  test("alerts and returns early when id is missing", () => {
    const alertSpy = jest.spyOn(window, "alert").mockImplementation(() => {});

    render(<HandleCloseAction onClose={onClose} />);

    fireEvent.change(screen.getByTestId("description-textarea"), {
      target: { value: "Valid comment without id" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Action" }));

    expect(alertSpy).toHaveBeenCalledWith("Error: Missing Ticket ID");
    expect(HelpDeskAxios).not.toHaveBeenCalled();
    expect(InventAxios).not.toHaveBeenCalled();
    alertSpy.mockRestore();
  });
});
