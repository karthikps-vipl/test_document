
import React from "react";
import { render, screen, waitFor, act } from "@testing-library/react";
import "@testing-library/jest-dom";



import { useDispatch, useSelector } from "react-redux";
import { useTheme } from "@mui/material";

import { PortStatusBoard } from "@/Pages/Rnmsdashboard/PortStatus/PortStatusBoard";
import LegendStatus from "@/Pages/Rnmsdashboard/PortStatus/LegendStatus";

import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import { setAvailableResources } from "@/store/features/PortStatus/portStatusSlice";

import { filterSwitchPorts } from "@/utility/portFilterUtils";
import { mapOpStatus } from "@/Pages/Rnmsdashboard/Topology/topologyConstants";
import PortStatus from "@/Pages/Rnmsdashboard/PortStatus";

// --------------------------------------------------
// MOCKS
// --------------------------------------------------

jest.mock("react-redux", () => ({
  useDispatch: jest.fn(),
  useSelector: jest.fn(),
}));

jest.mock("@mui/material", () => ({
  ...jest.requireActual("@mui/material"),
  useTheme: jest.fn(),
}));

jest.mock("@/Pages/Rnmsdashboard/PortStatus/PortStatusBoard", () => ({
  PortStatusBoard: jest.fn(() => (
    <div data-testid="port-status-board">
      Port Status Board
    </div>
  )),
}));

jest.mock("@/Pages/Rnmsdashboard/PortStatus/LegendStatus", () => ({
  __esModule: true,
  default: jest.fn(() => (
    <div data-testid="legend-status">
      Legend Status
    </div>
  )),
}));

jest.mock(
  "@/components/Reusable/Scrollbar/ScrollContainer",
  () => ({
    __esModule: true,
    default: ({ children, className, style }) => (
      <div className={className} style={style}>
        {children}
      </div>
    ),
  })
);

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  PORT_RESOURCE_DETAILS: "/resource-details",
}));

jest.mock("@/store/features/PortStatus/portStatusSlice", () => ({
  setAvailableResources: jest.fn((data) => ({
    type: "portStatus/setAvailableResources",
    payload: data,
  })),
}));

jest.mock("@/utility/portFilterUtils", () => ({
  filterSwitchPorts: jest.fn(),
}));

jest.mock("@/Pages/Rnmsdashboard/Topology/topologyConstants", () => ({
  mapOpStatus: jest.fn((opstatus, adminstatus) => {
    return `${opstatus}-${adminstatus}`;
  }),
}));

// --------------------------------------------------
// TEST DATA
// --------------------------------------------------

const mockDispatch = jest.fn();

const mockTheme = {
  palette: {
    mode: "light",
  },
};

const mockPort = {
  ifindex: 1,
  ifdesc: "GigabitEthernet1/0/1",
  ifportname: "GigabitEthernet1/0/1",
  iftype: "Ethernet",
  opstatus: 1,
  adminstatus: 1,
};

const mockDevice = {
  resourceId: "DEVICE001",
  resourceName: "Switch 001",
  imSegmentInfo: {
    segmentName: "Bangalore",
  },
  lstPortInfoDtl: [
    mockPort,
    {
      ifindex: 2,
      ifdesc: "GigabitEthernet1/0/2",
      ifportname: "GigabitEthernet1/0/2",
      iftype: "Ethernet",
      opstatus: 2,
      adminstatus: 1,
    },
    {
      ifindex: 3,
      ifdesc: "TenGigabitEthernet1/0/3",
      ifportname: "TenGigabitEthernet1/0/3",
      iftype: "Ethernet",
      opstatus: 1,
      adminstatus: 1,
    },
  ],
};

let mockReduxState;

// --------------------------------------------------
// TEST SUITE
// --------------------------------------------------

describe("PortStatus Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockReduxState = {
      portStatusSlice: {
        availableResources: [mockDevice],
      },
    };

    useDispatch.mockReturnValue(mockDispatch);

    useSelector.mockImplementation((selector) =>
      selector(mockReduxState)
    );

    useTheme.mockReturnValue(mockTheme);

    InventoryAxios.mockResolvedValue({
      data: [mockDevice],
    });

    filterSwitchPorts.mockImplementation((value) => {
      if (typeof value === "string") {
        return false;
      }

      return value || [];
    });

    mapOpStatus.mockImplementation((opstatus, adminstatus) => {
      return `${opstatus}-${adminstatus}`;
    });
  });

  // 1. Basic rendering
  test("should render PortStatus component successfully", () => {
    render(<PortStatus />);

    expect(screen.getByTestId("port-status-board")).toBeInTheDocument();
  });

  // 2. API call on mount
  test("should call InventoryAxios on component mount", async () => {
    render(<PortStatus />);

    await waitFor(() => {
      expect(InventoryAxios).toHaveBeenCalledWith(
        "/resource-details",
        "get"
      );
    });

    expect(InventoryAxios).toHaveBeenCalledTimes(1);
  });

  // 3. API success
  test("should dispatch available resources after successful API response", async () => {
    render(<PortStatus />);

    await waitFor(() => {
      expect(setAvailableResources).toHaveBeenCalledWith([
        mockDevice,
      ]);
    });

    expect(mockDispatch).toHaveBeenCalledWith({
      type: "portStatus/setAvailableResources",
      payload: [mockDevice],
    });
  });

  // 4. API failure
  test("should handle API failure without crashing", async () => {
    const consoleError = jest
      .spyOn(console, "error")
      .mockImplementation(() => {});

    InventoryAxios.mockRejectedValueOnce(
      new Error("API failed")
    );

    render(<PortStatus />);

    await waitFor(() => {
      expect(consoleError).toHaveBeenCalledWith(
        "Error fetching resource details:",
        expect.any(Error)
      );
    });

    expect(screen.getByTestId("port-status-board")).toBeInTheDocument();

    consoleError.mockRestore();
  });

  // 5. Empty available resources
  test("should display no devices available when resources are empty", () => {
    mockReduxState.portStatusSlice.availableResources = [];

    render(<PortStatus />);

    expect(
      screen.getByText("No devices available")
    ).toBeInTheDocument();

    expect(
      screen.queryByTestId("port-status-board")
    ).not.toBeInTheDocument();

    expect(
      screen.queryByTestId("legend-status")
    ).not.toBeInTheDocument();
  });

  // 6. Null available resources
  test("should display no devices when availableResources is null", () => {
    mockReduxState.portStatusSlice.availableResources = null;

    render(<PortStatus />);

    expect(
      screen.getByText("No devices available")
    ).toBeInTheDocument();
  });

  // 7. Render LegendStatus
  test("should render LegendStatus when devices are available", () => {
    render(<PortStatus />);

    expect(screen.getByTestId("legend-status")).toBeInTheDocument();
  });

  // 8. Render PortStatusBoard
  test("should render PortStatusBoard when transformed devices exist", () => {
    render(<PortStatus />);

    expect(
      screen.getByTestId("port-status-board")
    ).toBeInTheDocument();
  });

  // 9. Transform device details
  test("should transform device information correctly", () => {
    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0]).toMatchObject({
      id: "DEVICE001",
      title: "Switch 001",
      site: "Bangalore",
    });
  });

  // 10. Sort ports by ifindex
  test("should sort ports numerically by ifindex", () => {
    const unsortedDevice = {
      ...mockDevice,
      lstPortInfoDtl: [
        { ...mockPort, ifindex: 10 },
        { ...mockPort, ifindex: 2 },
        { ...mockPort, ifindex: 1 },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [
      unsortedDevice,
    ];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports.map((port) => port.ifindex)).toEqual([
      1, 2, 10,
    ]);
  });

  // 11. Filter ports
  test("should apply filterSwitchPorts when resource requires filtering", () => {
    filterSwitchPorts.mockImplementation((value) => {
      if (typeof value === "string") {
        return true;
      }

      return value.filter((port) => port.ifindex !== 2);
    });

    render(<PortStatus />);

    expect(filterSwitchPorts).toHaveBeenCalledWith("DEVICE001");

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports.map((port) => port.ifindex)).toEqual([
      1, 3,
    ]);
  });

  // 12. Ignore ports without ifindex
  test("should remove ports without ifindex", () => {
    const device = {
      ...mockDevice,
      lstPortInfoDtl: [
        { ...mockPort, ifindex: 1 },
        { ...mockPort, ifindex: null },
        { ...mockPort, ifindex: undefined },
        { ...mockPort, ifindex: 3 },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports).toHaveLength(2);

    expect(devices[0].ports.map((port) => port.ifindex)).toEqual([
      1, 3,
    ]);
  });

  // 13. TenGigabit detection using ifdesc
  test("should identify TenGigabit ports using ifdesc", () => {
    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    const tenGigabitPort = devices[0].ports.find(
      (port) => port.ifindex === 3
    );

    expect(tenGigabitPort.isTenGigabit).toBe(true);
  });

  // 14. TenGigabit detection using ifportname
  test("should identify TenGigabit ports using ifportname", () => {
    const device = {
      ...mockDevice,
      lstPortInfoDtl: [
        {
          ...mockPort,
          ifdesc: "Port 1",
          ifportname: "TenGigabitEthernet1/0/1",
        },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].isTenGigabit).toBe(true);
  });

  // 15. TenGigabit detection using iftype
  test("should identify TenGigabit ports using iftype", () => {
    const device = {
      ...mockDevice,
      lstPortInfoDtl: [
        {
          ...mockPort,
          ifdesc: "Port 1",
          ifportname: "Port 1",
          iftype: "TenGigabitEthernet",
        },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].isTenGigabit).toBe(true);
  });

  // 16. Case insensitive TenGigabit detection
  test("should detect TenGigabit ports regardless of letter case", () => {
    const device = {
      ...mockDevice,
      lstPortInfoDtl: [
        {
          ...mockPort,
          ifdesc: "tengigabitethernet1/0/1",
        },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].isTenGigabit).toBe(true);
  });

  // 17. Normal port detection
  test("should identify normal ports as non-TenGigabit", () => {
    const device = {
      ...mockDevice,
      lstPortInfoDtl: [
        {
          ...mockPort,
          ifdesc: "GigabitEthernet1/0/1",
          ifportname: "GigabitEthernet1/0/1",
          iftype: "Ethernet",
        },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].isTenGigabit).toBe(false);
  });

  // 18. Status mapping
  test("should map operational and administrative status correctly", () => {
    render(<PortStatus />);

    expect(mapOpStatus).toHaveBeenCalledWith(1, 1);
    expect(mapOpStatus).toHaveBeenCalledWith(2, 1);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].status).toBe("1-1");
    expect(devices[0].ports[1].status).toBe("2-1");
  });

  // 19. Port ID generation
  test("should generate unique port IDs using resourceId and ifindex", () => {
    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].id).toBe("DEVICE001-1");
    expect(devices[0].ports[1].id).toBe("DEVICE001-2");
  });

  // 20. Port name mapping
  test("should map ifdesc as port name", () => {
    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].name).toBe(
      "GigabitEthernet1/0/1"
    );
  });

  // 21. Visual index generation
  test("should assign sequential visualIndex values after sorting", () => {
    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports.map((port) => port.visualIndex)).toEqual([
      1, 2, 3,
    ]);
  });

  // 22. Trim port description
  test("should handle whitespace in port descriptions", () => {
    const device = {
      ...mockDevice,
      lstPortInfoDtl: [
        {
          ...mockPort,
          ifdesc: "  GigabitEthernet1/0/1  ",
          ifportname: "  GigabitEthernet1/0/1  ",
        },
      ],
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports[0].isTenGigabit).toBe(false);
  });

  // 23. Missing segment information
  test("should use Unknown Site when segment information is missing", () => {
    const device = {
      ...mockDevice,
      imSegmentInfo: null,
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].site).toBe("Unknown Site");
  });

  // 24. Missing port list
  test("should handle missing lstPortInfoDtl", () => {
    const device = {
      resourceId: "DEVICE002",
      resourceName: "Switch 002",
      imSegmentInfo: null,
    };

    mockReduxState.portStatusSlice.availableResources = [device];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices[0].ports).toEqual([]);
  });

  // 25. Light theme
  test("should apply light theme background color", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(<PortStatus />);

    expect(container.querySelector(".app-shell")).toHaveStyle({
      backgroundColor: "#ffffff",
    });
  });

  // 26. Dark theme
  test("should apply dark theme background color", () => {
    useTheme.mockReturnValue({
      palette: { mode: "dark" },
    });

    const { container } = render(<PortStatus />);

    expect(container.querySelector(".app-shell")).toHaveStyle({
      backgroundColor: "#3e3e3e",
    });
  });

  // 27. Dark theme empty state
  test("should display white text in dark theme when no devices exist", () => {
    mockReduxState.portStatusSlice.availableResources = [];

    useTheme.mockReturnValue({
      palette: { mode: "dark" },
    });

    render(<PortStatus />);

    expect(
      screen.getByText("No devices available")
    ).toHaveStyle({
      color: "#fff",
    });
  });

  // 28. Light theme empty state
  test("should display black text in light theme when no devices exist", () => {
    mockReduxState.portStatusSlice.availableResources = [];

    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    render(<PortStatus />);

    expect(
      screen.getByText("No devices available")
    ).toHaveStyle({
      color: "#000",
    });
  });

  // 29. Multiple devices
  test("should transform multiple devices correctly", () => {
    const secondDevice = {
      ...mockDevice,
      resourceId: "DEVICE002",
      resourceName: "Switch 002",
    };

    mockReduxState.portStatusSlice.availableResources = [
      mockDevice,
      secondDevice,
    ];

    render(<PortStatus />);

    const { devices } = PortStatusBoard.mock.calls[0][0];

    expect(devices).toHaveLength(2);
    expect(devices[0].id).toBe("DEVICE001");
    expect(devices[1].id).toBe("DEVICE002");
  });

  // 30. Scroll container
  test("should render content inside ScrollContainer", () => {
    const { container } = render(<PortStatus />);

    expect(container.querySelector(".h-full")).toBeInTheDocument();
  });
});