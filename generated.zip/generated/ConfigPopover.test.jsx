import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";

import { ConfigPopover } from "../../src/Pages/CnmsDashboard/CnmsMap/components/ConfigPopover";

const mockToast = jest.fn();

jest.mock("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: (...args) => mockToast(...args),
}));

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => {
  return function MockButton({ children, onClick, ...props }) {
    return (
      <button onClick={onClick} {...props}>
        {children}
      </button>
    );
  };
});

jest.mock("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");

  return {
    ...actual,

    Popover: ({ open, children, onClose }) =>
      open ? (
        <div data-testid="popover">
          {children}
          <button data-testid="popover-close" onClick={onClose}>
            Close Popover
          </button>
        </div>
      ) : null,
  };
});

describe("ConfigPopover Component", () => {
  let availableParams;
  let onClose;
  let onSave;
  let anchorEl;

  beforeEach(() => {
    jest.clearAllMocks();

    anchorEl = document.createElement("div");

    availableParams = [
      { key: "id", label: "ID", checked: true },
      { key: "name", label: "Name", checked: true },
      { key: "status", label: "Status", checked: false },
    ];

    onClose = jest.fn();
    onSave = jest.fn();
  });

  const renderComponent = (props = {}) =>
    render(
      <ConfigPopover
        anchorEl={anchorEl}
        onClose={onClose}
        availableParams={availableParams}
        onSave={onSave}
        {...props}
      />
    );

  test("does not render popover when anchorEl is null", () => {
    renderComponent({ anchorEl: null });

    expect(screen.queryByTestId("popover")).not.toBeInTheDocument();
  });

  test("renders popover when anchorEl is available", async () => {
    renderComponent();

    expect(screen.getByTestId("popover")).toBeInTheDocument();

    expect(screen.getByText("Configure Parameters")).toBeInTheDocument();

    expect(screen.getByText("Select All")).toBeInTheDocument();
  });

  test("renders all available parameters", () => {
    renderComponent();

    expect(screen.getByText("ID")).toBeInTheDocument();
    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("Status")).toBeInTheDocument();
  });

  test("initializes draft parameters when popover opens", async () => {
    renderComponent();

    await waitFor(() => {
      expect(screen.getByLabelText("ID")).toBeChecked();
      expect(screen.getByLabelText("Name")).toBeChecked();
      expect(screen.getByLabelText("Status")).not.toBeChecked();
    });
  });

  test("toggles an individual parameter", () => {
    renderComponent();

    const idCheckbox = screen.getByLabelText("ID");

    fireEvent.click(idCheckbox);

    expect(idCheckbox).not.toBeChecked();
  });

  test("selects all parameters", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("Select All"));

    expect(screen.getByLabelText("ID")).toBeChecked();
    expect(screen.getByLabelText("Name")).toBeChecked();
    expect(screen.getByLabelText("Status")).toBeChecked();
  });

  test("deselects all parameters when all are selected", () => {
    availableParams = availableParams.map((param) => ({
      ...param,
      checked: true,
    }));

    renderComponent();

    fireEvent.click(screen.getByLabelText("Select All"));

    expect(screen.getByLabelText("ID")).not.toBeChecked();
    expect(screen.getByLabelText("Name")).not.toBeChecked();
    expect(screen.getByLabelText("Status")).not.toBeChecked();
  });

  test("updates Select All state when all individual parameters become checked", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("Status"));

    expect(screen.getByLabelText("Select All")).toBeChecked();
  });

  test("saves selected parameters and closes popover", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("Status"));

    fireEvent.click(screen.getByText("Save"));

    expect(onSave).toHaveBeenCalledWith([
      { key: "id", label: "ID", checked: true },
      { key: "name", label: "Name", checked: true },
      { key: "status", label: "Status", checked: true },
    ]);

    expect(onClose).toHaveBeenCalledTimes(1);

    expect(mockToast).toHaveBeenCalledWith(
      "",
      "Selected parameters saved",
      "success"
    );
  });

  test("closes popover without saving changes", () => {
    renderComponent();

    fireEvent.click(screen.getByLabelText("ID"));

    fireEvent.click(screen.getByTestId("popover-close"));

    expect(onClose).toHaveBeenCalledTimes(1);
    expect(onSave).not.toHaveBeenCalled();
    expect(mockToast).not.toHaveBeenCalled();
  });

  test("closes popover using close icon", () => {
    renderComponent();

    fireEvent.click(screen.getByRole("button", { name: "" }));

    expect(onClose).toHaveBeenCalled();
    expect(onSave).not.toHaveBeenCalled();
  });

  test("handles empty availableParams", () => {
    renderComponent({ availableParams: [] });

    expect(screen.getByText("Configure Parameters")).toBeInTheDocument();
    expect(screen.getByText("Select All")).toBeInTheDocument();
  });

  test("Select All remains unchecked when parameter list is empty", () => {
    renderComponent({ availableParams: [] });

    expect(screen.getByLabelText("Select All")).not.toBeChecked();
  });

  test("updates draft parameters when availableParams changes while open", async () => {
    const { rerender } = renderComponent();

    const updatedParams = [
      { key: "longitude", label: "Longitude", checked: true },
      { key: "latitude", label: "Latitude", checked: false },
    ];

    rerender(
      <ConfigPopover
        anchorEl={anchorEl}
        onClose={onClose}
        availableParams={updatedParams}
        onSave={onSave}
      />
    );

    await waitFor(() => {
      expect(screen.getByLabelText("Longitude")).toBeChecked();
      expect(screen.getByLabelText("Latitude")).not.toBeChecked();
    });
  });

  test("resets draft when popover closes", () => {
    const { rerender } = renderComponent();

    fireEvent.click(screen.getByLabelText("ID"));

    rerender(
      <ConfigPopover
        anchorEl={null}
        onClose={onClose}
        availableParams={availableParams}
        onSave={onSave}
      />
    );

    expect(screen.queryByTestId("popover")).not.toBeInTheDocument();
    expect(onSave).not.toHaveBeenCalled();
  });
});
