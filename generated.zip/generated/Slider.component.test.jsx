import React from "react";
import { jest } from "@jest/globals";
import { fireEvent, render, screen } from "@testing-library/react";

jest.unstable_mockModule("@mui/material", async () => {
  const actual = await jest.requireActual("@mui/material");
  const ReactModule = React;

  return {
    ...actual,
    Slide: ({ direction, in: isOpen, children, mountOnEnter, unmountOnExit }) => {
      if (!isOpen && unmountOnExit) return null;

      return ReactModule.createElement(
        "div",
        {
          "data-testid": "slide-transition",
          "data-direction": direction,
          "data-open": String(isOpen),
          "data-mount-on-enter": String(mountOnEnter),
          "data-unmount-on-exit": String(unmountOnExit),
        },
        children
      );
    },
  };
});

jest.unstable_mockModule("lucide-react", () => ({
  Fullscreen: () => React.createElement("span", { "data-testid": "fullscreen-icon" }),
}));

jest.unstable_mockModule("@mui/icons-material", () => ({
  Close: () => React.createElement("span", { "data-testid": "close-icon" }),
  FullscreenExit: () =>
    React.createElement("span", { "data-testid": "fullscreen-exit-icon" }),
}));

const { default: Slider } = await import(
  "../../src/components/Reusable/Slider/Slider"
);

describe("Slider", () => {
  test("renders the Reports panel and its children when open", () => {
    render(
      <Slider open direction="left" onClose={jest.fn()}>
        <div>Report content</div>
      </Slider>
    );

    expect(screen.getByText("Reports")).toBeInTheDocument();
    expect(screen.getByText("Report content")).toBeInTheDocument();
  });

  test("passes the direction and transition lifecycle props to MUI Slide", () => {
    render(
      <Slider open direction="right" onClose={jest.fn()}>
        <div>Content</div>
      </Slider>
    );

    const transition = screen.getByTestId("slide-transition");
    expect(transition).toHaveAttribute("data-direction", "right");
    expect(transition).toHaveAttribute("data-open", "true");
    expect(transition).toHaveAttribute("data-mount-on-enter", "true");
    expect(transition).toHaveAttribute("data-unmount-on-exit", "true");
  });

  test("does not render the panel while closed with unmountOnExit enabled", () => {
    render(
      <Slider open={false} direction="left" onClose={jest.fn()}>
        <div>Hidden report content</div>
      </Slider>
    );

    expect(screen.queryByTestId("slide-transition")).not.toBeInTheDocument();
    expect(screen.queryByText("Reports")).not.toBeInTheDocument();
    expect(screen.queryByText("Hidden report content")).not.toBeInTheDocument();
  });

  test("renders all three action buttons", () => {
    const { container } = render(
      <Slider open direction="left" onClose={jest.fn()}>
        <div>Content</div>
      </Slider>
    );

    expect(container.querySelectorAll("button")).toHaveLength(3);
    expect(screen.getByAltText("Close")).toBeInTheDocument();
    expect(screen.getByTestId("fullscreen-icon")).toBeInTheDocument();
    expect(screen.getByTestId("close-icon")).toBeInTheDocument();
  });

  test("calls onClose when the header image close button is clicked", () => {
    const onClose = jest.fn();
    const { container } = render(
      <Slider open direction="left" onClose={onClose}>
        <div>Content</div>
      </Slider>
    );

    fireEvent.click(screen.getByAltText("Close").closest("button"));

    expect(onClose).toHaveBeenCalledTimes(1);
    expect(container.querySelectorAll("button")).toHaveLength(3);
  });

  test("calls onClose when the close icon button is clicked", () => {
    const onClose = jest.fn();
    render(
      <Slider open direction="left" onClose={onClose}>
        <div>Content</div>
      </Slider>
    );

    fireEvent.click(screen.getByTestId("close-icon").closest("button"));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("switches to fullscreen mode when the fullscreen button is clicked", () => {
    const { container } = render(
      <Slider open direction="left" onClose={jest.fn()}>
        <div>Content</div>
      </Slider>
    );

    expect(screen.getByTestId("fullscreen-icon")).toBeInTheDocument();
    expect(screen.queryByTestId("fullscreen-exit-icon")).not.toBeInTheDocument();

    fireEvent.click(container.querySelectorAll("button")[1]);

    expect(screen.getByTestId("fullscreen-exit-icon")).toBeInTheDocument();
    expect(screen.queryByTestId("fullscreen-icon")).not.toBeInTheDocument();
  });

  test("toggles back from fullscreen mode when clicked again", () => {
    const { container } = render(
      <Slider open direction="left" onClose={jest.fn()}>
        <div>Content</div>
      </Slider>
    );

    const fullscreenButton = container.querySelectorAll("button")[1];

    fireEvent.click(fullscreenButton);
    expect(screen.getByTestId("fullscreen-exit-icon")).toBeInTheDocument();

    fireEvent.click(fullscreenButton);
    expect(screen.getByTestId("fullscreen-icon")).toBeInTheDocument();
    expect(screen.queryByTestId("fullscreen-exit-icon")).not.toBeInTheDocument();
  });

  test("renders the supplied children without requiring an onClose callback", () => {
    render(
      <Slider open direction="up">
        <p>Custom report body</p>
      </Slider>
    );

    expect(screen.getByText("Custom report body")).toBeInTheDocument();
  });
});
