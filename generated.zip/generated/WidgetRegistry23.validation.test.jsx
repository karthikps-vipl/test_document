import React from 'react';

jest.mock('@/components/Reusable/Input/MInput', () => () => null);
jest.mock('@/components/Reusable/Select/MAlarmSelect', () => () => null);
jest.mock('@/components/Reusable/Texarea/MTextArea', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/VerticalTable/VerticalTableWidget', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/fan/FanWidget', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/gauge/GaugeWidget', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/PowerSupply/PowerSupplyWidget', () => ({ PowerSupplyWidget: () => null }));
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/Voltage/VoltageGaugeWidget', () => ({ VoltageGaugeWidget: () => null }));
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/title/TitleWidget', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/remoteDevice/RemoteDevice', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/image/ImageWidget', () => () => null);
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/dgSet/CircularDialGauge', () => () => null);

import { validateFieldValue, WIDGET_REGISTRY, AVAILABLE_WIDGETS } from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23';

describe('WidgetRegistry23 validation', () => {
  test('rejects empty required values', () => {
    expect(validateFieldValue('', {})).toBe('This field is required');
    expect(validateFieldValue(null, {})).toBe('This field is required');
    expect(validateFieldValue('   ', {})).toBe('This field is required');
  });

  test('accepts valid numeric values within min and max bounds', () => {
    expect(validateFieldValue('5', { inpType: 'number', min: 1, max: 10 })).toBe('');
    expect(validateFieldValue('0.5', { inpType: 'number', min: 0, max: 2, step: 0.5 })).toBe('');
  });

  test('rejects invalid number formats', () => {
    expect(validateFieldValue('abc', { inpType: 'number' })).toBe('Please enter a valid number');
    expect(validateFieldValue('1.5', { inpType: 'number', step: 1 })).toBe('Please enter a valid number');
  });

  test('enforces numeric minimum and maximum', () => {
    expect(validateFieldValue('2', { inpType: 'number', min: 3 })).toBe('Value must be at least 3');
    expect(validateFieldValue('11', { inpType: 'number', max: 10 })).toBe('Value must not exceed 10');
  });

  test('enforces numeric step increments relative to minimum', () => {
    expect(validateFieldValue('1.2', { inpType: 'number', min: 1, step: 0.5 })).toBe('Value must increase in steps of 0.5');
    expect(validateFieldValue('2', { inpType: 'number', min: 1, step: 0.5 })).toBe('');
  });

  test('validates string and regular-expression patterns', () => {
    expect(validateFieldValue('ABC123', { regex: '^[A-Z]+\\d+$' })).toBe('');
    expect(validateFieldValue('abc', { regex: /^[A-Z]+$/ })).toBe('Invalid format');
  });

  test('returns a validation configuration error for malformed regex', () => {
    expect(validateFieldValue('value', { regex: '[' })).toBe('Invalid validation configuration');
  });

  test('exposes a non-empty widget registry and matching available-widget list', () => {
    expect(Object.keys(WIDGET_REGISTRY).length).toBeGreaterThan(0);
    expect(AVAILABLE_WIDGETS).toHaveLength(Object.keys(WIDGET_REGISTRY).length);
  });
});
