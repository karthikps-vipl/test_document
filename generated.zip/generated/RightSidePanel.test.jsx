
import React from "react";
import { render, screen, fireEvent, cleanup } from "@testing-library/react";
import "@testing-library/jest-dom";
import RightSidePanel from "@/Pages/CnmsDashboard/BirdEyeView/RightSidePanel";


// Mock SVG imports
jest.mock(
  "../../../assets/CNMS/birdEyeViewLegend/vehicle.svg",
  () => "vehicle.svg"
);
jest.mock(
  "../../../assets/CNMS/birdEyeViewLegend/E1OFC.svg",
  () => "E1OFC.svg"
);
jest.mock(
  "../../../assets/CNMS/birdEyeViewLegend/NOTCONFIGURE.svg",
  () => "NOTCONFIGURE.svg"
);
jest.mock(
  "../../../assets/CNMS/birdEyeViewLegend/radio.svg",
  () => "radio.svg"
);
jest.mock(
  "../../../assets/CNMS/birdEyeViewLegend/VSat.svg",
  () => "VSat.svg"
);

// Mock fullscreen component
jest.mock(
  "@/components/Reusable/FullScreen/CustomeFullscreen",
  () => ({
    CustomeFullscreen: ({ onClose }) => (
      <button onClick={onClose}>Fullscreen Close</button>
    ),
  })
);

afterEach(() => {
  cleanup();
  document.body.innerHTML = "";
});

const mockSite = {
  siteId: "SITE001",
  siteName: "Bangalore Site",
  remoteNumber: 123,
  latitude: 12.9716,
  longitude: 77.5946,
  activeModeOfCommunication: 1,
  healthStatus: { id: 1 },
  imTerminalMode: { name: "LOCAL" },
};

const mockStatusColors = {
  Online: "green",
  Offline: "red",
  "RNMS Down": "orange",
  "Maintenance Non-OPS": "yellow",
  "Maintenance R-OPS": "blue",
};

const renderComponent = (props = {}) => {
  return render(
    <RightSidePanel
      selectedPath="CNMS"
      selectedNode={null}
      allSites={[]}
      statusColors={mockStatusColors}
      onClose={jest.fn()}
      {...props}
    />
  );
};

describe("RightSidePanel Component", () => {
  // 1. Basic rendering
  test("should render component successfully", () => {
    renderComponent();

    expect(screen.getByText("CNMS")).toBeInTheDocument();
    expect(
      screen.getByPlaceholderText("Search Here")
    ).toBeInTheDocument();
  });

  // 2. Root node rendering
  test("should render LOCAL sites in root node", () => {
    renderComponent({
      allSites: [
        mockSite,
        {
          ...mockSite,
          siteId: "SITE002",
          siteName: "Remote Site",
          imTerminalMode: { name: "REMOTE" },
        },
      ],
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
    expect(screen.queryByText("SITE002")).not.toBeInTheDocument();
  });

  // 3. Site count
  test("should display total site count in root node", () => {
    renderComponent({
      allSites: [
        mockSite,
        { ...mockSite, siteId: "SITE002" },
      ],
    });

    expect(screen.getByText("2 Total Site(s)")).toBeInTheDocument();
  });

  // 4. Search root sites
  test("should filter root sites based on site ID", () => {
    renderComponent({
      allSites: [
        mockSite,
        { ...mockSite, siteId: "SITE002", siteName: "Chennai" },
      ],
    });

    fireEvent.change(screen.getByPlaceholderText("Search Here"), {
      target: { value: "SITE001" },
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
    expect(screen.queryByText("SITE002")).not.toBeInTheDocument();
  });

  // 5. Search using site name
  test("should filter root sites using site name", () => {
    renderComponent({
      allSites: [
        mockSite,
        { ...mockSite, siteId: "SITE002", siteName: "Chennai" },
      ],
    });

    fireEvent.change(screen.getByPlaceholderText("Search Here"), {
      target: { value: "bangalore" },
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
    expect(screen.queryByText("SITE002")).not.toBeInTheDocument();
  });

  // 6. Search highlighting
  test("should highlight matching search text", () => {
    renderComponent({
      allSites: [mockSite],
    });

    fireEvent.change(screen.getByPlaceholderText("Search Here"), {
      target: { value: "SITE" },
    });

    expect(screen.getByText("SITE")).toBeInTheDocument();
    expect(screen.getByText("SITE").tagName).toBe("MARK");
  });

  // 7. Clear search
  test("should clear search when clear button is clicked", () => {
    renderComponent({
      allSites: [mockSite],
    });

    const searchInput = screen.getByPlaceholderText("Search Here");

    fireEvent.change(searchInput, {
      target: { value: "SITE001" },
    });

    fireEvent.click(screen.getByLabelText("Clear search"));

    expect(searchInput).toHaveValue("");
    expect(screen.getByText("SITE001")).toBeInTheDocument();
  });

  // 8. No search results
  test("should display no results message when search does not match", () => {
    renderComponent({
      allSites: [mockSite],
    });

    fireEvent.change(screen.getByPlaceholderText("Search Here"), {
      target: { value: "INVALID" },
    });

    expect(screen.getByText("No results found")).toBeInTheDocument();
  });

  // 9. Terminal node rendering
  test("should render terminal child sites", () => {
    const selectedNode = {
      name: "Terminal 1",
      children: [
        mockSite,
        { ...mockSite, siteId: "SITE002" },
      ],
    };

    renderComponent({
      selectedPath: "CNMS/Terminal1",
      selectedNode,
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
    expect(screen.getByText("SITE002")).toBeInTheDocument();
    expect(screen.getByText("2 Total Site(s)")).toBeInTheDocument();
  });

  // 10. Terminal search
  test("should filter terminal sites", () => {
    const selectedNode = {
      children: [
        mockSite,
        { ...mockSite, siteId: "SITE002", siteName: "Chennai" },
      ],
    };

    renderComponent({
      selectedPath: "CNMS/Terminal1",
      selectedNode,
    });

    fireEvent.change(screen.getByPlaceholderText("Search Here"), {
      target: { value: "chennai" },
    });

    expect(screen.getByText("SITE002")).toBeInTheDocument();
    expect(screen.queryByText("SITE001")).not.toBeInTheDocument();
  });

  // 11. Direction node rendering
  test("should render direction node sites", () => {
    const selectedNode = {
      name: "Direction 1",
      children: [
        {
          name: "Terminal 1",
          children: [mockSite],
        },
      ],
    };

    renderComponent({
      selectedPath: "CNMS/Direction1",
      selectedNode,
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
  });

  // 12. Site node rendering
  test("should render selected site and repeater nodes", () => {
    const selectedNode = {
      ...mockSite,
      repeator1Site: {
        ...mockSite,
        siteId: "REP001",
        activeModeOfCommunication: 2,
      },
      repeator2Site: {
        ...mockSite,
        siteId: "REP002",
        activeModeOfCommunication: 3,
      },
      remoteSite: {
        ...mockSite,
        siteId: "REMOTE001",
        activeModeOfCommunication: 4,
      },
    };

    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode,
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
    expect(screen.getByText("REP001")).toBeInTheDocument();
    expect(screen.getByText("REP002")).toBeInTheDocument();
    expect(screen.getByText("REMOTE001")).toBeInTheDocument();
  });

  // 13. No data available
  test("should display no data available when node has no children", () => {
    renderComponent({
      selectedPath: "CNMS/Direction1",
      selectedNode: { name: "Direction 1", children: [] },
    });

    expect(screen.getByText("No data available")).toBeInTheDocument();
  });

  // 14. Communication mode icons
  test.each([
    [1, "V-Sat"],
    [2, "Radio"],
    [3, "E1-OFC"],
    [4, "Not Configured"],
    [99, "Not Configured"],
  ])(
    "should render correct communication icon for mode %s",
    (mode, altText) => {
      renderComponent({
        selectedPath: "CNMS/SITE001",
        selectedNode: {
          ...mockSite,
          activeModeOfCommunication: mode,
        },
      });

      expect(screen.getByAltText(altText)).toBeInTheDocument();
    }
  );

  // 15. Tooltip on hover
  test("should display tooltip when hovering over a site", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: mockSite,
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("Bangalore Site")).toBeInTheDocument();
    expect(screen.getByText("Health Status")).toBeInTheDocument();
    expect(screen.getByText("Online")).toBeInTheDocument();
  });

  // 16. Tooltip position
  test("should update tooltip position on mouse move", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: mockSite,
    });

    const siteButton = screen.getByText("SITE001").closest("button");

    fireEvent.mouseEnter(siteButton);
    fireEvent.mouseMove(siteButton, {
      clientX: 100,
      clientY: 200,
    });

    const tooltip = screen.getByText("Bangalore Site").parentElement;

    expect(tooltip).toHaveStyle({
      left: "115px",
      top: "215px",
    });
  });

  // 17. Tooltip disappears on mouse leave
  test("should hide tooltip when mouse leaves site", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: mockSite,
    });

    const siteButton = screen.getByText("SITE001").closest("button");

    fireEvent.mouseEnter(siteButton);

    expect(screen.getByText("Bangalore Site")).toBeInTheDocument();

    fireEvent.mouseLeave(siteButton);

    expect(screen.queryByText("Bangalore Site")).not.toBeInTheDocument();
  });

  // 18. Health status UP
  test("should display UP health status", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: mockSite,
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("Online")).toBeInTheDocument();
  });

  // 19. Health status DOWN
  test("should display DOWN health status", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: {
        ...mockSite,
        healthStatus: { id: 0 },
      },
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("DOWN")).toBeInTheDocument();
  });

  // 20. RNMS DOWN
  test("should display RNMS DOWN health status", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: {
        ...mockSite,
        healthStatus: { id: 2 },
      },
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("RNMS DOWN")).toBeInTheDocument();
  });

  // 21. Maintenance Non-OPS
  test("should display Maintenance Non-OPS status", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: {
        ...mockSite,
        healthStatus: { id: 3 },
        maintenanceType: 1,
      },
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("Maintenance Non-OPS")).toBeInTheDocument();
  });

  // 22. Maintenance R-OPS
  test("should display Maintenance R-OPS status", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: {
        ...mockSite,
        healthStatus: { id: 3 },
        maintenanceType: 2,
      },
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("Maintenance R-OPS")).toBeInTheDocument();
  });

  // 23. Unknown health status
  test("should display UNKNOWN for invalid health status", () => {
    renderComponent({
      selectedPath: "CNMS/SITE001",
      selectedNode: {
        ...mockSite,
        healthStatus: { id: 99 },
      },
    });

    fireEvent.mouseEnter(screen.getByText("SITE001").closest("button"));

    expect(screen.getByText("UNKNOWN")).toBeInTheDocument();
  });

  // 24. Fallback status color
  test("should use fallback status color when color is not configured", () => {
    renderComponent({
      statusColors: {},
      selectedPath: "CNMS/SITE001",
      selectedNode: mockSite,
    });

    const siteButton = screen.getByText("SITE001").closest("button");

    expect(siteButton).toHaveStyle({
      backgroundColor: "rgb(148, 163, 184)",
    });
  });

  // 25. Selected path change
  test("should clear search when selectedPath changes", () => {
    const { rerender } = render(
      <RightSidePanel
        selectedPath="CNMS"
        selectedNode={null}
        allSites={[mockSite]}
      />
    );

    const searchInput = screen.getByPlaceholderText("Search Here");

    fireEvent.change(searchInput, {
      target: { value: "SITE001" },
    });

    rerender(
      <RightSidePanel
        selectedPath="CNMS/Terminal1"
        selectedNode={null}
        allSites={[mockSite]}
      />
    );

    expect(searchInput).toHaveValue("");
  });

  // 26. Close callback
  test("should call onClose when fullscreen close is clicked", () => {
    const onClose = jest.fn();

    renderComponent({ onClose });

    fireEvent.click(screen.getByText("Fullscreen Close"));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  // 27. Whitespace search
  test("should show all sites when search contains only spaces", () => {
    renderComponent({
      allSites: [mockSite],
    });

    fireEvent.change(screen.getByPlaceholderText("Search Here"), {
      target: { value: "   " },
    });

    expect(screen.getByText("SITE001")).toBeInTheDocument();
  });
});