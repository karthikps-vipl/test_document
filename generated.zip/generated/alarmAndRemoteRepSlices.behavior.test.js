import alarmReducer, {
  decrementAlarmCount, setAlarmSeverityCount, setSeverityData, updateSingleAlarm,
  setBadgeCount, setCnmsBadgeCount, setNewAlarm, clearUpdateAlarm,
  setAlarmNotificationSettings, setActiveAllAlarms, setupdateAlram,
} from '../../src/store/features/Fault/alarmSlice';
import remoteReducer, {
  setRemoteRepDetails, clearData, setFetchSiteDetails,
  setFetchAllTerminalTypeAlongWithSite, setCnmsDeleteAddSite, setCnmsDeleteSite,
  setCnmsOpenAlarm, upsertCnmsSocketAlarm, updateSingleCnmsAlarm,
  clearCnmsAlarmNotificationEvent, setSiteMoveToMaintaiance, updateSiteReachabilityStatus,
  deleteSite, startBlink, stopBlink, setSiteLocationUpdate,
} from '../../src/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice';

beforeEach(() => {
  jest.spyOn(console, 'log').mockImplementation(() => {});
  jest.spyOn(console, 'warn').mockImplementation(() => {});
});

describe('alarm slice behavior', () => {
  test('updates alarm counts only while outside the alarm page', () => {
    let state = alarmReducer(undefined, decrementAlarmCount());
    expect(state.alarmCount).toBe(0);
    expect(state.alarmCount).toBe(0);
    state = alarmReducer(state, setActiveAllAlarms([{ alarmId: 1 }]));
    expect(state.fetchAllAlarm).toEqual([{ alarmId: 1 }]);
  });

  test('inserts, updates and removes alarms by alarm name and resource IP', () => {
    let state = alarmReducer(undefined, updateSingleAlarm({ alarmName: 'Link Down', resourceIp: '10.0.0.1', severity: 2, alarmState: 1 }));
    expect(state.fetchAllAlarm).toHaveLength(1);
    expect(state.severityData).toEqual({ 0: 0, 1: 0, 2: 1 });
    state = alarmReducer(state, updateSingleAlarm({ alarmName: 'link down', resourceIp: '10.0.0.1', severity: 1, alarmState: 1, message: 'updated' }));
    expect(state.fetchAllAlarm).toHaveLength(1);
    expect(state.fetchAllAlarm[0].message).toBe('updated');
    expect(state.severityData).toEqual({ 0: 0, 1: 1, 2: 0 });
    state = alarmReducer(state, updateSingleAlarm({ alarmName: 'LINK DOWN', resourceIp: '10.0.0.1', severity: 1, alarmState: 0 }));
    expect(state.fetchAllAlarm).toEqual([]);
    expect(state.severityData).toEqual({ 0: 0, 1: 0, 2: 0 });
  });

  test('groups badge counts by resource and CNMS site', () => {
    let state = alarmReducer(undefined, setBadgeCount([
      { resourceId: 10, severity: 2 }, { resourceId: 10, severity: 1 },
      { resourceId: 11, severity: 0 }, { resourceId: 11, severity: 9 },
    ]));
    expect(state.badgeCount).toEqual([
      { id: '10', major: 1, minor: 1, warning: 0 },
      { id: '11', major: 0, minor: 0, warning: 1 },
    ]);
    state = alarmReducer(state, setCnmsBadgeCount([
      { siteId: 1, resourceId: 10, severity: 2 },
      { siteId: 1, resourceId: 11, severity: 1 },
    ]));
    expect(state.cnmsBadgeCount.length).toBeGreaterThan(0);
    state = alarmReducer(state, setBadgeCount(null));
    expect(state.badgeCount).toEqual([]);
  });

  test('stores and clears alarm notification and settings state', () => {
    let state = alarmReducer(undefined, setAlarmSeverityCount({ critical: 2 }));
    state = alarmReducer(state, setSeverityData([1, 2, 3]));
    state = alarmReducer(state, setNewAlarm({ id: 7 }));
    expect(state).toMatchObject({ severityData: { critical: 2 }, severityDataOri: [1, 2, 3], updateAlaram: { id: 7 } });
    state = alarmReducer(state, clearUpdateAlarm());
    state = alarmReducer(state, setAlarmNotificationSettings({ enabled: false }));
    state = alarmReducer(state, setupdateAlram({ id: 8 }));
    expect(state.updateAlaram).toEqual({ id: 8 });
    expect(state.alarmNotificationSettings).toEqual({ enabled: false });
  });
});

describe('remote representative and CNMS alarm slice', () => {
  test('normalizes representative payloads and clears invalid or stored data', () => {
    let state = remoteReducer(undefined, setRemoteRepDetails([{ id: 1 }]));
    expect(state.remoteRepDetails).toEqual([{ id: 1 }]);
    state = remoteReducer(state, setRemoteRepDetails({ data: [{ id: 2 }] }));
    expect(state.remoteRepDetails).toEqual([{ id: 2 }]);
    state = remoteReducer(state, setRemoteRepDetails({ id: 3 }));
    expect(state.remoteRepDetails).toEqual([{ id: 3 }]);
    state = remoteReducer(state, setRemoteRepDetails('bad-payload'));
    expect(state.remoteRepDetails).toEqual([{ id: 3 }]);
    state = remoteReducer(state, clearData());
    expect(state.remoteRepDetails).toEqual([]);
  });

  test('sets site collections and normalizes delete/open alarm payloads', () => {
    let state = remoteReducer(undefined, setFetchSiteDetails([{ siteId: 1 }]));
    state = remoteReducer(state, setFetchAllTerminalTypeAlongWithSite([{ id: 'T1' }]));
    state = remoteReducer(state, setCnmsDeleteAddSite([{ siteId: 2 }]));
    state = remoteReducer(state, setCnmsDeleteSite({ siteId: 3 }));
    state = remoteReducer(state, setCnmsOpenAlarm([{ alarmId: 4 }]));
    expect(state).toMatchObject({
      fetchSiteDetails: [{ siteId: 1 }], fetchAllTerminalTypeAlongWithSite: [{ id: 'T1' }],
      CnmsDeleteAddSite: [{ siteId: 2 }], CnmsDeleteSite: [{ siteId: 3 }], cnmsOpenAlarm: [{ alarmId: 4 }],
    });
    state = remoteReducer(state, setCnmsDeleteSite('invalid'));
    state = remoteReducer(state, setCnmsOpenAlarm(null));
    expect(state.CnmsDeleteSite).toEqual([]);
    expect(state.cnmsOpenAlarm).toEqual([]);
  });

  test('upserts socket alarms, avoids duplicate notification on workflow updates and clears recovered alarms', () => {
    const alarm = { terminalTypeName: 'T1', siteId: 4, resourceIp: '10.0.0.1', alarmName: 'Power', alarmId: 9, workflow: 0, alarmState: 1 };
    let state = remoteReducer(undefined, upsertCnmsSocketAlarm({ alarm, notificationId: 'N1' }));
    expect(state.cnmsOpenAlarm).toHaveLength(1);
    expect(state.cnmsOpenAlarm[0].alarmCount).toBe(1);
    expect(state.cnmsAlarmNotificationEvent.notificationEventId).toBe('N1');
    state = remoteReducer(state, upsertCnmsSocketAlarm({ alarm: { ...alarm, workflow: 1 }, notificationId: 'N2' }));
    expect(state.cnmsOpenAlarm[0].alarmCount).toBe(1);
    expect(state.cnmsOpenAlarm[0].alarmId).toBe(9);
    state = remoteReducer(state, upsertCnmsSocketAlarm({ alarm: { ...alarm, alarmState: 0 }, notificationId: 'N3' }));
    expect(state.cnmsOpenAlarm).toEqual([]);
    state = remoteReducer(state, clearCnmsAlarmNotificationEvent());
    expect(state.cnmsAlarmNotificationEvent).toBeNull();
  });

  test('updates and removes CNMS alarms by ID and cleared state', () => {
    let state = remoteReducer(undefined, setCnmsOpenAlarm([{ alarmId: 1, workflow: 0, label: 'old' }]));
    state = remoteReducer(state, updateSingleCnmsAlarm({ alarmId: 1, label: 'updated' }));
    expect(state.cnmsOpenAlarm[0].label).toBe('updated');
    state = remoteReducer(state, updateSingleCnmsAlarm({ alarmId: 2, label: 'new' }));
    expect(state.cnmsOpenAlarm).toHaveLength(2);
    state = remoteReducer(state, updateSingleCnmsAlarm({ alarmId: 1, workflow: 2 }));
    expect(state.cnmsOpenAlarm.some((item) => item.alarmId === 1)).toBe(false);
    state = remoteReducer(state, updateSingleCnmsAlarm(null));
    expect(state.cnmsOpenAlarm).toHaveLength(1);
  });

  test('moves sites to maintenance, merges reachability and location updates, deletes and blinks sites', () => {
    let state = remoteReducer(undefined, setFetchSiteDetails([
      { siteId: 1, isMaintainance: false, discovered: true, groupList: ['g'] },
      { siteId: 2, isMaintainance: false },
    ]));
    state = remoteReducer(state, setSiteMoveToMaintaiance({ siteId: 1, isMaintainance: true, discovered: false, maintenanceType: 'planned', healthStatusId: 2, healthStatusValue: 'Down' }));
    expect(state.fetchSiteDetails[0]).toMatchObject({ isMaintainance: true, discovered: false, maintenanceType: 'planned', healthStatus: { id: 2, value: 'Down' } });
    state = remoteReducer(state, updateSiteReachabilityStatus([{ siteId: 1, reachable: true }, { siteId: 9, reachable: false }]));
    expect(state.fetchSiteDetails[0]).toMatchObject({ reachable: true, groupList: ['g'] });
    state = remoteReducer(state, setSiteLocationUpdate({ siteId: 1, latitude: 12, longitude: 77, siteName: 'A', siteNickName: 'AA' }));
    expect(state.fetchSiteDetails[0]).toMatchObject({ latitude: 12, longitude: 77, siteName: 'A', siteNickName: 'AA' });
    state = remoteReducer(state, startBlink({ siteId: 1, maintenanceType: 'planned' }));
    state = remoteReducer(state, startBlink({ siteId: 1, maintenanceType: 'urgent' }));
    expect(state.blinkingSites).toEqual([{ siteId: 1, maintenanceType: 'urgent' }]);
    state = remoteReducer(state, stopBlink(1));
    expect(state.blinkingSites).toEqual([]);
    state = remoteReducer(state, deleteSite({ siteId: 2 }));
    expect(state.fetchSiteDetails.map((site) => site.siteId)).toEqual([1]);
  });
});
