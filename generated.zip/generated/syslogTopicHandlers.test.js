import { SYSLOG_AUDIT_TOPIC } from '../../src/RestAPI/Socket/Endpoint';
import { getSyslogTopicHandlers } from '../../src/store/socket/syslogTopicHandlers';
import { applySyslogAuditEvent } from '../../src/store/features/SyslogAI/syslogSlice';

describe('syslog websocket topic handler', () => {
  test('parses valid event and dispatches audit action', () => {
    const store = { dispatch: jest.fn() };
    const handlers = getSyslogTopicHandlers(store);
    const payload = { type: 'record', message: 'user login' };
    handlers[SYSLOG_AUDIT_TOPIC]({ body: JSON.stringify(payload) });
    expect(store.dispatch).toHaveBeenCalledWith(applySyslogAuditEvent(payload));
  });
  test.each(['stopped', 'error'])('disconnects socket after terminal event: %s', (type) => {
    jest.useFakeTimers();
    const store = { dispatch: jest.fn() };
    getSyslogTopicHandlers(store)[SYSLOG_AUDIT_TOPIC]({ body: JSON.stringify({ type }) });
    expect(store.dispatch).toHaveBeenCalledTimes(1);
    jest.advanceTimersByTime(100);
    expect(store.dispatch).toHaveBeenLastCalledWith({ type: 'syslogSocket/disconnect' });
    jest.useRealTimers();
  });
  test('ignores malformed JSON payload', () => {
    const store = { dispatch: jest.fn() };
    const error = jest.spyOn(console, 'error').mockImplementation(() => {});
    getSyslogTopicHandlers(store)[SYSLOG_AUDIT_TOPIC]({ body: '{invalid' });
    expect(store.dispatch).not.toHaveBeenCalled();
    expect(error).toHaveBeenCalled();
    error.mockRestore();
  });
});
