import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { ThemeProvider, createTheme } from '@mui/material/styles';

const mockConfigurationAxios = jest.fn();

jest.mock('react-grid-layout', () => ({ children, ...props }) => <div data-testid="grid-layout" {...props}>{children}</div>);
// Keep this component test focused on ExcelConfigBuilder itself. The real
// registry imports many individual widgets and MTable, which are covered separately.
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRegistry23', () => ({
  WIDGET_REGISTRY: {},
  AVAILABLE_WIDGETS: [],
}));
jest.mock('@/components/Reusable/Table/MTable', () => ({
  __esModule: true,
  default: () => <div data-testid="mock-mtable" />,
}));

jest.mock('@/RestAPI/api/axiosApicall', () => ({
  ConfigurationAxios: (...args) => mockConfigurationAxios(...args),
}));
jest.mock('@/components/Reusable/Select/MAlarmSelect', () => ({ label, options = [], value, onChange }) => (
  <select aria-label={label || 'tab selector'} value={value ?? ''} onChange={(event) => onChange?.(event.target.value)}>
    {options.map((option) => <option key={option.value ?? option.id} value={option.value ?? option.id}>{option.label ?? option.name}</option>)}
  </select>
));
jest.mock('@/components/Reusable/Input/MInput', () => (props) => <input {...props} />);
jest.mock('@/components/Reusable/Button/MButtonPrimary', () => ({ children, ...props }) => <button {...props}>{children}</button>);
jest.mock('@/components/Reusable/Button/MButtonSecondary', () => ({ children, ...props }) => <button {...props}>{children}</button>);
jest.mock('@/components/Reusable/Modal/MModal', () => ({ open, title, children, handleClose }) => open ? <div role="dialog" aria-label={title}>{children}<button onClick={handleClose}>Close modal</button></div> : null);
jest.mock('@/components/Reusable/Toast/Toast', () => jest.fn());
jest.mock('../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/WidgetRenderer', () => () => <div data-testid="widget-renderer" />);

import ExcelConfigBuilder from '../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/ExcelConfigBuilder';

const theme = createTheme({ palette: { custom: { border: '1px solid #ddd', snmp: { snmmptitle: '#222' } } } });
const renderBuilder = (props = {}) => render(
  <ThemeProvider theme={theme}>
    <ExcelConfigBuilder
      selectedDevice={{ resourceId: 7, resourceName: 'Router', imResourceType: { resourceTypeName: 'Router' } }}
      selectedTerminal={{ id: 3 }}
      tabs={[{ name: 'Configuration' }, { name: 'Status' }]}
      dialogType="CONFIGURATION"
      onBack={jest.fn()}
      setActiveTabId={jest.fn()}
      activeTabIdx={0}
      setActiveTabIdx={jest.fn()}
      {...props}
    />
  </ThemeProvider>
);

describe('ExcelConfigBuilder component', () => {
  beforeEach(() => {
    mockConfigurationAxios.mockReset();
    mockConfigurationAxios.mockResolvedValue({ data: { status: 1 } });
    global.ResizeObserver = class {
      observe = jest.fn();
      disconnect = jest.fn();
    };
  });

  afterEach(() => delete global.ResizeObserver);

  test('renders the selected device and initial tabs', () => {
    renderBuilder();
    expect(screen.getByText(/Manage Tabs : Router/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Add tab' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Back' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Save Layout' })).toBeInTheDocument();
  });

  test('adds a new tab to the layout editor', () => {
    renderBuilder();
    fireEvent.click(screen.getByRole('button', { name: 'Add tab' }));
    expect(screen.getByRole('option', { name: 'Tab 3' })).toBeInTheDocument();
  });

  test('saves an empty layout through the configuration API', async () => {
    renderBuilder();
    fireEvent.click(screen.getByRole('button', { name: 'Save Layout' }));
    await waitFor(() => expect(mockConfigurationAxios).toHaveBeenCalled());
    expect(mockConfigurationAxios.mock.calls[0][1]).toBe('post');
  });

  test('calls the supplied back callback', () => {
    const onBack = jest.fn();
    renderBuilder({ onBack });
    fireEvent.click(screen.getByRole('button', { name: 'Back' }));
    expect(onBack).toHaveBeenCalledTimes(1);
  });
});
