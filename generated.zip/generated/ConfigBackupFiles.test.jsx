
import React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from "@testing-library/react";
import "@testing-library/jest-dom";

import ConfigBackupFiles from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsBackup/ConfigBackupFiles";

import { DbAxios } from "@/RestAPI/api/axiosApicall";
import {
  CHECK_FOR_BACKUP_FILES,
  CONFIG_NO_OF_BACKUP_FILES,
  FETCH_DB_CONFIG_DATA,
} from "@/RestAPI/url/endpoint";
import Toast from "@/components/Reusable/Toast/Toast";

/* -------------------------------------------------------
   MOCKS
------------------------------------------------------- */

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  DbAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  CHECK_FOR_BACKUP_FILES: "/check-backup-files",
  CONFIG_NO_OF_BACKUP_FILES: "/config-backup-files",
  FETCH_DB_CONFIG_DATA: "/fetch-db-config",
}));

jest.mock("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

jest.mock("@/components/Reusable/Form/MForm", () => ({
  __esModule: true,
  default: ({ title, children }) => (
    <div data-testid="mform">
      <h2>{title}</h2>
      {children}
    </div>
  ),
}));

jest.mock("@/components/Reusable/Form/FormField", () => ({
  __esModule: true,
  default: ({
    label,
    name,
    value,
    placeholder,
    error,
    errorMessage,
    onChange,
    onBlur,
  }) => (
    <div>
      <label htmlFor={name}>{label}</label>
      <input
        id={name}
        name={name}
        data-testid="backup-count-input"
        value={value}
        placeholder={placeholder}
        onChange={onChange}
        onBlur={onBlur}
      />
      {error && <span data-testid="backup-count-error">{errorMessage}</span>}
    </div>
  ),
}));

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button
      type="button"
      data-testid="update-button"
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  ),
}));

let latestDialogProps;

jest.mock("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => {
    latestDialogProps = props;
    return props.open ? (
      <div data-testid="confirm-dialog">
        <span>{props.title}</span>
        <span>{props.message}</span>
        <button
          type="button"
          data-testid="dialog-confirm"
          onClick={props.onConfirm}
        >
          Confirm
        </button>
        <button
          type="button"
          data-testid="dialog-cancel"
          onClick={props.onClose}
        >
          Cancel
        </button>
      </div>
    ) : null;
  },
}));

jest.mock("@/assets/SVGIcons/question_mark.svg", () => "question-mark.svg");

/* -------------------------------------------------------
   HELPERS
------------------------------------------------------- */

const renderComponent = () => render(<ConfigBackupFiles />);

const enterBackupCount = (value) => {
  fireEvent.change(screen.getByTestId("backup-count-input"), {
    target: { name: "backupcount", value },
  });
};

/* -------------------------------------------------------
   TEST SUITE
------------------------------------------------------- */

describe("ConfigBackupFiles Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    latestDialogProps = undefined;

    DbAxios.mockImplementation((url) => {
      if (url === FETCH_DB_CONFIG_DATA) {
        return Promise.resolve({
          data: { noOfBackupfiles: 45 },
        });
      }
      if (url.startsWith(`${CHECK_FOR_BACKUP_FILES}/`)) {
        return Promise.resolve({ data: true });
      }
      if (url === CONFIG_NO_OF_BACKUP_FILES) {
        return Promise.resolve({
          status: 200,
          data: { status: 1 },
        });
      }
      return Promise.resolve({ data: null });
    });

    jest.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /* -------------------------------------------------------
     INITIAL LOAD & RENDERING
  ------------------------------------------------------- */

  describe("Initial rendering and config fetch", () => {
    it("shows loading spinner while fetching initial config", () => {
      DbAxios.mockImplementationOnce(() => new Promise(() => {}));

      renderComponent();

      expect(screen.getByRole("progressbar")).toBeInTheDocument();
    });

    it("loads initial backup count and keeps Update button disabled until dirty", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      expect(DbAxios).toHaveBeenCalledWith(FETCH_DB_CONFIG_DATA, "get");
      expect(screen.getByText("Config. Of Backup Files")).toBeInTheDocument();
      expect(screen.getByTestId("backup-count-input")).toHaveAttribute(
        "placeholder",
        "Must be between 30 - 100"
      );
      expect(screen.getByTestId("update-button")).toBeDisabled();
      expect(screen.queryByTestId("backup-count-error")).not.toBeInTheDocument();
    });

    it("handles null/undefined noOfBackupfiles and zero value", async () => {
      DbAxios.mockResolvedValueOnce({
        data: { noOfBackupfiles: null },
      });

      const { unmount } = renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("");
      });
      unmount();

      DbAxios.mockResolvedValueOnce({
        data: { noOfBackupfiles: 0 },
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("0");
      });
    });

    it("logs error and renders empty input when initial fetch fails", async () => {
      DbAxios.mockRejectedValueOnce(new Error("Fetch failed"));

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("");
      });

      expect(console.error).toHaveBeenCalledWith(
        "Error fetching config data:",
        expect.any(Error)
      );
    });
  });

  /* -------------------------------------------------------
     INPUT SANITIZATION & VALIDATION
  ------------------------------------------------------- */

  describe("Input filtering and validation", () => {
    it("ignores non-numeric input and allows digits or empty string", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("60abc");
      expect(screen.getByTestId("backup-count-input")).toHaveValue("45");

      enterBackupCount("60");
      expect(screen.getByTestId("backup-count-input")).toHaveValue("60");
      expect(screen.getByTestId("update-button")).toBeEnabled();

      enterBackupCount("");
      expect(screen.getByTestId("backup-count-input")).toHaveValue("");
      expect(screen.getByTestId("update-button")).toBeDisabled();
    });

    it("shows validation errors when dirty value is below 30 or above 100", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("20");
      fireEvent.blur(screen.getByTestId("backup-count-input"));

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-error")).toHaveTextContent(
          "Must be at least 30"
        );
      });
      expect(screen.getByTestId("update-button")).toBeDisabled();

      enterBackupCount("105");
      fireEvent.blur(screen.getByTestId("backup-count-input"));

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-error")).toHaveTextContent(
          "Must be at most 100"
        );
      });
      expect(screen.getByTestId("update-button")).toBeDisabled();
    });
  });

  /* -------------------------------------------------------
     CONFIRMATION & UPDATE SUBMISSION
  ------------------------------------------------------- */

  describe("Confirmation dialog and settings update", () => {
    it("opens confirmation dialog and closes it when cancelled", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("50");
      fireEvent.click(screen.getByTestId("update-button"));

      expect(screen.getByTestId("confirm-dialog")).toBeInTheDocument();
      expect(latestDialogProps.variant).toBe("info");
      expect(latestDialogProps.mode).toBe("child");

      fireEvent.click(screen.getByTestId("dialog-cancel"));
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
      expect(DbAxios).not.toHaveBeenCalledWith(
        expect.stringContaining(CHECK_FOR_BACKUP_FILES),
        expect.anything()
      );
    });

    it("shows error toast when backup file validation returns false", async () => {
      DbAxios.mockImplementation((url) => {
        if (url === FETCH_DB_CONFIG_DATA) {
          return Promise.resolve({ data: { noOfBackupfiles: 45 } });
        }
        if (url === `${CHECK_FOR_BACKUP_FILES}/35`) {
          return Promise.resolve({ data: false });
        }
        return Promise.resolve({ data: {} });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("35");
      fireEvent.click(screen.getByTestId("update-button"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Invalid backup count range or criteria not met",
          "error"
        );
      });
      expect(DbAxios).not.toHaveBeenCalledWith(
        CONFIG_NO_OF_BACKUP_FILES,
        expect.anything(),
        expect.anything()
      );
    });

    it("updates backup settings and shows success toast on valid response", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("75");
      fireEvent.click(screen.getByTestId("update-button"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(DbAxios).toHaveBeenCalledWith(
          `${CHECK_FOR_BACKUP_FILES}/75`,
          "get"
        );
        expect(DbAxios).toHaveBeenCalledWith(
          CONFIG_NO_OF_BACKUP_FILES,
          "post",
          { noOfBackupfiles: 75 }
        );
      });

      expect(Toast).toHaveBeenCalledWith(
        "Success!",
        "Config Backup Settings updated successfully",
        "success"
      );
      expect(screen.queryByTestId("confirm-dialog")).not.toBeInTheDocument();
    });

    it("handles non-status-1 response with response.data === true", async () => {
      DbAxios.mockImplementation((url) => {
        if (url === FETCH_DB_CONFIG_DATA) {
          return Promise.resolve({ data: { noOfBackupfiles: 45 } });
        }
        if (url.startsWith(`${CHECK_FOR_BACKUP_FILES}/`)) {
          return Promise.resolve({ data: true });
        }
        if (url === CONFIG_NO_OF_BACKUP_FILES) {
          return Promise.resolve({
            status: 204,
            data: true,
          });
        }
        return Promise.resolve({ data: {} });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("80");
      fireEvent.click(screen.getByTestId("update-button"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Success!",
          "Config Backup Settings updated successfully",
          "success"
        );
      });
    });

    it("shows error toast when update API returns failure status", async () => {
      DbAxios.mockImplementation((url) => {
        if (url === FETCH_DB_CONFIG_DATA) {
          return Promise.resolve({ data: { noOfBackupfiles: 45 } });
        }
        if (url.startsWith(`${CHECK_FOR_BACKUP_FILES}/`)) {
          return Promise.resolve({ data: true });
        }
        if (url === CONFIG_NO_OF_BACKUP_FILES) {
          return Promise.resolve({
            status: 200,
            data: { status: 0, message: "Database lock active" },
          });
        }
        return Promise.resolve({ data: {} });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("65");
      fireEvent.click(screen.getByTestId("update-button"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Database lock active",
          "error"
        );
      });

      // Default failure message branch
      DbAxios.mockImplementationOnce((url) => {
        if (url.startsWith(`${CHECK_FOR_BACKUP_FILES}/`)) {
          return Promise.resolve({ data: true });
        }
        return Promise.resolve({ status: 200, data: {} });
      });
      DbAxios.mockResolvedValueOnce({
        status: 200,
        data: { status: 0 },
      });

      fireEvent.click(screen.getByTestId("update-button"));
      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to update settings",
          "error"
        );
      });
    });

    it("shows error toast and resets Updating state when API throws", async () => {
      DbAxios.mockImplementation((url) => {
        if (url === FETCH_DB_CONFIG_DATA) {
          return Promise.resolve({ data: { noOfBackupfiles: 45 } });
        }
        if (url.startsWith(`${CHECK_FOR_BACKUP_FILES}/`)) {
          return Promise.reject(new Error("Validation endpoint down"));
        }
        return Promise.resolve({ data: {} });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("55");
      fireEvent.click(screen.getByTestId("update-button"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      await waitFor(() => {
        expect(Toast).toHaveBeenCalledWith(
          "Error!",
          "Failed to update Backup Settings",
          "error"
        );
      });

      expect(screen.getByTestId("update-button")).toHaveTextContent("Update");
      expect(screen.getByTestId("update-button")).toBeEnabled();
    });

    it("shows Updating... label while request is pending", async () => {
      let resolvePost;

      DbAxios.mockImplementation((url) => {
        if (url === FETCH_DB_CONFIG_DATA) {
          return Promise.resolve({ data: { noOfBackupfiles: 45 } });
        }
        if (url.startsWith(`${CHECK_FOR_BACKUP_FILES}/`)) {
          return Promise.resolve({ data: true });
        }
        if (url === CONFIG_NO_OF_BACKUP_FILES) {
          return new Promise((resolve) => {
            resolvePost = resolve;
          });
        }
        return Promise.resolve({ data: {} });
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("backup-count-input")).toHaveValue("45");
      });

      enterBackupCount("85");
      fireEvent.click(screen.getByTestId("update-button"));

      await act(async () => {
        fireEvent.click(screen.getByTestId("dialog-confirm"));
      });

      expect(screen.getByTestId("update-button")).toHaveTextContent("Updating...");
      expect(screen.getByTestId("update-button")).toBeDisabled();

      await act(async () => {
        resolvePost({ status: 200, data: { status: 1 } });
      });

      await waitFor(() => {
        expect(screen.getByTestId("update-button")).toHaveTextContent("Update");
      });
    });
  });
});