import React from "react";
import { render, screen, fireEvent, within, act } from "@testing-library/react";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import { jest } from "@jest/globals";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import MTable from "../../src/components/Reusable/Table/MTable";

const theme = createTheme({
  palette: {
    custom: {
      icon: { iconFilter: "none" },
      chart: { chartbg: "#fff" },
      table: {
        borderBox: "#ccc", headerBg: "#D5E0FF", headerText: "#14348D",
        border: "#e1e1e1", borderHeader: "#ccc", headerBottom: "#ccc",
        headerRight: "#eee", rowHover: "#f5f5f5", tablebodybg: "#fff",
      },
    },
  },
});

const defaultColumns = [
  { name: "Device Name", uid: "deviceName" },
  { name: "Status", uid: "status" },
];
const defaultRows = [
  { id: 1, deviceName: "Router A", status: "Active" },
  { id: 2, deviceName: "Switch B", status: "Inactive" },
];

function renderTable(props = {}, userState = {}) {
  const store = configureStore({
    reducer: {
      userSlice: () => ({
        isReadOnlyMode: false,
        isUserLoggedIn: true,
        userDetails: { data: { userName: "Test User", group: { privileges: [] } } },
        ...userState,
      }),
      alarm: (state = {}) => state,
    },
  });
  return render(
    <ThemeProvider theme={theme}>
      <Provider store={store}>
        <MTable
          tableTitle="Device List"
          columns={defaultColumns}
          tableData={defaultRows}
          {...props}
        />
      </Provider>
    </ThemeProvider>
  );
}

const tickDebounce = async () => {
  await act(async () => {
    await new Promise((resolve) => setTimeout(resolve, 130));
  });
};

describe("MTable – expanded behaviour coverage", () => {
  describe("rendering and optional header controls", () => {
    test("renders custom table header", () => {
      renderTable({ tableHeader: <span>Custom table header</span> });
      expect(screen.getByText("Custom table header")).toBeInTheDocument();
    });

    test("renders generic header actions when enabled", () => {
      renderTable({ showHeaderActions: true, headerActions: <button>Header action</button> });
      expect(screen.getByRole("button", { name: "Header action" })).toBeInTheDocument();
    });

    test("does not render Add button by default", () => {
      renderTable({ AddText: "Add Device", handleAdd: jest.fn() });
      expect(screen.queryByRole("button", { name: "Add Device" })).not.toBeInTheDocument();
    });

    test("disables Add button when addDisable is true", () => {
      renderTable({ hideAdd: false, AddText: "Add Device", addDisable: true });
      expect(screen.getByRole("button", { name: "Add Device" })).toBeDisabled();
    });

    test("disables controls when global disabled is true", () => {
      const onEdit = jest.fn();
      renderTable({
        disabled: true,
        columns: [{ name: "Device Name", uid: "deviceName" }, { name: "Actions", uid: "actions" }],
        handleEdit: onEdit,
      });
      const edit = screen.getAllByRole("button", { name: "Edit" })[0];
      expect(edit).toBeDisabled();
    });
  });

  describe("global and column search", () => {
    test("filters rows using global search", async () => {
      renderTable({ showSearch: true });
      fireEvent.change(screen.getByPlaceholderText("Search..."), { target: { value: "Router" } });
      await tickDebounce();
      expect(screen.getByText("Router A")).toBeInTheDocument();
      expect(screen.queryByText("Switch B")).not.toBeInTheDocument();
    });

    test("global search is case-insensitive", async () => {
      renderTable({ showSearch: true });
      fireEvent.change(screen.getByPlaceholderText("Search..."), { target: { value: "router a" } });
      await tickDebounce();
      expect(screen.getByText("Router A")).toBeInTheDocument();
      expect(screen.queryByText("Switch B")).not.toBeInTheDocument();
    });

    test("clearing global search restores all rows", async () => {
      renderTable({ showSearch: true });
      const input = screen.getByPlaceholderText("Search...");
      fireEvent.change(input, { target: { value: "Router" } });
      await tickDebounce();
      fireEvent.change(input, { target: { value: "" } });
      await tickDebounce();
      expect(screen.getByText("Router A")).toBeInTheDocument();
      expect(screen.getByText("Switch B")).toBeInTheDocument();
    });

    test("filters by a column-specific search input", () => {
      renderTable({ enableColumnSearch: true });
      fireEvent.change(screen.getByPlaceholderText("Search Device Name"), { target: { value: "Switch" } });
      expect(screen.getByText("Switch B")).toBeInTheDocument();
      expect(screen.queryByText("Router A")).not.toBeInTheDocument();
    });

    test("combines searches across columns", () => {
      renderTable({ enableColumnSearch: true });
      fireEvent.change(screen.getByPlaceholderText("Search Device Name"), { target: { value: "Router" } });
      fireEvent.change(screen.getByPlaceholderText("Search Status"), { target: { value: "Active" } });
      expect(screen.getByText("Router A")).toBeInTheDocument();
      expect(screen.queryByText("Switch B")).not.toBeInTheDocument();
    });

    test("shows no rows when global search has no match", async () => {
      renderTable({ showSearch: true });
      fireEvent.change(screen.getByPlaceholderText("Search..."), { target: { value: "does-not-exist" } });
      await tickDebounce();
      expect(screen.queryByText("Router A")).not.toBeInTheDocument();
      expect(screen.queryByText("Switch B")).not.toBeInTheDocument();
    });
  });

  describe("pagination", () => {
    const tenRows = Array.from({ length: 10 }, (_, i) => ({ id: i + 1, deviceName: `Device ${i + 1}`, status: "Active" }));

    test("shows only the first page initially", () => {
      renderTable({ tableData: tenRows, showPagination: true });
      expect(screen.getByText("Device 1")).toBeInTheDocument();
      expect(screen.getByText("Device 5")).toBeInTheDocument();
      expect(screen.queryByText("Device 6")).not.toBeInTheDocument();
    });

    test("moves to the next page", () => {
      renderTable({ tableData: tenRows, showPagination: true });
      fireEvent.click(screen.getByRole("button", { name: /go to next page/i }));
      expect(screen.getByText("Device 6")).toBeInTheDocument();
      expect(screen.getByText("Device 10")).toBeInTheDocument();
      expect(screen.queryByText("Device 1")).not.toBeInTheDocument();
    });

    test("moves back to the previous page", () => {
      renderTable({ tableData: tenRows, showPagination: true });
      fireEvent.click(screen.getByRole("button", { name: /go to next page/i }));
      fireEvent.click(screen.getByRole("button", { name: /go to previous page/i }));
      expect(screen.getByText("Device 1")).toBeInTheDocument();
    });

    test("hides pagination when showPagination is false", () => {
      renderTable({ tableData: tenRows, showPagination: false });
      expect(screen.getByText("Device 10")).toBeInTheDocument();
      expect(screen.queryByRole("button", { name: /go to next page/i })).not.toBeInTheDocument();
    });
  });

  describe("generic row selection", () => {
    test("renders a checkbox for each row when enabled", () => {
      renderTable({ enableRowSelection: true, selectedRowsNew: new Set() });
      expect(screen.getAllByRole("checkbox")).toHaveLength(3); // header + two rows
    });

    test("reports individual row selection", () => {
      const onRowSelect = jest.fn();
      renderTable({ enableRowSelection: true, selectedRowsNew: new Set(), onRowSelect });
      const checkboxes = screen.getAllByRole("checkbox");
      fireEvent.click(checkboxes[1]);
      expect(onRowSelect).toHaveBeenCalledWith(1, true);
    });

    test("reports select-all action", () => {
      const onSelectAll = jest.fn();
      renderTable({ enableRowSelection: true, selectedRowsNew: new Set(), onSelectAll });
      fireEvent.click(screen.getAllByRole("checkbox")[0]);
      expect(onSelectAll).toHaveBeenCalledWith(true);
    });

    test("marks all rows selected when every row ID is selected", () => {
      renderTable({ enableRowSelection: true, selectedRowsNew: new Set(["1", "2"]) });
      const checkboxes = screen.getAllByRole("checkbox");
      expect(checkboxes[0]).toBeChecked();
      expect(checkboxes[1]).toBeChecked();
      expect(checkboxes[2]).toBeChecked();
    });

    test("marks the header checkbox indeterminate for partial selection", () => {
      renderTable({ enableRowSelection: true, selectedRowsNew: new Set(["1"]) });
      expect(screen.getAllByRole("checkbox")[0].closest(".MuiCheckbox-root")).toHaveClass("MuiCheckbox-indeterminate");
    });

    test("uses configured rowIdKey", () => {
      const onRowSelect = jest.fn();
      const rows = [{ uuid: "r-1", deviceName: "Router A", status: "Active" }];
      renderTable({ tableData: rows, rowIdKey: "uuid", enableRowSelection: true, selectedRowsNew: new Set(), onRowSelect });
      fireEvent.click(screen.getAllByRole("checkbox")[1]);
      expect(onRowSelect).toHaveBeenCalledWith("r-1", true);
    });
  });

  describe("row actions", () => {
    const actionColumns = [
      { name: "Device Name", uid: "deviceName" },
      { name: "Actions", uid: "actions" },
    ];

    test("calls View callback with the clicked row", () => {
      const handleView = jest.fn();
      renderTable({ columns: actionColumns, handleView });
      fireEvent.click(screen.getAllByRole("img", { name: "view" })[0]);
      expect(handleView).toHaveBeenCalledWith(defaultRows[0]);
    });

    test("calls Edit callback with the clicked row", () => {
      const handleEdit = jest.fn();
      renderTable({ columns: actionColumns, handleEdit });
      fireEvent.click(screen.getAllByRole("button", { name: "Edit" })[0]);
      expect(handleEdit).toHaveBeenCalledWith(defaultRows[0]);
    });

    test("disables Edit when editDisable is true", () => {
      renderTable({ columns: actionColumns, handleEdit: jest.fn(), editDisable: true });
      expect(screen.getAllByRole("button", { name: "Edit" })[0]).toBeDisabled();
    });

    test("calls Delete callback with the clicked row", () => {
      const handleDelete = jest.fn();
      renderTable({ columns: actionColumns, handleDelete });
      fireEvent.click(screen.getAllByRole("button", { name: "Delete" })[0]);
      expect(handleDelete).toHaveBeenCalledWith(defaultRows[0]);
    });

    test("calls Download callback with the clicked row", () => {
      const handleDownload = jest.fn();
      renderTable({ columns: actionColumns, handleDownload });
      fireEvent.click(screen.getAllByRole("img", { name: "download" })[0]);
      expect(handleDownload).toHaveBeenCalledWith(defaultRows[0]);
    });

    test("calls History callback with the clicked row", () => {
      const handleHistory = jest.fn();
      renderTable({ columns: actionColumns, handleHistory });
      fireEvent.click(screen.getAllByRole("button", { name: "History" })[0]);
      expect(handleHistory).toHaveBeenCalledWith(defaultRows[0]);
    });
  });

  describe("collapsible rows", () => {
    test("expands a row and renders configured nested data", () => {
      const rows = [{ id: 7, deviceName: "Router A", status: "Active", children: [{ childName: "Port 1" }] }];
      renderTable({
        tableData: rows,
        columns: [{ name: "S.No", uid: "sno" }, { name: "Device Name", uid: "deviceName" }],
        isCollapsible: true,
        collapseColumns: [{ name: "Child", uid: "childName" }],
        collapseDataKey: "children",
      });
      const row = screen.getByText("Router A").closest("tr");
      fireEvent.click(within(row).getByRole("button"));
      expect(screen.getByText("Port 1")).toBeInTheDocument();
    });

    test("handles expanded row with no nested records", () => {
      const rows = [{ id: 8, deviceName: "Router Empty", status: "Active", children: [] }];
      renderTable({
        tableData: rows,
        columns: [{ name: "S.No", uid: "sno" }, { name: "Device Name", uid: "deviceName" }],
        isCollapsible: true,
        collapseColumns: [{ name: "Child", uid: "childName" }],
        collapseDataKey: "children",
      });
      const row = screen.getByText("Router Empty").closest("tr");
      fireEvent.click(within(row).getByRole("button"));
      expect(screen.getByText("Child")).toBeInTheDocument();
      expect(screen.getByText("Router Empty")).toBeInTheDocument();
    });
  });

  describe("refresh, export and maximize controls", () => {
    test("calls refresh callback", () => {
      const onRefreshClick = jest.fn();
      renderTable({ handleRefresh: true, onRefreshClick });
      fireEvent.click(screen.getByLabelText("Refresh"));
      expect(onRefreshClick).toHaveBeenCalledTimes(1);
    });

    test("calls custom export callback", () => {
      const onExportClick = jest.fn();
      renderTable({ showExportButton: true, onExportClick, exportIcon: "export.svg" });
      fireEvent.click(screen.getByAltText("export"));
      expect(onExportClick).toHaveBeenCalledTimes(1);
    });

    test("calls PDF export callback", () => {
      const handleDownloadPDF = jest.fn();
      renderTable({ handleDownloadPDF });
      fireEvent.click(screen.getAllByRole("img", { name: "download" })[0].parentElement);
      fireEvent.click(screen.getByText("Export as PDF"));
      expect(handleDownloadPDF).toHaveBeenCalled();
    });

    test("calls maximize callback", () => {
      const toggleMaximize = jest.fn();
      renderTable({ showMaximazed: true, toggleMaximize });
      fireEvent.click(screen.getByTestId("FullscreenIcon"));
      expect(toggleMaximize).toHaveBeenCalledTimes(1);
    });

    test("renders custom visible content when enabled", () => {
      renderTable({ showVisibleContent: true, VisibleContent: <div>Visible columns panel</div> });
      expect(screen.getByText("Visible columns panel")).toBeInTheDocument();
    });
  });
});
