
import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";


// Mock the React Flow package used by the component.
jest.unstable_mockModule("@xyflow/react", () => ({
  Handle: jest.fn(({ position, type }) => (
    <div
      data-testid={`reactflow-handle-${type}`}
      data-position={position}
      data-type={type}
    />
  )),
  Position: {
    Left: "left",
    Right: "right",
    Top: "top",
    Bottom: "bottom",
  },
}));

const { ReactFlowPortStatusNode } = await import(
  "@/Pages/Rnmsdashboard/PortStatus/ReactFlowPortStatusNode"
);

describe("ReactFlowPortStatusNode Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  // 1. Basic rendering
  test("should render ReactFlowPortStatusNode successfully", () => {
    const { container } = render(
      <ReactFlowPortStatusNode data={{}} />
    );

    expect(
      container.querySelector(".reactflow-port-node")
    ).toBeInTheDocument();
  });

  // 2. Left handle
  test("should render left target handle", () => {
    render(<ReactFlowPortStatusNode data={{}} />);

    const leftHandle = screen.getByTestId(
      "reactflow-handle-target"
    );

    expect(leftHandle).toBeInTheDocument();
    expect(leftHandle).toHaveAttribute("data-position", "left");
    expect(leftHandle).toHaveAttribute("data-type", "target");
  });

  // 3. Right handle
  test("should render right source handle", () => {
    render(<ReactFlowPortStatusNode data={{}} />);

    const rightHandle = screen.getByTestId(
      "reactflow-handle-source"
    );

    expect(rightHandle).toBeInTheDocument();
    expect(rightHandle).toHaveAttribute("data-position", "right");
    expect(rightHandle).toHaveAttribute("data-type", "source");
  });

  // 4. Handle count
  test("should render exactly two handles", () => {
    const { container } = render(
      <ReactFlowPortStatusNode data={{}} />
    );

    expect(
      container.querySelectorAll('[data-testid^="reactflow-handle-"]')
    ).toHaveLength(2);
  });



  // 6. Empty data
  test("should render successfully with empty data", () => {
    const { container } = render(
      <ReactFlowPortStatusNode data={{}} />
    );

    expect(
      container.querySelector(".reactflow-port-node")
    ).toBeInTheDocument();
  });

  // 7. Device data
  test("should render successfully when device data is provided", () => {
    const data = {
      device: {
        id: "DEVICE001",
        title: "Switch 001",
      },
    };

    const { container } = render(
      <ReactFlowPortStatusNode data={data} />
    );

    expect(
      container.querySelector(".reactflow-port-node")
    ).toBeInTheDocument();
  });

  // 8. No visible device content
  test("should not render device information inside the node", () => {
    const data = {
      device: {
        id: "DEVICE001",
        title: "Switch 001",
      },
    };

    render(<ReactFlowPortStatusNode data={data} />);

    expect(screen.queryByText("Switch 001")).not.toBeInTheDocument();
    expect(screen.queryByText("DEVICE001")).not.toBeInTheDocument();
  });

  // 9. Node structure
  test("should render handles inside the React Flow node container", () => {
    const { container } = render(
      <ReactFlowPortStatusNode data={{}} />
    );

    const node = container.querySelector(".reactflow-port-node");

    expect(node.children).toHaveLength(2);
    expect(node.children[0]).toHaveAttribute("data-type", "target");
    expect(node.children[1]).toHaveAttribute("data-type", "source");
  });
});
