import React from "react";
import { jest } from "@jest/globals";
import { fireEvent, render, screen, within } from "@testing-library/react";
import MSelect from "../../src/components/Reusable/Select/MSelect";
import MMultiSelect from "../../src/components/Reusable/Select/MMultiSelect";
import MAlarmSelect from "../../src/components/Reusable/Select/MAlarmSelect";

const options = [
  { id: 1, value: "alpha", label: "Alpha" },
  { id: 2, value: "beta", label: "Beta" },
  { id: 3, value: "gamma", label: "Gamma" },
];

const openSelect = (element) => {
  fireEvent.mouseDown(element);
};

describe("MSelect", () => {
  test("renders its label and placeholder when value is empty", () => {
    render(
      <MSelect
        label="Choose item"
        options={options}
        value=""
        placeholder="Select an item"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Choose item")).toBeInTheDocument();
    expect(screen.getByText("Select an item")).toBeInTheDocument();
  });

  test.each([null, undefined, ""])(
    "normalizes empty value %s to the placeholder",
    (value) => {
      render(
        <MSelect
          options={options}
          value={value}
          placeholder="Pick one"
          onChange={jest.fn()}
        />
      );

      expect(screen.getByText("Pick one")).toBeInTheDocument();
    }
  );

  test("normalizes an empty array to the placeholder", () => {
    render(
      <MSelect
        options={options}
        value={[]}
        placeholder="Pick one"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Pick one")).toBeInTheDocument();
  });

  test("gets the selected value from an option object", () => {
    render(
      <MSelect
        options={options}
        value={options[1]}
        placeholder="Pick one"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Beta")).toBeInTheDocument();
  });

  test("uses custom option label and value accessors", () => {
    const customOptions = [
      { key: "x", name: "Custom X" },
      { key: "y", name: "Custom Y" },
    ];

    render(
      <MSelect
        options={customOptions}
        value="y"
        placeholder="Choose"
        getOptionLabel={(option) => option.name}
        getOptionValue={(option) => option.key}
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Custom Y")).toBeInTheDocument();
  });

  test("returns the selected option object from onChange", () => {
    const onChange = jest.fn();
    render(
      <MSelect
        options={options}
        value=""
        placeholder="Choose"
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("option", { name: "Beta" }));

    expect(onChange).toHaveBeenCalledWith(options[1]);
  });

  test("renders a placeholder option that is disabled", () => {
    render(
      <MSelect
        options={options}
        value=""
        placeholder="Choose"
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    expect(screen.getByRole("option", { name: "Choose" })).toHaveAttribute(
      "aria-disabled",
      "true"
    );
  });

  test("calls onChange with null when the select emits an empty value", () => {
    const onChange = jest.fn();
    render(
      <MSelect
        options={options}
        value="alpha"
        placeholder="Choose"
        onChange={onChange}
      />
    );

    const hiddenInput = document.querySelector(
      'input[aria-hidden="true"].MuiSelect-nativeInput'
    );
    expect(hiddenInput).toBeInTheDocument();

    fireEvent.change(hiddenInput, { target: { value: "" } });

    expect(onChange).toHaveBeenCalledWith(null);
  });

  test("marks an option disabled when its disabled property is true", () => {
    render(
      <MSelect
        options={[
          ...options,
          { id: 4, value: "locked", label: "Locked", disabled: true },
        ]}
        value=""
        placeholder="Choose"
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    expect(screen.getByRole("option", { name: "Locked" })).toHaveAttribute(
      "aria-disabled",
      "true"
    );
  });

  test("renders a long selected label with truncation", () => {
    const longLabel = "This is a very long selected option label beyond limit";
    render(
      <MSelect
        options={[{ value: "long", label: longLabel }]}
        value="long"
        placeholder="Choose"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("This is a very long selected opti...")).toBeInTheDocument();
  });

  test("renders an empty label when a selected value is not found", () => {
    render(
      <MSelect
        options={options}
        value="not-found"
        placeholder="Choose"
        onChange={jest.fn()}
      />
    );

    expect(screen.queryByText("Alpha")).not.toBeInTheDocument();
  });

  test("does not call onChange when disabled", () => {
    const onChange = jest.fn();
    render(
      <MSelect
        options={options}
        value=""
        placeholder="Choose"
        disabled
        onChange={onChange}
      />
    );

    expect(screen.getByRole("combobox")).toHaveAttribute("aria-disabled", "true");
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe("MMultiSelect", () => {
  test("renders the placeholder when no values are selected", () => {
    render(
      <MMultiSelect
        options={options}
        value={[]}
        placeholder="Select items"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Select items")).toBeInTheDocument();
  });

  test("renders selected option labels", () => {
    render(
      <MMultiSelect
        options={options}
        value={["alpha", "gamma"]}
        placeholder="Select items"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Alpha, Gamma")).toBeInTheDocument();
  });

  test("filters out malformed options before rendering", () => {
    render(
      <MMultiSelect
        options={[
          ...options,
          null,
          {},
          { label: "Missing value" },
          { value: "missing-label" },
        ]}
        value={[]}
        placeholder="Select"
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    expect(screen.getByRole("option", { name: "Alpha" })).toBeInTheDocument();
    expect(
      screen.queryByRole("option", { name: "Missing value" })
    ).not.toBeInTheDocument();
  });

  test("selects all valid options when Select All is chosen", () => {
    const onChange = jest.fn();
    render(
      <MMultiSelect
        options={[...options, null, { label: "Bad" }]}
        value={[]}
        placeholder="Select"
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("option", { name: "Select All" }));

    expect(onChange).toHaveBeenCalledWith(["alpha", "beta", "gamma"]);
  });

  test("clears the selection when Select All is chosen while every valid option is selected", () => {
    const onChange = jest.fn();
    render(
      <MMultiSelect
        options={options}
        value={["alpha", "beta", "gamma"]}
        placeholder="Select"
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("option", { name: "Select All" }));

    expect(onChange).toHaveBeenCalledWith([]);
  });

  test("passes the selected values when an individual option is chosen", () => {
    const onChange = jest.fn();
    render(
      <MMultiSelect
        options={options}
        value={[]}
        placeholder="Select"
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("option", { name: "Beta" }));

    expect(onChange).toHaveBeenCalled();
    expect(onChange.mock.calls[0][0]).toContain("beta");
  });

  test("filters options using the search input", () => {
    render(
      <MMultiSelect
        options={options}
        value={[]}
        placeholder="Select"
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.change(screen.getByRole("textbox"), {
      target: { value: "gam" },
    });

    expect(screen.getByRole("option", { name: "Gamma" })).toBeInTheDocument();
    expect(screen.queryByRole("option", { name: "Alpha" })).not.toBeInTheDocument();
  });

  test("shows the no-results row when the search has no matches", () => {
    render(
      <MMultiSelect
        options={options}
        value={[]}
        placeholder="Select"
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.change(screen.getByRole("textbox"), {
      target: { value: "not-found" },
    });

    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  test("clears the search text when the menu closes", () => {
    render(
      <MMultiSelect
        options={options}
        value={[]}
        placeholder="Select"
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    const searchInput = screen.getByRole("textbox");
    fireEvent.change(searchInput, { target: { value: "alpha" } });
    fireEvent.keyDown(screen.getByRole("listbox"), {
      key: "Escape",
      code: "Escape",
    });

    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    openSelect(screen.getByRole("combobox"));
    expect(screen.getByRole("textbox")).toHaveValue("");
  });

  test("supports compact sizing and compact label truncation", () => {
    const longOptions = [
      {
        value: "long",
        label: "A very long compact selection label",
      },
    ];
    const { container } = render(
      <MMultiSelect
        options={longOptions}
        value={["long"]}
        placeholder="Select"
        isCompact
        onChange={jest.fn()}
      />
    );

    expect(container.querySelector(".MuiInputBase-root")).toHaveStyle({
      height: "36px",
    });
    expect(screen.getByText("A very long ...")).toBeInTheDocument();
  });

  test("uses compact sizing for the no-results row", () => {
    render(
      <MMultiSelect
        options={options}
        value={[]}
        placeholder="Select"
        isCompact
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.change(screen.getByRole("textbox"), {
      target: { value: "no-match" },
    });

    const noResults = screen.getByRole("option", { name: "No results" });
    expect(noResults).toHaveStyle({ minHeight: "28px" });
  });

  test("uses the regular label truncation limit", () => {
    const label = "A selected label that is deliberately longer than forty nine characters";
    render(
      <MMultiSelect
        options={[{ value: "long", label }]}
        value={["long"]}
        placeholder="Select"
      />
    );

    expect(
      screen.getByText("A selected label that is deliberately longer t...")
    ).toBeInTheDocument();
  });
});

describe("MAlarmSelect", () => {
  test("renders the label and multiple-select placeholder by default", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={[]}
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Alarm types")).toBeInTheDocument();
    expect(screen.getByText("Select Options...")).toBeInTheDocument();
  });

  test("normalizes a non-array value to an empty array in multiple mode", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value="alpha"
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Select Options...")).toBeInTheDocument();
  });

  test("renders the selected labels for multiple values", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={["alpha", "gamma"]}
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Alpha, Gamma")).toBeInTheDocument();
  });

  test("selects all filtered options and preserves existing selections", () => {
    const onChange = jest.fn();
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={["alpha"]}
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("menuitem", { name: /Select All/ }));

    expect(onChange).toHaveBeenCalledWith(["alpha", "beta", "gamma"]);
  });

  test("removes all currently filtered values when all are selected", () => {
    const onChange = jest.fn();
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={["alpha", "beta", "gamma"]}
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("menuitem", { name: /Select All/ }));

    expect(onChange).toHaveBeenCalledWith([]);
  });

  test("filters options using the search field", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={[]}
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.change(screen.getByPlaceholderText("Type here..."), {
      target: { value: "bet" },
    });

    expect(screen.getByRole("option", { name: /Beta/ })).toBeInTheDocument();
    expect(screen.queryByRole("option", { name: /Alpha/ })).not.toBeInTheDocument();
  });

  test("shows the no-results row when no alarm matches the search", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={[]}
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.change(screen.getByPlaceholderText("Type here..."), {
      target: { value: "unknown" },
    });

    expect(screen.getByText("No results found")).toBeInTheDocument();
  });

  test("safely filters options with a missing or falsy label", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={[
          { value: "empty-label", label: "" },
          { value: "null-label", label: null },
          { value: "alpha", label: "Alpha" },
        ]}
        value={[]}
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.change(screen.getByPlaceholderText("Type here..."), {
      target: { value: "alpha" },
    });

    expect(screen.getByRole("option", { name: /Alpha/ })).toBeInTheDocument();
    expect(
      screen.queryByRole("option", { name: /empty-label|null-label/ })
    ).not.toBeInTheDocument();
  });

  test("marks an item as already used and disables it", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={[
          ...options,
          { value: "used", label: "Used alarm", disabled: true },
        ]}
        value={[]}
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    expect(
      screen.getByRole("option", { name: "Used alarm (Already Used)" })
    ).toHaveAttribute("aria-disabled", "true");
  });

  test("passes selected values from the MUI change event to onChange", () => {
    const onChange = jest.fn();
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={[]}
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("option", { name: /Beta/ }));

    expect(onChange).toHaveBeenCalled();
    expect(onChange.mock.calls[0][0]).toContain("beta");
  });

  test("supports single-select mode and displays its placeholder", () => {
    render(
      <MAlarmSelect
        label="Alarm type"
        options={options}
        value={[]}
        multiple={false}
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Select Option...")).toBeInTheDocument();
  });

  test("normalizes an array to its first value in single-select mode", () => {
    render(
      <MAlarmSelect
        label="Alarm type"
        options={options}
        value={["beta", "gamma"]}
        multiple={false}
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("Beta")).toBeInTheDocument();
  });

  test("returns the selected single option value", () => {
    const onChange = jest.fn();
    render(
      <MAlarmSelect
        label="Alarm type"
        options={options}
        value=""
        multiple={false}
        onChange={onChange}
      />
    );

    openSelect(screen.getByRole("combobox"));
    fireEvent.click(screen.getByRole("option", { name: "Gamma" }));

    expect(onChange).toHaveBeenCalledWith("gamma");
  });

  test("shows an unknown selected value in single-select mode", () => {
    render(
      <MAlarmSelect
        label="Alarm type"
        options={options}
        value="external-alarm"
        multiple={false}
        onChange={jest.fn()}
      />
    );

    expect(screen.getByText("external-alarm")).toBeInTheDocument();
  });

  test("shows the indeterminate Select All checkbox for a partial selection", () => {
    render(
      <MAlarmSelect
        label="Alarm types"
        options={options}
        value={["alpha"]}
        onChange={jest.fn()}
      />
    );

    openSelect(screen.getByRole("combobox"));
    const selectAllRow = screen.getByRole("menuitem", {
      name: /Select All/,
    });
    const selectAllCheckbox = within(selectAllRow).getByRole("checkbox");
    expect(selectAllCheckbox).toHaveAttribute("aria-checked", "mixed");
    expect(selectAllCheckbox).toHaveAttribute("data-indeterminate", "true");
  });

  test("renders the dark mode palette without disabling the control", () => {
    render(
      <MAlarmSelect
        label="Dark alarm types"
        options={options}
        value={[]}
        isDark
        onChange={jest.fn()}
      />
    );

    expect(screen.getByRole("combobox")).toBeEnabled();
  });

  test("disables the select when disabled is true", () => {
    render(
      <MAlarmSelect
        label="Disabled alarm types"
        options={options}
        value={[]}
        disabled
        onChange={jest.fn()}
      />
    );

    expect(screen.getByRole("combobox")).toHaveAttribute("aria-disabled", "true");
  });

  test("does not call onChange from Select All in single-select mode", () => {
    const onChange = jest.fn();
    render(
      <MAlarmSelect
        label="Alarm type"
        options={options}
        value=""
        multiple={false}
        onChange={onChange}
      />
    );

    // Select All is intentionally not rendered for single-select mode.
    openSelect(screen.getByRole("combobox"));
    expect(screen.queryByRole("option", { name: /Select All/ })).not.toBeInTheDocument();
    expect(onChange).not.toHaveBeenCalled();
  });
});
