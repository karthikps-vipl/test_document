import { formatDateTime, getIpMaskedValueAndPosition, syslogSeverityConfig, syslogFacilityMap, severityConfig, workflowConfig, alarmStateConfig, getDeviceReachabilityColor } from '../../src/lib/utils';

describe('shared date and network utilities', () => {
  test('formats valid date and returns placeholder for empty input', () => {
    expect(formatDateTime(null)).toBe('-');
    expect(formatDateTime('not-a-date')).toBe('not-a-date');
    expect(formatDateTime('2026-01-02T03:04:05')).toMatch(/^2026-01-02 03:04:05$/);
  });
  test('masks IPv4 entry and rejects invalid edits without moving cursor', () => {
    expect(getIpMaskedValueAndPosition('192.168.1', 9, '')).toEqual({ maskedValue: '192.168.1', newCursorPosition: 9 });
    expect(getIpMaskedValueAndPosition('192.168.1.1.5', 13, '192.168.1.1')).toEqual({ maskedValue: '192.168.1.1', newCursorPosition: 13 });
    expect(getIpMaskedValueAndPosition('192.168.1.256', 13, '192.168.1.25')).toEqual({ maskedValue: '192.168.1.25', newCursorPosition: 13 });
  });
  test('exposes alarm and syslog lookup configurations', () => {
    expect(syslogSeverityConfig[0].label).toBe('EMERGENCY');
    expect(syslogSeverityConfig[7].label).toBe('DEBUG');
    expect(syslogFacilityMap[128]).toBe('LOCAL0');
    expect(severityConfig[2].label).toBe('Major');
    expect(workflowConfig.map((x) => x.value)).toEqual([2, 1, 0]);
    expect(alarmStateConfig).toEqual([{ label: 'RAISED', value: 1 }, { label: 'CLEARED', value: 0 }]);
  });
  test('maps device reachability to configured colors', () => {
    const device = { imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } };
    expect(getDeviceReachabilityColor(device)).toBe('#D3D3D3');
    expect(getDeviceReachabilityColor({ ...device, imResourceType: { imResourceStateInfo: { resourceStateId: 1 } }, isMaintainance: true })).toBe('#b8860b');
  });
});
