import React, { createContext, useContext } from "react";
import { jest } from "@jest/globals";
import { render, screen, within } from "@testing-library/react";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const ChartDataContext = createContext([]);

jest.unstable_mockModule("recharts", () => {
  const R = React;

  const ResponsiveContainer = ({ children, width, height }) =>
    R.createElement(
      "div",
      {
        "data-testid": "responsive-container",
        "data-width": String(width),
        "data-height": String(height),
      },
      children
    );

  const BarChart = ({ data = [], children, margin, barGap, barSize }) =>
    R.createElement(
      ChartDataContext.Provider,
      { value: data },
      R.createElement(
        "div",
        {
          "data-testid": "bar-chart",
          "data-margin": JSON.stringify(margin),
          "data-bar-gap": String(barGap),
          "data-bar-size": String(barSize),
        },
        children
      )
    );

  const XAxis = ({ dataKey, tick, children, ...props }) => {
    const data = useContext(ChartDataContext);
    return R.createElement(
      "div",
      {
        "data-testid": "x-axis",
        "data-key": dataKey,
        "data-interval": String(props.interval),
      },
      data.map((row, index) =>
        R.cloneElement(tick, {
          key: `tick-${index}`,
          x: index,
          y: 0,
          payload: { value: row[dataKey] },
        })
      ),
      children
    );
  };

  const YAxis = ({ children, allowDecimals, tick }) =>
    R.createElement(
      "div",
      {
        "data-testid": "y-axis",
        "data-allow-decimals": String(allowDecimals),
        "data-tick": JSON.stringify(tick),
      },
      children
    );

  const Legend = ({ content, verticalAlign, align }) => {
    const payload = [
      { value: "ACK", color: "#ack-color", payload: { fill: "#ack-payload" } },
      {
        value: "NOT_ACK",
        color: "#not-ack-color",
        payload: { fill: "#not-ack-payload" },
      },
      { value: "OTHER_COLOR", color: "#other-color", payload: { fill: "#other-payload" } },
      { value: "OTHER_PAYLOAD", payload: { fill: "#payload-fill" } },
    ];

    return R.createElement(
      "div",
      {
        "data-testid": "chart-legend",
        "data-vertical-align": verticalAlign,
        "data-align": align,
      },
      content({ payload })
    );
  };

  const Bar = ({ dataKey, name, stackId, fill, radius }) =>
    R.createElement("div", {
      "data-testid": `bar-${dataKey}`,
      "data-name": name,
      "data-stack-id": stackId,
      "data-fill": fill,
      "data-radius": radius ? JSON.stringify(radius) : "",
    });

  const CartesianGrid = ({ vertical, stroke }) =>
    R.createElement("div", {
      "data-testid": "cartesian-grid",
      "data-vertical": String(vertical),
      "data-stroke": stroke,
    });

  const Tooltip = ({
    cursor,
    formatter,
    labelFormatter,
    contentStyle,
    labelStyle,
    itemStyle,
  }) => {
    const formattedValue = formatter("7", "ACK");
    const formattedLabel = labelFormatter("Router");
    return R.createElement(
      "div",
      {
        "data-testid": "chart-tooltip",
        "data-cursor": JSON.stringify(cursor),
        "data-content-style": JSON.stringify(contentStyle),
        "data-label-style": JSON.stringify(labelStyle),
        "data-item-style": JSON.stringify(itemStyle),
        "data-formatted-value": JSON.stringify(formattedValue),
        "data-formatted-label": formattedLabel,
      },
      `${formattedLabel}: ${formattedValue.join(" / ")}`
    );
  };

  const Label = ({ value, position, offset, angle, style }) =>
    R.createElement(
      "span",
      {
        "data-testid": `axis-label-${value}`,
        "data-position": position,
        "data-offset": offset === undefined ? "" : String(offset),
        "data-angle": angle === undefined ? "" : String(angle),
        "data-style": JSON.stringify(style),
      },
      value
    );

  return {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    Label,
  };
});

const { default: AlarmWorkflowChart } = await import(
  "../../src/Pages/CnmsDashboard/CnmsAlarmSummary/components/AlarmWorkflowChart"
);

const chartBackground = "#f0f4f8";
const commonBorder = "1px solid rgb(190, 190, 190)";

const theme = createTheme({
  palette: {
    text: { primary: "#202020", secondary: "#606060" },
    background: { paper: "#ffffff", cardbg: "#fafafa" },
    divider: "#dddddd",
    custom: {
      chart: {
        chartbg: chartBackground,
        grid: "#eeeeee",
        text: "#505050",
        cursor: "#eeeeee",
        tooltipBg: "#fefefe",
        tooltipText: "#303030",
      },
      commonBorder,
    },
  },
});

const fallbackTheme = createTheme({
  palette: {
    text: { primary: "#111111", secondary: "#666666" },
    background: { paper: "#ffffff", cardbg: "#f7f7f7" },
    divider: "#cccccc",
    custom: {
      chart: {},
      commonBorder: "1px solid #aaaaaa",
    },
  },
});

const sampleData = [
  { terminal: "Router", ack: 4, notAck: 8 },
  { terminal: "LongTerminalName-01", ack: 7, notAck: 5 },
  { terminal: "", ack: 0, notAck: 0 },
  { terminal: "Switch", ack: 2, notAck: 3 },
];

const renderChart = (data = sampleData, selectedTheme = theme) =>
  render(
    <ThemeProvider theme={selectedTheme}>
      <AlarmWorkflowChart data={data} />
    </ThemeProvider>
  );

describe("AlarmWorkflowChart", () => {
  test("renders the responsive container and chart", () => {
    renderChart();

    expect(screen.getByTestId("responsive-container")).toHaveAttribute(
      "data-width",
      "100%"
    );
    expect(screen.getByTestId("responsive-container")).toHaveAttribute(
      "data-height",
      "100%"
    );
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
  });

  test("passes workflow data to the chart and formats terminal tick labels", () => {
    renderChart();

    const xAxis = screen.getByTestId("x-axis");
    expect(xAxis).toHaveAttribute("data-key", "terminal");
    expect(within(xAxis).getByText("Router")).toBeInTheDocument();
    expect(within(xAxis).getByText("LongTerminal...")).toBeInTheDocument();
    expect(within(xAxis).getByText("Switch")).toBeInTheDocument();

    const tickTexts = xAxis.querySelectorAll("text");
    expect(tickTexts).toHaveLength(4);
    expect(tickTexts[2]).toHaveTextContent("");
  });

  test("renders the terminal and alarm count axis labels", () => {
    renderChart();

    expect(screen.getByTestId("axis-label-Terminal Types")).toHaveAttribute(
      "data-position",
      "bottom"
    );
    expect(screen.getByTestId("axis-label-Terminal Types")).toHaveAttribute(
      "data-offset",
      "10"
    );
    expect(screen.getByTestId("axis-label-Alarm Count")).toHaveAttribute(
      "data-angle",
      "-90"
    );
    expect(screen.getByTestId("axis-label-Alarm Count")).toHaveAttribute(
      "data-position",
      "insideLeft"
    );
  });

  test("configures the grid and integer y-axis", () => {
    renderChart();

    expect(screen.getByTestId("cartesian-grid")).toHaveAttribute(
      "data-vertical",
      "false"
    );
    expect(screen.getByTestId("cartesian-grid")).toHaveAttribute(
      "data-stroke",
      "#eeeeee"
    );
    expect(screen.getByTestId("y-axis")).toHaveAttribute(
      "data-allow-decimals",
      "false"
    );
    expect(screen.getByTestId("y-axis")).toHaveAttribute(
      "data-tick",
      JSON.stringify({ fill: "#505050" })
    );
  });

  test("renders the ACK and NOT_ACK stacked bars", () => {
    renderChart();

    expect(screen.getByTestId("bar-ack")).toHaveAttribute("data-name", "ACK");
    expect(screen.getByTestId("bar-ack")).toHaveAttribute(
      "data-stack-id",
      "workflowStack"
    );
    expect(screen.getByTestId("bar-ack")).toHaveAttribute(
      "data-fill",
      "url(#cnmsAckGrad)"
    );

    expect(screen.getByTestId("bar-notAck")).toHaveAttribute(
      "data-name",
      "NOT_ACK"
    );
    expect(screen.getByTestId("bar-notAck")).toHaveAttribute(
      "data-stack-id",
      "workflowStack"
    );
    expect(screen.getByTestId("bar-notAck")).toHaveAttribute(
      "data-fill",
      "url(#cnmsNotAckGrad)"
    );
    expect(screen.getByTestId("bar-notAck")).toHaveAttribute(
      "data-radius",
      "[4,4,0,0]"
    );
  });

  test("renders both SVG gradient definitions with their color stops", () => {
    renderChart();

    expect(document.getElementById("cnmsAckGrad")).toBeInTheDocument();
    expect(document.getElementById("cnmsNotAckGrad")).toBeInTheDocument();

    const ackStops = document.querySelectorAll("#cnmsAckGrad stop");
    expect(ackStops).toHaveLength(2);
    expect(ackStops[0]).toHaveAttribute("offset", "19%");
    expect(ackStops[0]).toHaveAttribute("stop-color", "#198754");
    expect(ackStops[1]).toHaveAttribute("offset", "100%");
    expect(ackStops[1]).toHaveAttribute("stop-color", "#8BE0AE");

    const notAckStops = document.querySelectorAll("#cnmsNotAckGrad stop");
    expect(notAckStops).toHaveLength(2);
    expect(notAckStops[0]).toHaveAttribute("stop-color", "#E67E22");
    expect(notAckStops[1]).toHaveAttribute("stop-color", "#FFD08A");
  });

  test("renders the custom legend with ACK and NOT_ACK labels", () => {
    renderChart();

    const legend = screen.getByTestId("chart-legend");
    expect(within(legend).getByText("ACK")).toBeInTheDocument();
    expect(within(legend).getByText("NOT_ACK")).toBeInTheDocument();
    expect(within(legend).getByText("OTHER_COLOR")).toBeInTheDocument();
    expect(within(legend).getByText("OTHER_PAYLOAD")).toBeInTheDocument();
  });

  test("uses workflow gradients for known legend entries and fallback colors for others", () => {
    renderChart();

    const circles = screen.getByTestId("chart-legend").querySelectorAll("circle");
    expect(circles[0]).toHaveAttribute("fill", "url(#cnmsAckGrad)");
    expect(circles[1]).toHaveAttribute("fill", "url(#cnmsNotAckGrad)");
    expect(circles[2]).toHaveAttribute("fill", "#other-color");
    expect(circles[3]).toHaveAttribute("fill", "#payload-fill");
  });

  test("applies chart container dimensions, background, and border", () => {
    renderChart();

    const container = screen.getByTestId("responsive-container").parentElement;
    expect(container).toHaveStyle({
      width: "100%",
      height: "300px",
      borderRadius: "12px",
      padding: "8px",
      boxSizing: "border-box",
      background: chartBackground,
      border: commonBorder,
    });
  });

  test("uses theme fallback colors when chart-specific colors are absent", () => {
    renderChart(sampleData, fallbackTheme);

    expect(screen.getByTestId("cartesian-grid")).toHaveAttribute(
      "data-stroke",
      "#cccccc"
    );
    expect(screen.getByTestId("y-axis")).toHaveAttribute(
      "data-tick",
      JSON.stringify({ fill: "#666666" })
    );

    const tooltip = screen.getByTestId("chart-tooltip");
    const cursor = JSON.parse(tooltip.getAttribute("data-cursor"));
    const contentStyle = JSON.parse(
      tooltip.getAttribute("data-content-style")
    );
    const labelStyle = JSON.parse(tooltip.getAttribute("data-label-style"));
    const itemStyle = JSON.parse(tooltip.getAttribute("data-item-style"));

    expect(cursor.fill).toBe("rgba(128,128,128,0.08)");
    expect(contentStyle.backgroundColor).toBe("#ffffff");
    expect(contentStyle.color).toBe("#111111");
    expect(labelStyle.color).toBe("#111111");
    expect(itemStyle.color).toBe("#111111");
  });

  test("uses configured chart tooltip and cursor colors", () => {
    renderChart();

    const tooltip = screen.getByTestId("chart-tooltip");
    const cursor = JSON.parse(tooltip.getAttribute("data-cursor"));
    const contentStyle = JSON.parse(
      tooltip.getAttribute("data-content-style")
    );
    const labelStyle = JSON.parse(tooltip.getAttribute("data-label-style"));
    const itemStyle = JSON.parse(tooltip.getAttribute("data-item-style"));

    expect(cursor.fill).toBe("#eeeeee");
    expect(contentStyle.backgroundColor).toBe("#fefefe");
    expect(contentStyle.color).toBe("#303030");
    expect(labelStyle.color).toBe("#303030");
    expect(itemStyle.color).toBe("#303030");
  });

  test("formats tooltip values and terminal labels", () => {
    renderChart();

    const tooltip = screen.getByTestId("chart-tooltip");
    expect(tooltip).toHaveAttribute(
      "data-formatted-value",
      JSON.stringify(["7", "ACK"])
    );
    expect(tooltip).toHaveAttribute("data-formatted-label", "Terminal: Router");
  });

  test("uses the configured legend alignment and chart spacing", () => {
    renderChart();

    expect(screen.getByTestId("chart-legend")).toHaveAttribute(
      "data-vertical-align",
      "top"
    );
    expect(screen.getByTestId("chart-legend")).toHaveAttribute(
      "data-align",
      "right"
    );
    expect(screen.getByTestId("bar-chart")).toHaveAttribute("data-bar-gap", "8");
    expect(screen.getByTestId("bar-chart")).toHaveAttribute(
      "data-bar-size",
      "30"
    );
    expect(screen.getByTestId("bar-chart")).toHaveAttribute(
      "data-margin",
      JSON.stringify({ top: 0, right: 8, left: 0, bottom: 20 })
    );
  });

  test("accepts empty data and defaults data when the prop is omitted", () => {
    const { unmount } = renderChart([]);
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
    expect(screen.getByTestId("x-axis").querySelectorAll("text")).toHaveLength(0);

    unmount();
    render(
      <ThemeProvider theme={theme}>
        <AlarmWorkflowChart />
      </ThemeProvider>
    );
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
    expect(screen.getByTestId("x-axis").querySelectorAll("text")).toHaveLength(0);
  });
});
