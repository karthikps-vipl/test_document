import React from "react";
import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { ThemeProvider, createTheme } from "@mui/material/styles";

const mockDispatch = jest.fn();
const mockTopologyAxios = jest.fn();
const mockFitView = jest.fn();
const mockGetNodes = jest.fn();
const mockGetEdges = jest.fn();
const mockFlowProps = { current: null };
const mockUtilityOptions = { current: null };
const mockToast = jest.fn();
let mockSkipFlowInit = false;
let mockResizeObserverCallback = null;
let mockIsFullscreen = false;
const mockToggleFullscreen = jest.fn();
const mockDispatchContextAction = jest.fn();

const makeState = () => ({
  topologySlice: {
    nodes: [
      {
        id: "device-1",
        type: "commonNode",
        position: { x: 10, y: 20 },
        data: { resourceId: "R-1", resourceName: "Router 1", resourceIp: "10.1.1.1" },
      },
      {
        id: "device-2",
        type: "commonNode",
        position: { x: 80, y: 90 },
        data: { resourceId: "R-2", resourceName: "Router 2" },
      },
    ],
    edges: [{ id: "edge-1", source: "device-1", target: "device-2" }],
    rackLayout: [],
    currentViewTopology: true,
    undoStack: [],
    redoStack: [],
    undoStackRack: [],
    redoStackRack: [],
    currentNodeView: "simpleViewNode",
    switchTopology: "simpleViewNode",
  },
  nodeDetails: {
    isCnms: false,
    siteDetails: { terminalNickname: "MCT-MK-I Main" },
  },
});
let mockState = makeState();

jest.mock("react-redux", () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector(mockState),
}));

jest.mock("@xyflow/react", () => {
  return {
    ReactFlow: React.forwardRef((props, ref) => {
      mockFlowProps.current = props;
      React.useEffect(() => {
        if (!mockSkipFlowInit) {
          props.onInit?.({
            getNodes: () => mockGetNodes(),
            getEdges: () => mockGetEdges(),
          });
        }
      }, [props.onInit]);
      return React.createElement(
        "div",
        {
          ref,
          className: "react-flow",
          "data-testid": "react-flow",
        },
        React.createElement("div", {
          className: "react-flow__node",
          "data-id": "device-1",
          style: { width: "100px", height: "80px" },
        }),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-nodes-remove",
          onClick: () => props.onNodesChange?.([{ type: "remove", id: "device-1" }]),
        }, "Nodes remove"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-nodes-change",
          onClick: () => props.onNodesChange?.([{ type: "position", id: "device-1" }]),
        }, "Nodes change"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-edges-add",
          onClick: () => props.onEdgesChange?.([{ type: "add", item: { id: "edge-2" } }]),
        }, "Edges add"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-select-two",
          onClick: () => props.onSelectionChange?.({
            nodes: [{ id: "device-1" }, { id: "device-2" }],
            edges: [],
          }),
        }, "Select two"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-selection-end",
          onClick: () => props.onSelectionEnd?.(),
        }, "Selection end"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-pane-click",
          onClick: () => props.onPaneClick?.(),
        }, "Pane click"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-node-click",
          onClick: () => props.onNodeClick?.({}, {
            id: "blank-existing",
            type: "blankNode",
            data: { text: "Existing note", color: "#eeeeee", borderColor: "#222222" },
          }),
        }, "Node click"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-drop-device",
          onClick: () => props.onDrop?.({
            preventDefault: jest.fn(),
            clientX: 120,
            clientY: 160,
            dataTransfer: {
              getData: () => JSON.stringify({
                resourceId: "DROP-1",
                resourceName: "Dropped device",
                type: "commonNode",
              }),
            },
          }),
        }, "Drop device"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-drop-blank",
          onClick: () => props.onDrop?.({
            preventDefault: jest.fn(),
            clientX: 130,
            clientY: 170,
            dataTransfer: {
              getData: () => JSON.stringify({ type: "blankNode" }),
            },
          }),
        }, "Drop blank"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-drag-over",
          onClick: () => {
            const event = { preventDefault: jest.fn(), dataTransfer: { dropEffect: "none" } };
            props.onDragOver?.(event);
            window.__lastDragOverEvent = event;
          },
        }, "Drag over"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-edge-context",
          onClick: () => props.onEdgeContextMenu?.({
            preventDefault: jest.fn(),
            clientX: 500,
            clientY: 500,
          }, { id: "edge-1" }),
        }, "Edge context"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-node-context",
          onClick: () => props.onNodeContextMenu?.({
            preventDefault: jest.fn(),
            clientX: 35,
            clientY: 45,
          }, {
            id: "device-1",
            type: "commonNode",
            resourceIp: "10.20.30.40",
            resourceName: "Router 1",
          }),
        }, "Node context"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-node-enter",
          onClick: (event) => props.onNodeMouseEnter?.({
            currentTarget: event.currentTarget,
            clientX: 10,
            clientY: 10,
          }, { id: "device-1", type: "commonNode" }),
        }, "Node enter"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-node-leave",
          onClick: () => props.onNodeMouseLeave?.(),
        }, "Node leave"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-onconnect",
          onClick: () => mockUtilityOptions.current?.onEdgeCreated?.({
            id: "edge-created",
            target: "device-1",
          }),
        }, "Connect callback"),
        React.createElement("button", {
          type: "button",
          "data-testid": "flow-init-again",
          onClick: () => props.onInit?.({
            getNodes: () => mockGetNodes(),
            getEdges: () => mockGetEdges(),
          }),
        }, "Init again"),
        props.children,
      );
    }),
    Controls: () => React.createElement("div", { "data-testid": "flow-controls" }),
    Background: () => React.createElement("div", { "data-testid": "flow-background" }),
    applyEdgeChanges: (changes, edges) => {
      let next = [...edges];
      changes.forEach((change) => {
        if (change.type === "remove") next = next.filter((edge) => edge.id !== change.id);
        if (change.type === "add") next.push(change.item);
        if (change.type === "replace") next = next.map((edge) => edge.id === change.id ? change.item : edge);
      });
      return next;
    },
    applyNodeChanges: (changes, nodes) => {
      let next = [...nodes];
      changes.forEach((change) => {
        if (change.type === "remove") next = next.filter((node) => node.id !== change.id);
        if (change.type === "add") next.push(change.item);
        if (change.type === "replace") next = next.map((node) => node.id === change.id ? change.item : node);
      });
      return next;
    },
    useReactFlow: () => ({
      getNodesBounds: jest.fn(() => ({ x: 20, y: 30, width: 200, height: 100 })),
      screenToFlowPosition: jest.fn((point) => point),
      fitView: mockFitView,
      getNodes: () => mockGetNodes(),
    }),
  };
});

jest.mock("../../src/RestAPI/api/axiosApicall", () => ({
  TopologyAxios: (...args) => mockTopologyAxios(...args),
}));
jest.mock("../../src/utility/customHooks/useTopologyUtilityMethods", () => ({
  __esModule: true,
  default: (options) => {
    mockUtilityOptions.current = options;
    return { onConnect: jest.fn() };
  },
}));
jest.mock("@/utility/customHooks/useFullscreen", () => ({
  __esModule: true,
  default: () => ({ isFullscreen: mockIsFullscreen, toggleFullscreen: mockToggleFullscreen }),
}));
jest.mock("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");
  const ReactActual = jest.requireActual("react");
  return {
    ...actual,
    Popover: (props) => props.open
      ? ReactActual.createElement(
          "div",
          { "data-testid": "topo-view-popover" },
          props.children,
          ReactActual.createElement(
            "button",
            { type: "button", onClick: props.onClose },
            "Close view tools"
          )
        )
      : null,
  };
});
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeViewSwitcher", () => ({
  __esModule: true,
  default: () => <div data-testid="node-view-switcher">Node view switcher</div>,
}));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/TopologyEditActions", () => ({
  __esModule: true,
  default: (props) => (
    <div data-testid="topology-edit-actions">
      <button onClick={props.onPortMappingToggle}>Toggle port mapping</button>
      <button onClick={() => props.setIsDeleteAllConfirm(true)}>Open delete confirmation</button>
      <button onClick={() => props.setIsSaveConfirmOpen(true)}>Open save confirmation</button>
      <button onClick={props.onCanvasSave}>Save now</button>
    </div>
  ),
}));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodePalette/NodePalette", () => ({
  __esModule: true,
  default: (props) => (
    <div data-testid="node-palette">
      <button onClick={() => props.onImageUpload?.({ name: "bad.txt", type: "text/plain" })}>
        Upload invalid image
      </button>
      <button onClick={() => props.onImageUpload?.({ name: "map.png", type: "image/png" })}>
        Upload valid image
      </button>
    </div>
  ),
}));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/EdgeMenu", () => ({
  __esModule: true,
  default: () => <div data-testid="edge-menu">Edge menu</div>,
}));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/Tooltip/NodeTooltip", () => ({
  __esModule: true,
  default: (props) => <div data-testid="node-tooltip" data-node={props.activeNode?.id} />,
}));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/ImageNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/GroupNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/RackNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/RackFrameNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/RackResourceName", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/BlankNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/ImageOnly", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/SimpleViewNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/Topology/NodeTypes/UploadedImageNode", () => ({ __esModule: true, default: () => null }));
jest.mock("../../src/Pages/Rnmsdashboard/TopologyFabric/PortMapping", () => ({
  __esModule: true,
  default: () => <div data-testid="port-mapping">Port mapping panel</div>,
}));
jest.mock("../../src/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: (props) => props.open ? (
    <div data-testid="confirm-dialog">
      <div>{props.message}</div>
      <button onClick={props.onClose}>Cancel dialog</button>
      <button onClick={props.onConfirm}>{props.confirmText || "Confirm"}</button>
    </div>
  ) : null,
}));
jest.mock("@/components/Reusable/Modal/MModal", () => ({
  __esModule: true,
  default: (props) => props.open ? (
    <div data-testid="blank-node-modal">
      <div>{props.title}</div>
      <button onClick={props.handleClose}>Close modal</button>
      {props.children}
    </div>
  ) : null,
}));
jest.mock("@/components/Contextmenu/ContextMenu", () => ({
  __esModule: true,
  default: (props) => (
    <div data-testid="context-menu" data-view-only={String(!!props.viewOnly)}>
      <span>{props.node?.id}</span>
      <button onClick={() => props.onAction("inventory", props.node)}>Inventory action</button>
      <button onClick={() => props.onAction("addDevice", props.node)}>Add device action</button>
      <button onClick={() => props.onAction("pollingInterval", props.node)}>Polling action</button>
      <button onClick={() => props.onAction("alarmSuppression", props.node)}>Alarm suppression action</button>
      <button onClick={props.onClose}>Close context menu</button>
    </div>
  ),
}));
jest.mock("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: (...args) => mockToast(...args),
}));
jest.mock("@/core/actions/contextActionDispatcher", () => ({
  dispatchContextAction: (...args) => mockDispatchContextAction(...args),
}));

const theme = createTheme({
  palette: {
    custom: {
      reactFlow: { controlsBg: "#fff", controlsIcon: "#111", controlsBorder: "#ddd", backgroundDots: "#ccc" },
      icon: { iconFilter: "none" },
    },
    background: {
      paper: "#fff",
      secondary: "#eee",
      primary: "#fff",
      toplogybg: "#fff",
    },
  },
});

let Topology;
const renderTopology = (props = {}) =>
  render(
    <ThemeProvider theme={theme}>
      <Topology {...props} />
    </ThemeProvider>
  );

describe("Topology - broad interaction and workflow coverage", () => {
  beforeAll(async () => {
    window.isSuperAdmin = true;
    ({ default: Topology } = await import("@/Pages/Rnmsdashboard/Topology/Topology"));
  });

  beforeEach(() => {
    mockState = makeState();
    mockDispatch.mockClear();
    mockFitView.mockClear();
    mockToast.mockClear();
    mockDispatchContextAction.mockClear();
    mockTopologyAxios.mockReset();
    mockTopologyAxios.mockResolvedValue({ data: [{ linkId: 7, linkName: "WAN", linkStatus: "UP" }] });
    mockGetNodes.mockReturnValue([
      { id: "device-1", type: "commonNode", position: { x: 10, y: 20 }, data: { resourceId: "R-1", label: "Router" } },
      { id: "uploaded-1", type: "uploadedImage", position: { x: 30, y: 40 }, width: 160, height: 120, style: { width: 160, height: 120 }, data: { src: "data:image/png;base64,abc", width: 160, height: 120 } },
      { id: "blank-1", type: "blankNode", position: { x: 50, y: 60 }, data: { label: "Note" } },
    ]);
    mockGetEdges.mockReturnValue([{ id: "edge-1", source: "device-1", target: "device-2" }]);
    mockUtilityOptions.current = null;
    mockSkipFlowInit = false;
    mockIsFullscreen = false;
    mockToggleFullscreen.mockClear();
    mockResizeObserverCallback = null;
    global.ResizeObserver = class {
      constructor(callback) {
        mockResizeObserverCallback = callback;
      }
      observe = jest.fn();
      disconnect = jest.fn();
    };
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ nodes: [{ id: "saved-node" }], edges: [] }),
    });
  });

  afterEach(() => {
    delete global.ResizeObserver;
    delete global.fetch;
    delete global.FileReader;
    delete window.__lastDragOverEvent;
  });

  test("renders canvas, controls, node palette and topology toolbar", () => {
    renderTopology();
    expect(screen.getByTestId("react-flow")).toBeInTheDocument();
    expect(screen.getByTestId("flow-controls")).toBeInTheDocument();
    expect(screen.getByTestId("flow-background")).toBeInTheDocument();
    expect(screen.getByTestId("node-palette")).toBeInTheDocument();
    expect(screen.getByTestId("topology-edit-actions")).toBeInTheDocument();
  });

  test("loads existing link configuration and saved topology/rack JSON", async () => {
    renderTopology();
    await waitFor(() => expect(mockTopologyAxios).toHaveBeenCalledWith(
      expect.anything(),
      "get"
    ));
    await waitFor(() => expect(global.fetch).toHaveBeenCalledTimes(2));
    expect(global.fetch).toHaveBeenCalledWith("/savedReactflowTopology/MCT-MK-I.json");
    expect(global.fetch).toHaveBeenCalledWith("/savedRackNode/MCT-MK-I.json");
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("hydrateTopologyFromSavedTopology"),
    }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("hydrateRackFromSavedTopology"),
    }));
  });

  test("handles node changes and pushes undo history for add/remove changes", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-nodes-remove"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("onNodesChange") }));
  });

  test("handles ordinary node changes without adding undo history", () => {
    renderTopology();
    mockDispatch.mockClear();
    fireEvent.click(screen.getByTestId("flow-nodes-change"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("onNodesChange") }));
    expect(mockDispatch).not.toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") }));
  });

  test("handles edge changes and pushes topology undo history", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-edges-add"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("onEdgesChange") }));
  });

  test("groups multiple selected nodes into a new group node", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-select-two"));
    fireEvent.click(screen.getByTestId("flow-selection-end"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("setNodes"),
      payload: expect.arrayContaining([
        expect.objectContaining({ type: "groupNode" }),
      ]),
    }));
  });

  test("drops a device from the palette onto the topology canvas", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-drop-device"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("addNode"),
      payload: expect.arrayContaining([
        expect.objectContaining({
          id: "DROP-1",
          type: "commonNode",
          data: expect.objectContaining({ viewMode: "simpleViewNode", resourceId: "DROP-1" }),
        }),
      ]),
    }));
  });

  test("opens blank-node creation modal when a blank node is dropped", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-drop-blank"));
    expect(screen.getByTestId("blank-node-modal")).toBeInTheDocument();
    expect(screen.getByText("Create Blank Node")).toBeInTheDocument();
  });

  test("creates a blank node and dispatches addNode after form entry", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-drop-blank"));
    fireEvent.change(screen.getByLabelText("Node Label Text"), { target: { value: "Network note" } });
    const colors = screen.getAllByDisplayValue("#ffffff");
    fireEvent.change(colors[0], { target: { value: "#aabbcc" } });
    fireEvent.click(screen.getByRole("button", { name: "Add Node" }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("addNode"),
      payload: [expect.objectContaining({
        type: "blankNode",
        data: expect.objectContaining({
          label: "Network note",
          backgroundColor: "#aabbcc",
        }),
      })],
    }));
    expect(screen.queryByTestId("blank-node-modal")).not.toBeInTheDocument();
  });

  test("loads existing blank-node values for editing and dispatches updateNodeLabel", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-node-click"));
    expect(screen.getByText("Update Blank Node")).toBeInTheDocument();
    expect(screen.getByLabelText("Node Label Text")).toHaveValue("Existing note");
    fireEvent.change(screen.getByLabelText("Node Label Text"), { target: { value: "Updated note" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("updateNodeLabel") }));
  });

  test("closes blank-node modal and resets its editing state", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-drop-blank"));
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    expect(screen.queryByTestId("blank-node-modal")).not.toBeInTheDocument();
  });

  test("handles drag-over by preventing default and setting move drop effect", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-drag-over"));
    expect(window.__lastDragOverEvent.preventDefault).toHaveBeenCalled();
    expect(window.__lastDragOverEvent.dataTransfer.dropEffect).toBe("move");
  });

  test("opens edge context menu and deletes the selected edge", () => {
    renderTopology();
    act(() => {
      mockFlowProps.current.onEdgeContextMenu(
        {
          preventDefault: jest.fn(),
          clientX: 50,
          clientY: 60,
        },
        { id: "edge-1" }
      );
    });
    expect(screen.getByTestId("edge-menu")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "delete" }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("deleteLink"), payload: "edge-1" }));
  });

  test("opens device context menu and dispatches inventory context action", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-node-context"));
    expect(screen.getByTestId("context-menu")).toBeInTheDocument();
    expect(screen.getByText("device-1")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Inventory action" }));
    expect(mockDispatchContextAction).toHaveBeenCalledWith({
      action: "inventory",
      node: expect.objectContaining({ id: "device-1" }),
      source: "topology",
    });
    expect(screen.queryByTestId("context-menu")).not.toBeInTheDocument();
  });

  test("handles add-device context action and formats the IP mask", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-node-context"));
    fireEvent.click(screen.getByRole("button", { name: "Add device action" }));
    expect(screen.queryByTestId("context-menu")).not.toBeInTheDocument();
  });

  test("shows and clears the device tooltip on node hover and leave", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-node-enter"));
    expect(screen.getByTestId("node-tooltip")).toHaveAttribute("data-node", "device-1");
    fireEvent.click(screen.getByTestId("flow-node-leave"));
    expect(screen.queryByTestId("node-tooltip")).not.toBeInTheDocument();
  });

  test("toggles the port-mapping panel", () => {
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Toggle port mapping" }));
    expect(screen.getByTestId("port-mapping")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Toggle port mapping" }));
    expect(screen.queryByTestId("port-mapping")).not.toBeInTheDocument();
  });

  test("opens and closes the delete-all confirmation and deletes topology nodes", () => {
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Open delete confirmation" }));
    expect(screen.getByTestId("confirm-dialog")).toHaveTextContent("Topology");
    fireEvent.click(screen.getByRole("button", { name: "Yes" }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("deleteAllNodesAndEdges") }));
  });

  test("downloads optimized topology JSON from the current React Flow instance", () => {
    const createObjectURL = jest.fn(() => "blob:topology");
    const revokeObjectURL = jest.fn();
    Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, "revokeObjectURL", { configurable: true, value: revokeObjectURL });
    const clickSpy = jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Save now" }));
    expect(createObjectURL).toHaveBeenCalled();
    expect(clickSpy).toHaveBeenCalled();
    expect(mockToast).toHaveBeenCalledWith("Success!", "MCT-MK-I.json downloaded successfully", "success");
    clickSpy.mockRestore();
  });

  test("downloads rack JSON when the rack view is active", () => {
    mockState.topologySlice.currentViewTopology = false;
    const createObjectURL = jest.fn(() => "blob:rack");
    const revokeObjectURL = jest.fn();
    Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, "revokeObjectURL", { configurable: true, value: revokeObjectURL });
    const clickSpy = jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Save now" }));
    expect(createObjectURL).toHaveBeenCalled();
    expect(clickSpy).toHaveBeenCalled();
    expect(mockToast).toHaveBeenCalledWith("Success!", "MCT-MK-I.json downloaded successfully", "success");
    clickSpy.mockRestore();
  });

  test("shows an error toast when saving before React Flow has initialized", () => {
    mockSkipFlowInit = true;
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Save now" }));
    expect(mockToast).toHaveBeenCalledWith("Error", "Canvas not initialized", "error");
  });

  test("rejects unsupported image uploads", () => {
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Upload invalid image" }));
    expect(mockToast).toHaveBeenCalledWith("Invalid file", "Please upload a PNG or SVG image.", "error");
    expect(mockDispatch).not.toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("addNode") }));
  });

  test("adds a valid uploaded image node to the topology", async () => {
    global.FileReader = class {
      result = "data:image/png;base64,abc";
      readAsDataURL() {
        this.onload();
      }
    };
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Upload valid image" }));
    await waitFor(() => expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("addNode"),
      payload: [expect.objectContaining({
        type: "uploadedImage",
        width: 160,
        height: 120,
        data: expect.objectContaining({
          isUploadedImage: true,
          fileName: "map.png",
          mimeType: "image/png",
        }),
      })],
    })));
    expect(mockToast).toHaveBeenCalledWith("Success", "Image added to canvas.", "success");
    delete global.FileReader;
  });

  test("opens the link selector from the connect callback and updates edge configuration", async () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-onconnect"));
    expect(screen.getByText("Select Link")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByText("WAN")).toBeInTheDocument());
    fireEvent.click(screen.getByText("WAN"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("updateEdgeConfiguration"),
      payload: expect.objectContaining({
        edgeId: "edge-created",
        linkId: 7,
        linkName: "WAN",
        linkStatus: "UP",
      }),
    }));
    expect(screen.queryByText("Select Link")).not.toBeInTheDocument();
  });

  test("clears a link configuration when NONE is selected", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-onconnect"));
    fireEvent.click(screen.getByText("NONE"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("updateEdgeConfiguration"),
      payload: expect.objectContaining({
        edgeId: "edge-created",
        color: "grey",
        linkId: null,
        linkName: null,
        linkStatus: null,
      }),
    }));
  });

  test("closes an open link popup when the canvas pane is clicked", () => {
    renderTopology();
    // The connect hook callback opens the link popup only when the target DOM node is available.
    fireEvent.click(screen.getByTestId("flow-pane-click"));
    expect(screen.queryByText("Select Link")).not.toBeInTheDocument();
  });

  test("uses rack-specific actions when the rack view is active", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-nodes-remove"));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStackRack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("onNodesChangeOfRack") }));
  });

  test("uses rack-specific blank-node creation actions in rack view", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-drop-blank"));
    fireEvent.change(screen.getByLabelText("Node Label Text"), { target: { value: "Rack note" } });
    fireEvent.click(screen.getByRole("button", { name: "Add Node" }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("pushToUndoStackRack") }));
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({ type: expect.stringContaining("addNodeToRack") }));
  });

  test("handles failed saved-topology fetch without crashing", async () => {
    global.fetch = jest.fn().mockResolvedValue({ ok: false, json: async () => ({}) });
    const errorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    renderTopology();
    await waitFor(() => expect(errorSpy).toHaveBeenCalled());
    errorSpy.mockRestore();
  });


  test("maps uploaded-image hover to the smallest underlying device node", () => {
    renderTopology();
    const flowNode = screen.getByTestId("react-flow").querySelector('[data-id="device-1"]');
    flowNode.getBoundingClientRect = () => ({
      left: 0, right: 100, top: 0, bottom: 100, width: 100, height: 100,
    });
    mockGetNodes.mockReturnValue([
      { id: "device-1", type: "commonNode" },
      { id: "uploaded-1", type: "uploadedImage" },
    ]);

    act(() => {
      mockFlowProps.current.onNodeMouseEnter(
        { currentTarget: flowNode, clientX: 25, clientY: 25 },
        { id: "uploaded-1", type: "uploadedImage" }
      );
    });

    expect(screen.getByTestId("node-tooltip")).toHaveAttribute("data-node", "device-1");
  });

  test("clears the tooltip when an uploaded image has no device underneath", () => {
    renderTopology();
    const flowNode = screen.getByTestId("react-flow").querySelector('[data-id="device-1"]');
    flowNode.getBoundingClientRect = () => ({
      left: 0, right: 100, top: 0, bottom: 100, width: 100, height: 100,
    });
    mockGetNodes.mockReturnValue([
      { id: "uploaded-1", type: "uploadedImage" },
      { id: "blank-1", type: "blankNode" },
    ]);

    act(() => {
      mockFlowProps.current.onNodeMouseEnter(
        { currentTarget: flowNode, clientX: 25, clientY: 25 },
        { id: "uploaded-1", type: "uploadedImage" }
      );
    });

    expect(screen.queryByTestId("node-tooltip")).not.toBeInTheDocument();
  });

  test("forwards uploaded-image right-click to the underlying device context menu", () => {
    renderTopology();
    const flowNode = screen.getByTestId("react-flow").querySelector('[data-id="device-1"]');
    flowNode.getBoundingClientRect = () => ({
      left: 0, right: 100, top: 0, bottom: 100, width: 100, height: 100,
    });
    mockGetNodes.mockReturnValue([
      { id: "device-1", type: "commonNode" },
      { id: "uploaded-1", type: "uploadedImage" },
    ]);

    const preventDefault = jest.fn();
    act(() => {
      mockFlowProps.current.onNodeContextMenu(
        { preventDefault, clientX: 25, clientY: 25 },
        { id: "uploaded-1", type: "uploadedImage" }
      );
    });

    expect(preventDefault).toHaveBeenCalled();
    expect(screen.getByTestId("context-menu")).toBeInTheDocument();
    expect(screen.getByTestId("context-menu")).toHaveTextContent("device-1");
  });

  test("ignores uploaded-image right-click when no device is underneath", () => {
    renderTopology();
    const flowNode = screen.getByTestId("react-flow").querySelector('[data-id="device-1"]');
    flowNode.getBoundingClientRect = () => ({
      left: 0, right: 100, top: 0, bottom: 100, width: 100, height: 100,
    });
    mockGetNodes.mockReturnValue([
      { id: "uploaded-1", type: "uploadedImage" },
      { id: "blank-1", type: "blankNode" },
    ]);

    act(() => {
      mockFlowProps.current.onNodeContextMenu(
        { preventDefault: jest.fn(), clientX: 25, clientY: 25 },
        { id: "uploaded-1", type: "uploadedImage" }
      );
    });

    expect(screen.queryByTestId("context-menu")).not.toBeInTheDocument();
  });

  test("dispatches polling interval and alarm suppression context actions", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-node-context"));
    fireEvent.click(screen.getByRole("button", { name: "Polling action" }));
    expect(mockDispatchContextAction).toHaveBeenCalledWith({
      action: "pollingInterval",
      node: expect.objectContaining({ id: "device-1" }),
      source: "topology",
    });

    fireEvent.click(screen.getByTestId("flow-node-context"));
    fireEvent.click(screen.getByRole("button", { name: "Alarm suppression action" }));
    expect(mockDispatchContextAction).toHaveBeenCalledWith({
      action: "alarmSuppression",
      node: expect.objectContaining({ id: "device-1" }),
      source: "topology",
    });
  });

  test("passes read-only mode to the device context menu", () => {
    renderTopology({ readOnly: true });
    fireEvent.click(screen.getByTestId("flow-node-context"));
    expect(screen.getByTestId("context-menu")).toHaveAttribute("data-view-only", "true");
  });

  test("renders the exit-fullscreen icon and invokes the fullscreen toggle", () => {
    mockIsFullscreen = true;
    renderTopology();
    expect(screen.getByTitle("Exit Fullscreen")).toBeInTheDocument();
    expect(screen.getByTestId("FullscreenExitIcon")).toBeInTheDocument();
    fireEvent.click(screen.getByTitle("Exit Fullscreen"));
    expect(mockToggleFullscreen).toHaveBeenCalled();
  });

  test("handles rack JSON download failure", () => {
    mockState.topologySlice.currentViewTopology = false;
    const errorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    Object.defineProperty(URL, "createObjectURL", {
      configurable: true,
      value: jest.fn(() => { throw new Error("blob failure"); }),
    });
    renderTopology();
    // The save-confirmation dialog calls whatToSaveTopoOrRack(), which
    // selects the rack-specific save handler when currentViewTopology is false.
    fireEvent.click(screen.getByRole("button", { name: "Open save confirmation" }));
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    expect(mockToast).toHaveBeenCalledWith("Error", "Failed to download rack data", "error");
    expect(errorSpy).toHaveBeenCalled();
    errorSpy.mockRestore();
  });

  test("handles topology JSON download failure", () => {
    const errorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    Object.defineProperty(URL, "createObjectURL", {
      configurable: true,
      value: jest.fn(() => { throw new Error("blob failure"); }),
    });
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Save now" }));
    expect(mockToast).toHaveBeenCalledWith("Error", "Failed to download topology", "error");
    expect(errorSpy).toHaveBeenCalled();
    errorSpy.mockRestore();
  });

  test("reports an image upload error when FileReader fails", async () => {
    global.FileReader = class {
      readAsDataURL() {
        this.onerror();
      }
    };
    const errorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Upload valid image" }));
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith("Error", "Unable to load the selected image.", "error");
    });
    expect(errorSpy).toHaveBeenCalled();
    errorSpy.mockRestore();
  });

  test("reports an image upload error when FileReader returns a non-string result", async () => {
    global.FileReader = class {
      result = new ArrayBuffer(4);
      readAsDataURL() {
        this.onload();
      }
    };
    const errorSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Upload valid image" }));
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith("Error", "Unable to load the selected image.", "error");
    });
    expect(errorSpy).toHaveBeenCalled();
    errorSpy.mockRestore();
  });

  test("reports an image upload error when the React Flow canvas is unavailable", async () => {
    global.FileReader = class {
      result = "data:image/png;base64,abc";
      readAsDataURL() {
        this.onload();
      }
    };
    renderTopology();
    screen.getByTestId("react-flow").remove();
    fireEvent.click(screen.getByRole("button", { name: "Upload valid image" }));
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith("Error", "Canvas is not ready.", "error");
    });
  });

  test("does not fetch saved topology or rack while read-only and node data is empty", () => {
    mockState.topologySlice.nodes = [];
    renderTopology({ readOnly: true });
    expect(global.fetch).not.toHaveBeenCalled();
  });


  test("drops a regular device into rack view and adds its resource-name companion", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();
    act(() => {
      mockFlowProps.current.onDrop({
        preventDefault: jest.fn(),
        clientX: 120,
        clientY: 160,
        dataTransfer: {
          getData: () => JSON.stringify({
            resourceId: "RACK-DEVICE-1",
            resourceName: "Rack Router",
            type: "commonNode",
          }),
        },
      });
    });

    expect(mockDispatch).toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("pushToUndoStackRack") })
    );
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("addNodeToRack"),
      payload: expect.arrayContaining([
        expect.objectContaining({
          id: "RACK-DEVICE-1",
          type: "rackNode",
          position: { x: 120, y: 160 },
        }),
        expect.objectContaining({
          id: "RACK-DEVICE-1_NodeName",
          type: "rackResourceName",
          position: { x: 140, y: 170 },
        }),
      ]),
    }));
  });

  test("drops a rack frame without creating a resource-name companion", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();
    act(() => {
      mockFlowProps.current.onDrop({
        preventDefault: jest.fn(),
        clientX: 75,
        clientY: 95,
        dataTransfer: {
          getData: () => JSON.stringify({
            resourceId: "FRAME-1",
            resourceName: "Rack Frame",
            type: "rackFrame",
          }),
        },
      });
    });

    const rackAction = mockDispatch.mock.calls
      .map(([action]) => action)
      .find((action) => String(action?.type).includes("addNodeToRack"));
    expect(rackAction).toBeDefined();
    expect(rackAction.payload).toHaveLength(1);
    expect(rackAction.payload[0]).toEqual(expect.objectContaining({
      id: "FRAME-1",
      type: "rackFrame",
      position: { x: 75, y: 95 },
    }));
  });

  test("maps image-only palette drops to imageOnly node type", () => {
    renderTopology();
    act(() => {
      mockFlowProps.current.onDrop({
        preventDefault: jest.fn(),
        clientX: 12,
        clientY: 34,
        dataTransfer: {
          getData: () => JSON.stringify({
            resourceId: "IMAGE-ONLY-1",
            type: "imageOnly",
            resourceName: "Diagram",
          }),
        },
      });
    });

    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("addNode"),
      payload: [expect.objectContaining({
        id: "IMAGE-ONLY-1",
        type: "imageOnly",
      })],
    }));
  });

  test("adds uploaded images to rack state when rack view is active", async () => {
    mockState.topologySlice.currentViewTopology = false;
    global.FileReader = class {
      result = "data:image/png;base64,rack-image";
      readAsDataURL() {
        this.onload();
      }
    };
    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Upload valid image" }));

    await waitFor(() => {
      expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
        type: expect.stringContaining("addNodeToRack"),
        payload: [expect.objectContaining({
          type: "uploadedImage",
          data: expect.objectContaining({
            isUploadedImage: true,
            fileName: "map.png",
            mimeType: "image/png",
          }),
        })],
      }));
    });
    expect(mockDispatch).toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("pushToUndoStackRack") })
    );
    expect(mockToast).toHaveBeenCalledWith("Success", "Image added to canvas.", "success");
  });

  test("ignores right-clicks on non-device nodes other than uploaded images", () => {
    renderTopology();
    const preventDefault = jest.fn();
    act(() => {
      mockFlowProps.current.onNodeContextMenu(
        { preventDefault, clientX: 10, clientY: 20 },
        { id: "blank-note", type: "blankNode" }
      );
    });
    expect(preventDefault).toHaveBeenCalled();
    expect(screen.queryByTestId("context-menu")).not.toBeInTheDocument();
  });


  test("updates the blank-node border color when editing an existing blank node", () => {
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-node-click"));

    const borderColorInput = screen.getByDisplayValue("#222222");
    fireEvent.change(borderColorInput, { target: { value: "#123456" } });

    expect(screen.getByText("#123456")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));

    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("updateNodeLabel"),
      payload: expect.objectContaining({
        id: "blank-existing",
        borderColor: "#123456",
      }),
    }));
  });

  test("does not create a group when selection ends in rack view", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();
    fireEvent.click(screen.getByTestId("flow-select-two"));
    mockDispatch.mockClear();

    fireEvent.click(screen.getByTestId("flow-selection-end"));

    expect(mockDispatch).not.toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("setNodes") })
    );
    expect(mockDispatch).not.toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("pushToUndoStack") })
    );
  });

  test("shows the rack-save initialization error when React Flow has not initialized", () => {
    mockState.topologySlice.currentViewTopology = false;
    mockSkipFlowInit = true;
    renderTopology();

    fireEvent.click(screen.getByRole("button", { name: "Open save confirmation" }));
    fireEvent.click(screen.getByRole("button", { name: "Save" }));

    expect(mockToast).toHaveBeenCalledWith("Error", "Canvas not initialized", "error");
  });

  test("runs fitView after fullscreen, port-mapping and resize events", () => {
    jest.useFakeTimers();
    try {
      mockIsFullscreen = true;
      renderTopology();

      act(() => {
        jest.advanceTimersByTime(400);
      });

      expect(mockFitView).toHaveBeenCalledWith(expect.objectContaining({
        padding: 0.15,
        duration: 500,
        minZoom: 0.01,
        maxZoom: 50,
      }));
      expect(mockFitView).toHaveBeenCalledWith(expect.objectContaining({
        padding: 0.2,
        duration: 300,
      }));

      act(() => {
        mockResizeObserverCallback?.();
      });
      expect(mockFitView).toHaveBeenCalledWith(expect.objectContaining({
        padding: 0.15,
        duration: 300,
      }));
    } finally {
      jest.useRealTimers();
    }
  });


  test("logs link-configuration API errors without breaking the topology", async () => {
    mockTopologyAxios.mockRejectedValueOnce(new Error("link configuration unavailable"));
    const errorSpy = jest.spyOn(console, "error").mockImplementation(() => {});

    renderTopology();

    await waitFor(() => {
      expect(errorSpy).toHaveBeenCalledWith(expect.objectContaining({
        message: "link configuration unavailable",
      }));
    });
    expect(screen.getByTestId("react-flow")).toBeInTheDocument();
    errorSpy.mockRestore();
  });

  test("updates an existing blank node in rack view and pushes rack undo history", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();

    fireEvent.click(screen.getByTestId("flow-node-click"));
    fireEvent.change(screen.getByLabelText("Node Label Text"), {
      target: { value: "Rack note updated" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));

    expect(mockDispatch).toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("pushToUndoStackRack") })
    );
    expect(mockDispatch).toHaveBeenCalledWith(expect.objectContaining({
      type: expect.stringContaining("updateNodeLabel"),
      payload: expect.objectContaining({
        id: "blank-existing",
        label: "Rack note updated",
      }),
    }));
  });

  test("warns and skips saved topology and rack loads when terminal nickname is whitespace", async () => {
    mockState.nodeDetails.siteDetails.terminalNickname = "   ";
    const warnSpy = jest.spyOn(console, "warn").mockImplementation(() => {});

    renderTopology();

    await waitFor(() => {
      expect(warnSpy).toHaveBeenCalledWith("Terminal type not available");
    });
    expect(warnSpy).toHaveBeenCalledTimes(2);
    expect(global.fetch).not.toHaveBeenCalled();
    warnSpy.mockRestore();
  });

  test("preserves unselected nodes when grouping a subset of topology nodes", () => {
    mockState.topologySlice.nodes.push({
      id: "device-3",
      type: "commonNode",
      position: { x: 150, y: 160 },
      data: { resourceId: "R-3", resourceName: "Router 3" },
    });
    renderTopology();

    // Commit selection state first so onSelectionEnd sees the updated selection.
    act(() => {
      mockFlowProps.current.onSelectionChange({
        nodes: [{ id: "device-1" }, { id: "device-2" }],
        edges: [],
      });
    });

    act(() => {
      mockFlowProps.current.onSelectionEnd();
    });

    const setNodesAction = mockDispatch.mock.calls
      .map(([action]) => action)
      .find((action) => String(action?.type).includes("setNodes"));

    expect(setNodesAction).toBeDefined();
    expect(setNodesAction.payload).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: "device-1", parentNode: expect.any(String) }),
      expect.objectContaining({ id: "device-2", parentNode: expect.any(String) }),
      expect.objectContaining({ id: "device-3" }),
      expect.objectContaining({ type: "groupNode" }),
    ]));
  });

  test("deletes all rack nodes using rack-specific history and action", () => {
    mockState.topologySlice.currentViewTopology = false;
    renderTopology();

    fireEvent.click(screen.getByRole("button", { name: "Open delete confirmation" }));
    fireEvent.click(screen.getByRole("button", { name: "Yes" }));

    expect(mockDispatch).toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("pushToUndoStackRack") })
    );
    expect(mockDispatch).toHaveBeenCalledWith(
      expect.objectContaining({ type: expect.stringContaining("deleteAllNodesAndEdgesOfRack") })
    );
  });

  test("closes the topology view tools popover", () => {
    const { container } = renderTopology();
    const viewToolsButton = Array.from(container.querySelectorAll("button"))
      .find((button) => button.querySelector("img"));

    expect(viewToolsButton).toBeTruthy();
    fireEvent.click(viewToolsButton);

    expect(screen.getByTestId("topo-view-popover")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Close view tools" }));
    expect(screen.queryByTestId("topo-view-popover")).not.toBeInTheDocument();
  });

  test("saves topology through the save-confirmation branch", () => {
    const createObjectURL = jest.fn(() => "blob:topology-confirmed");
    const revokeObjectURL = jest.fn();
    Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, "revokeObjectURL", { configurable: true, value: revokeObjectURL });
    const clickSpy = jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});

    renderTopology();
    fireEvent.click(screen.getByRole("button", { name: "Open save confirmation" }));
    fireEvent.click(screen.getByRole("button", { name: "Save" }));

    expect(createObjectURL).toHaveBeenCalled();
    expect(clickSpy).toHaveBeenCalled();
    expect(mockToast).toHaveBeenCalledWith("Success!", "MCT-MK-I.json downloaded successfully", "success");
    clickSpy.mockRestore();
  });

  test("uses the terminal type override for saved JSON filenames", async () => {
    renderTopology({ terminalTypeOverride: "CNMS-Override", readOnly: true });
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith("/savedReactflowTopology/CNMS-Override.json"));
  });
});
