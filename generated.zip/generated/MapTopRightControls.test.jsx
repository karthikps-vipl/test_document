import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import MapTopRightControls from "../../src/Pages/CnmsDashboard/CnmsMap/components/MapTopRightControls";

jest.mock("@/assets/CNMS/Filter site.svg", () => "settings.svg");
jest.mock("@/assets/CNMS/Filter Birdeye.svg", () => "filter.svg");
jest.mock("@/assets/SVGIcons/ALL_Reports_View.svg", () => "up.svg");

describe("MapTopRightControls", () => {
  let setFilterAnchorEl;
  let setConfigAnchorEl;
  let setIsMiniMapOpen;

  beforeEach(() => {
    setFilterAnchorEl = jest.fn();
    setConfigAnchorEl = jest.fn();
    setIsMiniMapOpen = jest.fn();
  });

  test("renders all three control buttons", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    expect(screen.getByTitle("Filter")).toBeInTheDocument();
    expect(screen.getByTitle("Settings")).toBeInTheDocument();
    expect(screen.getByTitle("Min map")).toBeInTheDocument();
  });

  test("renders filter image", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    expect(screen.getByAltText("filter")).toHaveAttribute("src", "filter.svg");
  });

  test("renders settings image", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    expect(screen.getByAltText("settings")).toHaveAttribute(
      "src",
      "settings.svg"
    );
  });

  test("renders minimap image", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    expect(screen.getByAltText("min map")).toHaveAttribute("src", "up.svg");
  });

  test("opens filter using currentTarget", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    const button = screen.getByTitle("Filter");

    fireEvent.click(button);

    expect(setFilterAnchorEl).toHaveBeenCalledTimes(1);
    expect(setFilterAnchorEl).toHaveBeenCalledWith(button);
  });

  test("opens settings using currentTarget", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    const button = screen.getByTitle("Settings");

    fireEvent.click(button);

    expect(setConfigAnchorEl).toHaveBeenCalledTimes(1);
    expect(setConfigAnchorEl).toHaveBeenCalledWith(button);
  });

  test("toggles minimap from closed to open", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    fireEvent.click(screen.getByTitle("Min map"));

    expect(setIsMiniMapOpen).toHaveBeenCalledWith(true);
  });

  test("toggles minimap from open to closed", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={true}
      />
    );

    fireEvent.click(screen.getByTitle("Min map"));

    expect(setIsMiniMapOpen).toHaveBeenCalledWith(false);
  });

  test("uses correct rotation when minimap is open", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={true}
      />
    );

    expect(screen.getByAltText("min map")).toHaveStyle({
      transform: "rotate(90deg)",
    });
  });

  test("uses correct rotation when minimap is closed", () => {
    render(
      <MapTopRightControls
        setFilterAnchorEl={setFilterAnchorEl}
        setConfigAnchorEl={setConfigAnchorEl}
        setIsMiniMapOpen={setIsMiniMapOpen}
        isMiniMapOpen={false}
      />
    );

    expect(screen.getByAltText("min map")).toHaveStyle({
      transform: "rotate(-90deg)",
    });
  });
});
