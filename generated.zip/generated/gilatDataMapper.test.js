import {
  transformGilatRfCluster,
  transformGilatCpeGroup,
  transformGilatCpeSection,
} from "../../src/Pages/Rnmsdashboard/GilatSatcomModule/utils/gilatDataMapper";

describe("transformGilatRfCluster", () => {
  test("returns an empty object for non-array input", () => {
    expect(transformGilatRfCluster(null)).toEqual({});
    expect(transformGilatRfCluster({})).toEqual({});
  });

  test("maps clusters and network segment sections", () => {
    const result = transformGilatRfCluster([{
      rfClusterCode: "RF-1",
      networkSegmentList: [{
        nsID: 7,
        general: { name: "segment" },
        fwdLink: [{ id: 1 }],
        returnLink: null,
        channelList: ["channel"],
        ipConnectivity: [],
      }],
    }]);
    expect(result["Cluster Code-RF-1"]["NS-7"]).toEqual({
      General: [{ name: "segment" }],
      "Forward Link Section": [{ id: 1 }],
      "Return Link Section": [],
      "Return Channel Section": ["channel"],
      "IP Connectivity Section": [],
    });
  });

  test("supports misspelled legacy cluster code and fallback identifiers", () => {
    const result = transformGilatRfCluster([
      { rfClusterClode: "legacy", networkSegmentList: [{}] },
      { networkSegmentList: [{}] },
    ]);
    expect(result["Cluster Code-legacy"]["NS-1"].General).toEqual([]);
    expect(result["Cluster Code-Unknown-2"]["NS-1"]).toBeDefined();
  });

  test("defaults missing cluster lists to an empty object", () => {
    expect(transformGilatRfCluster()).toEqual({});
  });
});

describe("transformGilatCpeGroup", () => {
  test("normalizes managed group and SLA tables", () => {
    expect(transformGilatCpeGroup({
      managedCPEGroup: { name: "managed" },
      slaTable: {
        generalTable: [{ id: 1 }],
        forwardTable: { id: 2 },
        returnTable: null,
      },
    })).toEqual({
      "Managed Group": [{ name: "managed" }],
      "SLA Profile": {
        General: [{ id: 1 }],
        "Forward Table": [{ id: 2 }],
        "Return Table": [],
      },
    });
  });

  test("handles missing CPE group", () => {
    expect(transformGilatCpeGroup()).toEqual({
      "Managed Group": [],
      "SLA Profile": { General: [], "Forward Table": [], "Return Table": [] },
    });
  });
});

describe("transformGilatCpeSection", () => {
  test("normalizes arrays, objects and invalid values", () => {
    expect(transformGilatCpeSection([{ id: 1 }])).toEqual([{ id: 1 }]);
    expect(transformGilatCpeSection({ id: 2 })).toEqual([{ id: 2 }]);
    expect(transformGilatCpeSection(null)).toEqual([]);
  });
});
