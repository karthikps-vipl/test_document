import { MODAL_CONFIG } from "../../src/core/modal/modalConfig";
import { AntpConfig, loadLocal, setOid } from "../../src/components/Dialogs/ANTP/AntpConfig";
import { AntpConfig as AntpConstantsConfig, loadLocal as antpLocal, setOid as antpSetOid } from "../../src/Pages/Rnmsdashboard/MK-I/ANTP/utils/antpConstants";
import { WIDGET_TYPES, WIDGET_LABELS } from "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/SNMPConfigurator/widgets/types/widgetTypes";
import { severityConfig } from "../../src/Pages/Rnmsdashboard/AlarmDrawer/utils";

describe("modal configuration", () => {
  test("defines common modal widths", () => {
    expect(MODAL_CONFIG.inventory.maxWidth).toBe("md");
    expect(MODAL_CONFIG.status.maxWidth).toBe("xl");
    expect(MODAL_CONFIG.deleteDevice.maxWidth).toBe("xs");
    expect(MODAL_CONFIG.addAlarmSuppression.customSx.width).toBe("650px");
  });
});

describe("ANTP OID configuration", () => {
  test("exports configuration maps with expected keys", () => {
    expect(Object.keys(AntpConfig).length).toBeGreaterThan(10);
    expect(AntpConfig.Mode).toMatch(/1\.3\.6\.1\.4\.1/);
    expect(loadLocal).toHaveProperty("Altitude");
    expect(setOid).toHaveProperty("Set Remote GPS");
  });
  test("the MK-I ANTP constants preserve required OID mappings", () => {
    expect(AntpConstantsConfig.Mode).toBe(AntpConfig.Mode);
    expect(antpLocal).toHaveProperty("Station Latitude (deg)");
    expect(antpSetOid).toHaveProperty("Set Local GPS");
  });
});

describe("SNMP widget type labels", () => {
  test("every widget type has a display label", () => {
    Object.values(WIDGET_TYPES).forEach((type) => {
      expect(WIDGET_LABELS[type]).toEqual(expect.any(String));
      expect(WIDGET_LABELS[type].length).toBeGreaterThan(0);
    });
    expect(Object.keys(WIDGET_TYPES)).toHaveLength(Object.keys(WIDGET_LABELS).length);
  });
});

describe("alarm severity configuration", () => {
  test("defines major, minor and warning styles", () => {
    expect(severityConfig.MAJOR.label).toBe("Major");
    expect(severityConfig.MINOR.label).toBe("Minor");
    expect(severityConfig.WARNING.label).toBe("Warning");
  });
});
