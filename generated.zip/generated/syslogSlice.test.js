import reducer, {
  applySyslogAuditEvent, toggleStar, toggleSpam, setSelectedDate, setSelectedModel,
  setStompConnected, clearAuditRows,
} from '../../src/store/features/SyslogAI/syslogSlice';

describe('syslog audit reducer', () => {
  test('tracks started and status lifecycle events', () => {
    let state = reducer(undefined, applySyslogAuditEvent({ type: 'started', run_id: 'run-1' }));
    expect(state).toMatchObject({ isRunning: true, runId: 'run-1' });
    state = reducer(state, applySyslogAuditEvent({ type: 'status', running: false, run_id: 'run-2', selected_date: '2026-11-20' }));
    expect(state).toMatchObject({ isRunning: false, runId: 'run-2', selectedDate: '2026-11-20' });
  });
  test('creates batch placeholder and updates batch result', () => {
    let state = reducer(undefined, applySyslogAuditEvent({ type: 'batch_started', run_id: 'run-1', batch_index: 2, database_rows: 10, model: 'local' }));
    expect(state.allRows[0]).toMatchObject({ id: 'run-1-batch-2', batch: 'Batch 2', records: 10, processing: true, model: 'local' });
    state = reducer(state, applySyslogAuditEvent({ type: 'batch', run_id: 'run-1', batch_index: 2, database_rows: 10, stats: { critical: 1, moderate: 2, low: 3 }, rows: [{ id: 1 }] }));
    expect(state.allRows[0]).toMatchObject({ crit: 1, mod: 2, low: 3, liveRows: [{ id: 1 }], processing: false });
    expect(state.allRows).toHaveLength(1);
  });
  test('enriches existing batch and ignores unknown batch enrichment', () => {
    let state = reducer(undefined, applySyslogAuditEvent({ type: 'batch', run_id: 'run', batch_index: 1 }));
    state = reducer(state, applySyslogAuditEvent({ type: 'batch_enriched', run_id: 'run', batch_index: 1, stats: { critical: 4 }, rows: [{ id: 'enriched' }] }));
    expect(state.allRows[0]).toMatchObject({ crit: 4, enriched: true, liveRows: [{ id: 'enriched' }] });
    expect(reducer(undefined, applySyslogAuditEvent({ type: 'batch_enriched', run_id: 'x', batch_index: 5 })).allRows).toEqual([]);
  });
  test('stopped event creates selected-date download URLs and clears running state', () => {
    let state = reducer(undefined, setSelectedDate('2026-11-20'));
    state = reducer(state, applySyslogAuditEvent({ type: 'stopped', run_id: 'run-1' }));
    expect(state.isRunning).toBe(false);
    expect(state.runId).toBeNull();
    expect(state.masterFiles.pdf).toContain('selected_date=2026-11-20');
    expect(state.masterFiles.excel).toContain('/xlsx?');
    expect(state.lastEvent.type).toBe('stopped');
  });
  test('error event stores message and defaults when no message is supplied', () => {
    let state = reducer(undefined, applySyslogAuditEvent({ type: 'error', message: 'Database unavailable' }));
    expect(state).toMatchObject({ isRunning: false, lastError: 'Database unavailable' });
    state = reducer(state, applySyslogAuditEvent({ type: 'error' }));
    expect(state.lastError).toBe('Audit failed');
  });
  test('toggles star/spam ids and clears audit rows', () => {
    let state = reducer(undefined, toggleStar('batch-1'));
    state = reducer(state, toggleStar('batch-1'));
    state = reducer(state, toggleSpam('batch-2'));
    state = reducer(state, setSelectedModel('model-x'));
    state = reducer(state, setStompConnected(true));
    expect(state.starredRows).toEqual([]);
    expect(state.spamRows).toEqual(['batch-2']);
    expect(state.selectedModel).toBe('model-x');
    expect(state.isStompConnected).toBe(true);
    state = reducer(state, clearAuditRows());
    expect(state.allRows).toEqual([]);
    expect(state.masterFiles).toEqual({ pdf: null, excel: null });
    expect(state.lastEvent).toBeNull();
  });
  test('ignores empty and informational events', () => {
    const initial = reducer(undefined, { type: '@@INIT' });
    expect(reducer(initial, applySyslogAuditEvent(null))).toEqual(initial);
    expect(reducer(initial, applySyslogAuditEvent({ type: 'heartbeat' }))).toEqual(initial);
    expect(reducer(initial, applySyslogAuditEvent({ type: 'unrecognized' }))).toEqual(initial);
  });
});
