import reducer, {
  setToolTipOptions, setTopologyTooltipOptions,
} from "../../src/store/features/Tooltip/toolTipSlice";

describe("toolTipOptionsSlice", () => {
  const initialState = {
    toolTipOptions: [],
    mapTooltipOptions: {},
    topologyToolTipOptions: {},
  };

  test("returns the initial state", () => {
    expect(reducer(undefined, { type: "@@INIT" })).toEqual(initialState);
  });

  test("stores tooltip options and updates map and topology settings", () => {
    const topologyOptions = { enabled: true, fields: ["name", "status"] };
    const result = reducer(initialState, setToolTipOptions([
      { id: 1, value: { mapEnabled: true } },
      { id: 2, value: JSON.stringify(topologyOptions) },
    ]));
    expect(result.toolTipOptions).toHaveLength(2);
    expect(result.mapTooltipOptions).toEqual({ mapEnabled: true });
    expect(result.topologyToolTipOptions).toEqual(topologyOptions);
  });

  test("updates only topology tooltip settings through its dedicated action", () => {
    const next = reducer(initialState, setTopologyTooltipOptions({ enabled: false }));
    expect(next.topologyToolTipOptions).toEqual({ enabled: false });
    expect(next.mapTooltipOptions).toEqual({});
  });

  test("handles an empty tooltip options array", () => {
    const next = reducer(initialState, setToolTipOptions([]));
    expect(next.toolTipOptions).toEqual([]);
    expect(next.mapTooltipOptions).toEqual({});
    expect(next.topologyToolTipOptions).toEqual({});
  });
});
