import { extractOidsFromLayout, applyOidOperation } from "../../src/core/utils/oidExtractor";

describe("extractOidsFromLayout", () => {
  test("collects unique static OIDs and table mapping OIDs", () => {
    const result = extractOidsFromLayout({
      status: [{
        widget: [
          { data: [{ oid: "1.2.3" }, { oid: "1.2.3" }, { value: 4 }] },
          { mapForDisplay: { colA: "1.2.4", colB: "1.2.5" } },
        ],
      }],
    });
    expect(result).toEqual({
      staticOids: ["1.2.3"],
      tableOids: ["1.2.4", "1.2.5"],
    });
  });

  test("returns empty arrays for missing or empty layouts", () => {
    expect(extractOidsFromLayout()).toEqual({ staticOids: [], tableOids: [] });
    expect(extractOidsFromLayout({ status: [] })).toEqual({ staticOids: [], tableOids: [] });
  });

  test("ignores widgets without OID data", () => {
    expect(extractOidsFromLayout({ status: [{ widget: [{ data: [] }, {}] }] }))
      .toEqual({ staticOids: [], tableOids: [] });
  });
});

describe("applyOidOperation", () => {
  test("returns dash for nullish values", () => {
    expect(applyOidOperation(null, { operation: "divide" })).toBe("-");
    expect(applyOidOperation(undefined)).toBe("-");
  });

  test("returns original value when mapping is absent or unknown", () => {
    expect(applyOidOperation("42")).toBe("42");
    expect(applyOidOperation("42", {})).toBe("42");
    expect(applyOidOperation("42", { operation: "unknown" })).toBe("42");
  });

  test("applies divide and multiply operations", () => {
    expect(applyOidOperation("20", { operation: "divide", operator_map: 4 })).toBe(5);
    expect(applyOidOperation("20", { operation: "multiply", operator_map: 3 })).toBe(60);
  });

  test("uses one as the default operator", () => {
    expect(applyOidOperation("20", { operation: "divide" })).toBe(20);
    expect(applyOidOperation("20", { operation: "multiply", operator_map: 0 })).toBe(20);
  });

  test("formats system uptime ticks", () => {
    expect(applyOidOperation(90061, { operation: "removemilisecsysuptime" }))
      .toBe("1 D : 1 H : 1 M : 1 S");
  });
});
