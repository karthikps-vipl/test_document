const mockToast = jest.fn();
const mockHtml2Canvas = jest.fn();

jest.mock('jspdf', () => ({ jsPDF: jest.fn() }));
jest.mock('jspdf-autotable', () => jest.fn());
jest.mock('html2canvas', () => (...args) => mockHtml2Canvas(...args));
jest.mock('@/components/Reusable/Toast/Toast', () => ({
  default: (...args) => mockToast(...args),
}));

import { getChartImageBase64, exportToPDF, exportToCSV, exportSingleChartWithTable } from '../../src/components/Reusable/Pdf/downloadPdf';

describe('PDF and CSV export utilities', () => {
  beforeEach(() => {
    mockToast.mockClear();
    mockHtml2Canvas.mockReset();
    global.URL.createObjectURL = jest.fn(() => 'blob:test-url');
  });

  test('returns null when a chart element does not exist', async () => {
    expect(await getChartImageBase64('missing-chart')).toBeNull();
    expect(mockHtml2Canvas).not.toHaveBeenCalled();
  });

  test('does not create a PDF when there is no data', async () => {
    await exportToPDF('Alarm Report', [], [], 'alarms', {});
    expect(mockToast).toHaveBeenCalledWith('Information', 'No data available to export', 'info');
  });

  test('exports CSV headers and rows while excluding action columns', () => {
    const click = jest.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {});
    exportToCSV('alarms', [
      { uid: 'sno', name: 'No.' },
      { uid: 'alarmName', name: 'Alarm' },
      { uid: 'severity', name: 'Severity' },
      { uid: 'actions', name: 'Actions' },
    ], [
      { alarmName: 'Link Down', severity: 2 },
      { alarmName: 'Power "Fault"', severity: -1 },
    ]);
    expect(global.URL.createObjectURL).toHaveBeenCalled();
    expect(click).toHaveBeenCalledTimes(1);
    click.mockRestore();
  });

  test('returns safely when a single-chart export target is missing', async () => {
    const error = jest.spyOn(console, 'error').mockImplementation(() => {});
    await exportSingleChartWithTable('Chart', [], [], 'missing-target', 'chart');
    expect(error).toHaveBeenCalledWith('Target container not found in DOM');
    error.mockRestore();
  });
});
