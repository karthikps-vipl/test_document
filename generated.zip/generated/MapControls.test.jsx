import React from "react";
import { jest } from "@jest/globals";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";

const mockUseMap = jest.fn();

jest.unstable_mockModule("react-leaflet", () => ({
  useMap: mockUseMap,
}));

jest.unstable_mockModule("@/assets/CNMS/Fit Screen.svg", () => ({
  default: "fit-screen.svg",
}));

jest.unstable_mockModule("@/components/Reusable/Modal/MModal", () => ({
  SquareIconButton: ({ children, ...props }) => (
    <button {...props}>{children}</button>
  ),
}));

const { MapControls } = await import(
  "@/Pages/CnmsDashboard/CnmsMap/components/MapControls"
);

describe("MapControls", () => {
  let mapMock;
  let onToggleFullscreen;

  const defaultProps = {
    allCnms: [
      { latitude: 24.5, longitude: 72.7 },
      { latitude: 30.8, longitude: 76.9 },
    ],
    allSites: [{ latitude: 12.6, longitude: 80.6 }],
    isFullscreen: false,
  };

  beforeEach(() => {
    jest.clearAllMocks();

    mapMock = {
      setView: jest.fn(),
    };

    onToggleFullscreen = jest.fn();
    mockUseMap.mockReturnValue(mapMock);
  });

  test("renders map controls", () => {
    render(
      <MapControls
        {...defaultProps}
        onToggleFullscreen={onToggleFullscreen}
      />
    );

    expect(screen.getByTitle("Fit to Screen")).toBeInTheDocument();
    expect(screen.getByTitle("Enter full screen")).toBeInTheDocument();
  });

  test("calls setView when Fit to Screen is clicked with points", () => {
    render(
      <MapControls
        {...defaultProps}
        onToggleFullscreen={onToggleFullscreen}
      />
    );

    fireEvent.click(screen.getByTitle("Fit to Screen"));

    expect(mapMock.setView).toHaveBeenCalledWith([23.5937, 78.9029], 5);
  });

  test("does not call setView when both arrays are empty", () => {
    render(
      <MapControls
        {...defaultProps}
        allCnms={[]}
        allSites={[]}
        onToggleFullscreen={onToggleFullscreen}
      />
    );

    fireEvent.click(screen.getByTitle("Fit to Screen"));

    expect(mapMock.setView).not.toHaveBeenCalled();
  });

  test("calls setView when only CNMS points exist", () => {
    render(
      <MapControls
        {...defaultProps}
        allCnms={[{ latitude: 10, longitude: 20 }]}
        allSites={[]}
        onToggleFullscreen={onToggleFullscreen}
      />
    );

    fireEvent.click(screen.getByTitle("Fit to Screen"));

    expect(mapMock.setView).toHaveBeenCalledTimes(1);
    expect(mapMock.setView).toHaveBeenCalledWith([23.5937, 78.9029], 5);
  });

  test("calls setView when only Site points exist", () => {
    render(
      <MapControls
        {...defaultProps}
        allCnms={[]}
        allSites={[{ latitude: 10, longitude: 20 }]}
        onToggleFullscreen={onToggleFullscreen}
      />
    );

    fireEvent.click(screen.getByTitle("Fit to Screen"));

    expect(mapMock.setView).toHaveBeenCalledTimes(1);
    expect(mapMock.setView).toHaveBeenCalledWith([23.5937, 78.9029], 5);
  });

  test("calls fullscreen callback", () => {
    render(
      <MapControls
        {...defaultProps}
        onToggleFullscreen={onToggleFullscreen}
      />
    );

    fireEvent.click(screen.getByTitle("Enter full screen"));

    expect(onToggleFullscreen).toHaveBeenCalledTimes(1);
  });

  test("shows Exit full screen when fullscreen is enabled", () => {
    render(
      <MapControls
        {...defaultProps}
        onToggleFullscreen={onToggleFullscreen}
        isFullscreen={true}
      />
    );

    expect(screen.getByTitle("Exit full screen")).toBeInTheDocument();
    expect(screen.queryByTitle("Enter full screen")).not.toBeInTheDocument();
  });
});
