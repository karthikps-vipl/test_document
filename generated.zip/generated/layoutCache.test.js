import { getCachedLayout, setCachedLayout, clearLayoutCache } from "../../src/core/utils/layoutCache";

describe("layoutCache", () => {
  beforeEach(() => clearLayoutCache());

  test("returns undefined for a cache miss", () => {
    expect(getCachedLayout("router")).toBeUndefined();
  });

  test("stores and retrieves a layout by terminal type", () => {
    const layout = { status: [{ id: 1 }] };
    setCachedLayout("CNMS", layout);
    expect(getCachedLayout("CNMS")).toBe(layout);
  });

  test("keeps entries for different terminal types separate", () => {
    setCachedLayout("CNMS", { id: 1 });
    setCachedLayout("RNMS", { id: 2 });
    expect(getCachedLayout("CNMS")).toEqual({ id: 1 });
    expect(getCachedLayout("RNMS")).toEqual({ id: 2 });
  });

  test("clears all cached layouts", () => {
    setCachedLayout("CNMS", { id: 1 });
    clearLayoutCache();
    expect(getCachedLayout("CNMS")).toBeUndefined();
  });
});
