import { extractOidsFromLayout, applyOidOperation } from '../../src/core/utils/oidExtractor';

describe('extractOidsFromLayout', () => {
  test('collects unique static and table OIDs from all tabs and widgets', () => {
    const result = extractOidsFromLayout({ status: [
      { widget: [
        { data: [{ oid: '1.2.3' }, { oid: '1.2.3' }, { name: 'missing' }], mapForDisplay: { a: '1.2.4' } },
        { data: [{ oid: '1.2.5' }], mapForDisplay: { b: '1.2.4', c: '1.2.6' } },
      ] },
      { widget: [{ data: [{ oid: '1.2.7' }] }] },
    ] });
    expect(result).toEqual({ staticOids: ['1.2.3', '1.2.5', '1.2.7'], tableOids: ['1.2.4', '1.2.6'] });
  });

  test('safely handles missing or partial layout data', () => {
    expect(extractOidsFromLayout()).toEqual({ staticOids: [], tableOids: [] });
    expect(extractOidsFromLayout({ status: [{}, { widget: [null, {}] }] })).toEqual({ staticOids: [], tableOids: [] });
  });
});

describe('applyOidOperation', () => {
  test('returns a dash for nullish values and preserves values without mapping', () => {
    expect(applyOidOperation(null, { operation: 'divide' })).toBe('-');
    expect(applyOidOperation(undefined, null)).toBe('-');
    expect(applyOidOperation('abc')).toBe('abc');
  });
  test('applies divide and multiply operations with default operator', () => {
    expect(applyOidOperation('20', { operation: 'divide', operator_map: '4' })).toBe(5);
    expect(applyOidOperation(20, { operation: 'divide' })).toBe(20);
    expect(applyOidOperation('5', { operation: 'multiply', operator_map: 3 })).toBe(15);
    expect(applyOidOperation('5', { operation: 'multiply', operator_map: 0 })).toBe(5);
  });
  test('formats system uptime into days, hours, minutes and seconds', () => {
    expect(applyOidOperation(90061, { operation: 'removemilisecsysuptime' })).toBe('1 D : 1 H : 1 M : 1 S');
    expect(applyOidOperation(59, { operation: 'removemilisecsysuptime' })).toBe('0 D : 0 H : 0 M : 59 S');
  });
  test('returns original value for unknown operation', () => {
    expect(applyOidOperation('7', { operation: 'unknown' })).toBe('7');
  });
});
