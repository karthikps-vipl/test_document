import { linksMap, terminalType, UpdateURlFun } from "../../src/components/shared/utilis/utils";

describe("shared utility constants", () => {
  test("exposes expected link types", () => {
    expect(linksMap).toEqual({
      1: "VSAT",
      2: "E1/LOS",
      3: "E1/LOS",
      4: "Not Configured",
    });
  });
  test("exposes terminal type identifiers", () => {
    expect(terminalType.CNMS).toBe(1);
    expect(terminalType.HUB_NMS).toBe(2);
    expect(terminalType.MCT_MK_I).toBe(3);
    expect(terminalType.MCT_MK_II).toBe(5);
    expect(terminalType.MCT_LSV).toBe(7);
    expect(terminalType.MCT_LSV_ALPHA).toBe(8);
  });
});

describe("UpdateURlFun", () => {
  test("replaces the host while preserving protocol, port and path", () => {
    expect(UpdateURlFun("http://old-host:8080/api", "10.0.0.1"))
      .toBe("http://10.0.0.1:8080/api");
  });
  test("works with HTTPS URLs", () => {
    expect(UpdateURlFun("https://example.com:443/path", "new.example.com"))
      .toBe("https://new.example.com:443/path");
  });
});
