import React from "react";
import { jest } from "@jest/globals";

const notification = {
  success: jest.fn(),
  info: jest.fn(),
  warning: jest.fn(),
  error: jest.fn(),
  custom: jest.fn(),
};

jest.unstable_mockModule("antd", () => ({
  notification,
}));

const { Toast } = await import("../../src/components/Reusable/Toast/Toast");

describe("Toast", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const expectedCommonOptions = {
    closable: true,
    duration: 3,
    placement: "bottomLeft",
    className: "custom-toast custom-toast-white-text",
  };

  test("uses info notification by default and applies the info background", () => {
    Toast("Information", "This is an information message");

    expect(notification.info).toHaveBeenCalledTimes(1);

    const options = notification.info.mock.calls[0][0];

    expect(options).toMatchObject({
      ...expectedCommonOptions,
      style: {
        backgroundColor: "#1890ff",
        borderRadius: "4px",
      },
    });
    expect(React.isValidElement(options.title)).toBe(true);
    expect(options.title.props.children).toBe("Information");
    expect(React.isValidElement(options.description)).toBe(true);
    expect(options.description.props.children).toBe(
      "This is an information message"
    );
    expect(options.title.props.style).toEqual({
      color: "#fff",
      fontWeight: 600,
    });
    expect(options.description.props.style).toEqual({
      color: "#fff",
      opacity: 0.9,
    });
  });

  test.each([
    ["success", "#008746"],
    ["error", "#ff4d4f"],
    ["warning", "#faad14"],
    ["info", "#1890ff"],
  ])("uses the %s notification with its configured background", (type, color) => {
    Toast("Title", "Message", type);

    expect(notification[type]).toHaveBeenCalledTimes(1);
    expect(notification[type].mock.calls[0][0]).toMatchObject({
      ...expectedCommonOptions,
      style: {
        backgroundColor: color,
        borderRadius: "4px",
      },
    });
  });

  test("falls back to the info background color for an unlisted notification type", () => {
    Toast("Custom title", "Custom message", "custom");

    expect(notification.custom).toHaveBeenCalledTimes(1);
    expect(notification.custom.mock.calls[0][0]).toMatchObject({
      ...expectedCommonOptions,
      style: {
        backgroundColor: "#1890ff",
        borderRadius: "4px",
      },
    });
  });

  test("passes empty title and message through unchanged", () => {
    Toast("", "");

    expect(notification.info).toHaveBeenCalledTimes(1);

    const options = notification.info.mock.calls[0][0];
    expect(options.title.props.children).toBe("");
    expect(options.description.props.children).toBe("");
  });
});
