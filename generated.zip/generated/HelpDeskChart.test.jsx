 
import HelpDeskChart from "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HelpDeskChart";
 
import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useTheme } from "@mui/material";
 import { exportSingleChartWithTable } from "@/components/Reusable/Pdf/downloadPdf";

// ---- Mocks ----
jest.mock("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");
  return {
    ...actual,
    useTheme: jest.fn(() => ({
      palette: {
        text: { primary: "#111111" },
        custom: {
          chart: {
            chartbg: "#ffffff",
            tooltipBg: "#222222",
            tooltipText: "#ffffff",
            grid: "#e5e7eb",
            cursor: "#f3f4f6",
          },
          icon: {
            iconFilter: "none",
          },
        },
      },
    })),
  };
});

jest.mock("@/components/Reusable/Pdf/downloadPdf", () => ({
  exportSingleChartWithTable: jest.fn(),
}));

jest.mock("@/assets/SVGIcons/download.svg", () => "download-icon.svg");

jest.mock("recharts", () => {
  const React = require("react");
  return {
    ResponsiveContainer: ({ children }) => (
      <div data-testid="responsive-container">{children}</div>
    ),
    PieChart: ({ children }) => <div data-testid="pie-chart">{children}</div>,
    Pie: ({ data = [], label, children }) => (
      <div data-testid="pie" data-items={JSON.stringify(data)}>
        {typeof label === "function"
          ? label({
              cx: 100,
              cy: 100,
              midAngle: 0,
              outerRadius: 50,
              percent: 0.5,
            })
          : null}
        {children}
      </div>
    ),
    Cell: ({ fill }) => <span data-testid="pie-cell" data-fill={fill} />,
    BarChart: ({ data = [], children }) => (
      <div data-testid="bar-chart" data-items={JSON.stringify(data)}>
        {children}
      </div>
    ),
    Bar: ({ dataKey }) => <div data-testid="bar" data-key={dataKey} />,
    XAxis: ({ children }) => <div>{children}</div>,
    YAxis: ({ children }) => <div>{children}</div>,
    CartesianGrid: () => null,
    Label: ({ value }) => <span>{value}</span>,
    Tooltip: ({ formatter }) => (
      <span data-testid="tooltip-sample">
        {typeof formatter === "function" ? JSON.stringify(formatter(12)) : null}
      </span>
    ),
    Legend: () => <div data-testid="legend" />,
  };
});

describe("HelpDeskChart", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    useTheme.mockReturnValue({
      palette: {
        text: { primary: "#111111" },
        custom: {
          chart: {
            chartbg: "#ffffff",
            tooltipBg: "#222222",
            tooltipText: "#ffffff",
            grid: "#e5e7eb",
            cursor: "#f3f4f6",
          },
          icon: {
            iconFilter: "none",
          },
        },
      },
    });
  });

  test("renders empty state with disabled download buttons and does not export when clicked", () => {
    render(<HelpDeskChart tableData={[]} />);

    const buttons = screen.getAllByRole("button");
    expect(buttons).toHaveLength(2);
    expect(buttons[0]).toBeDisabled();
    expect(buttons[1]).toBeDisabled();

    fireEvent.click(buttons[0]);
    fireEvent.click(buttons[1]);

    expect(exportSingleChartWithTable).not.toHaveBeenCalled();
    expect(screen.getByText("50%")).toBeInTheDocument();
    expect(screen.getByText('["12 Units","Volume"]')).toBeInTheDocument();
  });

  test("aggregates priority and status data, renders colors/labels, and exports PDF reports", () => {
    const rows = [
      { priority: "Major", status: "Open" },
      { priority: "MAJOR", status: "Open" },
      { priority: "Minor", status: "Closed" },
      { priority: "Warning", status: "Pending" },
      { priority: "Other", status: undefined },
    ];

    render(<HelpDeskChart tableData={rows} />);

    const pie = screen.getByTestId("pie");
    expect(JSON.parse(pie.getAttribute("data-items"))).toEqual([
      { name: "Major", value: 2 },
      { name: "Minor", value: 1 },
      { name: "Warning", value: 1 },
    ]);

    const barChart = screen.getByTestId("bar-chart");
    expect(JSON.parse(barChart.getAttribute("data-items"))).toEqual([
      { name: "Open", count: 2 },
      { name: "Closed", count: 1 },
      { name: "Pending", count: 1 },
      { name: "Unknown", count: 1 },
    ]);

    const cells = screen.getAllByTestId("pie-cell");
    expect(cells.map((c) => c.getAttribute("data-fill"))).toEqual([
      "url(#majorGrad)",
      "url(#minorGrad)",
      "url(#warningGrad)",
    ]);

    const buttons = screen.getAllByRole("button");
    expect(buttons[0]).toBeEnabled();
    expect(buttons[1]).toBeEnabled();

    fireEvent.click(buttons[0]);
    expect(exportSingleChartWithTable).toHaveBeenCalledWith(
      "Pie Chart Summary (Based on Priority)",
      [
        { header: "Severity Level", dataKey: "name" },
        { header: "Total Count", dataKey: "value" },
      ],
      [
        { name: "Major", value: 2 },
        { name: "Minor", value: 1 },
        { name: "Warning", value: 1 },
      ],
      "pie-chart-container",
      "Priority_Distribution"
    );

    fireEvent.click(buttons[1]);
    expect(exportSingleChartWithTable).toHaveBeenCalledWith(
      "Bar Chart Summary (Ticket Status Breakdown)",
      [
        { header: "Ticket Status", dataKey: "name" },
        { header: "Total Count", dataKey: "count" },
      ],
      [
        { name: "Open", count: 2 },
        { name: "Closed", count: 1 },
        { name: "Pending", count: 1 },
        { name: "Unknown", count: 1 },
      ],
      "bar-chart-container",
      "Status_Matrix_Report"
    );
  });
});

