 
import HandleStatusUpdateAction from "../../src/Pages/Rnmsdashboard/RightUtilityDrawer/components/HelpDesk/HandleStatusUpdateAction";

import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { useSelector } from "react-redux";
import { useTheme } from "@mui/material";
 import { HelpDeskAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";

// ---- Mocks ----
jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.mock("@mui/material", () => {
  const actual = jest.requireActual("@mui/material");
  return {
    ...actual,
    useTheme: jest.fn(() => ({
      palette: { mode: "light" },
    })),
  };
});

jest.mock("antd/es/input/TextArea", () => {
  return function MockTextArea({
    value,
    onChange,
    placeholder,
    rows,
    className,
    style,
  }) {
    return (
      <textarea
        data-testid="status-textarea"
        rows={rows}
        value={value}
        placeholder={placeholder}
        className={className}
        style={style}
        onChange={onChange}
      />
    );
  };
});

jest.mock("@/RestAPI/api/axiosApicall", () => ({
  HelpDeskAxios: jest.fn(),
}));

jest.mock("@/RestAPI/url/endpoint", () => ({
  UPDATE_TICKET: "/api/ticket/update",
}));

jest.mock("@/components/Reusable/Toast/Toast", () => jest.fn());

jest.mock("@/assets/SVGIcons/question_mark.svg", () => "confirm-icon.svg");

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => {
  return function MockMButtonPrimary({ children, onClick, disabled }) {
    return (
      <button type="button" onClick={onClick} disabled={disabled}>
        {children}
      </button>
    );
  };
});

jest.mock("@/components/Reusable/Dialog/MDialog", () => {
  return function MockMDialog({
    open,
    title,
    message,
    onConfirm,
    onClose,
    isChildFullScreen,
  }) {
    if (!open) return null;
    return (
      <div
        role="dialog"
        aria-label={title}
        data-fullscreen={String(Boolean(isChildFullScreen))}
      >
        <p>{message}</p>
        <button type="button" onClick={onConfirm}>
          Confirm Status
        </button>
        <button type="button" onClick={onClose}>
          Cancel Status
        </button>
      </div>
    );
  };
});

describe("HandleStatusUpdateAction", () => {
  const onClose = jest.fn();
  const onRefresh = jest.fn();

  const defaultState = {
    userSlice: {
      userDetails: {
        data: {
          userName: "alex.ops",
        },
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    useSelector.mockImplementation((selectorFn) => selectorFn(defaultState));
    useTheme.mockReturnValue({ palette: { mode: "light" } });
    HelpDeskAxios.mockResolvedValue({ status: 200 });
  });

  test("renders initial state with Update disabled and formatted mode placeholder", () => {
    render(
      <HandleStatusUpdateAction
        id="101"
        mode="IN_PROGRESS"
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    expect(screen.getByText("Status Update Remark *")).toBeInTheDocument();
    expect(screen.getByText("0/255")).toBeInTheDocument();

    const textarea = screen.getByTestId("status-textarea");
    expect(textarea).toHaveValue("");
    expect(textarea).toHaveAttribute(
      "placeholder",
      "Enter comments to move to in progress..."
    );
    expect(screen.getByRole("button", { name: "Update" })).toBeDisabled();
  });

  // test("validates description: strips disallowed chars, cleans first 2 chars, checks length/start, caps at 255", () => {
  //   render(<HandleStatusUpdateAction id="101" mode="RESOLVED" />);
  //   const textarea = screen.getByTestId("status-textarea");

  //   // Non-letter single char stripped -> empty
  //   fireEvent.change(textarea, { target: { value: "9" } });
  //   expect(textarea).toHaveValue("");
  //   expect(screen.getByText("0/255")).toBeInTheDocument();

  //   // Single letter -> < 2 chars error
  //   fireEvent.change(textarea, { target: { value: "R" } });
  //   expect(textarea).toHaveValue("R");
  //   expect(
  //     screen.getByText("First 2 characters must be text (letters)")
  //   ).toBeInTheDocument();
  //   expect(screen.getByRole("button", { name: "Update" })).toBeDisabled();

  //   // 2nd char non-letter -> "Must start with 2 letters"
  //   fireEvent.change(textarea, { target: { value: "R2" } });
  //   expect(textarea).toHaveValue("R2");
  //   expect(screen.getByText("Must start with 2 letters")).toBeInTheDocument();

  //   // Valid start + allowed symbols + disallowed chars ($@#)
  //   fireEvent.change(textarea, {
  //     target: { value: "Resolved_case-2.1, done$@#!" },
  //   });
  //   expect(textarea).toHaveValue("Resolved_case-2.1, done!");
  //   expect(
  //     screen.queryByText(/Must start with 2 letters/i)
  //   ).not.toBeInTheDocument();
  //   expect(screen.getByRole("button", { name: "Update" })).toBeEnabled();

  //   // Cap at 255
  //   fireEvent.change(textarea, { target: { value: "Ok" + "a".repeat(260) } });
  //   expect(textarea.value).toHaveLength(255);
  //   expect(screen.getByText("255/255")).toBeInTheDocument();

  //   // Reset to empty
  //   fireEvent.change(textarea, { target: { value: "" } });
  //   expect(textarea).toHaveValue("");
  //   expect(screen.getByText("0/255")).toBeInTheDocument();
  // });

  test("applies dark theme styles, opens/closes confirm dialog, and sets isChildFullScreen", () => {
    useTheme.mockReturnValue({ palette: { mode: "dark" } });

    render(
      <HandleStatusUpdateAction
        id="101"
        mode="PENDING"
        isChildFullScreen={true}
      />
    );

    const textarea = screen.getByTestId("status-textarea");
    expect(textarea).toHaveClass("dark-ant-textarea");
    expect(textarea.style.background).toBe("rgb(51, 51, 51)");
    expect(textarea.style.color).toBe("rgb(255, 255, 255)");

    fireEvent.change(textarea, { target: { value: "Waiting on vendor" } });
    fireEvent.click(screen.getByRole("button", { name: "Update" }));

    const dialog = screen.getByRole("dialog", {
      name: "Confirm Status Change",
    });
    expect(dialog).toHaveAttribute("data-fullscreen", "true");
    expect(
      screen.getByText(
        "Are you sure you want to update this ticket to pending?"
      )
    ).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Cancel Status" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  test("submits RESOLVED with ticketData.ticketId, latest subDetail, and 201 response", async () => {
    HelpDeskAxios.mockResolvedValueOnce({ status: 201 });

    const ticketData = {
      ticketId: "TICKET-900",
      hdTicketSubDetails: [
        { sequenceNum: 1, loggedinUser: "first.user" },
        { sequenceNum: 5, loggedinUser: "latest.engineer" },
      ],
    };

    render(
      <HandleStatusUpdateAction
        id="STATUS-1"
        mode="RESOLVED"
        ticketData={ticketData}
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    fireEvent.change(screen.getByTestId("status-textarea"), {
      target: { value: "Root cause fixed" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Update" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Status" }));

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith("/api/ticket/update", "post", {
        hdTicketStatus: { id: "4" },
        hdTicketDetail: { id: "TICKET-900" },
        sequenceNum: 5,
        statement: "Root cause fixed",
        loggedinUser: "latest.engineer",
      });
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket moved to Resolved successfully!",
      "success"
    );
    expect(onRefresh).toHaveBeenCalledTimes(1);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test("handles IN_PROGRESS and PENDING modes with fallback id, userName, and 200 response", async () => {
    HelpDeskAxios.mockResolvedValueOnce({ status: 200 });

    render(
      <HandleStatusUpdateAction
        id="42"
        mode="in-progress"
        ticketData={{ hdTicketSubDetails: [] }}
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );

    fireEvent.change(screen.getByTestId("status-textarea"), {
      target: { value: "Investigating alert" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Update" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Status" }));

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith("/api/ticket/update", "post", {
        hdTicketStatus: { id: "2" },
        hdTicketDetail: { id: "42" },
        sequenceNum: 1,
        statement: "Investigating alert",
        loggedinUser: "alex.ops",
      });
    });

    expect(Toast).toHaveBeenCalledWith(
      "Success!",
      "Ticket moved to In Progress successfully!",
      "success"
    );
  });

  test("handles invalid mode, non-200/201 status, API rejection, and missing id", async () => {
    const errSpy = jest.spyOn(console, "error").mockImplementation(() => {});
    const alertSpy = jest.spyOn(window, "alert").mockImplementation(() => {});

    // 1. Invalid mode
    const { rerender } = render(
      <HandleStatusUpdateAction id="10" mode="UNKNOWN_MODE" />
    );
    fireEvent.change(screen.getByTestId("status-textarea"), {
      target: { value: "Testing invalid mode" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Update" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Status" }));

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error",
        "Invalid status mode selected",
        "error"
      );
    });

    // 2. Non-200/201 response + empty userName -> 'system'
    useSelector.mockImplementation((selectorFn) =>
      selectorFn({
        userSlice: { userDetails: { data: { userName: "" } } },
      })
    );
    HelpDeskAxios.mockResolvedValueOnce({ status: 422 });

    rerender(
      <HandleStatusUpdateAction
        id="10"
        mode="PENDING"
        onClose={onClose}
        onRefresh={onRefresh}
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "Update" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Status" }));

    await waitFor(() => {
      expect(HelpDeskAxios).toHaveBeenCalledWith(
        "/api/ticket/update",
        "post",
        expect.objectContaining({ loggedinUser: "system", hdTicketStatus: { id: "3" } })
      );
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "Failed to update status",
        "error"
      );
    });

    // 3. API rejection
    HelpDeskAxios.mockRejectedValueOnce(new Error("Server error"));
    fireEvent.click(screen.getByRole("button", { name: "Update" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Status" }));

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "Error!",
        "An error occurred while updating",
        "error"
      );
    });

    // 4. Missing ID
    rerender(<HandleStatusUpdateAction mode="PENDING" />);
    fireEvent.click(screen.getByRole("button", { name: "Update" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm Status" }));

    expect(alertSpy).toHaveBeenCalledWith("Error: Missing Ticket ID");

    errSpy.mockRestore();
    alertSpy.mockRestore();
  });
});
