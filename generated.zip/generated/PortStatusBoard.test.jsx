import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

import { useTheme } from "@mui/material";
import { PortStatusBoard } from "@/Pages/Rnmsdashboard/PortStatus/PortStatusBoard";

// Mock MUI theme
jest.mock("@mui/material", () => ({
  ...jest.requireActual("@mui/material"),
  useTheme: jest.fn(),
}));

// Mock child component
jest.mock("@/Pages/Rnmsdashboard/PortStatus/PortStatusSwitch", () => ({
  PortStatusSwitch: jest.fn(({ device }) => (
    <div data-testid="port-status-switch">
      {device.name}
    </div>
  )),
}));

describe("PortStatusBoard Component", () => {
  const mockDevices = [
    { id: 1, name: "Device 1" },
    { id: 2, name: "Device 2" },
    { id: 3, name: "Device 3" },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // 1. Render component
  test("should render PortStatusBoard successfully", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelector(".board-shell")).toBeInTheDocument();
  });

  // 2. Light theme background
  test("should apply white background in light theme", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelector(".board-shell")).toHaveStyle({
      backgroundColor: "#ffffff",
    });
  });

  // 3. Dark theme background
  test("should apply dark background in dark theme", () => {
    useTheme.mockReturnValue({
      palette: { mode: "dark" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelector(".board-shell")).toHaveStyle({
      backgroundColor: "rgb(84, 84, 84)",
    });
  });

  // 4. Background transition
  test("should apply background color transition", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelector(".board-shell")).toHaveStyle({
      transition: "background-color 0.3s ease",
    });
  });

  // 5. Render all devices
  test("should render all device rows", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelectorAll(".device-row")).toHaveLength(3);
  });

  // 6. Render device names
  test("should display all device names", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    render(<PortStatusBoard devices={mockDevices} />);

    expect(screen.getByText("Device 1")).toBeInTheDocument();
    expect(screen.getByText("Device 2")).toBeInTheDocument();
    expect(screen.getByText("Device 3")).toBeInTheDocument();
  });

  // 7. Pass correct device props
  test("should pass correct device props to PortStatusSwitch", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    render(<PortStatusBoard devices={mockDevices} />);

    const { PortStatusSwitch } = require("@/Pages/Rnmsdashboard/PortStatus/PortStatusSwitch");

    expect(PortStatusSwitch).toHaveBeenCalledTimes(3);

    expect(PortStatusSwitch).toHaveBeenNthCalledWith(
      1,
      { device: mockDevices[0] },
      expect.anything()
    );

    expect(PortStatusSwitch).toHaveBeenNthCalledWith(
      2,
      { device: mockDevices[1] },
      expect.anything()
    );
  });

  // 8. Empty devices array
  test("should render without device rows when devices array is empty", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={[]} />
    );

    expect(container.querySelectorAll(".device-row")).toHaveLength(0);
  });

  // 9. Device stack structure
  test("should render correct device stack structure", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelector(".device-stack-wrapper")).toBeInTheDocument();
    expect(container.querySelector(".device-stack")).toBeInTheDocument();
  });

  // 10. Verify section element
  test("should render board shell as a section element", () => {
    useTheme.mockReturnValue({
      palette: { mode: "light" },
    });

    const { container } = render(
      <PortStatusBoard devices={mockDevices} />
    );

    expect(container.querySelector("section.board-shell")).toBeInTheDocument();
  });
});
