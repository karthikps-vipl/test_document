import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import GroupMgmtAdd from "../../src/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsSecurity/GroupManangement/GroupMgmtAdd";

describe("GroupMgmtAdd", () => {
  test("renders without crashing", () => {
    render(<GroupMgmtAdd />);
  });

  test("runs useEffect on mount", () => {
    render(<GroupMgmtAdd />);
    // TODO improve based on real effect
    expect(true).toBe(true);
  });
});
