import reducer, {
  setViewOnMap, setAllSiteGroups, triggerFilterReset, clearFilterResetFlag,
} from '../../src/store/features/Cnms/mapViewSlice';

describe('CNMS map view slice', () => {
  test('stores sites to display on map and site groups', () => {
    let state = reducer(undefined, setViewOnMap([{ siteId: 1 }]));
    state = reducer(state, setAllSiteGroups([{ groupId: 2 }]));
    expect(state).toEqual({ viewOnMap: [{ siteId: 1 }], allSiteGroups: [{ groupId: 2 }], shouldResetFilters: false });
  });
  test('raises and clears filter reset flag', () => {
    let state = reducer(undefined, triggerFilterReset());
    expect(state.shouldResetFilters).toBe(true);
    state = reducer(state, clearFilterResetFlag());
    expect(state.shouldResetFilters).toBe(false);
  });
});
