import reducer, { setLogoutPending, resetAuthStatus } from '../../src/store/features/Logout/authSlice';

describe('auth logout notification slice', () => {
  test('starts with no pending logout', () => {
    expect(reducer(undefined, { type: '@@INIT' })).toEqual({ isLogoutPending: false, logoutMessage: '', targetUser: '' });
  });
  test('stores logout message and target user', () => {
    const next = reducer(undefined, setLogoutPending({ message: 'New login detected', targetUser: 'operator1' }));
    expect(next).toEqual({ isLogoutPending: true, logoutMessage: 'New login detected', targetUser: 'operator1' });
  });
  test('reset clears logout notification state', () => {
    const next = reducer({ isLogoutPending: true, logoutMessage: 'x', targetUser: 'u' }, resetAuthStatus());
    expect(next).toEqual({ isLogoutPending: false, logoutMessage: '', targetUser: '' });
  });
});
