import React from "react";
import { jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import { createTheme, ThemeProvider } from "@mui/material/styles";

jest.unstable_mockModule("@/components/Charts/CustomLineChart", () => ({
  CustomLineChart: ({ data, xAxisKey, lines, height, xAxisLabel, yAxisLabel }) => (
    <div
      data-testid="custom-line-chart"
      data-x-axis-key={xAxisKey}
      data-height={String(height)}
      data-x-axis-label={xAxisLabel}
      data-y-axis-label={yAxisLabel}
      data-lines={JSON.stringify(lines)}
      data-chart-data={JSON.stringify(data)}
    >
      {data.map((point) => (
        <div key={point.date} data-testid={`traffic-point-${point.date}`}>
          {point.date}: {point.major}/{point.minor}/{point.warning}
        </div>
      ))}
    </div>
  ),
}));

const { default: AlarmTrafficChart } = await import(
  "../../src/Pages/CnmsDashboard/CnmsAlarmSummary/components/AlarmTrafficChart"
);

const chartBackground = "#f0f4f8";
const commonBorder = "1px solid rgb(190, 190, 190)";
const primaryText = "#202020";

const theme = createTheme({
  palette: {
    text: {
      primary: primaryText,
    },
    custom: {
      chart: {
        chartbg: chartBackground,
      },
      commonBorder,
    },
  },
});

const renderChart = () =>
  render(
    <ThemeProvider theme={theme}>
      <AlarmTrafficChart />
    </ThemeProvider>
  );

describe("AlarmTrafficChart", () => {
  test("renders the Alarm Traffic heading", () => {
    renderChart();

    expect(
      screen.getByRole("heading", { name: "Alarm Traffic" })
    ).toBeInTheDocument();
  });

  test("renders the CustomLineChart component", () => {
    renderChart();

    expect(screen.getByTestId("custom-line-chart")).toBeInTheDocument();
  });

  test("passes the expected x-axis and y-axis configuration", () => {
    renderChart();

    const chart = screen.getByTestId("custom-line-chart");

    expect(chart).toHaveAttribute("data-x-axis-key", "date");
    expect(chart).toHaveAttribute("data-height", "280");
    expect(chart).toHaveAttribute("data-x-axis-label", "Date Time");
    expect(chart).toHaveAttribute("data-y-axis-label", "Alarm Count");
  });

  test("passes all three alarm series with their labels and colors", () => {
    renderChart();

    const lines = JSON.parse(
      screen.getByTestId("custom-line-chart").getAttribute("data-lines")
    );

    expect(lines).toEqual([
      { dataKey: "major", label: "Major", color: "#D75961" },
      { dataKey: "minor", label: "Minor", color: "#BDBD32" },
      { dataKey: "warning", label: "Warning", color: "#007C7C" },
    ]);
  });

  test("passes the six expected hourly traffic data points", () => {
    renderChart();

    const data = JSON.parse(
      screen.getByTestId("custom-line-chart").getAttribute("data-chart-data")
    );

    expect(data).toEqual([
      { date: "10:00", major: 4, minor: 8, warning: 3 },
      { date: "11:00", major: 7, minor: 5, warning: 4 },
      { date: "12:00", major: 5, minor: 10, warning: 6 },
      { date: "13:00", major: 9, minor: 7, warning: 3 },
      { date: "14:00", major: 6, minor: 11, warning: 5 },
      { date: "15:00", major: 10, minor: 8, warning: 7 },
    ]);
  });

  test("renders each hourly data point", () => {
    renderChart();

    ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00"].forEach(
      (time) => {
        expect(screen.getByTestId(`traffic-point-${time}`)).toBeInTheDocument();
      }
    );
  });

  test("applies the theme background and border to the chart container", () => {
    renderChart();

    const container = screen.getByText("Alarm Traffic").parentElement;

    expect(container).toHaveStyle({
      background: chartBackground,
      border: commonBorder,
      width: "100%",
      height: "300px",
      borderRadius: "12px",
      padding: "8px",
      boxSizing: "border-box",
    });
  });

  test("uses the theme primary text color for the heading", () => {
    renderChart();

    expect(screen.getByRole("heading", { name: "Alarm Traffic" })).toHaveStyle({
      color: primaryText,
      fontWeight: "600",
    });
  });
});
