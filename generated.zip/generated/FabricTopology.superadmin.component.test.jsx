import React from 'react';
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';

const mockDispatch = jest.fn();
const mockCanvasInstances = [];
const mockToast = jest.fn();
let mockLoadFromJSONError = null;
let mockInitialCanvasObjects = [];
let mockObjectsAfterLoad = null;
const mockState = {
  nodeDetails: { isCnms: false, repDetails: null },
  inventory: { resources: [] },
  alarmSlice: { badgeCount: [] },
  topologySlice: {
    past: [],
    future: [],
    present: null,
    terminalTypes: [],
    linkStatusData: [],
  },
};

const makeFabricObject = (type, options = {}) => ({
  type,
  ...options,
  set: jest.fn(function set(values) { Object.assign(this, values); }),
  setCoords: jest.fn(),
  getObjects: jest.fn(() => options.objects || []),
});

jest.mock('react-redux', () => ({
  useDispatch: () => mockDispatch,
  useSelector: (selector) => selector(mockState),
}));

jest.mock('fabric', () => {
  class MockFabricObject {}
  class MockShape {
    constructor(...args) {
      this.args = args;
      this.options = args[args.length - 1] || {};
      Object.assign(this, this.options);
      this.set = jest.fn((values) => Object.assign(this, values));
      this.setCoords = jest.fn();
      this.getObjects = jest.fn(() => this.objects || []);
      if (Array.isArray(args[0])) this.points = args[0];
    }
  }
  class MockGroup extends MockShape {
    constructor(objects, options = {}) {
      super(objects, options);
      this.objects = objects;
      this.getObjects = jest.fn(() => this.objects);
    }
  }
  class MockCanvas {
    constructor(element) {
      this.element = element;
      this.handlers = {};
      this.objects = [...mockInitialCanvasObjects];
      this.activeObjects = [];
      this.activeObject = null;
      this.upperCanvasEl = { addEventListener: jest.fn() };
      this.setDimensions = jest.fn();
      this.getWidth = jest.fn(() => 800);
      this.getHeight = jest.fn(() => 600);
      this.on = jest.fn((name, handler) => { this.handlers[name] = handler; });
      this.getObjects = jest.fn(() => this.objects);
      this.calcOffset = jest.fn();
      this.requestRenderAll = jest.fn();
      this.dispose = jest.fn();
      this.toJSON = jest.fn(() => ({ objects: this.objects.map((obj) => ({ ...obj })) }));
      this.getActiveObject = jest.fn(() => this.activeObject);
      this.getActiveObjects = jest.fn(() => this.activeObjects);
      this.remove = jest.fn((obj) => { this.objects = this.objects.filter((item) => item !== obj); });
      this.discardActiveObject = jest.fn(() => { this.activeObject = null; this.activeObjects = []; });
      this.add = jest.fn((obj) => { this.objects.push(obj); });
      this.setActiveObject = jest.fn((obj) => { this.activeObject = obj; this.activeObjects = [obj]; });
      this.setViewportTransform = jest.fn();
      this.loadFromJSON = jest.fn(async () => {
        if (mockLoadFromJSONError) throw mockLoadFromJSONError;
        if (mockObjectsAfterLoad) this.objects = [...mockObjectsAfterLoad];
        return this;
      });
      mockCanvasInstances.push(this);
    }
  }
  return {
    Canvas: MockCanvas,
    Rect: MockShape,
    Circle: MockShape,
    Line: MockShape,
    Triangle: MockShape,
    Group: MockGroup,
    Image: { fromURL: jest.fn().mockResolvedValue({
      width: 100,
      height: 100,
      left: 0,
      top: 0,
      scaleX: 1,
      scaleY: 1,
      set: jest.fn(),
    }) },
    FabricObject: MockFabricObject,
    loadSVGFromURL: jest.fn().mockResolvedValue({ objects: [] }),
  };
});

jest.mock('@/lib/utils', () => ({
  getDeviceReachabilityColor: jest.fn(() => '#00aa00'),
  getDeviceReachabilityColorCnms: jest.fn(() => '#00aa00'),
  getDeviceStatusIndicator: jest.fn(() => '#00aa00'),
  getDeviceStatusIndicatorCnms: jest.fn(() => '#00aa00'),
}));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/utils', () => ({
  getEdgeColor: jest.fn(() => '#123456'),
}));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/topologyConstants', () => ({
  mapOpStatus: jest.fn(() => 'up'),
}));

jest.mock('../../src/store/features/Topology/topologyNodesslice', () => ({
  redoTopologyState: () => ({ type: 'topology/redo' }),
  saveTopologyState: (payload) => ({ type: 'topology/save', payload }),
  selectCanRedo: () => true,
  selectCanUndo: () => true,
  undoTopologyState: () => ({ type: 'topology/undo' }),
}));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/TopologyEditActions', () => (props) => (
  <div data-testid="topology-actions">
    <button onClick={props.onCanvasUndo}>Undo</button>
    <button onClick={props.onCanvasRedo}>Redo</button>
    <button onClick={props.onPortMappingToggle}>Toggle port mapping</button>
    <button onClick={props.onFabricDeleteAll}>Clear canvas</button>
    <button onClick={props.onFabricDeleteSelected}>Delete selected</button>
    <button onClick={() => props.onFabricAddLine('line')}>Add line</button>
    <button onClick={() => props.onFabricAddLine('arrow')}>Add arrow</button>
    <button onClick={props.onFabricSave}>Save topology</button>
    <button onClick={() => props.onFabricFieldChange('terminalId', 'terminal-1')}>Set terminal</button>
    <button onClick={() => props.onFabricFieldChange('terminalId', 'terminal-2')}>Set second terminal</button>
    <button onClick={() => props.onFabricFieldChange('segment', 'LAN')}>Set segment</button>
    <button onClick={() => props.onFabricFieldChange('linkStatusData', [
      { linkId: 11, linkName: 'LAN', linkStatus: 'UP' },
    ])}>Set link data</button>
    <button onClick={() => props.onFabricFieldChange('commitCanvasState')}>Commit state</button>
    <button onClick={() => props.onFabricFieldChange('radioWidth', '55')}>Set radius</button>
    <button onClick={() => props.onFabricFieldChange('deleteCanvas')}>Delete canvas</button>
    <button onClick={() => props.onFabricFieldChange('customField', 'custom-value')}>Set custom field</button>
    <button onClick={() => props.onFabricFieldChange('loadTopology', 'missing-terminal')}>Load missing topology</button>
    <button onClick={() => props.onFabricFieldChange('loadTopology', 'unknown-terminal')}>Load unknown terminal</button>
    <button onClick={() => props.onFabricFieldChange('createDeviceMarker', { deviceId: 'Router-01', selectedDeviceData: { resourceId: 'Router-01', resourceName: 'Router 01', status: 'UP' } })}>Create device marker</button>
    <button onClick={() => props.onFabricFieldChange('radioWidth', '65')}>Set associated radius</button>
    <button onClick={() => props.onFabricFieldChange('radioWidth', '')}>Clear radius</button>
    <input aria-label="Topology image" type="file" onChange={props.onFabricUpload} />
    <output data-testid="form-state">{JSON.stringify(props.fabricForm)}</output>
    <output data-testid="read-only-state">{String(props.svgReadOnly)}</output>
  </div>
));

jest.mock('../../src/Pages/Rnmsdashboard/Topology/Tooltip/NodeTooltip', () => (props) => (
  <div data-testid="node-tooltip">{props.activeNode?.data?.resourceName || ''}</div>
));
jest.mock('@/components/Reusable/Toast/Toast', () => (...args) => mockToast(...args));
jest.mock('@/components/Contextmenu/ContextMenu', () => (props) => (
  <div data-testid="context-menu" data-view-only={String(!!props.viewOnly)}>
    {props.node?.data?.resourceName || ''}
    {props.anchor && <button onClick={props.onClose}>Close context menu</button>}
  </div>
));
jest.mock('../../src/Pages/Rnmsdashboard/TopologyFabric/PortMapping', () => () => (
  <div data-testid="port-mapping-panel">Port mapping panel</div>
));
jest.mock('@/components/Reusable/FullScreen/CustomeFullscreen', () => ({
  __esModule: true,
  CustomeFullscreen: (props) => <button onClick={props.onToggleFullScreen}>Fullscreen</button>,
}));
jest.mock('@mui/material', () => ({
  Backdrop: ({ open, children }) => open ? <div data-testid="loading-backdrop">{children}</div> : null,
  CircularProgress: () => <span>Loading</span>,
}));


// SUPERADMIN is captured when FabricTopology is imported, so set it first.
window.isSuperAdmin = true;
const FabricTopology = (await import('../../src/Pages/Rnmsdashboard/TopologyFabric/FabricTopology')).default;

describe('FabricTopology SUPERADMIN coverage', () => {
  beforeEach(() => {
    window.isSuperAdmin = true;
    mockDispatch.mockClear();
    mockToast.mockClear();
    mockLoadFromJSONError = null;
    mockInitialCanvasObjects = [];
    mockObjectsAfterLoad = null;
    mockCanvasInstances.length = 0;
    mockState.nodeDetails = { isCnms: false, repDetails: null };
    mockState.inventory = { resources: [] };
    mockState.alarmSlice = { badgeCount: [] };
    mockState.topologySlice = {
      past: [], future: [], present: null, terminalTypes: [], linkStatusData: [],
    };
    global.ResizeObserver = class {
      observe = jest.fn();
      disconnect = jest.fn();
      unobserve = jest.fn();
    };
  });

  afterEach(() => {
    delete global.ResizeObserver;
    delete global.fetch;
    jest.restoreAllMocks();
  });

  const renderTopology = (props = {}) => render(<FabricTopology {...props} />);
  const canvas = () => mockCanvasInstances[mockCanvasInstances.length - 1];

  test('applies Super Admin styling to device rectangles, indicators, connectors and hardware ports on export', () => {
    const rectangle = makeFabricObject('rect', { shapeType: 'deviceRectangle' });
    const unmanagedIndicator = makeFabricObject('circle', {
      shapeType: 'deviceStatus',
      metadata: { deviceData: { imResourceType: { imResourceStateInfo: { resourceStateId: 2 } } } },
    });
    const managedIndicator = makeFabricObject('circle', {
      shapeType: 'deviceStatus',
      metadata: { deviceData: { imResourceType: { imResourceStateInfo: { resourceStateId: 1 } } } },
    });
    const line = makeFabricObject('line');
    const triangle = makeFabricObject('triangle');
    const connector = makeFabricObject('group', {
      metadata: { kind: 'connector' },
      objects: [line, triangle],
    });
    const svgElement = makeFabricObject('path');
    const svgGroup = makeFabricObject('group', { objects: [svgElement] });
    const stateContainer = makeFabricObject('group', { objects: [svgGroup] });
    const hardwarePort = makeFabricObject('group', {
      shapeType: 'hardwarePort',
      metadata: { portState: 'up', currentState: 'up', label: 'Port 1' },
      objects: [stateContainer],
    });
    const device = makeFabricObject('group', {
      shapeType: 'deviceCompositeGroup',
      objects: [hardwarePort],
    });
    mockInitialCanvasObjects = [rectangle, unmanagedIndicator, managedIndicator, connector, device];
    const createObjectURL = jest.fn(() => 'blob:superadmin-export');
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: jest.fn() });

    renderTopology();
    fireEvent.click(screen.getByRole('button', { name: 'Save topology' }));

    expect(rectangle.set).toHaveBeenCalledWith({ stroke: '#D3D3D3', strokeWidth: 8 });
    expect(unmanagedIndicator.set).toHaveBeenCalledWith({ fill: '#D3D3D3' });
    expect(managedIndicator.set).toHaveBeenCalledWith({ fill: '#0000ff' });
    expect(line.set).toHaveBeenCalledWith({ stroke: '#D3D3D3' });
    expect(triangle.set).toHaveBeenCalledWith({ fill: '#D3D3D3' });
    expect(svgGroup.set).toHaveBeenCalledWith({ fill: '#D3D3D3' });
    expect(hardwarePort.metadata).toEqual(expect.objectContaining({
      portState: 'notConfigured', currentState: 'notConfigured',
    }));
  });

  test('blocks topology reload and Redux restoration while Super Admin device creation is active', async () => {
    mockState.topologySlice.terminalTypes = [
      { subTypeId: 'terminal-1', id: 1, terminalTypeName: 'Main Terminal' },
      { subTypeId: 'terminal-2', id: 2, terminalTypeName: 'Backup Terminal' },
    ];
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    const view = renderTopology();

    fireEvent.click(screen.getByRole('button', { name: 'Set terminal' }));
    await waitFor(() => expect(global.fetch).toHaveBeenCalled());
    global.fetch.mockClear();

    // createDeviceMarker sets the in-progress ref before its first await.
    fireEvent.click(screen.getByRole('button', { name: 'Create device marker' }));
    fireEvent.click(screen.getByRole('button', { name: 'Load missing topology' }));
    fireEvent.click(screen.getByRole('button', { name: 'Set second terminal' }));

    mockState.topologySlice.present = { objects: [{ type: 'group' }] };
    view.rerender(<FabricTopology />);

    expect(global.fetch).not.toHaveBeenCalled();
    expect(canvas().loadFromJSON).not.toHaveBeenCalled();
    await waitFor(() => expect(canvas().add).toHaveBeenCalledTimes(2));
  });

  test('blocks CNMS topology reload while Super Admin device creation is active', async () => {
    mockState.topologySlice.terminalTypes = [
      { subTypeId: 'terminal-1', id: 1, terminalTypeName: 'Main Terminal' },
    ];
    global.fetch = jest.fn().mockResolvedValue({ ok: false });
    renderTopology({ Rnms_TerminalType: 'Core-Site', Rnms_siteID: 'site-01' });
    await waitFor(() => expect(global.fetch).toHaveBeenCalled());
    global.fetch.mockClear();

    fireEvent.click(screen.getByRole('button', { name: 'Set terminal' }));
    await waitFor(() => expect(global.fetch).toHaveBeenCalled());
    global.fetch.mockClear();
    fireEvent.click(screen.getByRole('button', { name: 'Create device marker' }));
    fireEvent.click(screen.getByRole('button', { name: 'Load missing topology' }));

    expect(global.fetch).not.toHaveBeenCalled();
    await waitFor(() => expect(canvas().add).toHaveBeenCalledTimes(2));
  });

  test('locks restored Fabric objects when auto-loading a logged-in Super Admin terminal', async () => {
    const rectangle = makeFabricObject('rect', { shapeType: 'deviceRectangle' });
    const indicator = makeFabricObject('circle', { shapeType: 'deviceStatus' });
    mockObjectsAfterLoad = [rectangle, indicator];
    mockState.nodeDetails.repDetails = {
      imTerminalType: { terminalTypeName: 'Admin Terminal' },
    };
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue({ canvas: { objects: [] } }),
    });

    renderTopology();

    await waitFor(() => {
      expect(canvas().loadFromJSON).toHaveBeenCalled();
      expect(rectangle.set).toHaveBeenCalledWith(expect.objectContaining({
        selectable: false,
        lockMovementX: true,
        lockScalingX: true,
        lockRotation: true,
        hasControls: false,
        hasBorders: false,
      }));
      expect(indicator.set).toHaveBeenCalledWith(expect.objectContaining({
        selectable: false,
        evented: true,
      }));
    });
  });
});
