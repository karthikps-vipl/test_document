import reducer, { setPingData, clearPingData } from '../../src/store/features/Ping/pingSlice';

describe('ping diagnostic slice', () => {
  test('initial ping data is null', () => expect(reducer(undefined, { type: '@@INIT' })).toEqual({ pingData: null }));
  test('stores the diagnostic response object', () => {
    const payload = { ipAddress: '192.168.1.1', pingOutput: '4 packets transmitted', isReachable: true };
    expect(reducer(undefined, setPingData(payload)).pingData).toEqual(payload);
  });
  test('clears previous diagnostic output', () => expect(reducer({ pingData: { pingOutput: 'old' } }, clearPingData())).toEqual({ pingData: null }));
});
