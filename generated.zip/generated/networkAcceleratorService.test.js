jest.mock('@/RestAPI/api/axiosApicall', () => ({ ConfigurationAxios: jest.fn() }));
import { ConfigurationAxios } from '@/RestAPI/api/axiosApicall';
import { FETCH_NETWORK_ACCELERATOR_RTT_MODE } from '@/RestAPI/url/endpoint';
import { getNetworkAcceleratorRttMode } from '../../src/core/services/networkAccelerator.service';

describe('network accelerator service', () => {
  beforeEach(() => { jest.clearAllMocks(); jest.spyOn(console, 'log').mockImplementation(() => {}); jest.spyOn(console, 'error').mockImplementation(() => {}); });
  afterEach(() => jest.restoreAllMocks());
  test('fetches and returns RTT/mode data', async () => {
    ConfigurationAxios.mockResolvedValue({ data: { data: { mode: 'adaptive', rtt: 20 } } });
    await expect(getNetworkAcceleratorRttMode('R1')).resolves.toEqual({ mode: 'adaptive', rtt: 20 });
    expect(ConfigurationAxios).toHaveBeenCalledWith(`${FETCH_NETWORK_ACCELERATOR_RTT_MODE}/R1`, 'get');
  });
  test('returns undefined when nested response data is absent', async () => {
    ConfigurationAxios.mockResolvedValue({ data: {} });
    await expect(getNetworkAcceleratorRttMode('R2')).resolves.toBeUndefined();
  });
  test('logs and rethrows API errors', async () => {
    const error = new Error('offline');
    ConfigurationAxios.mockRejectedValue(error);
    await expect(getNetworkAcceleratorRttMode('R3')).rejects.toBe(error);
    expect(console.error).toHaveBeenCalled();
  });
});
