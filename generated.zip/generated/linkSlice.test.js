import reducer, { setLinks, clearLinks, setLinksLoading } from '../../src/store/features/LinkStatus/linkSlice';

describe('link status slice', () => {
  test('starts empty and not loading', () => expect(reducer(undefined, { type: '@@INIT' })).toEqual({ links: [], loading: false, error: null }));
  test('sets links and clears loading', () => {
    const next = reducer({ links: [], loading: true, error: 'old' }, setLinks([{ id: 1 }, { id: 2 }]));
    expect(next).toEqual({ links: [{ id: 1 }, { id: 2 }], loading: false, error: 'old' });
  });
  test('clears links without changing loading or error', () => {
    const next = reducer({ links: [{ id: 1 }], loading: true, error: 'x' }, clearLinks());
    expect(next).toEqual({ links: [], loading: true, error: 'x' });
  });
  test('updates loading flag', () => expect(reducer(undefined, setLinksLoading(true)).loading).toBe(true));
});
