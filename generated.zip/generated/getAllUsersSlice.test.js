import reducer, { setAllUsersData, clearAllUsers } from '../../src/store/features/Cnms/GetAllUsers/getAllUsersSlice';

describe('CNMS users slice', () => {
  test('initializes an empty users list', () => expect(reducer(undefined, { type: '@@INIT' })).toEqual({ allUsers: [] }));
  test('stores API user list', () => expect(reducer(undefined, setAllUsersData([{ id: 1 }])).allUsers).toEqual([{ id: 1 }]));
  test('clears user list', () => expect(reducer({ allUsers: [{ id: 1 }] }, clearAllUsers())).toEqual({ allUsers: [] }));
});
