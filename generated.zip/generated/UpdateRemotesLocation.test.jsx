import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import UpdateRemotesLocation from "@/Pages/Rnmsdashboard/RightUtilityDrawer/components/Configuration/Location/UpdateRemotesLocation";
import { InventoryAxios } from "@/RestAPI/api/axiosApicall";
import Toast from "@/components/Reusable/Toast/Toast";
import remoteRepDetailsReducer from "@/store/features/Cnms/remoteRepDetails/remoteRepDetailsSlice";
import nodeDetailsSlice from "@/store/features/nodeDetailsSlice";

// Mock external API and Toast
jest.mock("@/RestAPI/api/axiosApicall", () => ({
  InventoryAxios: jest.fn(),
}));

jest.mock(
  "@/assets/SVGIcons/Confirmation_icon.svg",
  () => "Confirmation_icon.svg"
);

jest.mock("@/components/Reusable/Toast/Toast", () => ({
  __esModule: true,
  default: jest.fn(),
}));

// Mock reusable components to render standard test-friendly elements
jest.mock("@/components/Reusable/Select/MSelect", () => ({
  __esModule: true,
  default: ({ label, options, value, onChange, disabled }) => (
    <div data-testid={`select-${label}`}>
      <label>{label}</label>
      <select
        disabled={disabled}
        aria-label={label}
        value={value ? value.value || value : ""}
        onChange={(e) => {
          const selected = options.find((opt) => opt.value === e.target.value);
          onChange(selected || null);
        }}
      >
        <option value="">{`Select ${label}`}</option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  ),
}));

jest.mock("@/components/Reusable/Input/MInput", () => ({
  __esModule: true,
  default: ({ label, value, onChange, disabled }) => (
    <input
      aria-label={label}
      value={value}
      onChange={onChange}
      disabled={disabled}
    />
  ),
}));

jest.mock("@/components/Reusable/Button/MButtonPrimary", () => ({
  __esModule: true,
  default: ({ children, onClick, disabled }) => (
    <button onClick={onClick} disabled={disabled}>
      {children}
    </button>
  ),
}));

jest.mock("@/components/Reusable/Dialog/MDialog", () => ({
  __esModule: true,
  default: ({ open, onConfirm, title }) =>
    open ? (
      <div role="dialog" aria-label={title}>
        <button onClick={(e) => onConfirm(e)}>Confirm Update</button>
      </div>
    ) : null,
}));

const createTestStore = (preloadedState) => {
  return configureStore({
    reducer: {
      nodeDetails: nodeDetailsSlice,
      remoteRepDetails: remoteRepDetailsReducer,
    },
    preloadedState,
  });
};

describe("UpdateRemotesLocation Component", () => {
  let store;

  const preloadedState = {
    nodeDetails: {
      allTerminalTypeDetails: [
        { terminalTypeName: "CNMS" }, // Filtered out per component logic
        { terminalTypeName: "VSAT" },
        { terminalTypeName: "SCPC" },
      ],
    },
    remoteRepDetails: {
      fetchSiteDetails: [
        {
          siteId: "SITE-001",
          siteName: "Alpha Site",
          siteNickName: "Alpha",
          latitude: "12.971600",
          longitude: "77.594600",
          imTerminalType: { terminalTypeName: "VSAT" },
        },
        {
          siteId: "SITE-002",
          siteName: "Beta Site",
          siteNickName: "Beta",
          latitude: "13.082700",
          longitude: "80.270700",
          imTerminalType: { terminalTypeName: "SCPC" },
        },
      ],
      remoteRepDetails: [],
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    store = createTestStore(preloadedState);
  });

  test("renders component correctly and filters out CNMS terminal option", () => {
    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    expect(screen.getByText(/Longitude \(Dec\)/i)).toBeInTheDocument();
    expect(screen.getByText(/Latitude \(Dec\)/i)).toBeInTheDocument();

    const terminalSelect = screen.getByLabelText(/Terminal\*/i);
    expect(terminalSelect).toBeInTheDocument();
    expect(screen.queryByText("CNMS")).not.toBeInTheDocument();
    expect(screen.getByText("VSAT")).toBeInTheDocument();
  });

  test("enables Site ID dropdown when a valid terminal is selected", () => {
    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    const terminalSelect = screen.getByLabelText(/Terminal\*/i);
    const siteSelect = screen.getByLabelText(/Site ID\*/i);

    expect(siteSelect).toBeDisabled();

    fireEvent.change(terminalSelect, { target: { value: "VSAT" } });

    expect(siteSelect).not.toBeDisabled();
    expect(screen.getByText("SITE-001")).toBeInTheDocument();
    expect(screen.queryByText("SITE-002")).not.toBeInTheDocument(); // Belongs to SCPC
  });

  test("fetches site details successfully on site selection and populates inputs", async () => {
    InventoryAxios.mockResolvedValueOnce({
      data: {
        siteId: "SITE-001",
        siteName: "Alpha Site Updated",
        siteNickName: "Alpha",
        latitude: "15.000000",
        longitude: "75.000000",
      },
    });

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: { value: "VSAT" },
    });

    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: { value: "SITE-001" },
    });

    await waitFor(() => {
      expect(InventoryAxios).toHaveBeenCalledWith(
        expect.stringContaining("/SITE-001"),
        "get"
      );
    });

    expect(screen.getByLabelText(/Latitude \(Dec\)/i)).toHaveValue("12.971600");
    expect(screen.getByLabelText(/Longitude \(Dec\)/i)).toHaveValue(
      "75.000000"
    );
  });

  test("handles fetch site error gracefully and triggers Toast", async () => {
    InventoryAxios.mockRejectedValueOnce(new Error("Failed to load"));

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );
  });

  test("displays validation errors when invalid latitude or longitude are entered", async () => {
    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    // Select Terminal and Site to enable inputs
    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: { value: "VSAT" },
    });
    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: { value: "SITE-001" },
    });

    const latInput = screen.getByLabelText(/Latitude \(Dec\)/i);

    // Simulate entering invalid input (mocked to return error)
    fireEvent.change(latInput, { target: { value: "invalid" } });

    // The update button should remain disabled due to validation/sanitization rules
    const updateButton = screen.getByRole("button", { name: /Update/i });
    expect(updateButton).toBeDisabled();
  });

  test("handles submission failure gracefully with error toast when API returns non-200 status", async () => {
    // First call for site fetch, second call for location update
    InventoryAxios.mockResolvedValueOnce({
      data: {
        siteId: "SITE-001",
        latitude: "12.9716",
        longitude: "77.5946",
      },
    }).mockResolvedValueOnce({
      status: 400, // Non-200 failure
      data: null,
    });

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: { value: "VSAT" },
    });
    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: { value: "SITE-001" },
    });

    // Modify latitude to enable update
    const latInput = screen.getByLabelText(/Latitude \(Dec\)/i);
    fireEvent.change(latInput, { target: { value: "14.0000" } });

    // Open dialog and confirm
    fireEvent.click(screen.getByRole("button", { name: /Update/i }));
    fireEvent.click(screen.getByRole("button", { name: /Confirm Update/i }));

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith(
        "",
        "Failed to update location",
        "error"
      );
    });
  });

  test("handles catch block errors during submission gracefully", async () => {
    InventoryAxios.mockResolvedValueOnce({
      data: {
        siteId: "SITE-001",
        latitude: "12.9716",
        longitude: "77.5946",
      },
    }).mockRejectedValueOnce(new Error("Server down"));

    render(
      <Provider store={store}>
        <UpdateRemotesLocation isChildFullScreen={false} />
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/Terminal\*/i), {
      target: { value: "VSAT" },
    });
    fireEvent.change(screen.getByLabelText(/Site ID\*/i), {
      target: { value: "SITE-001" },
    });

    const latInput = screen.getByLabelText(/Latitude \(Dec\)/i);
    fireEvent.change(latInput, { target: { value: "14.0000" } });

    fireEvent.click(screen.getByRole("button", { name: /Update/i }));
    fireEvent.click(screen.getByRole("button", { name: /Confirm Update/i }));

    await waitFor(() => {
      expect(Toast).toHaveBeenCalledWith("", "Something went wrong", "error");
    });
  });
});
