import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import IndividualDevicePreview from "@/Pages/CnmsDashboard/CnmsrightutilityDrawer/CnmsConfiguration/Upload/components/IndividualDevicePreview";
import formatDate from "@/lib/utils";

// Mock reusable components
jest.mock("@/components/Reusable/Input/MInput", () => {
  return function MockMInput(props) {
    return (
      <input
        data-testid="mock-input"
        aria-label={props.label || "input"}
        value={props.value ?? ""}
        readOnly
        onChange={props.onChange}
      />
    );
  };
});

jest.mock("@/components/Reusable/Modal/MModal", () => {
  return function MockMModal({ open, title, handleClose, children }) {
    if (!open) return null;

    return (
      <div data-testid="mock-modal">
        <h2>{title}</h2>
        <button onClick={handleClose}>Close</button>
        {children}
      </div>
    );
  };
});

// Mock date formatter
jest.mock("@/lib/utils", () =>
  jest.fn((date) => (date ? `Formatted-${date}` : ""))
);

describe("IndividualDevicePreview Component", () => {
  const mockOnClose = jest.fn();

  const mockData = {
    fileName: "Backup_Config_01",
    description: "Device configuration backup",
    imSiteResourceInfo: {
      resourceName: "Router-01",
      imResourceType: {
        resourceTypeName: "Router",
      },
    },
    backupMode: 1,
    formattedDateTime: "2025-01-15T10:30:00",
    configData: JSON.stringify([
      {
        hostname: "Router01",
        ipAddress: "192.168.1.1",
        username: "admin",
      },
    ]),
  };

  const renderComponent = (data = mockData) =>
    render(<IndividualDevicePreview data={data} onClose={mockOnClose} />);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // -----------------------------
  // Rendering Tests
  // -----------------------------

  test("renders modal with correct title", () => {
    renderComponent();

    expect(
      screen.getByText("Individual Device Configuration Backup")
    ).toBeInTheDocument();
  });

  test("renders all field labels", () => {
    renderComponent();

    expect(screen.getByText("File Name")).toBeInTheDocument();
    expect(screen.getByText("File Description")).toBeInTheDocument();
    expect(screen.getByText("Device Name")).toBeInTheDocument();
    expect(screen.getByText("Device Type")).toBeInTheDocument();
    expect(screen.getByText("Backup Mode")).toBeInTheDocument();
    expect(screen.getByText("Date/Time")).toBeInTheDocument();
    expect(screen.getByText("Config Data")).toBeInTheDocument();
  });

  test("renders file name and description", () => {
    renderComponent();

    expect(screen.getByDisplayValue("Backup_Config_01")).toBeInTheDocument();
    expect(
      screen.getByDisplayValue("Device configuration backup")
    ).toBeInTheDocument();
  });

  // -----------------------------
  // Device Information Tests
  // -----------------------------

  test("renders device information from imSiteResourceInfo", () => {
    renderComponent();

    expect(screen.getByDisplayValue("Router-01")).toBeInTheDocument();
    expect(screen.getByDisplayValue("Router")).toBeInTheDocument();
  });

  test("uses resourceInfo when imSiteResourceInfo is unavailable", () => {
    const data = {
      ...mockData,
      imSiteResourceInfo: undefined,
      resourceInfo: {
        resourceName: "Switch-01",
        imResourceType: {
          resourceTypeName: "Switch",
        },
      },
    };

    renderComponent(data);

    expect(screen.getByDisplayValue("Switch-01")).toBeInTheDocument();
    expect(screen.getByDisplayValue("Switch")).toBeInTheDocument();
  });

  test("displays null when device information is missing", () => {
    const data = {
      fileName: "Backup",
      description: "Description",
      backupMode: 1,
      configData: "",
    };

    renderComponent(data);

    expect(screen.getAllByDisplayValue("null").length).toBeGreaterThan(0);
  });

  // -----------------------------
  // Backup Mode Tests
  // -----------------------------

  test("displays MANUAL when backupMode is 1", () => {
    renderComponent();

    expect(screen.getByDisplayValue("MANUAL")).toBeInTheDocument();
  });

  test("displays SCHEDULED when backupMode is not 1", () => {
    renderComponent({
      ...mockData,
      backupMode: 2,
    });

    expect(screen.getByDisplayValue("SCHEDULED")).toBeInTheDocument();
  });

  test("uses formattedBackupMode when provided", () => {
    renderComponent({
      ...mockData,
      formattedBackupMode: "CUSTOM",
      backupMode: 2,
    });

    expect(screen.getByDisplayValue("MANUAL")).toBeInTheDocument();
  });

  // -----------------------------
  // Date Formatting Tests
  // -----------------------------

  test("formats formattedDateTime when available", () => {
    renderComponent();

    expect(formatDate).toHaveBeenCalledWith(mockData.formattedDateTime);

    expect(
      screen.getByDisplayValue(`Formatted-${mockData.formattedDateTime}`)
    ).toBeInTheDocument();
  });

  test("uses dateTime when formattedDateTime is unavailable", () => {
    const data = {
      ...mockData,
      formattedDateTime: undefined,
      dateTime: "2025-02-10T12:00:00",
    };

    renderComponent(data);

    expect(formatDate).toHaveBeenCalledWith(data.dateTime);

    expect(
      screen.getByDisplayValue(`Formatted-${data.dateTime}`)
    ).toBeInTheDocument();
  });

  // -----------------------------
  // Config Data Tests
  // -----------------------------

  test("formats valid JSON configData", async () => {
    renderComponent();

    await waitFor(() => {
      const configInput = screen
        .getAllByTestId("mock-input")
        .find((input) => input.value.includes("hostname"));

      expect(configInput).toBeInTheDocument();
      expect(configInput.value).toContain("Router01");
      expect(configInput.value).toContain("192.168.1.1");
    });
  });

  test("handles invalid JSON configData without crashing", async () => {
    renderComponent({
      ...mockData,
      configData: "Invalid JSON configuration",
    });

    await waitFor(() => {
      expect(
        screen.getByDisplayValue("Invalid JSON configuration")
      ).toBeInTheDocument();
    });
  });

  test("displays null when configData is missing", async () => {
    renderComponent({
      ...mockData,
      configData: "",
    });

    await waitFor(() => {
      expect(screen.getByDisplayValue("null")).toBeInTheDocument();
    });
  });

  test("displays null when configData is undefined", async () => {
    renderComponent({
      ...mockData,
      configData: undefined,
    });

    await waitFor(() => {
      expect(screen.getByDisplayValue("null")).toBeInTheDocument();
    });
  });

  test("handles empty JSON array", async () => {
    renderComponent({
      ...mockData,
      configData: "[]",
    });

    await waitFor(() => {
      const configInput = screen
        .getAllByTestId("mock-input")
        .find((input) => input.value === "{}");

      expect(configInput).toBeInTheDocument();
    });
  });

  // -----------------------------
  // Modal Interaction Tests
  // -----------------------------

  test("calls onClose when Close button is clicked", () => {
    renderComponent();

    fireEvent.click(screen.getByText("Close"));

    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  test("renders modal with open set to true", () => {
    renderComponent();

    expect(screen.getByTestId("mock-modal")).toBeInTheDocument();
  });

  // -----------------------------
  // Data Update Tests
  // -----------------------------

  test("updates displayed config data when props change", async () => {
    const { rerender } = renderComponent();

    const updatedData = {
      ...mockData,
      configData: JSON.stringify([
        {
          hostname: "UpdatedRouter",
          ipAddress: "10.0.0.1",
        },
      ]),
    };

    rerender(
      <IndividualDevicePreview data={updatedData} onClose={mockOnClose} />
    );

    await waitFor(() => {
      const configInput = screen
        .getAllByTestId("mock-input")
        .find((input) => input.value.includes("UpdatedRouter"));

      expect(configInput).toBeInTheDocument();
      expect(configInput.value).toContain("10.0.0.1");
    });
  });
});
