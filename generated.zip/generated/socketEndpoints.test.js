import * as endpoints from "../../src/RestAPI/Socket/Endpoint";

describe("socket endpoint constants", () => {
  test("exports expected base and alarm topics", () => {
    expect(endpoints.NmsSocketTopic).toBe("/IAFNMSWebSocketTopic");
    expect(endpoints.ALARM_SOCKET_NMS).toBe("/IAFNMSWebSocketTopic/sendAlarmToUI");
    expect(endpoints.ALARM_SOCKET_CNMS).toBe("/IAFNMSWebSocketTopic/cnmsAlarm");
  });
  test("exports discovery, reachability and performance topics", () => {
    expect(endpoints.DEVICE_REACHABILITY_STATUS).toContain("deviceReachabilityStatus");
    expect(endpoints.CNMS_REACH_ABILITY_STATUS).toContain("cnmsReachabilityStatus");
    expect(endpoints.PERFORMANCE_DATA_UPDATE_TO_UI).toContain("PerformanceDataUpdateToUI");
    expect(endpoints.DISCOVERY_STAGE_DATA).toContain("sendSiteDiscoveryData");
  });
  test("exports chat destinations", () => {
    expect(endpoints.CHAT_BASE).toBe("/nmsChat");
    expect(endpoints.CHAT_TOPIC).toBe("/topic/public");
    expect(endpoints.ACK_DESTINATION).toBe("/app/sendMessage");
  });
});
