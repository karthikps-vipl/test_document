jest.mock('@/RestAPI/api/axiosApicall', () => ({ ConfigurationAxios: jest.fn() }));
import { ConfigurationAxios } from '@/RestAPI/api/axiosApicall';
import { GET_LAYOUT_FOR_DEVICE_CNMS } from '@/RestAPI/url/cnmsEndPoint';
import { GET_DEVICE_LAYOUT } from '@/RestAPI/url/endpoint';
import { getDeviceLayout, getDeviceLayoutfofCnms } from '../../src/core/services/deviceLayout.service';

describe('device layout service', () => {
  beforeEach(() => jest.clearAllMocks());
  test('fetches RNMS device layout and returns response data', async () => {
    ConfigurationAxios.mockResolvedValue({ data: { tabs: ['General'] } });
    await expect(getDeviceLayout('MK-I')).resolves.toEqual({ tabs: ['General'] });
    expect(ConfigurationAxios).toHaveBeenCalledWith(`${GET_DEVICE_LAYOUT}/MK-I`);
  });
  test('fetches CNMS device layout using terminal, site and resource identifiers', async () => {
    ConfigurationAxios.mockResolvedValue({ data: { layout: [] } });
    await expect(getDeviceLayoutfofCnms(1, 2, 'R-3')).resolves.toEqual({ layout: [] });
    expect(ConfigurationAxios).toHaveBeenCalledWith(`${GET_LAYOUT_FOR_DEVICE_CNMS}/1/2/R-3`);
  });
  test('propagates API errors', async () => {
    const error = new Error('server unavailable');
    ConfigurationAxios.mockRejectedValue(error);
    await expect(getDeviceLayout('MK-II')).rejects.toBe(error);
  });
});
