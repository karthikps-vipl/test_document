package org.bel.authService.entity;

import java.time.LocalDateTime;
import java.util.UUID;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "sync_outbox_delivery", schema = "tcs_laa")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SyncOutboxDelivery {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "event_id", nullable = false)
    private UUID eventId;
    @Column(name = "target_node_id", nullable = false)
    private String targetNodeId;
    @Column(nullable = false)
    private String status;
    @Column(name = "retry_count", nullable = false)
    private Integer retryCount;
    @Column(name = "next_retry_at")
    private LocalDateTime nextRetryAt;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    @Column(name = "sent_at")
    private LocalDateTime sentAt;
    @Column(name = "acknowledged_at")
    private LocalDateTime acknowledgedAt;
    @Column(name = "last_error")
    private String lastError;
}
