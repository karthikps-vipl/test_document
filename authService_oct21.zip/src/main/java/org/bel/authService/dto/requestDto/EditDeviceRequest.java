package org.bel.authService.dto.requestDto;

import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmUser;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EditDeviceRequest {
	private String deviceId;
	private String deviceName;
	private String contactNo;
	private Integer mdmDeviceTypeId;
	private Integer mdmUserId;
	private String securePin;
}
