package org.bel.authService.dto.requestDto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class AddDeviceRequest {
	
	@NotBlank(message = "'DeviceId' is required")
	private String deviceId;
	
	@NotBlank(message = "'DeviceName' is required")
	private String deviceName;
	
	@NotBlank(message = "'ManufactureName' is required")
	private String manufactureName;
	
	@NotNull(message = "'status' is required")
	private Integer status;
	
	@Pattern(regexp = "^[0-9]{10}$", message = "Contact number must contain only 10 digits") 
	@NotBlank(message = "'ContactNo' is required")
	private String contactNo;
	
	@NotNull(message = "'MdmDeviceTypeId' is required")
	private Integer mdmDeviceTypeId;
	
	@NotNull(message = "'MdmUserId' is required")
	private Integer mdmUserId;
	
	@Size(min = 6, max = 6, message = "Secure pin must be of 6 digits")
	@NotBlank(message = "Secure pin is required")
	private String securePin;
}
