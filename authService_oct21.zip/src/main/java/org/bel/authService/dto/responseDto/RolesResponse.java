package org.bel.authService.dto.responseDto;

import lombok.Data;

@Data
public class RolesResponse {
	private Integer id;
	private String name;
}
