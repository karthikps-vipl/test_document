package org.bel.authService.dto.requestDto;

import lombok.Data;

@Data
public class RefreshTokenRequest {
	private String token;
}
