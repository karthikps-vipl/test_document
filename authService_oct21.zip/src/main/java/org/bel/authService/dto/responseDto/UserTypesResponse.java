package org.bel.authService.dto.responseDto;

import lombok.Data;

@Data
public class UserTypesResponse {
	private Integer id;
	private String name;
}
