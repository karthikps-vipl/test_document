package org.bel.authService.dto.sync;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/** Only non-secret user metadata is replicated. Password material is deliberately excluded. */
public record UserCreatedSyncEvent(
        UUID eventId,
        String sourceNodeId,
        Integer sourceUserId,
        String serviceId,
        Integer mdmNodeId,
        Integer mdmRoleId,
        Integer mdmUserTypeId,
        Integer mdmLevelId,
        Integer mdmRankId,
        String usrName,
        Integer userStats,
        Integer failedLoginCount,
        boolean signupStatus,
        String createdBy,
        String email,
        LocalDate dateOfJoining,
        LocalDate passwordChangedAt,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        LocalDateTime lastLogin,
        LocalDateTime loginTime
) {}
