package org.bel.authService.dto.responseDto;

import lombok.Data;

@Data
public class NodesListResponse {
	private String id;
	private String name;
}
