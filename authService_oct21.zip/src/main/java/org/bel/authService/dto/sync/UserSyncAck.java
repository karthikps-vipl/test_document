package org.bel.authService.dto.sync;

import java.util.UUID;

public record UserSyncAck(UUID eventId, String status, String nodeId, String message) {}
