package org.bel.authService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;

import org.bel.authService.dto.responseDto.HealthResponse;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/api")
public class HealthController {

    private final EntityManager entityManager;

    @Autowired
    public HealthController(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @GetMapping("/health")
    public ResponseEntity<HealthResponse> getHealth() {
        try {
            entityManager.createNativeQuery("SELECT 1").getResultList();

            // Success: Returns HTTP 200 with status "UP"
            return ResponseEntity.ok(new HealthResponse("UP"));

        } catch (Exception e) {
            // Returns HTTP 503 with status "DOWN" and error code
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(new HealthResponse("DOWN"));
        }
    }    
}

