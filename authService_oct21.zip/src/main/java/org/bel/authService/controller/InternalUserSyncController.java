package org.bel.authService.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import org.bel.authService.dto.sync.UserCreatedSyncEvent;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.service.CurrentNodeResolver;
import org.bel.authService.service.UserSyncService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/internal/sync/users")
@RequiredArgsConstructor
public class InternalUserSyncController {
    private final UserSyncService userSyncService;
    private final CurrentNodeResolver currentNodeResolver;
    @Value("${sync.internal-token:}") private String internalToken;

    @PostMapping("/receive")
    public UserSyncAck receiveUser(@RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
                                   @RequestBody UserCreatedSyncEvent event) {
        if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return userSyncService.receiveUserCreated(event, currentNodeResolver.getCurrentNodeId());
    }
}
