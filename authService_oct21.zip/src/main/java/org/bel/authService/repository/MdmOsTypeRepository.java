package org.bel.authService.repository;

import org.bel.authService.entity.MdmNode;
import org.bel.authService.entity.MdmOsType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdmOsTypeRepository extends JpaRepository<MdmOsType, Integer>{

}
