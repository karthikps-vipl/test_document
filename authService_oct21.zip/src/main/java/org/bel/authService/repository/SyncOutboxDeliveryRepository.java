package org.bel.authService.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bel.authService.entity.SyncOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface SyncOutboxDeliveryRepository extends JpaRepository<SyncOutboxDelivery, Long> {
    Optional<SyncOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);
    List<SyncOutboxDelivery> findByEventId(UUID eventId);

    @Query("SELECT d FROM SyncOutboxDelivery d WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncOutbox s WHERE s.eventType = 'USER_CREATED') AND " +
           "(d.status = 'PENDING' OR (d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now))) " +
           "ORDER BY d.createdAt")
    List<SyncOutboxDelivery> findDispatchableUserDeliveries(@Param("now") LocalDateTime now);

    @Query("SELECT DISTINCT d.targetNodeId FROM SyncOutboxDelivery d WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncOutbox s WHERE s.eventType = 'USER_CREATED') AND d.status = 'WAITING_FOR_NODE'")
    List<String> findWaitingUserTargetNodeIds();

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'SENDING', d.sentAt = :now, d.nextRetryAt = NULL " +
           "WHERE d.id = :id AND (d.status = 'PENDING' OR (d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now)))")
    int claim(@Param("id") Long id, @Param("now") LocalDateTime now);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL, d.lastError = NULL " +
           "WHERE d.targetNodeId = :nodeId AND d.status = 'WAITING_FOR_NODE' AND d.eventId IN " +
           "(SELECT s.eventId FROM SyncOutbox s WHERE s.eventType = 'USER_CREATED')")
    int requeueWaitingForTargetNode(@Param("nodeId") String nodeId);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'WAITING_FOR_NODE', d.nextRetryAt = NULL, d.lastError = :error WHERE d.id = :id")
    int markWaiting(@Param("id") Long id, @Param("error") String error);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncOutbox s WHERE s.eventType = 'USER_CREATED') AND d.status = 'SENDING' AND d.sentAt < :cutoff")
    int resetStaleSending(@Param("cutoff") LocalDateTime cutoff);
}
