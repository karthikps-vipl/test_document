package org.bel.authService.repository;

import java.util.Optional;
import java.util.UUID;
import org.bel.authService.entity.SyncOutbox;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface SyncOutboxRepository extends JpaRepository<SyncOutbox, Long> {
    Optional<SyncOutbox> findByEventId(UUID eventId);

    @Query("SELECT s FROM SyncOutbox s WHERE s.eventType = 'USER_CREATED' AND s.status = 'PENDING' ORDER BY s.createdAt ASC")
    Page<SyncOutbox> findPendingUserEvents(Pageable pageable);

    @Query("SELECT COUNT(s) FROM SyncOutbox s WHERE s.eventType = 'USER_CREATED' AND s.status = 'PENDING'")
    long countPendingUserEvents();

    @Transactional
    @Modifying
    @Query("UPDATE SyncOutbox s SET s.status = :status, s.sentAt = :sentAt, s.lastError = :error WHERE s.eventId = :eventId")
    int updateStatus(@Param("eventId") UUID eventId, @Param("status") String status,
                     @Param("sentAt") java.time.LocalDateTime sentAt, @Param("error") String error);
}
