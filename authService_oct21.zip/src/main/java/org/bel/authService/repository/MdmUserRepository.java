package org.bel.authService.repository;
import org.bel.authService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

	@Repository
	public interface MdmUserRepository extends JpaRepository<MdmUser, Integer> {

	    Optional<MdmUser> findMdmUserByServiceId(@Param("serviceId") String serviceId);

	    @Modifying
	    @Query("UPDATE MdmUser u SET u.failedLoginCount = :count, u.userStats = :stats WHERE u.id = :id")
	    void updateFailedAttempts(@Param("id") Integer id, @Param("count") Integer count, @Param("stats") Integer stats);

	    @Modifying
	    @Query("UPDATE MdmUser u SET u.failedLoginCount = 0 WHERE u.id = :id")
	    void resetFailedAttempts(@Param("id") Integer id);
	    
	    List<MdmUser> findByUserStats(Integer userStats);
	    
	    List<MdmUser> findByUserStatsOrderByServiceIdAsc(Integer userStats);
	    
	    List<MdmUser> findAllByOrderByIdAsc();

		List<MdmUser> findAllByOrderByServiceIdAsc();

		Optional<MdmUser> findMdmUserByUsrPass(String usrPass);
	}
