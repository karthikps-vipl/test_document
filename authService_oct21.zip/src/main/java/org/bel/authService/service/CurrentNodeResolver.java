package org.bel.authService.service;

import java.net.InetAddress;
import org.bel.authService.entity.NodeRegistry;
import org.bel.authService.repository.NodeRegistryRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CurrentNodeResolver {
    private final NodeRegistryRepository repository;

    public NodeRegistry getCurrentNode() {
        String ip = getLocalIpAddress();
        return repository.findByIpAddress(ip).orElseThrow(() ->
                new IllegalStateException("Current server IP " + ip + " is not registered in node_registry"));
    }

    public String getCurrentNodeId() {
        return getCurrentNode().getNodeId();
    }

    private String getLocalIpAddress() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to determine local server IP", ex);
        }
    }
}
