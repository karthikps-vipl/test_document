package org.bel.authService.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.bel.authService.dto.sync.UserCreatedSyncEvent;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.entity.*;
import org.bel.authService.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserSyncService {
    private final ObjectMapper objectMapper;
    private final SyncOutboxRepository outboxRepository;
    private final SyncOutboxDeliveryRepository deliveryRepository;
    private final NodeRegistryRepository nodeRegistryRepository;
    private final CurrentNodeResolver currentNodeResolver;
    private final MdmUserRepository userRepository;
    private final MdmNodeRepository nodeRepository;
    private final MdmRoleRepository roleRepository;
    private final MdmUserTypeRepository userTypeRepository;
    private final MdmLevelRepository levelRepository;
    private final MdmRankRepository rankRepository;

    /** Called inside addUser's transaction: user and outbox event commit together. */
    @Transactional
    public void enqueueUserCreated(MdmUser user) {
        String localNodeId = currentNodeResolver.getCurrentNodeId();
        List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
        UUID eventId = UUID.randomUUID();
        UserCreatedSyncEvent event = toEvent(user, eventId, localNodeId);
        final String payload;
        try {
            payload = objectMapper.writeValueAsString(event);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to serialize USER_CREATED sync event", ex);
        }

        LocalDateTime now = LocalDateTime.now();
        SyncOutbox outbox = SyncOutbox.builder()
                .eventId(eventId).eventType("USER_CREATED").entityType("USER")
                .userId(user.getId()).sourceNodeId(localNodeId).eventVersion(1L)
                .payload(payload).status(peers.isEmpty() ? "ACKNOWLEDGED" : "PENDING")
                .retryCount(0).createdAt(now)
                .sentAt(peers.isEmpty() ? now : null).build();
        outboxRepository.save(outbox);

        for (NodeRegistry peer : peers) {
            boolean active = "ACTIVE".equalsIgnoreCase(peer.getStatus());
            deliveryRepository.save(SyncOutboxDelivery.builder()
                    .eventId(eventId).targetNodeId(peer.getNodeId())
                    .status(active ? "PENDING" : "WAITING_FOR_NODE")
                    .retryCount(0).createdAt(now)
                    .lastError(active ? null : "Target node is inactive at event creation")
                    .build());
        }
    }

    /** Idempotent receiver: serviceId is the cross-node business key, not local numeric id. */
    @Transactional
    public UserSyncAck receiveUserCreated(UserCreatedSyncEvent event, String receivingNodeId) {
        if (event == null || event.eventId() == null || event.serviceId() == null || event.serviceId().isBlank()) {
            throw new IllegalArgumentException("eventId and serviceId are required");
        }
        if (userRepository.findMdmUserByServiceId(event.serviceId()).isPresent()) {
            return new UserSyncAck(event.eventId(), "ACKNOWLEDGED", receivingNodeId,
                    "User already exists; duplicate event safely ignored");
        }

        MdmUser user = new MdmUser();
        user.setServiceId(event.serviceId());
        user.setMdmNodeId(nodeRepository.findById(event.mdmNodeId())
                .orElseThrow(() -> new IllegalStateException("Missing mdm_node id " + event.mdmNodeId())));
        user.setMdmRoleId(roleRepository.findById(event.mdmRoleId())
                .orElseThrow(() -> new IllegalStateException("Missing mdm_role id " + event.mdmRoleId())));
        user.setMdmUserTypeId(userTypeRepository.findById(event.mdmUserTypeId())
                .orElseThrow(() -> new IllegalStateException("Missing mdm_user_type id " + event.mdmUserTypeId())));
        user.setMdmLevelId(levelRepository.findById(event.mdmLevelId())
                .orElseThrow(() -> new IllegalStateException("Missing mdm_level id " + event.mdmLevelId())));
        user.setMdmRankId(rankRepository.findById(event.mdmRankId())
                .orElseThrow(() -> new IllegalStateException("Missing mdm_rank id " + event.mdmRankId())));
        user.setUsrName(event.usrName());
        // Credential material is intentionally not replicated.
        user.setUsrPass("");
        user.setUserStats(event.userStats());
        user.setFailedLoginCount(event.failedLoginCount() == null ? 0 : event.failedLoginCount());
        user.setSignupStatus(event.signupStatus());
        user.setCreatedBy(event.createdBy());
        user.setEmail(event.email());
        user.setDateOfJoining(event.dateOfJoining());
        user.setPasswordChangedAt(event.passwordChangedAt());
        user.setCreatedAt(event.createdAt() == null ? LocalDateTime.now() : event.createdAt());
        user.setUpdatedAt(event.updatedAt() == null ? LocalDateTime.now() : event.updatedAt());
        user.setLastLogin(event.lastLogin());
        user.setLoginTime(event.loginTime());
        userRepository.saveAndFlush(user);
        return new UserSyncAck(event.eventId(), "ACKNOWLEDGED", receivingNodeId, "User created");
    }

    public UserCreatedSyncEvent parsePayload(String payload) {
        try { return objectMapper.readValue(payload, UserCreatedSyncEvent.class); }
        catch (Exception ex) { throw new IllegalStateException("Invalid USER_CREATED payload", ex); }
    }

    private UserCreatedSyncEvent toEvent(MdmUser user, UUID eventId, String localNodeId) {
        return new UserCreatedSyncEvent(eventId, localNodeId, user.getId(), user.getServiceId(),
                user.getMdmNodeId() == null ? null : user.getMdmNodeId().getId(),
                user.getMdmRoleId() == null ? null : user.getMdmRoleId().getId(),
                user.getMdmUserTypeId() == null ? null : user.getMdmUserTypeId().getId(),
                user.getMdmLevelId() == null ? null : user.getMdmLevelId().getId(),
                user.getMdmRankId() == null ? null : user.getMdmRankId().getId(),
                user.getUsrName(), user.getUserStats(), user.getFailedLoginCount(), user.isSignupStatus(),
                user.getCreatedBy(), user.getEmail(), user.getDateOfJoining(), user.getPasswordChangedAt(),
                user.getCreatedAt(), user.getUpdatedAt(), user.getLastLogin(), user.getLoginTime());
    }
}
