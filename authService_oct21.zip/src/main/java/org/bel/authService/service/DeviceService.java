package org.bel.authService.service;

import org.bel.authService.dto.responseDto.*;
import org.bel.authService.dto.responseDto.*;

import java.util.List;

import org.bel.authService.dto.requestDto.AddDeviceRequest;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditDeviceRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;

public interface DeviceService {
	SingleResponse<DeviceStatsResponse> getDeviceStats();
	
	SingleResponse<DeviceListResponse> getDeviceList();
	
	SingleResponse<DeviceListTypeResponse> getDeviceListType(String type);
	
	SingleResponse<DeviceTypeResponse> getDeviceTypes();

	SingleResponse<AddDeviceResponse> addDevice(@Valid AddDeviceRequest request);
	
	SingleResponse<?> editDevice(@Valid EditDeviceRequest request,Integer deviceId);
	
	SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage();
	
	SingleResponse<?> deleteDevices(List<Integer> deviceIds);
	
	SingleResponse<?> deleteDevice(Integer deviceId);
}
