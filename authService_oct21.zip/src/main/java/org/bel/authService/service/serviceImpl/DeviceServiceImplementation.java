package org.bel.authService.service.serviceImpl;

import org.bel.authService.dto.responseDto.*;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.bel.authService.dto.requestDto.AddDeviceRequest;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditDeviceRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.responseDto.DeviceStatsResponse.DeviceDetail;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.entity.LaaGroupTracking;
import org.bel.authService.entity.LaaUeLocationHist;
import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmLevel;
import org.bel.authService.entity.MdmNode;
import org.bel.authService.entity.MdmOsType;
import org.bel.authService.entity.MdmRank;
import org.bel.authService.entity.MdmRole;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserType;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.repository.LaaGroupTrackingRepository;
import org.bel.authService.repository.LaaUeLocationHistRepository;
import org.bel.authService.repository.MdmDeviceTypeRepository;
import org.bel.authService.repository.MdmLevelRepository;
import org.bel.authService.repository.MdmNodeRepository;
import org.bel.authService.repository.MdmOsTypeRepository;
import org.bel.authService.repository.MdmRankRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.service.DeviceService;
import org.bel.authService.service.MdmUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j

public class DeviceServiceImplementation implements DeviceService {
	private final MdmUeRepository mdmUeRepository;
	private final MdmUserUeMappingRepository mdmUserUeMappingRepository;
	private final MdmUserRepository userRepository;
	private final MdmDeviceTypeRepository mdmDeviceTypeRepository;
	private final LaaUeLocationHistRepository laaUeLocationHistRepository;
	private final MdmUserTypeRepository mdmUserTypeRepository;
	private final MdmOsTypeRepository mdmOsTypeRepository;
	private final LaaGroupTrackingRepository laaGroupTrackingRepository;

	private static final double REFERENCE_LATITUDE = 13.053524;
	private static final double REFERENCE_LONGITUDE = 77.561265;

	@Transactional
	public SingleResponse<DeviceStatsResponse> getDeviceStats() {
		LocalDateTime fourHoursAgo = LocalDateTime.now().minusHours(4);
		long totalDevices = mdmUeRepository.getTotalDevicesCount();
		Map<String, Object> groups = mdmUeRepository.getTacticalGroupCounts();
		Map<String, Object> counts = mdmUeRepository.getDeviceCounts(fourHoursAgo);
		int activeDevices = ((Number) counts.get("active_devices")).intValue();
		int detachedDevices = ((Number) counts.get("detached_devices")).intValue();
		int fencingViolations = ((Number) counts.get("fencing_violations")).intValue();
		int todayCount = ((Number) counts.get("today")).intValue();
		int criticalDevices = ((Number) counts.get("critical_devices")).intValue();
		long totalGroups = ((Number) groups.get("total_groups")).longValue();
		long activeGroups = ((Number) groups.get("active_groups")).longValue();
		int activePercentage = totalDevices > 0 ? Math.round((float) activeDevices / totalDevices * 100) : 0;
		int detachedPercentage = totalDevices > 0 ? Math.round((float) todayCount / detachedDevices * 100) : 0;
		int fencingPercentage = totalDevices > 0 ? Math.round((float) criticalDevices / fencingViolations * 100) : 0;
		int tacticalPercentage = totalGroups > 0 ? Math.round((float) activeGroups / totalGroups * 100) : 0;
		DeviceStatsResponse dto = DeviceStatsResponse.builder()
				.ueDevices(DeviceDetail.builder().total(totalDevices).value("Active " + activeDevices)
						.percentage(activePercentage).build())
				.detachedUe(DeviceDetail.builder().total(detachedDevices).value("Today " + todayCount)
						.percentage(detachedPercentage).build())
				.fencingViolation(DeviceDetail.builder().total(fencingViolations).value("Critical " + criticalDevices)
						.percentage(fencingPercentage).build())
				.tacticalGroups(DeviceDetail.builder().total(totalGroups).value("Active " + activeGroups)
						.percentage(tacticalPercentage).build())
				.build();
		return new SingleResponse<>(dto, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceListResponse> getDeviceList() {
		List<MdmUser> mdmUsers = userRepository.findAllByOrderByIdAsc();
		List<MdmUserUeMapping> allMappings = mdmUserUeMappingRepository.findAll();
		Map<Integer, MdmUserUeMapping> mappingMap = allMappings.stream()
				.collect(Collectors.toMap(mdmUserMap -> mdmUserMap.getMdmUserId().getId(), mapping -> mapping,
						(existing, replacement) -> existing));
		Set<Integer> deviceIds = allMappings.stream().map(m -> m.getMdmUeId().getId()).collect(Collectors.toSet());
		Map<Integer, MdmUe> deviceMap = mdmUeRepository.findAllById(deviceIds).stream()
				.collect(Collectors.toMap(MdmUe::getId, device -> device));
		List<DeviceListResponse> deviceListResponses = mdmUsers.stream().map(user -> {
			MdmUserUeMapping mapping = mappingMap.get(user.getId());
			if (mapping == null)
				return null;
			MdmUe device = deviceMap.get(mapping.getMdmUeId().getId());
			if (device == null)
				return null;
			DeviceListResponse response = new DeviceListResponse();
			response.setId(device.getId());
			response.setDeviceId(device.getDeviceId());
			response.setDeviceName(device.getDeviceName());
			if (device.getMdmDeviceType() != null) {
				response.setDeviceTypeId(device.getMdmDeviceType().getId());
				response.setDeviceType(device.getMdmDeviceType().getDeviceType());
			}
			response.setStatus(device.getStatus());
			response.setContactNo(device.getContactNo());
			DeviceListUserResponse userResponse = new DeviceListUserResponse();
			userResponse.setUserId(user.getId());
			userResponse.setServiceId(user.getServiceId());
			userResponse.setUsrName(user.getUsrName());
			response.setUsers(userResponse);
			response.setSecurePin(device.getSecurePin());
			return response;
		}).filter(Objects::nonNull).toList();
		return new SingleResponse(deviceListResponses, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceListTypeResponse> getDeviceListType(String type) {
		List<DeviceListTypeResponse> deviceListTypeResponses = null;
	    List<MdmUe> devices = mdmUeRepository.findAllByOrderByIdAsc();
	    List<MdmUser> users = userRepository.findAll();
	    List<LaaGroupTracking> groupTrackings = laaGroupTrackingRepository.findAll();
	    List<LaaUeLocationHist> laaUeLocationHist = laaUeLocationHistRepository.findAll();

	    Map<Integer, List<LaaUeLocationHist>> historyByUserMap = laaUeLocationHist.stream()
	            .collect(Collectors.groupingBy(h -> h.getMdmUser().getId()));
	    Map<Integer, MdmUe> deviceMap = devices.stream()
	            .collect(Collectors.toMap(MdmUe::getId, ue -> ue, (existing, replacement) -> existing));
	    Map<Integer, MdmUser> userMap = users.stream()
	            .collect(Collectors.toMap(MdmUser::getId, u -> u, (existing, replacement) -> existing));

	    switch (type) {
	        case "ue_devices":
	            Map<Integer, LaaUeLocationHist> mdmUeIdMap = laaUeLocationHist.stream()
	                    .collect(Collectors.toMap(m -> m.getMdmUe().getId(), m -> m, (existing, replacement) -> existing));
	            
	            Set<Integer> userIds = laaUeLocationHist.stream().map(m -> m.getMdmUser().getId()).collect(Collectors.toSet());
	            Map<Integer, MdmUser> userToDeviceMap = userRepository.findAllById(userIds).stream()
	                    .collect(Collectors.toMap(MdmUser::getId, u -> u));

	            deviceListTypeResponses = devices.stream().map(device -> {
	                LaaUeLocationHist mapping = mdmUeIdMap.get(device.getId());
	                if (mapping == null || mapping.getMdmUser() == null) return null;

	                MdmUser user = userToDeviceMap.get(mapping.getMdmUser().getId());
	                if (user == null) return null;

	                DeviceListTypeResponse response = new DeviceListTypeResponse();
	                response.setDeviceId(device.getDeviceId());
	                response.setDeviceName(device.getDeviceName());
	                response.setUsername(user.getUsrName());

	                // Distance
	                Double dist = mdmUeRepository.getDistance(device.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
	                response.setDistance(dist != null ? String.format("%.2f km", dist / 1000.0) : "0.00 km");

	                // Time and Status
	                LocalDateTime now = LocalDateTime.now();
	                Object rawTime = mapping.getCreatedTime();
	                LocalDateTime historyTime = (rawTime instanceof LocalDateTime) ? (LocalDateTime) rawTime : null;

	                if (historyTime != null) {
	                    if (historyTime.isAfter(now.minusHours(4))) {
	                        response.setStatus("Active");
	                    } else {
	                        response.setStatus("Inactive");
	                    }
	                    // SAFE DURATION CALL
	                    Duration d = Duration.between(historyTime, now);
	                    if (d.isNegative()) response.setLastUpdated("Just now");
	                    else if (d.getSeconds() < 60) response.setLastUpdated("Just now");
	                    else if (d.toMinutes() < 60) response.setLastUpdated(d.toMinutes() + " mins ago");
	                    else if (d.toHours() < 24) response.setLastUpdated(d.toHours() + " hours ago");
	                    else response.setLastUpdated(d.toDays() + " days ago");
	                } else {
	                    response.setStatus("Inactive");
	                    response.setLastUpdated("N/A");
	                }
	                return response;
	            }).filter(Objects::nonNull).toList();
	            break;

	        case "tactical_groups":
	            deviceListTypeResponses = groupTrackings.stream()
	                    .sorted(Comparator.comparing(LaaGroupTracking::getId))
	                    .filter(gt -> gt.getGroupStats() != 2)
	                    .map(gt -> {
	                        Integer userId = gt.getMdmUser().getId();
	                        List<LaaUeLocationHist> userHistories = historyByUserMap.getOrDefault(userId, Collections.emptyList());
	                        if (userHistories.isEmpty()) return null;

	                        LaaUeLocationHist latest = userHistories.stream()
	                                .max(Comparator.comparing(h -> (h.getCreatedTime() instanceof LocalDateTime ? (LocalDateTime)h.getCreatedTime() : LocalDateTime.MIN)))
	                                .orElse(null);

	                        if (latest == null || latest.getMdmUe() == null) return null;
	                        MdmUe ue = deviceMap.get(latest.getMdmUe().getId());
	                        MdmUser user = userMap.get(userId);
	                        if (ue == null || user == null) return null;

	                        DeviceListTypeResponse resp = new DeviceListTypeResponse();
	                        resp.setDeviceId(ue.getDeviceId());
	                        resp.setDeviceName(ue.getDeviceName());
	                        resp.setUsername(user.getUsrName());

	                        Double dist = mdmUeRepository.getDistance(ue.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
	                        resp.setDistance(dist != null ? String.format("%.2f km", dist / 1000.0) : "0.00 km");
	                        resp.setStatus(gt.getGroupStats() == 1 ? "Active" : "Inactive");

	                        Object rt = latest.getCreatedTime();
	                        LocalDateTime hTime = (rt instanceof LocalDateTime) ? (LocalDateTime) rt : null;
	                        if (hTime != null) {
	                            LocalDateTime now = LocalDateTime.now();
	                            Duration d = Duration.between(hTime, now);
	                            if (d.isNegative()) resp.setLastUpdated("Just now");
	                            else if (d.getSeconds() < 60) resp.setLastUpdated("Just now");
	                            else if (d.toMinutes() < 60) resp.setLastUpdated(d.toMinutes() + " mins ago");
	                            else if (d.toHours() < 24) resp.setLastUpdated(d.toHours() + " hours ago");
	                            else resp.setLastUpdated(d.toDays() + " days ago");
	                        } else {
	                            resp.setLastUpdated("N/A");
	                        }
	                        return resp;
	                    }).filter(Objects::nonNull).toList();
	            break;

	        case "detached_ue":
	            deviceListTypeResponses = deviceMap.values().stream().map(u -> {
	                MdmUser user = userMap.get(u.getId());
	                String username = (user != null) ? user.getUsrName() : "Unknown";
	                List<LaaUeLocationHist> deviceHistories = laaUeLocationHist.stream()
	                        .filter(h -> h.getMdmUe().getId().equals(u.getId()) && h.getMdmUser().getId().equals(u.getId()))
	                        .toList();

	                if (deviceHistories.isEmpty()) return null;
	                
	                // Check for valid node
	                boolean hasValidNode = deviceHistories.stream().anyMatch(h -> h.getMdmNode().getId() != 1);
	                if (!hasValidNode) return null;

	                LaaUeLocationHist latest = deviceHistories.stream()
	                        .max(Comparator.comparing(h -> (h.getCreatedTime() instanceof LocalDateTime ? (LocalDateTime)h.getCreatedTime() : LocalDateTime.MIN)))
	                        .orElse(null);

	                if (latest == null) return null;

	                DeviceListTypeResponse resp = new DeviceListTypeResponse();
	                resp.setDeviceId(u.getDeviceId());
	                resp.setDeviceName(u.getDeviceName());
	                resp.setUsername(username);

	                Double dist = mdmUeRepository.getDistance(u.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
	                resp.setDistance(dist != null ? String.format("%.2f km", dist / 1000.0) : "0.00 km");

	                Object rt = latest.getCreatedTime();
	                LocalDateTime hTime = (rt instanceof LocalDateTime) ? (LocalDateTime) rt : null;
	                if (hTime != null) {
	                    LocalDateTime now = LocalDateTime.now();
	                    Duration d = Duration.between(hTime, now);
	                    if (d.isNegative()) resp.setLastUpdated("Just now");
	                    else if (d.getSeconds() < 60) resp.setLastUpdated("Just now");
	                    else if (d.toMinutes() < 60) resp.setLastUpdated(d.toMinutes() + " mins ago");
	                    else if (d.toHours() < 24) resp.setLastUpdated(d.toHours() + " hours ago");
	                    else resp.setLastUpdated(d.toDays() + " days ago");

	                    resp.setStatus(d.toDays() < 1 ? "Today" : d.toDays() + " days ago");
	                } else {
	                    resp.setLastUpdated("N/A");
	                }
	                return resp;
	            }).filter(Objects::nonNull).toList();
	            break;

	        case "fencing_violation":
	            deviceListTypeResponses = deviceMap.values().stream().map(u -> {
	                MdmUser user = userMap.get(u.getId());
	                List<LaaUeLocationHist> userHistories = historyByUserMap.getOrDefault(u.getId(), Collections.emptyList());
	                
	                LaaUeLocationHist latestViolation = userHistories.stream()
	                        .filter(h -> h.getLatitude().compareTo(REFERENCE_LATITUDE) != 0 || h.getLongitude().compareTo(REFERENCE_LONGITUDE) != 0)
	                        .max(Comparator.comparing(h -> (h.getCreatedTime() instanceof LocalDateTime ? (LocalDateTime)h.getCreatedTime() : LocalDateTime.MIN)))
	                        .orElse(null);

	                if (latestViolation == null) return null;

	                DeviceListTypeResponse resp = new DeviceListTypeResponse();
	                resp.setDeviceId(u.getDeviceId());
	                resp.setDeviceName(u.getDeviceName());
	                resp.setUsername(user != null ? user.getUsrName() : "Unknown");

	                Double dist = mdmUeRepository.getDistance(u.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
	                if (dist != null) {
	                    double km = dist / 1000.0;
	                    resp.setDistance(String.format("%.2f km", km));
	                    resp.setStatus(km > 1.0 ? "Critical" : "Violated");
	                } else {
	                    resp.setDistance("0.00 km");
	                }

	                Object rt = latestViolation.getCreatedTime();
	                LocalDateTime hTime = (rt instanceof LocalDateTime) ? (LocalDateTime) rt : null;
	                if (hTime != null) {
	                    LocalDateTime now = LocalDateTime.now();
	                    Duration d = Duration.between(hTime, now);
	                    if (d.isNegative()) resp.setLastUpdated("Just now");
	                    else if (d.getSeconds() < 60) resp.setLastUpdated("Just now");
	                    else if (d.toMinutes() < 60) resp.setLastUpdated(d.toMinutes() + " mins ago");
	                    else if (d.toHours() < 24) resp.setLastUpdated(d.toHours() + " hours ago");
	                    else resp.setLastUpdated(d.toDays() + " days ago");
	                }
		        
		            return resp;
		        })
		        .filter(Objects::nonNull)
		        .toList();
		    break;
		}return new SingleResponse(deviceListTypeResponses,CustomStatus.SUCCESS);

	}

	@Transactional
	public SingleResponse<DeviceTypeResponse> getDeviceTypes() {
		List<MdmDeviceType> mdmDeviceTypes = mdmDeviceTypeRepository.findAllByOrderByIdAsc();
		List<DeviceTypeResponse> responseList = new ArrayList<>();
		for (MdmDeviceType mdmDeviceType : mdmDeviceTypes) {
			DeviceTypeResponse dto = new DeviceTypeResponse();
			dto.setId(mdmDeviceType.getId());
			dto.setName(mdmDeviceType.getDeviceType());
			responseList.add(dto);
		}
		return new SingleResponse(responseList, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<AddDeviceResponse> addDevice(AddDeviceRequest request) {
		Optional<MdmUe> existingDevice = mdmUeRepository.findMdmUeByDeviceId(request.getDeviceId());
		if (existingDevice.isPresent()) {
			throw new CustomException("Device Id '" + request.getDeviceId() + "' already exists",
					CustomStatus.DEVICE_ALREADY_EXISTS, 400);
		}
		boolean deviceTypeExists = mdmDeviceTypeRepository.existsById(request.getMdmDeviceTypeId());
		if (!deviceTypeExists) {
			throw new CustomException("invalid mdmDeviceTypeId", CustomStatus.BAD_REQUEST, 400);
		}
		boolean userExists = userRepository.existsById(request.getMdmUserId());
		if (!userExists) {
			throw new CustomException("invalid mdmUserId", CustomStatus.BAD_REQUEST, 400);
		}
		MdmUe newDevice = new MdmUe();
		MdmUserUeMapping mdmUserUeMapping = new MdmUserUeMapping();
		newDevice.setDeviceId(request.getDeviceId());
		newDevice.setDeviceName(request.getDeviceName());
		newDevice.setManufactureName(request.getManufactureName());
		newDevice.setStatus(request.getStatus());
		newDevice.setContactNo(request.getContactNo());
		if (request.getMdmDeviceTypeId() != null) {
			MdmDeviceType deviceType = mdmDeviceTypeRepository.findById(request.getMdmDeviceTypeId())
					.orElseThrow(() -> new CustomException("MdmDeviceType not found", CustomStatus.BAD_REQUEST, 400));
			newDevice.setMdmDeviceType(deviceType);
		}
		if (request.getMdmUserId() != null) {
			MdmUser user = userRepository.findById(request.getMdmUserId())
					.orElseThrow(() -> new CustomException("MdmUser not found", CustomStatus.BAD_REQUEST, 400));
			mdmUserUeMapping.setMdmUserId(user);
		}
		newDevice.setSecurePin(request.getSecurePin());
		newDevice.setCreatedAt(LocalDate.now());
		newDevice.setFailedLoginCount(0);
		mdmUeRepository.save(newDevice);
		MdmUe device = mdmUeRepository.findById(newDevice.getId())
				.orElseThrow(() -> new CustomException("MdmUe not found", CustomStatus.BAD_REQUEST, 400));
		mdmUserUeMapping.setMdmUeId(device);
		mdmUserUeMappingRepository.save(mdmUserUeMapping);
		AddDeviceResponse response = new AddDeviceResponse();
		response.setId(newDevice.getId());
		response.setCreatedAt(newDevice.getCreatedAt());
		response.setFailedLoginCount(newDevice.getFailedLoginCount());
		response.setDeviceId(newDevice.getDeviceId());
		response.setDeviceName(newDevice.getDeviceName());
		response.setManufactureName(newDevice.getManufactureName());
		response.setStatus(newDevice.getStatus());
		response.setContactNo(newDevice.getContactNo());
		response.setMdmDeviceTypeId(newDevice.getMdmDeviceType().getId());
		response.setSecurePin(newDevice.getSecurePin());
		response.setUpdatedAt(newDevice.getUpdatedAt());
		response.setCreatedBy(newDevice.getCreatedBy());
		response.setUpdatedBy(newDevice.getUpdatedBy());
		response.setDeviceType(newDevice.getDeviceType());
		response.setImeiNumber(newDevice.getImeiNumber());
		response.setSimNumber(newDevice.getSimNumber());
		response.setMdmOsTypeId(null);
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<?> editDevice(@Valid EditDeviceRequest request, Integer deviceId) {
		MdmUe mdmUe = mdmUeRepository.findById(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));
		Optional<MdmUe> existingDevice = mdmUeRepository.findMdmUeByDeviceId(request.getDeviceId());
		if (existingDevice.isPresent()) {
			throw new CustomException("Device Id '" + request.getDeviceId() + "' already exists",
					CustomStatus.DEVICE_ALREADY_EXISTS, 400);
		}
		if (mdmUe.getStatus() == 1) {
			mdmUe.setFailedLoginCount(0);
		}
		if (request.getDeviceId() != null) {
			mdmUe.setDeviceId(request.getDeviceId());
		}
		if (request.getDeviceName() != null) {
			mdmUe.setDeviceName(request.getDeviceName());
		}
		if (request.getContactNo() != null) {
			mdmUe.setContactNo(request.getContactNo());
		}
		if (request.getMdmDeviceTypeId() != null) {
			MdmDeviceType mdmDeviceType = mdmDeviceTypeRepository.findById(request.getMdmDeviceTypeId())
					.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_TYPE_NOT_FOUND, 404));
			mdmUe.setMdmDeviceType(mdmDeviceType);

		}
		if (request.getSecurePin() != null) {
			mdmUe.setSecurePin(request.getSecurePin());
		}
		mdmUeRepository.save(mdmUe);
		if (request.getMdmUserId() != null) {
			MdmUserUeMapping mdmUserUeMapping = mdmUserUeMappingRepository
					.findMdmUserUeMappingByMdmUserId(request.getMdmUserId())
					.orElseThrow(() -> new CustomException(CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 404));
			if (mdmUserUeMapping != null) {
				MdmUser mdmUser = userRepository.findById(request.getMdmUserId())
						.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
				mdmUserUeMapping.setMdmUserId(mdmUser);
				mdmUserUeMapping.setMdmUeId(mdmUe);
				mdmUserUeMappingRepository.save(mdmUserUeMapping);
			} else {
				MdmUserUeMapping newMdmUserUeMapping = new MdmUserUeMapping();
				MdmUser mdmUser = userRepository.findById(request.getMdmUserId())
						.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
				newMdmUserUeMapping.setMdmUeId(mdmUe);
				newMdmUserUeMapping.setMdmUserId(mdmUser);
				mdmUserUeMappingRepository.save(newMdmUserUeMapping);
			}
		}
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage() {
		List<MdmUe> allUes = mdmUeRepository.findAll();
		List<MdmUser> allUsers = userRepository.findAll();
		List<MdmUserType> allUserTypes = mdmUserTypeRepository.findAll();
		List<LaaUeLocationHist> allHistories = laaUeLocationHistRepository.findAll();
		LocalDateTime fourHoursAgo = LocalDateTime.now().minusHours(4);
		List<DeviceMappingPercentageResponse> deviceMappingList = new ArrayList<>();
		Map<Integer, List<LaaUeLocationHist>> userTypeToHistoriesMap = allHistories.stream()
				.filter(h -> h.getMdmUser() != null && h.getMdmUser().getMdmUserTypeId() != null)
				.collect(Collectors.groupingBy(h -> {
					Integer id = h.getMdmUser().getMdmUserTypeId().getId();
					return id;
				}));
		long totalDevicesCount = allUes.size();
		long activeDevicesCount = allUes.stream().filter(ue -> {
			return ue.getStatus() == 1 && allHistories.stream().anyMatch(h -> h.getMdmUe().getId().equals(ue.getId())
					&& h.getMdmUser().getUserStats() == 1 && h.getCreatedTime().isAfter(fourHoursAgo));
		}).distinct().count();
		List<Map<String, Object>> rankedList = new ArrayList<>();
		for (MdmUserType type : allUserTypes) {
			List<LaaUeLocationHist> typeHistories = userTypeToHistoriesMap.getOrDefault(type.getId(),
					Collections.emptyList());
			long distinctDeviceCount = typeHistories.stream().map(h -> h.getMdmUe().getId()).distinct().count();
			long recentDistinctDeviceCount = typeHistories.stream()
					.filter(h -> h.getCreatedTime().isAfter(fourHoursAgo)).map(h -> h.getMdmUe().getId()).distinct()
					.count();
			if (recentDistinctDeviceCount > 0) {
				Map<String, Object> row = new HashMap<>();
				row.put("id", type.getId());
				row.put("name", type.getUsrType());
				row.put("count", recentDistinctDeviceCount);
				rankedList.add(row);
			}
		}
		rankedList.sort((a, b) -> Long.compare((long) b.get("count"), (long) a.get("count")));
		Map<String, DeviceMappingPercentageResponse.CountDetail> dynamicFieldsMap = new LinkedHashMap<>();
		long otherCount = 0;
		for (int i = 0; i < rankedList.size(); i++) {
			Map<String, Object> row = rankedList.get(i);
			long count = (long) row.get("count");
			int typeId = (int) row.get("id");
			String typeName = (String) row.get("name");
			if (i < 4) {
				float percentage = (totalDevicesCount == 0) ? 0f : (float) ((count * 100.0) / totalDevicesCount);
				dynamicFieldsMap.put(String.valueOf(typeId), DeviceMappingPercentageResponse.CountDetail.builder()
						.name(typeName).count((int) count).percentage(percentage).build());
			} else {
				otherCount += count;
			}
		}
		if (otherCount > 0) {
			float otherPercentage = (totalDevicesCount == 0) ? 0f : (float) ((otherCount * 100.0) / totalDevicesCount);
			dynamicFieldsMap.put("0", DeviceMappingPercentageResponse.CountDetail.builder().name("Other")
					.count((int) otherCount).percentage(otherPercentage).build());
		} else if (totalDevicesCount > 0 && rankedList.isEmpty()) {
			dynamicFieldsMap.put("0", DeviceMappingPercentageResponse.CountDetail.builder().name("Other").count(0)
					.percentage(0f).build());
		}
		DeviceMappingPercentageResponse responseDto = DeviceMappingPercentageResponse.builder()
				.total((int) totalDevicesCount).active((int) activeDevicesCount).dynamicFields(dynamicFieldsMap)
				.build();
		deviceMappingList.add(responseDto);
		return new SingleResponse(deviceMappingList, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<?> deleteDevices(List<Integer> deviceIds) {
		for (Integer id : deviceIds) {
			MdmUe device = mdmUeRepository.findById(id)
					.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));
			MdmUserUeMapping mdmUserUeMapping = mdmUserUeMappingRepository.findMdmUserUeMappingByMdmUeId(id)
					.orElseThrow(() -> new CustomException(CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 404));
			if (mdmUserUeMapping != null) {
				device.setStatus(0);
			} else {
				mdmUeRepository.deleteById(id);
			}
			mdmUeRepository.save(device);
		}
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<?> deleteDevice(Integer deviceId) {
		MdmUe device = mdmUeRepository.findById(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));
		mdmUeRepository.deleteById(deviceId);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
}