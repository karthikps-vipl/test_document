package org.bel.location.event;

/** Published whenever a node-registry row is inserted or updated locally. */
public record NodeRegistryChangedEvent(String nodeId, String status) {
}
