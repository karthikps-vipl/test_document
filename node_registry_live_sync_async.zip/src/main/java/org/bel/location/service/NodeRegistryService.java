package org.bel.location.service;

import java.time.OffsetDateTime;
import java.util.List;

import org.apache.commons.validator.routines.InetAddressValidator;
import org.bel.location.constants.AppConstants;
import org.bel.location.dto.request.ChangeNodeStatusRequest;
import org.bel.location.dto.request.NodeRegistryRequest;
import org.bel.location.dto.response.NodeRegistryResponse;
import org.bel.location.dto.response.SingleResponse;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.enums.CustomStatus;
import org.bel.location.exception.CustomException;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeRegistryService {
	private final NodeRegistryRepository repo;
	private final CurrentNodeResolver resolver;
	private final NodeRegistrySyncService registrySyncService;
	
	@Value("${server.port}")
	private Integer port;

	public NodeRegistry getCurrentNode() {
		return resolver.getCurrentNode();
	}

	public String getCurrentNodeId() {
		return resolver.getCurrentNodeId();
	}

	public List<NodeRegistry> getOtherActiveNodes() {
		System.out.println("currrent Node id:" + resolver.getCurrentNode());
		return repo.findByStatusAndNodeIdNot(AppConstants.ACTIVE, resolver.getCurrentNodeId());
	}

	public List<NodeRegistry> getOtherRegisteredNodes() {
		return repo.findByNodeIdNot(resolver.getCurrentNodeId());
	}

	public SingleResponse<List<NodeRegistryResponse>> getAllNodesList(String roleId) {

		if (Integer.parseInt(roleId) != 1) {
			throw new CustomException(CustomStatus.UNAUTHORISED, 401);
		}

		List<NodeRegistry> nodesList = repo.findAllOrderByNodeIdAsc();

		List<NodeRegistryResponse> response = nodesList.stream().map(node -> {
			NodeRegistryResponse nodeResponse = new NodeRegistryResponse();
			nodeResponse.setNodeId(node.getNodeId());
			nodeResponse.setNodeName(node.getNodeName());
			nodeResponse.setIpAddress(node.getIpAddress());
			nodeResponse.setPort(node.getPort());
			nodeResponse.setStatus(node.getStatus());

			return nodeResponse;
		}).toList();
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	public SingleResponse<String> createNode(String roleId, @Valid NodeRegistryRequest request) {
		
		log.info("Current Node Id :{}",resolver.getCurrentNodeId());


		if (Integer.parseInt(roleId) != 1) {
			throw new CustomException(CustomStatus.UNAUTHORISED, 401);
		}

		if (!isValidIp(request.getIpAddress().trim())) {
			throw new CustomException(CustomStatus.INVALID_IP_ADDRESS, 400);
		}

		boolean isIpInUse = repo.existsByIpAddressAndStatus(request.getIpAddress(), AppConstants.ACTIVE_STATUS);

		if (isIpInUse) {
			throw new CustomException(CustomStatus.DUPLICATE_IP, 409);
		}
		
		String node = AppConstants.NODE_CONSTANT +request.getNodeId().trim().toUpperCase();

		NodeRegistry newNode = new NodeRegistry();
		newNode.setNodeId(node);
		newNode.setNodeName(request.getNodeName() == null || request.getNodeName().isBlank() ? node : request.getNodeName().trim());
		newNode.setStatus(AppConstants.ACTIVE_STATUS);
		newNode.setCreatedAt(OffsetDateTime.now());
		newNode.setIpAddress(request.getIpAddress());
		newNode.setUpdatedAt(OffsetDateTime.now());
		newNode.setPort(request.getPort() == null ? port : request.getPort());
		
		
		newNode = repo.save(newNode);
		log.info("New node created :{}",newNode);
		registrySyncService.registryChanged(newNode);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	public SingleResponse<String> changeNodeStatus(String roleId, ChangeNodeStatusRequest request) {

		if (Integer.parseInt(roleId) != 1) {
			throw new CustomException(CustomStatus.UNAUTHORISED, 401);
		}

		NodeRegistry node = repo.findByNodeId(request.getNodeId().trim().toUpperCase())
				.orElseThrow(() -> new CustomException(CustomStatus.NODE_NOT_FOUND, 400));

		node.setStatus(request.getStatus().equalsIgnoreCase(AppConstants.ACTIVE_STATUS) ? AppConstants.ACTIVE_STATUS : AppConstants.DEACTIVE_STATUS);
		node.setUpdatedAt(OffsetDateTime.now());
		node = repo.save(node);
		registrySyncService.registryChanged(node);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

/*	public SingleResponse<?> updateNode(String roleId, EditNodeDetailsRequest request) {

		if (Integer.parseInt(roleId) != 1) {
			throw new CustomException(CustomStatus.UNAUTHORISED, 401);
		}

		NodeRegistry existingNode = repo.findByNodeId(request.getNodeId().trim().toUpperCase())
				.orElseThrow(() -> new CustomException(CustomStatus.NODE_NOT_FOUND, 400));

		if (request.getIpAddress() != null && !request.getIpAddress().equals(existingNode.getIpAddress())) {
			boolean ipInUseByOther = repo.existsByIpAddressAndStatusAndNodeIdNot(request.getIpAddress(), ACTIVE_STATUS, request.getNodeId());
			
			if (ipInUseByOther) {
				throw new CustomException(CustomStatus.IP_ADDRESS_ALREADY_IN_USE, 409);
			}
			
			existingNode.setIpAddress(request.getIpAddress());
		}

		if (request.getNodeName() != null) {
			existingNode.setNodeName(request.getNodeName());
		}

		if (request.getPort() != null) {
			existingNode.setPort(request.getPort());
		}

		existingNode.setUpdatedAt(OffsetDateTime.now());
		
		repo.save(existingNode);

		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	} */

	// HELPER
	private static final InetAddressValidator validator = InetAddressValidator.getInstance();

	public static boolean isValidIp(String ip) {
		log.info("DEBUG: Received IP address :{}", ip);
		// Checks for valid IPv4 or IPv6 format
		return validator.isValid(ip);
	}
}
