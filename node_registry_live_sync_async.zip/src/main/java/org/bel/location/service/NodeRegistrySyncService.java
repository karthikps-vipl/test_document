package org.bel.location.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Executor;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.event.NodeRegistryChangedEvent;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Replicates node_registry snapshots to peer Node Services. Immediate replication is
 * attempted after local changes; periodic snapshots retry convergence after outages.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class NodeRegistrySyncService {
    private static final String SYNC_PATH = "/internal/node-registry/sync";

    private final NodeRegistryRepository repository;
    private final CurrentNodeResolver currentNodeResolver;
    private final RestClient restClient;
    private final ApplicationEventPublisher eventPublisher;

    @Qualifier("syncExecutor")
    private final Executor syncExecutor;

    @Value("${sync.internal-token:}")
    private String internalToken;

    /** Called after a local registry mutation. Queue the immediate broadcast in the
     * background so peer network latency does not delay the registry API response.
     * The scheduled full snapshot below retries convergence if a peer is offline. */
    public void registryChanged(NodeRegistry changed) {
        eventPublisher.publishEvent(new NodeRegistryChangedEvent(changed.getNodeId(), changed.getStatus()));
        try {
            syncExecutor.execute(this::broadcastSnapshot);
        } catch (Exception ex) {
            // The scheduled reconciliation remains a fallback if the executor is unavailable.
            log.error("Could not queue immediate node registry synchronization; scheduled retry will run: {}", safeMessage(ex));
        }
    }

    @Scheduled(fixedDelayString = "${node.registry.sync.interval-ms:30000}",
               initialDelayString = "${node.registry.sync.initial-delay-ms:10000}")
    public void reconcileRegistryAcrossPeers() {
        broadcastSnapshot();
    }

    public void broadcastSnapshot() {
        if (internalToken == null || internalToken.isBlank()) {
            log.error("sync.internal-token is not configured; refusing node_registry synchronization");
            return;
        }

        final String localNodeId;
        try {
            localNodeId = currentNodeResolver.getCurrentNodeId();
        } catch (Exception ex) {
            log.error("Cannot synchronize node_registry because the current node is not resolvable: {}", ex.getMessage());
            return;
        }

        List<NodeRegistry> snapshot = repository.findAll();
        List<NodeRegistry> peers = repository.findByNodeIdNot(localNodeId);
        for (NodeRegistry peer : peers) {
            if (peer.getIpAddress() == null || peer.getIpAddress().isBlank() || peer.getPort() == null) {
                log.warn("Skipping node_registry sync to {} because its address is incomplete", peer.getNodeId());
                continue;
            }
            try {
                String url = baseUrl(peer) + SYNC_PATH;
                restClient.post().uri(url)
                        .header("X-Node-Sync-Token", internalToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(snapshot)
                        .retrieve().toBodilessEntity();
                log.debug("Synchronized {} node_registry rows to {}", snapshot.size(), peer.getNodeId());
            } catch (Exception ex) {
                // A failed peer is retried by the next scheduled snapshot.
                log.warn("Node registry sync to {} failed; will retry: {}", peer.getNodeId(), safeMessage(ex));
            }
        }
    }

    @Transactional
    public int receiveSnapshot(List<NodeRegistry> incomingRows) {
        if (incomingRows == null || incomingRows.isEmpty()) {
            return 0;
        }

        String localNodeId = null;
        try {
            localNodeId = currentNodeResolver.getCurrentNodeId();
        } catch (Exception ex) {
            // During first bootstrap the receiving node might not yet have its own row.
            log.debug("Local node ID is not registered yet; accepting registry snapshot for bootstrap");
        }

        int changedCount = 0;
        List<NodeRegistry> toSave = new ArrayList<>();
        for (NodeRegistry incoming : incomingRows) {
            if (incoming == null || incoming.getNodeId() == null || incoming.getNodeId().isBlank()
                    || incoming.getNodeName() == null || incoming.getIpAddress() == null
                    || incoming.getPort() == null || incoming.getStatus() == null) {
                continue;
            }
            if (localNodeId != null && localNodeId.equalsIgnoreCase(incoming.getNodeId())) {
                // A peer must never overwrite this server's own registration.
                continue;
            }

            Optional<NodeRegistry> existingOpt = repository.findById(incoming.getNodeId());
            if (existingOpt.isEmpty()) {
                NodeRegistry copy = copyOf(incoming);
                toSave.add(copy);
                eventPublisher.publishEvent(new NodeRegistryChangedEvent(copy.getNodeId(), copy.getStatus()));
                changedCount++;
                continue;
            }

            NodeRegistry existing = existingOpt.get();
            // Last-update-wins prevents an older periodic snapshot from rolling back a newer row.
            OffsetDateTime incomingUpdated = incoming.getUpdatedAt();
            OffsetDateTime existingUpdated = existing.getUpdatedAt();
            if (incomingUpdated != null && existingUpdated != null && incomingUpdated.isBefore(existingUpdated)) {
                continue;
            }

            boolean changed = !same(existing.getNodeName(), incoming.getNodeName())
                    || !same(existing.getIpAddress(), incoming.getIpAddress())
                    || !java.util.Objects.equals(existing.getPort(), incoming.getPort())
                    || !same(existing.getStatus(), incoming.getStatus());
            if (!changed) {
                continue;
            }

            existing.setNodeName(incoming.getNodeName());
            existing.setIpAddress(incoming.getIpAddress());
            existing.setPort(incoming.getPort());
            existing.setStatus(incoming.getStatus());
            if (incomingUpdated != null) {
                existing.setUpdatedAt(incomingUpdated);
            } else {
                existing.setUpdatedAt(OffsetDateTime.now());
            }
            toSave.add(existing);
            eventPublisher.publishEvent(new NodeRegistryChangedEvent(existing.getNodeId(), existing.getStatus()));
            changedCount++;
        }
        if (!toSave.isEmpty()) {
            repository.saveAll(toSave);
        }
        return changedCount;
    }

    private NodeRegistry copyOf(NodeRegistry source) {
        OffsetDateTime now = OffsetDateTime.now();
        return NodeRegistry.builder()
                .nodeId(source.getNodeId())
                .nodeName(source.getNodeName())
                .ipAddress(source.getIpAddress())
                .port(source.getPort())
                .status(source.getStatus())
                .createdAt(source.getCreatedAt() == null ? now : source.getCreatedAt())
                .updatedAt(source.getUpdatedAt() == null ? now : source.getUpdatedAt())
                .build();
    }

    private String baseUrl(NodeRegistry peer) {
        String host = peer.getIpAddress().trim().replaceFirst("^/", "").replaceFirst("/\\d+$", "");
        return "http://" + host + ":" + peer.getPort();
    }

    private boolean same(String a, String b) {
        return java.util.Objects.equals(a, b);
    }

    private String safeMessage(Exception ex) {
        String message = ex.getMessage();
        if (message == null) return ex.getClass().getSimpleName();
        return message.length() > 500 ? message.substring(0, 500) : message;
    }

    public boolean validToken(String token) {
        return internalToken != null && !internalToken.isBlank() && token != null
                && MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8));
    }
}
