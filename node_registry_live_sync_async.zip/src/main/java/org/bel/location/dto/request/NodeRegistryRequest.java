package org.bel.location.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class NodeRegistryRequest {
	@NotBlank(message = "Node Id is required")
	private String nodeId;

	@NotBlank(message = "Ip address is required")
	@Pattern(
			regexp = "^((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$",
			message = "Invalid IPv4 format"
	)
	private String ipAddress;

	// Optional for backward compatibility with existing clients. When supplied,
	// this is the target node's reachable Node Service port, not the caller's port.
	private String nodeName;

	@Min(value = 1, message = "Port must be between 1 and 65535")
	@Max(value = 65535, message = "Port must be between 1 and 65535")
	private Integer port;
}
