package org.bel.location.controller;

import java.util.List;
import java.util.Map;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.service.NodeRegistrySyncService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/internal/node-registry")
@RequiredArgsConstructor
public class InternalNodeRegistrySyncController {
    private final NodeRegistrySyncService syncService;

    @PostMapping("/sync")
    public ResponseEntity<Map<String, Object>> receiveSnapshot(
            @RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
            @RequestBody List<NodeRegistry> nodes) {
        if (!syncService.validToken(token)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        int changed = syncService.receiveSnapshot(nodes);
        return ResponseEntity.ok(Map.of("status", "ACKNOWLEDGED", "received", nodes.size(), "changed", changed));
    }
}
