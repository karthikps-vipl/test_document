# Node Registry Synchronization

This implementation synchronizes `node_registry` snapshots between Node Service peers.

## Behaviour

1. A node registry change is saved to the local database by `NodeRegistryService`.
2. `registryChanged()` publishes a local registry-change event and queues the immediate peer broadcast on the `syncExecutor` background thread pool. The API does not wait for peer HTTP requests to finish.
3. The scheduled reconciliation broadcasts a full snapshot periodically, so temporarily unreachable peers can catch up after they become reachable.
4. The internal receiver validates `X-Node-Sync-Token` and applies incoming rows without rebroadcasting them.

## Configuration

In `application-dev.properties` and `application-prod.properties`:

```properties
node.registry.sync.interval-ms=30000
node.registry.sync.initial-delay-ms=10000
sync.internal-token=${SYNC_INTERNAL_TOKEN}
```

Set `SYNC_INTERNAL_TOKEN` to the same strong secret on every Node Service instance. Do not use a sample or weak token in production.

## Notes

- Immediate broadcast is asynchronous and best-effort. Failures are logged; periodic full-snapshot reconciliation retries later.
- This is not a durable per-peer delivery queue. If durable delivery guarantees are required, use a persistent per-peer outbox/retry table.
- Ensure each registered peer has the correct IP address and Node Service port.
- Compile and test in the project's normal build environment before deployment.


| No. | File path | Purpose |
|---|---|---|
| 1 | `src/main/java/org/bel/location/service/NodeRegistrySyncService.java` | Handles immediate asynchronous synchronization and periodic synchronization retries between nodes. |
| 2 | `src/main/java/org/bel/location/controller/InternalNodeRegistrySyncController.java` | Exposes the internal API endpoint that receives registry snapshots from peer nodes. |
| 3 | `src/main/java/org/bel/location/event/NodeRegistryChangedEvent.java` | Defines the event published when node registry information changes. |
| 4 | `NODE_REGISTRY_SYNC_README.md` | Documents the synchronization implementation and configuration. |



| No. | File path | Changes made |
|---|---|---|
| 1 | `src/main/java/org/bel/location/service/NodeRegistryService.java` | Triggers synchronization after creating a node or changing its status. Updates `updatedAt` when the status changes. |
| 2 | `src/main/java/org/bel/location/dto/request/NodeRegistryRequest.java` | Adds optional `nodeName` and `port` fields while retaining the existing request fields. |
| 3 | `src/main/java/org/bel/location/service/NodeHealthMonitor.java` | Listens for registry-change events and updates the health-status cache. |
| 4 | `src/main/resources/application-dev.properties` | Adds the periodic synchronization configuration. |
| 5 | `src/main/resources/application-prod.properties` | Adds the periodic synchronization configuration. |
