-- Run this migration against the Auth Service PostgreSQL database before deployment.
CREATE TABLE IF NOT EXISTS auth_sessions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    jti VARCHAR(36) NOT NULL UNIQUE,
    token_type VARCHAR(20) NOT NULL,
    revoked BOOLEAN NOT NULL DEFAULT FALSE,
    expires_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_auth_sessions_user_type_revoked
    ON auth_sessions (user_id, token_type, revoked);

CREATE UNIQUE INDEX IF NOT EXISTS idx_auth_sessions_jti
    ON auth_sessions (jti);
