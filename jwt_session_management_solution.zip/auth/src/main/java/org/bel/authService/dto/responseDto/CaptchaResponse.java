package org.bel.authService.dto.responseDto;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class CaptchaResponse {

	private UUID captchaKey;
	private String captcha;

}
