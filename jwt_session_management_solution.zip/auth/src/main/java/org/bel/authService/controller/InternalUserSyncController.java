package org.bel.authService.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.bel.authService.dto.sync.DeleteUserSyncEvent;
import org.bel.authService.dto.sync.EditUserSyncEvent;
import org.bel.authService.dto.sync.PasswordChangeSyncEvent;
import org.bel.authService.dto.sync.SignUpSyncEvent;
import org.bel.authService.dto.sync.UserCreatedSyncEvent;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.service.CurrentNodeResolver;
import org.bel.authService.service.UserSyncService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/internal/sync/users")
@RequiredArgsConstructor
public class InternalUserSyncController {
    private final UserSyncService userSyncService;
    private final CurrentNodeResolver currentNodeResolver;
    @Value("${sync.internal-token:}") private String internalToken;

    @PostMapping("/receive")
    public UserSyncAck receiveUser(@RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
                                   @RequestBody UserCreatedSyncEvent event) {
        if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return userSyncService.receiveUserCreated(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/edit")
    public UserSyncAck receiveUserEdit(
            @RequestBody EditUserSyncEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return userSyncService.receiveEditUser(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/delete")
    public UserSyncAck receiveUserDelete(
            @RequestBody DeleteUserSyncEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return userSyncService.receiveDeleteUser(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/passwordChange")
    public UserSyncAck receivePasswordChange(
            @RequestBody PasswordChangeSyncEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return userSyncService.receivePasswordChange(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/signUp")
    public UserSyncAck receiveUserSignUp(
            @RequestBody SignUpSyncEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return userSyncService.receiveUserSignUp(event, currentNodeResolver.getCurrentNodeId());
    }
}
