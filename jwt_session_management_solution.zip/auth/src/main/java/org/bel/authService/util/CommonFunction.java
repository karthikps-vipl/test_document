package org.bel.authService.util;

import java.util.Base64;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CommonFunction {
	public String getIp(HttpServletRequest suRequest) {
//		String ip = null;
//		java.util.Enumeration<String> headerNames = suRequest.getHeaderNames();
//		while (headerNames.hasMoreElements()) {
//		    String name = headerNames.nextElement();
//		    log.info("Header: {} = {}", name, suRequest.getHeader(name));
//		}
//		log.info("Direct Remote Addr: {}", suRequest.getRemoteAddr());
		
		
		String ip = suRequest.getHeader("X-Forwarded-For");
		if (ip != null && !ip.isEmpty()) {
		    // If there are multiple IPs (e.g. "client-ip, proxy-ip"), take the first one
		    ip = ip.split(",")[0].trim();
		} else {
		    // Fallback if header is missing
		    ip = suRequest.getRemoteAddr();
		}
		log.info("Resolved Client IP: {}", ip);
		return ip;
		
//		String ip = suRequest.getRemoteAddr();
//		log.info("Resolved Client IP: {}", ip);
//
//		// 1. Check X-Forwarded-For (Standard for Proxies/Load Balancers)
//		String xForwardedFor = suRequest.getHeader("X-Forwarded-For");
//		if (xForwardedFor != null && !xForwardedFor.trim().isEmpty()) {
//			// The header can contain a list of IPs; the first one is the client
//			String[] ips = xForwardedFor.split(",");
//			if (ips.length > 0) {
//				ip = ips[0].trim();
//			}
//		}
//
//		// 2. Check X-Real-IP (Commonly used by Nginx)
//		if (ip == null || ip.isEmpty()) {
//			String xRealIp = suRequest.getHeader("X-Real-IP");
//			if (xRealIp != null && !xRealIp.trim().isEmpty()) {
//				ip = xRealIp.trim();
//			}
//		}
//
//		// 3. Check Proxy-Client-IP (Older proxy standard)
//		if (ip == null || ip.isEmpty()) {
//			String proxyClientIp = suRequest.getHeader("Proxy-Client-IP");
//			if (proxyClientIp != null && !proxyClientIp.trim().isEmpty()) {
//				ip = proxyClientIp.trim();
//			}
//		}
//
//		// 4. Fallback to getRemoteAddr (Direct connection)
//		if (ip == null || ip.isEmpty()) {
//			ip = suRequest.getRemoteAddr();
//		}
//
//		// Final Validation
//		if (ip == null || ip.trim().isEmpty() || "unknown".equalsIgnoreCase(ip)) {
//			throw new CustomException("Ip Data Not Found", CustomStatus.IP_NOT_FOUND, 401);
//		}
//
//		log.info("Resolved Client IP: {}", ip);
//		return ip;
	}
}
