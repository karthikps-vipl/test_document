package org.bel.authService.dto.requestDto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LoginCaptchaRequest {
    @NotBlank(message = "ServiceId is required")
    private String serviceId;

    @NotBlank(message = "Password is required")
    private String usrPass;
    
	@NotBlank(message = "captcha field shouldn't be empty")
	private String captcha;

	@NotBlank(message = "captchaKey shouldn't be empty")
	@Size(min = 4,max = 60)
	private String captchaKey;
}