package org.bel.authService.controller;

import java.util.List;

import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.requestDto.EditUserStatsRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.EmailResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.dto.responseDto.UnallottedUsersResponse;
import org.bel.authService.service.MdmUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/users")

@AllArgsConstructor
public class MdmUserController {
	private final MdmUserService userService;
	
	@PostMapping("/addUser")
	public ResponseEntity<SingleResponse<AddUserResponse>> addUser(@RequestHeader("X-User-Id") Long userId,@Valid @RequestBody AddUserRequest request) {
		SingleResponse<AddUserResponse> response = userService.addUser(userId,request);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/listUser")
	public ResponseEntity<SingleResponse<List<ListOfUsersResponse>>> getAllUsers(){
		SingleResponse<List<ListOfUsersResponse>> response = userService.getAllUsers();
		return ResponseEntity.ok(response);
	}
	
	@PatchMapping("/editUser/{userId}")
	public ResponseEntity<SingleResponse<String>> editUser(@Valid @RequestBody EditUserRequest request,@PathVariable Long userId) {
		SingleResponse<String> response = userService.editUser(request,userId);
		return ResponseEntity.ok(response);
	} 
	
	@DeleteMapping("/deleteUser")
	public ResponseEntity<SingleResponse<String>> deleteUser(@RequestBody List<Long> userIds) {
		SingleResponse<String> response = userService.deleteUser(userIds);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/unallottedUsers")
	public ResponseEntity<SingleResponse<List<UnallottedUsersResponse>>> getUnallottedUsers() {
		SingleResponse<List<UnallottedUsersResponse>> response = userService.getUnallottedUsers();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/getEmail/{serviceId}")
	public ResponseEntity<SingleResponse<EmailResponse>> getEmail(@PathVariable String serviceId) {
		SingleResponse<EmailResponse> response = userService.getEmail(serviceId);
		return ResponseEntity.ok(response);
	}
	
	@PatchMapping("/editUserStats/{userId}")
	public ResponseEntity<SingleResponse<String>> editUserStats(@Valid @RequestBody EditUserStatsRequest request,@PathVariable Long userId) {
		SingleResponse<String> response = userService.editUserStats(request,userId);
		return ResponseEntity.ok(response);
	}
}
