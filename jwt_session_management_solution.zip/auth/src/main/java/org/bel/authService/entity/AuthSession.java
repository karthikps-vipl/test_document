package org.bel.authService.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Table(name = "auth_sessions", indexes = {
    @Index(name = "idx_auth_sessions_user_type_revoked", columnList = "user_id, token_type, revoked"),
    @Index(name = "idx_auth_sessions_jti", columnList = "jti", unique = true)
})
@Getter
@Setter
public class AuthSession {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "user_id", nullable = false)
    private Long userId;
    @Column(name = "jti", nullable = false, unique = true, length = 36)
    private String jti;
    @Column(name = "token_type", nullable = false, length = 20)
    private String tokenType;
    @Column(name = "revoked", nullable = false)
    private boolean revoked = false;
    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
