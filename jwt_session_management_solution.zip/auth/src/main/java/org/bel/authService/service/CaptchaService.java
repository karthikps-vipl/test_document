package org.bel.authService.service;

import java.util.Map;
import org.bel.authService.dto.requestDto.CaptchaDTO;
import org.bel.authService.dto.responseDto.CaptchaResponse;
import org.bel.authService.dto.responseDto.SingleResponse;

import jakarta.servlet.http.HttpServletRequest;

public interface CaptchaService {

	public SingleResponse<CaptchaResponse> getCaptcha(HttpServletRequest request);

	public CaptchaDTO getCaptchaDTO(String uuid);

	public Map<String, CaptchaDTO> getCaptchaData();

	public void removeCaptchaDTO(String uuid);

}
