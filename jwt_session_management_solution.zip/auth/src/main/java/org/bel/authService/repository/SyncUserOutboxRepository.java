package org.bel.authService.repository;

import java.util.Optional;
import java.util.UUID;

import org.bel.authService.entity.SyncUserOutbox;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface SyncUserOutboxRepository extends JpaRepository<SyncUserOutbox, Long>{
	Optional<SyncUserOutbox> findByEventId(UUID eventId);

	@Query("SELECT s FROM SyncUserOutbox s WHERE s.eventType IN ('USER_CREATED', 'EDIT_USER', 'DELETE_USER', 'PASSWORD_CHANGE', 'SIGN_UP') AND s.status = 'PENDING' ORDER BY s.createdAt ASC")
	Page<SyncUserOutbox> findPendingUserEvents(Pageable pageable);

	@Query("SELECT COUNT(s) FROM SyncUserOutbox s WHERE s.eventType IN ('USER_CREATED', 'EDIT_USER', 'DELETE_USER', 'PASSWORD_CHANGE', 'SIGN_UP') AND s.status = 'PENDING'")
	long countPendingUserEvents();

	@Transactional
	@Modifying
	@Query("UPDATE SyncUserOutbox s SET s.status = :status, s.sentAt = :sentAt, s.lastError = :error WHERE s.eventId = :eventId")
	int updateStatus(@Param("eventId") UUID eventId, @Param("status") String status,
			@Param("sentAt") java.time.LocalDateTime sentAt, @Param("error") String error);
}
