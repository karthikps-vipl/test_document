package org.bel.authService.dto.sync;

import java.time.LocalDate;
import java.util.UUID;

public record UpdatePinSyncEvent(
		UUID eventId,
        String sourceNodeId,
        Long deviceId,
        String updatedBy,
        LocalDate updatedAt,
        String newPin
        ) {
}
