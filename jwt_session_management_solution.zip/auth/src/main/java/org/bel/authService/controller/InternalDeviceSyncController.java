package org.bel.authService.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.bel.authService.dto.sync.AddNewDeviceSyncEvent;
import org.bel.authService.dto.sync.DeleteBulkDeviceEvent;
import org.bel.authService.dto.sync.DeleteDeviceSyncEvent;
import org.bel.authService.dto.sync.EditDeviceSyncEvent;
import org.bel.authService.dto.sync.UpdatePinSyncEvent;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.service.CurrentNodeResolver;
import org.bel.authService.service.DeviceSyncService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/internal/sync/device")
@RequiredArgsConstructor
public class InternalDeviceSyncController {
    private final DeviceSyncService deviceSyncService;
    private final CurrentNodeResolver currentNodeResolver;
    @Value("${sync.internal-token:}") private String internalToken;

    @PostMapping("/updatePin")
    public UserSyncAck receiveUpdatePin(@RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
                                   @RequestBody UpdatePinSyncEvent event) {
        if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return deviceSyncService.receiveUpdatedPin(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/addNewDevice")
    public UserSyncAck receivedAddNewDevice(@RequestHeader(value = "X-Node-Sync-Token", required = false) String token,
                                   @RequestBody AddNewDeviceSyncEvent event) {
        if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return deviceSyncService.receiveAddNewDevice(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/edit")
    public UserSyncAck receiveDeviceEdit(
            @RequestBody EditDeviceSyncEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return deviceSyncService.receiveEditDevice(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/deleteAll")
    public UserSyncAck receiveDeviceBulkDelete(
            @RequestBody DeleteBulkDeviceEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return deviceSyncService.receiveBulkDeleteDevice(event, currentNodeResolver.getCurrentNodeId());
    }
    
    @PostMapping("/delete")
    public UserSyncAck receiveDeviceDelete(
            @RequestBody DeleteDeviceSyncEvent event, 
            @RequestHeader("X-Node-Sync-Token") String token) {
    	if (internalToken == null || internalToken.isBlank() || token == null ||
                !MessageDigest.isEqual(internalToken.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid node sync token");
        }
        return deviceSyncService.receiveDeleteDevice(event, currentNodeResolver.getCurrentNodeId());
    }
}
