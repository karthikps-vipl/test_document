package org.bel.authService.controller;

import lombok.RequiredArgsConstructor;
import org.bel.authService.repository.AuthSessionRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@RestController
@RequestMapping("/internal/auth")
@RequiredArgsConstructor
public class InternalSessionController {
    private final AuthSessionRepository sessions;
    @Value("${security.internal-token}") private String internalToken;

    @GetMapping("/validate-session")
    public ResponseEntity<Boolean> validateSession(
            @RequestHeader(value = "X-Internal-Token", required = false) String suppliedToken,
            @RequestParam String jti, @RequestParam Long userId, @RequestParam String tokenType) {
        if (suppliedToken == null || !java.security.MessageDigest.isEqual(
                internalToken.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                suppliedToken.getBytes(java.nio.charset.StandardCharsets.UTF_8))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(false);
        }
        boolean active = sessions.existsByJtiAndUserIdAndTokenTypeAndRevokedFalseAndExpiresAtAfter(
                jti, userId, tokenType, LocalDateTime.now(ZoneOffset.UTC));
        return ResponseEntity.ok(active);
    }
}
