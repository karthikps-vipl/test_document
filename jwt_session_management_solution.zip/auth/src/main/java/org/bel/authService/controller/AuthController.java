package org.bel.authService.controller;

import java.util.List;
import java.util.Map;

import org.bel.authService.dto.requestDto.LoginCaptchaRequest;
import org.bel.authService.dto.requestDto.LoginRequest;
import org.bel.authService.dto.requestDto.PasswordChangeRequest;
import org.bel.authService.dto.requestDto.PinChangeRequest;
import org.bel.authService.dto.requestDto.PinValidationRequest;
import org.bel.authService.dto.requestDto.RefreshTokenRequest;
import org.bel.authService.dto.requestDto.SignUpRequest;
import org.bel.authService.dto.responseDto.CaptchaResponse;
import org.bel.authService.dto.responseDto.LoginCaptchaResponse;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.NodesListResponse;
import org.bel.authService.dto.responseDto.PinValidationResponse;
import org.bel.authService.dto.responseDto.RolesResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.dto.responseDto.UserTypesResponse;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.service.AuthService;
import org.bel.authService.service.RsaService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.bel.authService.service.CaptchaService;
import org.bel.authService.dto.requestDto.CaptchaDTO;

@RestController
@RequestMapping("/auth")
@AllArgsConstructor
@Slf4j
public class AuthController {
	private final AuthService authService;
	private final RsaService rsaService;
	private final CaptchaService captchaService;

	@PostMapping("/login")
	public ResponseEntity<SingleResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest request) {
		SingleResponse<LoginResponse> response = authService.login(request.getServiceId(), request.getUsrPass());
		return ResponseEntity.ok(response);
	}

	@PostMapping("/validatePin")
	public ResponseEntity<SingleResponse<PinValidationResponse>> validatePin(@RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-Token-Jti") String tokenJti,
			@Valid @RequestBody PinValidationRequest request) {
		return ResponseEntity.ok(authService.validatePin(userId, tokenJti, request));
	}

	@PatchMapping("/pinChange/{deviceId}")
	public ResponseEntity<SingleResponse<String>> updatePin(@PathVariable("deviceId") Long deviceId,
			@Valid @RequestBody PinChangeRequest request, @RequestHeader("X-User-Id") String adminId) {
		return ResponseEntity.ok(authService.updatePin(adminId, deviceId, request));
	}

	@PostMapping("/signUp")
	public ResponseEntity<SingleResponse<String>> signUp(@Valid @RequestBody SignUpRequest signUpRequest) {
		SingleResponse<String> response = authService.signUp(signUpRequest.getServiceId(), signUpRequest.getUsrPass(),
				signUpRequest.getDeviceUUID());
		return ResponseEntity.ok(response);
	}

	@PostMapping("/refresh")
	public ResponseEntity<SingleResponse<String>> refreshToken(@RequestBody RefreshTokenRequest request) {
		return ResponseEntity.ok(authService.refreshTokenRequest(request));
	}

	@GetMapping("/roles")
	public ResponseEntity<SingleResponse<List<RolesResponse>>> getListOfRoles() {
		return ResponseEntity.ok(authService.getListOfRoles());
	}

	@GetMapping("/nodes")
	public ResponseEntity<SingleResponse<List<NodesListResponse>>> getListOfNodes() {
		return ResponseEntity.ok(authService.getListOfNode());
	}

	@GetMapping("/userTypes")
	public ResponseEntity<SingleResponse<List<UserTypesResponse>>> getListOfUserTypes() {
		return ResponseEntity.ok(authService.getListOfUserTypes());
	}

	@PatchMapping("/passwordChange")
	public ResponseEntity<SingleResponse<String>> passwordChange(@RequestHeader("X-User-Id") String userId,
			@Valid @RequestBody PasswordChangeRequest request) {
		return ResponseEntity.ok(authService.passwordChange(userId, request));
	}

	@GetMapping("/encryptPassword")
	public ResponseEntity<String> getEncryptedPassword(@RequestParam String rawPassword) {
		try {
			log.info("DEBUG: Raw Password :{}", rawPassword);
			String encrypted = rsaService.encrypt(rawPassword);
			log.info("DEBUG: Encrypted password is :{}", encrypted);
			return ResponseEntity.ok(encrypted);
		} catch (Exception e) {
			return ResponseEntity.internalServerError().body("Encryption failed: " + e.getMessage());
		}
	}

	@PostMapping("/vendorlogin")
	public ResponseEntity<SingleResponse<LoginCaptchaResponse>> vendorlogin(
			@Valid @RequestBody LoginCaptchaRequest request, HttpServletRequest suRequest) {
		SingleResponse<LoginCaptchaResponse> response = authService.vendorlogin(request.getServiceId(),
				request.getUsrPass(), request.getCaptcha(), request.getCaptchaKey(), suRequest);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/get/captcha")
	public SingleResponse<CaptchaResponse> getCaptcha(HttpServletRequest request) {
		return captchaService.getCaptcha(request);
	}

	@GetMapping("/get/captchaData")
	public SingleResponse<Map<String, CaptchaDTO>> getCaptchaData() {
		return new SingleResponse<>(captchaService.getCaptchaData(), CustomStatus.SUCCESS);
	}
}
