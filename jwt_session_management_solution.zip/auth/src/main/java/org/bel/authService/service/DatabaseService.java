package org.bel.authService.service;

import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.DropDatabasePinValidateWipeRequest;
import org.bel.authService.dto.requestDto.EditDeviceStatusRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;

public interface DatabaseService {
	SingleResponse<String> dropDatabase();
	
	SingleResponse<String> dropDatabasePinValidateWipe(DropDatabasePinValidateWipeRequest request,Long deviceId, String userId);
}
