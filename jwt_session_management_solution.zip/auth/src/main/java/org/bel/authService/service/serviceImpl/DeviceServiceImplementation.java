package org.bel.authService.service.serviceImpl;

import org.bel.authService.dto.responseDto.*;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.bel.authService.constants.AppConstants;
import org.bel.authService.dto.requestDto.AddDeviceRequest;
import org.bel.authService.dto.requestDto.EditDeviceRequest;
import org.bel.authService.dto.requestDto.EditDeviceStatusRequest;
import org.bel.authService.dto.responseDto.DeviceStatsResponse.DeviceDetail;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.entity.LaaGroupTracking;
import org.bel.authService.entity.LaaUeLocationHist;
import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserType;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.repository.LaaGroupTrackingRepository;
import org.bel.authService.repository.LaaUeLocationHistRepository;
import org.bel.authService.repository.MdmDeviceTypeRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.service.DeviceService;
import org.bel.authService.service.DeviceSyncService;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j

public class DeviceServiceImplementation implements DeviceService {
	private final MdmUeRepository mdmUeRepository;
	private final MdmUserUeMappingRepository mdmUserUeMappingRepository;
	private final MdmUserRepository userRepository;
	private final MdmDeviceTypeRepository mdmDeviceTypeRepository;
	private final LaaUeLocationHistRepository laaUeLocationHistRepository;
	private final MdmUserTypeRepository mdmUserTypeRepository;
	private final LaaGroupTrackingRepository laaGroupTrackingRepository;
	private final DeviceSyncService deviceSyncService;

	private static final double REFERENCE_LATITUDE = 13.053524;
	private static final double REFERENCE_LONGITUDE = 77.561265;

	@Transactional
	public SingleResponse<DeviceStatsResponse> getDeviceStats() {
		LocalDateTime fourHoursAgo = LocalDateTime.now().minusHours(4);
		long totalDevices = mdmUeRepository.getTotalDevicesCount();
		Map<String, Object> groups = mdmUeRepository.getTacticalGroupCounts();
		Map<String, Object> counts = mdmUeRepository.getDeviceCounts(fourHoursAgo);
		int activeDevices = ((Number) counts.get("active_devices")).intValue();
		int detachedDevices = ((Number) counts.get("detached_devices")).intValue();
		int fencingViolations = ((Number) counts.get("fencing_violations")).intValue();
		int todayCount = ((Number) counts.get("today")).intValue();
		int criticalDevices = ((Number) counts.get("critical_devices")).intValue();
		long totalGroups = ((Number) groups.get("total_groups")).longValue();
		long activeGroups = ((Number) groups.get("active_groups")).longValue();
		int activePercentage = totalDevices > 0 ? Math.round((float) activeDevices / totalDevices * 100) : 0;
		int detachedPercentage = totalDevices > 0 ? Math.round((float) todayCount / detachedDevices * 100) : 0;
		int fencingPercentage = totalDevices > 0 ? Math.round((float) criticalDevices / fencingViolations * 100) : 0;
		int tacticalPercentage = totalGroups > 0 ? Math.round((float) activeGroups / totalGroups * 100) : 0;
		DeviceStatsResponse dto = DeviceStatsResponse.builder()
				.ueDevices(DeviceDetail.builder().total(totalDevices).value("Active " + activeDevices)
						.percentage(activePercentage).build())
				.detachedUe(DeviceDetail.builder().total(detachedDevices).value("Today " + todayCount)
						.percentage(detachedPercentage).build())
				.fencingViolation(DeviceDetail.builder().total(fencingViolations).value("Critical " + criticalDevices)
						.percentage(fencingPercentage).build())
				.tacticalGroups(DeviceDetail.builder().total(totalGroups).value("Active " + activeGroups)
						.percentage(tacticalPercentage).build())
				.build();
		return new SingleResponse<>(dto, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<List<DeviceListResponse>> getDeviceList() {
		List<MdmUser> mdmUsers = userRepository.findAllByOrderByIdAsc();
		List<MdmUserUeMapping> allMappings = mdmUserUeMappingRepository.findAll();
		Map<Long, MdmUserUeMapping> mappingMap = allMappings.stream()
				.collect(Collectors.toMap(mdmUserMap -> mdmUserMap.getMdmUserId().getId(), mapping -> mapping,
						(existing, replacement) -> existing));
		Set<Long> deviceIds = allMappings.stream()
		.map(m -> m.getMdmUeId().getId()).collect(Collectors.toSet());
		Map<Long, MdmUe> deviceMap = mdmUeRepository.findAllById(deviceIds).stream()
				.collect(Collectors.toMap(MdmUe::getId, device -> device));
		List<DeviceListResponse> deviceListResponses = mdmUsers.stream().map(user -> {
			MdmUserUeMapping mapping = mappingMap.get(user.getId());
			if (mapping == null)
				return null;
			MdmUe device = deviceMap.get(mapping.getMdmUeId().getId());
			if (device == null)
				return null;

			if(device.getStatus() == 2){
				return null;
			}
			DeviceListResponse response = new DeviceListResponse();
			response.setId(device.getId());
			response.setDeviceId(device.getDeviceId());
			response.setDeviceName(device.getDeviceName());
			if (device.getMdmDeviceType() != null) {
				response.setDeviceTypeId(device.getMdmDeviceType().getId());
				response.setDeviceType(device.getMdmDeviceType().getDeviceType());
			}
			response.setStatus(device.getStatus());
			response.setContactNo(device.getContactNo());
			DeviceListUserResponse userResponse = new DeviceListUserResponse();
			userResponse.setUserId(user.getId());
			userResponse.setServiceId(user.getServiceId());
			userResponse.setUsrName(user.getUsrName());
			response.setUsers(userResponse);
			response.setSecurePin(device.getSecurePin());
			return response;
		}).filter(Objects::nonNull).toList();
		return new SingleResponse<>(deviceListResponses, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<List<DeviceListTypeResponse>> getDeviceListType(String type) {
		List<DeviceListTypeResponse> deviceListTypeResponses = null;
	    List<MdmUe> devices = mdmUeRepository.findAllByOrderByIdAsc();
	    List<MdmUser> users = userRepository.findAll();
	    List<LaaGroupTracking> groupTrackings = laaGroupTrackingRepository.findAll();
	    List<LaaUeLocationHist> laaUeLocationHist = laaUeLocationHistRepository.findAll();

	    Map<Long, List<LaaUeLocationHist>> historyByUserMap = laaUeLocationHist.stream()
	            .collect(Collectors.groupingBy(h -> h.getMdmUser().getId()));
	    Map<Long, MdmUe> deviceMap = devices.stream()
	            .collect(Collectors.toMap(MdmUe::getId, ue -> ue, (existing, replacement) -> existing));
	    Map<Long, MdmUser> userMap = users.stream()
	            .collect(Collectors.toMap(MdmUser::getId, u -> u, (existing, replacement) -> existing));
	    Set<Long> userIds = laaUeLocationHist.stream().map(m -> m.getMdmUser().getId()).collect(Collectors.toSet());
	    Map<Long, MdmUser> userToDeviceMap = userRepository.findAllById(userIds).stream()
                .collect(Collectors.toMap(MdmUser::getId, u -> u));
	    Map<Long, LaaUeLocationHist> mdmUeIdMap = laaUeLocationHist.stream()
                .collect(Collectors.toMap(m -> m.getMdmUe().getId(), m -> m, (existing, replacement) -> existing));
	    switch (type) {
	    case "ue_devices":
	        deviceListTypeResponses = getUeDevicesResponse(devices, userToDeviceMap, mdmUeIdMap);
	        break;
	    case "tactical_groups":
	        deviceListTypeResponses = getTacticalGroupsResponse(groupTrackings, historyByUserMap, deviceMap, userMap);
	        break;
	    case "detached_ue":
	        deviceListTypeResponses = getDetachedUeResponse(deviceMap, userMap, laaUeLocationHist);
	        break;
	    case "fencing_violation":
	        deviceListTypeResponses = getFencingViolationResponse(deviceMap, userMap, historyByUserMap);
	        break;
	    default:
	    	log.warn("Invalid type");
	}
	    return new SingleResponse<>(deviceListTypeResponses,CustomStatus.SUCCESS);
	}

	private List<DeviceListTypeResponse> getUeDevicesResponse(List<MdmUe> devices,
			Map<Long, MdmUser> userToDeviceMap, Map<Long, LaaUeLocationHist> mdmUeIdMap) {
          	 return devices.stream().map(device -> {
             LaaUeLocationHist mapping = mdmUeIdMap.get(device.getId());
             if (mapping == null || mapping.getMdmUser() == null) return null;
             MdmUser user = userToDeviceMap.get(mapping.getMdmUser().getId());
             if (user == null) return null;
             DeviceListTypeResponse response = new DeviceListTypeResponse();
             response.setDeviceId(device.getDeviceId());
             response.setDeviceName(device.getDeviceName());
             response.setUsername(user.getUsrName());
             // Distance
             Double dist = mdmUeRepository.getDistance(device.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
             response.setDistance(formatDistance(dist));
             processStatusAndTiming(response, mapping);
             return response;
         }).filter(Objects::nonNull).toList();
	}
	
	private List<DeviceListTypeResponse> getTacticalGroupsResponse(List<LaaGroupTracking> groupTrackings,
			Map<Long, List<LaaUeLocationHist>> historyByUserMap, Map<Long, MdmUe> deviceMap,
			Map<Long, MdmUser> userMap) {
			return groupTrackings.stream()
                .sorted(Comparator.comparing(LaaGroupTracking::getId))
                .filter(gt -> gt.getGroupStats() != 2)
                .map(gt -> {
                    Long userId = gt.getMdmUser().getId();
                    List<LaaUeLocationHist> userHistories = historyByUserMap.getOrDefault(userId, Collections.emptyList());
                    if (userHistories.isEmpty()) return null;
                    LaaUeLocationHist latest = userHistories.stream()
                            .max(Comparator.comparing(h -> (h.getCreatedTime() instanceof LocalDateTime ? (LocalDateTime)h.getCreatedTime() : LocalDateTime.MIN)))
                            .orElse(null);
                    if (latest == null || latest.getMdmUe() == null) return null;
                    MdmUe ue = deviceMap.get(latest.getMdmUe().getId());
                    MdmUser user = userMap.get(userId);
                    if (ue == null || user == null) return null;
                    DeviceListTypeResponse resp = new DeviceListTypeResponse();
                    resp.setDeviceId(ue.getDeviceId());
                    resp.setDeviceName(ue.getDeviceName());
                    resp.setUsername(user.getUsrName());
                    Double dist = mdmUeRepository.getDistance(ue.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
                    resp.setDistance(formatDistance(dist));
                    resp.setStatus(gt.getGroupStats() == 1 ? "Active" : "Inactive");

                    Object rt = latest.getCreatedTime();
                    LocalDateTime hTime = (rt instanceof LocalDateTime) ? (LocalDateTime) rt : null;
                    resp.setLastUpdated(formatTimeAgo(hTime));
                    return resp;
                }).filter(Objects::nonNull).toList();
	}
	
	private List<DeviceListTypeResponse> getDetachedUeResponse(Map<Long, MdmUe> deviceMap,
			Map<Long, MdmUser> userMap, List<LaaUeLocationHist> laaUeLocationHist) {
		 return deviceMap.values().stream().map(u -> { 
             MdmUser user = userMap.get(u.getId());
             String username = (user != null) ? user.getUsrName() : AppConstants.UNKNOWN_USER;
             List<LaaUeLocationHist> deviceHistories = laaUeLocationHist.stream()
                     .filter(h -> h.getMdmUe().getId().equals(u.getId()) && h.getMdmUser().getId().equals(u.getId()))
                     .toList();
             if (deviceHistories.isEmpty()) return null;
             // Check for valid node
//             boolean hasValidNode = deviceHistories.stream().anyMatch(h -> h.getMdmNode().getId() != 1);
             boolean hasValidNode = deviceHistories.stream().anyMatch(h -> !h.getNode().getNodeId().equals("NODE-001"));
             if (!hasValidNode) return null;
             LaaUeLocationHist latest = deviceHistories.stream()
                     .max(Comparator.comparing(h -> (h.getCreatedTime() instanceof LocalDateTime ? (LocalDateTime)h.getCreatedTime() : LocalDateTime.MIN)))
                     .orElse(null);
             if (latest == null) return null;
             DeviceListTypeResponse resp = new DeviceListTypeResponse();
             resp.setDeviceId(u.getDeviceId());
             resp.setDeviceName(u.getDeviceName());
             resp.setUsername(username);
             Double dist = mdmUeRepository.getDistance(u.getDeviceId(), REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
             resp.setDistance(formatDistance(dist));
             Object rt = latest.getCreatedTime();
             LocalDateTime hTime = (rt instanceof LocalDateTime) ? (LocalDateTime) rt : null;
             resp.setLastUpdated(formatTimeAgo(hTime));
             return resp;
         }).filter(Objects::nonNull).toList();
	}
	
	private List<DeviceListTypeResponse> getFencingViolationResponse(Map<Long, MdmUe> deviceMap,
			Map<Long, MdmUser> userMap, Map<Long, List<LaaUeLocationHist>> historyByUserMap) {
		return deviceMap.values().stream().map(u -> {
            MdmUser user = userMap.get(u.getId());
            List<LaaUeLocationHist> userHistories = historyByUserMap.getOrDefault(u.getId(), Collections.emptyList());
            LaaUeLocationHist latestViolation = findLatestViolation(userHistories);
            if (latestViolation == null) return null;
            DeviceListTypeResponse resp = new DeviceListTypeResponse();
            resp.setDeviceId(u.getDeviceId());
            resp.setDeviceName(u.getDeviceName());
            resp.setUsername(user != null ? user.getUsrName() : AppConstants.UNKNOWN_USER);
            processDistanceAndStatus(resp, u.getDeviceId());
            processViolationTime(resp, latestViolation);
            return resp;
        })
        .filter(Objects::nonNull)
        .toList();
	}

	private String formatTimeAgo(LocalDateTime historyTime) {
	    if (historyTime == null) return "N/A";
	    LocalDateTime now = LocalDateTime.now();
	    Duration d = Duration.between(historyTime, now);

	    if (d.isNegative() || d.getSeconds() < 60) return "Just now";
	    if (d.toMinutes() < 60) return d.toMinutes() + " mins ago";
	    if (d.toHours() < 24) return d.toHours() + " hours ago";
	    return d.toDays() + " days ago";
	}
	
	private String formatDistance(Double dist) {
	    if (dist == null) return AppConstants.DEFAULT_DISTANCE;
	    return String.format("%.2f km", dist / 1000.0);
	}
	
	private void processStatusAndTiming(DeviceListTypeResponse response, LaaUeLocationHist mapping) {
	    Object rawTime = mapping.getCreatedTime();
	    LocalDateTime historyTime = (rawTime instanceof LocalDateTime) ? (LocalDateTime) rawTime : null;
	    response.setLastUpdated(formatTimeAgo(historyTime));
	    String status = "Inactive";
	    if (historyTime != null && historyTime.isAfter(LocalDateTime.now().minusHours(4))) {
	        status = "Active";
	    }
	    response.setStatus(status);
	}
	
	private void processDistanceAndStatus(DeviceListTypeResponse resp, String deviceId) {
	    Double dist = mdmUeRepository.getDistance(deviceId, REFERENCE_LONGITUDE, REFERENCE_LATITUDE);
	    if (dist == null) {
	        resp.setDistance(AppConstants.DEFAULT_DISTANCE);
	        return;
	    }
	    resp.setDistance(formatDistance(dist));
	    double km = dist / 1000.0;
	    resp.setStatus(km > 1.0 ? "Critical" : "Violated");
	}
	
	private void processViolationTime(DeviceListTypeResponse resp, LaaUeLocationHist violation) {
	    LocalDateTime hTime = extractLocalDateTime(violation.getCreatedTime());
	    resp.setLastUpdated(formatTimeAgo(hTime));
	}
	
	private LocalDateTime extractLocalDateTime(Object timeObj) {
	    return (timeObj instanceof LocalDateTime) ? (LocalDateTime) timeObj : LocalDateTime.MIN;
	}
	
	private LaaUeLocationHist findLatestViolation(List<LaaUeLocationHist> histories) {
	    return histories.stream()
	            .filter(this::isOutsideFence)
	            .max(Comparator.comparing(h -> extractLocalDateTime(h.getCreatedTime())))
	            .orElse(null);
	}
	
	private boolean isOutsideFence(LaaUeLocationHist h) {
	    return h.getLatitude().compareTo(REFERENCE_LATITUDE) != 0 
	        || h.getLongitude().compareTo(REFERENCE_LONGITUDE) != 0;
	}

	@Transactional
	public SingleResponse<List<DeviceTypeResponse>> getDeviceTypes() {
		List<MdmDeviceType> mdmDeviceTypes = mdmDeviceTypeRepository.findAllByOrderByIdAsc();
		List<DeviceTypeResponse> responseList = new ArrayList<>();
		for (MdmDeviceType mdmDeviceType : mdmDeviceTypes) {
			DeviceTypeResponse dto = new DeviceTypeResponse();
			dto.setId(mdmDeviceType.getId());
			dto.setName(mdmDeviceType.getDeviceType());
			responseList.add(dto);
		}
		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<AddDeviceResponse> addDevice(AddDeviceRequest request) {
		Optional<MdmUe> existingDevice = mdmUeRepository.findMdmUeByDeviceId(request.getDeviceId());
		if (existingDevice.isPresent()) {
			throw new CustomException("Device Id '" + request.getDeviceId() + "' already exists",
					CustomStatus.DEVICE_ALREADY_EXISTS, 409);
		}
		boolean deviceTypeExists = mdmDeviceTypeRepository.existsById(request.getMdmDeviceTypeId());
		if (!deviceTypeExists) {
			throw new CustomException("invalid mdmDeviceTypeId", CustomStatus.BAD_REQUEST, 409);
		}
		boolean userExists = userRepository.existsById(request.getMdmUserId());
		if (!userExists) {
			throw new CustomException("invalid mdmUserId", CustomStatus.BAD_REQUEST, 409);
		}
		MdmUe newDevice = new MdmUe();
		MdmUserUeMapping mdmUserUeMapping = new MdmUserUeMapping();
		newDevice.setId(System.currentTimeMillis());
		newDevice.setDeviceId(request.getDeviceId());
		newDevice.setDeviceName(request.getDeviceName());
		newDevice.setManufactureName(request.getManufactureName());
		newDevice.setStatus(request.getStatus());
		newDevice.setContactNo(request.getContactNo());
		if (request.getMdmDeviceTypeId() != null) {
			MdmDeviceType deviceType = mdmDeviceTypeRepository.findById(request.getMdmDeviceTypeId())
					.orElseThrow(() -> new CustomException("MdmDeviceType not found", CustomStatus.DEVICE_TYPE_NOT_FOUND, 409));
			newDevice.setMdmDeviceType(deviceType);
		}
		if (request.getMdmUserId() != null) {
			MdmUser user = userRepository.findById(request.getMdmUserId())
					.orElseThrow(() -> new CustomException("MdmUser not found", CustomStatus.USER_NOT_FOUND, 409));
			mdmUserUeMapping.setMdmUserId(user);
		}
		newDevice.setSecurePin(request.getSecurePin());
		newDevice.setCreatedAt(LocalDate.now());
		newDevice.setFailedLoginCount(0);
		mdmUeRepository.save(newDevice);
		MdmUe device = mdmUeRepository.findById(newDevice.getId())
				.orElseThrow(() -> new CustomException("MdmUe not found", CustomStatus.DEVICE_NOT_FOUND, 409));
		mdmUserUeMapping.setMdmUeId(device);
		mdmUserUeMapping.setActive(request.getStatus() == 1 ? true : false);
		mdmUserUeMappingRepository.save(mdmUserUeMapping);
		deviceSyncService.addNewDeviceSync(newDevice, request.getMdmUserId());
		
		AddDeviceResponse response = new AddDeviceResponse();
		response.setId(newDevice.getId());
		response.setCreatedAt(newDevice.getCreatedAt());
		response.setFailedLoginCount(newDevice.getFailedLoginCount());
		response.setDeviceId(newDevice.getDeviceId());
		response.setDeviceName(newDevice.getDeviceName());
		response.setManufactureName(newDevice.getManufactureName());
		response.setStatus(newDevice.getStatus());
		response.setContactNo(newDevice.getContactNo());
		response.setMdmDeviceTypeId(newDevice.getMdmDeviceType().getId());
		response.setSecurePin(newDevice.getSecurePin());
		response.setUpdatedAt(newDevice.getUpdatedAt());
		response.setCreatedBy(newDevice.getCreatedBy());
		response.setUpdatedBy(newDevice.getUpdatedBy());
		response.setDeviceType(newDevice.getDeviceType());
		response.setImeiNumber(newDevice.getImeiNumber());
		response.setSimNumber(newDevice.getSimNumber());
		response.setMdmOsTypeId(null);
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	@Override
	@Transactional
	public SingleResponse<String> editDevice(@Valid EditDeviceRequest request, Long deviceId) {
		MdmUe mdmUe = mdmUeRepository.findById(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 409));
		Optional<MdmUe> existingDevice = mdmUeRepository.findMdmUeByDeviceId(request.getDeviceId());
		if (existingDevice.isPresent()) {
			throw new CustomException("Device Id '" + request.getDeviceId() + "' already exists",
					CustomStatus.DEVICE_ALREADY_EXISTS, 409);
		}
		if (mdmUe.getStatus() == 1) {
			mdmUe.setFailedLoginCount(0);
		}
		if (request.getDeviceId() != null) {
			mdmUe.setDeviceId(request.getDeviceId());
		}
		if (request.getDeviceName() != null) {
			mdmUe.setDeviceName(request.getDeviceName());
		}
		if (request.getContactNo() != null) {
			mdmUe.setContactNo(request.getContactNo());
		}
		if (request.getMdmDeviceTypeId() != null) {
			MdmDeviceType mdmDeviceType = mdmDeviceTypeRepository.findById(request.getMdmDeviceTypeId())
					.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_TYPE_NOT_FOUND, 409));
			mdmUe.setMdmDeviceType(mdmDeviceType);

		}
		if (request.getSecurePin() != null) {
			mdmUe.setSecurePin(request.getSecurePin());
		}
		mdmUeRepository.save(mdmUe);
		deviceSyncService.editDeviceSync(mdmUe, null);

		if (request.getMdmUserId() != null) {
			MdmUserUeMapping mdmUserUeMapping = mdmUserUeMappingRepository
					.findMdmUserUeMappingByMdmUserId(request.getMdmUserId())
					.orElseThrow(() -> new CustomException(CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 409));
			if (mdmUserUeMapping != null) {
				MdmUser mdmUser = userRepository.findById(request.getMdmUserId())
						.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
				mdmUserUeMapping.setMdmUserId(mdmUser);
				mdmUserUeMapping.setMdmUeId(mdmUe);
				mdmUserUeMappingRepository.save(mdmUserUeMapping);
				deviceSyncService.editDeviceSync(mdmUe, mdmUser);
			} else {
				MdmUserUeMapping newMdmUserUeMapping = new MdmUserUeMapping();
				MdmUser mdmUser = userRepository.findById(request.getMdmUserId())
						.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
				newMdmUserUeMapping.setMdmUeId(mdmUe);
				newMdmUserUeMapping.setMdmUserId(mdmUser);
				mdmUserUeMappingRepository.save(newMdmUserUeMapping);
				deviceSyncService.editDeviceSync(mdmUe, mdmUser);
			}
		}
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage() {
		List<MdmUe> allUes = mdmUeRepository.findAll();
		List<MdmUserType> allUserTypes = mdmUserTypeRepository.findAll();
		List<LaaUeLocationHist> allHistories = laaUeLocationHistRepository.findAll();
		LocalDateTime fourHoursAgo = LocalDateTime.now().minusHours(4);
		Map<Integer, List<LaaUeLocationHist>> typeToHistoriesMap = groupHistoriesByType(allHistories);
		long totalDevicesCount = allUes.size();
		long activeDevicesCount = calculateActiveDevices(allUes, allHistories, fourHoursAgo);
		List<Map<String, Object>> rankedList = getRankedUserTypeList(allUserTypes, typeToHistoriesMap, fourHoursAgo);
		Map<String, DeviceMappingPercentageResponse.CountDetail> dynamicFieldsMap = 
	            buildDynamicFields(rankedList, totalDevicesCount);
		DeviceMappingPercentageResponse responseDto = DeviceMappingPercentageResponse.builder()
	            .total((int) totalDevicesCount)
	            .active((int) activeDevicesCount)
	            .dynamicFields(dynamicFieldsMap)
	            .build();
		return new SingleResponse<>(responseDto, CustomStatus.SUCCESS);
	}
	
	private Map<Integer, List<LaaUeLocationHist>> groupHistoriesByType(List<LaaUeLocationHist> histories) {
	    return histories.stream()
	            .filter(h -> h.getMdmUser() != null && h.getMdmUser().getMdmUserTypeId() != null)
	            .collect(Collectors.groupingBy(h -> h.getMdmUser().getMdmUserTypeId().getId()));
	}
	
	private long calculateActiveDevices(List<MdmUe> ues, List<LaaUeLocationHist> histories, LocalDateTime threshold) {
	    return ues.stream().filter(ue -> {
	        if (ue.getStatus() != 1) return false;
	        return histories.stream().anyMatch(h -> 
	            h.getMdmUe().getId().equals(ue.getId()) && 
	            h.getMdmUser().getUserStats() == 1 && 
	            h.getCreatedTime().isAfter(threshold)
	        );
	    }).distinct().count();
	}
	
	private List<Map<String, Object>> getRankedUserTypeList(List<MdmUserType> types, 
	        Map<Integer, List<LaaUeLocationHist>> typeMap, LocalDateTime threshold) {
	    List<Map<String, Object>> list = new ArrayList<>();
	    for (MdmUserType type : types) {
	        List<LaaUeLocationHist> histories = typeMap.getOrDefault(type.getId(), Collections.emptyList());
	        long recentCount = histories.stream()
	                .filter(h -> h.getCreatedTime().isAfter(threshold))
	                .map(h -> h.getMdmUe().getId())
	                .distinct()
	                .count();
	        if (recentCount > 0) {
	            Map<String, Object> row = new HashMap<>();
	            row.put(AppConstants.KEY_ID, type.getId());
	            row.put(AppConstants.KEY_NAME, type.getUsrType());
	            row.put(AppConstants.KEY_COUNT, recentCount);
	            list.add(row);
	        }
	    }
	    list.sort((a, b) -> Long.compare((long) b.get(AppConstants.KEY_COUNT), (long) a.get(AppConstants.KEY_COUNT)));
	    return list;
	}
	
	private Map<String, DeviceMappingPercentageResponse.CountDetail> buildDynamicFields(
	        List<Map<String, Object>> rankedList, long totalCount) {
	    Map<String, DeviceMappingPercentageResponse.CountDetail> dynamicFields = new LinkedHashMap<>();
	    long otherCount = 0;
	    for (int i = 0; i < rankedList.size(); i++) {
	        Map<String, Object> row = rankedList.get(i);
	        long count = (long) row.get(AppConstants.KEY_COUNT);
	        int typeId = (int) row.get(AppConstants.KEY_ID);
	        String typeName = (String) row.get(AppConstants.KEY_NAME);
	        if (i < 4) {
	            float percentage = calculatePercentage(count, totalCount);
	            dynamicFields.put(String.valueOf(typeId), DeviceMappingPercentageResponse.CountDetail.builder()
	                    .name(typeName).count((int) count).percentage(percentage).build());
	        } else {
	            otherCount += count;
	        }
	    }
	    handleOtherCategory(dynamicFields, otherCount, totalCount, rankedList.isEmpty());
	    return dynamicFields;
	}
	
	private float calculatePercentage(long count, long total) {
	    return (total == 0) ? 0f : (float) ((count * 100.0) / total);
	}
	
	private void handleOtherCategory(Map<String, DeviceMappingPercentageResponse.CountDetail> map, 
            long otherCount, long totalCount, boolean listIsEmpty) {
				if (otherCount > 0) {
						map.put(AppConstants.OTHER_KEY, DeviceMappingPercentageResponse.CountDetail.builder()
								.name(AppConstants.OTHER_NAME).count((int) otherCount).percentage(calculatePercentage(otherCount, totalCount)).build());
				} else if (totalCount > 0 && listIsEmpty) {
					map.put(AppConstants.OTHER_KEY, DeviceMappingPercentageResponse.CountDetail.builder()
							.name(AppConstants.OTHER_NAME).count(0).percentage(0f).build());
					}
			}


	@Transactional
	public SingleResponse<String> deleteDevices(List<Long> deviceIds) {
	    List<MdmUe> affectedDevices = new ArrayList<>();
		
		for (Long id : deviceIds) {
			MdmUe device = mdmUeRepository.findById(id)
					.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 409));
			MdmUserUeMapping mdmUserUeMapping = mdmUserUeMappingRepository.findMdmUserUeMappingByMdmUeId(id)
					.orElseThrow(() -> new CustomException(CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 409));
			if (mdmUserUeMapping != null) {
				device.setStatus(2);
				mdmUeRepository.save(device);
				affectedDevices.add(device);
			} else {
				mdmUeRepository.deleteById(id);
				mdmUeRepository.save(device);
				affectedDevices.add(device);
			}
//			mdmUeRepository.save(device); 
		}
		if (!affectedDevices.isEmpty()) {
	        deviceSyncService.deleteDevicesBulkSync(affectedDevices);
	    }
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<String> deleteDevice(Long deviceId) {
		MdmUe device = mdmUeRepository.findById(deviceId)
			.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 409));
		// mdmUeRepository.deleteById(deviceId);
		if(device.getStatus() == 2){
			throw new CustomException(CustomStatus.DEVICE_ALREADY_DELETED, 409);
		}
		device.setStatus(2);
		mdmUeRepository.save(device);
		deviceSyncService.deleteDeviceSync(deviceId);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
	
	@Override
	@Transactional
	public SingleResponse<String> editDeviceStatus(@Valid EditDeviceStatusRequest request,Long deviceId) {
		MdmUe mdmUe = mdmUeRepository.findById(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 404));
		if (request.getStatus() != null) {
			mdmUe.setStatus(request.getStatus());
		}
		mdmUeRepository.save(mdmUe);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
}