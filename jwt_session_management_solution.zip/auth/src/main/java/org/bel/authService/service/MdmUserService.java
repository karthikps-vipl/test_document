package org.bel.authService.service;

import java.util.List;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.requestDto.EditUserStatsRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;
import org.bel.authService.dto.responseDto.*;

public interface MdmUserService {
	SingleResponse<AddUserResponse> addUser(Long userId, @Valid AddUserRequest request);
	
	SingleResponse<List<ListOfUsersResponse>> getAllUsers();
	
	SingleResponse<String> editUser(@Valid EditUserRequest request,Long userId);

	SingleResponse<String> deleteUser(List<Long> userIds);

	SingleResponse<List<UnallottedUsersResponse>> getUnallottedUsers();
	
	SingleResponse<EmailResponse> getEmail(String serviceId);
	
	SingleResponse<String> editUserStats(@Valid EditUserStatsRequest request,Long userId);
}
