package org.bel.authService.dto.sync;

import java.util.UUID;

public record EditUserSyncEvent (
		UUID eventId,
        String sourceNodeId,
        Long sourceUserId,
        String serviceId,
        Integer mdmRoleId,
        Integer mdmUserTypeId,
        String usrName	
) {}