package org.bel.authService.service.serviceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.bel.authService.dto.requestDto.DropDatabasePinValidateWipeRequest;
import org.bel.authService.dto.requestDto.EditDeviceStatusRequest;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.dto.responseDto.UnallottedUsersResponse;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.repository.MdmLevelRepository;
import org.bel.authService.repository.MdmRankRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.repository.NodeRegistryRepository;
import org.bel.authService.service.DatabaseService;
import org.bel.authService.service.MdmUserService;
import org.bel.authService.service.UserSyncService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class DatabaseServiceImplementation implements DatabaseService{
	private final MdmUserRepository userRepository;
	
	private final MdmUeRepository mdmUeRepository;
	
	@Qualifier("adminJdbcTemplate")
    private final JdbcTemplate adminJdbcTemplate;
	
	@Override
	public SingleResponse<String> dropDatabase() {
//		String targetDb = "tcs_backup";
//		adminJdbcTemplate.queryForList(
//			    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = ? AND pid <> pg_backend_pid()",targetDb); 
//	    String dropDbSql = "DROP DATABASE IF EXISTS " + targetDb; 
//	    adminJdbcTemplate.execute(dropDbSql);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
	
	@Override
	public SingleResponse<String> dropDatabasePinValidateWipe(DropDatabasePinValidateWipeRequest request, Long deviceId, String userId) {
		MdmUser user = userRepository.findById(Long.parseLong(userId))
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
		if (request.getSecurePin() == null || !request.getSecurePin().matches("^\\d{6}$")) {
			throw new CustomException(CustomStatus.INVALID_PIN, 409);
		}
		MdmUe device = mdmUeRepository.findById(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 409));
		if(!device.getSecurePin().equals((request.getSecurePin()))) {
			throw new CustomException(CustomStatus.INCORRECT_PIN, 409);
		}
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
}
