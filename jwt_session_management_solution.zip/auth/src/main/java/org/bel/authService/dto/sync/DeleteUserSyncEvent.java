package org.bel.authService.dto.sync;

import java.util.UUID;

public record DeleteUserSyncEvent(
		UUID eventId,
		Long sourceUserId,
	    String sourceNodeId,
	    String serviceId ){}
