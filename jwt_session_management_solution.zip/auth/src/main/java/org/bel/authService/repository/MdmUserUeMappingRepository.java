package org.bel.authService.repository;

import org.bel.authService.entity.MdmUserUeMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MdmUserUeMappingRepository extends JpaRepository<MdmUserUeMapping, Integer> {
	
	@Query(value = "SELECT * FROM tcs_mdm.mdm_user_ue_mapping WHERE mdm_user__id = :userId", nativeQuery = true)
	Optional<MdmUserUeMapping> findMdmUserUeMappingByMdmUserId(@Param("userId") Long userId);
	
	@Query(value = "SELECT * FROM tcs_mdm.mdm_user_ue_mapping WHERE mdm_ue__id = :deviceId", nativeQuery = true)
	Optional<MdmUserUeMapping> findMdmUserUeMappingByMdmUeId(@Param("deviceId") Long deviceId);

	Optional<MdmUserUeMapping> findByMdmUeId(Integer id);
}