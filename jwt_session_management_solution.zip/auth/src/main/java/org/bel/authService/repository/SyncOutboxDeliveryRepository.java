package org.bel.authService.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bel.authService.entity.SyncOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface SyncOutboxDeliveryRepository extends JpaRepository<SyncOutboxDelivery, Long> {
    Optional<SyncOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);
    List<SyncOutboxDelivery> findByEventId(UUID eventId);

    @Query("SELECT d FROM SyncOutboxDelivery d WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncUserOutbox s WHERE s.eventType IN ('USER_CREATED', 'EDIT_USER', 'DELETE_USER', 'PASSWORD_CHANGE', 'SIGN_UP')) AND " +
           "(d.status = 'PENDING' OR (d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now))) " +
           "ORDER BY d.createdAt")
    List<SyncOutboxDelivery> findDispatchableUserDeliveries(@Param("now") LocalDateTime now);

    @Query("SELECT DISTINCT d.targetNodeId FROM SyncOutboxDelivery d WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncUserOutbox s WHERE s.eventType IN ('USER_CREATED', 'EDIT_USER', 'DELETE_USER', 'PASSWORD_CHANGE', 'SIGN_UP')) AND d.status = 'WAITING_FOR_NODE'")
    List<String> findWaitingUserTargetNodeIds();

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'SENDING', d.sentAt = :now, d.nextRetryAt = NULL " +
           "WHERE d.id = :id AND (d.status = 'PENDING' OR (d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now)))")
    int claim(@Param("id") Long id, @Param("now") LocalDateTime now);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL, d.lastError = NULL " +
           "WHERE d.targetNodeId = :nodeId AND d.status = 'WAITING_FOR_NODE' AND d.eventId IN " +
           "(SELECT s.eventId FROM SyncUserOutbox s WHERE s.eventType IN ('USER_CREATED', 'EDIT_USER', 'DELETE_USER', 'PASSWORD_CHANGE', 'SIGN_UP'))")
    int requeueWaitingForTargetNode(@Param("nodeId") String nodeId);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'WAITING_FOR_NODE', d.nextRetryAt = NULL, d.lastError = :error WHERE d.id = :id")
    int markWaiting(@Param("id") Long id, @Param("error") String error);

    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncUserOutbox s WHERE s.eventType IN ('USER_CREATED', 'EDIT_USER', 'DELETE_USER', 'PASSWORD_CHANGE', 'SIGN_UP')) AND d.status = 'SENDING' AND d.sentAt < :cutoff")
    int resetStaleSending(@Param("cutoff") LocalDateTime cutoff);
    
    
    //---------------------
    // FOR DEVICE INFO SYNC
    //---------------------
    @Query("SELECT d FROM SyncOutboxDelivery d WHERE d.eventId IN " +
            "(SELECT s.eventId FROM SyncDeviceOutBox s WHERE s.eventType IN ('PIN_CHANGE', 'ADD_NEW_DEVICE', 'EDIT_DEVICE', 'BULK_DELETE_DEVICE', 'DELETE_DEVICE')) AND " +
            "(d.status = 'PENDING' OR (d.status = 'FAILED' AND (d.nextRetryAt IS NULL OR d.nextRetryAt <= :now))) " +
            "ORDER BY d.createdAt")
     List<SyncOutboxDelivery> findDispatchableDeviceDeliveries(@Param("now") LocalDateTime now);
    
    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL, d.lastError = NULL " +
           "WHERE d.targetNodeId = :nodeId AND d.status = 'WAITING_FOR_NODE' AND d.eventId IN " +
           "(SELECT s.eventId FROM SyncDeviceOutBox s WHERE s.eventType IN ('PIN_CHANGE', 'ADD_NEW_DEVICE', 'EDIT_DEVICE', 'BULK_DELETE_DEVICE', 'DELETE_DEVICE'))")
    int requeueWaitingForTargetNodeDevice(@Param("nodeId") String nodeId);
    
    @Query("SELECT DISTINCT d.targetNodeId FROM SyncOutboxDelivery d WHERE d.eventId IN " +
            "(SELECT s.eventId FROM SyncDeviceOutBox s WHERE s.eventType IN ('PIN_CHANGE', 'ADD_NEW_DEVICE', 'EDIT_DEVICE', 'BULK_DELETE_DEVICE', 'DELETE_DEVICE')) AND d.status = 'WAITING_FOR_NODE'")
     List<String> findWaitingDeviceTargetNodeIds();
    
    
    @Transactional
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE SyncOutboxDelivery d SET d.status = 'PENDING', d.nextRetryAt = NULL WHERE d.eventId IN " +
           "(SELECT s.eventId FROM SyncDeviceOutBox s WHERE s.eventType IN ('PIN_CHANGE', 'ADD_NEW_DEVICE', 'EDIT_DEVICE', 'BULK_DELETE_DEVICE', 'DELETE_DEVICE')) AND d.status = 'SENDING' AND d.sentAt < :cutoff")
    int resetStaleDeviceSending(@Param("cutoff") LocalDateTime cutoff);
}
