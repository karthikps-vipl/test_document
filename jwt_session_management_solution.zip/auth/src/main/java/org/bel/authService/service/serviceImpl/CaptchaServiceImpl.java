package org.bel.authService.service.serviceImpl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.imageio.ImageIO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.google.code.kaptcha.impl.DefaultKaptcha;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.bel.authService.service.CaptchaService;
import org.bel.authService.util.CommonFunction;
import org.bel.authService.dto.requestDto.CaptchaDTO;
import org.bel.authService.dto.responseDto.CaptchaResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;


@Service
@AllArgsConstructor
public class CaptchaServiceImpl implements CaptchaService {

	private final DefaultKaptcha captchaProducer;

	private final CommonFunction commonFunction;

	private final ConcurrentHashMap<String, CaptchaDTO> captchaData = new ConcurrentHashMap<>();

	private static final Logger logger = LoggerFactory.getLogger(CaptchaServiceImpl.class);

	@Override
	public SingleResponse<CaptchaResponse> getCaptcha(HttpServletRequest request) {
		try {
			UUID captchaId = UUID.randomUUID();
			String capText = captchaProducer.createText();
			logger.info(capText);
//			String capText = generateSumCaptcha();
			BufferedImage captchaBufferImage = captchaProducer.createImage(capText);
			ByteArrayOutputStream captchaOutputStream = new ByteArrayOutputStream();

			ImageIO.write(captchaBufferImage, "jpg", captchaOutputStream);

			String base64CaptchaImage = "data:image/jpeg;base64,"
					+ Base64.getEncoder().encodeToString(captchaOutputStream.toByteArray());
			String ipAddress = commonFunction.getIp(request);
			//logger.info("ipAddress",ipAddress);
			//logger.info("Value returned from getIp: [{}]", ipAddress); 


			captchaData.put(captchaId.toString(), new CaptchaDTO(capText, LocalDateTime.now(), ipAddress));
			
//			CaptchaDTO storedDto = captchaData.get(captchaId.toString());
//			if (storedDto != null) {
//			    logger.info("DEBUG: Retrieval successful -> Stored IP: [{}], Current Request IP: [{}]", 
//			                 storedDto.getIp(), ipAddress);
//			} else {
//			    logger.warn("DEBUG: Retrieval FAILED -> No DTO found for ID: [{}]", captchaId);
//			}
			
			return new SingleResponse<>(new CaptchaResponse(captchaId, base64CaptchaImage),
					CustomStatus.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("Error while generating captcha", CustomStatus.CAPTCH_ERROR,409);
		}
	}
	


	@Scheduled(cron = " 0 0/2 * * * *")
	public void removeCapchaData() {
		logger.info("RemoveCapchaData function triggred");
		LocalDateTime now = LocalDateTime.now();
		captchaData.entrySet().removeIf(entry -> {
			LocalDateTime time = entry.getValue().getTime();
			return time.plusMinutes(2).isBefore(now); // Check if entry is older than 1 minute
		});
	}

	@Override
	public CaptchaDTO getCaptchaDTO(String uuid) {
		logger.info("Entering getCaptchaDTO with value: {}", uuid);
	    logger.info("Available keys in captcha map: {}", captchaData.keySet());

		return captchaData.get(uuid);
	}

	@Override
	public void removeCaptchaDTO(String uuid) {
		captchaData.remove(uuid);
	}

	@Override
	public Map<String, CaptchaDTO> getCaptchaData() {
		return captchaData;
	}
	
}
