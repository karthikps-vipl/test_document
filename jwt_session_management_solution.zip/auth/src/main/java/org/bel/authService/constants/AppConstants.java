package org.bel.authService.constants;

import org.springframework.stereotype.Component;

@Component
public class AppConstants {
	private AppConstants() {
    }
	
	public static final int MAX_LOGIN_ATTEMPTS = 3;
	public static final String UNKNOWN_USER = "UNKNOWN";
	public static final String DEFAULT_DISTANCE = "0.00 km";
	public static final String ACTIVE = "ACTIVE";
	public static final String ACKNOWLEDGED = "ACKNOWLEDGED";
	public static final String KEY_COUNT = "count";
	public static final String KEY_ID = "id";
	public static final String KEY_NAME = "name";
	public static final String OTHER_KEY = "0";
	public static final String OTHER_NAME = "Other";
	public static final String PENDING = "PENDING";
	public static final String WAITING_FOR_NODE = "WAITING_FOR_NODE";
	public static final String EDIT_USER = "EDIT_USER";
	public static final String USER_CREATED = "USER_CREATED";
	public static final String DELETE_USER = "DELETE_USER";
	public static final String FAILED = "FAILED";
	public static final String PIN_CHANGE = "PIN_CHANGE";
	public static final String DEVICE = "DEVICE";
	public static final String PASSWORD_CHANGE = "PASSWORD_CHANGE";
	public static final String ADD_NEW_DEVICE = "ADD_NEW_DEVICE";
	public static final String EDIT_DEVICE = "EDIT_DEVICE";
	public static final String BULK_DELETE_DEVICE = "BULK_DELETE_DEVICE";
	public static final String DELETE_DEVICE = "DELETE_DEVICE";
	public static final String TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION = "Target node is inactive at event creation";
	public static final String SIGN_UP = "SIGN_UP";
}
