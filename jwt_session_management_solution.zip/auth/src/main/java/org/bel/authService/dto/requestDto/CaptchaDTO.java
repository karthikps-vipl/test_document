package org.bel.authService.dto.requestDto;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CaptchaDTO {

	private String captchaText;
	
	private LocalDateTime time;
	
	private String ip;
}
