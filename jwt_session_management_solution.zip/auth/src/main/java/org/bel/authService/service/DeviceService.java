package org.bel.authService.service;

import org.bel.authService.dto.responseDto.*;
import java.util.List;

import org.bel.authService.dto.requestDto.AddDeviceRequest;
import org.bel.authService.dto.requestDto.EditDeviceRequest;
import org.bel.authService.dto.requestDto.EditDeviceStatusRequest;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;

public interface DeviceService {
	SingleResponse<DeviceStatsResponse> getDeviceStats();
	
	SingleResponse<List<DeviceListResponse>> getDeviceList();
	
	SingleResponse<List<DeviceListTypeResponse>> getDeviceListType(String type);
	
	SingleResponse<List<DeviceTypeResponse>> getDeviceTypes();

	SingleResponse<AddDeviceResponse> addDevice(@Valid AddDeviceRequest request);
	
	SingleResponse<String> editDevice(@Valid EditDeviceRequest request,Long deviceId);
	
	SingleResponse<DeviceMappingPercentageResponse> getDeviceMappingPercentage();
	
	SingleResponse<String> deleteDevices(List<Long> deviceIds);
	
	SingleResponse<String> deleteDevice(Long deviceId);
	
	SingleResponse<String> editDeviceStatus(@Valid EditDeviceStatusRequest request,Long deviceId);
}
