package org.bel.authService.dto.sync;

import java.util.UUID;

public record EditDeviceSyncEvent(
		UUID eventId,
        String sourceNodeId,
		Long id,
		String deviceId,
		String deviceName,
		String contactNo,
		Integer mdmDeviceTypeId,
		Long mdmUserId,
		String securePin,
		Integer failedLoginCount,
		Integer status
		) {}
