package org.bel.authService.controller;

import java.util.List;

import org.bel.authService.dto.requestDto.AddDeviceRequest;
import org.bel.authService.dto.requestDto.EditDeviceRequest;
import org.bel.authService.dto.requestDto.EditDeviceStatusRequest;
import org.bel.authService.dto.responseDto.AddDeviceResponse;
import org.bel.authService.dto.responseDto.DeviceListResponse;
import org.bel.authService.dto.responseDto.DeviceListTypeResponse;
import org.bel.authService.dto.responseDto.DeviceMappingPercentageResponse;
import org.bel.authService.dto.responseDto.DeviceStatsResponse;
import org.bel.authService.dto.responseDto.DeviceTypeResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.service.DeviceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/device")
@AllArgsConstructor

public class DeviceController {
	private final DeviceService deviceService;
	@GetMapping("/deviceStats")
	public ResponseEntity<SingleResponse<DeviceStatsResponse>> getDeviceStats() {
		SingleResponse<DeviceStatsResponse> response = deviceService.getDeviceStats();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceList")
	public ResponseEntity<SingleResponse<List<DeviceListResponse>>> getDeviceList() {
		SingleResponse<List<DeviceListResponse>> response = deviceService.getDeviceList();
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceList/{type}")
	public ResponseEntity<SingleResponse<List<DeviceListTypeResponse>>> getDeviceListType(@PathVariable String type) {
		SingleResponse<List<DeviceListTypeResponse>> response = deviceService.getDeviceListType(type);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceTypes")
	public ResponseEntity<SingleResponse<List<DeviceTypeResponse>>> getDeviceTypes() {
		SingleResponse<List<DeviceTypeResponse>> response = deviceService.getDeviceTypes();
		return ResponseEntity.ok(response);
	}
	
	@PostMapping("/addDevice")
	public ResponseEntity<SingleResponse<AddDeviceResponse>> addDevice(@Valid @RequestBody AddDeviceRequest request) {
		SingleResponse<AddDeviceResponse> response = deviceService.addDevice(request);
		return ResponseEntity.ok(response);
	}
	
	@PatchMapping("/editDevice/{deviceId}")
	public ResponseEntity<SingleResponse<String>> editDevice(@Valid @RequestBody EditDeviceRequest request,
															@PathVariable("deviceId") Long deviceId) {
		SingleResponse<String> response = deviceService.editDevice(request,deviceId);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/deviceMappingPercentage")
	public ResponseEntity<SingleResponse<DeviceMappingPercentageResponse>> getDeviceMappingPercentage() {
		SingleResponse<DeviceMappingPercentageResponse> response = deviceService.getDeviceMappingPercentage();
		return ResponseEntity.ok(response);
	}
	
	@DeleteMapping("/deleteDevices")
	public ResponseEntity<SingleResponse<String>> deleteDevices(@RequestBody List<Long> deviceIds) {
		SingleResponse<String> response = deviceService.deleteDevices(deviceIds);
		return ResponseEntity.ok(response);
	}
	
	@DeleteMapping("/deleteDevice/{deviceId}")
	public ResponseEntity<SingleResponse<String>> deleteDevice(@PathVariable Long deviceId) {
		SingleResponse<String> response = deviceService.deleteDevice(deviceId);
		return ResponseEntity.ok(response);
	}
	
	@PatchMapping("/editDeviceStatus/{deviceId}")
	public ResponseEntity<SingleResponse<String>> editDeviceStatus(@Valid @RequestBody EditDeviceStatusRequest request,@PathVariable Long deviceId) {
		SingleResponse<String> response = deviceService.editDeviceStatus(request,deviceId);
		return ResponseEntity.ok(response);
	}
}
