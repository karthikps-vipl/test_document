package org.bel.authService.service;

import java.util.List;
import java.util.UUID;

import org.bel.authService.dto.requestDto.PasswordChangeRequest;
import org.bel.authService.dto.requestDto.PinChangeRequest;
import org.bel.authService.dto.requestDto.PinValidationRequest;
import org.bel.authService.dto.requestDto.RefreshTokenRequest;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.NodesListResponse;
import org.bel.authService.dto.responseDto.PinValidationResponse;
import org.bel.authService.dto.responseDto.RolesResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.dto.responseDto.UserTypesResponse;
import org.bel.authService.dto.responseDto.LoginCaptchaResponse;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

public interface AuthService {
    SingleResponse<LoginResponse> login(String serviceId, String rawPassword);

	SingleResponse<PinValidationResponse> validatePin(String userId, String tokenJti, @Valid PinValidationRequest request);

	SingleResponse<String> updatePin(String adminId, Long deviceId, @Valid PinChangeRequest request);

	SingleResponse<String> signUp(String serviceId, String usrPass,UUID deviceUUID);

	SingleResponse<String> refreshTokenRequest(RefreshTokenRequest request);

	SingleResponse<List<RolesResponse>> getListOfRoles();

	SingleResponse<List<NodesListResponse>> getListOfNode();

	SingleResponse<List<UserTypesResponse>> getListOfUserTypes();
	
	SingleResponse<String> passwordChange(String userId,@Valid PasswordChangeRequest request);

	SingleResponse<LoginCaptchaResponse> vendorlogin(String serviceId, String usrPass, String captcha, String string, HttpServletRequest suRequest);
}
