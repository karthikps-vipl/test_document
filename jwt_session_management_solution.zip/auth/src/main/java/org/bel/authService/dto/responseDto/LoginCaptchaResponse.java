package org.bel.authService.dto.responseDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LoginCaptchaResponse {
    private String usrName;
    private String serviceId;
    private String nodeName;
    private String rankName;
    private String mdm_level;
    private String email;

}
