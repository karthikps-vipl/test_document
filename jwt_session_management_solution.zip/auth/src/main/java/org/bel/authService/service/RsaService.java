package org.bel.authService.service;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

@Service
public class RsaService {
	
	// Use Resource instead of String for file paths
	@Value("${app.security.private-key}")
	private Resource privateKeyResource;

	@Value("${app.security.public-key}")
	private Resource publicKeyResource;

	private PrivateKey privateKey;
	private PublicKey publicKey;

	@PostConstruct
	public void init() throws Exception {
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		// 1. Load private key safely
		String privatePem = new String(privateKeyResource.getContentAsByteArray(), StandardCharsets.UTF_8);
		privatePem = privatePem.replace("-----BEGIN PRIVATE KEY-----", "")
				.replace("-----END PRIVATE KEY-----", "")
				.replaceAll("\\s", "");

		byte[] privateBytes = Base64.getDecoder().decode(privatePem);
		PKCS8EncodedKeySpec privateSpec = new PKCS8EncodedKeySpec(privateBytes);
		privateKey = keyFactory.generatePrivate(privateSpec);

		// 2. Load public key safely
		String publicPem = new String(publicKeyResource.getContentAsByteArray(), StandardCharsets.UTF_8);
		publicPem = publicPem.replace("-----BEGIN PUBLIC KEY-----", "")
				.replace("-----END PUBLIC KEY-----", "")
				.replaceAll("\\s", "");

		byte[] publicBytes = Base64.getDecoder().decode(publicPem);
		X509EncodedKeySpec publicSpec = new X509EncodedKeySpec(publicBytes);
		publicKey = keyFactory.generatePublic(publicSpec);
	}

	private OAEPParameterSpec getOaepParameters() {
		return new OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);
	}

	public String decrypt(String encryptedPassword) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey, getOaepParameters());
		byte[] encryptedBytes = Base64.getDecoder().decode(encryptedPassword);
		byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

	public String getPublicKey() throws Exception {
		return "-----BEGIN PUBLIC KEY-----\n"
				+ Base64.getMimeEncoder(64, new byte[] { '\n' }).encodeToString(publicKey.getEncoded())
				+ "\n-----END PUBLIC KEY-----";
	}
	
	public String encrypt(String plainTextPassword) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey, getOaepParameters());
		
		byte[] encryptedBytes = cipher.doFinal(plainTextPassword.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}
}