package org.bel.authService.repository;

import org.bel.authService.entity.AuthSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;

public interface AuthSessionRepository extends JpaRepository<AuthSession, Long> {
    boolean existsByJtiAndUserIdAndTokenTypeAndRevokedFalseAndExpiresAtAfter(
        String jti, Long userId, String tokenType, LocalDateTime now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update AuthSession s set s.revoked = true where s.jti = :jti and s.revoked = false")
    int revokeByJti(@Param("jti") String jti);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update AuthSession s set s.revoked = true where s.userId = :userId and s.tokenType = 'ACCESS' and s.revoked = false")
    int revokeAllAccessSessions(@Param("userId") Long userId);
}
