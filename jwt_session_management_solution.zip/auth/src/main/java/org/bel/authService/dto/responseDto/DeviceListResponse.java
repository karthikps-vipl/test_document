package org.bel.authService.dto.responseDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DeviceListResponse {
	private Long id;
	private String deviceId;
	private String deviceName;
	private Integer deviceTypeId;
	private String deviceType;
	private Integer status;
	private String contactNo;
	private DeviceListUserResponse users;
	private String securePin;
}
