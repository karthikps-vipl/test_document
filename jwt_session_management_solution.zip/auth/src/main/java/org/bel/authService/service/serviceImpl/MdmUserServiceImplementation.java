 package org.bel.authService.service.serviceImpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.bel.authService.dto.requestDto.AddUserRequest;
import org.bel.authService.dto.requestDto.EditDeviceStatusRequest;
import org.bel.authService.dto.requestDto.EditUserRequest;
import org.bel.authService.dto.requestDto.EditUserStatsRequest;
import org.bel.authService.dto.responseDto.AddUserResponse;
import org.bel.authService.dto.responseDto.DeviceResponse;
import org.bel.authService.dto.responseDto.EmailResponse;
import org.bel.authService.dto.responseDto.ListOfUsersResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.entity.MdmLevel;
import org.bel.authService.entity.MdmRank;
import org.bel.authService.entity.MdmRole;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserType;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.entity.NodeRegistry;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.repository.MdmLevelRepository;
import org.bel.authService.repository.MdmRankRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.repository.NodeRegistryRepository;
import org.bel.authService.service.MdmUserService;
import org.bel.authService.service.UserSyncService;
import org.bel.authService.dto.responseDto.UnallottedUsersResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.ArrayList;

@Service
@RequiredArgsConstructor
@Slf4j

public class MdmUserServiceImplementation implements MdmUserService{
	private final MdmUserRepository userRepository;
	private final MdmRoleRepository mdmRoleRepository;
	private final MdmLevelRepository mdmLevelRepository;
	private final MdmRankRepository mdmRankRepository;
	private final MdmUserTypeRepository mdmUserTypeRepository;
	private final MdmUeRepository mdmUeRepository;
	private final MdmUserUeMappingRepository mdmUserUeRepository;
	private final UserSyncService userSyncService;
	private final NodeRegistryRepository nodeRegistryRepository;
	
	@Transactional
	public SingleResponse<AddUserResponse> addUser(Long userId, AddUserRequest request) {
		
		MdmUser mdmUser = userRepository.findById(userId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
		
		if(!mdmUser.getMdmRoleId().getRoleName().equalsIgnoreCase("Super Admin")) {
			throw new CustomException(CustomStatus.UNAUTHORISED, 409);
		}
		
		Optional<MdmUser> existingUser = userRepository.findMdmUserByServiceId(request.getServiceId());
		if (existingUser.isPresent()) {
			throw new CustomException("User Id '" + request.getServiceId() + "' already exists",
					CustomStatus.USER_ALREADY_EXISTS, 409);
		}
		MdmUser newUser = new MdmUser();
		newUser.setId(System.currentTimeMillis());
		newUser.setServiceId(request.getServiceId());
		log.info("Provided Node ID :{}",request.getNodeId());
		log.info("!request.getNodeId().isEmpty() :{}",!request.getNodeId().isEmpty());
		if (!request.getNodeId().isEmpty()) {
			NodeRegistry node = nodeRegistryRepository.findByNodeId(request.getNodeId().trim().toUpperCase())
					.orElseThrow(() -> new CustomException("MdmNode not found", CustomStatus.NODE_NOT_FOUND, 409)); // TODO
			newUser.setNode(node);
		}
		if (request.getMdmRoleId() != null) {
			MdmRole role = mdmRoleRepository.findById(request.getMdmRoleId())
					.orElseThrow(() -> new CustomException("MdmRole not found", CustomStatus.ROLE_NOT_FOUND, 409));
			newUser.setMdmRoleId(role);
		}
		if (request.getMdmUserTypeId() != null) {
			MdmUserType userType = mdmUserTypeRepository.findById(request.getMdmUserTypeId())
					.orElseThrow(() -> new CustomException("MdmUserType not found", CustomStatus.MDM_USER_TYPE_NOT_FOUND, 409));
			newUser.setMdmUserTypeId(userType);
		}
		newUser.setFailedLoginCount(0);
		newUser.setCreatedAt(LocalDateTime.now());
		newUser.setUpdatedAt(LocalDateTime.now());
//		newUser.setCreatedBy(userId);// TODO Change it to this once entity is finalized
		newUser.setCreatedBy(mdmUser.getUsrName());
		newUser.setUserStats(request.getUsrStats());
		newUser.setUsrName(request.getUsrName());
		newUser.setUsrPass("");
		MdmLevel level = mdmLevelRepository.findById(1)
				.orElseThrow(() -> new CustomException("MdmLevel with ID 1 not found", CustomStatus.MDM_LEVEL_NOT_FOUND, 409));
		newUser.setMdmLevelId(level);

		MdmRank rank = mdmRankRepository.findById(1)
				.orElseThrow(() -> new CustomException("MdmRank with ID 1 not found", CustomStatus.MDM_RANK_NOT_FOUND, 409));
		newUser.setMdmRankId(rank);
		newUser.setDateOfJoining(LocalDate.now());
		userRepository.saveAndFlush(newUser);
		// Enqueue a durable USER_CREATED event in the same transaction as the local user.
		// The remote nodes are updated asynchronously by UserSyncOutboxWorker.
		userSyncService.enqueueUserCreated(newUser);
		AddUserResponse response = new AddUserResponse();
		response.setId(newUser.getId());
		
		log.info("DEBUG: The current saved user Id is :{}",newUser.getId());
		log.info("DEBUG: The current saved user is :{}",newUser.getUsrName());
		log.info("DEBUG: The current saved user service id is :{}",newUser.getServiceId());
		
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}
	
	@Override
	public SingleResponse<List<ListOfUsersResponse>> getAllUsers() {
		List<MdmUser> mdmUsers = userRepository.findByUserStatsOrderByServiceIdAsc(1);
	
		List<MdmUserUeMapping> allMappings = mdmUserUeRepository.findAll();
		
		Map<Long, MdmUserUeMapping> mappingMap = allMappings.stream()
				.collect(Collectors.toMap(
						mdmUserMap -> mdmUserMap.getMdmUserId().getId(), 
						mapping -> mapping, 
						(existing, replacement) -> existing));
		
		Set<Long> deviceIds = allMappings.stream()
				.map(m -> m.getMdmUeId().getId())
				.collect(Collectors.toSet());
		
		Map<Long, MdmUe> deviceMap = mdmUeRepository.findAllById(deviceIds).stream()
			    .collect(Collectors.toMap(
			    		MdmUe::getId, 
			    		device -> device));
		
		
		List<ListOfUsersResponse> listOfUsersResponses = mdmUsers.stream()
			    .map(user -> {
			        MdmUserUeMapping mapping = mappingMap.get(user.getId());
			        
			        if (mapping == null) return null; 

			        MdmUe device = deviceMap.get(mapping.getMdmUeId().getId());
			        if (device == null) return null;

			        ListOfUsersResponse response = new ListOfUsersResponse();
			        response.setId(user.getId());
			        response.setServiceId(user.getServiceId());
			        response.setUserName(user.getUsrName());

			        // Device mapping
			        DeviceResponse deviceResponse = new DeviceResponse();
			        deviceResponse.setId(device.getId());
			        deviceResponse.setDeviceId(device.getDeviceId());
			        deviceResponse.setName(device.getDeviceName());
			        response.setDevices(deviceResponse);

			        // Mapping and User Details
			        response.setUserUeMapId(mapping.getId());
			        response.setLoginTime(user.getLoginTime());
			        
			        if (user.getMdmRoleId() != null) {
			            response.setMdmRoleId(user.getMdmRoleId().getId());
			            response.setRoleName(user.getMdmRoleId().getRoleName());
			        }
			        if (user.getMdmUserTypeId() != null) {
			            response.setMdmUserTypeId(user.getMdmUserTypeId().getId());
			            response.setUserType(user.getMdmUserTypeId().getUsrType());
			        }
			        if (user.getNode() != null) {
			            response.setNodeId(user.getNode().getNodeId());
			            response.setNodeName(user.getNode().getNodeName());
			        }
			        if (user.getMdmRankId() != null) {
			            response.setRankName(user.getMdmRankId().getRankName());
			        }
			        if (user.getMdmLevelId() != null) {
			            response.setMdmLevel(user.getMdmLevelId().getMdmLevel());
			        }

			        response.setUserStats(user.getUserStats());
			        response.setEmail(user.getEmail());
			        response.setDateOfJoining(user.getDateOfJoining());
			        
			        return response;
			    })
			    .filter(Objects::nonNull) // Remove users who didn't have a mapping or device
			    .toList();
		return new SingleResponse<>(
				listOfUsersResponses,
				CustomStatus.SUCCESS
			);
	}
	
	@Transactional
	public SingleResponse<String> editUser(@Valid EditUserRequest request,Long userId) {
		MdmUser mdmUser = userRepository.findById(userId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
		if(mdmUser.getUserStats()==1) {
			mdmUser.setFailedLoginCount(0);
		}
		if (request.getServiceId() != null) {
	        mdmUser.setServiceId(request.getServiceId());
	    }
		log.info("Provided Node ID :{}",request.getNodeId());
		if (!request.getNodeId().isEmpty()) {
			NodeRegistry node = nodeRegistryRepository.findByNodeId(request.getNodeId().trim().toUpperCase())
					.orElseThrow(() -> new CustomException(CustomStatus.MDM_NODE_NOT_FOUND, 409));
			mdmUser.setNode(node);
			
	    }
		if (request.getMdmRoleId() != null) {
			MdmRole mdmRole = mdmRoleRepository.findById(request.getMdmRoleId())
					.orElseThrow(() -> new CustomException(CustomStatus.ROLE_NOT_FOUND, 409));
			mdmUser.setMdmRoleId(mdmRole);
			
	    }
		if (request.getMdmUserTypeId() != null) {
			MdmUserType mdmUserType = mdmUserTypeRepository.findById(request.getMdmUserTypeId())
					.orElseThrow(() -> new CustomException(CustomStatus.MDM_USER_TYPE_NOT_FOUND, 409));
			mdmUser.setMdmUserTypeId(mdmUserType);
	    }
		if (request.getUsrName() != null) {
	        mdmUser.setUsrName(request.getUsrName());
	    }
		userRepository.save(mdmUser);
		userSyncService.editUserSync(mdmUser);
		return new SingleResponse<>(null,CustomStatus.SUCCESS);
	}
	
	@Transactional
	public SingleResponse<String> deleteUser(List<Long> userIds) {
		for (Long id : userIds) {
	        MdmUser user = userRepository.findById(id)
	            .orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
	        if (user.getUserStats() == 2) {
	        	throw new CustomException("User deleted", CustomStatus.BAD_REQUEST, 409);
	        }
	        user.setUserStats(2);
	        userRepository.save(user);
	        userSyncService.deleteUserSync(user);
	    }
		return new SingleResponse<>(null,CustomStatus.SUCCESS);
	}
	
	@Transactional
	public SingleResponse<List<UnallottedUsersResponse>> getUnallottedUsers() {
		 List<MdmUser> users = userRepository.findAllByOrderByServiceIdAsc();
		 Set<Long> activeMappingIds = new HashSet<>();
		    List<MdmUserUeMapping> allMappings = mdmUserUeRepository.findAll();    
		    for (MdmUserUeMapping device : allMappings) {
		        if (device.isActive()) {
		        	Long mdmUserId = device.getMdmUserId().getId();
		            if (mdmUserId != null) {
		                activeMappingIds.add(mdmUserId);
		            }
		        }
		    }
		    List<UnallottedUsersResponse> responseList = new ArrayList<>();
		    for (MdmUser user : users) {
		    	if (user.getUserStats() == 1 && !activeMappingIds.contains(user.getId())) {
		                UnallottedUsersResponse dto = new UnallottedUsersResponse();
		                dto.setId(user.getId());
		                dto.setServiceId(user.getServiceId());
		                dto.setOptional(user.getUsrName());
		                responseList.add(dto);
		    	}
		    }
		    return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}
	
	@Transactional
	public SingleResponse<EmailResponse> getEmail(String serviceId) {
		MdmUser user = userRepository.findMdmUserByServiceId(serviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
		if (user.getUserStats() == 2) {
        	throw new CustomException("Your account wasn't found. Please ensure you're using the right credentials.", CustomStatus.ACCOUNT_NOT_FOUND, 409);
        }
		if (user.isSignupStatus()) {
        	throw new CustomException("User already signed up, please go to login page", CustomStatus.USER_ALREADY_SIGNED_UP, 409);
        }
		EmailResponse response = new EmailResponse();
		response.setEmail(user.getEmail());
		response.setName(user.getUsrName());
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}
	
	@Override
	@Transactional
	public SingleResponse<String> editUserStats(@Valid EditUserStatsRequest request,Long userId) {
		MdmUser mdmUser = userRepository.findById(userId)
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));
		if (request.getUserStats() != null) {
			mdmUser.setUserStats(request.getUserStats());
		}
		userRepository.save(mdmUser);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
}
