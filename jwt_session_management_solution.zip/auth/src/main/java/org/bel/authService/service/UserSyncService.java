package org.bel.authService.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.bel.authService.constants.AppConstants;
import org.bel.authService.dto.sync.DeleteUserSyncEvent;
import org.bel.authService.dto.sync.EditUserSyncEvent;
import org.bel.authService.dto.sync.PasswordChangeSyncEvent;
import org.bel.authService.dto.sync.SignUpSyncEvent;
import org.bel.authService.dto.sync.UserCreatedSyncEvent;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.NodeRegistry;
import org.bel.authService.entity.SyncOutboxDelivery;
import org.bel.authService.entity.SyncUserOutbox;
import org.bel.authService.repository.MdmLevelRepository;
import org.bel.authService.repository.MdmRankRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.NodeRegistryRepository;
import org.bel.authService.repository.SyncOutboxDeliveryRepository;
import org.bel.authService.repository.SyncUserOutboxRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserSyncService {

	private final ObjectMapper objectMapper;
	private final SyncUserOutboxRepository userOutboxRepository;
	private final SyncOutboxDeliveryRepository deliveryRepository;
	private final NodeRegistryRepository nodeRegistryRepository;
	private final CurrentNodeResolver currentNodeResolver;
	private final MdmUserRepository userRepository;
	private final MdmRoleRepository roleRepository;
	private final MdmUserTypeRepository userTypeRepository;
	private final MdmLevelRepository levelRepository;
	private final MdmRankRepository rankRepository;

	/**
	 * Called inside addUser's transaction: user and outbox event commit together.
	 */
	@Transactional
	public void enqueueUserCreated(MdmUser user) {
		String localNodeId = currentNodeResolver.getCurrentNodeId();
		List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
		UUID eventId = UUID.randomUUID();
		UserCreatedSyncEvent event = toEvent(user, eventId, localNodeId);
		final String payload;
		try {
			payload = objectMapper.writeValueAsString(event);
		} catch (Exception ex) {
			log.error("DEBUG : Unable to serialize USER_CREATED sync event");
			throw new IllegalStateException("Unable to serialize USER_CREATED sync event", ex);
		}

		LocalDateTime now = LocalDateTime.now();

		SyncUserOutbox userOutbox = SyncUserOutbox.builder()
				.eventId(eventId)
				.eventType(AppConstants.USER_CREATED)
				.entityType("USER")
				.userId(user.getId())
				.sourceNodeId(localNodeId)
				.payload(payload)
				.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
				.retryCount(0)
				.createdAt(now)
				.sentAt(peers.isEmpty() ? now : null)
				.build();
		userOutboxRepository.save(userOutbox);

		for (NodeRegistry peer : peers) {
			boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
			deliveryRepository.save(SyncOutboxDelivery.builder().eventId(eventId).targetNodeId(peer.getNodeId())
					.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE).retryCount(0).createdAt(now)
					.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION).build());
		}
	}

	/**
	 * Idempotent receiver: serviceId is the cross-node business key, not local
	 * numeric id.
	 */
	@Transactional
	public UserSyncAck receiveUserCreated(UserCreatedSyncEvent event, String receivingNodeId) {
		if (event == null || event.eventId() == null || event.serviceId() == null || event.serviceId().isBlank()) {
			log.warn("DEBUG: eventId and serviceId are required");
			throw new IllegalArgumentException("eventId and serviceId are required");
		}
		if (userRepository.findById(event.sourceUserId()).isPresent()) {
			return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId,
					"User already exists; duplicate event safely ignored");
		}

		MdmUser user = new MdmUser();
		user.setId(event.sourceUserId());
		user.setServiceId(event.serviceId());
		user.setNode(nodeRegistryRepository.findByNodeId(event.sourceNodeId())
				.orElseThrow(() -> new IllegalStateException("Missing node id " + event.sourceNodeId())));
		user.setMdmRoleId(roleRepository.findById(event.mdmRoleId())
				.orElseThrow(() -> new IllegalStateException("Missing mdm_role id " + event.mdmRoleId())));
		user.setMdmUserTypeId(userTypeRepository.findById(event.mdmUserTypeId())
				.orElseThrow(() -> new IllegalStateException("Missing mdm_user_type id " + event.mdmUserTypeId())));
		user.setMdmLevelId(levelRepository.findById(event.mdmLevelId())
				.orElseThrow(() -> new IllegalStateException("Missing mdm_level id " + event.mdmLevelId())));
		user.setMdmRankId(rankRepository.findById(event.mdmRankId())
				.orElseThrow(() -> new IllegalStateException("Missing mdm_rank id " + event.mdmRankId())));
		user.setUsrName(event.usrName());
		// Credential material is intentionally not replicated.
		user.setUsrPass("");
		user.setUserStats(event.userStats());
		user.setFailedLoginCount(event.failedLoginCount() == null ? 0 : event.failedLoginCount());
		user.setSignupStatus(event.signupStatus());
		user.setCreatedBy(event.createdBy());
		user.setEmail(event.email());
		user.setDateOfJoining(event.dateOfJoining());
		user.setPasswordChangedAt(event.passwordChangedAt());
		user.setCreatedAt(event.createdAt() == null ? LocalDateTime.now() : event.createdAt());
		user.setUpdatedAt(event.updatedAt() == null ? LocalDateTime.now() : event.updatedAt());
		user.setLastLogin(event.lastLogin());
		user.setLoginTime(event.loginTime());
		userRepository.saveAndFlush(user);
		return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "User created");
	}

	public UserCreatedSyncEvent parsePayload(String payload) {
		try {
			return objectMapper.readValue(payload, UserCreatedSyncEvent.class);
		} catch (Exception ex) {
			log.error("DEBUG: Invalid USER_CREATED payload");
			throw new IllegalStateException("Invalid USER_CREATED payload", ex);
		}
	}

	private UserCreatedSyncEvent toEvent(MdmUser user, UUID eventId, String localNodeId) {
		return new UserCreatedSyncEvent(eventId, localNodeId, user.getId(), user.getServiceId(),
//                user.getNode() == null ? null : user.getNode().getNodeId(),
				user.getMdmRoleId() == null ? null : user.getMdmRoleId().getId(),
				user.getMdmUserTypeId() == null ? null : user.getMdmUserTypeId().getId(),
				user.getMdmLevelId() == null ? null : user.getMdmLevelId().getId(),
				user.getMdmRankId() == null ? null : user.getMdmRankId().getId(), user.getUsrName(),
				user.getUserStats(), user.getFailedLoginCount(), user.isSignupStatus(), user.getCreatedBy(),
				user.getEmail(), user.getDateOfJoining(), user.getPasswordChangedAt(), user.getCreatedAt(),
				user.getUpdatedAt(), user.getLastLogin(), user.getLoginTime());
	}

	// ==========================================
	// EDIT USER EVENT
	// ==========================================
	@Transactional
	public void editUserSync(MdmUser user) {
		String localNodeId = currentNodeResolver.getCurrentNodeId();
		List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
		UUID eventId = UUID.randomUUID();
		EditUserSyncEvent event = editUserEvent(user, eventId, localNodeId);
		final String payload;
		try {
			payload = objectMapper.writeValueAsString(event);
		} catch (Exception ex) {
			log.error("DEBUG: Unable to serialize EDIT_USER sync event");
			throw new IllegalStateException("Unable to serialize EDIT_USER sync event", ex);
		}

		LocalDateTime now = LocalDateTime.now();
		SyncUserOutbox userOutBox = SyncUserOutbox.builder().eventId(eventId).eventType("EDIT_USER").entityType("USER")
				.userId(user.getId()).sourceNodeId(localNodeId).payload(payload)
				.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING).retryCount(0).createdAt(now)
				.sentAt(peers.isEmpty() ? now : null).build();
		userOutboxRepository.save(userOutBox);

		for (NodeRegistry peer : peers) {
			boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
			deliveryRepository.save(SyncOutboxDelivery.builder().eventId(eventId).targetNodeId(peer.getNodeId())
					.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE).retryCount(0).createdAt(now)
					.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION).build());
		}
	}

	public EditUserSyncEvent parseEditPayload(String payload) {
		try {
			return objectMapper.readValue(payload, EditUserSyncEvent.class);
		} catch (Exception ex) {
			log.error("DEBUG: Invalid EDIT_USER payload");
			throw new IllegalStateException("Invalid EDIT_USER payload", ex);
		}
	}

	// EDIT USER EVENT
	private EditUserSyncEvent editUserEvent(MdmUser user, UUID eventId, String localNodeId) {
		return new EditUserSyncEvent(eventId, localNodeId, user.getId(), user.getServiceId(),
				user.getMdmRoleId() == null ? null : user.getMdmRoleId().getId(),
				user.getMdmUserTypeId() == null ? null : user.getMdmUserTypeId().getId(), user.getUsrName());
	}

	// EDIT USER EVENT
	@Transactional
	public UserSyncAck receiveEditUser(EditUserSyncEvent event, String receivingNodeId) {

		log.info("DEBUG: Received EDIT_USER event");

		if (event == null || event.eventId() == null || event.serviceId() == null || event.serviceId().isBlank()) {
			throw new IllegalArgumentException("eventId and serviceId are required");
		}
		Optional<MdmUser> optionalUser = userRepository.findById(event.sourceUserId());
		if (optionalUser.isEmpty()) {
			log.error("DEBUG: User not found. Cannot apply edit until user is created.");
			throw new IllegalStateException("User not found. Cannot apply edit until user is created.");
		}

		MdmUser user = optionalUser.get();

		if (event.serviceId() != null && !event.serviceId().trim().isEmpty()) {
			user.setServiceId(event.serviceId());
		}

		if (event.mdmRoleId() != null) {
			user.setMdmRoleId(roleRepository.findById(event.mdmRoleId())
					.orElseThrow(() -> new IllegalStateException("Missing mdm_role id " + event.mdmRoleId())));
		}

		if (event.mdmUserTypeId() != null) {
			user.setMdmUserTypeId(userTypeRepository.findById(event.mdmUserTypeId())
					.orElseThrow(() -> new IllegalStateException("Missing mdm_user_type id " + event.mdmUserTypeId())));
		}

		if (event.usrName() != null && !event.usrName().trim().isEmpty()) {
			user.setUsrName(event.usrName());
		}

		userRepository.saveAndFlush(user);
		return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "User edited");
	}

	// ==========================================
	// DELETE USER EVENT
	// ==========================================
	@Transactional
	public void deleteUserSync(MdmUser user) {
		// Unrecognized field "serviceId" (class
		// org.bel.location.dto.request.LocationSyncEvent), not marked as ignorable (10
		// known properties: "eventType", "eventId", "userId", "sourceNodeId",
		// "latitude", "entityType", "targetNodeId", "longitude", "timestamp",
		// "version")
		// at [Source: REDACTED (`StreamReadFeature.INCLUDE_SOURCE_IN_LOCATION`
		// disabled); line: 1, column: 101] (through reference chain:
		// org.bel.location.dto.request.LocationSyncEvent["serviceId"])
		String localNodeId = currentNodeResolver.getCurrentNodeId();
		List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
		UUID eventId = UUID.randomUUID();
		DeleteUserSyncEvent event = new DeleteUserSyncEvent(eventId, user.getId(), localNodeId, user.getServiceId());

		final String payload;
		try {
			payload = objectMapper.writeValueAsString(event);
		} catch (Exception ex) {
			log.error("DEBUG: Unable to serialize DELETE_USER sync event");
			throw new IllegalStateException("Unable to serialize DELETE_USER sync event", ex);
		}

		LocalDateTime now = LocalDateTime.now();
		SyncUserOutbox userOutbox = SyncUserOutbox.builder().eventId(eventId).eventType(AppConstants.DELETE_USER)
				.entityType("USER").userId(user.getId()).sourceNodeId(localNodeId).payload(payload)
				.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING).retryCount(0).createdAt(now)
				.sentAt(peers.isEmpty() ? now : null).build();
		userOutboxRepository.save(userOutbox);

		for (NodeRegistry peer : peers) {
			boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
			deliveryRepository.save(SyncOutboxDelivery.builder().eventId(eventId).targetNodeId(peer.getNodeId())
					.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE).retryCount(0).createdAt(now)
					.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION).build());
		}
	}

	@Transactional
	public UserSyncAck receiveDeleteUser(DeleteUserSyncEvent event, String receivingNodeId) {
		if (event == null || event.eventId() == null || event.serviceId() == null || event.serviceId().isBlank()) {
			log.warn("DEBUG: eventId and serviceId are required");
			throw new IllegalArgumentException("eventId and serviceId are required");
		}

		Optional<MdmUser> optionalUser = userRepository.findById(event.sourceUserId());

		if (optionalUser.isEmpty()) {
			// Throw error to force retry, ensuring we don't drop the delete
			// if the USER_CREATED event is lagging behind.
			log.error("DEBUG: User not found. Cannot soft-delete until user is synced.");
			throw new IllegalStateException("User not found. Cannot soft-delete until user is synced.");
		}

		MdmUser user = optionalUser.get();
		user.setUserStats(2);
		userRepository.saveAndFlush(user);

		return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId,
				"User soft-deleted successfully");
	}

	public DeleteUserSyncEvent parseDeletePayload(String payload) {
		try {
			return objectMapper.readValue(payload, DeleteUserSyncEvent.class);
		} catch (Exception ex) {
			log.error("DEBUG: Invalid DELETE_USER payload");
			throw new IllegalStateException("Invalid DELETE_USER payload", ex);
		}
	}
	

	// ==========================================
	// PASSWORD CHANGE EVENT
	// ==========================================
	@Transactional
	public void passwordChangeSync(MdmUser user) {
		String localNodeId = currentNodeResolver.getCurrentNodeId();
		List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
		UUID eventId = UUID.randomUUID();
		PasswordChangeSyncEvent event = passwordChangeEvent(user, eventId, localNodeId);
		final String payload;
		try {
			payload = objectMapper.writeValueAsString(event);
		} catch (Exception ex) {
			log.error("DEBUG: Unable to serialize PASSWORD_CHANGE sync event");
			throw new IllegalStateException("Unable to serialize PASSWORD_CHANGE sync event", ex);
		}

		LocalDateTime now = LocalDateTime.now();
		SyncUserOutbox userOutBox = SyncUserOutbox.builder()
				.eventId(eventId)
				.eventType(AppConstants.PASSWORD_CHANGE)
				.entityType("USER")
				.userId(user.getId())
				.sourceNodeId(localNodeId)
				.payload(payload)
				.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
				.retryCount(0)
				.createdAt(now)
				.sentAt(peers.isEmpty() ? now : null)
				.build();
		userOutboxRepository.save(userOutBox);

		for (NodeRegistry peer : peers) {
			boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
			deliveryRepository.save(SyncOutboxDelivery.builder()
					.eventId(eventId)
					.targetNodeId(peer.getNodeId())
					.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
					.retryCount(0)
					.createdAt(now)
					.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
					.build());
		}
	}

	public PasswordChangeSyncEvent parsePasswordChangePayload(String payload) {
		try {
			return objectMapper.readValue(payload, PasswordChangeSyncEvent.class);
		} catch (Exception ex) {
			log.error("DEBUG: Invalid PASSWORD_CHANGE payload");
			throw new IllegalStateException("Invalid PASSWORD_CHANGE payload", ex);
		}
	}

	// PASSWORD CHANGE EVENT
	private PasswordChangeSyncEvent passwordChangeEvent(MdmUser user, UUID eventId, String localNodeId) {
		return new PasswordChangeSyncEvent(
				eventId, 
				localNodeId, 
				user.getId(), 
				user.getUsrPass(),
				user.getPasswordChangedAt(),
				user.getUpdatedAt());
	}

	// PASSWORD CHANGE EVENT
	@Transactional
	public UserSyncAck receivePasswordChange(PasswordChangeSyncEvent event, String receivingNodeId) {

		log.info("DEBUG: Received PASSWORD_CHANGE event");

		if (event == null || event.eventId() == null || event.sourceUserId() == null) {
			log.warn("DEBUG :eventId and source userId are required");
			throw new IllegalArgumentException("eventId and source userId are required");
		}
		Optional<MdmUser> optionalUser = userRepository.findById(event.sourceUserId());
		if (optionalUser.isEmpty()) {
			log.warn("DEBUG: User not found. Cannot apply password change until user is created.");
			throw new IllegalStateException("User not found. Cannot apply password change until user is created.");
		}

		MdmUser user = optionalUser.get();

		if (event.userPass() != null && !event.userPass().trim().isEmpty()) {
			user.setUsrPass(event.userPass());
		}

		if (event.passwordChagnedAt() != null) {
			user.setPasswordChangedAt(event.passwordChagnedAt());
		}

		if (event.updatedAt() != null) {
			user.setUpdatedAt(event.updatedAt());
		}

		userRepository.saveAndFlush(user);
		return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "Password Changed");
	}


	// ==========================================
	// USER SIGNUP EVENT
	// ==========================================
	@Transactional
	public void syncSignUp(MdmUser user) {
		String localNodeId = currentNodeResolver.getCurrentNodeId();
		List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
		UUID eventId = UUID.randomUUID();
		SignUpSyncEvent event = signUpEvent(user, eventId, localNodeId);
		final String payload;
		try {
			payload = objectMapper.writeValueAsString(event);
		} catch (Exception ex) {
			log.error("DEBUG: Unable to serialize SIGN_UP sync event");
			throw new IllegalStateException("Unable to serialize SIGN_UP sync event", ex);
		}

		LocalDateTime now = LocalDateTime.now();
		SyncUserOutbox userOutBox = SyncUserOutbox.builder()
				.eventId(eventId)
				.eventType(AppConstants.SIGN_UP)
				.entityType("USER")
				.userId(user.getId())
				.sourceNodeId(localNodeId)
				.payload(payload)
				.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
				.retryCount(0)
				.createdAt(now)
				.sentAt(peers.isEmpty() ? now : null)
				.build();
		userOutboxRepository.save(userOutBox);

		for (NodeRegistry peer : peers) {
			boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
			deliveryRepository.save(SyncOutboxDelivery.builder()
					.eventId(eventId)
					.targetNodeId(peer.getNodeId())
					.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
					.retryCount(0)
					.createdAt(now)
					.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
					.build());
		}
	}

	public SignUpSyncEvent parseUserSignUpPayload(String payload) {
		try {
			return objectMapper.readValue(payload, SignUpSyncEvent.class);
		} catch (Exception ex) {
			log.error("DEBUG: Invalid SIGN_UP payload");
			throw new IllegalStateException("Invalid SIGN_UP payload", ex);
		}
	}

	// USER SIGN UP EVENT
	private SignUpSyncEvent signUpEvent(MdmUser user, UUID eventId, String localNodeId) {
		return new SignUpSyncEvent(
				eventId, 
				localNodeId, 
				user.getId(), 
				user.getUsrPass(),
				user.isSignupStatus());
	}

	// USER SIGN UP EVENT
	@Transactional
	public UserSyncAck receiveUserSignUp(SignUpSyncEvent event, String receivingNodeId) {

		log.info("DEBUG: Received SIGN_UP event");

		if (event == null || event.eventId() == null || event.sourceUserId() == null) {
			log.warn("DEBUG :eventId and source userId are required");
			throw new IllegalArgumentException("EventId and Source UserId are required");
		}
		Optional<MdmUser> optionalUser = userRepository.findById(event.sourceUserId());
		if (optionalUser.isEmpty()) {
			log.warn("DEBUG: User not found. Cannot apply sign up until user is created.");
			throw new IllegalStateException("User not found. Cannot apply sign up until user is created.");
		}

		MdmUser user = optionalUser.get();

		if (event.userPass() != null && !event.userPass().trim().isEmpty()) {
			user.setUsrPass(event.userPass());
			user.setSignupStatus(event.signUpStatus());
		}
		userRepository.saveAndFlush(user);
		return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "SignUp Completed");
	}

}
