package org.bel.authService.dto.sync;

import java.util.List;
import java.util.UUID;

public record DeleteBulkDeviceEvent(
		UUID eventId,
        String sourceNodeId,
		List<Long> deviceIds
		) {}
