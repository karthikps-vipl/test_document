package org.bel.authService.dto.requestDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EditUserRequest {
    private String serviceId;
    private String nodeId;
    private Integer mdmRoleId;
    private Integer mdmUserTypeId;
    private String usrName;
}
