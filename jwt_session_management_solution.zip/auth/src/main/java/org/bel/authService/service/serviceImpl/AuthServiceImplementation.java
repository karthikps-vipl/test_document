package org.bel.authService.service.serviceImpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bel.authService.config.AppProperties;
import org.bel.authService.constants.AppConstants;
import org.bel.authService.dto.requestDto.CaptchaDTO;
import org.bel.authService.dto.requestDto.PasswordChangeRequest;
import org.bel.authService.dto.requestDto.PinChangeRequest;
import org.bel.authService.dto.requestDto.PinValidationRequest;
import org.bel.authService.dto.requestDto.RefreshTokenRequest;
import org.bel.authService.dto.responseDto.LoginCaptchaResponse;
import org.bel.authService.dto.responseDto.LoginResponse;
import org.bel.authService.dto.responseDto.NodesListResponse;
import org.bel.authService.dto.responseDto.PinValidationResponse;
import org.bel.authService.dto.responseDto.RolesResponse;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.dto.responseDto.UserTypesResponse;
import org.bel.authService.entity.MdmRole;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserType;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.entity.NodeRegistry;
import org.bel.authService.entity.RefreshToken;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.repository.AuthSessionRepository;
import org.bel.authService.repository.MdmRoleRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserTypeRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.repository.NodeRegistryRepository;
import org.bel.authService.repository.RefreshTokenRepository;
import org.bel.authService.service.AuthService;
import org.bel.authService.service.DeviceSyncService;
import org.bel.authService.service.RsaService;
import org.bel.authService.service.UserSyncService;
import org.bel.authService.util.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bel.authService.util.CommonFunction;
import org.bel.authService.service.CaptchaService;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImplementation implements AuthService {
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;
	private final MdmUserUeMappingRepository mdmUserUeRepository;
	private final MdmUserRepository userRepository;
	private final MdmUeRepository mdmUeRepository;
	private final MdmRoleRepository mdmRoleRepository;
	private final MdmUserTypeRepository mdmUserTypeRepository;
	private final AppProperties appProperties;
	private final RefreshTokenRepository refreshTokenRepository;
	private final AuthSessionRepository authSessionRepository;
	private final NodeRegistryRepository nodeRegistryRepository;
	private final DeviceSyncService deviceSyncService;
	private final UserSyncService userSyncService;
	private final RsaService rsaService;
	private final CommonFunction commonFunction ;
	private final CaptchaService captchaService;

	@Transactional
	public SingleResponse<LoginResponse> login(String serviceId, String encryptedPassword) {
		// 1. Fetch User
		MdmUser user = userRepository.findMdmUserByServiceId(serviceId)
				.orElseThrow(() -> new CustomException("Account not found", CustomStatus.ACCOUNT_NOT_FOUND, 409));

		MdmUserUeMapping ueMapping = mdmUserUeRepository.findMdmUserUeMappingByMdmUserId(user.getId()).orElseThrow(
				() -> new CustomException("Device not found", CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 409));

		// 2. Validate Statuses
		if (user.getUserStats() == 2)
			throw new CustomException("User deleted", CustomStatus.ACCOUNT_DELETED, 409);
		if (ueMapping.getMdmUeId() == null)
			throw new CustomException("No device allotted", CustomStatus.MDM_USER_UE_MAPPING_NOT_FOUND, 409);
		if (!user.isSignupStatus())
			throw new CustomException("Signup incomplete", CustomStatus.SIGNUP_INCOMPLETE, 409);

		if (user.getUserStats() == 3)
			throw new CustomException("User is locked", CustomStatus.USER_LOCKED, 409);
		if (user.getUserStats() == 0)
			throw new CustomException("User is deactivated", CustomStatus.USER_DEACTIVATED, 409);

		// 3. Check Password
//		if (!rawPassword.equals(appProperties.getLogin().getFixedPassword())
//				&& !passwordEncoder.matches(rawPassword, user.getUsrPass())) {
//			handleFailedLogin(user);
//			throw new CustomException(CustomStatus.INVALID_PASSWORD, 401);
//		}

		String rawPassword = null;
		try {
			rawPassword = rsaService.decrypt(encryptedPassword);
			log.info("Raw Password is {}",rawPassword);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
		} catch (IllegalArgumentException e) { 
			log.error("Password must be Base64 encoded");
			// Thrown when the frontend sends raw text or invalid Base64 characters
			throw new CustomException("Password must be Base64 encoded", CustomStatus.BAD_REQUEST, 409);
		} catch (Exception e) {
			// Thrown when Base64 is valid, but RSA decryption fails (e.g. wrong key padding)
			handleFailedLogin(user);
			log.error("Invalid encryption format or credentials");
			throw new CustomException("Invalid encryption format or credentials", CustomStatus.INVALID_PASSWORD, 409);
		}

		boolean isFixedPasswordMatch = appProperties.getLogin().isFixedPasswordEnabled() 
                && rawPassword.equals(appProperties.getLogin().getFixedPassword());

		boolean isStandardPasswordMatch = passwordEncoder.matches(rawPassword, user.getUsrPass());
		
		if (!(isFixedPasswordMatch || isStandardPasswordMatch)) {
			handleFailedLogin(user);
			throw new CustomException(CustomStatus.INVALID_PASSWORD, 409);
		}
		
//		if (!rawPassword.equals(appProperties.getLogin().getFixedPassword())
//				&& !passwordEncoder.matches(rawPassword, user.getUsrPass())) {
//			handleFailedLogin(user);
//			throw new CustomException(CustomStatus.INVALID_PASSWORD, 409);
//		}
		// Add Login time
		// 4. Success: Reset attempts and return response
		userRepository.resetFailedAttempts(user.getId());
		LoginResponse response = new LoginResponse();
		response.setId(user.getId());
		response.setUsrName(user.getUsrName());
		response.setServiceId(user.getServiceId());
		response.setMdmUeId(ueMapping.getMdmUeId().getId());
		response.setDeviceId(ueMapping.getMdmUeId().getDeviceId());
		response.setUserUeMapId(ueMapping.getId());
		response.setMdmRoleId(user.getMdmRoleId().getId());
		response.setDeviceName(ueMapping.getMdmUeId().getDeviceName());
		response.setRoleName(user.getMdmRoleId().getRoleName());
		response.setUsrType(user.getMdmUserTypeId().getUsrType());

		if (ueMapping.getLoginTime() == null) {
			ueMapping.setLoginTime(null);
		} else {
			response.setLoginTime(ueMapping.getLoginTime());
		}

		response.setNodeName(user.getNode().getNodeName()); // TODO
		response.setRankName(user.getMdmRankId().getRankName());
		response.setMdm_level(user.getMdmLevelId().getMdmLevel());
		response.setEmail(user.getEmail());
		response.setContactNo(ueMapping.getMdmUeId().getContactNo());
		response.setSortOrder(user.getMdmRoleId().getSortOrder());
		log.info("DEBUG : Login response built attempting for token generation");
		response.setToken(jwtUtil.generatePreAuthToken(user.getId(), user.getMdmRoleId().getId()));
		return new SingleResponse<>(response, CustomStatus.SUCCESS);
	}

	private void handleFailedLogin(MdmUser user) {
		int newCount = user.getFailedLoginCount() + 1;
		int newStats = (newCount > AppConstants.MAX_LOGIN_ATTEMPTS) ? 3 : user.getUserStats();
		userRepository.updateFailedAttempts(user.getId(), newCount, newStats);
	}

	@Transactional
	public SingleResponse<PinValidationResponse> validatePin(String userId, String tokenJti, PinValidationRequest request) {

		MdmUser mdmUser = userRepository.findByIdForUpdate(Long.parseLong(userId))
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));

		String enteredPin = request.getSecurePin();

		MdmUserUeMapping mdmUserUeMapping = mdmUserUeRepository.findMdmUserUeMappingByMdmUserId(Long.parseLong(userId))
				.orElseThrow(() -> new CustomException(CustomStatus.UE_MAPPING_NOT_FOUND, 409));

		if (enteredPin == null || !enteredPin.matches("^\\d{6}$")) {
			throw new CustomException(CustomStatus.INVALID_PIN, 409);
		}

		MdmUe device = mdmUeRepository.findById(mdmUserUeMapping.getMdmUeId().getId())
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 409));

		if (device.getStatus() == 0) {
			throw new CustomException(CustomStatus.DEVICE_LOCKED, 409);
		}

		if (device.getSecurePin().equals(enteredPin)) {
            boolean preAuthActive = authSessionRepository
                .existsByJtiAndUserIdAndTokenTypeAndRevokedFalseAndExpiresAtAfter(
                    tokenJti, mdmUser.getId(), "PRE_AUTH", LocalDateTime.now(ZoneOffset.UTC));
            if (!preAuthActive) {
                throw new CustomException("Pre-authentication token is invalid or already used",
                    CustomStatus.INVALID_REFRESH_TOKEN, 401);
            }
            handleSuccessfulLogin(device);
            authSessionRepository.revokeByJti(tokenJti);
            authSessionRepository.revokeAllAccessSessions(mdmUser.getId());
            refreshTokenRepository.revokeAllByUserId(mdmUser.getId());
            String accessToken = jwtUtil.generateAccessToken(mdmUser.getId(), mdmUser.getMdmRoleId().getId());
            String refreshToken = jwtUtil.generateRefreshToken(mdmUser.getId());
            PinValidationResponse response = new PinValidationResponse(accessToken, refreshToken);
            return new SingleResponse<>(response, CustomStatus.SUCCESS);
		} else {
			return handleFailedLogin(device);
		}
	}

	private void handleSuccessfulLogin(MdmUe device) {
		if (device.getFailedLoginCount() > 0 && device.getFailedLoginCount() != AppConstants.MAX_LOGIN_ATTEMPTS) {
			device.setFailedLoginCount(0);
			mdmUeRepository.save(device);
		}
	}

	private SingleResponse<PinValidationResponse> handleFailedLogin(MdmUe device) {
		int updatedAttempts = device.getFailedLoginCount() + 1;
		device.setFailedLoginCount(updatedAttempts);

		if (updatedAttempts >= AppConstants.MAX_LOGIN_ATTEMPTS) {
			device.setStatus(0); // Lock device
			mdmUeRepository.save(device);
			throw new CustomException(CustomStatus.DEVICE_LOCKED, 409);
		} else {
			mdmUeRepository.save(device);
			int remaining = AppConstants.MAX_LOGIN_ATTEMPTS - updatedAttempts;
			throw new CustomException("Remaining Attempts " + remaining, CustomStatus.INCORRECT_PIN, 409);
		}
	}

	// ADMIN WILL UPDATE THE PIN
	public SingleResponse<String> updatePin(String adminId, Long deviceId, PinChangeRequest request) {

		MdmUser adminUser = userRepository.findById(Long.parseLong(adminId))
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));

		MdmUe device = mdmUeRepository.findById(deviceId)
				.orElseThrow(() -> new CustomException(CustomStatus.DEVICE_NOT_FOUND, 409));

		if (request.getNewPin().equals(request.getOldPin())) {
			throw new CustomException(CustomStatus.OLD_AND_NEW_PIN_SAME, 409);
		}

		if (request.getNewPin() == null || !request.getNewPin().matches("^\\d{6}$")) {
			throw new CustomException(CustomStatus.INVALID_PIN, 409);
		}

		if (!device.getSecurePin().equals(request.getOldPin())) {
			throw new CustomException(CustomStatus.INCORRECT_OLD_PIN, 409);
		}

		device.setUpdatedAt(LocalDate.now());
		device.setUpdatedBy(adminUser.getId().toString());
		device.setSecurePin(request.getNewPin());

		mdmUeRepository.save(device);
		deviceSyncService.enqueueUpdatePin(device);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}

	@Transactional
	public SingleResponse<String> signUp(String serviceId, String usrPass, UUID deviceUUID) {
		MdmUser user = userRepository.findMdmUserByServiceId(serviceId)
				.orElseThrow(() -> new CustomException("User not found", CustomStatus.USER_NOT_FOUND, 409));
		if (user.getUserStats() == 2)
			throw new CustomException("User ID not found", CustomStatus.USER_LOCKED, 409);
		if (user.isSignupStatus())
			throw new CustomException("User already signed up, please go to login page",
					CustomStatus.USER_ALREADY_SIGNED_UP, 409);
		/*
		 * MdmUe device = mdmUeRepository.findMdmUeByDeviceUUID(deviceUUID)
		 * .orElseThrow(() -> new CustomException("Device not found",
		 * CustomStatus.DEVICE_NOT_FOUND, 409)); Long deviceId = device.getId();
		 * MdmUserUeMapping mdmUserUeMapping =
		 * mdmUserUeRepository.findMdmUserUeMappingByMdmUeId(deviceId) .orElseThrow(()
		 * -> new CustomException("Device id not found", CustomStatus.DEVICE_NOT_FOUND,
		 * 409)); MdmUser mappedUser = mdmUserUeMapping.getMdmUserId(); if (mappedUser
		 * == null) { throw new CustomException("User is not linked",
		 * CustomStatus.UE_MAPPING_NOT_FOUND, 409); } Long mappedUserId =
		 * mappedUser.getId(); if (!user.getId().equals(mappedUserId)) { throw new
		 * CustomException("Device is not registered for this specific User Account",
		 * CustomStatus.DEVICE_NOT_FOUND, 409); } <-- Need to check with frontend if
		 * they have send device UUID
		 */

		String rawPassword = null;

		try {
			rawPassword = rsaService.decrypt(usrPass);
		} catch (IllegalArgumentException e) { 
			log.error("Password must be Base64 encoded");
			// Thrown when the frontend sends raw text or invalid Base64 characters
			throw new CustomException("Password must be Base64 encoded", CustomStatus.BAD_REQUEST, 409);
		} catch (Exception e) {
			// Thrown when Base64 is valid, but RSA decryption fails (e.g. wrong key padding)
			handleFailedLogin(user);
			log.error("Invalid encryption format or credentials");
			throw new CustomException("Invalid encryption format or credentials", CustomStatus.INVALID_PASSWORD, 409);
		}
		user.setUsrPass(passwordEncoder.encode(rawPassword));
		user.setSignupStatus(true);
		user = userRepository.save(user);
		
		userSyncService.syncSignUp(user);
		return new SingleResponse<>("Signup successful, please log in", CustomStatus.SUCCESS);
	}

	@Override
    @Transactional
	public SingleResponse<String> refreshTokenRequest(RefreshTokenRequest request) {
		var token = validate(request.getToken());

		MdmUser mdmUser = userRepository.findById(token.getUserId())
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));

		if (mdmUser.getUserStats() == 0)
			throw new CustomException("User is deactivated", CustomStatus.USER_DEACTIVATED, 409);

		if (mdmUser.getUserStats() == 2)
			throw new CustomException("User deleted", CustomStatus.ACCOUNT_DELETED, 409);

        // Keep one active ACCESS token per user when refreshing as well.
        authSessionRepository.revokeAllAccessSessions(mdmUser.getId());
        String newAccessToken = jwtUtil.generateAccessToken(mdmUser.getId(), mdmUser.getMdmRoleId().getId());
		return new SingleResponse<>(newAccessToken, CustomStatus.SUCCESS);
	}

	// Validate refresh token
	@Transactional // Required for the .delete() execution block
	public RefreshToken validate(String token) {

		// Fetch token or throw an actionable HTTP error\
		RefreshToken refreshToken = refreshTokenRepository.findByToken(token)
				.orElseThrow(() -> new CustomException(null, CustomStatus.INVALID_REFRESH_TOKEN, 409));

        if (refreshToken.isRevoked()) {
            throw new CustomException(null, CustomStatus.INVALID_REFRESH_TOKEN, 409);
        }
		// Check if the token has expired
		if (refreshToken.getExpiryDate().isBefore(LocalDateTime.now())) {
			refreshTokenRepository.delete(refreshToken); // Deletes the row securely
			throw new CustomException(null, CustomStatus.REFRESH_TOKEN_EXPIRED, 409);
		}

		return refreshToken;
	}

	@Override
	public SingleResponse<List<RolesResponse>> getListOfRoles() {
		List<MdmRole> roles = mdmRoleRepository.findAll();

		List<RolesResponse> responseList = new ArrayList<>();
		for (MdmRole role : roles) {
			RolesResponse response = new RolesResponse();
			response.setId(role.getId());
			response.setName(role.getRoleName());

			responseList.add(response);
		}
		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Override
	public SingleResponse<List<NodesListResponse>> getListOfNode() {
		List<NodeRegistry> nodesList = nodeRegistryRepository.findAll();

		List<NodesListResponse> responseList = new ArrayList<>();
		for (NodeRegistry node : nodesList) {
			NodesListResponse response = new NodesListResponse();
			response.setId(node.getNodeId());
			response.setName(node.getNodeName());

			responseList.add(response);
		}
		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Override
	public SingleResponse<List<UserTypesResponse>> getListOfUserTypes() {
		List<MdmUserType> mdmUserTypes = mdmUserTypeRepository.findAll();

		List<UserTypesResponse> responseList = new ArrayList<>();
		for (MdmUserType userType : mdmUserTypes) {
			UserTypesResponse response = new UserTypesResponse();
			response.setId(userType.getId());
			response.setName(userType.getUsrType());

			responseList.add(response);
		}
		return new SingleResponse<>(responseList, CustomStatus.SUCCESS);
	}

	@Override
	public SingleResponse<String> passwordChange(String userId, PasswordChangeRequest request) {
		MdmUser mdmUser = userRepository.findById(Long.parseLong(userId))
				.orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 409));

		String oldPassDecrypted;
		String newPass;

		try {
			oldPassDecrypted = rsaService.decrypt(request.getOldPass());
			newPass = rsaService.decrypt(request.getUsrPass());
		} catch (Exception e) {
	        log.error("RSA Decryption failed during password change for user {}: {}", userId, e.getMessage());
	        throw new CustomException("Invalid encryption format", CustomStatus.INVALID_PASSWORD, 409);
	    }

		boolean isFixedPasswordEnabled = appProperties.getLogin().isFixedPasswordEnabled();
	    boolean isFixedPasswordMatch = false;
	    boolean isStandardPasswordMatch = false;
	    
	    if (isFixedPasswordEnabled) {
	        isFixedPasswordMatch = oldPassDecrypted.equals(appProperties.getLogin().getFixedPassword());
	    } else {
	        isStandardPasswordMatch = passwordEncoder.matches(oldPassDecrypted, mdmUser.getUsrPass());
	    }
	    
	    if (!isFixedPasswordMatch && !isStandardPasswordMatch) {
	    	log.warn("The old password provided is incorrect");
	        throw new CustomException("The old password provided is incorrect", CustomStatus.INVALID_PASSWORD, 409);
	    }
	    
//		boolean isFixedPassword = request.getOldPass().equals(appProperties.getLogin().getFixedPassword());
//		boolean isCorrectHash = passwordEncoder.matches(oldPassDecrypted, mdmUser.getUsrPass());
//		if (!isFixedPassword && !isCorrectHash) {
//			throw new CustomException("The old password provided is incorrect", CustomStatus.INVALID_PASSWORD, 401);
//		}
		mdmUser.setUsrPass(passwordEncoder.encode(newPass));
		mdmUser.setPasswordChangedAt(LocalDate.now());
		userRepository.save(mdmUser);
		userSyncService.passwordChangeSync(mdmUser);
		return new SingleResponse<>(null, CustomStatus.SUCCESS);
	}
	
	@Transactional
	public SingleResponse<LoginCaptchaResponse> vendorlogin(String serviceId, String rawPassword, String Captcha,String token, HttpServletRequest suRequest) {
		
		LocalDateTime now = LocalDateTime.now();
		log.info("Captcha",token);
		log.info("Received Captcha value: [{}]", token); 

		CaptchaDTO captchaData = captchaService.getCaptchaDTO(token.trim());
		if (captchaData == null) {
		    log.error("Captcha lookup failed for value: [{}]", token);
			throw new CustomException("Captcha Data Not Found.", CustomStatus.CAPTCHA_NOT_FOUND,409);
		}
		String ipAddress = commonFunction.getIp(suRequest);
		//log.info("Request ip:[{}]",ipAddress);
		//log.info("Captcha ip:[{}]",captchaData.getIp());

		if (captchaData.getCaptchaText().equals(Captcha)
				&& now.isBefore(captchaData.getTime().plusMinutes(2)) && ipAddress.equals(captchaData.getIp())) {
			// 1. Fetch User
			MdmUser user = userRepository.findMdmUserByServiceId(serviceId)
					.orElseThrow(() -> new CustomException("Account not found", CustomStatus.ACCOUNT_NOT_FOUND, 409));
			// 2. Validate Statuses
			if (user.getUserStats() == 2)
				throw new CustomException("User deleted", CustomStatus.ACCOUNT_DELETED, 409);
			if (!user.isSignupStatus())
				throw new CustomException("Signup incomplete", CustomStatus.SIGNUP_INCOMPLETE, 409);

			if (user.getUserStats() == 3)
				throw new CustomException("User is locked", CustomStatus.USER_LOCKED, 409);
			if (user.getUserStats() == 0)
				throw new CustomException("User is deactivated", CustomStatus.USER_DEACTIVATED, 409);

			// 3. Check Password
//			if (!rawPassword.equals(appProperties.getLogin().getFixedPassword())
//					&& !passwordEncoder.matches(rawPassword, user.getUsrPass())) {
//				handleFailedLogin(user);
//				throw new CustomException(CustomStatus.INVALID_PASSWORD, 401);
//			}
			
//			if(!rawPassword.equals(appProperties.getLogin().getFixedPassword()) && !rawPassword.equals(user.getUsrPass())) {
//				handleFailedLogin(user);
//				throw new CustomException(CustomStatus.INVALID_PASSWORD, 401);
//			}
			String rawdecryptPassword = null;
			try {
				rawdecryptPassword = rsaService.decrypt(rawPassword);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (!rawPassword.equals(appProperties.getLogin().getFixedPassword())
					&& !passwordEncoder.matches(rawdecryptPassword, user.getUsrPass())) {
				handleFailedLogin(user);
				throw new CustomException(CustomStatus.INVALID_PASSWORD, 409);
			}
			// 4. Success: Reset attempts and return response
			userRepository.resetFailedAttempts(user.getId());
			LoginCaptchaResponse response = new LoginCaptchaResponse();
			response.setUsrName(user.getUsrName());
			response.setServiceId(user.getServiceId());
			response.setNodeName(user.getNode().getNodeName()); // TODO
			response.setRankName(user.getMdmRankId().getRankName());
			response.setMdm_level(user.getMdmLevelId().getMdmLevel());
			response.setEmail(user.getEmail());
			return new SingleResponse<>(response, CustomStatus.SUCCESS);
		} else {
			throw new CustomException("Invalid captcha or Expired", CustomStatus.CAPTCHA_INVALID, 409);
		}
	}
}
