package org.bel.authService.repository;

import java.util.Optional;
import java.util.UUID;

import org.bel.authService.entity.SyncDeviceOutBox;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface SyncDeviceOutboxRepository extends JpaRepository<SyncDeviceOutBox, Long>{
	Optional<SyncDeviceOutBox> findByEventId(UUID eventId);

	@Query("SELECT s FROM SyncDeviceOutBox s WHERE s.eventType IN ('PIN_CHANGE', 'ADD_NEW_DEVICE', 'EDIT_DEVICE', 'BULK_DELETE_DEVICE', 'DELETE_DEVICE') AND s.status = 'PENDING' ORDER BY s.createdAt ASC")
	Page<SyncDeviceOutBox> findPendingDeviceEvents(Pageable pageable);

	@Query("SELECT COUNT(s) FROM SyncDeviceOutBox s WHERE s.eventType IN ('PIN_CHANGE', 'ADD_NEW_DEVICE', 'EDIT_DEVICE', 'BULK_DELETE_DEVICE', 'DELETE_DEVICE') AND s.status = 'PENDING'")
	long countPendingDeviceEvents();

	@Transactional
	@Modifying
	@Query("UPDATE SyncDeviceOutBox s SET s.status = :status, s.sentAt = :sentAt, s.lastError = :error WHERE s.eventId = :eventId")
	int updateStatus(@Param("eventId") UUID eventId, @Param("status") String status,
			@Param("sentAt") java.time.LocalDateTime sentAt, @Param("error") String error);
}
