package org.bel.authService.repository;
import org.bel.authService.entity.MdmUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

	@Repository
	public interface MdmUserRepository extends JpaRepository<MdmUser, Long> {

	    Optional<MdmUser> findMdmUserByServiceId(@Param("serviceId") String serviceId);

        @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("select u from MdmUser u where u.id = :id")
        Optional<MdmUser> findByIdForUpdate(@Param("id") Long id);

	    @Modifying
	    @Query("UPDATE MdmUser u SET u.failedLoginCount = :count, u.userStats = :stats WHERE u.id = :id")
	    void updateFailedAttempts(@Param("id") Long id, @Param("count") Integer count, @Param("stats") Integer stats);

	    @Modifying
	    @Query("UPDATE MdmUser u SET u.failedLoginCount = 0 WHERE u.id = :id")
	    void resetFailedAttempts(@Param("id") Long id);
	    
	    List<MdmUser> findByUserStats(Integer userStats);
	    
	    List<MdmUser> findByUserStatsOrderByServiceIdAsc(Integer userStats);
	    
	    List<MdmUser> findAllByOrderByIdAsc();

		List<MdmUser> findAllByOrderByServiceIdAsc();

		Optional<MdmUser> findMdmUserByUsrPass(String usrPass);
	}
