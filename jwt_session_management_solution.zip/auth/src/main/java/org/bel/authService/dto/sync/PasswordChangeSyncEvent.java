package org.bel.authService.dto.sync;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public record PasswordChangeSyncEvent(
		UUID eventId, 
		String sourceNodeId,
		Long sourceUserId,
		String userPass,
		LocalDate passwordChagnedAt,
        LocalDateTime updatedAt
		){}
