package org.bel.authService.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.bel.authService.constants.AppConstants;
import org.bel.authService.dto.sync.AddNewDeviceSyncEvent;
import org.bel.authService.dto.sync.DeleteBulkDeviceEvent;
import org.bel.authService.dto.sync.DeleteDeviceSyncEvent;
import org.bel.authService.dto.sync.EditDeviceSyncEvent;
import org.bel.authService.dto.sync.UpdatePinSyncEvent;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.entity.MdmDeviceType;
import org.bel.authService.entity.MdmUe;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.MdmUserUeMapping;
import org.bel.authService.entity.NodeRegistry;
import org.bel.authService.entity.SyncDeviceOutBox;
import org.bel.authService.entity.SyncOutboxDelivery;
import org.bel.authService.repository.MdmDeviceTypeRepository;
import org.bel.authService.repository.MdmUeRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.MdmUserUeMappingRepository;
import org.bel.authService.repository.NodeRegistryRepository;
import org.bel.authService.repository.SyncDeviceOutboxRepository;
import org.bel.authService.repository.SyncOutboxDeliveryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.bel.authService.exception.*;
import org.bel.authService.enums.*;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class DeviceSyncService {
	
	private final ObjectMapper objectMapper;
	private final SyncDeviceOutboxRepository deviceOutboxRepository;
	private final MdmUeRepository mdmUeRepository;
	private final NodeRegistryRepository nodeRegistryRepository;
	private final CurrentNodeResolver currentNodeResolver;
	private final SyncOutboxDeliveryRepository deliveryRepository;
	private final MdmUserRepository userRepository;
	private final MdmUserUeMappingRepository mdmUserUeMappingRepository;
	private final MdmDeviceTypeRepository mdmDeviceTypeRepository;

		// ==========================================
		// UPDATE USER'S PIN EVENT
		// ==========================================
		@Transactional
		public void enqueueUpdatePin(MdmUe device) {
			String localNodeId = currentNodeResolver.getCurrentNodeId();
			List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
			UUID eventId = UUID.randomUUID();
			UpdatePinSyncEvent event = updatePinEvent(device, eventId, localNodeId);
			final String payload;
			try {
				payload = objectMapper.writeValueAsString(event);
			} catch (Exception ex) {
				log.error("DEBUG: Unable to serialize PIN_CHANGE sync event");
				throw new IllegalStateException("Unable to serialize PIN_CHANGE sync event", ex);
			}

			LocalDateTime now = LocalDateTime.now();

			SyncDeviceOutBox deviceOutbox = SyncDeviceOutBox.builder()
					.eventId(eventId)
					.eventType(AppConstants.PIN_CHANGE)
					.entityType(AppConstants.DEVICE)
					.deviceId(device.getId())
					.sourceNodeId(localNodeId)
					.payload(payload)
					.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
					.retryCount(0)
					.createdAt(now)
					.sentAt(peers.isEmpty() ? now : null)
					.build();
			deviceOutboxRepository.save(deviceOutbox);

			for (NodeRegistry peer : peers) {
				boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
				deliveryRepository.save(SyncOutboxDelivery.builder()
						.eventId(eventId)
						.targetNodeId(peer.getNodeId())
						.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
						.retryCount(0)
						.createdAt(now)
						.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
						.build());
			}
		}

		/**
		 * Idempotent receiver: serviceId is the cross-node business key, not local
		 * numeric id.
		 */
		@Transactional
		public UserSyncAck receiveUpdatedPin(UpdatePinSyncEvent event, String receivingNodeId) {
			if (event == null || event.eventId() == null || event.deviceId() == null) {
				log.warn("DEBUG: EventId and DeviceId are required");
				throw new IllegalArgumentException("EventId and DeviceId are required");
			}
			Optional<MdmUe> optionalDevice = mdmUeRepository.findById(event.deviceId());
			if (optionalDevice.isEmpty()) {
				log.warn("DEBUG: Device not found. Cannot apply pin change until device is created.");
				throw new IllegalStateException("Device not found. Cannot apply pin change until device is created.");
			}

			MdmUe device = optionalDevice.get();

			if (event.newPin() != null && !event.newPin().trim().isEmpty()) {
				device.setSecurePin(event.newPin());
			}
			MdmUser updater = userRepository.findById(Long.parseLong(event.updatedBy()))
			.orElseThrow(() -> {
				log.warn("DEBUG: Updated by user details not found ");
				return new IllegalStateException("Updated by user details not found ");
			});
			
			if (event.updatedBy() != null && !event.updatedBy().trim().isEmpty()) {
				device.setUpdatedBy(updater.getId().toString());
			}

			if (event.updatedAt() != null) {
				device.setUpdatedAt(event.updatedAt());
			}
			
			mdmUeRepository.saveAndFlush(device);
			return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "Pin Updated");
		}

		public UpdatePinSyncEvent parseUpdatePinPayload(String payload) {
			try {
				return objectMapper.readValue(payload, UpdatePinSyncEvent.class);
			} catch (Exception ex) {
				log.error("DEBUG: Invalid PIN_UPDATE payload");
				throw new IllegalStateException("Invalid PIN_UPDATE payload", ex);
			}
		}

		private UpdatePinSyncEvent updatePinEvent(MdmUe ue, UUID eventId, String localNodeId) {
			return new UpdatePinSyncEvent(
					eventId, 
					localNodeId, 
					ue.getId(), 
					ue.getUpdatedBy(), 
					ue.getUpdatedAt(),
					ue.getSecurePin());
		}


		// ==========================================
		// ADD NEW DEVICE EVENT
		// ==========================================
		@Transactional
		public void addNewDeviceSync(MdmUe newDevice, Long userId) {
			String localNodeId = currentNodeResolver.getCurrentNodeId();
			List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
			UUID eventId = UUID.randomUUID();
			AddNewDeviceSyncEvent event = addNewDeviceEvent(newDevice, eventId, localNodeId, userId);
			final String payload;
			try {
				payload = objectMapper.writeValueAsString(event);
			} catch (Exception ex) {
				log.error("DEBUG: Unable to serialize ADD_NEW_DEVICE sync event");
				throw new IllegalStateException("Unable to serialize ADD_NEW_DEVICE sync event", ex);
			}

			LocalDateTime now = LocalDateTime.now();

			SyncDeviceOutBox deviceOutbox = SyncDeviceOutBox.builder()
					.eventId(eventId)
					.eventType(AppConstants.ADD_NEW_DEVICE)
					.entityType(AppConstants.DEVICE)
					.deviceId(newDevice.getId())
					.sourceNodeId(localNodeId)
					.payload(payload)
					.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
					.retryCount(0)
					.createdAt(now)
					.sentAt(peers.isEmpty() ? now : null)
					.build();
			deviceOutboxRepository.save(deviceOutbox);

			for (NodeRegistry peer : peers) {
				boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
				deliveryRepository.save(SyncOutboxDelivery.builder()
						.eventId(eventId)
						.targetNodeId(peer.getNodeId())
						.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
						.retryCount(0)
						.createdAt(now)
						.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
						.build());
			}
			
		}
		
		/**
		 * Idempotent receiver: serviceId is the cross-node business key, not local
		 * numeric id.
		 */
		@Transactional
		public UserSyncAck receiveAddNewDevice(AddNewDeviceSyncEvent event, String receivingNodeId) {
			if (event == null || event.eventId() == null || event.deviceId() == null || event.userId() == null || event.status() == null || (event.securePin() == null || event.securePin().isEmpty())) {
				log.warn("DEBUG: EventId, DeviceId,User id and Status are required");
				throw new IllegalArgumentException("EventId, DeviceId and User id are required");
			}
			
//			if(event.mdmOsTypeId() == null || (event.deviceType() == null ||event.deviceType().isEmpty())) {
//				throw new IllegalArgumentException("Device Type and OS type id is required");
//			} UNCOMMENT THIS IF REQUIRED
			
			if (mdmUeRepository.findById(event.id()).isPresent()) {
				return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId,
						"Device already exists; duplicate event safely ignored");
			}
			
			Optional<MdmDeviceType> optionalMdmDeviceType = mdmDeviceTypeRepository.findById(event.mdmDeviceTypeId());
			
			MdmUe newDevice = new MdmUe();
			newDevice.setId(event.id());
			newDevice.setDeviceId(event.deviceId());
			newDevice.setDeviceName(event.deviceName());
			newDevice.setManufactureName(event.manufactureName().isEmpty() ? null : event.manufactureName());
			newDevice.setContactNo(event.contactNo().isEmpty() ? null : event.contactNo());
			newDevice.setCreatedAt(event.createdAt() == null ? null : event.createdAt());
			newDevice.setUpdatedAt(event.updatedAt() == null ? null : event.updatedAt());
			newDevice.setCreatedBy(event.createdBy() == null ? null : event.createdBy());
			newDevice.setUpdatedBy(event.updatedBy() == null ? null : event.updatedBy());
			newDevice.setDeviceType(event.deviceType() == null ? null : event.deviceType());
			newDevice.setImeiNumber(event.imeiNumber() == null ? null : event.imeiNumber());
			newDevice.setSimNumber(event.simNumber() == null ? null : event.simNumber());
			newDevice.setDeviceUUID(event.deviceUUID() == null ? null : event.deviceUUID());
			newDevice.setMdmDeviceType(event.mdmDeviceTypeId() == null ? null : optionalMdmDeviceType.get());
			newDevice.setStatus(event.status());
			newDevice.setFailedLoginCount(event.failedLoginCount() == null ? null : 0);
			newDevice.setSecurePin(event.securePin());
			mdmUeRepository.save(newDevice);
			
			MdmUserUeMapping mdmUserUeMapping = new MdmUserUeMapping();
			MdmUser user = userRepository.findById(event.userId())
					.orElseThrow(() -> new IllegalStateException("MdmUser not found"));
			mdmUserUeMapping.setMdmUserId(user);
			mdmUserUeMapping.setMdmUeId(newDevice);
			mdmUserUeMapping.setActive(event.status() == 1 ? true : false);
			
			mdmUserUeMappingRepository.save(mdmUserUeMapping);

			return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "New Device Added");
		}

		public AddNewDeviceSyncEvent parseAddNewDevicePayload(String payload) {
			try {
				return objectMapper.readValue(payload, AddNewDeviceSyncEvent.class);
			} catch (Exception ex) {
				log.error("DEBUG: Invalid ADD_NEW_DEVICE payload");
				throw new IllegalStateException("Invalid ADD_NEW_DEVICE payload", ex);
			}
		}

		private AddNewDeviceSyncEvent addNewDeviceEvent(MdmUe ue, UUID eventId, String localNodeId, Long userId) {
			return new AddNewDeviceSyncEvent(
					eventId, 
					localNodeId, 
					ue.getId(),
					ue.getDeviceId(),
					ue.getDeviceName(),
					ue.getManufactureName(),
					ue.getContactNo(),
					ue.getCreatedAt(),
					ue.getUpdatedAt(),
					ue.getCreatedBy(),
					ue.getUpdatedBy(),
					ue.getDeviceType(),
					ue.getImeiNumber(),
					ue.getSimNumber(),
					ue.getDeviceUUID(),
					2,
					ue.getStatus(),
					ue.getMdmDeviceType().getId(),
					ue.getFailedLoginCount(),
					ue.getSecurePin(),
					userId);
		}


		// ==========================================
		// EDIT DEVICE EVENT
		// ==========================================
		@Transactional
		public void editDeviceSync(MdmUe device, MdmUser user) {
			log.info("Edit device sync is called");
			String localNodeId = currentNodeResolver.getCurrentNodeId();
			List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
			UUID eventId = UUID.randomUUID();
			EditDeviceSyncEvent event = editDeviceEvent(device, eventId, localNodeId, user);
			final String payload;
			try {
				payload = objectMapper.writeValueAsString(event);
			} catch (Exception ex) {
				log.error("DEBUG: Unable to serialize EDIT_DEVICE sync event");
				throw new IllegalStateException("Unable to serialize EDIT_DEVICE sync event", ex);
			}

			LocalDateTime now = LocalDateTime.now();

			SyncDeviceOutBox deviceOutbox = SyncDeviceOutBox.builder()
					.eventId(eventId)
					.eventType(AppConstants.EDIT_DEVICE)
					.entityType(AppConstants.DEVICE)
					.deviceId(device.getId())
					.sourceNodeId(localNodeId)
					.payload(payload)
					.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
					.retryCount(0)
					.createdAt(now)
					.sentAt(peers.isEmpty() ? now : null)
					.build();
			deviceOutboxRepository.save(deviceOutbox);

			for (NodeRegistry peer : peers) {
				boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
				deliveryRepository.save(SyncOutboxDelivery.builder()
						.eventId(eventId)
						.targetNodeId(peer.getNodeId())
						.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
						.retryCount(0)
						.createdAt(now)
						.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
						.build());
			}
			
		}
		
		@Transactional
		public UserSyncAck receiveEditDevice(EditDeviceSyncEvent event, String receivingNodeId) {
			if (event == null || event.eventId() == null || event.deviceId() == null ) {
				log.warn("DEBUG: EventId, DeviceId,User id and Status are required");
				throw new IllegalArgumentException("EventId, DeviceId and User id are required");
			}
			
			Optional<MdmUe> optionalDevice = mdmUeRepository.findById(event.id());
			if (optionalDevice.isEmpty()) {
				log.error("DEBUG: Device not found. Cannot apply edit until Device is created.");
				throw new IllegalStateException("Device not found. Cannot apply edit until Device is created.");
			}
			
			MdmUe mdmUe = optionalDevice.get();
//			Optional<MdmUe> existingDevice = mdmUeRepository.findMdmUeByDeviceId(event.deviceId());
//			if (existingDevice.isPresent()) {
//				throw new IllegalStateException("Device Id '" + event.deviceId() + "' already exists");
//			}
//			
			if (event.deviceId() != null) {
			    Optional<MdmUe> existingDeviceWithNewId = mdmUeRepository.findMdmUeByDeviceId(event.deviceId());
			    if (existingDeviceWithNewId.isPresent() && !existingDeviceWithNewId.get().getId().equals(mdmUe.getId())) { // <-- 2nd condition current record
			        throw new IllegalStateException("Device Id '" + event.deviceId() + "' already exists on another record.");
			    }
			}
			
			if (event.status() == 1) {
				mdmUe.setFailedLoginCount(0);
			}
			if (event.deviceId() != null) {
				mdmUe.setDeviceId(event.deviceId());
			}
			if (event.deviceName() != null) {
				mdmUe.setDeviceName(event.deviceName());
			}
			if (event.contactNo() != null) {
				mdmUe.setContactNo(event.contactNo());
			}
			if (event.mdmDeviceTypeId() != null) {
				MdmDeviceType mdmDeviceType = mdmDeviceTypeRepository.findById(event.mdmDeviceTypeId())
						.orElseThrow(() -> new IllegalStateException("Device Type Id '" + event.mdmDeviceTypeId() + "' not found"));
				mdmUe.setMdmDeviceType(mdmDeviceType);

			}
			if (event.securePin() != null) {
				mdmUe.setSecurePin(event.securePin());
			}
			mdmUeRepository.save(mdmUe);
			if (event.mdmUserId() != null) {
				MdmUserUeMapping mdmUserUeMapping = mdmUserUeMappingRepository
						.findMdmUserUeMappingByMdmUserId(event.mdmUserId())
						.orElseThrow(() -> new IllegalStateException("Mdm User Ue Mapping '" + event.mdmUserId() + "' not found"));
				if (mdmUserUeMapping != null) {
					MdmUser mdmUser = userRepository.findById(event.mdmUserId())
							.orElseThrow(() -> new IllegalStateException("User '" + event.mdmUserId() + "' not found"));
					mdmUserUeMapping.setMdmUserId(mdmUser);
					mdmUserUeMapping.setMdmUeId(mdmUe);
					mdmUserUeMappingRepository.save(mdmUserUeMapping);
				} else {
					MdmUserUeMapping newMdmUserUeMapping = new MdmUserUeMapping();
					MdmUser mdmUser = userRepository.findById(event.mdmUserId())
							.orElseThrow(() -> new IllegalStateException("User '" + event.mdmUserId() + "' not found"));
					newMdmUserUeMapping.setMdmUeId(mdmUe);
					newMdmUserUeMapping.setMdmUserId(mdmUser);
					mdmUserUeMappingRepository.save(newMdmUserUeMapping);
				}
			}

			return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "Edit Device Success");
		}

		public EditDeviceSyncEvent parseEditDevicePayload(String payload) {
			try {
				return objectMapper.readValue(payload, EditDeviceSyncEvent.class);
			} catch (Exception ex) {
				log.error("DEBUG: Invalid EDIT_DEVICE payload");
				throw new IllegalStateException("Invalid EDIT_DEVICE payload", ex);
			}
		}

		private EditDeviceSyncEvent editDeviceEvent(MdmUe ue, UUID eventId, String localNodeId, MdmUser user) {
			log.info("Edit device event is called");
			return new EditDeviceSyncEvent(
					eventId, 
					localNodeId, 
					ue.getId(),
					ue.getDeviceId(),
					ue.getDeviceName(),
					ue.getContactNo(),
					ue.getMdmDeviceType().getId(),
					user == null ? null : user.getId(),
					ue.getSecurePin(),
					ue.getFailedLoginCount(),
					ue.getStatus()
					);
		}

		// ==========================================
		// DELETE BULK DEVICE EVENT
		// ==========================================
		private int count = 0;
		@Transactional
		public void deleteDevicesBulkSync(List<MdmUe> devices) {
			log.info("count: {}", count++);
			String localNodeId = currentNodeResolver.getCurrentNodeId();
			List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
			UUID eventId = UUID.randomUUID();
			DeleteBulkDeviceEvent event = deleteBulkDeviceEvent(devices, eventId, localNodeId);
			final String payload;
			try {
				payload = objectMapper.writeValueAsString(event);
			} catch (Exception ex) {
				log.error("DEBUG: Unable to serialize BULK_DELETE_DEVICE sync event");
				throw new IllegalStateException("Unable to serialize BULK_DELETE_DEVICE sync event", ex);
			}

			LocalDateTime now = LocalDateTime.now();

			SyncDeviceOutBox deviceOutbox = SyncDeviceOutBox.builder()
					.eventId(eventId)
					.eventType(AppConstants.BULK_DELETE_DEVICE)
					.entityType(AppConstants.DEVICE)
					.sourceNodeId(localNodeId)
					.deviceId(devices.get(0).getId())
					.payload(payload)
					.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
					.retryCount(0)
					.createdAt(now)
					.sentAt(peers.isEmpty() ? now : null)
					.build();
			deviceOutboxRepository.save(deviceOutbox);

			for (NodeRegistry peer : peers) {
				boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
				deliveryRepository.save(SyncOutboxDelivery.builder()
						.eventId(eventId)
						.targetNodeId(peer.getNodeId())
						.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
						.retryCount(0)
						.createdAt(now)
						.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
						.build());
			}
		}
		
		@Transactional
		public UserSyncAck receiveBulkDeleteDevice(DeleteBulkDeviceEvent event, String receivingNodeId) {
			if (event == null || event.eventId() == null || event.deviceIds() == null) {
		        log.warn("DEBUG: Bulk Delete event or DeviceIds are null/empty. EventId: {}, DeviceIds: {}", 
		                  event != null ? event.eventId() : "NULL", 
		                  event != null ? event.deviceIds() : "NULL");
		        throw new IllegalArgumentException("Bulk Delete event or DeviceIds are required");
		    }

		    log.info("DEBUG: Processing bulk delete for {} devices. EventId: {}", event.deviceIds().size(), event.eventId());

		    for (Long id : event.deviceIds()) {
		        
		        // Find the device. If it's already gone, we just log and continue (Idempotency)
		        Optional<MdmUe> deviceOptional = mdmUeRepository.findById(id);
		        
		        if (deviceOptional.isPresent()) {
		            MdmUe device = deviceOptional.get();
		            
		            // Check if there is a mapping (to decide between Soft Delete or Hard Delete)
		            Optional<MdmUserUeMapping> mappingOptional = mdmUserUeMappingRepository.findMdmUserUeMappingByMdmUeId(id);
		            
		            if (mappingOptional.isPresent()) {
		                // SOFT DELETE: Set status to 2 (Mapping exists)
		                device.setStatus(2);
		                mdmUeRepository.save(device);
		                log.debug("DEBUG: Soft deleted device ID: {}", id);
		            } else {
		                // HARD DELETE (No mapping exists)
		                mdmUeRepository.deleteById(id);
		                log.debug("DEBUG: Hard deleted device ID: {}", id);
		            }
		        } else {
		            // If the device doesn't exist on this node, we don't throw an error.
		            // This makes the operation "Idempotent" (safe to call multiple times).
		            log.warn("DEBUG: Device ID {} not found on this node, skipping...", id);
		        }
		    }

		    return new UserSyncAck(
		        event.eventId(), 
		        AppConstants.ACKNOWLEDGED, 
		        receivingNodeId, 
		        "Bulk Delete Device Success"
		    );
		}

		public DeleteBulkDeviceEvent parseBulkDeleteDevicePayload(String payload) {
			try {
				return objectMapper.readValue(payload, DeleteBulkDeviceEvent.class);
			} catch (Exception ex) {
				log.error("DEBUG: Invalid BULK_DELETE_DEVICE payload");
				throw new IllegalStateException("Invalid BULK_DELETE_DEVICE payload", ex);
			}
		}

		private DeleteBulkDeviceEvent deleteBulkDeviceEvent(List<MdmUe> devices, UUID eventId, String localNodeId) {
			List<Long> deviceIds = devices.stream()
                    .map(MdmUe::getId)
                    .collect(Collectors.toList());

			return new DeleteBulkDeviceEvent(
					eventId, 
					localNodeId, 
					deviceIds
					);
		}


		// ==========================================
		// DELETE DEVICE EVENT
		// ==========================================
		@Transactional
		public void deleteDeviceSync(Long deviceId) {
			String localNodeId = currentNodeResolver.getCurrentNodeId();
			List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
			UUID eventId = UUID.randomUUID();
			DeleteDeviceSyncEvent event = deleteDeviceEvent(deviceId, eventId, localNodeId);
			final String payload;
			try {
				payload = objectMapper.writeValueAsString(event);
			} catch (Exception ex) {
				log.error("DEBUG: Unable to serialize DELETE_DEVICE sync event");
				throw new IllegalStateException("Unable to serialize DELETE_DEVICE sync event", ex);
			}

			LocalDateTime now = LocalDateTime.now();

			SyncDeviceOutBox deviceOutbox = SyncDeviceOutBox.builder()
					.eventId(eventId)
					.eventType(AppConstants.DELETE_DEVICE)
					.entityType(AppConstants.DEVICE)
					.deviceId(deviceId)
					.sourceNodeId(localNodeId)
					.payload(payload)
					.status(peers.isEmpty() ? AppConstants.ACKNOWLEDGED : AppConstants.PENDING)
					.retryCount(0)
					.createdAt(now)
					.sentAt(peers.isEmpty() ? now : null)
					.build();
			deviceOutboxRepository.save(deviceOutbox);

			for (NodeRegistry peer : peers) {
				boolean active = AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus());
				deliveryRepository.save(SyncOutboxDelivery.builder()
						.eventId(eventId)
						.targetNodeId(peer.getNodeId())
						.status(active ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
						.retryCount(0)
						.createdAt(now)
						.lastError(active ? null : AppConstants.TARGET_NODE_IS_INACTIVE_AT_EVENT_CREATION)
						.build());
			}
			
		}
		
		@Transactional
		public UserSyncAck receiveDeleteDevice(DeleteDeviceSyncEvent event, String receivingNodeId) {
			if (event == null || event.eventId() == null || event.deviceId() == null ) {
				log.warn("DEBUG: EventId and DeviceId are required");
				throw new IllegalArgumentException("EventId and DeviceId are required");
			}
			
			Optional<MdmUe> optionalDevice = mdmUeRepository.findById(event.deviceId());
			if (optionalDevice.isEmpty()) {
				log.error("DEBUG: Device not found. Cannot apply delete until Device is created.");
				throw new IllegalStateException("Device not found. Cannot apply delete until Device is created.");
			}
			Long deviceId =  event.deviceId();
			MdmUe device = mdmUeRepository.findById(deviceId)
			.orElseThrow(() -> new IllegalStateException("Device not found"));
			
			// mdmUeRepository.deleteById(deviceId);
			if(device.getStatus() == 2){
				throw new CustomException(CustomStatus.DEVICE_ALREADY_DELETED, 409);
			}
			device.setStatus(2);
			mdmUeRepository.save(device);
			
			return new UserSyncAck(event.eventId(), AppConstants.ACKNOWLEDGED, receivingNodeId, "Edit Device Success");
		}

		public DeleteDeviceSyncEvent parseDeleteDevicePayload(String payload) {
			try {
				return objectMapper.readValue(payload, DeleteDeviceSyncEvent.class);
			} catch (Exception ex) {
				log.error("DEBUG: Invalid DELETE_DEVICE payload");
				throw new IllegalStateException("Invalid DELETE_DEVICE payload", ex);
			}
		}

		private DeleteDeviceSyncEvent deleteDeviceEvent(Long deviceId, UUID eventId, String localNodeId) {
			return new DeleteDeviceSyncEvent(
					eventId, 
					localNodeId, 
					deviceId
					);
		}
}
