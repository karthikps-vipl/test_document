package org.bel.authService.dto.responseDto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddDeviceResponse {
	private Long id;
	private LocalDate createdAt;
	private Integer failedLoginCount;
	private String deviceId;
	private String deviceName;
	private String manufactureName;
	private Integer status;
	private String contactNo;
	private Integer mdmDeviceTypeId;
	private String securePin;
	private LocalDate updatedAt;
	private String createdBy;
	private String updatedBy;
	private String deviceType;
	private String imeiNumber;
	private String simNumber;
	private Integer mdmOsTypeId;
}
