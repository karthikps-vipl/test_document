package org.bel.authService.dto.sync;

import java.util.UUID;

public record SignUpSyncEvent(
		UUID eventId, 
		String sourceNodeId,
		Long sourceUserId,
		String userPass,
		boolean signUpStatus
		) {

}
