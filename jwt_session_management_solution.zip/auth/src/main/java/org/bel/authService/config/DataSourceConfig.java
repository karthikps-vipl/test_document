//package org.bel.authService.config;
//
//import javax.sql.DataSource;
//
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.boot.jdbc.DataSourceBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import com.zaxxer.hikari.HikariDataSource;
//
//import org.springframework.beans.factory.annotation.Value;
//
//@Configuration
//public class DataSourceConfig {
//    @Value("${spring.datasource.url}")
//    private String mainUrl;
//
//    @Value("${spring.datasource.username}")
//    private String mainUsername;
//
//    @Value("${spring.datasource.password}")
//    private String mainPassword;
//
//    @Value("${admin.datasource.url}")
//    private String adminUrl;
//
//    @Value("${admin.datasource.username}")
//    private String adminUsername;
//
//    @Value("${admin.datasource.password}")
//    private String adminPassword;
//
//    @Bean
//    @Primary
//    public DataSource mainDataSource() {
//        HikariDataSource dataSource = new HikariDataSource();
//        dataSource.setJdbcUrl(mainUrl);
//        dataSource.setUsername(mainUsername);
//        dataSource.setPassword(mainPassword);
//        dataSource.setDriverClassName("org.postgresql.Driver"); 
//        return dataSource;
//    }
//
//    @Bean(name = "adminDataSource")
//    public DataSource adminDataSource() {
//        HikariDataSource dataSource = new HikariDataSource();
//        dataSource.setJdbcUrl(adminUrl);
//        dataSource.setUsername(adminUsername);
//        dataSource.setPassword(adminPassword);
//        dataSource.setDriverClassName("org.postgresql.Driver");
//        return dataSource;
//    }
//
//    @Bean
//    @Primary
//    public JdbcTemplate jdbcTemplate(@Qualifier("mainDataSource") DataSource ds) {
//        return new JdbcTemplate(ds);
//    }
//
//    @Bean(name = "adminJdbcTemplate")
//    public JdbcTemplate adminJdbcTemplate(@Qualifier("adminDataSource") DataSource ds) {
//        return new JdbcTemplate(ds);
//    }
//}
