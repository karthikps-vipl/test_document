package org.bel.authService.config;

import java.util.Properties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;
import lombok.AllArgsConstructor;

@Configuration
@AllArgsConstructor
public class AppConfig {

	@Bean
	DefaultKaptcha captchaProducer() {
		DefaultKaptcha kaptcha = new DefaultKaptcha();
		Properties props = new Properties();
		props.put("kaptcha.border", "no");
		props.put("kaptcha.textproducer.font.color", "black");
		props.put("kaptcha.textproducer.char.space", "4");
		props.put("kaptcha.image.width", "180");
		props.put("kaptcha.image.height", "40");
		props.put("kaptcha.textproducer.font.size", "30");
		props.put("kaptcha.textproducer.char.length", "5");

		Config config = new Config(props);
		kaptcha.setConfig(config);
		return kaptcha;
	}

}
