package org.bel.authService.controller;

import org.bel.authService.dto.requestDto.DropDatabasePinValidateWipeRequest;
import org.bel.authService.dto.responseDto.SingleResponse;
import org.bel.authService.service.DatabaseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/database")
@AllArgsConstructor
public class DatabaseController {
	private final DatabaseService databaseService;
	@DeleteMapping("/dropDatabase")
	public ResponseEntity<SingleResponse<String>> dropDatabase() {
		SingleResponse<String> response = databaseService.dropDatabase();
		return ResponseEntity.ok(response);
	}
	
	@DeleteMapping("/dropDatabase/pinValidateWipe/{deviceId}")
	public ResponseEntity<SingleResponse<String>> dropDatabasePinValidateWipe(@RequestBody DropDatabasePinValidateWipeRequest request,
			@PathVariable Long deviceId,
			@RequestHeader("X-User-Id") String userId) {
		SingleResponse<String> response = databaseService.dropDatabasePinValidateWipe(request, deviceId, userId);
		return ResponseEntity.ok(response);
	}
}
