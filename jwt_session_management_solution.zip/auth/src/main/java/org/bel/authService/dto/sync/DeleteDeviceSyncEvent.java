package org.bel.authService.dto.sync;

import java.util.UUID;

public record DeleteDeviceSyncEvent(
		UUID eventId,
        String sourceNodeId,
		Long deviceId) {}
