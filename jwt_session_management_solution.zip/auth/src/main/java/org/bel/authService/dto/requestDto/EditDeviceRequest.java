package org.bel.authService.dto.requestDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EditDeviceRequest {
	private String deviceId;
	private String deviceName;
	private String contactNo;
	private Integer mdmDeviceTypeId;
	private Long mdmUserId;
	private String securePin;
}
