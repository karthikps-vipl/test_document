package org.bel.authService.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bel.authService.entity.AuthSession;
import org.bel.authService.entity.MdmUser;
import org.bel.authService.entity.RefreshToken;
import org.bel.authService.enums.CustomStatus;
import org.bel.authService.exception.CustomException;
import org.bel.authService.repository.AuthSessionRepository;
import org.bel.authService.repository.MdmUserRepository;
import org.bel.authService.repository.RefreshTokenRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtUtil {
    private final RefreshTokenRepository refreshTokenRepository;
    private final MdmUserRepository mdmUserRepository;
    private final AuthSessionRepository authSessionRepository;

    @Value("${jwt.secret}") private String secret;
    @Value("${jwt.token-expiry-time}") private Long jwtExpiration;
    @Value("${jwt.pre-auth-expiry-time:300000}") private Long preAuthExpiration;
    @Value("${jwt.refresh-token-time}") private Long refreshExpiration;

    public String generatePreAuthToken(Long userId, Integer roleId) {
        return generateSessionToken(userId, roleId, "PRE_AUTH", preAuthExpiration);
    }

    public String generateAccessToken(Long userId, Integer roleId) {
        return generateSessionToken(userId, roleId, "ACCESS", jwtExpiration);
    }

    private String generateSessionToken(Long userId, Integer roleId, String tokenType, Long expiryMillis) {
        String jti = UUID.randomUUID().toString();
        Date issuedAt = new Date();
        Date expiryDate = new Date(System.currentTimeMillis() + expiryMillis);
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", roleId.toString());
        claims.put("token_type", tokenType);
        String jwt = Jwts.builder().setClaims(claims).setId(jti)
            .setSubject(userId.toString()).setIssuedAt(issuedAt).setExpiration(expiryDate)
            .signWith(getSignKey(), SignatureAlgorithm.HS256).compact();
        AuthSession session = new AuthSession();
        session.setUserId(userId); session.setJti(jti); session.setTokenType(tokenType);
        session.setExpiresAt(LocalDateTime.ofInstant(expiryDate.toInstant(), ZoneOffset.UTC));
        authSessionRepository.save(session);
        return jwt;
    }

    /** Kept for source compatibility; new code should explicitly choose PRE_AUTH or ACCESS. */
    @Deprecated
    public String generateToken(Long userId, Integer roleId) {
        return generateAccessToken(userId, roleId);
    }

    public String generateRefreshToken(Long userId) {
        MdmUser user = mdmUserRepository.findById(userId)
            .orElseThrow(() -> new CustomException(CustomStatus.USER_NOT_FOUND, 404));
        RefreshToken token = new RefreshToken();
        token.setToken(UUID.randomUUID().toString()); token.setUserId(user.getId());
        token.setExpiryDate(LocalDateTime.now().plusSeconds(refreshExpiration));
        token.setRevoked(false);
        refreshTokenRepository.save(token);
        return token.getToken();
    }

    public Claims getClaims(String token) {
        return Jwts.parserBuilder().setSigningKey(getSignKey()).build().parseClaimsJws(token).getBody();
    }

    private Key getSignKey() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(secret));
    }
}
