package org.bel.authService.dto.sync;

import java.time.LocalDate;
import java.util.UUID;

public record AddNewDeviceSyncEvent(
		UUID eventId,
        String sourceNodeId,
        Long id,
    	String deviceId,
    	String deviceName,
    	String manufactureName,
    	String contactNo,
        LocalDate createdAt,
    	LocalDate updatedAt,
    	String createdBy,
    	String updatedBy,
    	String deviceType,
    	String imeiNumber,
    	String simNumber,
    	UUID deviceUUID,
    	Integer mdmOsTypeId,
    	Integer status,
    	Integer mdmDeviceTypeId,
    	Integer failedLoginCount,
    	String securePin,
    	Long userId
		) {

}
