package org.bel.authService.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import org.bel.authService.constants.AppConstants;
import org.bel.authService.dto.sync.UserSyncAck;
import org.bel.authService.entity.NodeRegistry;
import org.bel.authService.entity.SyncOutboxDelivery;
import org.bel.authService.entity.SyncUserOutbox;
import org.bel.authService.repository.NodeRegistryRepository;
import org.bel.authService.repository.SyncOutboxDeliveryRepository;
import org.bel.authService.repository.SyncUserOutboxRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserSyncOutboxWorker {

//	private final SyncOutboxRepository outboxRepository;
	private final SyncUserOutboxRepository userOutboxRepository;
	private final SyncOutboxDeliveryRepository deliveryRepository;
	private final NodeRegistryRepository nodeRegistryRepository;
	private final CurrentNodeResolver currentNodeResolver;
	private final UserSyncService userSyncService;
	private final RestClient restClient;
	private final AtomicInteger reconciliationPage = new AtomicInteger(0);

	public UserSyncOutboxWorker(SyncUserOutboxRepository userOutboxRepository, SyncOutboxDeliveryRepository deliveryRepository,
			NodeRegistryRepository nodeRegistryRepository, CurrentNodeResolver currentNodeResolver,
			UserSyncService userSyncService, @Qualifier("userSyncRestClient") RestClient restClient) {

		this.userOutboxRepository = userOutboxRepository;
		this.deliveryRepository = deliveryRepository;
		this.nodeRegistryRepository = nodeRegistryRepository;
		this.currentNodeResolver = currentNodeResolver;
		this.userSyncService = userSyncService;
		this.restClient = restClient;
	}

	@Value("${sync.internal-token:}")
	private String internalToken;
	@Value("${sync.outbox.batch-size:100}")
	private int batchSize;
	@Value("${sync.outbox.stale-sending-seconds:120}")
	private long staleSendingSeconds;
	
	@Value("${server.port}")
	private Integer port;

	@Scheduled(fixedDelayString = "${sync.outbox.fixed-delay-ms:5000}")
	public void processUserOutbox() {

		LocalDateTime now = LocalDateTime.now();
		deliveryRepository.resetStaleSending(now.minusSeconds(staleSendingSeconds));
		// Continue processing only if there are pending USER_CREATED events.
		long pendingCount = userOutboxRepository.countPendingUserEvents();
		if (pendingCount == 0) {
			deliveryRepository.findDispatchableUserDeliveries(LocalDateTime.now()).stream().limit(batchSize)
					.forEach(this::dispatch);
			return;
		}
		String localNodeId = currentNodeResolver.getCurrentNodeId();
		List<NodeRegistry> peers = nodeRegistryRepository.findByNodeIdNot(localNodeId);
		int pageSize = Math.max(1, batchSize);
		int totalPages = (int) Math.max(1, (pendingCount + pageSize - 1) / pageSize);
		int page = Math.floorMod(reconciliationPage.getAndIncrement(), totalPages);
		List<SyncUserOutbox> pending = userOutboxRepository.findPendingUserEvents(PageRequest.of(page, pageSize)).getContent();
		for (SyncUserOutbox event : pending) {
			ensureDeliveryRows(event, peers);
			refreshParent(event.getEventId());
		}
		deliveryRepository.findDispatchableUserDeliveries(LocalDateTime.now()).stream().limit(batchSize)
				.forEach(this::dispatch);
	}

	/**
	 * Probe each waiting destination once per recovery cycle, not once per event.
	 */
	@Scheduled(fixedDelayString = "${sync.recovery-check-interval-ms:15000}")
	public void recoverWaitingDeliveries() {
		for (String targetNodeId : deliveryRepository.findWaitingUserTargetNodeIds()) {
			NodeRegistry target = nodeRegistryRepository.findById(targetNodeId).orElse(null);
			if (target == null || !AppConstants.ACTIVE.equalsIgnoreCase(target.getStatus()) || target.getIpAddress() == null
					|| target.getIpAddress().isBlank())
				continue;
			try {
				String url = nodeServiceBaseUrl(target) + "/internal/health/sync";
				restClient.get().uri(url).retrieve().toBodilessEntity();
				int count = deliveryRepository.requeueWaitingForTargetNode(targetNodeId);
				if (count > 0)
					log.info("Requeued {} USER entity type deliveries for recovered node {}", count, targetNodeId);
			} catch (Exception ex) {
				// Health probe only. Leave WAITING_FOR_NODE and next_retry_at NULL while
				// offline.
				log.debug("Node {} is not ready for user synchronization: {}", targetNodeId, ex.getMessage());
			}
		}
	}

	private void ensureDeliveryRows(SyncUserOutbox event, List<NodeRegistry> peers) {
		for (NodeRegistry peer : peers) {
			deliveryRepository.findByEventIdAndTargetNodeId(event.getEventId(), peer.getNodeId())
					.orElseGet(() -> deliveryRepository.save(SyncOutboxDelivery.builder()
							.eventId(event.getEventId())
							.targetNodeId(peer.getNodeId())
							.status(AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus()) ? AppConstants.PENDING : AppConstants.WAITING_FOR_NODE)
							.retryCount(0).createdAt(LocalDateTime.now())
							.lastError(AppConstants.ACTIVE.equalsIgnoreCase(peer.getStatus()) ? null : "Target node inactive")
							.build()));
		}
	}

	private void dispatch(SyncOutboxDelivery candidate) {
		NodeRegistry target = nodeRegistryRepository.findById(candidate.getTargetNodeId()).orElse(null);
		if (target == null || !AppConstants.ACTIVE.equalsIgnoreCase(target.getStatus()) || target.getIpAddress() == null
				|| target.getIpAddress().isBlank()) {
			deliveryRepository.markWaiting(candidate.getId(), "Target node is missing or inactive in node_registry");
			return;
		}
		if (internalToken == null || internalToken.isBlank()) {
			log.error("sync.internal-token is not configured; refusing USER_CREATED delivery");
			return;
		}
		LocalDateTime now = LocalDateTime.now();
		if (deliveryRepository.claim(candidate.getId(), now) != 1)
			return;
		SyncUserOutbox event = userOutboxRepository.findByEventId(candidate.getEventId()).orElse(null);
		if (event == null) {
			log.error("Missing sync_outbox event {}", candidate.getEventId());
			return;
		}
		try {
			final Object payload;
			final String url;
			
			// DYNAMIC ROUTING BASED ON EVENT TYPE
			if (AppConstants.EDIT_USER.equals(event.getEventType())) {
				payload = userSyncService.parseEditPayload(event.getPayload());
				url = nodeServiceBaseUrl(target) + "/internal/sync/users/edit"; 
			} else if (AppConstants.USER_CREATED.equals(event.getEventType())) {
				payload = userSyncService.parsePayload(event.getPayload());
				url = nodeServiceBaseUrl(target) + "/internal/sync/users/receive";
			} else if (AppConstants.DELETE_USER.equals(event.getEventType())) {
				payload = userSyncService.parseDeletePayload(event.getPayload());
				url = nodeServiceBaseUrl(target) + "/internal/sync/users/delete";
			} else if (AppConstants.PASSWORD_CHANGE.equals(event.getEventType())) {
				payload = userSyncService.parsePasswordChangePayload(event.getPayload());
				url = nodeServiceBaseUrl(target) + "/internal/sync/users/passwordChange";
			} else if (AppConstants.SIGN_UP.equals(event.getEventType())) {
				payload = userSyncService.parseUserSignUpPayload(event.getPayload());
				url = nodeServiceBaseUrl(target) + "/internal/sync/users/signUp";
			} else {
				markFailed(candidate.getId(), "Unknown event type: " + event.getEventType());
				return;
			}
			log.info("DEBUG: Making API call to {} for event {}", url, event.getEventType());
			UserSyncAck ack = restClient.post()
					.uri(url)
					.header("X-Node-Sync-Token", internalToken)
					.contentType(MediaType.APPLICATION_JSON)
					.body(payload)
					.retrieve()
					.body(UserSyncAck.class);
			if (ack == null || !event.getEventId().equals(ack.eventId()) || !AppConstants.ACKNOWLEDGED.equals(ack.status())) {
				markFailed(candidate.getId(), "Invalid/mismatched USER entity type acknowledgement");
			} else {
				acknowledge(candidate.getId());
			}
		} catch (ResourceAccessException ex) {
			markWaiting(candidate.getId(), safeMessage(ex));
		} catch (Exception ex) {
			markFailed(candidate.getId(), safeMessage(ex));
		} finally {
			refreshParent(event.getEventId());
		}
	}

	private String nodeServiceBaseUrl(NodeRegistry target) {
		String host = target.getIpAddress().trim().replaceFirst("^/", "").replaceFirst("/\\d+$", "");
		return "http://" + host + ":" + port;
	}

	private void acknowledge(Long id) {
		SyncOutboxDelivery d = deliveryRepository.findById(id).orElseThrow();
		LocalDateTime now = LocalDateTime.now();
		d.setStatus(AppConstants.ACKNOWLEDGED);
		d.setAcknowledgedAt(now);
		d.setSentAt(now);
		d.setNextRetryAt(null);
		d.setLastError(null);
		deliveryRepository.save(d);
	}

	private void markWaiting(Long id, String error) {
		SyncOutboxDelivery d = deliveryRepository.findById(id).orElseThrow();
		d.setStatus(AppConstants.WAITING_FOR_NODE);
		d.setNextRetryAt(null);
		d.setLastError(error);
		deliveryRepository.save(d);
	}

	private void markFailed(Long id, String error) {
		SyncOutboxDelivery d = deliveryRepository.findById(id).orElseThrow();
		int retries = d.getRetryCount() == null ? 1 : d.getRetryCount() + 1;
		d.setRetryCount(retries);
		d.setStatus(AppConstants.FAILED);
		d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300, 5L * retries)));
		d.setLastError(error);
		deliveryRepository.save(d);
	}

	private void refreshParent(UUID eventId) {
		SyncUserOutbox event = userOutboxRepository.findByEventId(eventId).orElse(null);
		if (event == null)
			return;
		List<SyncOutboxDelivery> deliveries = deliveryRepository.findByEventId(eventId);
		boolean allAck = deliveries.stream().allMatch(d -> AppConstants.ACKNOWLEDGED.equalsIgnoreCase(d.getStatus()));
		// Empty delivery set means no other nodes were registered when event was
		// created.
		if (allAck) {
			event.setStatus(AppConstants.ACKNOWLEDGED);
			event.setSentAt(LocalDateTime.now());
			event.setLastError(null);
			event.setNextRetryAt(null);
		} else {
			event.setStatus(AppConstants.PENDING);
		}
		userOutboxRepository.save(event);
	}

	private String safeMessage(Exception ex) {
		String msg = ex.getMessage();
		if (msg == null)
			return ex.getClass().getSimpleName();
		return msg.length() > 1800 ? msg.substring(0, 1800) : msg;
	}
}
