package org.bel.apiGateway.Security;

import io.github.bucket4j.Bucket;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Component
@RequiredArgsConstructor
public class AuthenticationFilter implements GlobalFilter, Ordered {
    private final JwtUtil jwtUtil;
    private final RateLimiterService rateLimiterService;
    private final SessionValidationService sessionValidationService;
    private static final Logger log = LoggerFactory.getLogger(AuthenticationFilter.class);
    private final AntPathMatcher matcher = new AntPathMatcher();

    @Value("${gateway.open-endpoints}") private List<String> openEndpoints;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();
        if (exchange.getRequest().getMethod() == HttpMethod.OPTIONS) return chain.filter(exchange);
        String clientIp = exchange.getRequest().getRemoteAddress() == null
            ? "unknown" : exchange.getRequest().getRemoteAddress().getAddress().getHostAddress();

        if (isPublicEndpoint(path)) {
            ServerHttpRequest publicRequest = exchange.getRequest().mutate()
                .headers(h -> { h.remove("X-User-Id"); h.remove("X-User-Role"); h.remove("X-Token-Jti"); })
                .header("X-Forwarded-For", clientIp).build();
            return chain.filter(exchange.mutate().request(publicRequest).build());
        }

        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (authHeader == null || !authHeader.startsWith("Bearer "))
            return unauthorized(exchange, "Missing or invalid Authorization header");

        final Claims claims;
        final String userId;
        final String tokenType;
        final String jti;
        try {
            claims = jwtUtil.getClaims(authHeader.substring(7));
            userId = claims.getSubject();
            tokenType = claims.get("token_type", String.class);
            jti = claims.getId();
            if (userId == null || tokenType == null || jti == null)
                return unauthorized(exchange, "Token is missing required claims");
        } catch (Exception ex) {
            return unauthorized(exchange, "Authentication failed");
        }

        boolean validatePinEndpoint = path.equals("/authService/auth/validatePin")
            || path.equals("/auth/validatePin");
        String requiredType = validatePinEndpoint ? "PRE_AUTH" : "ACCESS";
        if (!requiredType.equals(tokenType))
            return unauthorized(exchange, validatePinEndpoint
                ? "PRE_AUTH token required for PIN validation"
                : "ACCESS token required");

        final Long numericUserId;
        try { numericUserId = Long.valueOf(userId); }
        catch (NumberFormatException ex) { return unauthorized(exchange, "Invalid user identity"); }

        return sessionValidationService.isSessionActive(jti, numericUserId, tokenType)
            .flatMap(active -> {
                if (!active) return unauthorized(exchange, "Token revoked, expired or inactive");
                Bucket bucket = rateLimiterService.resolveBucket(userId);
                if (!bucket.tryConsume(1)) return tooManyRequests(exchange);

                ServerHttpRequest request = exchange.getRequest().mutate().headers(headers -> {
                    headers.remove(HttpHeaders.AUTHORIZATION);
                    headers.remove("X-User-Id"); headers.remove("X-User-Role");
                    headers.remove("X-User-Roles"); headers.remove("X-Authenticated-User");
                    headers.remove("X-Internal-Token"); headers.remove("X-Token-Jti");
                    String forwarded = headers.getFirst("X-Forwarded-For");
                    headers.set("X-Forwarded-For", forwarded == null || forwarded.isBlank()
                        ? clientIp : forwarded + "," + clientIp);
                }).header("X-User-Id", userId)
                  .header("X-User-Role", claims.get("role", String.class))
                  .header("X-Token-Jti", jti)
                  .build();
                return chain.filter(exchange.mutate().request(request).build());
            });
    }

    private boolean isPublicEndpoint(String path) {
        return openEndpoints.stream().map(String::trim).anyMatch(pattern -> matcher.match(pattern, path));
    }

    private Mono<Void> unauthorized(ServerWebExchange exchange, String message) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        exchange.getResponse().getHeaders().add(HttpHeaders.CONTENT_TYPE, "application/json");
        String body = "{\"status\":401,\"message\":\"" + message + "\"}";
        DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(body.getBytes(StandardCharsets.UTF_8));
        return exchange.getResponse().writeWith(Mono.just(buffer));
    }

    private Mono<Void> tooManyRequests(ServerWebExchange exchange) {
        exchange.getResponse().setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
        exchange.getResponse().getHeaders().add(HttpHeaders.CONTENT_TYPE, "application/json");
        String body = "{\"status\":429,\"message\":\"Rate limit exceeded\"}";
        DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(body.getBytes(StandardCharsets.UTF_8));
        return exchange.getResponse().writeWith(Mono.just(buffer));
    }

    @Override public int getOrder() { return -1; }
}
