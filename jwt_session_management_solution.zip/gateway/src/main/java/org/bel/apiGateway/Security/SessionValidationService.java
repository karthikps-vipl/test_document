package org.bel.apiGateway.Security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.time.Duration;

@Service
public class SessionValidationService {
    private final WebClient webClient;
    @Value("${security.internal-token}") private String internalToken;

    public SessionValidationService(@Value("${gateway.auth-session-url}") String authSessionUrl) {
        this.webClient = WebClient.builder().baseUrl(authSessionUrl).build();
    }

    public Mono<Boolean> isSessionActive(String jti, Long userId, String tokenType) {
        return webClient.get()
            .uri(uriBuilder -> uriBuilder.path("/internal/auth/validate-session")
                .queryParam("jti", jti).queryParam("userId", userId)
                .queryParam("tokenType", tokenType).build())
            .header("X-Internal-Token", internalToken)
            .retrieve().bodyToMono(Boolean.class)
            .timeout(Duration.ofSeconds(3))
            .onErrorReturn(false);
    }
}
