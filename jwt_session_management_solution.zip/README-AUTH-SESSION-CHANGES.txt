JWT session-control changes (no Redis)
=====================================

Contents
--------
authService/   Modified Auth Service project
gatewayService/ Modified API Gateway project

Database
--------
One new table is introduced in the Auth Service database: auth_sessions.
Run authService/src/main/resources/db/manual_create_auth_sessions.sql before deploying.
The production profile uses ddl-auto=validate, so Hibernate will NOT create this table automatically.
The existing refresh_tokens table is reused; no new refresh-token table is added.

Environment configuration
--------------------------
Set the SAME high-entropy INTERNAL_AUTH_TOKEN value in both services.
Set AUTH_SESSION_URL in the Gateway to the internal Auth Service base URL reachable from the Gateway
(default is http://localhost:9101 for local development). Do not expose /internal/auth/validate-session
to mobile clients or the public Internet; restrict it to the Gateway network and shared secret.

JWT settings
------------
PRE_AUTH token lifetime: 300000 ms (5 minutes).
ACCESS token lifetime: 1800000 ms (30 minutes).
Refresh token lifetime remains 86400 seconds in the supplied profiles.
JWT_SECRET must be identical in Gateway and Auth Service.

Flow
----
1. /auth/login returns a PRE_AUTH JWT and registers its JTI in auth_sessions.
2. Gateway allows PRE_AUTH only for /authService/auth/validatePin.
3. Auth Service verifies the PRE_AUTH JTI belongs to the user, is active and unexpired.
4. Successful PIN validation revokes the PRE_AUTH JTI, revokes all old ACCESS sessions for the user,
   revokes the user's old refresh tokens, then creates a new ACCESS session and refresh token.
5. All protected Gateway requests require ACCESS token type and an active auth_sessions row.
6. Refresh checks the refresh-token revoked flag, revokes the user's prior ACCESS session, and creates
   a replacement ACCESS token.

Important integration note
--------------------------
The Gateway injects X-Token-Jti for the Auth Service validatePin endpoint. The mobile client must keep
using the login token for validatePin and must replace it with the ACCESS token returned by validatePin
for all subsequent protected APIs. The login token cannot be used for normal APIs.

Build validation
----------------
The editing environment did not have Maven installed, so Maven compilation/tests could not be run here.
Run `mvn clean verify` for each project in your build environment before deploying.








I have prepared the modified projects and packaged them.

## 1. Download modified source code

You can download the projects individually or together.

**Recommended: Download both projects together**

📦 jwt_session_management_solution.zip[JWT Session Management – Complete Solution](sandbox:/mnt/data/jwt_session_management_solution.zip)

Individual downloads:

- authService_modified.zip[Modified Auth Service](sandbox:/mnt/data/authService_modified.zip)
- gatewayService_modified.zip[Modified API Gateway](sandbox:/mnt/data/gatewayService_modified.zip)

---

## 2. Files modified in Auth Service

| File | Change |
|---|---|
| `util/JwtUtil.java` | Added separate PRE_AUTH and ACCESS token generation. Registers token JTI in database. |
| `service/serviceImpl/AuthServiceImplementation.java` | Modified login, PIN validation and refresh-token handling. Revokes previous sessions. |
| `service/AuthService.java` | Updated validatePin method signature to receive JTI. |
| `controller/AuthController.java` | Updated validatePin to receive X-Token-Jti. |
| `config/SecurityConfig.java` | Added permission for internal session-validation endpoint. |
| `repository/MdmUserRepository.java` | Added pessimistic locking for simultaneous login handling. |
| `repository/RefreshTokenRepository.java` | Added method to revoke existing refresh tokens. |
| `application-dev.properties` | Added PRE_AUTH expiry and internal security configuration. |
| `application-prod.properties` | Updated JWT expiry and internal security configuration. |

### New files added

| File | Purpose |
|---|---|
| `entity/AuthSession.java` | Stores active and revoked JWT sessions. |
| `repository/AuthSessionRepository.java` | Database operations for session validation and revocation. |
| `controller/InternalSessionController.java` | Provides internal session-validation API. |
| `resources/db/manual_create_auth_sessions.sql` | SQL script for creating the new table. |

## 3. Files modified in API Gateway

| File | Change |
|---|---|
| `Security/AuthenticationFilter.java` | Added token-purpose validation, session validation and JTI forwarding. |
| `application-dev.properties` | Added Auth Service session-validation URL and internal credential. |
| `application-prod.properties` | Added production session-validation configuration. |

### New file added

| File | Purpose |
|---|---|
| `Security/SessionValidationService.java` | Communicates with Auth Service to verify whether a JWT session is active. |

---

## 4. Additional database tables

Only **ONE new table** has been introduced.

### `auth_sessions`

| Column | Data type | Description |
|---|---|---|
| id | BIGSERIAL | Primary key |
| user_id | BIGINT | User ID |
| jti | VARCHAR(36) | Unique JWT identifier |
| token_type | VARCHAR(20) | PRE_AUTH / ACCESS |
| revoked | BOOLEAN | Whether token is revoked |
| expires_at | TIMESTAMP | Token expiry |
| created_at | TIMESTAMP | Session creation time |

Your existing `refresh_tokens` table is reused.

**No additional refresh-token table is required.**

---

## 5. Before running the projects

There are three important configurations.

### A. Create the new table

Execute:

`authService/src/main/resources/db/manual_create_auth_sessions.sql`

Execute this against your existing PostgreSQL database.

This is particularly important because your production configuration uses:

```properties
spring.jpa.hibernate.ddl-auto=validate
```

Hibernate will not automatically create the table in production.

### B. Configure the same internal secret

Generate a strong secret and configure it as an environment variable in both services:

```bash
export INTERNAL_AUTH_TOKEN="your-long-random-secret"
```

Make sure the Gateway and Auth Service receive exactly the same value.

### C. Configure Gateway's Auth Service URL

Development:

```properties
gateway.auth-session-url=${AUTH_SESSION_URL:http://localhost:9101}
```

Production:

Set `AUTH_SESSION_URL` to the internal Auth Service URL reachable from Gateway.

---

## 6. Important testing scenarios

After deploying, test these scenarios in order:

| Test | Expected result |
|---|---|
| Login | PRE_AUTH token generated |
| Use login token for another API | 401 Unauthorized |
| Use login token for validatePin | Successful |
| Reuse same login token for validatePin | 401 Unauthorized |
| Use ACCESS token for application APIs | Successful |
| Login from another device and validate PIN | Previous ACCESS token revoked |
| Use previous device's ACCESS token | 401 Unauthorized |
| Use new device's ACCESS token | Successful |
| Use revoked refresh token | Rejected |

---

### One important note

I could not execute Maven compilation because Maven is not installed in the execution environment. Therefore, these are edited source packages, not Maven-build-verified releases.

Before production deployment, run:

```bash
mvn clean verify
```

in both projects.

I have also included a README in the combined ZIP explaining the implementation and deployment configuration.

**My suggestion:** First deploy these changes in your development environment and test the two-device login scenario. In particular, verify that Device A immediately receives HTTP 401 after Device B successfully validates its PIN.
