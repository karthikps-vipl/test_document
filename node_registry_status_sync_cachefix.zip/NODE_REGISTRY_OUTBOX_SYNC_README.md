# Node registry snapshot synchronization (separate from location synchronization)

This change adds a separate durable registry outbox and delivery queue. It does not modify the existing `sync_outbox`, `sync_outbox_delivery`, `NodeSyncService`, or location endpoint.

## Flow
1. Creating a node or changing a node status saves `node_registry` and inserts a full snapshot event into `tcs_laa.node_registry_outbox` in the same transaction.
2. `NodeRegistryOutboxWorker` creates per-destination rows in `tcs_laa.node_registry_outbox_delivery` for every currently ACTIVE node in the snapshot except the source node. A deactivated node is included in the snapshot data so peers learn its new status, but is not a delivery target.
3. The worker posts the complete snapshot to each destination at `POST /internal/sync/node-registry`.
4. The destination validates `X-Node-Sync-Token`, upserts registry rows, preserves its own local row when it can identify it, and returns an acknowledgement.
5. Failed deliveries are retried with increasing delays; delivery state is tracked independently per destination.

When Node D is added at Node A, the snapshot includes A, B, C and D. A is excluded as the sender, so B, C and D each receive the full snapshot. Node D does not need a special payload.

## Deploy
1. Run `NODE_REGISTRY_OUTBOX_MIGRATION.sql` on every Node Service database.
2. Set the same strong `SYNC_INTERNAL_TOKEN` secret on all nodes. Do not use the development fallback in production.
3. Build and test with `mvn clean package` before deployment.

The worker retries offline peers independently. Registry sync uses dedicated tables and does not change the location synchronization pipeline.

## Health-cache refresh after receiving a snapshot
After the receiver applies the snapshot, it publishes `NodeRegistryCacheRefreshEvent`.
`NodeHealthMonitor` handles the event after the database transaction commits. Active peer
entries are immediately set to `UNKNOWN` until the next actual health probe; inactive entries
are set to `INACTIVE_IN_REGISTRY`. The local node is excluded when it can be resolved. This
updates only the in-memory health cache and does not alter location synchronization.

The same cache-refresh event is also published after a local node registration or status change, including `PATCH /api/node/change/status`.
Because the listener runs after transaction commit, both the source node and receiving nodes refresh
health-cache entries immediately; active peers remain `UNKNOWN` until probed, and inactive peers
are marked `INACTIVE_IN_REGISTRY`. Pending deliveries to a target that becomes inactive are marked
`SKIPPED` instead of being retried forever.



| File | Responsibility |
|---|---|
| `NodeRegistryController.java` | Exposes `/change/status`. |
| `NodeRegistryService.java` | Updates the status, queues the registry snapshot and publishes the cache-refresh event. |
| `NodeRegistryOutboxService.java` | Creates the durable snapshot event. |
| `NodeRegistryOutboxWorker.java` | Delivers snapshots to active peers and retries failures. |
| `NodeRegistrySnapshotReceiver.java` | Applies incoming registry changes on receiving nodes. |
| `NodeHealthMonitor.java` | Refreshes the in-memory health cache. |
