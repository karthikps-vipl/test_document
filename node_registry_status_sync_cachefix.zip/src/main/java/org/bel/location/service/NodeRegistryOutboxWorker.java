package org.bel.location.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bel.location.dto.request.NodeRegistrySnapshotEvent;
import org.bel.location.dto.request.SyncAckResponse;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.entity.NodeRegistryOutbox;
import org.bel.location.entity.NodeRegistryOutboxDelivery;
import org.bel.location.repository.NodeRegistryOutboxDeliveryRepository;
import org.bel.location.repository.NodeRegistryOutboxRepository;
import org.bel.location.repository.NodeRegistryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service @RequiredArgsConstructor @Slf4j
public class NodeRegistryOutboxWorker {
    private final NodeRegistryOutboxRepository outboxRepository;
    private final NodeRegistryOutboxDeliveryRepository deliveryRepository;
    private final NodeRegistryRepository nodeRepository;
    private final RestClient restClient;
    private final ObjectMapper objectMapper;
    @Value("${sync.internal-token:}") private String internalToken;

    @Scheduled(fixedDelayString = "${node.registry.outbox.fixed-delay-ms:5000}", initialDelayString = "${node.registry.outbox.initial-delay-ms:5000}")
    public void process() {
        try {
            List<NodeRegistryOutbox> events = outboxRepository.findTop100ByStatusInOrderByCreatedAtAsc(List.of("PENDING", "PARTIAL"));
            for (NodeRegistryOutbox event : events) processEvent(event);
            retryDueDeliveries();
        } catch (Exception e) { log.error("Node registry outbox processing cycle failed", e); }
    }

    private void processEvent(NodeRegistryOutbox event) {
        try {
            NodeRegistrySnapshotEvent snapshot = objectMapper.readValue(event.getPayload(), NodeRegistrySnapshotEvent.class);
            for (NodeRegistrySnapshotEvent.NodeRecord node : snapshot.nodes()) {
                if (node.nodeId().equals(snapshot.sourceNodeId())) continue;
                // Registry snapshots are delivered only to currently ACTIVE peers. A deactivated
                // node is included in the payload so active peers learn its new status, but it
                // must not be selected as a delivery target itself.
                if (!"ACTIVE".equalsIgnoreCase(node.status())) continue;
                deliveryRepository.findByEventIdAndTargetNodeId(event.getEventId(), node.nodeId()).orElseGet(() -> {
                    LocalDateTime now = LocalDateTime.now();
                    return deliveryRepository.save(NodeRegistryOutboxDelivery.builder().eventId(event.getEventId()).targetNodeId(node.nodeId())
                        .status("PENDING").retryCount(0).createdAt(now).updatedAt(now).build());
                });
            }
            // Empty peers means the event is already complete. SKIPPED deliveries are terminal
            // too (for example, a target was deactivated after an event was queued).
            List<NodeRegistryOutboxDelivery> deliveries = deliveryRepository.findByEventId(event.getEventId());
            boolean complete = deliveries.stream().allMatch(d -> isTerminal(d.getStatus()));
            if (deliveries.isEmpty()) event.setStatus("ACKNOWLEDGED"); else event.setStatus(complete ? "ACKNOWLEDGED" : "PARTIAL");
            event.setUpdatedAt(LocalDateTime.now()); outboxRepository.save(event);
        } catch (Exception e) {
            event.setLastError(shortError(e)); event.setUpdatedAt(LocalDateTime.now()); outboxRepository.save(event);
            log.error("Unable to prepare registry deliveries for event {}", event.getEventId(), e);
        }
    }

    private void retryDueDeliveries() {
        LocalDateTime now = LocalDateTime.now();
        List<NodeRegistryOutboxDelivery> candidates = new ArrayList<>();
        candidates.addAll(deliveryRepository.findTop200ByStatusInAndNextRetryAtIsNullOrderByCreatedAtAsc(List.of("PENDING", "FAILED")));
        candidates.addAll(deliveryRepository.findTop200ByStatusInAndNextRetryAtLessThanEqualOrderByCreatedAtAsc(List.of("FAILED"), now));
        Map<String, NodeRegistry> nodes = nodeRepository.findAll().stream().collect(Collectors.toMap(NodeRegistry::getNodeId, n -> n, (a,b)->a));
        for (NodeRegistryOutboxDelivery delivery : candidates) {
            NodeRegistry target = nodes.get(delivery.getTargetNodeId());
            if (target == null || !"ACTIVE".equalsIgnoreCase(target.getStatus())) {
                delivery.setStatus("SKIPPED");
                delivery.setLastError("Target node is not registered or ACTIVE; delivery skipped");
                delivery.setNextRetryAt(null);
                delivery.setUpdatedAt(LocalDateTime.now());
                deliveryRepository.save(delivery);
                continue;
            }
            NodeRegistryOutbox event = outboxRepository.findById(delivery.getEventId()).orElse(null);
            if (event == null) continue;
            try {
                NodeRegistrySnapshotEvent payload = objectMapper.readValue(event.getPayload(), NodeRegistrySnapshotEvent.class);
                String url = "http://" + target.getIpAddress() + ":" + target.getPort() + "/internal/sync/node-registry";
                ResponseEntity<SyncAckResponse> response = restClient.post().uri(url).header("X-Node-Sync-Token", internalToken).body(payload).retrieve().toEntity(SyncAckResponse.class);
                SyncAckResponse ack = response.getBody();
                if (response.getStatusCode().is2xxSuccessful() && ack != null && delivery.getEventId().equals(ack.eventId()) && "ACKNOWLEDGED".equals(ack.status())) {
                    delivery.setStatus("ACKNOWLEDGED"); delivery.setLastError(null); delivery.setNextRetryAt(null); delivery.setUpdatedAt(LocalDateTime.now());
                    deliveryRepository.save(delivery);
                } else markFailed(delivery, "Invalid or mismatched acknowledgement");
            } catch (Exception ex) { markFailed(delivery, shortError(ex)); }
            refreshEventStatus(event);
        }
    }

    private void refreshEventStatus(NodeRegistryOutbox event) {
        List<NodeRegistryOutboxDelivery> deliveries = deliveryRepository.findByEventId(event.getEventId());
        boolean complete = deliveries.stream().allMatch(d -> isTerminal(d.getStatus()));
        event.setStatus(complete ? "ACKNOWLEDGED" : "PARTIAL"); event.setUpdatedAt(LocalDateTime.now());
        outboxRepository.save(event);
    }
    private boolean isTerminal(String status) {
        return "ACKNOWLEDGED".equals(status) || "SKIPPED".equals(status);
    }

    private void markFailed(NodeRegistryOutboxDelivery d, String error) {
        int retries = d.getRetryCount() == null ? 1 : d.getRetryCount() + 1;
        d.setRetryCount(retries); d.setStatus("FAILED"); d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300, 10L * retries)));
        d.setLastError(error); d.setUpdatedAt(LocalDateTime.now()); deliveryRepository.save(d);
    }
    private String shortError(Exception e) { String s=e.getMessage(); return s == null ? e.getClass().getSimpleName() : (s.length()>2000 ? s.substring(0,2000) : s); }
}
