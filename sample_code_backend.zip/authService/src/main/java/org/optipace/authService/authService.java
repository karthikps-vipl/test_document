package org.optipace.authService;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class authService {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String hash = encoder.encode("ramesh@123");

        System.out.println(hash);
    }
}