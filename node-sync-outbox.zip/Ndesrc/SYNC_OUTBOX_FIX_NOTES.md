# Node-to-node sync: outbox completion, down-node recovery, and health API

## Behaviour
- Location/outbox event creation remains independent of peer status. A GPS event should create `sync_outbox` based on the existing location sync policy; a deactivated peer should not suppress the local outbox insert.
- `SyncOutboxWorker` creates a durable `sync_outbox_delivery` row for every registered peer, including inactive peers.
- If `node_registry.status` is not `ACTIVE`, delivery status becomes `WAITING_FOR_NODE` and `next_retry_at` is cleared.
- Active peers are checked by `NodeHealthMonitor` through `GET /internal/health/sync`. If the service is unreachable, delivery stays `WAITING_FOR_NODE` with `next_retry_at = NULL`; no timed retry loop runs while the peer is down.
- Once a peer is active and its health endpoint responds successfully, the worker picks up waiting delivery rows and sends the pending event. This sends the queued event payloads to that peer; it does not automatically mean a full database snapshot/backfill is implemented.
- The parent `sync_outbox.status` remains `PENDING` until every peer currently registered in `node_registry` (excluding the source node) has a delivery row with `ACKNOWLEDGED`. Then it becomes `ACKNOWLEDGED` and is excluded from the pending-event query.
- Connectivity failures are recorded as `WAITING_FOR_NODE`, not `FAILED` with a repeatedly advancing `next_retry_at`. Other application/HTTP errors continue using backoff as `FAILED`.

## APIs
- `GET /internal/health/sync` — internal endpoint used by peer nodes. Returns application and database status.
- `GET /api/nodes/sync-health` — returns local node plus all registered peers, their registry status, latest health state, and cluster counts.

## Configuration (`application-prod.properties`)
- `sync.http.connect-timeout-ms=2000`
- `sync.http.read-timeout-ms=3000`
- `sync.health.check-interval-ms=15000`
- `sync.health.initial-delay-ms=3000`

## Important operational notes
1. Ensure the database allows the string `WAITING_FOR_NODE` in `sync_outbox_delivery.status` if a CHECK constraint or enum restricts allowed values.
2. `node_registry` must be populated consistently on each node; it is currently the source of truth for required recipients.
3. The health check currently uses HTTP. Use HTTPS/mTLS and authentication before production deployment.
4. `CurrentNodeResolver` identifies this server using `InetAddress.getLocalHost()` matched against `node_registry.ip_address`. Verify this resolves to the registered server IP in your deployment, especially inside Docker.
5. This health API reports node service reachability and local database connectivity; it is not a full end-to-end sync test.
6. Build and integration tests must be run in your Java/Maven environment. This environment did not have Maven available, so compilation has not been verified here.


## Offline-node retry efficiency update

- `sync_outbox` events are used to create per-target delivery rows only when no delivery rows exist yet. A parent event with existing delivery rows is not rescanned just because one peer is offline.
- The worker polls only `PENDING` and retry-due `FAILED` rows in `sync_outbox_delivery`. `WAITING_FOR_NODE` rows are not polled for delivery.
- When a peer transitions from unknown/down to healthy, `NodeHealthMonitor` changes its `WAITING_FOR_NODE` deliveries back to `PENDING` once, allowing the worker to resume them.
- A lightweight health probe continues every configured health interval; location/event delivery is not retried while the peer is known down.
- Old `SENDING` rows with no `sent_at` are reset after `sync.outbox.stale-sending-seconds` to recover after an application crash.
- Ensure the database permits `WAITING_FOR_NODE` as a delivery status.

## Three hardening changes (2026-10-14)

1. **Reliable recovery reconciliation:** every health-monitor cycle collects peers whose sync health endpoint responds successfully, then performs one batch update to requeue their `WAITING_FOR_NODE` deliveries. Recovery no longer depends only on detecting an in-memory `DOWN -> UP` transition. A connection failure from `NodeSyncService` immediately marks the peer unhealthy in the local cache.
2. **Fewer registry reads:** each `SyncOutboxWorker` cycle reads `node_registry` once and reuses that peer snapshot for new delivery-row initialization and dispatch target lookup. The health monitor also reads the registry once per cycle and requeues all healthy peers in one database update.
3. **Atomic delivery claim:** the worker uses a conditional database update to move only eligible `PENDING` / retry-due `FAILED` rows to `SENDING`. If another worker already claimed the row, the update count is zero and no second HTTP send is started. The `sent_at` column is set when a delivery attempt is claimed and refreshed on acknowledgement; stale `SENDING` recovery now uses that attempt timestamp rather than the event's original `created_at`.

**Validation note:** Maven is not installed in the editing environment, so this ZIP has not been compiled or integration-tested here. Build and test it in the project's Java 21/Maven environment before deploying. Confirm any database CHECK constraint permits `PENDING`, `SENDING`, `FAILED`, `ACKNOWLEDGED`, and `WAITING_FOR_NODE` statuses.
