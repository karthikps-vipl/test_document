package org.bel.location.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.bel.location.entity.SyncOutbox;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SyncOutboxRepository extends JpaRepository<SyncOutbox, Long> {

    Optional<SyncOutbox> findByEventId(UUID eventId);

    /**
     * Returns only events for which delivery rows have not yet been created.
     * This prevents the scheduled worker from rescanning every PENDING parent event
     * while one or more target nodes are offline.
     */
    @Query("SELECT s FROM SyncOutbox s WHERE s.status = 'PENDING' " +
           "AND NOT EXISTS (SELECT d.id FROM SyncOutboxDelivery d WHERE d.eventId = s.eventId) " +
           "ORDER BY s.createdAt")
    List<SyncOutbox> findEventsWithoutDeliveryRows();
}
