package org.bel.location.service;

import java.time.LocalDateTime;

import org.bel.location.dto.LocationSyncEvent;
import org.bel.location.dto.SyncAckResponse;
import org.bel.location.entity.NodeRegistry;
import org.bel.location.entity.SyncOutbox;
import org.bel.location.entity.SyncOutboxDelivery;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.ResourceAccessException;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class NodeSyncService {
    private final RestClient restClient;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final ObjectMapper mapper;
    private final ObjectProvider<SyncOutboxWorker> outboxWorker;
    private final NodeHealthMonitor nodeHealthMonitor;

    @Async("syncExecutor")
    public void send(SyncOutbox outbox, SyncOutboxDelivery delivery, NodeRegistry target) {
        try {
            LocationSyncEvent e = mapper.readValue(outbox.getPayload(), LocationSyncEvent.class);
            LocationSyncEvent targetEvent = new LocationSyncEvent(e.eventId(), e.eventType(), e.entityType(),
                    e.userId(), e.sourceNodeId(), target.getNodeId(), e.version(), e.latitude(), e.longitude(), e.timestamp());
            String url = "http://" + target.getIpAddress() + ":" + target.getPort() + "/internal/sync/location";
            ResponseEntity<SyncAckResponse> response = restClient.post().uri(url).body(targetEvent)
                    .retrieve().toEntity(SyncAckResponse.class);
            SyncAckResponse ack = response.getBody();
            if (response.getStatusCode().is2xxSuccessful() && ack != null
                    && outbox.getEventId().equals(ack.eventId())
                    && ("ACKNOWLEDGED".equals(ack.status()) || "STALE_IGNORED".equals(ack.status()))) {
                LocalDateTime now = LocalDateTime.now();
                delivery.setStatus("ACKNOWLEDGED");
                delivery.setSentAt(now);
                delivery.setAcknowledgedAt(now);
                delivery.setNextRetryAt(null);
                delivery.setLastError(null);
                deliveryRepo.save(delivery);
            } else {
                fail(delivery, new IllegalStateException("Invalid or mismatched sync acknowledgement"));
            }
        } catch (ResourceAccessException ex) {
            // Mark cached health DOWN immediately, so the next successful probe causes recovery.
            nodeHealthMonitor.markUnhealthy(delivery.getTargetNodeId(), ex.getMessage());
            // Connection refused / timeout means the node is currently unreachable.
            // Do not schedule repeated attempts; the health monitor will detect recovery.
            delivery.setStatus("WAITING_FOR_NODE");
            delivery.setNextRetryAt(null);
            delivery.setLastError(shortError(ex));
            deliveryRepo.save(delivery);
        } catch (Exception ex) {
            fail(delivery, ex);
        } finally {
            outboxWorker.getObject().refreshOutboxStatus(outbox);
        }
    }

    private void fail(SyncOutboxDelivery d, Exception ex) {
        int retry = (d.getRetryCount() == null ? 0 : d.getRetryCount()) + 1;
        d.setRetryCount(retry);
        d.setStatus("FAILED");
        d.setNextRetryAt(LocalDateTime.now().plusSeconds(Math.min(300, 10L * retry)));
        d.setLastError(shortError(ex));
        deliveryRepo.save(d);
    }

    private String shortError(Exception ex) {
        String msg = ex.getMessage();
        return msg != null && msg.length() > 2000 ? msg.substring(0, 2000) : msg;
    }
}
