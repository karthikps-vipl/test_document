package org.bel.location.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.bel.location.entity.NodeRegistry;
import org.bel.location.entity.SyncOutbox;
import org.bel.location.entity.SyncOutboxDelivery;
import org.bel.location.repository.SyncOutboxDeliveryRepository;
import org.bel.location.repository.SyncOutboxRepository;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class SyncOutboxWorker {
    private final SyncOutboxRepository outboxRepo;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final NodeRegistryService nodeRegistryService;
    private final NodeSyncService nodeSyncService;
    private final NodeHealthMonitor nodeHealthMonitor;
    private final ObjectProvider<SyncOutboxWorker> selfProvider;

    @Value("${sync.outbox.batch-size:100}")
    private int batchSize;

    @Value("${sync.outbox.stale-sending-seconds:120}")
    private long staleSendingSeconds;

    @Scheduled(fixedDelayString = "${sync.outbox.fixed-delay-ms:10000}")
    public void processOutbox() {
        LocalDateTime now = LocalDateTime.now();
        deliveryRepo.resetStaleSendingRows(now.minusSeconds(staleSendingSeconds));

        // One registry read per worker cycle, shared by initialization and dispatch.
        List<NodeRegistry> targets = nodeRegistryService.getOtherRegisteredNodes();
        Map<String, NodeRegistry> targetsById = targets.stream().collect(
                Collectors.toMap(NodeRegistry::getNodeId, Function.identity(), (first, ignored) -> first));

        outboxRepo.findEventsWithoutDeliveryRows().stream().limit(batchSize)
                .forEach(event -> selfProvider.getObject().initializeDeliveries(event, targets));

        deliveryRepo.findDispatchable(now).stream().limit(batchSize)
                .forEach(delivery -> dispatchDelivery(delivery, targetsById, now));
    }

    @Transactional
    public void initializeDeliveries(SyncOutbox event, List<NodeRegistry> targets) {
        if (targets.isEmpty()) {
            event.setStatus("ACKNOWLEDGED");
            event.setSentAt(LocalDateTime.now());
            event.setLastError(null);
            outboxRepo.save(event);
            return;
        }

        for (NodeRegistry target : targets) {
            deliveryRepo.findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
                    .orElseGet(() -> deliveryRepo.save(SyncOutboxDelivery.builder()
                            .eventId(event.getEventId())
                            .targetNodeId(target.getNodeId())
                            .status("PENDING")
                            .retryCount(0)
                            .createdAt(LocalDateTime.now())
                            .build()));
        }
    }

    private void dispatchDelivery(SyncOutboxDelivery candidate, Map<String, NodeRegistry> targetsById,
                                  LocalDateTime now) {
        NodeRegistry target = targetsById.get(candidate.getTargetNodeId());
        if (target == null) {
            deliveryRepo.markWaitingIfDispatchable(candidate.getId(), now,
                    "Target node is not present in node_registry");
            return;
        }

        if (!"ACTIVE".equalsIgnoreCase(target.getStatus()) || !nodeHealthMonitor.isHealthy(target.getNodeId())) {
            deliveryRepo.markWaitingIfDispatchable(candidate.getId(), now,
                    "Target node is inactive or unhealthy");
            return;
        }

        // Conditional UPDATE is the concurrency gate. If another worker already claimed
        // this delivery, the update count is zero and no duplicate HTTP send is started.
        if (deliveryRepo.claimDispatchable(candidate.getId(), now) != 1) {
            return;
        }

        SyncOutboxDelivery claimed = deliveryRepo.findById(candidate.getId()).orElse(null);
        if (claimed == null) {
            log.error("Claimed sync delivery {} disappeared", candidate.getId());
            return;
        }
        SyncOutbox event = outboxRepo.findByEventId(claimed.getEventId()).orElse(null);
        if (event == null) {
            log.error("No sync_outbox event found for delivery {}", claimed.getId());
            return;
        }
        nodeSyncService.send(event, claimed, target);
    }

    @Transactional
    public void refreshOutboxStatus(SyncOutbox event) {
        List<NodeRegistry> targets = nodeRegistryService.getOtherRegisteredNodes();
        boolean allAcknowledged = targets.stream().allMatch(target -> deliveryRepo
                .findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
                .map(d -> "ACKNOWLEDGED".equals(d.getStatus())).orElse(false));

        if (allAcknowledged) {
            event.setStatus("ACKNOWLEDGED");
            event.setSentAt(LocalDateTime.now());
            event.setLastError(null);
        } else {
            event.setStatus("PENDING");
        }
        outboxRepo.save(event);
    }
}
