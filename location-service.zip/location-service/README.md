# Distributed Location Synchronization Service

Same JAR/Docker image is deployed to all nodes. PostgreSQL database name is the same on all nodes and is configured as localhost:5432/locationdb.

Node identity is resolved by the local server IP -> node_registry -> node_id.

No target API URL is hardcoded in application.properties. Target IP/port are read from node_registry.

Flow:
Flutter -> LocationService -> local DB -> sync_outbox -> SyncOutboxWorker -> node_registry -> NodeSyncService -> target /internal/sync/location -> target DB -> ACK.

HCRR is intentionally excluded from this first implementation.

Build:
mvn clean package

Before running, change YOUR_PASSWORD in application.properties.

Example node registry:
INSERT INTO node_registry(node_id,node_name,ip_address,port,status) VALUES
('NODE-001','NODE-001','10.10.1.11',9120,'ACTIVE'),
('NODE-002','NODE-002','10.10.1.12',9120,'ACTIVE'),
('NODE-003','NODE-003','10.10.1.13',9120,'ACTIVE');

Docker note:
If PostgreSQL and the application are separate containers, localhost is not the host PostgreSQL. Configure Docker networking accordingly. If the application container cannot see the physical server IP, CurrentNodeResolver must be adapted to the chosen Docker networking mode.
