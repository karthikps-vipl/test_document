CREATE TABLE IF NOT EXISTS node_registry (
node_id VARCHAR(100) PRIMARY KEY, node_name VARCHAR(100) NOT NULL,
ip_address INET NOT NULL UNIQUE, port INTEGER NOT NULL,
status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_node_registry_status ON node_registry(status);

CREATE TABLE IF NOT EXISTS user_location_latest (
user_id VARCHAR(100) PRIMARY KEY, node_id VARCHAR(100) NOT NULL,
latitude NUMERIC(10,7) NOT NULL, longitude NUMERIC(10,7) NOT NULL,
accuracy NUMERIC(10,2), location_timestamp TIMESTAMPTZ NOT NULL,
location_version BIGINT NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_user_location_latest_node ON user_location_latest(node_id);
CREATE INDEX IF NOT EXISTS idx_user_location_latest_updated ON user_location_latest(updated_at);

CREATE TABLE IF NOT EXISTS user_location_history (
id BIGSERIAL PRIMARY KEY, user_id VARCHAR(100) NOT NULL, node_id VARCHAR(100) NOT NULL,
latitude NUMERIC(10,7) NOT NULL, longitude NUMERIC(10,7) NOT NULL,
accuracy NUMERIC(10,2), location_timestamp TIMESTAMPTZ NOT NULL,
location_version BIGINT NOT NULL, recorded_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_location_history_user_time ON user_location_history(user_id, location_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_location_history_node ON user_location_history(node_id);

CREATE TABLE IF NOT EXISTS user_location_sync_state (
user_id VARCHAR(100) PRIMARY KEY, last_synced_latitude NUMERIC(10,7),
last_synced_longitude NUMERIC(10,7), last_synced_version BIGINT,
last_synced_at TIMESTAMPTZ, last_local_update_at TIMESTAMPTZ,
updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS sync_outbox (
id BIGSERIAL PRIMARY KEY, event_id UUID NOT NULL UNIQUE,
event_type VARCHAR(100) NOT NULL, entity_type VARCHAR(100) NOT NULL,
entity_id VARCHAR(100) NOT NULL, source_node_id VARCHAR(100) NOT NULL,
event_version BIGINT NOT NULL, payload JSONB NOT NULL,
status VARCHAR(30) NOT NULL DEFAULT 'PENDING', retry_count INTEGER NOT NULL DEFAULT 0,
next_retry_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
sent_at TIMESTAMPTZ, last_error TEXT);
CREATE INDEX IF NOT EXISTS idx_sync_outbox_status ON sync_outbox(status, next_retry_at);
CREATE INDEX IF NOT EXISTS idx_sync_outbox_entity ON sync_outbox(entity_id, event_version);

CREATE TABLE IF NOT EXISTS sync_outbox_delivery (
id BIGSERIAL PRIMARY KEY, event_id UUID NOT NULL, target_node_id VARCHAR(100) NOT NULL,
status VARCHAR(30) NOT NULL DEFAULT 'PENDING', retry_count INTEGER NOT NULL DEFAULT 0,
next_retry_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
sent_at TIMESTAMPTZ, acknowledged_at TIMESTAMPTZ, last_error TEXT,
CONSTRAINT uk_sync_outbox_delivery UNIQUE(event_id, target_node_id));
CREATE INDEX IF NOT EXISTS idx_outbox_delivery_status ON sync_outbox_delivery(status, next_retry_at);
CREATE INDEX IF NOT EXISTS idx_outbox_delivery_event ON sync_outbox_delivery(event_id);

CREATE TABLE IF NOT EXISTS processed_sync_event (
event_id UUID PRIMARY KEY, event_type VARCHAR(100) NOT NULL,
source_node_id VARCHAR(100) NOT NULL, processed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP);




INSERT INTO node_registry
(node_id, node_name, ip_address, port, status)
VALUES
('NODE-001', 'NODE-001', '10.10.1.11', 9120, 'ACTIVE'),
('NODE-002', 'NODE-002', '10.10.1.12', 9120, 'ACTIVE'),
('NODE-003', 'NODE-003', '10.10.1.13', 9120, 'ACTIVE'),
('NODE-004', 'NODE-004', '10.10.1.14', 9120, 'ACTIVE');






POST http://10.10.1.11:9120/api/location/users/USER-001
Content-Type: application/json




{
  "latitude": 12.9715987,
  "longitude": 77.5945660,
  "accuracy": 5.2,
  "timestamp": "2026-09-30T17:24:12Z"
}






