package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "user_location_history")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLocationHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "user_id", nullable = false)
	private String userId;
	@Column(name = "node_id", nullable = false)
	private String nodeId;
	@Column(nullable = false)
	private BigDecimal latitude;
	@Column(nullable = false)
	private BigDecimal longitude;
	private BigDecimal accuracy;
	@Column(name = "location_timestamp", nullable = false)
	private OffsetDateTime locationTimestamp;
	@Column(name = "location_version", nullable = false)
	private Long locationVersion;
	@Column(name = "recorded_at", nullable = false)
	private OffsetDateTime recordedAt;
}
