package com.example.location.repository;

import com.example.location.entity.SyncOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface SyncOutboxDeliveryRepository extends JpaRepository<SyncOutboxDelivery, Long> {
	Optional<SyncOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);
}
