package com.example.location.repository;

import com.example.location.entity.SyncOutbox;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.OffsetDateTime;
import java.util.List;

public interface SyncOutboxRepository extends JpaRepository<SyncOutbox, Long> {
	@Query("SELECT s FROM SyncOutbox s WHERE s.status='PENDING' OR (s.status='FAILED' AND (s.nextRetryAt IS NULL OR s.nextRetryAt<=:now)) ORDER BY s.createdAt")
	List<SyncOutbox> findEventsToProcess(@Param("now") OffsetDateTime now);
}
