package com.example.location.repository;

import com.example.location.entity.ProcessedSyncEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ProcessedSyncEventRepository extends JpaRepository<ProcessedSyncEvent, UUID> {
}
