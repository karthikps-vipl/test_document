package com.example.location.dto;

import java.util.UUID;

public record SyncAckResponse(UUID eventId, String status, String nodeId) {
}
