package com.example.location.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record LocationResponse(String userId, String nodeId, BigDecimal latitude, BigDecimal longitude,
		BigDecimal accuracy, OffsetDateTime timestamp, Long version) {
}
