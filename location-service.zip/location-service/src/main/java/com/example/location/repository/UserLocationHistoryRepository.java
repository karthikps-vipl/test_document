package com.example.location.repository;

import com.example.location.entity.UserLocationHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLocationHistoryRepository extends JpaRepository<UserLocationHistory, Long> {
}
