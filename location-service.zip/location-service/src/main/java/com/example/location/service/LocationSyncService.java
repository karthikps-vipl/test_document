package com.example.location.service;

import com.example.location.dto.*;
import com.example.location.entity.*;
import com.example.location.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.OffsetDateTime;

@Service
@RequiredArgsConstructor
public class LocationSyncService {
	private final UserLocationLatestRepository latestRepo;
	private final ProcessedSyncEventRepository processedRepo;
	private final NodeRegistryService nodeRegistryService;

	@Transactional
	public SyncAckResponse process(LocationSyncEvent event) {
		String current = nodeRegistryService.getCurrentNodeId();
		if (processedRepo.existsById(event.eventId()))
			return new SyncAckResponse(event.eventId(), "ACKNOWLEDGED", current);
		UserLocationLatest old = latestRepo.findById(event.entityId()).orElse(null);
		if (old != null && event.version() <= old.getLocationVersion()) {
			saveProcessed(event);
			return new SyncAckResponse(event.eventId(), "STALE_IGNORED", current);
		}
		latestRepo.save(UserLocationLatest.builder().userId(event.entityId()).nodeId(event.sourceNodeId())
				.latitude(event.latitude()).longitude(event.longitude()).accuracy(event.accuracy())
				.locationTimestamp(event.timestamp()).locationVersion(event.version()).updatedAt(OffsetDateTime.now())
				.build());
		saveProcessed(event);
		return new SyncAckResponse(event.eventId(), "ACKNOWLEDGED", current);
	}

	private void saveProcessed(LocationSyncEvent e) {
		processedRepo.save(ProcessedSyncEvent.builder().eventId(e.eventId()).eventType(e.eventType())
				.sourceNodeId(e.sourceNodeId()).processedAt(OffsetDateTime.now()).build());
	}
}
