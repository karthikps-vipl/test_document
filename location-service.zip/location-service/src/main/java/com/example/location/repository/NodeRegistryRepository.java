package com.example.location.repository;

import com.example.location.entity.NodeRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface NodeRegistryRepository extends JpaRepository<NodeRegistry, String> {
	Optional<NodeRegistry> findByIpAddress(String ipAddress);

	List<NodeRegistry> findByStatusAndNodeIdNot(String status, String nodeId);
}
