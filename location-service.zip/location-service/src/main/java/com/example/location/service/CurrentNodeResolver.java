package com.example.location.service;

import com.example.location.entity.NodeRegistry;
import com.example.location.repository.NodeRegistryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.net.InetAddress;

@Service
@RequiredArgsConstructor
public class CurrentNodeResolver {
	private final NodeRegistryRepository repo;

	public NodeRegistry getCurrentNode() {
		String ip = getLocalIpAddress();
		return repo.findByIpAddress(ip).orElseThrow(
				() -> new IllegalStateException("Current server IP " + ip + " is not registered in node_registry"));
	}

	public String getCurrentNodeId() {
		return getCurrentNode().getNodeId();
	}

	private String getLocalIpAddress() {
		try {
			return InetAddress.getLocalHost().getHostAddress();
		} catch (Exception e) {
			throw new IllegalStateException("Unable to determine local server IP", e);
		}
	}
}
