package com.example.location.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record LocationUpdateRequest(@NotNull @DecimalMin("-90.0") @DecimalMax("90.0") BigDecimal latitude,
		@NotNull @DecimalMin("-180.0") @DecimalMax("180.0") BigDecimal longitude, BigDecimal accuracy,
		@NotNull OffsetDateTime timestamp) {
}
