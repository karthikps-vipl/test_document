package com.example.location.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "sync_outbox")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncOutbox {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "event_id", nullable = false, unique = true)
	private UUID eventId;
	@Column(name = "event_type", nullable = false)
	private String eventType;
	@Column(name = "entity_type", nullable = false)
	private String entityType;
	@Column(name = "entity_id", nullable = false)
	private String entityId;
	@Column(name = "source_node_id", nullable = false)
	private String sourceNodeId;
	@Column(name = "event_version", nullable = false)
	private Long eventVersion;
	@Column(nullable = false, columnDefinition = "jsonb")
	private String payload;
	@Column(nullable = false)
	private String status;
	@Column(name = "retry_count", nullable = false)
	private Integer retryCount;
	@Column(name = "next_retry_at")
	private OffsetDateTime nextRetryAt;
	@Column(name = "created_at", nullable = false)
	private OffsetDateTime createdAt;
	@Column(name = "sent_at")
	private OffsetDateTime sentAt;
	@Column(name = "last_error")
	private String lastError;
}
