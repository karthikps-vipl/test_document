# Distributed Location Synchronization Service

Spring Boot 3.5.4 / Java 17 / PostgreSQL. This source includes durable per-target synchronization delivery, node availability gating, periodic peer health checks, and a cluster sync-health API.

## Important behavior

- A location update creates `sync_outbox` only when the existing time/distance synchronization policy says to synchronize.
- For each outbox event, the worker creates a `sync_outbox_delivery` record for every registered peer node, including registry rows whose status is `INACTIVE`.
- If a target is `INACTIVE`, delivery is set to `WAITING_FOR_NODE` and `next_retry_at` is cleared. No HTTP delivery attempt is made.
- For a target marked `ACTIVE`, the worker waits for a successful cached health probe before sending events.
- If a node is unreachable, delivery changes to `WAITING_FOR_NODE`, `next_retry_at` is cleared, and the health cache is marked down. The periodic health monitor probes active nodes; once health is UP, pending deliveries become eligible again.
- Application-level HTTP errors are retained as `FAILED` with backoff. No event is deleted on failure.
- Receiver processing should remain idempotent using `event_id` and location version checks.

## APIs

- `GET /internal/health/sync` — local application/database/sync endpoint health; intended for node-to-node checks.
- `GET /api/nodes/sync-health` — latest known health of registered peers and delivery backlog counts.
- Existing location endpoint: `POST /api/location/users/{userId}`.
- Existing internal receiver: `POST /internal/sync/location`.

The cluster health API reports the latest periodic probe cache, not an instantaneous probe on every request. Configure the health probe interval in `application.properties`.

## Build

```bash
mvn clean package
```

Set the real database password in `application.properties` (or externalize it as a secret in deployment). Confirm that the current host IP maps to exactly one `node_registry.ip_address` row. With Docker bridge networking, `InetAddress.getLocalHost()` may not return the host IP; adapt `CurrentNodeResolver` for your deployment network if required.

## Database migration

`V1__location_sync.sql` is the original schema supplied with the source. `V2__sync_delivery_health_index.sql` adds indexes for per-node backlog queries. For an already deployed database, apply V2 through your migration process; do not rerun V1 blindly because it contains seed inserts.

## Production notes

Protect `/api/nodes/sync-health` and `/internal/health/sync` with your internal network/security policy. Use HTTPS/mTLS for inter-node traffic in production. For multiple concurrent worker instances, add atomic row claiming/locking before scaling out the worker. Latest-state reconciliation is recommended after a node outage if intermediate location updates can be coalesced.

I've prepared the updated source code as a single ZIP, based on your uploaded `src(7).zip`.

### Download the complete updated source code

**[Download Location Service – Node Recovery, Synchronization & Health Check (ZIP)](sandbox:/mnt/data/location-service-sync-recovery-source.zip)**

### Changes included

| Component                            | Changes                                                                                                                           |
| ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------- |
| `SyncOutboxWorker.java`              | Creates delivery records for all registered nodes, including inactive nodes. Skips delivery when a node is inactive or unhealthy. |
| `NodeRegistryService.java`           | Adds methods to retrieve all registered nodes and active nodes separately.                                                        |
| `NodeSyncService.java`               | Handles successful acknowledgements, connection failures, retry scheduling, and waiting for node recovery.                        |
| `NodeHealthMonitor.java`             | New component that periodically checks active nodes and tracks their health.                                                      |
| `ClusterSyncHealthController.java`   | New API to check synchronization health across registered nodes.                                                                  |
| `LocalSyncHealthController.java`     | New internal API to check the local application and database health.                                                              |
| `RestClientConfig.java`              | Adds configurable HTTP connection and read timeouts.                                                                              |
| `SyncOutboxDeliveryRepository.java`  | Adds repository methods for querying pending and failed deliveries.                                                               |
| `application.properties`             | Adds configuration for health-check intervals and HTTP timeouts.                                                                  |
| `V2__sync_delivery_health_index.sql` | Adds indexes for delivery backlog queries.                                                                                        |
| `pom.xml`                            | Included at the project root for building the application.                                                                        |
| `README.md`                          | Explains the changes, APIs, build instructions, and deployment considerations.                                                    |

### How the updated code behaves

**When a node is inactive:**

* The worker creates or retains its `sync_outbox_delivery` records.
* Delivery status becomes `WAITING_FOR_NODE`.
* `next_retry_at` is cleared.
* No synchronization HTTP request is sent.

**When a node is active but unreachable:**

* Health monitoring identifies the node as unhealthy.
* Pending deliveries remain stored.
* Repeated per-event connection attempts are stopped while the node is considered unhealthy.

**When the node recovers:**

* The health monitor detects that its synchronization endpoint is healthy.
* Pending deliveries become eligible for processing again.
* Successfully delivered events are marked `ACKNOWLEDGED`.

### New APIs

**1. Check the local synchronization service**

```http
GET /internal/health/sync
```

**2. Check synchronization health across registered nodes**

```http
GET /api/nodes/sync-health
```

The cluster endpoint reports registry status, health status, synchronization-service status, and delivery backlog information.

### Before deploying

1. Extract the ZIP.
2. Configure the correct database credentials in `application.properties`.
3. For an existing database, apply the new **V2 migration** through your migration process. Do not blindly rerun V1, because it contains node seed inserts.
4. Build the application using `mvn clean package`.
5. Test with two nodes first: deactivate NODE-002, generate location updates on NODE-001, reactivate NODE-002, and verify that pending deliveries are acknowledged.

**One limitation:** I could not run a Maven build in this environment because Maven is not installed, so the updated source has not been compile-verified here. Please build and test it in your development environment before deploying it to production.




**Yes, mostly correct.** The changes were intended to be focused on node health monitoring, delivery tracking, recovery, and the synchronization health APIs. The existing location-processing and synchronization architecture was intended to remain in place.

However, the list you shared is **not the complete list of changes** in the updated ZIP. Besides those files, the project also includes a few supporting changes and additions.

### Complete change summary

| File / Component                     | Change type | What changed                                                                                                               |
| ------------------------------------ | ----------- | -------------------------------------------------------------------------------------------------------------------------- |
| `SyncOutboxWorker.java`              | Modified    | Creates delivery records for registered nodes, including inactive nodes, and waits when targets are inactive or unhealthy. |
| `NodeRegistryService.java`           | Modified    | Adds methods to retrieve all registered nodes and active nodes separately.                                                 |
| `NodeSyncService.java`               | Modified    | Handles acknowledgements, connection failures, delivery status, retry scheduling, and recovery.                            |
| `NodeHealthMonitor.java`             | **New**     | Periodically checks the health of active peer nodes.                                                                       |
| `ClusterSyncHealthController.java`   | **New**     | Adds the API to check synchronization health across registered nodes.                                                      |
| `LocalSyncHealthController.java`     | **New**     | Adds an internal API to check local application and database health.                                                       |
| `RestClientConfig.java`              | Modified    | Configures HTTP connection and read timeouts.                                                                              |
| `SyncOutboxDeliveryRepository.java`  | Modified    | Adds methods for querying pending and failed deliveries.                                                                   |
| `NodeRegistryRepository.java`        | Modified    | Adds a repository query to retrieve registered nodes.                                                                      |
| `LocalSyncHealthResponse.java`       | **New**     | Defines the response structure for local health checks.                                                                    |
| `NodeSyncHealthItem.java`            | **New**     | Defines the health information returned for an individual node.                                                            |
| `ClusterSyncHealthResponse.java`     | **New**     | Defines the aggregated cluster health response.                                                                            |
| `application.properties`             | Modified    | Adds health-check, HTTP timeout, and synchronization configuration properties.                                             |
| `V2__sync_delivery_health_index.sql` | **New**     | Adds indexes to improve delivery-status queries.                                                                           |
| `pom.xml`                            | **New**     | Adds Maven project configuration and dependencies.                                                                         |
| `Dockerfile`                         | **New**     | Adds a Docker build configuration.                                                                                         |
| `README.md`                          | **New**     | Documents the project, APIs, build instructions, and configuration.                                                        |

### What about the remaining files?

The intention was to leave the existing location-processing and synchronization logic unchanged wherever possible. For example:

* `LocationService.java` — intended to remain unchanged.
* Existing location entities and repositories — intended to remain unchanged, except for the explicitly listed repository changes.
* Existing location controllers — intended to remain unchanged.
* Existing database migration V1 — retained.
* Existing location history, latest-location updates, and outbox event creation — intended to continue working as before.

**One important qualification:** I have not verified a complete file-by-file diff against your original `src(7).zip` in this response. Therefore, I can confirm the intended scope from the previous work summary, but I cannot guarantee that every other file is byte-for-byte unchanged.

Also, the updated project has **not been compiled or tested**, because Maven was unavailable in the environment.

If you need certainty before deploying, compare the original and updated ZIPs using Git or a directory-diff tool. That will identify every modified, added, and deleted file.

