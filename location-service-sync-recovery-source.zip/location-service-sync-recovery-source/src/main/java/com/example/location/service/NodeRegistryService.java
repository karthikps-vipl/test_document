package com.example.location.service;

import com.example.location.entity.NodeRegistry;
import com.example.location.repository.NodeRegistryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NodeRegistryService {
    private final NodeRegistryRepository repo;
    private final CurrentNodeResolver resolver;

    public NodeRegistry getCurrentNode() { return resolver.getCurrentNode(); }
    public String getCurrentNodeId() { return resolver.getCurrentNodeId(); }

    public List<NodeRegistry> getAllRegisteredNodes() {
        return repo.findAll().stream().sorted(java.util.Comparator.comparing(NodeRegistry::getNodeId)).toList();
    }

    /** All registered targets, including INACTIVE nodes, so a durable delivery row can be created. */
    public List<NodeRegistry> getOtherRegisteredNodes() {
        return repo.findByNodeIdNotOrderByNodeId(resolver.getCurrentNodeId());
    }

    /** Kept for callers that explicitly need only administratively active nodes. */
    public List<NodeRegistry> getOtherActiveNodes() {
        return repo.findByStatusAndNodeIdNot("ACTIVE", resolver.getCurrentNodeId());
    }
}
