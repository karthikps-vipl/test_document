package com.example.location.service;

import com.example.location.dto.LocationSyncEvent;
import com.example.location.dto.SyncAckResponse;
import com.example.location.entity.NodeRegistry;
import com.example.location.entity.SyncOutbox;
import com.example.location.entity.SyncOutboxDelivery;
import com.example.location.repository.SyncOutboxDeliveryRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.time.OffsetDateTime;

@Service
@RequiredArgsConstructor
public class NodeSyncService {
    private final RestClient restClient;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final ObjectMapper mapper;
    private final NodeHealthMonitor healthMonitor;

    public void send(SyncOutbox outbox, SyncOutboxDelivery delivery, NodeRegistry target) {
        try {
            LocationSyncEvent event = mapper.readValue(outbox.getPayload(), LocationSyncEvent.class);
            LocationSyncEvent targetEvent = new LocationSyncEvent(event.eventId(), event.eventType(),
                    event.entityType(), event.entityId(), event.sourceNodeId(), target.getNodeId(),
                    event.version(), event.latitude(), event.longitude(), event.accuracy(), event.timestamp());

            String url = NodeHealthMonitor.baseUrl(target) + "/internal/sync/location";
            ResponseEntity<SyncAckResponse> response = restClient.post().uri(url).body(targetEvent)
                    .retrieve().toEntity(SyncAckResponse.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    && outbox.getEventId().equals(response.getBody().eventId())
                    && "ACKNOWLEDGED".equalsIgnoreCase(response.getBody().status())) {
                OffsetDateTime now = OffsetDateTime.now();
                delivery.setStatus("ACKNOWLEDGED");
                delivery.setSentAt(now);
                delivery.setAcknowledgedAt(now);
                delivery.setNextRetryAt(null);
                delivery.setLastError(null);
                deliveryRepo.save(delivery);
                return;
            }
            scheduleFailure(delivery, "Remote node returned no valid acknowledgement");
        } catch (ResourceAccessException ex) {
            // Connection refused, timeout, DNS/routing failure: stop per-event retries until health recovers.
            healthMonitor.markUnhealthy(target.getNodeId(), ex.getMessage());
            delivery.setStatus("WAITING_FOR_NODE");
            delivery.setNextRetryAt(null);
            delivery.setLastError(shorten(ex.getMessage()));
            deliveryRepo.save(delivery);
        } catch (RestClientResponseException ex) {
            // The endpoint answered, but rejected the request (for example 400/401/500). Back off and retain error.
            scheduleFailure(delivery, ex.getStatusCode() + " " + ex.getResponseBodyAsString());
        } catch (Exception ex) {
            scheduleFailure(delivery, ex.getMessage());
        }
    }

    private void scheduleFailure(SyncOutboxDelivery delivery, String message) {
        int retry = (delivery.getRetryCount() == null ? 0 : delivery.getRetryCount()) + 1;
        delivery.setRetryCount(retry);
        delivery.setStatus("FAILED");
        delivery.setNextRetryAt(OffsetDateTime.now().plusSeconds(Math.min(300, 10L * retry)));
        delivery.setLastError(shorten(message));
        deliveryRepo.save(delivery);
    }

    private String shorten(String message) {
        if (message == null) return "Unspecified delivery error";
        return message.length() > 2000 ? message.substring(0, 2000) : message;
    }
}
