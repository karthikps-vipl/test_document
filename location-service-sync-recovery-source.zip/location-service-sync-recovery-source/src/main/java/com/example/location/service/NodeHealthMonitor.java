package com.example.location.service;

import com.example.location.dto.LocalSyncHealthResponse;
import com.example.location.entity.NodeRegistry;
import com.example.location.repository.SyncOutboxDeliveryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class NodeHealthMonitor {
    private final NodeRegistryService nodeRegistryService;
    private final RestClient restClient;
    private final SyncOutboxDeliveryRepository deliveryRepo;

    private final Map<String, HealthState> states = new ConcurrentHashMap<>();

    public record HealthState(String healthStatus, String syncServiceStatus,
                              OffsetDateTime checkedAt, String details) {}

    /** Periodically probes ACTIVE nodes. Registry INACTIVE is an administrative decision, not a health result. */
    @Scheduled(fixedDelayString = "${sync.health.check-interval-ms:15000}", initialDelayString = "${sync.health.initial-delay-ms:3000}")
    public void refreshHealth() {
        List<NodeRegistry> targets;
        try {
            targets = nodeRegistryService.getOtherRegisteredNodes();
        } catch (Exception ex) {
            return; // Registry/database itself is unavailable; retain the last known cache.
        }

        List<CompletableFuture<Void>> futures = targets.stream()
                .filter(n -> isActive(n.getStatus()))
                .map(n -> CompletableFuture.runAsync(() -> probe(n)))
                .toList();
        try {
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                    .get(healthRefreshTimeoutSeconds, TimeUnit.SECONDS);
        } catch (Exception ignored) {
            // Individual probes have HTTP timeouts. A slow sweep must not block the scheduler indefinitely.
        }
    }

    @Value("${sync.health.refresh-timeout-seconds:5}")
    private long healthRefreshTimeoutSeconds;

    private void probe(NodeRegistry node) {
        OffsetDateTime now = OffsetDateTime.now();
        try {
            String url = baseUrl(node) + "/internal/health/sync";
            LocalSyncHealthResponse response = restClient.get().uri(url).retrieve().body(LocalSyncHealthResponse.class);
            if (response != null && "UP".equalsIgnoreCase(response.applicationStatus())
                    && "UP".equalsIgnoreCase(response.databaseStatus())
                    && "UP".equalsIgnoreCase(response.syncServiceStatus())) {
                states.put(node.getNodeId(), new HealthState("UP", "UP", now, null));
            } else {
                states.put(node.getNodeId(), new HealthState("DOWN", "UNHEALTHY", now,
                        "Remote health endpoint reported an unhealthy component"));
            }
        } catch (Exception ex) {
            states.put(node.getNodeId(), new HealthState("DOWN", "UNREACHABLE", now, shorten(ex.getMessage())));
        }
    }

    public boolean isHealthy(NodeRegistry node) {
        if (!isActive(node.getStatus())) return false;
        HealthState state = states.get(node.getNodeId());
        if (state == null || !"UP".equals(state.healthStatus())) return false;
        long freshnessSeconds = 45;
        return state.checkedAt() != null && state.checkedAt().isAfter(OffsetDateTime.now().minusSeconds(freshnessSeconds));
    }

    public void markUnhealthy(String nodeId, String details) {
        states.put(nodeId, new HealthState("DOWN", "UNREACHABLE", OffsetDateTime.now(), shorten(details)));
    }

    public HealthState getState(String nodeId) { return states.get(nodeId); }

    public long pendingCount(String nodeId) {
        return deliveryRepo.countPendingForNode(nodeId, List.of("PENDING", "FAILED", "WAITING_FOR_NODE"));
    }

    public long failedCount(String nodeId) {
        return deliveryRepo.countByTargetNodeIdAndStatus(nodeId, "FAILED");
    }

    public static boolean isActive(String status) {
        return status != null && "ACTIVE".equalsIgnoreCase(status.trim());
    }

    public static String baseUrl(NodeRegistry node) {
        String host = node.getIpAddress();
        if (host != null && host.startsWith("/") && host.indexOf('/') == 0) host = host.substring(1);
        return "http://" + host + ":" + node.getPort();
    }

    private String shorten(String text) {
        if (text == null) return "No additional details";
        return text.length() > 500 ? text.substring(0, 500) : text;
    }
}
