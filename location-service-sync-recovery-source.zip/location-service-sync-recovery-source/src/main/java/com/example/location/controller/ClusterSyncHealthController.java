package com.example.location.controller;

import com.example.location.dto.ClusterSyncHealthResponse;
import com.example.location.dto.NodeSyncHealthItem;
import com.example.location.entity.NodeRegistry;
import com.example.location.service.NodeHealthMonitor;
import com.example.location.service.NodeRegistryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/nodes")
@RequiredArgsConstructor
public class ClusterSyncHealthController {
    private final NodeRegistryService nodeRegistryService;
    private final NodeHealthMonitor healthMonitor;
    private final DataSource dataSource;

    /** Includes this node and every registered peer; peer status uses the latest periodic health probe. */
    @GetMapping("/sync-health")
    public ClusterSyncHealthResponse getClusterSyncHealth() {
        List<NodeRegistry> allNodes = nodeRegistryService.getAllRegisteredNodes();
        String currentNodeId = nodeRegistryService.getCurrentNodeId();
        List<NodeSyncHealthItem> items = new ArrayList<>();
        int active = 0, healthy = 0, unhealthy = 0, inactive = 0;

        for (NodeRegistry node : allNodes) {
            boolean isActive = NodeHealthMonitor.isActive(node.getStatus());
            boolean isLocal = node.getNodeId().equals(currentNodeId);
            String healthStatus;
            String syncStatus;
            OffsetDateTime checkedAt = null;
            String details = null;

            if (isLocal) {
                checkedAt = OffsetDateTime.now();
                boolean localUp = isLocalDatabaseUp();
                healthStatus = localUp ? "UP" : "DOWN";
                syncStatus = localUp ? "UP" : "DOWN";
                details = localUp ? "Local application is responding and database is reachable"
                        : "Local database health check failed";
            } else if (!isActive) {
                healthStatus = "NOT_CHECKED";
                syncStatus = "NOT_CHECKED";
                details = "Node is administratively inactive in node_registry";
            } else {
                NodeHealthMonitor.HealthState state = healthMonitor.getState(node.getNodeId());
                if (state == null) {
                    healthStatus = "UNKNOWN";
                    syncStatus = "UNKNOWN";
                    details = "Health probe has not completed yet";
                } else {
                    healthStatus = state.healthStatus();
                    syncStatus = state.syncServiceStatus();
                    checkedAt = state.checkedAt();
                    details = state.details();
                }
            }

            if (isActive) active++; else inactive++;
            if ("UP".equals(healthStatus)) healthy++;
            else if (isActive) unhealthy++;

            items.add(new NodeSyncHealthItem(node.getNodeId(), node.getStatus(), healthStatus, syncStatus,
                    checkedAt, isLocal ? 0 : healthMonitor.pendingCount(node.getNodeId()),
                    isLocal ? 0 : healthMonitor.failedCount(node.getNodeId()), details));
        }
        return new ClusterSyncHealthResponse(OffsetDateTime.now(), allNodes.size(), active, healthy, unhealthy,
                inactive, items);
    }

    private boolean isLocalDatabaseUp() {
        try (Connection connection = dataSource.getConnection()) {
            return connection.isValid(2);
        } catch (Exception ex) {
            return false;
        }
    }
}
