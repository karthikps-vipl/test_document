package com.example.location.dto;

import java.time.OffsetDateTime;
import java.util.List;

public record ClusterSyncHealthResponse(
        OffsetDateTime checkedAt,
        int totalNodes,
        int activeNodes,
        int healthyNodes,
        int unhealthyNodes,
        int inactiveNodes,
        List<NodeSyncHealthItem> nodes) {
}
