package com.example.location.dto;

import java.time.OffsetDateTime;

public record LocalSyncHealthResponse(
        String nodeId,
        String applicationStatus,
        String databaseStatus,
        String syncServiceStatus,
        OffsetDateTime checkedAt) {
}
