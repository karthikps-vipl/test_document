package com.example.location.repository;

import com.example.location.entity.SyncOutboxDelivery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SyncOutboxDeliveryRepository extends JpaRepository<SyncOutboxDelivery, Long> {
    Optional<SyncOutboxDelivery> findByEventIdAndTargetNodeId(UUID eventId, String targetNodeId);

    List<SyncOutboxDelivery> findByTargetNodeIdAndStatusIn(String targetNodeId, List<String> statuses);

    long countByTargetNodeIdAndStatus(String targetNodeId, String status);

    @Query("select count(d) from SyncOutboxDelivery d where d.targetNodeId = :nodeId and d.status in :statuses")
    long countPendingForNode(@Param("nodeId") String nodeId, @Param("statuses") List<String> statuses);
}
