package com.example.location.service;

import com.example.location.entity.NodeRegistry;
import com.example.location.entity.SyncOutbox;
import com.example.location.entity.SyncOutboxDelivery;
import com.example.location.repository.SyncOutboxDeliveryRepository;
import com.example.location.repository.SyncOutboxRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;

@Component
@RequiredArgsConstructor
public class SyncOutboxWorker {
    private final SyncOutboxRepository outboxRepo;
    private final SyncOutboxDeliveryRepository deliveryRepo;
    private final NodeRegistryService nodeRegistryService;
    private final NodeSyncService nodeSyncService;
    private final NodeHealthMonitor healthMonitor;

    @Value("${sync.outbox.batch-size:100}")
    private int batchSize;

    @Scheduled(fixedDelayString = "${sync.outbox.fixed-delay-ms:1000}")
    public void processOutbox() {
        outboxRepo.findEventsToProcess(OffsetDateTime.now()).stream()
                .limit(batchSize)
                .forEach(this::processEvent);
    }

    private void processEvent(SyncOutbox event) {
        // Do not filter by ACTIVE here: inactive nodes still need durable delivery rows.
        for (NodeRegistry target : nodeRegistryService.getOtherRegisteredNodes()) {
            SyncOutboxDelivery delivery = deliveryRepo
                    .findByEventIdAndTargetNodeId(event.getEventId(), target.getNodeId())
                    .orElseGet(() -> deliveryRepo.save(SyncOutboxDelivery.builder()
                            .eventId(event.getEventId())
                            .targetNodeId(target.getNodeId())
                            .status("PENDING")
                            .retryCount(0)
                            .createdAt(OffsetDateTime.now())
                            .build()));

            if ("ACKNOWLEDGED".equals(delivery.getStatus())) continue;

            // An inactive node is administratively disabled. Keep the row, but do not retry or set next_retry_at.
            if (!NodeHealthMonitor.isActive(target.getStatus())) {
                waitForNode(delivery, "Target node is INACTIVE in node_registry");
                continue;
            }

            // Health is periodically probed. Unknown/stale/down nodes are not sent data until healthy.
            if (!healthMonitor.isHealthy(target)) {
                waitForNode(delivery, "Target node is not currently reported healthy");
                continue;
            }

            // For ordinary transient application errors, respect scheduled backoff.
            if ("FAILED".equals(delivery.getStatus()) && delivery.getNextRetryAt() != null
                    && delivery.getNextRetryAt().isAfter(OffsetDateTime.now())) {
                continue;
            }

            nodeSyncService.send(event, delivery, target);
        }
    }

    private void waitForNode(SyncOutboxDelivery delivery, String reason) {
        delivery.setStatus("WAITING_FOR_NODE");
        delivery.setNextRetryAt(null);
        delivery.setLastError(reason);
        deliveryRepo.save(delivery);
    }
}
