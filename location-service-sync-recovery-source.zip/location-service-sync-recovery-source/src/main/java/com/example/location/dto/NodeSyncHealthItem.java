package com.example.location.dto;

import java.time.OffsetDateTime;

public record NodeSyncHealthItem(
        String nodeId,
        String registryStatus,
        String healthStatus,
        String syncServiceStatus,
        OffsetDateTime lastCheckedAt,
        long pendingDeliveries,
        long failedDeliveries,
        String details) {
}
