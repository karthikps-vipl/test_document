package com.example.location.controller;

import com.example.location.dto.LocalSyncHealthResponse;
import com.example.location.service.NodeRegistryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.OffsetDateTime;

@RestController
@RequestMapping("/internal/health")
@RequiredArgsConstructor
public class LocalSyncHealthController {
    private final DataSource dataSource;
    private final NodeRegistryService nodeRegistryService;

    @GetMapping("/sync")
    public ResponseEntity<LocalSyncHealthResponse> syncHealth() {
        String databaseStatus = "DOWN";
        try (Connection connection = dataSource.getConnection()) {
            databaseStatus = connection.isValid(2) ? "UP" : "DOWN";
        } catch (Exception ignored) {
            databaseStatus = "DOWN";
        }
        String appStatus = "UP";
        String syncStatus = "UP";
        LocalSyncHealthResponse body = new LocalSyncHealthResponse(
                safeNodeId(), appStatus, databaseStatus, databaseStatus.equals("UP") ? syncStatus : "DOWN",
                OffsetDateTime.now());
        boolean healthy = "UP".equals(databaseStatus);
        return ResponseEntity.status(healthy ? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE).body(body);
    }

    private String safeNodeId() {
        try { return nodeRegistryService.getCurrentNodeId(); }
        catch (Exception ex) { return "UNKNOWN"; }
    }
}
