-- Supports per-node backlog and recovery queries.
CREATE INDEX IF NOT EXISTS idx_outbox_delivery_target_status
    ON sync_outbox_delivery(target_node_id, status, next_retry_at);

CREATE INDEX IF NOT EXISTS idx_outbox_delivery_status_created
    ON sync_outbox_delivery(status, created_at);
